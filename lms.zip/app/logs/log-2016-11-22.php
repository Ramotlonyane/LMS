<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-22 09:43:44 --> Config Class Initialized
INFO - 2016-11-22 09:43:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:43:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:43:44 --> Utf8 Class Initialized
INFO - 2016-11-22 09:43:44 --> URI Class Initialized
DEBUG - 2016-11-22 09:43:44 --> No URI present. Default controller set.
INFO - 2016-11-22 09:43:44 --> Router Class Initialized
INFO - 2016-11-22 09:43:44 --> Output Class Initialized
INFO - 2016-11-22 09:43:44 --> Security Class Initialized
DEBUG - 2016-11-22 09:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:43:44 --> Input Class Initialized
INFO - 2016-11-22 09:43:44 --> Language Class Initialized
INFO - 2016-11-22 09:43:45 --> Loader Class Initialized
INFO - 2016-11-22 09:43:45 --> Helper loaded: url_helper
INFO - 2016-11-22 09:43:45 --> Helper loaded: form_helper
INFO - 2016-11-22 09:43:45 --> Database Driver Class Initialized
INFO - 2016-11-22 09:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:43:45 --> Controller Class Initialized
INFO - 2016-11-22 09:43:45 --> Model Class Initialized
INFO - 2016-11-22 09:43:45 --> Model Class Initialized
INFO - 2016-11-22 09:43:45 --> Model Class Initialized
INFO - 2016-11-22 09:43:45 --> Model Class Initialized
INFO - 2016-11-22 09:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:43:45 --> Pagination Class Initialized
INFO - 2016-11-22 09:43:45 --> Helper loaded: app_helper
INFO - 2016-11-22 09:43:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:43:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 09:43:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:43:45 --> Final output sent to browser
DEBUG - 2016-11-22 09:43:46 --> Total execution time: 1.6099
INFO - 2016-11-22 09:43:59 --> Config Class Initialized
INFO - 2016-11-22 09:43:59 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:43:59 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:43:59 --> Utf8 Class Initialized
INFO - 2016-11-22 09:43:59 --> URI Class Initialized
INFO - 2016-11-22 09:43:59 --> Router Class Initialized
INFO - 2016-11-22 09:43:59 --> Output Class Initialized
INFO - 2016-11-22 09:43:59 --> Security Class Initialized
DEBUG - 2016-11-22 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:43:59 --> Input Class Initialized
INFO - 2016-11-22 09:43:59 --> Language Class Initialized
INFO - 2016-11-22 09:43:59 --> Loader Class Initialized
INFO - 2016-11-22 09:43:59 --> Helper loaded: url_helper
INFO - 2016-11-22 09:43:59 --> Helper loaded: form_helper
INFO - 2016-11-22 09:43:59 --> Database Driver Class Initialized
INFO - 2016-11-22 09:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:43:59 --> Controller Class Initialized
INFO - 2016-11-22 09:43:59 --> Model Class Initialized
INFO - 2016-11-22 09:43:59 --> Model Class Initialized
INFO - 2016-11-22 09:43:59 --> Model Class Initialized
INFO - 2016-11-22 09:43:59 --> Model Class Initialized
INFO - 2016-11-22 09:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:43:59 --> Pagination Class Initialized
INFO - 2016-11-22 09:43:59 --> Helper loaded: app_helper
DEBUG - 2016-11-22 09:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-22 09:43:59 --> Model Class Initialized
INFO - 2016-11-22 09:43:59 --> Final output sent to browser
DEBUG - 2016-11-22 09:43:59 --> Total execution time: 0.6508
INFO - 2016-11-22 09:43:59 --> Config Class Initialized
INFO - 2016-11-22 09:43:59 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:43:59 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:43:59 --> Utf8 Class Initialized
INFO - 2016-11-22 09:43:59 --> URI Class Initialized
DEBUG - 2016-11-22 09:43:59 --> No URI present. Default controller set.
INFO - 2016-11-22 09:43:59 --> Router Class Initialized
INFO - 2016-11-22 09:43:59 --> Output Class Initialized
INFO - 2016-11-22 09:43:59 --> Security Class Initialized
DEBUG - 2016-11-22 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:43:59 --> Input Class Initialized
INFO - 2016-11-22 09:43:59 --> Language Class Initialized
INFO - 2016-11-22 09:44:00 --> Loader Class Initialized
INFO - 2016-11-22 09:44:00 --> Helper loaded: url_helper
INFO - 2016-11-22 09:44:00 --> Helper loaded: form_helper
INFO - 2016-11-22 09:44:00 --> Database Driver Class Initialized
INFO - 2016-11-22 09:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:44:00 --> Controller Class Initialized
INFO - 2016-11-22 09:44:00 --> Model Class Initialized
INFO - 2016-11-22 09:44:00 --> Model Class Initialized
INFO - 2016-11-22 09:44:00 --> Model Class Initialized
INFO - 2016-11-22 09:44:00 --> Model Class Initialized
INFO - 2016-11-22 09:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:44:00 --> Pagination Class Initialized
INFO - 2016-11-22 09:44:00 --> Helper loaded: app_helper
INFO - 2016-11-22 09:44:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:44:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:44:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:44:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:44:01 --> Final output sent to browser
DEBUG - 2016-11-22 09:44:01 --> Total execution time: 1.6972
INFO - 2016-11-22 09:44:10 --> Config Class Initialized
INFO - 2016-11-22 09:44:10 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:44:10 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:44:10 --> Utf8 Class Initialized
INFO - 2016-11-22 09:44:10 --> URI Class Initialized
INFO - 2016-11-22 09:44:10 --> Router Class Initialized
INFO - 2016-11-22 09:44:10 --> Output Class Initialized
INFO - 2016-11-22 09:44:10 --> Security Class Initialized
DEBUG - 2016-11-22 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:44:10 --> Input Class Initialized
INFO - 2016-11-22 09:44:10 --> Language Class Initialized
INFO - 2016-11-22 09:44:10 --> Loader Class Initialized
INFO - 2016-11-22 09:44:10 --> Helper loaded: url_helper
INFO - 2016-11-22 09:44:10 --> Helper loaded: form_helper
INFO - 2016-11-22 09:44:10 --> Database Driver Class Initialized
INFO - 2016-11-22 09:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:44:11 --> Controller Class Initialized
INFO - 2016-11-22 09:44:11 --> Model Class Initialized
INFO - 2016-11-22 09:44:11 --> Form Validation Class Initialized
INFO - 2016-11-22 09:44:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 09:44:11 --> Final output sent to browser
DEBUG - 2016-11-22 09:44:11 --> Total execution time: 0.2582
INFO - 2016-11-22 09:44:12 --> Config Class Initialized
INFO - 2016-11-22 09:44:12 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:44:12 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:44:12 --> Utf8 Class Initialized
INFO - 2016-11-22 09:44:12 --> URI Class Initialized
DEBUG - 2016-11-22 09:44:12 --> No URI present. Default controller set.
INFO - 2016-11-22 09:44:12 --> Router Class Initialized
INFO - 2016-11-22 09:44:12 --> Output Class Initialized
INFO - 2016-11-22 09:44:12 --> Security Class Initialized
DEBUG - 2016-11-22 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:44:12 --> Input Class Initialized
INFO - 2016-11-22 09:44:12 --> Language Class Initialized
INFO - 2016-11-22 09:44:12 --> Loader Class Initialized
INFO - 2016-11-22 09:44:12 --> Helper loaded: url_helper
INFO - 2016-11-22 09:44:12 --> Helper loaded: form_helper
INFO - 2016-11-22 09:44:12 --> Database Driver Class Initialized
INFO - 2016-11-22 09:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:44:13 --> Controller Class Initialized
INFO - 2016-11-22 09:44:13 --> Model Class Initialized
INFO - 2016-11-22 09:44:13 --> Model Class Initialized
INFO - 2016-11-22 09:44:13 --> Model Class Initialized
INFO - 2016-11-22 09:44:13 --> Model Class Initialized
INFO - 2016-11-22 09:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:44:13 --> Pagination Class Initialized
INFO - 2016-11-22 09:44:13 --> Helper loaded: app_helper
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:44:13 --> Final output sent to browser
DEBUG - 2016-11-22 09:44:13 --> Total execution time: 0.4571
INFO - 2016-11-22 09:44:21 --> Config Class Initialized
INFO - 2016-11-22 09:44:21 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:44:21 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:44:21 --> Utf8 Class Initialized
INFO - 2016-11-22 09:44:21 --> URI Class Initialized
INFO - 2016-11-22 09:44:21 --> Router Class Initialized
INFO - 2016-11-22 09:44:21 --> Output Class Initialized
INFO - 2016-11-22 09:44:21 --> Security Class Initialized
DEBUG - 2016-11-22 09:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:44:21 --> Input Class Initialized
INFO - 2016-11-22 09:44:21 --> Language Class Initialized
INFO - 2016-11-22 09:44:21 --> Loader Class Initialized
INFO - 2016-11-22 09:44:21 --> Helper loaded: url_helper
INFO - 2016-11-22 09:44:21 --> Helper loaded: form_helper
INFO - 2016-11-22 09:44:21 --> Database Driver Class Initialized
INFO - 2016-11-22 09:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:44:21 --> Controller Class Initialized
INFO - 2016-11-22 09:44:21 --> Model Class Initialized
INFO - 2016-11-22 09:44:21 --> Form Validation Class Initialized
INFO - 2016-11-22 09:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:44:21 --> Pagination Class Initialized
INFO - 2016-11-22 09:44:21 --> Helper loaded: app_helper
INFO - 2016-11-22 09:44:21 --> Email Class Initialized
INFO - 2016-11-22 09:44:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:44:21 --> Final output sent to browser
DEBUG - 2016-11-22 09:44:21 --> Total execution time: 0.2432
INFO - 2016-11-22 09:44:34 --> Config Class Initialized
INFO - 2016-11-22 09:44:34 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:44:34 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:44:34 --> Utf8 Class Initialized
INFO - 2016-11-22 09:44:35 --> URI Class Initialized
INFO - 2016-11-22 09:44:35 --> Router Class Initialized
INFO - 2016-11-22 09:44:35 --> Output Class Initialized
INFO - 2016-11-22 09:44:35 --> Security Class Initialized
DEBUG - 2016-11-22 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:44:35 --> Input Class Initialized
INFO - 2016-11-22 09:44:35 --> Language Class Initialized
INFO - 2016-11-22 09:44:35 --> Loader Class Initialized
INFO - 2016-11-22 09:44:35 --> Helper loaded: url_helper
INFO - 2016-11-22 09:44:35 --> Helper loaded: form_helper
INFO - 2016-11-22 09:44:35 --> Database Driver Class Initialized
INFO - 2016-11-22 09:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:44:35 --> Controller Class Initialized
INFO - 2016-11-22 09:44:35 --> Model Class Initialized
INFO - 2016-11-22 09:44:35 --> Form Validation Class Initialized
INFO - 2016-11-22 09:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:44:35 --> Pagination Class Initialized
INFO - 2016-11-22 09:44:35 --> Helper loaded: app_helper
INFO - 2016-11-22 09:44:35 --> Email Class Initialized
ERROR - 2016-11-22 09:44:35 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:44:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:44:35 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:44:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:44:35 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:44:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:44:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:44:35 --> Final output sent to browser
DEBUG - 2016-11-22 09:44:35 --> Total execution time: 0.3386
INFO - 2016-11-22 09:44:41 --> Config Class Initialized
INFO - 2016-11-22 09:44:41 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:44:41 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:44:41 --> Utf8 Class Initialized
INFO - 2016-11-22 09:44:41 --> URI Class Initialized
INFO - 2016-11-22 09:44:41 --> Router Class Initialized
INFO - 2016-11-22 09:44:41 --> Output Class Initialized
INFO - 2016-11-22 09:44:41 --> Security Class Initialized
DEBUG - 2016-11-22 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:44:41 --> Input Class Initialized
INFO - 2016-11-22 09:44:41 --> Language Class Initialized
INFO - 2016-11-22 09:44:41 --> Loader Class Initialized
INFO - 2016-11-22 09:44:41 --> Helper loaded: url_helper
INFO - 2016-11-22 09:44:41 --> Helper loaded: form_helper
INFO - 2016-11-22 09:44:41 --> Database Driver Class Initialized
INFO - 2016-11-22 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:44:41 --> Controller Class Initialized
INFO - 2016-11-22 09:44:41 --> Model Class Initialized
INFO - 2016-11-22 09:44:41 --> Form Validation Class Initialized
INFO - 2016-11-22 09:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:44:41 --> Pagination Class Initialized
INFO - 2016-11-22 09:44:41 --> Helper loaded: app_helper
INFO - 2016-11-22 09:44:41 --> Email Class Initialized
INFO - 2016-11-22 09:44:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:44:41 --> Final output sent to browser
DEBUG - 2016-11-22 09:44:41 --> Total execution time: 0.2721
INFO - 2016-11-22 09:45:01 --> Config Class Initialized
INFO - 2016-11-22 09:45:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:45:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:45:01 --> Utf8 Class Initialized
INFO - 2016-11-22 09:45:01 --> URI Class Initialized
INFO - 2016-11-22 09:45:01 --> Router Class Initialized
INFO - 2016-11-22 09:45:01 --> Output Class Initialized
INFO - 2016-11-22 09:45:01 --> Security Class Initialized
DEBUG - 2016-11-22 09:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:45:01 --> Input Class Initialized
INFO - 2016-11-22 09:45:01 --> Language Class Initialized
INFO - 2016-11-22 09:45:01 --> Loader Class Initialized
INFO - 2016-11-22 09:45:01 --> Helper loaded: url_helper
INFO - 2016-11-22 09:45:01 --> Helper loaded: form_helper
INFO - 2016-11-22 09:45:01 --> Database Driver Class Initialized
INFO - 2016-11-22 09:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:45:01 --> Controller Class Initialized
INFO - 2016-11-22 09:45:01 --> Model Class Initialized
INFO - 2016-11-22 09:45:01 --> Form Validation Class Initialized
INFO - 2016-11-22 09:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:45:01 --> Pagination Class Initialized
INFO - 2016-11-22 09:45:01 --> Helper loaded: app_helper
INFO - 2016-11-22 09:45:01 --> Email Class Initialized
ERROR - 2016-11-22 09:45:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:45:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:45:01 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:45:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:45:01 --> Final output sent to browser
DEBUG - 2016-11-22 09:45:01 --> Total execution time: 0.3146
INFO - 2016-11-22 09:45:35 --> Config Class Initialized
INFO - 2016-11-22 09:45:35 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:45:35 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:45:35 --> Utf8 Class Initialized
INFO - 2016-11-22 09:45:35 --> URI Class Initialized
DEBUG - 2016-11-22 09:45:35 --> No URI present. Default controller set.
INFO - 2016-11-22 09:45:35 --> Router Class Initialized
INFO - 2016-11-22 09:45:35 --> Output Class Initialized
INFO - 2016-11-22 09:45:35 --> Security Class Initialized
DEBUG - 2016-11-22 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:45:35 --> Input Class Initialized
INFO - 2016-11-22 09:45:35 --> Language Class Initialized
INFO - 2016-11-22 09:45:35 --> Loader Class Initialized
INFO - 2016-11-22 09:45:35 --> Helper loaded: url_helper
INFO - 2016-11-22 09:45:35 --> Helper loaded: form_helper
INFO - 2016-11-22 09:45:35 --> Database Driver Class Initialized
INFO - 2016-11-22 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:45:35 --> Controller Class Initialized
INFO - 2016-11-22 09:45:35 --> Model Class Initialized
INFO - 2016-11-22 09:45:35 --> Model Class Initialized
INFO - 2016-11-22 09:45:35 --> Model Class Initialized
INFO - 2016-11-22 09:45:35 --> Model Class Initialized
INFO - 2016-11-22 09:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:45:35 --> Pagination Class Initialized
INFO - 2016-11-22 09:45:35 --> Helper loaded: app_helper
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:45:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:45:35 --> Final output sent to browser
DEBUG - 2016-11-22 09:45:35 --> Total execution time: 0.3761
INFO - 2016-11-22 09:46:10 --> Config Class Initialized
INFO - 2016-11-22 09:46:10 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:10 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:10 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:11 --> URI Class Initialized
INFO - 2016-11-22 09:46:11 --> Router Class Initialized
INFO - 2016-11-22 09:46:11 --> Output Class Initialized
INFO - 2016-11-22 09:46:11 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:11 --> Input Class Initialized
INFO - 2016-11-22 09:46:11 --> Language Class Initialized
INFO - 2016-11-22 09:46:11 --> Loader Class Initialized
INFO - 2016-11-22 09:46:11 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:11 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:11 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:11 --> Controller Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:11 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:11 --> Helper loaded: app_helper
DEBUG - 2016-11-22 09:46:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-22 09:46:11 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-22 09:46:11 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-22 09:46:11 --> Config Class Initialized
INFO - 2016-11-22 09:46:11 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:11 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:11 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:11 --> URI Class Initialized
DEBUG - 2016-11-22 09:46:11 --> No URI present. Default controller set.
INFO - 2016-11-22 09:46:11 --> Router Class Initialized
INFO - 2016-11-22 09:46:11 --> Output Class Initialized
INFO - 2016-11-22 09:46:11 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:11 --> Input Class Initialized
INFO - 2016-11-22 09:46:11 --> Language Class Initialized
INFO - 2016-11-22 09:46:11 --> Loader Class Initialized
INFO - 2016-11-22 09:46:11 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:11 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:11 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:11 --> Controller Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Model Class Initialized
INFO - 2016-11-22 09:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:11 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:11 --> Helper loaded: app_helper
INFO - 2016-11-22 09:46:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:46:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 09:46:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:46:11 --> Final output sent to browser
DEBUG - 2016-11-22 09:46:11 --> Total execution time: 0.2571
INFO - 2016-11-22 09:46:23 --> Config Class Initialized
INFO - 2016-11-22 09:46:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:23 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:23 --> URI Class Initialized
INFO - 2016-11-22 09:46:23 --> Router Class Initialized
INFO - 2016-11-22 09:46:23 --> Output Class Initialized
INFO - 2016-11-22 09:46:23 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:23 --> Input Class Initialized
INFO - 2016-11-22 09:46:23 --> Language Class Initialized
INFO - 2016-11-22 09:46:23 --> Loader Class Initialized
INFO - 2016-11-22 09:46:23 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:23 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:23 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:23 --> Controller Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:23 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:23 --> Helper loaded: app_helper
DEBUG - 2016-11-22 09:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Final output sent to browser
DEBUG - 2016-11-22 09:46:23 --> Total execution time: 0.2446
INFO - 2016-11-22 09:46:23 --> Config Class Initialized
INFO - 2016-11-22 09:46:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:23 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:23 --> URI Class Initialized
DEBUG - 2016-11-22 09:46:23 --> No URI present. Default controller set.
INFO - 2016-11-22 09:46:23 --> Router Class Initialized
INFO - 2016-11-22 09:46:23 --> Output Class Initialized
INFO - 2016-11-22 09:46:23 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:23 --> Input Class Initialized
INFO - 2016-11-22 09:46:23 --> Language Class Initialized
INFO - 2016-11-22 09:46:23 --> Loader Class Initialized
INFO - 2016-11-22 09:46:23 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:23 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:23 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:23 --> Controller Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Model Class Initialized
INFO - 2016-11-22 09:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:23 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:23 --> Helper loaded: app_helper
INFO - 2016-11-22 09:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:46:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:46:24 --> Final output sent to browser
DEBUG - 2016-11-22 09:46:24 --> Total execution time: 0.3571
INFO - 2016-11-22 09:46:28 --> Config Class Initialized
INFO - 2016-11-22 09:46:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:28 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:28 --> URI Class Initialized
INFO - 2016-11-22 09:46:28 --> Router Class Initialized
INFO - 2016-11-22 09:46:28 --> Output Class Initialized
INFO - 2016-11-22 09:46:28 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:28 --> Input Class Initialized
INFO - 2016-11-22 09:46:28 --> Language Class Initialized
INFO - 2016-11-22 09:46:28 --> Loader Class Initialized
INFO - 2016-11-22 09:46:28 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:28 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:28 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:28 --> Controller Class Initialized
INFO - 2016-11-22 09:46:28 --> Model Class Initialized
INFO - 2016-11-22 09:46:28 --> Form Validation Class Initialized
INFO - 2016-11-22 09:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:28 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:28 --> Helper loaded: app_helper
INFO - 2016-11-22 09:46:28 --> Email Class Initialized
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:46:28 --> Final output sent to browser
DEBUG - 2016-11-22 09:46:28 --> Total execution time: 0.4082
INFO - 2016-11-22 09:46:38 --> Config Class Initialized
INFO - 2016-11-22 09:46:38 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:38 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:38 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:38 --> URI Class Initialized
DEBUG - 2016-11-22 09:46:38 --> No URI present. Default controller set.
INFO - 2016-11-22 09:46:38 --> Router Class Initialized
INFO - 2016-11-22 09:46:38 --> Output Class Initialized
INFO - 2016-11-22 09:46:38 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:38 --> Input Class Initialized
INFO - 2016-11-22 09:46:38 --> Language Class Initialized
INFO - 2016-11-22 09:46:38 --> Loader Class Initialized
INFO - 2016-11-22 09:46:38 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:38 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:38 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:38 --> Controller Class Initialized
INFO - 2016-11-22 09:46:38 --> Model Class Initialized
INFO - 2016-11-22 09:46:38 --> Model Class Initialized
INFO - 2016-11-22 09:46:38 --> Model Class Initialized
INFO - 2016-11-22 09:46:38 --> Model Class Initialized
INFO - 2016-11-22 09:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:38 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:38 --> Helper loaded: app_helper
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:46:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:46:38 --> Final output sent to browser
DEBUG - 2016-11-22 09:46:38 --> Total execution time: 0.3680
INFO - 2016-11-22 09:46:42 --> Config Class Initialized
INFO - 2016-11-22 09:46:42 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:46:42 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:46:42 --> Utf8 Class Initialized
INFO - 2016-11-22 09:46:42 --> URI Class Initialized
INFO - 2016-11-22 09:46:42 --> Router Class Initialized
INFO - 2016-11-22 09:46:42 --> Output Class Initialized
INFO - 2016-11-22 09:46:42 --> Security Class Initialized
DEBUG - 2016-11-22 09:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:46:42 --> Input Class Initialized
INFO - 2016-11-22 09:46:42 --> Language Class Initialized
INFO - 2016-11-22 09:46:42 --> Loader Class Initialized
INFO - 2016-11-22 09:46:42 --> Helper loaded: url_helper
INFO - 2016-11-22 09:46:42 --> Helper loaded: form_helper
INFO - 2016-11-22 09:46:42 --> Database Driver Class Initialized
INFO - 2016-11-22 09:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:46:42 --> Controller Class Initialized
INFO - 2016-11-22 09:46:42 --> Model Class Initialized
INFO - 2016-11-22 09:46:42 --> Form Validation Class Initialized
INFO - 2016-11-22 09:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:46:42 --> Pagination Class Initialized
INFO - 2016-11-22 09:46:42 --> Helper loaded: app_helper
INFO - 2016-11-22 09:46:42 --> Email Class Initialized
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:46:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:46:42 --> Final output sent to browser
DEBUG - 2016-11-22 09:46:42 --> Total execution time: 0.3898
INFO - 2016-11-22 09:49:05 --> Config Class Initialized
INFO - 2016-11-22 09:49:05 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:49:05 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:49:05 --> Utf8 Class Initialized
INFO - 2016-11-22 09:49:05 --> URI Class Initialized
DEBUG - 2016-11-22 09:49:05 --> No URI present. Default controller set.
INFO - 2016-11-22 09:49:05 --> Router Class Initialized
INFO - 2016-11-22 09:49:05 --> Output Class Initialized
INFO - 2016-11-22 09:49:05 --> Security Class Initialized
DEBUG - 2016-11-22 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:49:05 --> Input Class Initialized
INFO - 2016-11-22 09:49:05 --> Language Class Initialized
INFO - 2016-11-22 09:49:05 --> Loader Class Initialized
INFO - 2016-11-22 09:49:05 --> Helper loaded: url_helper
INFO - 2016-11-22 09:49:05 --> Helper loaded: form_helper
INFO - 2016-11-22 09:49:06 --> Database Driver Class Initialized
INFO - 2016-11-22 09:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:49:06 --> Controller Class Initialized
INFO - 2016-11-22 09:49:06 --> Model Class Initialized
INFO - 2016-11-22 09:49:06 --> Model Class Initialized
INFO - 2016-11-22 09:49:06 --> Model Class Initialized
INFO - 2016-11-22 09:49:06 --> Model Class Initialized
INFO - 2016-11-22 09:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:49:06 --> Pagination Class Initialized
INFO - 2016-11-22 09:49:06 --> Helper loaded: app_helper
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:49:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:49:06 --> Final output sent to browser
DEBUG - 2016-11-22 09:49:06 --> Total execution time: 0.3706
INFO - 2016-11-22 09:49:09 --> Config Class Initialized
INFO - 2016-11-22 09:49:09 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:49:09 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:49:09 --> Utf8 Class Initialized
INFO - 2016-11-22 09:49:09 --> URI Class Initialized
INFO - 2016-11-22 09:49:09 --> Router Class Initialized
INFO - 2016-11-22 09:49:09 --> Output Class Initialized
INFO - 2016-11-22 09:49:09 --> Security Class Initialized
DEBUG - 2016-11-22 09:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:49:09 --> Input Class Initialized
INFO - 2016-11-22 09:49:09 --> Language Class Initialized
INFO - 2016-11-22 09:49:09 --> Loader Class Initialized
INFO - 2016-11-22 09:49:09 --> Helper loaded: url_helper
INFO - 2016-11-22 09:49:09 --> Helper loaded: form_helper
INFO - 2016-11-22 09:49:09 --> Database Driver Class Initialized
INFO - 2016-11-22 09:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:49:09 --> Controller Class Initialized
INFO - 2016-11-22 09:49:09 --> Model Class Initialized
INFO - 2016-11-22 09:49:09 --> Form Validation Class Initialized
INFO - 2016-11-22 09:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:49:09 --> Pagination Class Initialized
INFO - 2016-11-22 09:49:09 --> Helper loaded: app_helper
INFO - 2016-11-22 09:49:09 --> Email Class Initialized
ERROR - 2016-11-22 09:49:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:09 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:49:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:49:10 --> Final output sent to browser
DEBUG - 2016-11-22 09:49:10 --> Total execution time: 0.5287
INFO - 2016-11-22 09:49:34 --> Config Class Initialized
INFO - 2016-11-22 09:49:34 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:49:34 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:49:34 --> Utf8 Class Initialized
INFO - 2016-11-22 09:49:34 --> URI Class Initialized
DEBUG - 2016-11-22 09:49:34 --> No URI present. Default controller set.
INFO - 2016-11-22 09:49:34 --> Router Class Initialized
INFO - 2016-11-22 09:49:34 --> Output Class Initialized
INFO - 2016-11-22 09:49:34 --> Security Class Initialized
DEBUG - 2016-11-22 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:49:34 --> Input Class Initialized
INFO - 2016-11-22 09:49:34 --> Language Class Initialized
INFO - 2016-11-22 09:49:34 --> Loader Class Initialized
INFO - 2016-11-22 09:49:34 --> Helper loaded: url_helper
INFO - 2016-11-22 09:49:34 --> Helper loaded: form_helper
INFO - 2016-11-22 09:49:34 --> Database Driver Class Initialized
INFO - 2016-11-22 09:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:49:35 --> Controller Class Initialized
INFO - 2016-11-22 09:49:35 --> Model Class Initialized
INFO - 2016-11-22 09:49:35 --> Model Class Initialized
INFO - 2016-11-22 09:49:35 --> Model Class Initialized
INFO - 2016-11-22 09:49:35 --> Model Class Initialized
INFO - 2016-11-22 09:49:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:49:35 --> Pagination Class Initialized
INFO - 2016-11-22 09:49:35 --> Helper loaded: app_helper
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:49:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:49:35 --> Final output sent to browser
DEBUG - 2016-11-22 09:49:35 --> Total execution time: 0.6397
INFO - 2016-11-22 09:49:47 --> Config Class Initialized
INFO - 2016-11-22 09:49:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:49:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:49:47 --> Utf8 Class Initialized
INFO - 2016-11-22 09:49:47 --> URI Class Initialized
INFO - 2016-11-22 09:49:47 --> Router Class Initialized
INFO - 2016-11-22 09:49:47 --> Output Class Initialized
INFO - 2016-11-22 09:49:47 --> Security Class Initialized
DEBUG - 2016-11-22 09:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:49:47 --> Input Class Initialized
INFO - 2016-11-22 09:49:47 --> Language Class Initialized
INFO - 2016-11-22 09:49:47 --> Loader Class Initialized
INFO - 2016-11-22 09:49:47 --> Helper loaded: url_helper
INFO - 2016-11-22 09:49:47 --> Helper loaded: form_helper
INFO - 2016-11-22 09:49:47 --> Database Driver Class Initialized
INFO - 2016-11-22 09:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:49:47 --> Controller Class Initialized
INFO - 2016-11-22 09:49:47 --> Model Class Initialized
INFO - 2016-11-22 09:49:47 --> Form Validation Class Initialized
INFO - 2016-11-22 09:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:49:47 --> Pagination Class Initialized
INFO - 2016-11-22 09:49:47 --> Helper loaded: app_helper
INFO - 2016-11-22 09:49:47 --> Email Class Initialized
ERROR - 2016-11-22 09:49:47 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:49:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:49:48 --> Final output sent to browser
DEBUG - 2016-11-22 09:49:48 --> Total execution time: 0.3712
INFO - 2016-11-22 09:54:17 --> Config Class Initialized
INFO - 2016-11-22 09:54:17 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:54:17 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:54:17 --> Utf8 Class Initialized
INFO - 2016-11-22 09:54:17 --> URI Class Initialized
DEBUG - 2016-11-22 09:54:18 --> No URI present. Default controller set.
INFO - 2016-11-22 09:54:18 --> Router Class Initialized
INFO - 2016-11-22 09:54:18 --> Output Class Initialized
INFO - 2016-11-22 09:54:18 --> Security Class Initialized
DEBUG - 2016-11-22 09:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:54:18 --> Input Class Initialized
INFO - 2016-11-22 09:54:18 --> Language Class Initialized
INFO - 2016-11-22 09:54:18 --> Loader Class Initialized
INFO - 2016-11-22 09:54:18 --> Helper loaded: url_helper
INFO - 2016-11-22 09:54:18 --> Helper loaded: form_helper
INFO - 2016-11-22 09:54:18 --> Database Driver Class Initialized
INFO - 2016-11-22 09:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:54:18 --> Controller Class Initialized
INFO - 2016-11-22 09:54:18 --> Model Class Initialized
INFO - 2016-11-22 09:54:18 --> Model Class Initialized
INFO - 2016-11-22 09:54:18 --> Model Class Initialized
INFO - 2016-11-22 09:54:18 --> Model Class Initialized
INFO - 2016-11-22 09:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:54:18 --> Pagination Class Initialized
INFO - 2016-11-22 09:54:18 --> Helper loaded: app_helper
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:54:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:54:18 --> Final output sent to browser
DEBUG - 2016-11-22 09:54:18 --> Total execution time: 0.4398
INFO - 2016-11-22 09:54:33 --> Config Class Initialized
INFO - 2016-11-22 09:54:33 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:54:33 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:54:33 --> Utf8 Class Initialized
INFO - 2016-11-22 09:54:33 --> URI Class Initialized
INFO - 2016-11-22 09:54:33 --> Router Class Initialized
INFO - 2016-11-22 09:54:33 --> Output Class Initialized
INFO - 2016-11-22 09:54:33 --> Security Class Initialized
DEBUG - 2016-11-22 09:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:54:33 --> Input Class Initialized
INFO - 2016-11-22 09:54:33 --> Language Class Initialized
INFO - 2016-11-22 09:54:33 --> Loader Class Initialized
INFO - 2016-11-22 09:54:33 --> Helper loaded: url_helper
INFO - 2016-11-22 09:54:33 --> Helper loaded: form_helper
INFO - 2016-11-22 09:54:33 --> Database Driver Class Initialized
INFO - 2016-11-22 09:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:54:33 --> Controller Class Initialized
INFO - 2016-11-22 09:54:33 --> Model Class Initialized
INFO - 2016-11-22 09:54:33 --> Form Validation Class Initialized
INFO - 2016-11-22 09:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:54:33 --> Pagination Class Initialized
INFO - 2016-11-22 09:54:33 --> Helper loaded: app_helper
INFO - 2016-11-22 09:54:33 --> Email Class Initialized
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:54:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:54:33 --> Final output sent to browser
DEBUG - 2016-11-22 09:54:33 --> Total execution time: 0.4515
INFO - 2016-11-22 09:54:56 --> Config Class Initialized
INFO - 2016-11-22 09:54:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:54:57 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:54:57 --> Utf8 Class Initialized
INFO - 2016-11-22 09:54:57 --> URI Class Initialized
DEBUG - 2016-11-22 09:54:57 --> No URI present. Default controller set.
INFO - 2016-11-22 09:54:57 --> Router Class Initialized
INFO - 2016-11-22 09:54:57 --> Output Class Initialized
INFO - 2016-11-22 09:54:57 --> Security Class Initialized
DEBUG - 2016-11-22 09:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:54:57 --> Input Class Initialized
INFO - 2016-11-22 09:54:57 --> Language Class Initialized
INFO - 2016-11-22 09:54:57 --> Loader Class Initialized
INFO - 2016-11-22 09:54:57 --> Helper loaded: url_helper
INFO - 2016-11-22 09:54:57 --> Helper loaded: form_helper
INFO - 2016-11-22 09:54:57 --> Database Driver Class Initialized
INFO - 2016-11-22 09:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:54:57 --> Controller Class Initialized
INFO - 2016-11-22 09:54:57 --> Model Class Initialized
INFO - 2016-11-22 09:54:57 --> Model Class Initialized
INFO - 2016-11-22 09:54:57 --> Model Class Initialized
INFO - 2016-11-22 09:54:57 --> Model Class Initialized
INFO - 2016-11-22 09:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:54:57 --> Pagination Class Initialized
INFO - 2016-11-22 09:54:57 --> Helper loaded: app_helper
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:54:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:54:57 --> Final output sent to browser
DEBUG - 2016-11-22 09:54:57 --> Total execution time: 0.4359
INFO - 2016-11-22 09:55:40 --> Config Class Initialized
INFO - 2016-11-22 09:55:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:55:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:55:40 --> Utf8 Class Initialized
INFO - 2016-11-22 09:55:40 --> URI Class Initialized
INFO - 2016-11-22 09:55:40 --> Router Class Initialized
INFO - 2016-11-22 09:55:40 --> Output Class Initialized
INFO - 2016-11-22 09:55:40 --> Security Class Initialized
DEBUG - 2016-11-22 09:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:55:40 --> Input Class Initialized
INFO - 2016-11-22 09:55:40 --> Language Class Initialized
INFO - 2016-11-22 09:55:40 --> Loader Class Initialized
INFO - 2016-11-22 09:55:40 --> Helper loaded: url_helper
INFO - 2016-11-22 09:55:40 --> Helper loaded: form_helper
INFO - 2016-11-22 09:55:40 --> Database Driver Class Initialized
INFO - 2016-11-22 09:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:55:40 --> Controller Class Initialized
INFO - 2016-11-22 09:55:40 --> Model Class Initialized
INFO - 2016-11-22 09:55:40 --> Form Validation Class Initialized
INFO - 2016-11-22 09:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:55:40 --> Pagination Class Initialized
INFO - 2016-11-22 09:55:40 --> Helper loaded: app_helper
INFO - 2016-11-22 09:55:40 --> Email Class Initialized
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:55:40 --> Final output sent to browser
DEBUG - 2016-11-22 09:55:40 --> Total execution time: 0.6408
INFO - 2016-11-22 09:55:44 --> Config Class Initialized
INFO - 2016-11-22 09:55:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:55:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:55:44 --> Utf8 Class Initialized
INFO - 2016-11-22 09:55:44 --> URI Class Initialized
DEBUG - 2016-11-22 09:55:44 --> No URI present. Default controller set.
INFO - 2016-11-22 09:55:44 --> Router Class Initialized
INFO - 2016-11-22 09:55:44 --> Output Class Initialized
INFO - 2016-11-22 09:55:44 --> Security Class Initialized
DEBUG - 2016-11-22 09:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:55:44 --> Input Class Initialized
INFO - 2016-11-22 09:55:44 --> Language Class Initialized
INFO - 2016-11-22 09:55:44 --> Loader Class Initialized
INFO - 2016-11-22 09:55:44 --> Helper loaded: url_helper
INFO - 2016-11-22 09:55:44 --> Helper loaded: form_helper
INFO - 2016-11-22 09:55:44 --> Database Driver Class Initialized
INFO - 2016-11-22 09:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:55:44 --> Controller Class Initialized
INFO - 2016-11-22 09:55:44 --> Model Class Initialized
INFO - 2016-11-22 09:55:44 --> Model Class Initialized
INFO - 2016-11-22 09:55:44 --> Model Class Initialized
INFO - 2016-11-22 09:55:44 --> Model Class Initialized
INFO - 2016-11-22 09:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:55:44 --> Pagination Class Initialized
INFO - 2016-11-22 09:55:44 --> Helper loaded: app_helper
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:55:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:55:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:55:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:55:45 --> Final output sent to browser
DEBUG - 2016-11-22 09:55:45 --> Total execution time: 0.3952
INFO - 2016-11-22 09:55:48 --> Config Class Initialized
INFO - 2016-11-22 09:55:48 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:55:48 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:55:48 --> Utf8 Class Initialized
INFO - 2016-11-22 09:55:48 --> URI Class Initialized
INFO - 2016-11-22 09:55:48 --> Router Class Initialized
INFO - 2016-11-22 09:55:48 --> Output Class Initialized
INFO - 2016-11-22 09:55:48 --> Security Class Initialized
DEBUG - 2016-11-22 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:55:48 --> Input Class Initialized
INFO - 2016-11-22 09:55:48 --> Language Class Initialized
INFO - 2016-11-22 09:55:48 --> Loader Class Initialized
INFO - 2016-11-22 09:55:48 --> Helper loaded: url_helper
INFO - 2016-11-22 09:55:48 --> Helper loaded: form_helper
INFO - 2016-11-22 09:55:48 --> Database Driver Class Initialized
INFO - 2016-11-22 09:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:55:49 --> Controller Class Initialized
INFO - 2016-11-22 09:55:49 --> Model Class Initialized
INFO - 2016-11-22 09:55:49 --> Form Validation Class Initialized
INFO - 2016-11-22 09:55:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:55:49 --> Pagination Class Initialized
INFO - 2016-11-22 09:55:49 --> Helper loaded: app_helper
INFO - 2016-11-22 09:55:49 --> Email Class Initialized
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:55:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:55:49 --> Final output sent to browser
DEBUG - 2016-11-22 09:55:49 --> Total execution time: 0.3694
INFO - 2016-11-22 09:56:40 --> Config Class Initialized
INFO - 2016-11-22 09:56:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:56:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:56:40 --> Utf8 Class Initialized
INFO - 2016-11-22 09:56:40 --> URI Class Initialized
DEBUG - 2016-11-22 09:56:40 --> No URI present. Default controller set.
INFO - 2016-11-22 09:56:40 --> Router Class Initialized
INFO - 2016-11-22 09:56:40 --> Output Class Initialized
INFO - 2016-11-22 09:56:40 --> Security Class Initialized
DEBUG - 2016-11-22 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:56:40 --> Input Class Initialized
INFO - 2016-11-22 09:56:40 --> Language Class Initialized
INFO - 2016-11-22 09:56:40 --> Loader Class Initialized
INFO - 2016-11-22 09:56:40 --> Helper loaded: url_helper
INFO - 2016-11-22 09:56:40 --> Helper loaded: form_helper
INFO - 2016-11-22 09:56:40 --> Database Driver Class Initialized
INFO - 2016-11-22 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:56:40 --> Controller Class Initialized
INFO - 2016-11-22 09:56:40 --> Model Class Initialized
INFO - 2016-11-22 09:56:40 --> Model Class Initialized
INFO - 2016-11-22 09:56:40 --> Model Class Initialized
INFO - 2016-11-22 09:56:40 --> Model Class Initialized
INFO - 2016-11-22 09:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:56:40 --> Pagination Class Initialized
INFO - 2016-11-22 09:56:40 --> Helper loaded: app_helper
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:56:40 --> Final output sent to browser
DEBUG - 2016-11-22 09:56:40 --> Total execution time: 0.4208
INFO - 2016-11-22 09:56:44 --> Config Class Initialized
INFO - 2016-11-22 09:56:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:56:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:56:44 --> Utf8 Class Initialized
INFO - 2016-11-22 09:56:44 --> URI Class Initialized
INFO - 2016-11-22 09:56:44 --> Router Class Initialized
INFO - 2016-11-22 09:56:44 --> Output Class Initialized
INFO - 2016-11-22 09:56:44 --> Security Class Initialized
DEBUG - 2016-11-22 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:56:44 --> Input Class Initialized
INFO - 2016-11-22 09:56:44 --> Language Class Initialized
INFO - 2016-11-22 09:56:44 --> Loader Class Initialized
INFO - 2016-11-22 09:56:44 --> Helper loaded: url_helper
INFO - 2016-11-22 09:56:44 --> Helper loaded: form_helper
INFO - 2016-11-22 09:56:44 --> Database Driver Class Initialized
INFO - 2016-11-22 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:56:44 --> Controller Class Initialized
INFO - 2016-11-22 09:56:44 --> Model Class Initialized
INFO - 2016-11-22 09:56:44 --> Form Validation Class Initialized
INFO - 2016-11-22 09:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:56:44 --> Pagination Class Initialized
INFO - 2016-11-22 09:56:44 --> Helper loaded: app_helper
INFO - 2016-11-22 09:56:44 --> Email Class Initialized
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:56:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:56:44 --> Final output sent to browser
DEBUG - 2016-11-22 09:56:44 --> Total execution time: 0.4734
INFO - 2016-11-22 09:57:30 --> Config Class Initialized
INFO - 2016-11-22 09:57:30 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:57:30 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:57:30 --> Utf8 Class Initialized
INFO - 2016-11-22 09:57:30 --> URI Class Initialized
DEBUG - 2016-11-22 09:57:30 --> No URI present. Default controller set.
INFO - 2016-11-22 09:57:30 --> Router Class Initialized
INFO - 2016-11-22 09:57:30 --> Output Class Initialized
INFO - 2016-11-22 09:57:30 --> Security Class Initialized
DEBUG - 2016-11-22 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:57:30 --> Input Class Initialized
INFO - 2016-11-22 09:57:30 --> Language Class Initialized
INFO - 2016-11-22 09:57:30 --> Loader Class Initialized
INFO - 2016-11-22 09:57:30 --> Helper loaded: url_helper
INFO - 2016-11-22 09:57:30 --> Helper loaded: form_helper
INFO - 2016-11-22 09:57:30 --> Database Driver Class Initialized
INFO - 2016-11-22 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:57:30 --> Controller Class Initialized
INFO - 2016-11-22 09:57:30 --> Model Class Initialized
INFO - 2016-11-22 09:57:30 --> Model Class Initialized
INFO - 2016-11-22 09:57:30 --> Model Class Initialized
INFO - 2016-11-22 09:57:30 --> Model Class Initialized
INFO - 2016-11-22 09:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:57:31 --> Pagination Class Initialized
INFO - 2016-11-22 09:57:31 --> Helper loaded: app_helper
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 09:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 09:57:31 --> Final output sent to browser
DEBUG - 2016-11-22 09:57:31 --> Total execution time: 0.4135
INFO - 2016-11-22 09:57:34 --> Config Class Initialized
INFO - 2016-11-22 09:57:34 --> Hooks Class Initialized
DEBUG - 2016-11-22 09:57:34 --> UTF-8 Support Enabled
INFO - 2016-11-22 09:57:34 --> Utf8 Class Initialized
INFO - 2016-11-22 09:57:34 --> URI Class Initialized
INFO - 2016-11-22 09:57:34 --> Router Class Initialized
INFO - 2016-11-22 09:57:34 --> Output Class Initialized
INFO - 2016-11-22 09:57:34 --> Security Class Initialized
DEBUG - 2016-11-22 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 09:57:34 --> Input Class Initialized
INFO - 2016-11-22 09:57:34 --> Language Class Initialized
INFO - 2016-11-22 09:57:34 --> Loader Class Initialized
INFO - 2016-11-22 09:57:34 --> Helper loaded: url_helper
INFO - 2016-11-22 09:57:34 --> Helper loaded: form_helper
INFO - 2016-11-22 09:57:34 --> Database Driver Class Initialized
INFO - 2016-11-22 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 09:57:34 --> Controller Class Initialized
INFO - 2016-11-22 09:57:34 --> Model Class Initialized
INFO - 2016-11-22 09:57:34 --> Form Validation Class Initialized
INFO - 2016-11-22 09:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 09:57:34 --> Pagination Class Initialized
INFO - 2016-11-22 09:57:34 --> Helper loaded: app_helper
INFO - 2016-11-22 09:57:34 --> Email Class Initialized
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 09:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 09:57:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 09:57:34 --> Final output sent to browser
DEBUG - 2016-11-22 09:57:34 --> Total execution time: 0.3652
INFO - 2016-11-22 10:02:19 --> Config Class Initialized
INFO - 2016-11-22 10:02:19 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:02:19 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:02:19 --> Utf8 Class Initialized
INFO - 2016-11-22 10:02:19 --> URI Class Initialized
DEBUG - 2016-11-22 10:02:19 --> No URI present. Default controller set.
INFO - 2016-11-22 10:02:19 --> Router Class Initialized
INFO - 2016-11-22 10:02:19 --> Output Class Initialized
INFO - 2016-11-22 10:02:19 --> Security Class Initialized
DEBUG - 2016-11-22 10:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:02:19 --> Input Class Initialized
INFO - 2016-11-22 10:02:19 --> Language Class Initialized
INFO - 2016-11-22 10:02:19 --> Loader Class Initialized
INFO - 2016-11-22 10:02:19 --> Helper loaded: url_helper
INFO - 2016-11-22 10:02:19 --> Helper loaded: form_helper
INFO - 2016-11-22 10:02:19 --> Database Driver Class Initialized
INFO - 2016-11-22 10:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:02:19 --> Controller Class Initialized
INFO - 2016-11-22 10:02:19 --> Model Class Initialized
INFO - 2016-11-22 10:02:19 --> Model Class Initialized
INFO - 2016-11-22 10:02:19 --> Model Class Initialized
INFO - 2016-11-22 10:02:19 --> Model Class Initialized
INFO - 2016-11-22 10:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:02:19 --> Pagination Class Initialized
INFO - 2016-11-22 10:02:19 --> Helper loaded: app_helper
INFO - 2016-11-22 10:02:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:02:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:02:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:02:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:02:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:02:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:02:20 --> Final output sent to browser
DEBUG - 2016-11-22 10:02:20 --> Total execution time: 0.5391
INFO - 2016-11-22 10:02:27 --> Config Class Initialized
INFO - 2016-11-22 10:02:27 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:02:27 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:02:27 --> Utf8 Class Initialized
INFO - 2016-11-22 10:02:27 --> URI Class Initialized
DEBUG - 2016-11-22 10:02:27 --> No URI present. Default controller set.
INFO - 2016-11-22 10:02:27 --> Router Class Initialized
INFO - 2016-11-22 10:02:27 --> Output Class Initialized
INFO - 2016-11-22 10:02:27 --> Security Class Initialized
DEBUG - 2016-11-22 10:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:02:27 --> Input Class Initialized
INFO - 2016-11-22 10:02:27 --> Language Class Initialized
INFO - 2016-11-22 10:02:27 --> Loader Class Initialized
INFO - 2016-11-22 10:02:27 --> Helper loaded: url_helper
INFO - 2016-11-22 10:02:27 --> Helper loaded: form_helper
INFO - 2016-11-22 10:02:27 --> Database Driver Class Initialized
INFO - 2016-11-22 10:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:02:27 --> Controller Class Initialized
INFO - 2016-11-22 10:02:27 --> Model Class Initialized
INFO - 2016-11-22 10:02:27 --> Model Class Initialized
INFO - 2016-11-22 10:02:27 --> Model Class Initialized
INFO - 2016-11-22 10:02:28 --> Model Class Initialized
INFO - 2016-11-22 10:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:02:28 --> Pagination Class Initialized
INFO - 2016-11-22 10:02:28 --> Helper loaded: app_helper
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:02:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:02:28 --> Final output sent to browser
DEBUG - 2016-11-22 10:02:28 --> Total execution time: 0.4162
INFO - 2016-11-22 10:02:32 --> Config Class Initialized
INFO - 2016-11-22 10:02:32 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:02:32 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:02:32 --> Utf8 Class Initialized
INFO - 2016-11-22 10:02:32 --> URI Class Initialized
INFO - 2016-11-22 10:02:32 --> Router Class Initialized
INFO - 2016-11-22 10:02:32 --> Output Class Initialized
INFO - 2016-11-22 10:02:32 --> Security Class Initialized
DEBUG - 2016-11-22 10:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:02:32 --> Input Class Initialized
INFO - 2016-11-22 10:02:32 --> Language Class Initialized
INFO - 2016-11-22 10:02:32 --> Loader Class Initialized
INFO - 2016-11-22 10:02:32 --> Helper loaded: url_helper
INFO - 2016-11-22 10:02:32 --> Helper loaded: form_helper
INFO - 2016-11-22 10:02:32 --> Database Driver Class Initialized
INFO - 2016-11-22 10:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:02:32 --> Controller Class Initialized
INFO - 2016-11-22 10:02:32 --> Model Class Initialized
INFO - 2016-11-22 10:02:33 --> Form Validation Class Initialized
INFO - 2016-11-22 10:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:02:33 --> Pagination Class Initialized
INFO - 2016-11-22 10:02:33 --> Helper loaded: app_helper
INFO - 2016-11-22 10:02:33 --> Email Class Initialized
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:02:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:02:33 --> Final output sent to browser
DEBUG - 2016-11-22 10:02:33 --> Total execution time: 1.0419
INFO - 2016-11-22 10:02:53 --> Config Class Initialized
INFO - 2016-11-22 10:02:53 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:02:53 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:02:53 --> Utf8 Class Initialized
INFO - 2016-11-22 10:02:53 --> URI Class Initialized
DEBUG - 2016-11-22 10:02:53 --> No URI present. Default controller set.
INFO - 2016-11-22 10:02:53 --> Router Class Initialized
INFO - 2016-11-22 10:02:53 --> Output Class Initialized
INFO - 2016-11-22 10:02:53 --> Security Class Initialized
DEBUG - 2016-11-22 10:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:02:53 --> Input Class Initialized
INFO - 2016-11-22 10:02:53 --> Language Class Initialized
INFO - 2016-11-22 10:02:53 --> Loader Class Initialized
INFO - 2016-11-22 10:02:53 --> Helper loaded: url_helper
INFO - 2016-11-22 10:02:53 --> Helper loaded: form_helper
INFO - 2016-11-22 10:02:53 --> Database Driver Class Initialized
INFO - 2016-11-22 10:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:02:53 --> Controller Class Initialized
INFO - 2016-11-22 10:02:53 --> Model Class Initialized
INFO - 2016-11-22 10:02:53 --> Model Class Initialized
INFO - 2016-11-22 10:02:53 --> Model Class Initialized
INFO - 2016-11-22 10:02:53 --> Model Class Initialized
INFO - 2016-11-22 10:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:02:53 --> Pagination Class Initialized
INFO - 2016-11-22 10:02:53 --> Helper loaded: app_helper
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:02:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:02:53 --> Final output sent to browser
DEBUG - 2016-11-22 10:02:53 --> Total execution time: 0.5042
INFO - 2016-11-22 10:02:57 --> Config Class Initialized
INFO - 2016-11-22 10:02:57 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:02:57 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:02:57 --> Utf8 Class Initialized
INFO - 2016-11-22 10:02:57 --> URI Class Initialized
INFO - 2016-11-22 10:02:57 --> Router Class Initialized
INFO - 2016-11-22 10:02:57 --> Output Class Initialized
INFO - 2016-11-22 10:02:57 --> Security Class Initialized
DEBUG - 2016-11-22 10:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:02:58 --> Input Class Initialized
INFO - 2016-11-22 10:02:58 --> Language Class Initialized
INFO - 2016-11-22 10:02:58 --> Loader Class Initialized
INFO - 2016-11-22 10:02:58 --> Helper loaded: url_helper
INFO - 2016-11-22 10:02:58 --> Helper loaded: form_helper
INFO - 2016-11-22 10:02:58 --> Database Driver Class Initialized
INFO - 2016-11-22 10:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:02:58 --> Controller Class Initialized
INFO - 2016-11-22 10:02:58 --> Model Class Initialized
INFO - 2016-11-22 10:02:58 --> Form Validation Class Initialized
INFO - 2016-11-22 10:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:02:58 --> Pagination Class Initialized
INFO - 2016-11-22 10:02:58 --> Helper loaded: app_helper
INFO - 2016-11-22 10:02:58 --> Email Class Initialized
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:02:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:02:58 --> Final output sent to browser
DEBUG - 2016-11-22 10:02:58 --> Total execution time: 0.6162
INFO - 2016-11-22 10:03:00 --> Config Class Initialized
INFO - 2016-11-22 10:03:00 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:00 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:00 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:00 --> URI Class Initialized
DEBUG - 2016-11-22 10:03:00 --> No URI present. Default controller set.
INFO - 2016-11-22 10:03:00 --> Router Class Initialized
INFO - 2016-11-22 10:03:00 --> Output Class Initialized
INFO - 2016-11-22 10:03:00 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:00 --> Input Class Initialized
INFO - 2016-11-22 10:03:00 --> Language Class Initialized
INFO - 2016-11-22 10:03:00 --> Loader Class Initialized
INFO - 2016-11-22 10:03:00 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:00 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:00 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:00 --> Controller Class Initialized
INFO - 2016-11-22 10:03:00 --> Model Class Initialized
INFO - 2016-11-22 10:03:00 --> Model Class Initialized
INFO - 2016-11-22 10:03:00 --> Model Class Initialized
INFO - 2016-11-22 10:03:00 --> Model Class Initialized
INFO - 2016-11-22 10:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:00 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:00 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:03:00 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:00 --> Total execution time: 0.7118
INFO - 2016-11-22 10:03:00 --> Config Class Initialized
INFO - 2016-11-22 10:03:00 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:00 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:00 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:00 --> URI Class Initialized
DEBUG - 2016-11-22 10:03:00 --> No URI present. Default controller set.
INFO - 2016-11-22 10:03:00 --> Router Class Initialized
INFO - 2016-11-22 10:03:00 --> Output Class Initialized
INFO - 2016-11-22 10:03:01 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:01 --> Input Class Initialized
INFO - 2016-11-22 10:03:01 --> Language Class Initialized
INFO - 2016-11-22 10:03:01 --> Loader Class Initialized
INFO - 2016-11-22 10:03:01 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:01 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:01 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:01 --> Controller Class Initialized
INFO - 2016-11-22 10:03:01 --> Model Class Initialized
INFO - 2016-11-22 10:03:01 --> Model Class Initialized
INFO - 2016-11-22 10:03:01 --> Model Class Initialized
INFO - 2016-11-22 10:03:01 --> Model Class Initialized
INFO - 2016-11-22 10:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:01 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:01 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:03:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:03:01 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:01 --> Total execution time: 0.6015
INFO - 2016-11-22 10:03:05 --> Config Class Initialized
INFO - 2016-11-22 10:03:05 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:05 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:05 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:05 --> URI Class Initialized
INFO - 2016-11-22 10:03:05 --> Router Class Initialized
INFO - 2016-11-22 10:03:05 --> Output Class Initialized
INFO - 2016-11-22 10:03:05 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:05 --> Input Class Initialized
INFO - 2016-11-22 10:03:05 --> Language Class Initialized
INFO - 2016-11-22 10:03:05 --> Loader Class Initialized
INFO - 2016-11-22 10:03:05 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:05 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:05 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:05 --> Controller Class Initialized
INFO - 2016-11-22 10:03:05 --> Model Class Initialized
INFO - 2016-11-22 10:03:05 --> Form Validation Class Initialized
INFO - 2016-11-22 10:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:05 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:05 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:05 --> Email Class Initialized
ERROR - 2016-11-22 10:03:05 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:03:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:06 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:06 --> Total execution time: 0.3949
INFO - 2016-11-22 10:03:08 --> Config Class Initialized
INFO - 2016-11-22 10:03:08 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:08 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:08 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:08 --> URI Class Initialized
DEBUG - 2016-11-22 10:03:08 --> No URI present. Default controller set.
INFO - 2016-11-22 10:03:08 --> Router Class Initialized
INFO - 2016-11-22 10:03:08 --> Output Class Initialized
INFO - 2016-11-22 10:03:08 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:08 --> Input Class Initialized
INFO - 2016-11-22 10:03:08 --> Language Class Initialized
INFO - 2016-11-22 10:03:08 --> Loader Class Initialized
INFO - 2016-11-22 10:03:08 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:08 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:08 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:08 --> Controller Class Initialized
INFO - 2016-11-22 10:03:08 --> Model Class Initialized
INFO - 2016-11-22 10:03:08 --> Model Class Initialized
INFO - 2016-11-22 10:03:08 --> Model Class Initialized
INFO - 2016-11-22 10:03:08 --> Model Class Initialized
INFO - 2016-11-22 10:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:08 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:08 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:03:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:03:08 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:08 --> Total execution time: 0.7281
INFO - 2016-11-22 10:03:12 --> Config Class Initialized
INFO - 2016-11-22 10:03:12 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:12 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:12 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:12 --> URI Class Initialized
INFO - 2016-11-22 10:03:12 --> Router Class Initialized
INFO - 2016-11-22 10:03:12 --> Output Class Initialized
INFO - 2016-11-22 10:03:12 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:12 --> Input Class Initialized
INFO - 2016-11-22 10:03:12 --> Language Class Initialized
INFO - 2016-11-22 10:03:12 --> Loader Class Initialized
INFO - 2016-11-22 10:03:12 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:12 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:12 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:12 --> Controller Class Initialized
INFO - 2016-11-22 10:03:12 --> Model Class Initialized
INFO - 2016-11-22 10:03:12 --> Form Validation Class Initialized
INFO - 2016-11-22 10:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:12 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:12 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:12 --> Email Class Initialized
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:03:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:12 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:12 --> Total execution time: 0.3904
INFO - 2016-11-22 10:03:17 --> Config Class Initialized
INFO - 2016-11-22 10:03:17 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:17 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:17 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:17 --> URI Class Initialized
DEBUG - 2016-11-22 10:03:17 --> No URI present. Default controller set.
INFO - 2016-11-22 10:03:17 --> Router Class Initialized
INFO - 2016-11-22 10:03:17 --> Output Class Initialized
INFO - 2016-11-22 10:03:17 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:17 --> Input Class Initialized
INFO - 2016-11-22 10:03:17 --> Language Class Initialized
INFO - 2016-11-22 10:03:17 --> Loader Class Initialized
INFO - 2016-11-22 10:03:17 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:17 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:17 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:17 --> Controller Class Initialized
INFO - 2016-11-22 10:03:17 --> Model Class Initialized
INFO - 2016-11-22 10:03:17 --> Model Class Initialized
INFO - 2016-11-22 10:03:18 --> Model Class Initialized
INFO - 2016-11-22 10:03:18 --> Model Class Initialized
INFO - 2016-11-22 10:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:18 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:18 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:03:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:03:18 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:18 --> Total execution time: 0.4800
INFO - 2016-11-22 10:03:23 --> Config Class Initialized
INFO - 2016-11-22 10:03:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:23 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:23 --> URI Class Initialized
INFO - 2016-11-22 10:03:23 --> Router Class Initialized
INFO - 2016-11-22 10:03:23 --> Output Class Initialized
INFO - 2016-11-22 10:03:23 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:23 --> Input Class Initialized
INFO - 2016-11-22 10:03:23 --> Language Class Initialized
INFO - 2016-11-22 10:03:23 --> Loader Class Initialized
INFO - 2016-11-22 10:03:23 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:23 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:23 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:23 --> Controller Class Initialized
INFO - 2016-11-22 10:03:23 --> Model Class Initialized
INFO - 2016-11-22 10:03:23 --> Form Validation Class Initialized
INFO - 2016-11-22 10:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:23 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:23 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:23 --> Email Class Initialized
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:03:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:23 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:23 --> Total execution time: 0.4086
INFO - 2016-11-22 10:03:25 --> Config Class Initialized
INFO - 2016-11-22 10:03:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:25 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:25 --> URI Class Initialized
DEBUG - 2016-11-22 10:03:25 --> No URI present. Default controller set.
INFO - 2016-11-22 10:03:25 --> Router Class Initialized
INFO - 2016-11-22 10:03:25 --> Output Class Initialized
INFO - 2016-11-22 10:03:25 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:25 --> Input Class Initialized
INFO - 2016-11-22 10:03:25 --> Language Class Initialized
INFO - 2016-11-22 10:03:25 --> Loader Class Initialized
INFO - 2016-11-22 10:03:25 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:25 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:25 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:25 --> Controller Class Initialized
INFO - 2016-11-22 10:03:25 --> Model Class Initialized
INFO - 2016-11-22 10:03:25 --> Model Class Initialized
INFO - 2016-11-22 10:03:25 --> Model Class Initialized
INFO - 2016-11-22 10:03:25 --> Model Class Initialized
INFO - 2016-11-22 10:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:25 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:25 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:03:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:03:25 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:25 --> Total execution time: 0.5429
INFO - 2016-11-22 10:03:29 --> Config Class Initialized
INFO - 2016-11-22 10:03:29 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:29 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:29 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:29 --> URI Class Initialized
INFO - 2016-11-22 10:03:29 --> Router Class Initialized
INFO - 2016-11-22 10:03:29 --> Output Class Initialized
INFO - 2016-11-22 10:03:29 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:29 --> Input Class Initialized
INFO - 2016-11-22 10:03:29 --> Language Class Initialized
INFO - 2016-11-22 10:03:29 --> Loader Class Initialized
INFO - 2016-11-22 10:03:29 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:29 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:29 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:29 --> Controller Class Initialized
INFO - 2016-11-22 10:03:30 --> Model Class Initialized
INFO - 2016-11-22 10:03:30 --> Form Validation Class Initialized
INFO - 2016-11-22 10:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:30 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:30 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:30 --> Email Class Initialized
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:30 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:30 --> Total execution time: 0.6691
INFO - 2016-11-22 10:03:34 --> Config Class Initialized
INFO - 2016-11-22 10:03:34 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:03:34 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:03:34 --> Utf8 Class Initialized
INFO - 2016-11-22 10:03:34 --> URI Class Initialized
DEBUG - 2016-11-22 10:03:34 --> No URI present. Default controller set.
INFO - 2016-11-22 10:03:34 --> Router Class Initialized
INFO - 2016-11-22 10:03:34 --> Output Class Initialized
INFO - 2016-11-22 10:03:34 --> Security Class Initialized
DEBUG - 2016-11-22 10:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:03:34 --> Input Class Initialized
INFO - 2016-11-22 10:03:34 --> Language Class Initialized
INFO - 2016-11-22 10:03:34 --> Loader Class Initialized
INFO - 2016-11-22 10:03:34 --> Helper loaded: url_helper
INFO - 2016-11-22 10:03:34 --> Helper loaded: form_helper
INFO - 2016-11-22 10:03:34 --> Database Driver Class Initialized
INFO - 2016-11-22 10:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:03:34 --> Controller Class Initialized
INFO - 2016-11-22 10:03:34 --> Model Class Initialized
INFO - 2016-11-22 10:03:34 --> Model Class Initialized
INFO - 2016-11-22 10:03:34 --> Model Class Initialized
INFO - 2016-11-22 10:03:34 --> Model Class Initialized
INFO - 2016-11-22 10:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:03:34 --> Pagination Class Initialized
INFO - 2016-11-22 10:03:34 --> Helper loaded: app_helper
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:03:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:03:34 --> Final output sent to browser
DEBUG - 2016-11-22 10:03:34 --> Total execution time: 0.4877
INFO - 2016-11-22 10:04:52 --> Config Class Initialized
INFO - 2016-11-22 10:04:52 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:04:52 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:04:52 --> Utf8 Class Initialized
INFO - 2016-11-22 10:04:52 --> URI Class Initialized
DEBUG - 2016-11-22 10:04:52 --> No URI present. Default controller set.
INFO - 2016-11-22 10:04:53 --> Router Class Initialized
INFO - 2016-11-22 10:04:53 --> Output Class Initialized
INFO - 2016-11-22 10:04:53 --> Security Class Initialized
DEBUG - 2016-11-22 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:04:53 --> Input Class Initialized
INFO - 2016-11-22 10:04:53 --> Language Class Initialized
INFO - 2016-11-22 10:04:53 --> Loader Class Initialized
INFO - 2016-11-22 10:04:53 --> Helper loaded: url_helper
INFO - 2016-11-22 10:04:53 --> Helper loaded: form_helper
INFO - 2016-11-22 10:04:53 --> Database Driver Class Initialized
INFO - 2016-11-22 10:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:04:53 --> Controller Class Initialized
INFO - 2016-11-22 10:04:53 --> Model Class Initialized
INFO - 2016-11-22 10:04:53 --> Model Class Initialized
INFO - 2016-11-22 10:04:53 --> Model Class Initialized
INFO - 2016-11-22 10:04:53 --> Model Class Initialized
INFO - 2016-11-22 10:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:04:53 --> Pagination Class Initialized
INFO - 2016-11-22 10:04:53 --> Helper loaded: app_helper
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:04:53 --> Final output sent to browser
DEBUG - 2016-11-22 10:04:53 --> Total execution time: 0.4407
INFO - 2016-11-22 10:04:56 --> Config Class Initialized
INFO - 2016-11-22 10:04:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:04:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:04:56 --> Utf8 Class Initialized
INFO - 2016-11-22 10:04:56 --> URI Class Initialized
INFO - 2016-11-22 10:04:56 --> Router Class Initialized
INFO - 2016-11-22 10:04:56 --> Output Class Initialized
INFO - 2016-11-22 10:04:56 --> Security Class Initialized
DEBUG - 2016-11-22 10:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:04:56 --> Input Class Initialized
INFO - 2016-11-22 10:04:56 --> Language Class Initialized
INFO - 2016-11-22 10:04:56 --> Loader Class Initialized
INFO - 2016-11-22 10:04:56 --> Helper loaded: url_helper
INFO - 2016-11-22 10:04:56 --> Helper loaded: form_helper
INFO - 2016-11-22 10:04:56 --> Database Driver Class Initialized
INFO - 2016-11-22 10:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:04:57 --> Controller Class Initialized
INFO - 2016-11-22 10:04:57 --> Model Class Initialized
INFO - 2016-11-22 10:04:57 --> Form Validation Class Initialized
INFO - 2016-11-22 10:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:04:57 --> Pagination Class Initialized
INFO - 2016-11-22 10:04:57 --> Helper loaded: app_helper
INFO - 2016-11-22 10:04:57 --> Email Class Initialized
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:04:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:04:57 --> Final output sent to browser
DEBUG - 2016-11-22 10:04:57 --> Total execution time: 0.3926
INFO - 2016-11-22 10:04:59 --> Config Class Initialized
INFO - 2016-11-22 10:04:59 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:04:59 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:04:59 --> Utf8 Class Initialized
INFO - 2016-11-22 10:04:59 --> URI Class Initialized
DEBUG - 2016-11-22 10:04:59 --> No URI present. Default controller set.
INFO - 2016-11-22 10:04:59 --> Router Class Initialized
INFO - 2016-11-22 10:04:59 --> Output Class Initialized
INFO - 2016-11-22 10:04:59 --> Security Class Initialized
DEBUG - 2016-11-22 10:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:04:59 --> Input Class Initialized
INFO - 2016-11-22 10:04:59 --> Language Class Initialized
INFO - 2016-11-22 10:04:59 --> Loader Class Initialized
INFO - 2016-11-22 10:04:59 --> Helper loaded: url_helper
INFO - 2016-11-22 10:04:59 --> Helper loaded: form_helper
INFO - 2016-11-22 10:04:59 --> Database Driver Class Initialized
INFO - 2016-11-22 10:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:04:59 --> Controller Class Initialized
INFO - 2016-11-22 10:04:59 --> Model Class Initialized
INFO - 2016-11-22 10:04:59 --> Model Class Initialized
INFO - 2016-11-22 10:04:59 --> Model Class Initialized
INFO - 2016-11-22 10:04:59 --> Model Class Initialized
INFO - 2016-11-22 10:04:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:04:59 --> Pagination Class Initialized
INFO - 2016-11-22 10:04:59 --> Helper loaded: app_helper
INFO - 2016-11-22 10:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:04:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:05:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:05:00 --> Final output sent to browser
DEBUG - 2016-11-22 10:05:00 --> Total execution time: 0.4946
INFO - 2016-11-22 10:05:04 --> Config Class Initialized
INFO - 2016-11-22 10:05:04 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:05:04 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:05:04 --> Utf8 Class Initialized
INFO - 2016-11-22 10:05:04 --> URI Class Initialized
INFO - 2016-11-22 10:05:04 --> Router Class Initialized
INFO - 2016-11-22 10:05:04 --> Output Class Initialized
INFO - 2016-11-22 10:05:04 --> Security Class Initialized
DEBUG - 2016-11-22 10:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:05:04 --> Input Class Initialized
INFO - 2016-11-22 10:05:04 --> Language Class Initialized
INFO - 2016-11-22 10:05:04 --> Loader Class Initialized
INFO - 2016-11-22 10:05:04 --> Helper loaded: url_helper
INFO - 2016-11-22 10:05:04 --> Helper loaded: form_helper
INFO - 2016-11-22 10:05:04 --> Database Driver Class Initialized
INFO - 2016-11-22 10:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:05:04 --> Controller Class Initialized
INFO - 2016-11-22 10:05:04 --> Model Class Initialized
INFO - 2016-11-22 10:05:04 --> Form Validation Class Initialized
INFO - 2016-11-22 10:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:05:04 --> Pagination Class Initialized
INFO - 2016-11-22 10:05:04 --> Helper loaded: app_helper
INFO - 2016-11-22 10:05:04 --> Email Class Initialized
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:05:04 --> Final output sent to browser
DEBUG - 2016-11-22 10:05:04 --> Total execution time: 0.4217
INFO - 2016-11-22 10:05:33 --> Config Class Initialized
INFO - 2016-11-22 10:05:33 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:05:33 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:05:33 --> Utf8 Class Initialized
INFO - 2016-11-22 10:05:33 --> URI Class Initialized
DEBUG - 2016-11-22 10:05:33 --> No URI present. Default controller set.
INFO - 2016-11-22 10:05:33 --> Router Class Initialized
INFO - 2016-11-22 10:05:33 --> Output Class Initialized
INFO - 2016-11-22 10:05:33 --> Security Class Initialized
DEBUG - 2016-11-22 10:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:05:33 --> Input Class Initialized
INFO - 2016-11-22 10:05:33 --> Language Class Initialized
INFO - 2016-11-22 10:05:33 --> Loader Class Initialized
INFO - 2016-11-22 10:05:33 --> Helper loaded: url_helper
INFO - 2016-11-22 10:05:33 --> Helper loaded: form_helper
INFO - 2016-11-22 10:05:33 --> Database Driver Class Initialized
INFO - 2016-11-22 10:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:05:34 --> Controller Class Initialized
INFO - 2016-11-22 10:05:34 --> Model Class Initialized
INFO - 2016-11-22 10:05:34 --> Model Class Initialized
INFO - 2016-11-22 10:05:34 --> Model Class Initialized
INFO - 2016-11-22 10:05:34 --> Model Class Initialized
INFO - 2016-11-22 10:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:05:34 --> Pagination Class Initialized
INFO - 2016-11-22 10:05:34 --> Helper loaded: app_helper
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:05:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:05:34 --> Final output sent to browser
DEBUG - 2016-11-22 10:05:34 --> Total execution time: 0.5207
INFO - 2016-11-22 10:05:37 --> Config Class Initialized
INFO - 2016-11-22 10:05:37 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:05:37 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:05:37 --> Utf8 Class Initialized
INFO - 2016-11-22 10:05:37 --> URI Class Initialized
INFO - 2016-11-22 10:05:37 --> Router Class Initialized
INFO - 2016-11-22 10:05:37 --> Output Class Initialized
INFO - 2016-11-22 10:05:38 --> Security Class Initialized
DEBUG - 2016-11-22 10:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:05:38 --> Input Class Initialized
INFO - 2016-11-22 10:05:38 --> Language Class Initialized
INFO - 2016-11-22 10:05:38 --> Loader Class Initialized
INFO - 2016-11-22 10:05:38 --> Helper loaded: url_helper
INFO - 2016-11-22 10:05:38 --> Helper loaded: form_helper
INFO - 2016-11-22 10:05:38 --> Database Driver Class Initialized
INFO - 2016-11-22 10:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:05:38 --> Controller Class Initialized
INFO - 2016-11-22 10:05:38 --> Model Class Initialized
INFO - 2016-11-22 10:05:38 --> Form Validation Class Initialized
INFO - 2016-11-22 10:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:05:38 --> Pagination Class Initialized
INFO - 2016-11-22 10:05:38 --> Helper loaded: app_helper
INFO - 2016-11-22 10:05:38 --> Email Class Initialized
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:05:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:05:38 --> Final output sent to browser
DEBUG - 2016-11-22 10:05:38 --> Total execution time: 0.4184
INFO - 2016-11-22 10:06:06 --> Config Class Initialized
INFO - 2016-11-22 10:06:06 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:06:06 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:06:06 --> Utf8 Class Initialized
INFO - 2016-11-22 10:06:06 --> URI Class Initialized
DEBUG - 2016-11-22 10:06:06 --> No URI present. Default controller set.
INFO - 2016-11-22 10:06:06 --> Router Class Initialized
INFO - 2016-11-22 10:06:06 --> Output Class Initialized
INFO - 2016-11-22 10:06:06 --> Security Class Initialized
DEBUG - 2016-11-22 10:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:06:06 --> Input Class Initialized
INFO - 2016-11-22 10:06:06 --> Language Class Initialized
INFO - 2016-11-22 10:06:06 --> Loader Class Initialized
INFO - 2016-11-22 10:06:06 --> Helper loaded: url_helper
INFO - 2016-11-22 10:06:06 --> Helper loaded: form_helper
INFO - 2016-11-22 10:06:06 --> Database Driver Class Initialized
INFO - 2016-11-22 10:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:06:06 --> Controller Class Initialized
INFO - 2016-11-22 10:06:06 --> Model Class Initialized
INFO - 2016-11-22 10:06:06 --> Model Class Initialized
INFO - 2016-11-22 10:06:06 --> Model Class Initialized
INFO - 2016-11-22 10:06:06 --> Model Class Initialized
INFO - 2016-11-22 10:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:06:06 --> Pagination Class Initialized
INFO - 2016-11-22 10:06:06 --> Helper loaded: app_helper
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:06:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:06:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:06:07 --> Final output sent to browser
DEBUG - 2016-11-22 10:06:07 --> Total execution time: 0.5861
INFO - 2016-11-22 10:06:17 --> Config Class Initialized
INFO - 2016-11-22 10:06:17 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:06:17 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:06:17 --> Utf8 Class Initialized
INFO - 2016-11-22 10:06:17 --> URI Class Initialized
INFO - 2016-11-22 10:06:17 --> Router Class Initialized
INFO - 2016-11-22 10:06:17 --> Output Class Initialized
INFO - 2016-11-22 10:06:17 --> Security Class Initialized
DEBUG - 2016-11-22 10:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:06:17 --> Input Class Initialized
INFO - 2016-11-22 10:06:17 --> Language Class Initialized
INFO - 2016-11-22 10:06:17 --> Loader Class Initialized
INFO - 2016-11-22 10:06:17 --> Helper loaded: url_helper
INFO - 2016-11-22 10:06:17 --> Helper loaded: form_helper
INFO - 2016-11-22 10:06:17 --> Database Driver Class Initialized
INFO - 2016-11-22 10:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:06:17 --> Controller Class Initialized
INFO - 2016-11-22 10:06:17 --> Model Class Initialized
INFO - 2016-11-22 10:06:17 --> Form Validation Class Initialized
INFO - 2016-11-22 10:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:06:17 --> Pagination Class Initialized
INFO - 2016-11-22 10:06:17 --> Helper loaded: app_helper
INFO - 2016-11-22 10:06:17 --> Email Class Initialized
ERROR - 2016-11-22 10:06:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:06:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:06:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:06:18 --> Final output sent to browser
DEBUG - 2016-11-22 10:06:18 --> Total execution time: 0.4168
INFO - 2016-11-22 10:08:10 --> Config Class Initialized
INFO - 2016-11-22 10:08:10 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:08:10 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:08:10 --> Utf8 Class Initialized
INFO - 2016-11-22 10:08:10 --> URI Class Initialized
DEBUG - 2016-11-22 10:08:10 --> No URI present. Default controller set.
INFO - 2016-11-22 10:08:10 --> Router Class Initialized
INFO - 2016-11-22 10:08:10 --> Output Class Initialized
INFO - 2016-11-22 10:08:10 --> Security Class Initialized
DEBUG - 2016-11-22 10:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:08:10 --> Input Class Initialized
INFO - 2016-11-22 10:08:10 --> Language Class Initialized
INFO - 2016-11-22 10:08:10 --> Loader Class Initialized
INFO - 2016-11-22 10:08:10 --> Helper loaded: url_helper
INFO - 2016-11-22 10:08:10 --> Helper loaded: form_helper
INFO - 2016-11-22 10:08:10 --> Database Driver Class Initialized
INFO - 2016-11-22 10:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:08:10 --> Controller Class Initialized
INFO - 2016-11-22 10:08:10 --> Model Class Initialized
INFO - 2016-11-22 10:08:10 --> Model Class Initialized
INFO - 2016-11-22 10:08:10 --> Model Class Initialized
INFO - 2016-11-22 10:08:10 --> Model Class Initialized
INFO - 2016-11-22 10:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:08:10 --> Pagination Class Initialized
INFO - 2016-11-22 10:08:10 --> Helper loaded: app_helper
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:08:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:08:10 --> Final output sent to browser
DEBUG - 2016-11-22 10:08:11 --> Total execution time: 0.5918
INFO - 2016-11-22 10:09:58 --> Config Class Initialized
INFO - 2016-11-22 10:09:58 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:09:58 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:09:58 --> Utf8 Class Initialized
INFO - 2016-11-22 10:09:58 --> URI Class Initialized
DEBUG - 2016-11-22 10:09:58 --> No URI present. Default controller set.
INFO - 2016-11-22 10:09:58 --> Router Class Initialized
INFO - 2016-11-22 10:09:58 --> Output Class Initialized
INFO - 2016-11-22 10:09:58 --> Security Class Initialized
DEBUG - 2016-11-22 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:09:58 --> Input Class Initialized
INFO - 2016-11-22 10:09:58 --> Language Class Initialized
INFO - 2016-11-22 10:09:58 --> Loader Class Initialized
INFO - 2016-11-22 10:09:58 --> Helper loaded: url_helper
INFO - 2016-11-22 10:09:58 --> Helper loaded: form_helper
INFO - 2016-11-22 10:09:58 --> Database Driver Class Initialized
INFO - 2016-11-22 10:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:09:58 --> Controller Class Initialized
INFO - 2016-11-22 10:09:58 --> Model Class Initialized
INFO - 2016-11-22 10:09:58 --> Model Class Initialized
INFO - 2016-11-22 10:09:58 --> Model Class Initialized
INFO - 2016-11-22 10:09:58 --> Model Class Initialized
INFO - 2016-11-22 10:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:09:59 --> Pagination Class Initialized
INFO - 2016-11-22 10:09:59 --> Helper loaded: app_helper
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:09:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:09:59 --> Final output sent to browser
DEBUG - 2016-11-22 10:09:59 --> Total execution time: 0.6011
INFO - 2016-11-22 10:10:05 --> Config Class Initialized
INFO - 2016-11-22 10:10:05 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:10:05 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:10:05 --> Utf8 Class Initialized
INFO - 2016-11-22 10:10:05 --> URI Class Initialized
INFO - 2016-11-22 10:10:05 --> Router Class Initialized
INFO - 2016-11-22 10:10:05 --> Output Class Initialized
INFO - 2016-11-22 10:10:05 --> Security Class Initialized
DEBUG - 2016-11-22 10:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:10:05 --> Input Class Initialized
INFO - 2016-11-22 10:10:05 --> Language Class Initialized
INFO - 2016-11-22 10:10:05 --> Loader Class Initialized
INFO - 2016-11-22 10:10:05 --> Helper loaded: url_helper
INFO - 2016-11-22 10:10:05 --> Helper loaded: form_helper
INFO - 2016-11-22 10:10:05 --> Database Driver Class Initialized
INFO - 2016-11-22 10:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:10:05 --> Controller Class Initialized
INFO - 2016-11-22 10:10:05 --> Model Class Initialized
INFO - 2016-11-22 10:10:05 --> Form Validation Class Initialized
INFO - 2016-11-22 10:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:10:06 --> Pagination Class Initialized
INFO - 2016-11-22 10:10:06 --> Helper loaded: app_helper
INFO - 2016-11-22 10:10:06 --> Email Class Initialized
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:10:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:10:06 --> Final output sent to browser
DEBUG - 2016-11-22 10:10:06 --> Total execution time: 0.4440
INFO - 2016-11-22 10:13:50 --> Config Class Initialized
INFO - 2016-11-22 10:13:50 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:13:51 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:13:51 --> Utf8 Class Initialized
INFO - 2016-11-22 10:13:51 --> URI Class Initialized
DEBUG - 2016-11-22 10:13:51 --> No URI present. Default controller set.
INFO - 2016-11-22 10:13:51 --> Router Class Initialized
INFO - 2016-11-22 10:13:51 --> Output Class Initialized
INFO - 2016-11-22 10:13:51 --> Security Class Initialized
DEBUG - 2016-11-22 10:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:13:51 --> Input Class Initialized
INFO - 2016-11-22 10:13:51 --> Language Class Initialized
INFO - 2016-11-22 10:13:51 --> Loader Class Initialized
INFO - 2016-11-22 10:13:51 --> Helper loaded: url_helper
INFO - 2016-11-22 10:13:51 --> Helper loaded: form_helper
INFO - 2016-11-22 10:13:51 --> Database Driver Class Initialized
INFO - 2016-11-22 10:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:13:51 --> Controller Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:13:51 --> Pagination Class Initialized
INFO - 2016-11-22 10:13:51 --> Helper loaded: app_helper
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:13:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:13:51 --> Final output sent to browser
DEBUG - 2016-11-22 10:13:51 --> Total execution time: 0.6043
INFO - 2016-11-22 10:13:51 --> Config Class Initialized
INFO - 2016-11-22 10:13:51 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:13:51 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:13:51 --> Utf8 Class Initialized
INFO - 2016-11-22 10:13:51 --> URI Class Initialized
DEBUG - 2016-11-22 10:13:51 --> No URI present. Default controller set.
INFO - 2016-11-22 10:13:51 --> Router Class Initialized
INFO - 2016-11-22 10:13:51 --> Output Class Initialized
INFO - 2016-11-22 10:13:51 --> Security Class Initialized
DEBUG - 2016-11-22 10:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:13:51 --> Input Class Initialized
INFO - 2016-11-22 10:13:51 --> Language Class Initialized
INFO - 2016-11-22 10:13:51 --> Loader Class Initialized
INFO - 2016-11-22 10:13:51 --> Helper loaded: url_helper
INFO - 2016-11-22 10:13:51 --> Helper loaded: form_helper
INFO - 2016-11-22 10:13:51 --> Database Driver Class Initialized
INFO - 2016-11-22 10:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:13:51 --> Controller Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:51 --> Model Class Initialized
INFO - 2016-11-22 10:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:13:52 --> Pagination Class Initialized
INFO - 2016-11-22 10:13:52 --> Helper loaded: app_helper
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:13:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:13:52 --> Final output sent to browser
DEBUG - 2016-11-22 10:13:52 --> Total execution time: 0.5163
INFO - 2016-11-22 10:14:03 --> Config Class Initialized
INFO - 2016-11-22 10:14:03 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:14:03 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:14:03 --> Utf8 Class Initialized
INFO - 2016-11-22 10:14:03 --> URI Class Initialized
INFO - 2016-11-22 10:14:03 --> Router Class Initialized
INFO - 2016-11-22 10:14:03 --> Output Class Initialized
INFO - 2016-11-22 10:14:03 --> Security Class Initialized
DEBUG - 2016-11-22 10:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:14:03 --> Input Class Initialized
INFO - 2016-11-22 10:14:03 --> Language Class Initialized
INFO - 2016-11-22 10:14:03 --> Loader Class Initialized
INFO - 2016-11-22 10:14:03 --> Helper loaded: url_helper
INFO - 2016-11-22 10:14:03 --> Helper loaded: form_helper
INFO - 2016-11-22 10:14:03 --> Database Driver Class Initialized
INFO - 2016-11-22 10:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:14:03 --> Controller Class Initialized
INFO - 2016-11-22 10:14:03 --> Model Class Initialized
INFO - 2016-11-22 10:14:03 --> Form Validation Class Initialized
INFO - 2016-11-22 10:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:14:03 --> Pagination Class Initialized
INFO - 2016-11-22 10:14:03 --> Helper loaded: app_helper
INFO - 2016-11-22 10:14:03 --> Email Class Initialized
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:14:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:14:03 --> Final output sent to browser
DEBUG - 2016-11-22 10:14:04 --> Total execution time: 0.4761
INFO - 2016-11-22 10:14:18 --> Config Class Initialized
INFO - 2016-11-22 10:14:18 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:14:18 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:14:18 --> Utf8 Class Initialized
INFO - 2016-11-22 10:14:18 --> URI Class Initialized
DEBUG - 2016-11-22 10:14:18 --> No URI present. Default controller set.
INFO - 2016-11-22 10:14:18 --> Router Class Initialized
INFO - 2016-11-22 10:14:18 --> Output Class Initialized
INFO - 2016-11-22 10:14:18 --> Security Class Initialized
DEBUG - 2016-11-22 10:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:14:18 --> Input Class Initialized
INFO - 2016-11-22 10:14:18 --> Language Class Initialized
INFO - 2016-11-22 10:14:18 --> Loader Class Initialized
INFO - 2016-11-22 10:14:18 --> Helper loaded: url_helper
INFO - 2016-11-22 10:14:18 --> Helper loaded: form_helper
INFO - 2016-11-22 10:14:18 --> Database Driver Class Initialized
INFO - 2016-11-22 10:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:14:18 --> Controller Class Initialized
INFO - 2016-11-22 10:14:18 --> Model Class Initialized
INFO - 2016-11-22 10:14:18 --> Model Class Initialized
INFO - 2016-11-22 10:14:18 --> Model Class Initialized
INFO - 2016-11-22 10:14:18 --> Model Class Initialized
INFO - 2016-11-22 10:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:14:18 --> Pagination Class Initialized
INFO - 2016-11-22 10:14:18 --> Helper loaded: app_helper
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:14:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:14:18 --> Final output sent to browser
DEBUG - 2016-11-22 10:14:18 --> Total execution time: 0.5729
INFO - 2016-11-22 10:14:28 --> Config Class Initialized
INFO - 2016-11-22 10:14:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:14:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:14:28 --> Utf8 Class Initialized
INFO - 2016-11-22 10:14:28 --> URI Class Initialized
INFO - 2016-11-22 10:14:28 --> Router Class Initialized
INFO - 2016-11-22 10:14:28 --> Output Class Initialized
INFO - 2016-11-22 10:14:28 --> Security Class Initialized
DEBUG - 2016-11-22 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:14:28 --> Input Class Initialized
INFO - 2016-11-22 10:14:28 --> Language Class Initialized
INFO - 2016-11-22 10:14:28 --> Loader Class Initialized
INFO - 2016-11-22 10:14:28 --> Helper loaded: url_helper
INFO - 2016-11-22 10:14:28 --> Helper loaded: form_helper
INFO - 2016-11-22 10:14:28 --> Database Driver Class Initialized
INFO - 2016-11-22 10:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:14:28 --> Controller Class Initialized
INFO - 2016-11-22 10:14:28 --> Model Class Initialized
INFO - 2016-11-22 10:14:28 --> Form Validation Class Initialized
INFO - 2016-11-22 10:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:14:28 --> Pagination Class Initialized
INFO - 2016-11-22 10:14:28 --> Helper loaded: app_helper
INFO - 2016-11-22 10:14:28 --> Email Class Initialized
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:14:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:14:28 --> Final output sent to browser
DEBUG - 2016-11-22 10:14:28 --> Total execution time: 0.4743
INFO - 2016-11-22 10:16:11 --> Config Class Initialized
INFO - 2016-11-22 10:16:11 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:16:11 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:16:11 --> Utf8 Class Initialized
INFO - 2016-11-22 10:16:11 --> URI Class Initialized
DEBUG - 2016-11-22 10:16:11 --> No URI present. Default controller set.
INFO - 2016-11-22 10:16:11 --> Router Class Initialized
INFO - 2016-11-22 10:16:11 --> Output Class Initialized
INFO - 2016-11-22 10:16:11 --> Security Class Initialized
DEBUG - 2016-11-22 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:16:11 --> Input Class Initialized
INFO - 2016-11-22 10:16:11 --> Language Class Initialized
INFO - 2016-11-22 10:16:11 --> Loader Class Initialized
INFO - 2016-11-22 10:16:11 --> Helper loaded: url_helper
INFO - 2016-11-22 10:16:11 --> Helper loaded: form_helper
INFO - 2016-11-22 10:16:11 --> Database Driver Class Initialized
INFO - 2016-11-22 10:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:16:11 --> Controller Class Initialized
INFO - 2016-11-22 10:16:11 --> Model Class Initialized
INFO - 2016-11-22 10:16:11 --> Model Class Initialized
INFO - 2016-11-22 10:16:11 --> Model Class Initialized
INFO - 2016-11-22 10:16:11 --> Model Class Initialized
INFO - 2016-11-22 10:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:16:11 --> Pagination Class Initialized
INFO - 2016-11-22 10:16:11 --> Helper loaded: app_helper
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:16:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:16:11 --> Final output sent to browser
DEBUG - 2016-11-22 10:16:11 --> Total execution time: 0.5416
INFO - 2016-11-22 10:16:16 --> Config Class Initialized
INFO - 2016-11-22 10:16:16 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:16:16 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:16:16 --> Utf8 Class Initialized
INFO - 2016-11-22 10:16:16 --> URI Class Initialized
INFO - 2016-11-22 10:16:16 --> Router Class Initialized
INFO - 2016-11-22 10:16:16 --> Output Class Initialized
INFO - 2016-11-22 10:16:16 --> Security Class Initialized
DEBUG - 2016-11-22 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:16:17 --> Input Class Initialized
INFO - 2016-11-22 10:16:17 --> Language Class Initialized
INFO - 2016-11-22 10:16:17 --> Loader Class Initialized
INFO - 2016-11-22 10:16:17 --> Helper loaded: url_helper
INFO - 2016-11-22 10:16:17 --> Helper loaded: form_helper
INFO - 2016-11-22 10:16:17 --> Database Driver Class Initialized
INFO - 2016-11-22 10:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:16:17 --> Controller Class Initialized
INFO - 2016-11-22 10:16:17 --> Model Class Initialized
INFO - 2016-11-22 10:16:17 --> Form Validation Class Initialized
INFO - 2016-11-22 10:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:16:17 --> Pagination Class Initialized
INFO - 2016-11-22 10:16:17 --> Helper loaded: app_helper
INFO - 2016-11-22 10:16:17 --> Email Class Initialized
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:16:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:16:17 --> Final output sent to browser
DEBUG - 2016-11-22 10:16:17 --> Total execution time: 1.2124
INFO - 2016-11-22 10:16:57 --> Config Class Initialized
INFO - 2016-11-22 10:16:57 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:16:57 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:16:57 --> Utf8 Class Initialized
INFO - 2016-11-22 10:16:57 --> URI Class Initialized
DEBUG - 2016-11-22 10:16:57 --> No URI present. Default controller set.
INFO - 2016-11-22 10:16:57 --> Router Class Initialized
INFO - 2016-11-22 10:16:57 --> Output Class Initialized
INFO - 2016-11-22 10:16:57 --> Security Class Initialized
DEBUG - 2016-11-22 10:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:16:57 --> Input Class Initialized
INFO - 2016-11-22 10:16:57 --> Language Class Initialized
INFO - 2016-11-22 10:16:57 --> Loader Class Initialized
INFO - 2016-11-22 10:16:57 --> Helper loaded: url_helper
INFO - 2016-11-22 10:16:58 --> Helper loaded: form_helper
INFO - 2016-11-22 10:16:58 --> Database Driver Class Initialized
INFO - 2016-11-22 10:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:16:58 --> Controller Class Initialized
INFO - 2016-11-22 10:16:58 --> Model Class Initialized
INFO - 2016-11-22 10:16:58 --> Model Class Initialized
INFO - 2016-11-22 10:16:58 --> Model Class Initialized
INFO - 2016-11-22 10:16:58 --> Model Class Initialized
INFO - 2016-11-22 10:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:16:58 --> Pagination Class Initialized
INFO - 2016-11-22 10:16:58 --> Helper loaded: app_helper
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:16:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:16:58 --> Final output sent to browser
DEBUG - 2016-11-22 10:16:58 --> Total execution time: 0.6304
INFO - 2016-11-22 10:18:22 --> Config Class Initialized
INFO - 2016-11-22 10:18:22 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:18:22 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:18:22 --> Utf8 Class Initialized
INFO - 2016-11-22 10:18:22 --> URI Class Initialized
INFO - 2016-11-22 10:18:22 --> Router Class Initialized
INFO - 2016-11-22 10:18:22 --> Output Class Initialized
INFO - 2016-11-22 10:18:22 --> Security Class Initialized
DEBUG - 2016-11-22 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:18:22 --> Input Class Initialized
INFO - 2016-11-22 10:18:22 --> Language Class Initialized
INFO - 2016-11-22 10:18:22 --> Loader Class Initialized
INFO - 2016-11-22 10:18:22 --> Helper loaded: url_helper
INFO - 2016-11-22 10:18:22 --> Helper loaded: form_helper
INFO - 2016-11-22 10:18:22 --> Database Driver Class Initialized
INFO - 2016-11-22 10:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:18:22 --> Controller Class Initialized
INFO - 2016-11-22 10:18:22 --> Model Class Initialized
INFO - 2016-11-22 10:18:22 --> Form Validation Class Initialized
INFO - 2016-11-22 10:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:18:23 --> Pagination Class Initialized
INFO - 2016-11-22 10:18:23 --> Helper loaded: app_helper
INFO - 2016-11-22 10:18:23 --> Email Class Initialized
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:18:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:18:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:18:23 --> Final output sent to browser
DEBUG - 2016-11-22 10:18:23 --> Total execution time: 0.7157
INFO - 2016-11-22 10:21:12 --> Config Class Initialized
INFO - 2016-11-22 10:21:12 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:12 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:12 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:12 --> URI Class Initialized
DEBUG - 2016-11-22 10:21:12 --> No URI present. Default controller set.
INFO - 2016-11-22 10:21:12 --> Router Class Initialized
INFO - 2016-11-22 10:21:12 --> Output Class Initialized
INFO - 2016-11-22 10:21:12 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:12 --> Input Class Initialized
INFO - 2016-11-22 10:21:12 --> Language Class Initialized
INFO - 2016-11-22 10:21:12 --> Loader Class Initialized
INFO - 2016-11-22 10:21:12 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:12 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:12 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:13 --> Controller Class Initialized
INFO - 2016-11-22 10:21:13 --> Model Class Initialized
INFO - 2016-11-22 10:21:13 --> Model Class Initialized
INFO - 2016-11-22 10:21:13 --> Model Class Initialized
INFO - 2016-11-22 10:21:13 --> Model Class Initialized
INFO - 2016-11-22 10:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:13 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:13 --> Helper loaded: app_helper
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:21:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:21:13 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:13 --> Total execution time: 0.6345
INFO - 2016-11-22 10:21:27 --> Config Class Initialized
INFO - 2016-11-22 10:21:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:28 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:28 --> URI Class Initialized
INFO - 2016-11-22 10:21:28 --> Router Class Initialized
INFO - 2016-11-22 10:21:28 --> Output Class Initialized
INFO - 2016-11-22 10:21:28 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:28 --> Input Class Initialized
INFO - 2016-11-22 10:21:28 --> Language Class Initialized
INFO - 2016-11-22 10:21:28 --> Loader Class Initialized
INFO - 2016-11-22 10:21:28 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:28 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:28 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:28 --> Controller Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:28 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:28 --> Helper loaded: app_helper
DEBUG - 2016-11-22 10:21:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-22 10:21:28 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-22 10:21:28 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-22 10:21:28 --> Config Class Initialized
INFO - 2016-11-22 10:21:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:28 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:28 --> URI Class Initialized
DEBUG - 2016-11-22 10:21:28 --> No URI present. Default controller set.
INFO - 2016-11-22 10:21:28 --> Router Class Initialized
INFO - 2016-11-22 10:21:28 --> Output Class Initialized
INFO - 2016-11-22 10:21:28 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:28 --> Input Class Initialized
INFO - 2016-11-22 10:21:28 --> Language Class Initialized
INFO - 2016-11-22 10:21:28 --> Loader Class Initialized
INFO - 2016-11-22 10:21:28 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:28 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:28 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:28 --> Controller Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Model Class Initialized
INFO - 2016-11-22 10:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:28 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:28 --> Helper loaded: app_helper
INFO - 2016-11-22 10:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:21:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 10:21:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:21:29 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:29 --> Total execution time: 0.8380
INFO - 2016-11-22 10:21:31 --> Config Class Initialized
INFO - 2016-11-22 10:21:31 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:31 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:31 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:31 --> URI Class Initialized
DEBUG - 2016-11-22 10:21:31 --> No URI present. Default controller set.
INFO - 2016-11-22 10:21:31 --> Router Class Initialized
INFO - 2016-11-22 10:21:31 --> Output Class Initialized
INFO - 2016-11-22 10:21:31 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:31 --> Input Class Initialized
INFO - 2016-11-22 10:21:31 --> Language Class Initialized
INFO - 2016-11-22 10:21:32 --> Loader Class Initialized
INFO - 2016-11-22 10:21:32 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:32 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:32 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:32 --> Controller Class Initialized
INFO - 2016-11-22 10:21:32 --> Model Class Initialized
INFO - 2016-11-22 10:21:32 --> Model Class Initialized
INFO - 2016-11-22 10:21:32 --> Model Class Initialized
INFO - 2016-11-22 10:21:32 --> Model Class Initialized
INFO - 2016-11-22 10:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:32 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:32 --> Helper loaded: app_helper
INFO - 2016-11-22 10:21:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:21:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 10:21:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:21:32 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:32 --> Total execution time: 0.4336
INFO - 2016-11-22 10:21:43 --> Config Class Initialized
INFO - 2016-11-22 10:21:43 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:43 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:43 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:43 --> URI Class Initialized
INFO - 2016-11-22 10:21:43 --> Router Class Initialized
INFO - 2016-11-22 10:21:43 --> Output Class Initialized
INFO - 2016-11-22 10:21:43 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:43 --> Input Class Initialized
INFO - 2016-11-22 10:21:43 --> Language Class Initialized
INFO - 2016-11-22 10:21:43 --> Loader Class Initialized
INFO - 2016-11-22 10:21:43 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:43 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:43 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:43 --> Controller Class Initialized
INFO - 2016-11-22 10:21:43 --> Model Class Initialized
INFO - 2016-11-22 10:21:43 --> Model Class Initialized
INFO - 2016-11-22 10:21:43 --> Model Class Initialized
INFO - 2016-11-22 10:21:43 --> Model Class Initialized
INFO - 2016-11-22 10:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:43 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:43 --> Helper loaded: app_helper
DEBUG - 2016-11-22 10:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-22 10:21:43 --> Model Class Initialized
INFO - 2016-11-22 10:21:43 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:43 --> Total execution time: 0.3550
INFO - 2016-11-22 10:21:43 --> Config Class Initialized
INFO - 2016-11-22 10:21:43 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:43 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:43 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:43 --> URI Class Initialized
DEBUG - 2016-11-22 10:21:43 --> No URI present. Default controller set.
INFO - 2016-11-22 10:21:43 --> Router Class Initialized
INFO - 2016-11-22 10:21:43 --> Output Class Initialized
INFO - 2016-11-22 10:21:43 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:43 --> Input Class Initialized
INFO - 2016-11-22 10:21:43 --> Language Class Initialized
INFO - 2016-11-22 10:21:43 --> Loader Class Initialized
INFO - 2016-11-22 10:21:43 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:43 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:44 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:44 --> Controller Class Initialized
INFO - 2016-11-22 10:21:44 --> Model Class Initialized
INFO - 2016-11-22 10:21:44 --> Model Class Initialized
INFO - 2016-11-22 10:21:44 --> Model Class Initialized
INFO - 2016-11-22 10:21:44 --> Model Class Initialized
INFO - 2016-11-22 10:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:44 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:44 --> Helper loaded: app_helper
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:21:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:21:44 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:44 --> Total execution time: 0.5041
INFO - 2016-11-22 10:21:52 --> Config Class Initialized
INFO - 2016-11-22 10:21:52 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:21:52 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:21:52 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:52 --> URI Class Initialized
INFO - 2016-11-22 10:21:52 --> Router Class Initialized
INFO - 2016-11-22 10:21:52 --> Config Class Initialized
INFO - 2016-11-22 10:21:52 --> Output Class Initialized
INFO - 2016-11-22 10:21:52 --> Hooks Class Initialized
INFO - 2016-11-22 10:21:52 --> Security Class Initialized
DEBUG - 2016-11-22 10:21:52 --> UTF-8 Support Enabled
DEBUG - 2016-11-22 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:52 --> Utf8 Class Initialized
INFO - 2016-11-22 10:21:52 --> Input Class Initialized
INFO - 2016-11-22 10:21:52 --> URI Class Initialized
INFO - 2016-11-22 10:21:52 --> Language Class Initialized
INFO - 2016-11-22 10:21:52 --> Router Class Initialized
INFO - 2016-11-22 10:21:52 --> Loader Class Initialized
INFO - 2016-11-22 10:21:52 --> Output Class Initialized
INFO - 2016-11-22 10:21:52 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:52 --> Security Class Initialized
INFO - 2016-11-22 10:21:52 --> Helper loaded: form_helper
DEBUG - 2016-11-22 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:21:52 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:52 --> Input Class Initialized
INFO - 2016-11-22 10:21:52 --> Language Class Initialized
INFO - 2016-11-22 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:52 --> Loader Class Initialized
INFO - 2016-11-22 10:21:52 --> Controller Class Initialized
INFO - 2016-11-22 10:21:52 --> Model Class Initialized
INFO - 2016-11-22 10:21:52 --> Helper loaded: url_helper
INFO - 2016-11-22 10:21:52 --> Form Validation Class Initialized
INFO - 2016-11-22 10:21:52 --> Helper loaded: form_helper
INFO - 2016-11-22 10:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:52 --> Database Driver Class Initialized
INFO - 2016-11-22 10:21:52 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:52 --> Helper loaded: app_helper
INFO - 2016-11-22 10:21:52 --> Email Class Initialized
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:21:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:21:52 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:52 --> Total execution time: 0.6083
INFO - 2016-11-22 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:21:52 --> Controller Class Initialized
INFO - 2016-11-22 10:21:52 --> Model Class Initialized
INFO - 2016-11-22 10:21:52 --> Form Validation Class Initialized
INFO - 2016-11-22 10:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:21:52 --> Pagination Class Initialized
INFO - 2016-11-22 10:21:52 --> Helper loaded: app_helper
INFO - 2016-11-22 10:21:52 --> Email Class Initialized
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:21:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:21:53 --> Final output sent to browser
DEBUG - 2016-11-22 10:21:53 --> Total execution time: 0.8738
INFO - 2016-11-22 10:22:03 --> Config Class Initialized
INFO - 2016-11-22 10:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:22:03 --> Utf8 Class Initialized
INFO - 2016-11-22 10:22:03 --> URI Class Initialized
DEBUG - 2016-11-22 10:22:03 --> No URI present. Default controller set.
INFO - 2016-11-22 10:22:03 --> Router Class Initialized
INFO - 2016-11-22 10:22:03 --> Output Class Initialized
INFO - 2016-11-22 10:22:03 --> Security Class Initialized
DEBUG - 2016-11-22 10:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:22:03 --> Input Class Initialized
INFO - 2016-11-22 10:22:03 --> Language Class Initialized
INFO - 2016-11-22 10:22:03 --> Loader Class Initialized
INFO - 2016-11-22 10:22:03 --> Helper loaded: url_helper
INFO - 2016-11-22 10:22:03 --> Helper loaded: form_helper
INFO - 2016-11-22 10:22:03 --> Database Driver Class Initialized
INFO - 2016-11-22 10:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:22:03 --> Controller Class Initialized
INFO - 2016-11-22 10:22:03 --> Model Class Initialized
INFO - 2016-11-22 10:22:03 --> Model Class Initialized
INFO - 2016-11-22 10:22:03 --> Model Class Initialized
INFO - 2016-11-22 10:22:03 --> Model Class Initialized
INFO - 2016-11-22 10:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:22:03 --> Pagination Class Initialized
INFO - 2016-11-22 10:22:03 --> Helper loaded: app_helper
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:22:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:22:03 --> Final output sent to browser
DEBUG - 2016-11-22 10:22:03 --> Total execution time: 0.5953
INFO - 2016-11-22 10:22:20 --> Config Class Initialized
INFO - 2016-11-22 10:22:20 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:22:20 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:22:20 --> Utf8 Class Initialized
INFO - 2016-11-22 10:22:20 --> URI Class Initialized
INFO - 2016-11-22 10:22:20 --> Router Class Initialized
INFO - 2016-11-22 10:22:20 --> Output Class Initialized
INFO - 2016-11-22 10:22:20 --> Security Class Initialized
DEBUG - 2016-11-22 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:22:20 --> Input Class Initialized
INFO - 2016-11-22 10:22:20 --> Language Class Initialized
INFO - 2016-11-22 10:22:20 --> Loader Class Initialized
INFO - 2016-11-22 10:22:20 --> Helper loaded: url_helper
INFO - 2016-11-22 10:22:20 --> Helper loaded: form_helper
INFO - 2016-11-22 10:22:20 --> Database Driver Class Initialized
INFO - 2016-11-22 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:22:20 --> Controller Class Initialized
INFO - 2016-11-22 10:22:20 --> Model Class Initialized
INFO - 2016-11-22 10:22:20 --> Form Validation Class Initialized
INFO - 2016-11-22 10:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:22:20 --> Pagination Class Initialized
INFO - 2016-11-22 10:22:20 --> Helper loaded: app_helper
INFO - 2016-11-22 10:22:20 --> Email Class Initialized
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:22:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:22:20 --> Final output sent to browser
DEBUG - 2016-11-22 10:22:20 --> Total execution time: 0.5024
INFO - 2016-11-22 10:22:23 --> Config Class Initialized
INFO - 2016-11-22 10:22:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:22:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:22:23 --> Utf8 Class Initialized
INFO - 2016-11-22 10:22:23 --> URI Class Initialized
DEBUG - 2016-11-22 10:22:23 --> No URI present. Default controller set.
INFO - 2016-11-22 10:22:23 --> Router Class Initialized
INFO - 2016-11-22 10:22:23 --> Output Class Initialized
INFO - 2016-11-22 10:22:23 --> Security Class Initialized
DEBUG - 2016-11-22 10:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:22:23 --> Input Class Initialized
INFO - 2016-11-22 10:22:23 --> Language Class Initialized
INFO - 2016-11-22 10:22:24 --> Loader Class Initialized
INFO - 2016-11-22 10:22:24 --> Helper loaded: url_helper
INFO - 2016-11-22 10:22:24 --> Helper loaded: form_helper
INFO - 2016-11-22 10:22:24 --> Database Driver Class Initialized
INFO - 2016-11-22 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:22:24 --> Controller Class Initialized
INFO - 2016-11-22 10:22:24 --> Model Class Initialized
INFO - 2016-11-22 10:22:24 --> Model Class Initialized
INFO - 2016-11-22 10:22:24 --> Model Class Initialized
INFO - 2016-11-22 10:22:24 --> Model Class Initialized
INFO - 2016-11-22 10:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:22:24 --> Pagination Class Initialized
INFO - 2016-11-22 10:22:24 --> Helper loaded: app_helper
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:22:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:22:24 --> Final output sent to browser
DEBUG - 2016-11-22 10:22:24 --> Total execution time: 0.6001
INFO - 2016-11-22 10:22:40 --> Config Class Initialized
INFO - 2016-11-22 10:22:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:22:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:22:40 --> Utf8 Class Initialized
INFO - 2016-11-22 10:22:40 --> URI Class Initialized
INFO - 2016-11-22 10:22:40 --> Router Class Initialized
INFO - 2016-11-22 10:22:40 --> Output Class Initialized
INFO - 2016-11-22 10:22:40 --> Security Class Initialized
DEBUG - 2016-11-22 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:22:40 --> Input Class Initialized
INFO - 2016-11-22 10:22:40 --> Language Class Initialized
INFO - 2016-11-22 10:22:40 --> Loader Class Initialized
INFO - 2016-11-22 10:22:40 --> Helper loaded: url_helper
INFO - 2016-11-22 10:22:40 --> Helper loaded: form_helper
INFO - 2016-11-22 10:22:40 --> Database Driver Class Initialized
INFO - 2016-11-22 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:22:40 --> Controller Class Initialized
INFO - 2016-11-22 10:22:40 --> Model Class Initialized
INFO - 2016-11-22 10:22:40 --> Form Validation Class Initialized
INFO - 2016-11-22 10:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:22:40 --> Pagination Class Initialized
INFO - 2016-11-22 10:22:40 --> Helper loaded: app_helper
INFO - 2016-11-22 10:22:40 --> Email Class Initialized
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:22:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:22:40 --> Final output sent to browser
DEBUG - 2016-11-22 10:22:40 --> Total execution time: 0.4863
INFO - 2016-11-22 10:25:25 --> Config Class Initialized
INFO - 2016-11-22 10:25:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:25:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:25:25 --> Utf8 Class Initialized
INFO - 2016-11-22 10:25:25 --> URI Class Initialized
DEBUG - 2016-11-22 10:25:26 --> No URI present. Default controller set.
INFO - 2016-11-22 10:25:26 --> Router Class Initialized
INFO - 2016-11-22 10:25:26 --> Output Class Initialized
INFO - 2016-11-22 10:25:26 --> Security Class Initialized
DEBUG - 2016-11-22 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:25:26 --> Input Class Initialized
INFO - 2016-11-22 10:25:26 --> Language Class Initialized
INFO - 2016-11-22 10:25:26 --> Loader Class Initialized
INFO - 2016-11-22 10:25:26 --> Helper loaded: url_helper
INFO - 2016-11-22 10:25:26 --> Helper loaded: form_helper
INFO - 2016-11-22 10:25:26 --> Database Driver Class Initialized
INFO - 2016-11-22 10:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:25:26 --> Controller Class Initialized
INFO - 2016-11-22 10:25:26 --> Model Class Initialized
INFO - 2016-11-22 10:25:26 --> Model Class Initialized
INFO - 2016-11-22 10:25:26 --> Model Class Initialized
INFO - 2016-11-22 10:25:26 --> Model Class Initialized
INFO - 2016-11-22 10:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:25:26 --> Pagination Class Initialized
INFO - 2016-11-22 10:25:26 --> Helper loaded: app_helper
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:25:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:25:26 --> Final output sent to browser
DEBUG - 2016-11-22 10:25:26 --> Total execution time: 0.6321
INFO - 2016-11-22 10:25:45 --> Config Class Initialized
INFO - 2016-11-22 10:25:45 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:25:45 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:25:45 --> Utf8 Class Initialized
INFO - 2016-11-22 10:25:45 --> URI Class Initialized
INFO - 2016-11-22 10:25:45 --> Router Class Initialized
INFO - 2016-11-22 10:25:45 --> Output Class Initialized
INFO - 2016-11-22 10:25:45 --> Security Class Initialized
DEBUG - 2016-11-22 10:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:25:45 --> Input Class Initialized
INFO - 2016-11-22 10:25:45 --> Language Class Initialized
INFO - 2016-11-22 10:25:45 --> Loader Class Initialized
INFO - 2016-11-22 10:25:45 --> Helper loaded: url_helper
INFO - 2016-11-22 10:25:45 --> Helper loaded: form_helper
INFO - 2016-11-22 10:25:45 --> Database Driver Class Initialized
INFO - 2016-11-22 10:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:25:45 --> Controller Class Initialized
INFO - 2016-11-22 10:25:45 --> Model Class Initialized
INFO - 2016-11-22 10:25:45 --> Form Validation Class Initialized
INFO - 2016-11-22 10:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:25:45 --> Pagination Class Initialized
INFO - 2016-11-22 10:25:45 --> Helper loaded: app_helper
INFO - 2016-11-22 10:25:45 --> Email Class Initialized
ERROR - 2016-11-22 10:25:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:45 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:46 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:25:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:25:46 --> Final output sent to browser
DEBUG - 2016-11-22 10:25:46 --> Total execution time: 0.5242
INFO - 2016-11-22 10:27:32 --> Config Class Initialized
INFO - 2016-11-22 10:27:32 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:27:32 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:27:32 --> Utf8 Class Initialized
INFO - 2016-11-22 10:27:32 --> URI Class Initialized
DEBUG - 2016-11-22 10:27:32 --> No URI present. Default controller set.
INFO - 2016-11-22 10:27:32 --> Router Class Initialized
INFO - 2016-11-22 10:27:32 --> Output Class Initialized
INFO - 2016-11-22 10:27:32 --> Security Class Initialized
DEBUG - 2016-11-22 10:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:27:32 --> Input Class Initialized
INFO - 2016-11-22 10:27:32 --> Language Class Initialized
INFO - 2016-11-22 10:27:32 --> Loader Class Initialized
INFO - 2016-11-22 10:27:32 --> Helper loaded: url_helper
INFO - 2016-11-22 10:27:32 --> Helper loaded: form_helper
INFO - 2016-11-22 10:27:32 --> Database Driver Class Initialized
INFO - 2016-11-22 10:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:27:32 --> Controller Class Initialized
INFO - 2016-11-22 10:27:32 --> Model Class Initialized
INFO - 2016-11-22 10:27:32 --> Model Class Initialized
INFO - 2016-11-22 10:27:32 --> Model Class Initialized
INFO - 2016-11-22 10:27:32 --> Model Class Initialized
INFO - 2016-11-22 10:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:27:32 --> Pagination Class Initialized
INFO - 2016-11-22 10:27:32 --> Helper loaded: app_helper
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:27:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:27:32 --> Final output sent to browser
DEBUG - 2016-11-22 10:27:32 --> Total execution time: 0.6289
INFO - 2016-11-22 10:28:44 --> Config Class Initialized
INFO - 2016-11-22 10:28:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:28:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:28:44 --> Utf8 Class Initialized
INFO - 2016-11-22 10:28:44 --> URI Class Initialized
INFO - 2016-11-22 10:28:44 --> Router Class Initialized
INFO - 2016-11-22 10:28:44 --> Output Class Initialized
INFO - 2016-11-22 10:28:44 --> Security Class Initialized
DEBUG - 2016-11-22 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:28:44 --> Input Class Initialized
INFO - 2016-11-22 10:28:44 --> Language Class Initialized
INFO - 2016-11-22 10:28:44 --> Loader Class Initialized
INFO - 2016-11-22 10:28:44 --> Helper loaded: url_helper
INFO - 2016-11-22 10:28:44 --> Helper loaded: form_helper
INFO - 2016-11-22 10:28:44 --> Database Driver Class Initialized
INFO - 2016-11-22 10:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:28:44 --> Controller Class Initialized
INFO - 2016-11-22 10:28:44 --> Model Class Initialized
INFO - 2016-11-22 10:28:44 --> Form Validation Class Initialized
INFO - 2016-11-22 10:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:28:44 --> Pagination Class Initialized
INFO - 2016-11-22 10:28:44 --> Helper loaded: app_helper
INFO - 2016-11-22 10:28:44 --> Email Class Initialized
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:28:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:28:44 --> Final output sent to browser
DEBUG - 2016-11-22 10:28:44 --> Total execution time: 0.5377
INFO - 2016-11-22 10:28:52 --> Config Class Initialized
INFO - 2016-11-22 10:28:52 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:28:52 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:28:52 --> Utf8 Class Initialized
INFO - 2016-11-22 10:28:52 --> URI Class Initialized
DEBUG - 2016-11-22 10:28:52 --> No URI present. Default controller set.
INFO - 2016-11-22 10:28:52 --> Router Class Initialized
INFO - 2016-11-22 10:28:53 --> Output Class Initialized
INFO - 2016-11-22 10:28:53 --> Security Class Initialized
DEBUG - 2016-11-22 10:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:28:53 --> Input Class Initialized
INFO - 2016-11-22 10:28:53 --> Language Class Initialized
INFO - 2016-11-22 10:28:53 --> Loader Class Initialized
INFO - 2016-11-22 10:28:53 --> Helper loaded: url_helper
INFO - 2016-11-22 10:28:53 --> Helper loaded: form_helper
INFO - 2016-11-22 10:28:53 --> Database Driver Class Initialized
INFO - 2016-11-22 10:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:28:53 --> Controller Class Initialized
INFO - 2016-11-22 10:28:53 --> Model Class Initialized
INFO - 2016-11-22 10:28:53 --> Model Class Initialized
INFO - 2016-11-22 10:28:53 --> Model Class Initialized
INFO - 2016-11-22 10:28:53 --> Model Class Initialized
INFO - 2016-11-22 10:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:28:53 --> Pagination Class Initialized
INFO - 2016-11-22 10:28:53 --> Helper loaded: app_helper
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:28:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:28:53 --> Final output sent to browser
DEBUG - 2016-11-22 10:28:53 --> Total execution time: 0.5802
INFO - 2016-11-22 10:29:28 --> Config Class Initialized
INFO - 2016-11-22 10:29:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:29:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:29:28 --> Utf8 Class Initialized
INFO - 2016-11-22 10:29:28 --> URI Class Initialized
INFO - 2016-11-22 10:29:28 --> Router Class Initialized
INFO - 2016-11-22 10:29:28 --> Output Class Initialized
INFO - 2016-11-22 10:29:28 --> Security Class Initialized
DEBUG - 2016-11-22 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:29:28 --> Input Class Initialized
INFO - 2016-11-22 10:29:28 --> Language Class Initialized
INFO - 2016-11-22 10:29:28 --> Loader Class Initialized
INFO - 2016-11-22 10:29:28 --> Helper loaded: url_helper
INFO - 2016-11-22 10:29:28 --> Helper loaded: form_helper
INFO - 2016-11-22 10:29:28 --> Database Driver Class Initialized
INFO - 2016-11-22 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:29:28 --> Controller Class Initialized
INFO - 2016-11-22 10:29:28 --> Model Class Initialized
INFO - 2016-11-22 10:29:28 --> Form Validation Class Initialized
INFO - 2016-11-22 10:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:29:28 --> Pagination Class Initialized
INFO - 2016-11-22 10:29:28 --> Helper loaded: app_helper
INFO - 2016-11-22 10:29:28 --> Email Class Initialized
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:29:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:29:28 --> Final output sent to browser
DEBUG - 2016-11-22 10:29:28 --> Total execution time: 0.5179
INFO - 2016-11-22 10:30:53 --> Config Class Initialized
INFO - 2016-11-22 10:30:53 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:30:53 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:30:53 --> Utf8 Class Initialized
INFO - 2016-11-22 10:30:53 --> URI Class Initialized
DEBUG - 2016-11-22 10:30:53 --> No URI present. Default controller set.
INFO - 2016-11-22 10:30:53 --> Router Class Initialized
INFO - 2016-11-22 10:30:53 --> Output Class Initialized
INFO - 2016-11-22 10:30:53 --> Security Class Initialized
DEBUG - 2016-11-22 10:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:30:54 --> Input Class Initialized
INFO - 2016-11-22 10:30:54 --> Language Class Initialized
INFO - 2016-11-22 10:30:54 --> Loader Class Initialized
INFO - 2016-11-22 10:30:54 --> Helper loaded: url_helper
INFO - 2016-11-22 10:30:54 --> Helper loaded: form_helper
INFO - 2016-11-22 10:30:54 --> Database Driver Class Initialized
INFO - 2016-11-22 10:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:30:54 --> Controller Class Initialized
INFO - 2016-11-22 10:30:54 --> Model Class Initialized
INFO - 2016-11-22 10:30:54 --> Model Class Initialized
INFO - 2016-11-22 10:30:54 --> Model Class Initialized
INFO - 2016-11-22 10:30:54 --> Model Class Initialized
INFO - 2016-11-22 10:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:30:54 --> Pagination Class Initialized
INFO - 2016-11-22 10:30:54 --> Helper loaded: app_helper
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:30:54 --> Final output sent to browser
DEBUG - 2016-11-22 10:30:54 --> Total execution time: 0.8815
INFO - 2016-11-22 10:31:07 --> Config Class Initialized
INFO - 2016-11-22 10:31:07 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:31:07 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:31:07 --> Utf8 Class Initialized
INFO - 2016-11-22 10:31:07 --> URI Class Initialized
INFO - 2016-11-22 10:31:07 --> Router Class Initialized
INFO - 2016-11-22 10:31:07 --> Output Class Initialized
INFO - 2016-11-22 10:31:08 --> Security Class Initialized
DEBUG - 2016-11-22 10:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:31:08 --> Input Class Initialized
INFO - 2016-11-22 10:31:08 --> Language Class Initialized
INFO - 2016-11-22 10:31:08 --> Loader Class Initialized
INFO - 2016-11-22 10:31:08 --> Helper loaded: url_helper
INFO - 2016-11-22 10:31:08 --> Helper loaded: form_helper
INFO - 2016-11-22 10:31:08 --> Database Driver Class Initialized
INFO - 2016-11-22 10:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:31:08 --> Controller Class Initialized
INFO - 2016-11-22 10:31:08 --> Model Class Initialized
INFO - 2016-11-22 10:31:08 --> Form Validation Class Initialized
INFO - 2016-11-22 10:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:31:08 --> Pagination Class Initialized
INFO - 2016-11-22 10:31:08 --> Helper loaded: app_helper
INFO - 2016-11-22 10:31:08 --> Email Class Initialized
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:31:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:31:08 --> Final output sent to browser
DEBUG - 2016-11-22 10:31:08 --> Total execution time: 0.5283
INFO - 2016-11-22 10:31:34 --> Config Class Initialized
INFO - 2016-11-22 10:31:34 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:31:34 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:31:34 --> Utf8 Class Initialized
INFO - 2016-11-22 10:31:34 --> URI Class Initialized
DEBUG - 2016-11-22 10:31:34 --> No URI present. Default controller set.
INFO - 2016-11-22 10:31:34 --> Router Class Initialized
INFO - 2016-11-22 10:31:34 --> Output Class Initialized
INFO - 2016-11-22 10:31:34 --> Security Class Initialized
DEBUG - 2016-11-22 10:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:31:34 --> Input Class Initialized
INFO - 2016-11-22 10:31:34 --> Language Class Initialized
INFO - 2016-11-22 10:31:34 --> Loader Class Initialized
INFO - 2016-11-22 10:31:34 --> Helper loaded: url_helper
INFO - 2016-11-22 10:31:34 --> Helper loaded: form_helper
INFO - 2016-11-22 10:31:34 --> Database Driver Class Initialized
INFO - 2016-11-22 10:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:31:34 --> Controller Class Initialized
INFO - 2016-11-22 10:31:34 --> Model Class Initialized
INFO - 2016-11-22 10:31:34 --> Model Class Initialized
INFO - 2016-11-22 10:31:34 --> Model Class Initialized
INFO - 2016-11-22 10:31:34 --> Model Class Initialized
INFO - 2016-11-22 10:31:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:31:34 --> Pagination Class Initialized
INFO - 2016-11-22 10:31:34 --> Helper loaded: app_helper
INFO - 2016-11-22 10:31:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:31:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:31:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:31:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:31:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:31:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:31:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:31:35 --> Final output sent to browser
DEBUG - 2016-11-22 10:31:35 --> Total execution time: 0.6024
INFO - 2016-11-22 10:31:40 --> Config Class Initialized
INFO - 2016-11-22 10:31:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:31:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:31:40 --> Utf8 Class Initialized
INFO - 2016-11-22 10:31:40 --> URI Class Initialized
INFO - 2016-11-22 10:31:40 --> Router Class Initialized
INFO - 2016-11-22 10:31:40 --> Output Class Initialized
INFO - 2016-11-22 10:31:40 --> Security Class Initialized
DEBUG - 2016-11-22 10:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:31:40 --> Input Class Initialized
INFO - 2016-11-22 10:31:40 --> Language Class Initialized
INFO - 2016-11-22 10:31:40 --> Loader Class Initialized
INFO - 2016-11-22 10:31:40 --> Helper loaded: url_helper
INFO - 2016-11-22 10:31:40 --> Helper loaded: form_helper
INFO - 2016-11-22 10:31:40 --> Database Driver Class Initialized
INFO - 2016-11-22 10:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:31:40 --> Controller Class Initialized
INFO - 2016-11-22 10:31:40 --> Model Class Initialized
INFO - 2016-11-22 10:31:40 --> Form Validation Class Initialized
INFO - 2016-11-22 10:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:31:40 --> Pagination Class Initialized
INFO - 2016-11-22 10:31:40 --> Helper loaded: app_helper
INFO - 2016-11-22 10:31:40 --> Email Class Initialized
ERROR - 2016-11-22 10:31:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:40 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:31:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:31:41 --> Final output sent to browser
DEBUG - 2016-11-22 10:31:41 --> Total execution time: 0.6571
INFO - 2016-11-22 10:31:46 --> Config Class Initialized
INFO - 2016-11-22 10:31:46 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:31:46 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:31:46 --> Utf8 Class Initialized
INFO - 2016-11-22 10:31:46 --> URI Class Initialized
DEBUG - 2016-11-22 10:31:46 --> No URI present. Default controller set.
INFO - 2016-11-22 10:31:46 --> Router Class Initialized
INFO - 2016-11-22 10:31:46 --> Output Class Initialized
INFO - 2016-11-22 10:31:46 --> Security Class Initialized
DEBUG - 2016-11-22 10:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:31:46 --> Input Class Initialized
INFO - 2016-11-22 10:31:46 --> Language Class Initialized
INFO - 2016-11-22 10:31:46 --> Loader Class Initialized
INFO - 2016-11-22 10:31:46 --> Helper loaded: url_helper
INFO - 2016-11-22 10:31:46 --> Helper loaded: form_helper
INFO - 2016-11-22 10:31:46 --> Database Driver Class Initialized
INFO - 2016-11-22 10:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:31:46 --> Controller Class Initialized
INFO - 2016-11-22 10:31:46 --> Model Class Initialized
INFO - 2016-11-22 10:31:46 --> Model Class Initialized
INFO - 2016-11-22 10:31:46 --> Model Class Initialized
INFO - 2016-11-22 10:31:46 --> Model Class Initialized
INFO - 2016-11-22 10:31:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:31:46 --> Pagination Class Initialized
INFO - 2016-11-22 10:31:46 --> Helper loaded: app_helper
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:31:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:31:46 --> Final output sent to browser
DEBUG - 2016-11-22 10:31:46 --> Total execution time: 0.6396
INFO - 2016-11-22 10:33:30 --> Config Class Initialized
INFO - 2016-11-22 10:33:30 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:33:30 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:33:30 --> Utf8 Class Initialized
INFO - 2016-11-22 10:33:30 --> URI Class Initialized
DEBUG - 2016-11-22 10:33:30 --> No URI present. Default controller set.
INFO - 2016-11-22 10:33:30 --> Router Class Initialized
INFO - 2016-11-22 10:33:30 --> Output Class Initialized
INFO - 2016-11-22 10:33:30 --> Security Class Initialized
DEBUG - 2016-11-22 10:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:33:30 --> Input Class Initialized
INFO - 2016-11-22 10:33:30 --> Language Class Initialized
INFO - 2016-11-22 10:33:30 --> Loader Class Initialized
INFO - 2016-11-22 10:33:30 --> Helper loaded: url_helper
INFO - 2016-11-22 10:33:30 --> Helper loaded: form_helper
INFO - 2016-11-22 10:33:30 --> Database Driver Class Initialized
INFO - 2016-11-22 10:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:33:30 --> Controller Class Initialized
INFO - 2016-11-22 10:33:30 --> Model Class Initialized
INFO - 2016-11-22 10:33:30 --> Model Class Initialized
INFO - 2016-11-22 10:33:30 --> Model Class Initialized
INFO - 2016-11-22 10:33:30 --> Model Class Initialized
INFO - 2016-11-22 10:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:33:30 --> Pagination Class Initialized
INFO - 2016-11-22 10:33:30 --> Helper loaded: app_helper
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:33:30 --> Final output sent to browser
DEBUG - 2016-11-22 10:33:30 --> Total execution time: 0.6951
INFO - 2016-11-22 10:33:59 --> Config Class Initialized
INFO - 2016-11-22 10:33:59 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:33:59 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:33:59 --> Utf8 Class Initialized
INFO - 2016-11-22 10:33:59 --> URI Class Initialized
INFO - 2016-11-22 10:33:59 --> Router Class Initialized
INFO - 2016-11-22 10:33:59 --> Output Class Initialized
INFO - 2016-11-22 10:33:59 --> Security Class Initialized
DEBUG - 2016-11-22 10:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:33:59 --> Input Class Initialized
INFO - 2016-11-22 10:33:59 --> Language Class Initialized
INFO - 2016-11-22 10:33:59 --> Loader Class Initialized
INFO - 2016-11-22 10:33:59 --> Helper loaded: url_helper
INFO - 2016-11-22 10:33:59 --> Helper loaded: form_helper
INFO - 2016-11-22 10:33:59 --> Database Driver Class Initialized
INFO - 2016-11-22 10:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:33:59 --> Controller Class Initialized
INFO - 2016-11-22 10:33:59 --> Model Class Initialized
INFO - 2016-11-22 10:33:59 --> Form Validation Class Initialized
INFO - 2016-11-22 10:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:33:59 --> Pagination Class Initialized
INFO - 2016-11-22 10:33:59 --> Helper loaded: app_helper
INFO - 2016-11-22 10:34:00 --> Email Class Initialized
INFO - 2016-11-22 10:34:12 --> Config Class Initialized
INFO - 2016-11-22 10:34:12 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:34:12 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:34:12 --> Utf8 Class Initialized
INFO - 2016-11-22 10:34:12 --> URI Class Initialized
DEBUG - 2016-11-22 10:34:12 --> No URI present. Default controller set.
INFO - 2016-11-22 10:34:12 --> Router Class Initialized
INFO - 2016-11-22 10:34:12 --> Output Class Initialized
INFO - 2016-11-22 10:34:12 --> Security Class Initialized
DEBUG - 2016-11-22 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:34:12 --> Input Class Initialized
INFO - 2016-11-22 10:34:12 --> Language Class Initialized
INFO - 2016-11-22 10:34:12 --> Loader Class Initialized
INFO - 2016-11-22 10:34:12 --> Helper loaded: url_helper
INFO - 2016-11-22 10:34:12 --> Helper loaded: form_helper
INFO - 2016-11-22 10:34:12 --> Database Driver Class Initialized
INFO - 2016-11-22 10:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:34:12 --> Controller Class Initialized
INFO - 2016-11-22 10:34:12 --> Model Class Initialized
INFO - 2016-11-22 10:34:12 --> Model Class Initialized
INFO - 2016-11-22 10:34:12 --> Model Class Initialized
INFO - 2016-11-22 10:34:12 --> Model Class Initialized
INFO - 2016-11-22 10:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:34:12 --> Pagination Class Initialized
INFO - 2016-11-22 10:34:12 --> Helper loaded: app_helper
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:34:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:34:12 --> Final output sent to browser
DEBUG - 2016-11-22 10:34:12 --> Total execution time: 0.6128
INFO - 2016-11-22 10:34:44 --> Config Class Initialized
INFO - 2016-11-22 10:34:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:34:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:34:44 --> Utf8 Class Initialized
INFO - 2016-11-22 10:34:44 --> URI Class Initialized
DEBUG - 2016-11-22 10:34:44 --> No URI present. Default controller set.
INFO - 2016-11-22 10:34:44 --> Router Class Initialized
INFO - 2016-11-22 10:34:44 --> Output Class Initialized
INFO - 2016-11-22 10:34:44 --> Security Class Initialized
DEBUG - 2016-11-22 10:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:34:44 --> Input Class Initialized
INFO - 2016-11-22 10:34:44 --> Language Class Initialized
INFO - 2016-11-22 10:34:44 --> Loader Class Initialized
INFO - 2016-11-22 10:34:44 --> Helper loaded: url_helper
INFO - 2016-11-22 10:34:44 --> Helper loaded: form_helper
INFO - 2016-11-22 10:34:44 --> Database Driver Class Initialized
INFO - 2016-11-22 10:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:34:45 --> Controller Class Initialized
INFO - 2016-11-22 10:34:45 --> Model Class Initialized
INFO - 2016-11-22 10:34:45 --> Model Class Initialized
INFO - 2016-11-22 10:34:45 --> Model Class Initialized
INFO - 2016-11-22 10:34:45 --> Model Class Initialized
INFO - 2016-11-22 10:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:34:45 --> Pagination Class Initialized
INFO - 2016-11-22 10:34:45 --> Helper loaded: app_helper
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:34:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:34:45 --> Final output sent to browser
DEBUG - 2016-11-22 10:34:45 --> Total execution time: 0.7014
INFO - 2016-11-22 10:34:53 --> Config Class Initialized
INFO - 2016-11-22 10:34:53 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:34:53 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:34:53 --> Utf8 Class Initialized
INFO - 2016-11-22 10:34:53 --> URI Class Initialized
INFO - 2016-11-22 10:34:53 --> Router Class Initialized
INFO - 2016-11-22 10:34:53 --> Output Class Initialized
INFO - 2016-11-22 10:34:53 --> Security Class Initialized
DEBUG - 2016-11-22 10:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:34:53 --> Input Class Initialized
INFO - 2016-11-22 10:34:53 --> Language Class Initialized
INFO - 2016-11-22 10:34:53 --> Loader Class Initialized
INFO - 2016-11-22 10:34:53 --> Helper loaded: url_helper
INFO - 2016-11-22 10:34:53 --> Helper loaded: form_helper
INFO - 2016-11-22 10:34:53 --> Database Driver Class Initialized
INFO - 2016-11-22 10:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:34:53 --> Controller Class Initialized
INFO - 2016-11-22 10:34:53 --> Model Class Initialized
INFO - 2016-11-22 10:34:53 --> Form Validation Class Initialized
INFO - 2016-11-22 10:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:34:53 --> Pagination Class Initialized
INFO - 2016-11-22 10:34:53 --> Helper loaded: app_helper
INFO - 2016-11-22 10:34:53 --> Email Class Initialized
INFO - 2016-11-22 10:35:07 --> Config Class Initialized
INFO - 2016-11-22 10:35:07 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:35:07 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:35:07 --> Utf8 Class Initialized
INFO - 2016-11-22 10:35:07 --> URI Class Initialized
DEBUG - 2016-11-22 10:35:07 --> No URI present. Default controller set.
INFO - 2016-11-22 10:35:07 --> Router Class Initialized
INFO - 2016-11-22 10:35:07 --> Output Class Initialized
INFO - 2016-11-22 10:35:07 --> Security Class Initialized
DEBUG - 2016-11-22 10:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:35:07 --> Input Class Initialized
INFO - 2016-11-22 10:35:07 --> Language Class Initialized
INFO - 2016-11-22 10:35:07 --> Loader Class Initialized
INFO - 2016-11-22 10:35:07 --> Helper loaded: url_helper
INFO - 2016-11-22 10:35:07 --> Helper loaded: form_helper
INFO - 2016-11-22 10:35:07 --> Database Driver Class Initialized
INFO - 2016-11-22 10:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:35:08 --> Controller Class Initialized
INFO - 2016-11-22 10:35:08 --> Model Class Initialized
INFO - 2016-11-22 10:35:08 --> Model Class Initialized
INFO - 2016-11-22 10:35:08 --> Model Class Initialized
INFO - 2016-11-22 10:35:08 --> Model Class Initialized
INFO - 2016-11-22 10:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:35:08 --> Pagination Class Initialized
INFO - 2016-11-22 10:35:08 --> Helper loaded: app_helper
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:35:08 --> Final output sent to browser
DEBUG - 2016-11-22 10:35:08 --> Total execution time: 0.8035
INFO - 2016-11-22 10:35:11 --> Config Class Initialized
INFO - 2016-11-22 10:35:11 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:35:11 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:35:11 --> Utf8 Class Initialized
INFO - 2016-11-22 10:35:11 --> URI Class Initialized
INFO - 2016-11-22 10:35:11 --> Router Class Initialized
INFO - 2016-11-22 10:35:11 --> Output Class Initialized
INFO - 2016-11-22 10:35:11 --> Security Class Initialized
DEBUG - 2016-11-22 10:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:35:11 --> Input Class Initialized
INFO - 2016-11-22 10:35:11 --> Language Class Initialized
INFO - 2016-11-22 10:35:11 --> Loader Class Initialized
INFO - 2016-11-22 10:35:11 --> Helper loaded: url_helper
INFO - 2016-11-22 10:35:11 --> Helper loaded: form_helper
INFO - 2016-11-22 10:35:11 --> Database Driver Class Initialized
INFO - 2016-11-22 10:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:35:11 --> Controller Class Initialized
INFO - 2016-11-22 10:35:11 --> Model Class Initialized
INFO - 2016-11-22 10:35:11 --> Form Validation Class Initialized
INFO - 2016-11-22 10:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:35:11 --> Pagination Class Initialized
INFO - 2016-11-22 10:35:11 --> Helper loaded: app_helper
INFO - 2016-11-22 10:35:11 --> Email Class Initialized
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:11 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:35:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:35:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:35:12 --> Final output sent to browser
DEBUG - 2016-11-22 10:35:12 --> Total execution time: 0.7902
INFO - 2016-11-22 10:36:44 --> Config Class Initialized
INFO - 2016-11-22 10:36:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:36:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:36:44 --> Utf8 Class Initialized
INFO - 2016-11-22 10:36:44 --> URI Class Initialized
DEBUG - 2016-11-22 10:36:44 --> No URI present. Default controller set.
INFO - 2016-11-22 10:36:44 --> Router Class Initialized
INFO - 2016-11-22 10:36:44 --> Output Class Initialized
INFO - 2016-11-22 10:36:44 --> Security Class Initialized
DEBUG - 2016-11-22 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:36:44 --> Input Class Initialized
INFO - 2016-11-22 10:36:44 --> Language Class Initialized
INFO - 2016-11-22 10:36:44 --> Loader Class Initialized
INFO - 2016-11-22 10:36:44 --> Helper loaded: url_helper
INFO - 2016-11-22 10:36:44 --> Helper loaded: form_helper
INFO - 2016-11-22 10:36:44 --> Database Driver Class Initialized
INFO - 2016-11-22 10:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:36:44 --> Controller Class Initialized
INFO - 2016-11-22 10:36:44 --> Model Class Initialized
INFO - 2016-11-22 10:36:44 --> Model Class Initialized
INFO - 2016-11-22 10:36:45 --> Model Class Initialized
INFO - 2016-11-22 10:36:45 --> Model Class Initialized
INFO - 2016-11-22 10:36:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:36:45 --> Pagination Class Initialized
INFO - 2016-11-22 10:36:45 --> Helper loaded: app_helper
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:36:45 --> Final output sent to browser
DEBUG - 2016-11-22 10:36:45 --> Total execution time: 1.0158
INFO - 2016-11-22 10:37:07 --> Config Class Initialized
INFO - 2016-11-22 10:37:07 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:37:07 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:37:07 --> Utf8 Class Initialized
INFO - 2016-11-22 10:37:07 --> URI Class Initialized
INFO - 2016-11-22 10:37:07 --> Router Class Initialized
INFO - 2016-11-22 10:37:07 --> Output Class Initialized
INFO - 2016-11-22 10:37:07 --> Security Class Initialized
DEBUG - 2016-11-22 10:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:37:07 --> Input Class Initialized
INFO - 2016-11-22 10:37:07 --> Language Class Initialized
INFO - 2016-11-22 10:37:07 --> Loader Class Initialized
INFO - 2016-11-22 10:37:07 --> Helper loaded: url_helper
INFO - 2016-11-22 10:37:07 --> Helper loaded: form_helper
INFO - 2016-11-22 10:37:07 --> Database Driver Class Initialized
INFO - 2016-11-22 10:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:37:07 --> Controller Class Initialized
INFO - 2016-11-22 10:37:07 --> Model Class Initialized
INFO - 2016-11-22 10:37:07 --> Form Validation Class Initialized
INFO - 2016-11-22 10:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:37:07 --> Pagination Class Initialized
INFO - 2016-11-22 10:37:07 --> Helper loaded: app_helper
INFO - 2016-11-22 10:37:07 --> Email Class Initialized
INFO - 2016-11-22 10:38:18 --> Config Class Initialized
INFO - 2016-11-22 10:38:18 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:38:19 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:38:19 --> Utf8 Class Initialized
INFO - 2016-11-22 10:38:19 --> URI Class Initialized
DEBUG - 2016-11-22 10:38:19 --> No URI present. Default controller set.
INFO - 2016-11-22 10:38:19 --> Router Class Initialized
INFO - 2016-11-22 10:38:19 --> Output Class Initialized
INFO - 2016-11-22 10:38:19 --> Security Class Initialized
DEBUG - 2016-11-22 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:38:19 --> Input Class Initialized
INFO - 2016-11-22 10:38:19 --> Language Class Initialized
INFO - 2016-11-22 10:38:19 --> Loader Class Initialized
INFO - 2016-11-22 10:38:19 --> Helper loaded: url_helper
INFO - 2016-11-22 10:38:19 --> Helper loaded: form_helper
INFO - 2016-11-22 10:38:19 --> Database Driver Class Initialized
INFO - 2016-11-22 10:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:38:19 --> Controller Class Initialized
INFO - 2016-11-22 10:38:19 --> Model Class Initialized
INFO - 2016-11-22 10:38:19 --> Model Class Initialized
INFO - 2016-11-22 10:38:19 --> Model Class Initialized
INFO - 2016-11-22 10:38:19 --> Model Class Initialized
INFO - 2016-11-22 10:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:38:19 --> Pagination Class Initialized
INFO - 2016-11-22 10:38:19 --> Helper loaded: app_helper
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:38:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:38:19 --> Final output sent to browser
DEBUG - 2016-11-22 10:38:19 --> Total execution time: 0.9039
INFO - 2016-11-22 10:43:14 --> Config Class Initialized
INFO - 2016-11-22 10:43:14 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:43:14 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:43:14 --> Utf8 Class Initialized
INFO - 2016-11-22 10:43:14 --> URI Class Initialized
DEBUG - 2016-11-22 10:43:14 --> No URI present. Default controller set.
INFO - 2016-11-22 10:43:14 --> Router Class Initialized
INFO - 2016-11-22 10:43:14 --> Output Class Initialized
INFO - 2016-11-22 10:43:15 --> Security Class Initialized
DEBUG - 2016-11-22 10:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:43:15 --> Input Class Initialized
INFO - 2016-11-22 10:43:15 --> Language Class Initialized
INFO - 2016-11-22 10:43:15 --> Loader Class Initialized
INFO - 2016-11-22 10:43:15 --> Helper loaded: url_helper
INFO - 2016-11-22 10:43:15 --> Helper loaded: form_helper
INFO - 2016-11-22 10:43:15 --> Database Driver Class Initialized
INFO - 2016-11-22 10:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:43:15 --> Controller Class Initialized
INFO - 2016-11-22 10:43:15 --> Model Class Initialized
INFO - 2016-11-22 10:43:15 --> Model Class Initialized
INFO - 2016-11-22 10:43:15 --> Model Class Initialized
INFO - 2016-11-22 10:43:15 --> Model Class Initialized
INFO - 2016-11-22 10:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:43:15 --> Pagination Class Initialized
INFO - 2016-11-22 10:43:15 --> Helper loaded: app_helper
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:43:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:43:15 --> Final output sent to browser
DEBUG - 2016-11-22 10:43:15 --> Total execution time: 0.5898
INFO - 2016-11-22 10:43:20 --> Config Class Initialized
INFO - 2016-11-22 10:43:20 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:43:20 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:43:20 --> Utf8 Class Initialized
INFO - 2016-11-22 10:43:20 --> URI Class Initialized
INFO - 2016-11-22 10:43:20 --> Router Class Initialized
INFO - 2016-11-22 10:43:20 --> Output Class Initialized
INFO - 2016-11-22 10:43:20 --> Security Class Initialized
DEBUG - 2016-11-22 10:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:43:20 --> Input Class Initialized
INFO - 2016-11-22 10:43:20 --> Language Class Initialized
INFO - 2016-11-22 10:43:20 --> Loader Class Initialized
INFO - 2016-11-22 10:43:20 --> Helper loaded: url_helper
INFO - 2016-11-22 10:43:20 --> Helper loaded: form_helper
INFO - 2016-11-22 10:43:20 --> Database Driver Class Initialized
INFO - 2016-11-22 10:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:43:20 --> Controller Class Initialized
INFO - 2016-11-22 10:43:20 --> Model Class Initialized
INFO - 2016-11-22 10:43:20 --> Form Validation Class Initialized
INFO - 2016-11-22 10:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:43:20 --> Pagination Class Initialized
INFO - 2016-11-22 10:43:20 --> Helper loaded: app_helper
INFO - 2016-11-22 10:43:20 --> Email Class Initialized
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 199
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: sub_subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 199
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:43:21 --> Final output sent to browser
DEBUG - 2016-11-22 10:43:21 --> Total execution time: 1.3439
INFO - 2016-11-22 10:43:45 --> Config Class Initialized
INFO - 2016-11-22 10:43:45 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:43:45 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:43:45 --> Utf8 Class Initialized
INFO - 2016-11-22 10:43:45 --> URI Class Initialized
DEBUG - 2016-11-22 10:43:45 --> No URI present. Default controller set.
INFO - 2016-11-22 10:43:45 --> Router Class Initialized
INFO - 2016-11-22 10:43:45 --> Output Class Initialized
INFO - 2016-11-22 10:43:45 --> Security Class Initialized
DEBUG - 2016-11-22 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:43:45 --> Input Class Initialized
INFO - 2016-11-22 10:43:45 --> Language Class Initialized
INFO - 2016-11-22 10:43:45 --> Loader Class Initialized
INFO - 2016-11-22 10:43:46 --> Helper loaded: url_helper
INFO - 2016-11-22 10:43:46 --> Helper loaded: form_helper
INFO - 2016-11-22 10:43:46 --> Database Driver Class Initialized
INFO - 2016-11-22 10:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:43:46 --> Controller Class Initialized
INFO - 2016-11-22 10:43:46 --> Model Class Initialized
INFO - 2016-11-22 10:43:46 --> Model Class Initialized
INFO - 2016-11-22 10:43:46 --> Model Class Initialized
INFO - 2016-11-22 10:43:46 --> Model Class Initialized
INFO - 2016-11-22 10:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:43:46 --> Pagination Class Initialized
INFO - 2016-11-22 10:43:46 --> Helper loaded: app_helper
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:43:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:43:46 --> Final output sent to browser
DEBUG - 2016-11-22 10:43:46 --> Total execution time: 0.7277
INFO - 2016-11-22 10:43:49 --> Config Class Initialized
INFO - 2016-11-22 10:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:43:49 --> Utf8 Class Initialized
INFO - 2016-11-22 10:43:49 --> URI Class Initialized
INFO - 2016-11-22 10:43:49 --> Router Class Initialized
INFO - 2016-11-22 10:43:49 --> Output Class Initialized
INFO - 2016-11-22 10:43:49 --> Security Class Initialized
DEBUG - 2016-11-22 10:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:43:50 --> Input Class Initialized
INFO - 2016-11-22 10:43:50 --> Language Class Initialized
INFO - 2016-11-22 10:43:50 --> Loader Class Initialized
INFO - 2016-11-22 10:43:50 --> Helper loaded: url_helper
INFO - 2016-11-22 10:43:50 --> Helper loaded: form_helper
INFO - 2016-11-22 10:43:50 --> Database Driver Class Initialized
INFO - 2016-11-22 10:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:43:50 --> Controller Class Initialized
INFO - 2016-11-22 10:43:50 --> Model Class Initialized
INFO - 2016-11-22 10:43:50 --> Form Validation Class Initialized
INFO - 2016-11-22 10:43:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:43:50 --> Pagination Class Initialized
INFO - 2016-11-22 10:43:50 --> Helper loaded: app_helper
INFO - 2016-11-22 10:43:50 --> Email Class Initialized
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:43:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:43:50 --> Final output sent to browser
DEBUG - 2016-11-22 10:43:50 --> Total execution time: 0.5313
INFO - 2016-11-22 10:43:52 --> Config Class Initialized
INFO - 2016-11-22 10:43:52 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:43:52 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:43:52 --> Utf8 Class Initialized
INFO - 2016-11-22 10:43:52 --> URI Class Initialized
INFO - 2016-11-22 10:43:52 --> Router Class Initialized
INFO - 2016-11-22 10:43:52 --> Output Class Initialized
INFO - 2016-11-22 10:43:52 --> Security Class Initialized
DEBUG - 2016-11-22 10:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:43:52 --> Input Class Initialized
INFO - 2016-11-22 10:43:52 --> Language Class Initialized
INFO - 2016-11-22 10:43:52 --> Loader Class Initialized
INFO - 2016-11-22 10:43:52 --> Helper loaded: url_helper
INFO - 2016-11-22 10:43:52 --> Helper loaded: form_helper
INFO - 2016-11-22 10:43:52 --> Database Driver Class Initialized
INFO - 2016-11-22 10:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:43:52 --> Controller Class Initialized
INFO - 2016-11-22 10:43:52 --> Model Class Initialized
INFO - 2016-11-22 10:43:52 --> Form Validation Class Initialized
INFO - 2016-11-22 10:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:43:52 --> Pagination Class Initialized
INFO - 2016-11-22 10:43:52 --> Helper loaded: app_helper
INFO - 2016-11-22 10:43:52 --> Email Class Initialized
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:53 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 10:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
INFO - 2016-11-22 10:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:43:53 --> Final output sent to browser
DEBUG - 2016-11-22 10:43:53 --> Total execution time: 0.6158
INFO - 2016-11-22 10:44:06 --> Config Class Initialized
INFO - 2016-11-22 10:44:06 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:44:06 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:44:06 --> Utf8 Class Initialized
INFO - 2016-11-22 10:44:06 --> URI Class Initialized
DEBUG - 2016-11-22 10:44:06 --> No URI present. Default controller set.
INFO - 2016-11-22 10:44:06 --> Router Class Initialized
INFO - 2016-11-22 10:44:06 --> Output Class Initialized
INFO - 2016-11-22 10:44:06 --> Security Class Initialized
DEBUG - 2016-11-22 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:44:06 --> Input Class Initialized
INFO - 2016-11-22 10:44:06 --> Language Class Initialized
INFO - 2016-11-22 10:44:06 --> Loader Class Initialized
INFO - 2016-11-22 10:44:06 --> Helper loaded: url_helper
INFO - 2016-11-22 10:44:06 --> Helper loaded: form_helper
INFO - 2016-11-22 10:44:06 --> Database Driver Class Initialized
INFO - 2016-11-22 10:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:44:06 --> Controller Class Initialized
INFO - 2016-11-22 10:44:06 --> Model Class Initialized
INFO - 2016-11-22 10:44:06 --> Model Class Initialized
INFO - 2016-11-22 10:44:06 --> Model Class Initialized
INFO - 2016-11-22 10:44:06 --> Model Class Initialized
INFO - 2016-11-22 10:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:44:06 --> Pagination Class Initialized
INFO - 2016-11-22 10:44:06 --> Helper loaded: app_helper
INFO - 2016-11-22 10:44:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:44:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:44:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:44:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:44:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:44:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:44:07 --> Final output sent to browser
DEBUG - 2016-11-22 10:44:07 --> Total execution time: 0.7043
INFO - 2016-11-22 10:45:27 --> Config Class Initialized
INFO - 2016-11-22 10:45:27 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:45:27 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:45:27 --> Utf8 Class Initialized
INFO - 2016-11-22 10:45:27 --> URI Class Initialized
DEBUG - 2016-11-22 10:45:27 --> No URI present. Default controller set.
INFO - 2016-11-22 10:45:27 --> Router Class Initialized
INFO - 2016-11-22 10:45:27 --> Output Class Initialized
INFO - 2016-11-22 10:45:27 --> Security Class Initialized
DEBUG - 2016-11-22 10:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:45:27 --> Input Class Initialized
INFO - 2016-11-22 10:45:27 --> Language Class Initialized
INFO - 2016-11-22 10:45:27 --> Loader Class Initialized
INFO - 2016-11-22 10:45:27 --> Helper loaded: url_helper
INFO - 2016-11-22 10:45:27 --> Helper loaded: form_helper
INFO - 2016-11-22 10:45:27 --> Database Driver Class Initialized
INFO - 2016-11-22 10:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:45:27 --> Controller Class Initialized
INFO - 2016-11-22 10:45:27 --> Model Class Initialized
INFO - 2016-11-22 10:45:27 --> Model Class Initialized
INFO - 2016-11-22 10:45:27 --> Model Class Initialized
INFO - 2016-11-22 10:45:28 --> Model Class Initialized
INFO - 2016-11-22 10:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:45:28 --> Pagination Class Initialized
INFO - 2016-11-22 10:45:28 --> Helper loaded: app_helper
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:45:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:45:28 --> Final output sent to browser
DEBUG - 2016-11-22 10:45:28 --> Total execution time: 0.7164
INFO - 2016-11-22 10:45:31 --> Config Class Initialized
INFO - 2016-11-22 10:45:31 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:45:31 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:45:31 --> Utf8 Class Initialized
INFO - 2016-11-22 10:45:31 --> URI Class Initialized
INFO - 2016-11-22 10:45:31 --> Router Class Initialized
INFO - 2016-11-22 10:45:31 --> Output Class Initialized
INFO - 2016-11-22 10:45:31 --> Security Class Initialized
DEBUG - 2016-11-22 10:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:45:31 --> Input Class Initialized
INFO - 2016-11-22 10:45:31 --> Language Class Initialized
INFO - 2016-11-22 10:45:31 --> Loader Class Initialized
INFO - 2016-11-22 10:45:31 --> Helper loaded: url_helper
INFO - 2016-11-22 10:45:31 --> Helper loaded: form_helper
INFO - 2016-11-22 10:45:31 --> Database Driver Class Initialized
INFO - 2016-11-22 10:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:45:31 --> Controller Class Initialized
INFO - 2016-11-22 10:45:31 --> Model Class Initialized
INFO - 2016-11-22 10:45:31 --> Form Validation Class Initialized
INFO - 2016-11-22 10:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:45:31 --> Pagination Class Initialized
INFO - 2016-11-22 10:45:31 --> Helper loaded: app_helper
INFO - 2016-11-22 10:45:31 --> Email Class Initialized
INFO - 2016-11-22 10:45:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:45:31 --> Final output sent to browser
DEBUG - 2016-11-22 10:45:31 --> Total execution time: 0.3504
INFO - 2016-11-22 10:45:45 --> Config Class Initialized
INFO - 2016-11-22 10:45:45 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:45:45 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:45:45 --> Utf8 Class Initialized
INFO - 2016-11-22 10:45:46 --> URI Class Initialized
DEBUG - 2016-11-22 10:45:46 --> No URI present. Default controller set.
INFO - 2016-11-22 10:45:46 --> Router Class Initialized
INFO - 2016-11-22 10:45:46 --> Output Class Initialized
INFO - 2016-11-22 10:45:46 --> Security Class Initialized
DEBUG - 2016-11-22 10:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:45:46 --> Input Class Initialized
INFO - 2016-11-22 10:45:46 --> Language Class Initialized
INFO - 2016-11-22 10:45:46 --> Loader Class Initialized
INFO - 2016-11-22 10:45:46 --> Helper loaded: url_helper
INFO - 2016-11-22 10:45:46 --> Helper loaded: form_helper
INFO - 2016-11-22 10:45:46 --> Database Driver Class Initialized
INFO - 2016-11-22 10:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:45:46 --> Controller Class Initialized
INFO - 2016-11-22 10:45:46 --> Model Class Initialized
INFO - 2016-11-22 10:45:46 --> Model Class Initialized
INFO - 2016-11-22 10:45:46 --> Model Class Initialized
INFO - 2016-11-22 10:45:46 --> Model Class Initialized
INFO - 2016-11-22 10:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:45:46 --> Pagination Class Initialized
INFO - 2016-11-22 10:45:46 --> Helper loaded: app_helper
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 10:45:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 10:45:46 --> Final output sent to browser
DEBUG - 2016-11-22 10:45:46 --> Total execution time: 0.6622
INFO - 2016-11-22 10:50:38 --> Config Class Initialized
INFO - 2016-11-22 10:50:38 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:50:39 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:50:39 --> Utf8 Class Initialized
INFO - 2016-11-22 10:50:39 --> URI Class Initialized
INFO - 2016-11-22 10:50:39 --> Router Class Initialized
INFO - 2016-11-22 10:50:39 --> Output Class Initialized
INFO - 2016-11-22 10:50:39 --> Security Class Initialized
DEBUG - 2016-11-22 10:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:50:39 --> Input Class Initialized
INFO - 2016-11-22 10:50:39 --> Language Class Initialized
INFO - 2016-11-22 10:50:39 --> Loader Class Initialized
INFO - 2016-11-22 10:50:39 --> Helper loaded: url_helper
INFO - 2016-11-22 10:50:39 --> Helper loaded: form_helper
INFO - 2016-11-22 10:50:39 --> Database Driver Class Initialized
INFO - 2016-11-22 10:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:50:39 --> Controller Class Initialized
INFO - 2016-11-22 10:50:39 --> Model Class Initialized
INFO - 2016-11-22 10:50:39 --> Form Validation Class Initialized
INFO - 2016-11-22 10:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:50:39 --> Pagination Class Initialized
INFO - 2016-11-22 10:50:39 --> Helper loaded: app_helper
INFO - 2016-11-22 10:50:39 --> Email Class Initialized
INFO - 2016-11-22 10:50:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 10:51:00 --> Config Class Initialized
INFO - 2016-11-22 10:51:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:51:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:51:01 --> Utf8 Class Initialized
INFO - 2016-11-22 10:51:01 --> URI Class Initialized
INFO - 2016-11-22 10:51:01 --> Router Class Initialized
INFO - 2016-11-22 10:51:01 --> Output Class Initialized
INFO - 2016-11-22 10:51:01 --> Security Class Initialized
DEBUG - 2016-11-22 10:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:51:01 --> Input Class Initialized
INFO - 2016-11-22 10:51:01 --> Language Class Initialized
INFO - 2016-11-22 10:51:01 --> Loader Class Initialized
INFO - 2016-11-22 10:51:01 --> Helper loaded: url_helper
INFO - 2016-11-22 10:51:01 --> Helper loaded: form_helper
INFO - 2016-11-22 10:51:01 --> Database Driver Class Initialized
INFO - 2016-11-22 10:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:51:01 --> Controller Class Initialized
INFO - 2016-11-22 10:51:01 --> Model Class Initialized
INFO - 2016-11-22 10:51:01 --> Form Validation Class Initialized
INFO - 2016-11-22 10:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:51:01 --> Pagination Class Initialized
INFO - 2016-11-22 10:51:01 --> Helper loaded: app_helper
INFO - 2016-11-22 10:51:01 --> Email Class Initialized
INFO - 2016-11-22 10:51:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 10:56:28 --> Config Class Initialized
INFO - 2016-11-22 10:56:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:56:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:56:28 --> Utf8 Class Initialized
INFO - 2016-11-22 10:56:28 --> URI Class Initialized
INFO - 2016-11-22 10:56:28 --> Router Class Initialized
INFO - 2016-11-22 10:56:28 --> Output Class Initialized
INFO - 2016-11-22 10:56:28 --> Security Class Initialized
DEBUG - 2016-11-22 10:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:56:29 --> Input Class Initialized
INFO - 2016-11-22 10:56:29 --> Language Class Initialized
INFO - 2016-11-22 10:56:29 --> Loader Class Initialized
INFO - 2016-11-22 10:56:29 --> Helper loaded: url_helper
INFO - 2016-11-22 10:56:29 --> Helper loaded: form_helper
INFO - 2016-11-22 10:56:29 --> Database Driver Class Initialized
INFO - 2016-11-22 10:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:56:29 --> Controller Class Initialized
INFO - 2016-11-22 10:56:29 --> Model Class Initialized
INFO - 2016-11-22 10:56:29 --> Form Validation Class Initialized
INFO - 2016-11-22 10:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:56:29 --> Pagination Class Initialized
INFO - 2016-11-22 10:56:29 --> Helper loaded: app_helper
INFO - 2016-11-22 10:56:29 --> Email Class Initialized
INFO - 2016-11-22 10:56:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 09:56:29 --> Severity: Warning --> Missing argument 4 for Leave_application_m::get_emails(), called in C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php on line 171 and defined C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 16
ERROR - 2016-11-22 09:56:29 --> Severity: Notice --> Undefined variable: application_id C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 23
INFO - 2016-11-22 10:56:47 --> Config Class Initialized
INFO - 2016-11-22 10:56:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:56:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:56:47 --> Utf8 Class Initialized
INFO - 2016-11-22 10:56:47 --> URI Class Initialized
INFO - 2016-11-22 10:56:47 --> Router Class Initialized
INFO - 2016-11-22 10:56:47 --> Output Class Initialized
INFO - 2016-11-22 10:56:47 --> Security Class Initialized
DEBUG - 2016-11-22 10:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:56:47 --> Input Class Initialized
INFO - 2016-11-22 10:56:47 --> Language Class Initialized
INFO - 2016-11-22 10:56:47 --> Loader Class Initialized
INFO - 2016-11-22 10:56:47 --> Helper loaded: url_helper
INFO - 2016-11-22 10:56:47 --> Helper loaded: form_helper
INFO - 2016-11-22 10:56:47 --> Database Driver Class Initialized
INFO - 2016-11-22 10:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:56:47 --> Controller Class Initialized
INFO - 2016-11-22 10:56:47 --> Model Class Initialized
INFO - 2016-11-22 10:56:47 --> Form Validation Class Initialized
INFO - 2016-11-22 10:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:56:47 --> Pagination Class Initialized
INFO - 2016-11-22 10:56:47 --> Helper loaded: app_helper
INFO - 2016-11-22 10:56:47 --> Email Class Initialized
INFO - 2016-11-22 10:56:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 10:56:55 --> Config Class Initialized
INFO - 2016-11-22 10:56:55 --> Hooks Class Initialized
DEBUG - 2016-11-22 10:56:55 --> UTF-8 Support Enabled
INFO - 2016-11-22 10:56:55 --> Utf8 Class Initialized
INFO - 2016-11-22 10:56:55 --> URI Class Initialized
INFO - 2016-11-22 10:56:55 --> Router Class Initialized
INFO - 2016-11-22 10:56:55 --> Output Class Initialized
INFO - 2016-11-22 10:56:55 --> Security Class Initialized
DEBUG - 2016-11-22 10:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 10:56:55 --> Input Class Initialized
INFO - 2016-11-22 10:56:55 --> Language Class Initialized
INFO - 2016-11-22 10:56:55 --> Loader Class Initialized
INFO - 2016-11-22 10:56:55 --> Helper loaded: url_helper
INFO - 2016-11-22 10:56:55 --> Helper loaded: form_helper
INFO - 2016-11-22 10:56:55 --> Database Driver Class Initialized
INFO - 2016-11-22 10:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 10:56:55 --> Controller Class Initialized
INFO - 2016-11-22 10:56:55 --> Model Class Initialized
INFO - 2016-11-22 10:56:55 --> Form Validation Class Initialized
INFO - 2016-11-22 10:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 10:56:55 --> Pagination Class Initialized
INFO - 2016-11-22 10:56:55 --> Helper loaded: app_helper
INFO - 2016-11-22 10:56:55 --> Email Class Initialized
INFO - 2016-11-22 10:56:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 11:18:16 --> Config Class Initialized
INFO - 2016-11-22 11:18:16 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:18:16 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:18:16 --> Utf8 Class Initialized
INFO - 2016-11-22 11:18:16 --> URI Class Initialized
DEBUG - 2016-11-22 11:18:16 --> No URI present. Default controller set.
INFO - 2016-11-22 11:18:16 --> Router Class Initialized
INFO - 2016-11-22 11:18:16 --> Output Class Initialized
INFO - 2016-11-22 11:18:16 --> Security Class Initialized
DEBUG - 2016-11-22 11:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:18:16 --> Input Class Initialized
INFO - 2016-11-22 11:18:16 --> Language Class Initialized
INFO - 2016-11-22 11:18:16 --> Loader Class Initialized
INFO - 2016-11-22 11:18:16 --> Helper loaded: url_helper
INFO - 2016-11-22 11:18:16 --> Helper loaded: form_helper
INFO - 2016-11-22 11:18:16 --> Database Driver Class Initialized
INFO - 2016-11-22 11:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:18:16 --> Controller Class Initialized
INFO - 2016-11-22 11:18:16 --> Model Class Initialized
INFO - 2016-11-22 11:18:16 --> Model Class Initialized
INFO - 2016-11-22 11:18:16 --> Model Class Initialized
INFO - 2016-11-22 11:18:16 --> Model Class Initialized
INFO - 2016-11-22 11:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:18:16 --> Pagination Class Initialized
INFO - 2016-11-22 11:18:16 --> Helper loaded: app_helper
INFO - 2016-11-22 11:18:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:18:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:18:18 --> Final output sent to browser
DEBUG - 2016-11-22 11:18:18 --> Total execution time: 1.7246
INFO - 2016-11-22 11:18:40 --> Config Class Initialized
INFO - 2016-11-22 11:18:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:18:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:18:40 --> Utf8 Class Initialized
INFO - 2016-11-22 11:18:40 --> URI Class Initialized
INFO - 2016-11-22 11:18:40 --> Router Class Initialized
INFO - 2016-11-22 11:18:40 --> Output Class Initialized
INFO - 2016-11-22 11:18:40 --> Security Class Initialized
DEBUG - 2016-11-22 11:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:18:40 --> Input Class Initialized
INFO - 2016-11-22 11:18:40 --> Language Class Initialized
INFO - 2016-11-22 11:18:40 --> Loader Class Initialized
INFO - 2016-11-22 11:18:40 --> Helper loaded: url_helper
INFO - 2016-11-22 11:18:40 --> Helper loaded: form_helper
INFO - 2016-11-22 11:18:40 --> Database Driver Class Initialized
INFO - 2016-11-22 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:18:40 --> Controller Class Initialized
INFO - 2016-11-22 11:18:40 --> Model Class Initialized
INFO - 2016-11-22 11:18:40 --> Form Validation Class Initialized
INFO - 2016-11-22 11:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:18:40 --> Pagination Class Initialized
INFO - 2016-11-22 11:18:40 --> Helper loaded: app_helper
INFO - 2016-11-22 11:18:40 --> Email Class Initialized
INFO - 2016-11-22 11:18:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:18:40 --> Final output sent to browser
DEBUG - 2016-11-22 11:18:40 --> Total execution time: 0.3849
INFO - 2016-11-22 11:18:44 --> Config Class Initialized
INFO - 2016-11-22 11:18:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:18:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:18:44 --> Utf8 Class Initialized
INFO - 2016-11-22 11:18:44 --> URI Class Initialized
INFO - 2016-11-22 11:18:44 --> Router Class Initialized
INFO - 2016-11-22 11:18:44 --> Output Class Initialized
INFO - 2016-11-22 11:18:44 --> Security Class Initialized
DEBUG - 2016-11-22 11:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:18:44 --> Input Class Initialized
INFO - 2016-11-22 11:18:44 --> Language Class Initialized
INFO - 2016-11-22 11:18:44 --> Loader Class Initialized
INFO - 2016-11-22 11:18:44 --> Helper loaded: url_helper
INFO - 2016-11-22 11:18:44 --> Helper loaded: form_helper
INFO - 2016-11-22 11:18:44 --> Database Driver Class Initialized
INFO - 2016-11-22 11:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:18:44 --> Controller Class Initialized
INFO - 2016-11-22 11:18:44 --> Model Class Initialized
INFO - 2016-11-22 11:18:44 --> Form Validation Class Initialized
INFO - 2016-11-22 11:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:18:44 --> Pagination Class Initialized
INFO - 2016-11-22 11:18:44 --> Helper loaded: app_helper
INFO - 2016-11-22 11:18:44 --> Email Class Initialized
INFO - 2016-11-22 11:18:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:18:44 --> Final output sent to browser
DEBUG - 2016-11-22 11:18:44 --> Total execution time: 0.3657
INFO - 2016-11-22 11:18:50 --> Config Class Initialized
INFO - 2016-11-22 11:18:50 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:18:50 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:18:50 --> Utf8 Class Initialized
INFO - 2016-11-22 11:18:50 --> URI Class Initialized
DEBUG - 2016-11-22 11:18:50 --> No URI present. Default controller set.
INFO - 2016-11-22 11:18:50 --> Router Class Initialized
INFO - 2016-11-22 11:18:50 --> Output Class Initialized
INFO - 2016-11-22 11:18:50 --> Security Class Initialized
DEBUG - 2016-11-22 11:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:18:50 --> Input Class Initialized
INFO - 2016-11-22 11:18:50 --> Language Class Initialized
INFO - 2016-11-22 11:18:50 --> Loader Class Initialized
INFO - 2016-11-22 11:18:50 --> Helper loaded: url_helper
INFO - 2016-11-22 11:18:50 --> Helper loaded: form_helper
INFO - 2016-11-22 11:18:50 --> Database Driver Class Initialized
INFO - 2016-11-22 11:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:18:50 --> Controller Class Initialized
INFO - 2016-11-22 11:18:50 --> Model Class Initialized
INFO - 2016-11-22 11:18:50 --> Model Class Initialized
INFO - 2016-11-22 11:18:50 --> Model Class Initialized
INFO - 2016-11-22 11:18:50 --> Model Class Initialized
INFO - 2016-11-22 11:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:18:50 --> Pagination Class Initialized
INFO - 2016-11-22 11:18:50 --> Helper loaded: app_helper
INFO - 2016-11-22 11:18:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:18:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:18:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:18:51 --> Final output sent to browser
DEBUG - 2016-11-22 11:18:51 --> Total execution time: 0.6440
INFO - 2016-11-22 11:18:55 --> Config Class Initialized
INFO - 2016-11-22 11:18:55 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:18:55 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:18:55 --> Utf8 Class Initialized
INFO - 2016-11-22 11:18:55 --> URI Class Initialized
INFO - 2016-11-22 11:18:55 --> Router Class Initialized
INFO - 2016-11-22 11:18:55 --> Output Class Initialized
INFO - 2016-11-22 11:18:55 --> Security Class Initialized
DEBUG - 2016-11-22 11:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:18:55 --> Input Class Initialized
INFO - 2016-11-22 11:18:55 --> Language Class Initialized
INFO - 2016-11-22 11:18:55 --> Loader Class Initialized
INFO - 2016-11-22 11:18:55 --> Helper loaded: url_helper
INFO - 2016-11-22 11:18:55 --> Helper loaded: form_helper
INFO - 2016-11-22 11:18:56 --> Database Driver Class Initialized
INFO - 2016-11-22 11:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:18:56 --> Controller Class Initialized
INFO - 2016-11-22 11:18:56 --> Model Class Initialized
INFO - 2016-11-22 11:18:56 --> Form Validation Class Initialized
INFO - 2016-11-22 11:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:18:56 --> Pagination Class Initialized
INFO - 2016-11-22 11:18:56 --> Helper loaded: app_helper
INFO - 2016-11-22 11:18:56 --> Email Class Initialized
INFO - 2016-11-22 11:18:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:18:56 --> Final output sent to browser
DEBUG - 2016-11-22 11:18:56 --> Total execution time: 0.5193
INFO - 2016-11-22 11:19:08 --> Config Class Initialized
INFO - 2016-11-22 11:19:08 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:19:08 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:19:08 --> Utf8 Class Initialized
INFO - 2016-11-22 11:19:08 --> URI Class Initialized
INFO - 2016-11-22 11:19:08 --> Router Class Initialized
INFO - 2016-11-22 11:19:08 --> Output Class Initialized
INFO - 2016-11-22 11:19:08 --> Security Class Initialized
DEBUG - 2016-11-22 11:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:19:08 --> Input Class Initialized
INFO - 2016-11-22 11:19:08 --> Language Class Initialized
INFO - 2016-11-22 11:19:08 --> Loader Class Initialized
INFO - 2016-11-22 11:19:08 --> Helper loaded: url_helper
INFO - 2016-11-22 11:19:08 --> Helper loaded: form_helper
INFO - 2016-11-22 11:19:08 --> Database Driver Class Initialized
INFO - 2016-11-22 11:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:19:08 --> Controller Class Initialized
INFO - 2016-11-22 11:19:08 --> Model Class Initialized
INFO - 2016-11-22 11:19:08 --> Form Validation Class Initialized
INFO - 2016-11-22 11:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:19:08 --> Pagination Class Initialized
INFO - 2016-11-22 11:19:08 --> Helper loaded: app_helper
INFO - 2016-11-22 11:19:08 --> Email Class Initialized
INFO - 2016-11-22 11:19:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:19:08 --> Final output sent to browser
DEBUG - 2016-11-22 11:19:09 --> Total execution time: 0.3675
INFO - 2016-11-22 11:19:11 --> Config Class Initialized
INFO - 2016-11-22 11:19:11 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:19:11 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:19:11 --> Utf8 Class Initialized
INFO - 2016-11-22 11:19:11 --> URI Class Initialized
DEBUG - 2016-11-22 11:19:11 --> No URI present. Default controller set.
INFO - 2016-11-22 11:19:11 --> Router Class Initialized
INFO - 2016-11-22 11:19:11 --> Output Class Initialized
INFO - 2016-11-22 11:19:11 --> Security Class Initialized
DEBUG - 2016-11-22 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:19:12 --> Input Class Initialized
INFO - 2016-11-22 11:19:12 --> Language Class Initialized
INFO - 2016-11-22 11:19:12 --> Loader Class Initialized
INFO - 2016-11-22 11:19:12 --> Helper loaded: url_helper
INFO - 2016-11-22 11:19:12 --> Helper loaded: form_helper
INFO - 2016-11-22 11:19:12 --> Database Driver Class Initialized
INFO - 2016-11-22 11:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:19:12 --> Controller Class Initialized
INFO - 2016-11-22 11:19:12 --> Model Class Initialized
INFO - 2016-11-22 11:19:12 --> Model Class Initialized
INFO - 2016-11-22 11:19:12 --> Model Class Initialized
INFO - 2016-11-22 11:19:12 --> Model Class Initialized
INFO - 2016-11-22 11:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:19:12 --> Pagination Class Initialized
INFO - 2016-11-22 11:19:12 --> Helper loaded: app_helper
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:19:12 --> Final output sent to browser
DEBUG - 2016-11-22 11:19:12 --> Total execution time: 0.6545
INFO - 2016-11-22 11:20:29 --> Config Class Initialized
INFO - 2016-11-22 11:20:29 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:20:29 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:20:29 --> Utf8 Class Initialized
INFO - 2016-11-22 11:20:29 --> URI Class Initialized
DEBUG - 2016-11-22 11:20:29 --> No URI present. Default controller set.
INFO - 2016-11-22 11:20:29 --> Router Class Initialized
INFO - 2016-11-22 11:20:29 --> Output Class Initialized
INFO - 2016-11-22 11:20:29 --> Security Class Initialized
DEBUG - 2016-11-22 11:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:20:29 --> Input Class Initialized
INFO - 2016-11-22 11:20:29 --> Language Class Initialized
INFO - 2016-11-22 11:20:29 --> Loader Class Initialized
INFO - 2016-11-22 11:20:29 --> Helper loaded: url_helper
INFO - 2016-11-22 11:20:29 --> Helper loaded: form_helper
INFO - 2016-11-22 11:20:29 --> Database Driver Class Initialized
INFO - 2016-11-22 11:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:20:29 --> Controller Class Initialized
INFO - 2016-11-22 11:20:29 --> Model Class Initialized
INFO - 2016-11-22 11:20:29 --> Model Class Initialized
INFO - 2016-11-22 11:20:29 --> Model Class Initialized
INFO - 2016-11-22 11:20:29 --> Model Class Initialized
INFO - 2016-11-22 11:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:20:29 --> Pagination Class Initialized
INFO - 2016-11-22 11:20:29 --> Helper loaded: app_helper
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:20:29 --> Final output sent to browser
DEBUG - 2016-11-22 11:20:29 --> Total execution time: 0.6604
INFO - 2016-11-22 11:20:42 --> Config Class Initialized
INFO - 2016-11-22 11:20:42 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:20:42 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:20:42 --> Utf8 Class Initialized
INFO - 2016-11-22 11:20:42 --> URI Class Initialized
INFO - 2016-11-22 11:20:42 --> Router Class Initialized
INFO - 2016-11-22 11:20:42 --> Output Class Initialized
INFO - 2016-11-22 11:20:42 --> Security Class Initialized
DEBUG - 2016-11-22 11:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:20:42 --> Input Class Initialized
INFO - 2016-11-22 11:20:42 --> Language Class Initialized
INFO - 2016-11-22 11:20:42 --> Loader Class Initialized
INFO - 2016-11-22 11:20:42 --> Helper loaded: url_helper
INFO - 2016-11-22 11:20:42 --> Helper loaded: form_helper
INFO - 2016-11-22 11:20:42 --> Database Driver Class Initialized
INFO - 2016-11-22 11:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:20:42 --> Controller Class Initialized
INFO - 2016-11-22 11:20:42 --> Model Class Initialized
INFO - 2016-11-22 11:20:42 --> Form Validation Class Initialized
INFO - 2016-11-22 11:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:20:42 --> Pagination Class Initialized
INFO - 2016-11-22 11:20:42 --> Helper loaded: app_helper
INFO - 2016-11-22 11:20:42 --> Email Class Initialized
INFO - 2016-11-22 11:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:20:42 --> Final output sent to browser
DEBUG - 2016-11-22 11:20:42 --> Total execution time: 0.3826
INFO - 2016-11-22 11:21:06 --> Config Class Initialized
INFO - 2016-11-22 11:21:06 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:21:06 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:21:06 --> Utf8 Class Initialized
INFO - 2016-11-22 11:21:06 --> URI Class Initialized
INFO - 2016-11-22 11:21:06 --> Router Class Initialized
INFO - 2016-11-22 11:21:06 --> Output Class Initialized
INFO - 2016-11-22 11:21:07 --> Security Class Initialized
DEBUG - 2016-11-22 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:21:07 --> Input Class Initialized
INFO - 2016-11-22 11:21:07 --> Language Class Initialized
INFO - 2016-11-22 11:21:07 --> Loader Class Initialized
INFO - 2016-11-22 11:21:07 --> Helper loaded: url_helper
INFO - 2016-11-22 11:21:07 --> Helper loaded: form_helper
INFO - 2016-11-22 11:21:07 --> Database Driver Class Initialized
INFO - 2016-11-22 11:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:21:07 --> Controller Class Initialized
INFO - 2016-11-22 11:21:07 --> Model Class Initialized
INFO - 2016-11-22 11:21:07 --> Form Validation Class Initialized
INFO - 2016-11-22 11:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:21:07 --> Pagination Class Initialized
INFO - 2016-11-22 11:21:07 --> Helper loaded: app_helper
INFO - 2016-11-22 11:21:07 --> Email Class Initialized
INFO - 2016-11-22 11:21:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 11:21:07 --> Final output sent to browser
DEBUG - 2016-11-22 11:21:07 --> Total execution time: 0.4652
INFO - 2016-11-22 11:21:14 --> Config Class Initialized
INFO - 2016-11-22 11:21:14 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:21:14 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:21:14 --> Utf8 Class Initialized
INFO - 2016-11-22 11:21:14 --> URI Class Initialized
INFO - 2016-11-22 11:21:14 --> Router Class Initialized
INFO - 2016-11-22 11:21:14 --> Output Class Initialized
INFO - 2016-11-22 11:21:14 --> Security Class Initialized
DEBUG - 2016-11-22 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:21:14 --> Input Class Initialized
INFO - 2016-11-22 11:21:14 --> Language Class Initialized
INFO - 2016-11-22 11:21:14 --> Loader Class Initialized
INFO - 2016-11-22 11:21:14 --> Helper loaded: url_helper
INFO - 2016-11-22 11:21:14 --> Helper loaded: form_helper
INFO - 2016-11-22 11:21:14 --> Database Driver Class Initialized
INFO - 2016-11-22 11:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:21:14 --> Controller Class Initialized
INFO - 2016-11-22 11:21:14 --> Model Class Initialized
INFO - 2016-11-22 11:21:14 --> Form Validation Class Initialized
INFO - 2016-11-22 11:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:21:14 --> Pagination Class Initialized
INFO - 2016-11-22 11:21:14 --> Helper loaded: app_helper
INFO - 2016-11-22 11:21:14 --> Email Class Initialized
INFO - 2016-11-22 11:21:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:21:15 --> Final output sent to browser
DEBUG - 2016-11-22 11:21:15 --> Total execution time: 0.4024
INFO - 2016-11-22 11:21:21 --> Config Class Initialized
INFO - 2016-11-22 11:21:21 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:21:21 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:21:21 --> Utf8 Class Initialized
INFO - 2016-11-22 11:21:21 --> URI Class Initialized
INFO - 2016-11-22 11:21:21 --> Router Class Initialized
INFO - 2016-11-22 11:21:21 --> Output Class Initialized
INFO - 2016-11-22 11:21:21 --> Security Class Initialized
DEBUG - 2016-11-22 11:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:21:21 --> Input Class Initialized
INFO - 2016-11-22 11:21:21 --> Language Class Initialized
INFO - 2016-11-22 11:21:21 --> Loader Class Initialized
INFO - 2016-11-22 11:21:21 --> Helper loaded: url_helper
INFO - 2016-11-22 11:21:21 --> Helper loaded: form_helper
INFO - 2016-11-22 11:21:21 --> Database Driver Class Initialized
INFO - 2016-11-22 11:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:21:21 --> Controller Class Initialized
INFO - 2016-11-22 11:21:21 --> Model Class Initialized
INFO - 2016-11-22 11:21:21 --> Form Validation Class Initialized
INFO - 2016-11-22 11:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:21:21 --> Pagination Class Initialized
INFO - 2016-11-22 11:21:21 --> Helper loaded: app_helper
INFO - 2016-11-22 11:21:21 --> Email Class Initialized
INFO - 2016-11-22 11:21:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:21:21 --> Final output sent to browser
DEBUG - 2016-11-22 11:21:21 --> Total execution time: 0.4008
INFO - 2016-11-22 11:21:23 --> Config Class Initialized
INFO - 2016-11-22 11:21:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:21:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:21:23 --> Utf8 Class Initialized
INFO - 2016-11-22 11:21:23 --> URI Class Initialized
DEBUG - 2016-11-22 11:21:23 --> No URI present. Default controller set.
INFO - 2016-11-22 11:21:23 --> Router Class Initialized
INFO - 2016-11-22 11:21:23 --> Output Class Initialized
INFO - 2016-11-22 11:21:23 --> Security Class Initialized
DEBUG - 2016-11-22 11:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:21:23 --> Input Class Initialized
INFO - 2016-11-22 11:21:23 --> Language Class Initialized
INFO - 2016-11-22 11:21:23 --> Loader Class Initialized
INFO - 2016-11-22 11:21:23 --> Helper loaded: url_helper
INFO - 2016-11-22 11:21:23 --> Helper loaded: form_helper
INFO - 2016-11-22 11:21:23 --> Database Driver Class Initialized
INFO - 2016-11-22 11:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:21:23 --> Controller Class Initialized
INFO - 2016-11-22 11:21:23 --> Model Class Initialized
INFO - 2016-11-22 11:21:23 --> Model Class Initialized
INFO - 2016-11-22 11:21:23 --> Model Class Initialized
INFO - 2016-11-22 11:21:23 --> Model Class Initialized
INFO - 2016-11-22 11:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:21:23 --> Pagination Class Initialized
INFO - 2016-11-22 11:21:23 --> Helper loaded: app_helper
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:21:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:21:23 --> Final output sent to browser
DEBUG - 2016-11-22 11:21:23 --> Total execution time: 0.7465
INFO - 2016-11-22 11:21:33 --> Config Class Initialized
INFO - 2016-11-22 11:21:33 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:21:33 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:21:33 --> Utf8 Class Initialized
INFO - 2016-11-22 11:21:33 --> URI Class Initialized
DEBUG - 2016-11-22 11:21:34 --> No URI present. Default controller set.
INFO - 2016-11-22 11:21:34 --> Router Class Initialized
INFO - 2016-11-22 11:21:34 --> Output Class Initialized
INFO - 2016-11-22 11:21:34 --> Security Class Initialized
DEBUG - 2016-11-22 11:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:21:34 --> Input Class Initialized
INFO - 2016-11-22 11:21:34 --> Language Class Initialized
INFO - 2016-11-22 11:21:34 --> Loader Class Initialized
INFO - 2016-11-22 11:21:34 --> Helper loaded: url_helper
INFO - 2016-11-22 11:21:34 --> Helper loaded: form_helper
INFO - 2016-11-22 11:21:34 --> Database Driver Class Initialized
INFO - 2016-11-22 11:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:21:34 --> Controller Class Initialized
INFO - 2016-11-22 11:21:34 --> Model Class Initialized
INFO - 2016-11-22 11:21:34 --> Model Class Initialized
INFO - 2016-11-22 11:21:34 --> Model Class Initialized
INFO - 2016-11-22 11:21:34 --> Model Class Initialized
INFO - 2016-11-22 11:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:21:34 --> Pagination Class Initialized
INFO - 2016-11-22 11:21:34 --> Helper loaded: app_helper
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:21:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:21:34 --> Final output sent to browser
DEBUG - 2016-11-22 11:21:34 --> Total execution time: 0.6238
INFO - 2016-11-22 11:22:03 --> Config Class Initialized
INFO - 2016-11-22 11:22:03 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:22:03 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:22:03 --> Utf8 Class Initialized
INFO - 2016-11-22 11:22:03 --> URI Class Initialized
INFO - 2016-11-22 11:22:03 --> Router Class Initialized
INFO - 2016-11-22 11:22:03 --> Output Class Initialized
INFO - 2016-11-22 11:22:03 --> Security Class Initialized
DEBUG - 2016-11-22 11:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:22:03 --> Input Class Initialized
INFO - 2016-11-22 11:22:03 --> Language Class Initialized
INFO - 2016-11-22 11:22:03 --> Loader Class Initialized
INFO - 2016-11-22 11:22:03 --> Helper loaded: url_helper
INFO - 2016-11-22 11:22:03 --> Helper loaded: form_helper
INFO - 2016-11-22 11:22:03 --> Database Driver Class Initialized
INFO - 2016-11-22 11:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:22:03 --> Controller Class Initialized
INFO - 2016-11-22 11:22:03 --> Model Class Initialized
INFO - 2016-11-22 11:22:03 --> Form Validation Class Initialized
INFO - 2016-11-22 11:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:22:04 --> Pagination Class Initialized
INFO - 2016-11-22 11:22:04 --> Helper loaded: app_helper
INFO - 2016-11-22 11:22:04 --> Email Class Initialized
INFO - 2016-11-22 11:22:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:22:04 --> Final output sent to browser
DEBUG - 2016-11-22 11:22:04 --> Total execution time: 0.7219
INFO - 2016-11-22 11:22:09 --> Config Class Initialized
INFO - 2016-11-22 11:22:09 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:22:09 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:22:09 --> Utf8 Class Initialized
INFO - 2016-11-22 11:22:09 --> URI Class Initialized
DEBUG - 2016-11-22 11:22:09 --> No URI present. Default controller set.
INFO - 2016-11-22 11:22:09 --> Router Class Initialized
INFO - 2016-11-22 11:22:09 --> Output Class Initialized
INFO - 2016-11-22 11:22:09 --> Security Class Initialized
DEBUG - 2016-11-22 11:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:22:09 --> Input Class Initialized
INFO - 2016-11-22 11:22:09 --> Language Class Initialized
INFO - 2016-11-22 11:22:09 --> Loader Class Initialized
INFO - 2016-11-22 11:22:09 --> Helper loaded: url_helper
INFO - 2016-11-22 11:22:09 --> Helper loaded: form_helper
INFO - 2016-11-22 11:22:09 --> Database Driver Class Initialized
INFO - 2016-11-22 11:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:22:09 --> Controller Class Initialized
INFO - 2016-11-22 11:22:09 --> Model Class Initialized
INFO - 2016-11-22 11:22:09 --> Model Class Initialized
INFO - 2016-11-22 11:22:09 --> Model Class Initialized
INFO - 2016-11-22 11:22:09 --> Model Class Initialized
INFO - 2016-11-22 11:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:22:09 --> Pagination Class Initialized
INFO - 2016-11-22 11:22:09 --> Helper loaded: app_helper
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:22:09 --> Final output sent to browser
DEBUG - 2016-11-22 11:22:10 --> Total execution time: 0.6426
INFO - 2016-11-22 11:23:39 --> Config Class Initialized
INFO - 2016-11-22 11:23:39 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:23:39 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:23:39 --> Utf8 Class Initialized
INFO - 2016-11-22 11:23:39 --> URI Class Initialized
INFO - 2016-11-22 11:23:39 --> Router Class Initialized
INFO - 2016-11-22 11:23:39 --> Output Class Initialized
INFO - 2016-11-22 11:23:39 --> Security Class Initialized
DEBUG - 2016-11-22 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:23:39 --> Input Class Initialized
INFO - 2016-11-22 11:23:39 --> Language Class Initialized
INFO - 2016-11-22 11:23:39 --> Loader Class Initialized
INFO - 2016-11-22 11:23:39 --> Helper loaded: url_helper
INFO - 2016-11-22 11:23:40 --> Helper loaded: form_helper
INFO - 2016-11-22 11:23:40 --> Database Driver Class Initialized
INFO - 2016-11-22 11:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:23:40 --> Controller Class Initialized
INFO - 2016-11-22 11:23:40 --> Model Class Initialized
INFO - 2016-11-22 11:23:40 --> Form Validation Class Initialized
INFO - 2016-11-22 11:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:23:40 --> Pagination Class Initialized
INFO - 2016-11-22 11:23:40 --> Helper loaded: app_helper
INFO - 2016-11-22 11:23:40 --> Email Class Initialized
INFO - 2016-11-22 11:23:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:23:40 --> Final output sent to browser
DEBUG - 2016-11-22 11:23:40 --> Total execution time: 0.3570
INFO - 2016-11-22 11:25:01 --> Config Class Initialized
INFO - 2016-11-22 11:25:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:25:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:25:01 --> Utf8 Class Initialized
INFO - 2016-11-22 11:25:01 --> URI Class Initialized
DEBUG - 2016-11-22 11:25:01 --> No URI present. Default controller set.
INFO - 2016-11-22 11:25:01 --> Router Class Initialized
INFO - 2016-11-22 11:25:01 --> Output Class Initialized
INFO - 2016-11-22 11:25:01 --> Security Class Initialized
DEBUG - 2016-11-22 11:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:25:01 --> Input Class Initialized
INFO - 2016-11-22 11:25:01 --> Language Class Initialized
INFO - 2016-11-22 11:25:01 --> Loader Class Initialized
INFO - 2016-11-22 11:25:01 --> Helper loaded: url_helper
INFO - 2016-11-22 11:25:01 --> Helper loaded: form_helper
INFO - 2016-11-22 11:25:01 --> Database Driver Class Initialized
INFO - 2016-11-22 11:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:25:01 --> Controller Class Initialized
INFO - 2016-11-22 11:25:01 --> Model Class Initialized
INFO - 2016-11-22 11:25:01 --> Model Class Initialized
INFO - 2016-11-22 11:25:02 --> Model Class Initialized
INFO - 2016-11-22 11:25:02 --> Model Class Initialized
INFO - 2016-11-22 11:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:25:02 --> Pagination Class Initialized
INFO - 2016-11-22 11:25:02 --> Helper loaded: app_helper
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:25:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:25:02 --> Final output sent to browser
DEBUG - 2016-11-22 11:25:02 --> Total execution time: 0.6461
INFO - 2016-11-22 11:25:10 --> Config Class Initialized
INFO - 2016-11-22 11:25:10 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:25:10 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:25:10 --> Utf8 Class Initialized
INFO - 2016-11-22 11:25:10 --> URI Class Initialized
INFO - 2016-11-22 11:25:10 --> Router Class Initialized
INFO - 2016-11-22 11:25:10 --> Output Class Initialized
INFO - 2016-11-22 11:25:10 --> Security Class Initialized
DEBUG - 2016-11-22 11:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:25:10 --> Input Class Initialized
INFO - 2016-11-22 11:25:10 --> Language Class Initialized
INFO - 2016-11-22 11:25:10 --> Loader Class Initialized
INFO - 2016-11-22 11:25:10 --> Helper loaded: url_helper
INFO - 2016-11-22 11:25:10 --> Helper loaded: form_helper
INFO - 2016-11-22 11:25:10 --> Database Driver Class Initialized
INFO - 2016-11-22 11:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:25:10 --> Controller Class Initialized
INFO - 2016-11-22 11:25:11 --> Model Class Initialized
INFO - 2016-11-22 11:25:11 --> Form Validation Class Initialized
INFO - 2016-11-22 11:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:25:11 --> Pagination Class Initialized
INFO - 2016-11-22 11:25:11 --> Helper loaded: app_helper
INFO - 2016-11-22 11:25:11 --> Email Class Initialized
INFO - 2016-11-22 11:25:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:25:11 --> Final output sent to browser
DEBUG - 2016-11-22 11:25:11 --> Total execution time: 0.5449
INFO - 2016-11-22 11:25:44 --> Config Class Initialized
INFO - 2016-11-22 11:25:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:25:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:25:44 --> Utf8 Class Initialized
INFO - 2016-11-22 11:25:44 --> URI Class Initialized
INFO - 2016-11-22 11:25:44 --> Router Class Initialized
INFO - 2016-11-22 11:25:44 --> Output Class Initialized
INFO - 2016-11-22 11:25:44 --> Security Class Initialized
DEBUG - 2016-11-22 11:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:25:44 --> Input Class Initialized
INFO - 2016-11-22 11:25:44 --> Language Class Initialized
INFO - 2016-11-22 11:25:44 --> Loader Class Initialized
INFO - 2016-11-22 11:25:44 --> Helper loaded: url_helper
INFO - 2016-11-22 11:25:44 --> Helper loaded: form_helper
INFO - 2016-11-22 11:25:44 --> Database Driver Class Initialized
INFO - 2016-11-22 11:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:25:44 --> Controller Class Initialized
INFO - 2016-11-22 11:25:44 --> Model Class Initialized
INFO - 2016-11-22 11:25:44 --> Form Validation Class Initialized
INFO - 2016-11-22 11:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:25:44 --> Pagination Class Initialized
INFO - 2016-11-22 11:25:44 --> Helper loaded: app_helper
INFO - 2016-11-22 11:25:44 --> Email Class Initialized
INFO - 2016-11-22 11:25:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:25:44 --> Final output sent to browser
DEBUG - 2016-11-22 11:25:44 --> Total execution time: 0.3678
INFO - 2016-11-22 11:25:54 --> Config Class Initialized
INFO - 2016-11-22 11:25:54 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:25:54 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:25:54 --> Utf8 Class Initialized
INFO - 2016-11-22 11:25:54 --> URI Class Initialized
INFO - 2016-11-22 11:25:54 --> Router Class Initialized
INFO - 2016-11-22 11:25:54 --> Output Class Initialized
INFO - 2016-11-22 11:25:54 --> Security Class Initialized
DEBUG - 2016-11-22 11:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:25:54 --> Input Class Initialized
INFO - 2016-11-22 11:25:54 --> Language Class Initialized
INFO - 2016-11-22 11:25:54 --> Loader Class Initialized
INFO - 2016-11-22 11:25:54 --> Helper loaded: url_helper
INFO - 2016-11-22 11:25:54 --> Helper loaded: form_helper
INFO - 2016-11-22 11:25:55 --> Database Driver Class Initialized
INFO - 2016-11-22 11:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:25:55 --> Controller Class Initialized
INFO - 2016-11-22 11:25:55 --> Model Class Initialized
INFO - 2016-11-22 11:25:55 --> Form Validation Class Initialized
INFO - 2016-11-22 11:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:25:55 --> Pagination Class Initialized
INFO - 2016-11-22 11:25:55 --> Helper loaded: app_helper
INFO - 2016-11-22 11:25:55 --> Email Class Initialized
INFO - 2016-11-22 11:25:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:25:55 --> Final output sent to browser
DEBUG - 2016-11-22 11:25:55 --> Total execution time: 0.3869
INFO - 2016-11-22 11:26:51 --> Config Class Initialized
INFO - 2016-11-22 11:26:51 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:26:51 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:26:51 --> Utf8 Class Initialized
INFO - 2016-11-22 11:26:51 --> URI Class Initialized
DEBUG - 2016-11-22 11:26:51 --> No URI present. Default controller set.
INFO - 2016-11-22 11:26:51 --> Router Class Initialized
INFO - 2016-11-22 11:26:51 --> Output Class Initialized
INFO - 2016-11-22 11:26:51 --> Security Class Initialized
DEBUG - 2016-11-22 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:26:51 --> Input Class Initialized
INFO - 2016-11-22 11:26:51 --> Language Class Initialized
INFO - 2016-11-22 11:26:51 --> Loader Class Initialized
INFO - 2016-11-22 11:26:51 --> Helper loaded: url_helper
INFO - 2016-11-22 11:26:51 --> Helper loaded: form_helper
INFO - 2016-11-22 11:26:51 --> Database Driver Class Initialized
INFO - 2016-11-22 11:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:26:51 --> Controller Class Initialized
INFO - 2016-11-22 11:26:51 --> Model Class Initialized
INFO - 2016-11-22 11:26:51 --> Model Class Initialized
INFO - 2016-11-22 11:26:51 --> Model Class Initialized
INFO - 2016-11-22 11:26:51 --> Model Class Initialized
INFO - 2016-11-22 11:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:26:51 --> Pagination Class Initialized
INFO - 2016-11-22 11:26:51 --> Helper loaded: app_helper
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:26:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:26:51 --> Final output sent to browser
DEBUG - 2016-11-22 11:26:51 --> Total execution time: 0.6579
INFO - 2016-11-22 11:27:16 --> Config Class Initialized
INFO - 2016-11-22 11:27:16 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:27:16 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:27:16 --> Utf8 Class Initialized
INFO - 2016-11-22 11:27:16 --> URI Class Initialized
INFO - 2016-11-22 11:27:16 --> Router Class Initialized
INFO - 2016-11-22 11:27:16 --> Output Class Initialized
INFO - 2016-11-22 11:27:16 --> Security Class Initialized
DEBUG - 2016-11-22 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:27:16 --> Input Class Initialized
INFO - 2016-11-22 11:27:16 --> Language Class Initialized
INFO - 2016-11-22 11:27:16 --> Loader Class Initialized
INFO - 2016-11-22 11:27:16 --> Helper loaded: url_helper
INFO - 2016-11-22 11:27:16 --> Helper loaded: form_helper
INFO - 2016-11-22 11:27:16 --> Database Driver Class Initialized
INFO - 2016-11-22 11:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:27:17 --> Controller Class Initialized
INFO - 2016-11-22 11:27:17 --> Model Class Initialized
INFO - 2016-11-22 11:27:17 --> Form Validation Class Initialized
INFO - 2016-11-22 11:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:27:17 --> Pagination Class Initialized
INFO - 2016-11-22 11:27:17 --> Helper loaded: app_helper
INFO - 2016-11-22 11:27:17 --> Email Class Initialized
INFO - 2016-11-22 11:27:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:27:17 --> Final output sent to browser
DEBUG - 2016-11-22 11:27:17 --> Total execution time: 0.4886
INFO - 2016-11-22 11:27:36 --> Config Class Initialized
INFO - 2016-11-22 11:27:36 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:27:36 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:27:36 --> Utf8 Class Initialized
INFO - 2016-11-22 11:27:36 --> URI Class Initialized
DEBUG - 2016-11-22 11:27:36 --> No URI present. Default controller set.
INFO - 2016-11-22 11:27:36 --> Router Class Initialized
INFO - 2016-11-22 11:27:36 --> Output Class Initialized
INFO - 2016-11-22 11:27:36 --> Security Class Initialized
DEBUG - 2016-11-22 11:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:27:36 --> Input Class Initialized
INFO - 2016-11-22 11:27:36 --> Language Class Initialized
INFO - 2016-11-22 11:27:36 --> Loader Class Initialized
INFO - 2016-11-22 11:27:36 --> Helper loaded: url_helper
INFO - 2016-11-22 11:27:36 --> Helper loaded: form_helper
INFO - 2016-11-22 11:27:36 --> Database Driver Class Initialized
INFO - 2016-11-22 11:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:27:36 --> Controller Class Initialized
INFO - 2016-11-22 11:27:36 --> Model Class Initialized
INFO - 2016-11-22 11:27:36 --> Model Class Initialized
INFO - 2016-11-22 11:27:36 --> Model Class Initialized
INFO - 2016-11-22 11:27:36 --> Model Class Initialized
INFO - 2016-11-22 11:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:27:36 --> Pagination Class Initialized
INFO - 2016-11-22 11:27:36 --> Helper loaded: app_helper
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:27:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:27:36 --> Final output sent to browser
DEBUG - 2016-11-22 11:27:36 --> Total execution time: 0.6508
INFO - 2016-11-22 11:27:49 --> Config Class Initialized
INFO - 2016-11-22 11:27:49 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:27:49 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:27:49 --> Utf8 Class Initialized
INFO - 2016-11-22 11:27:49 --> URI Class Initialized
INFO - 2016-11-22 11:27:49 --> Router Class Initialized
INFO - 2016-11-22 11:27:49 --> Output Class Initialized
INFO - 2016-11-22 11:27:49 --> Security Class Initialized
DEBUG - 2016-11-22 11:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:27:49 --> Input Class Initialized
INFO - 2016-11-22 11:27:49 --> Language Class Initialized
INFO - 2016-11-22 11:27:49 --> Loader Class Initialized
INFO - 2016-11-22 11:27:49 --> Helper loaded: url_helper
INFO - 2016-11-22 11:27:49 --> Helper loaded: form_helper
INFO - 2016-11-22 11:27:49 --> Database Driver Class Initialized
INFO - 2016-11-22 11:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:27:50 --> Controller Class Initialized
INFO - 2016-11-22 11:27:50 --> Model Class Initialized
INFO - 2016-11-22 11:27:50 --> Form Validation Class Initialized
INFO - 2016-11-22 11:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:27:50 --> Pagination Class Initialized
INFO - 2016-11-22 11:27:50 --> Helper loaded: app_helper
INFO - 2016-11-22 11:27:50 --> Email Class Initialized
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:50 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:27:51 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-22 11:27:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:27:51 --> Final output sent to browser
DEBUG - 2016-11-22 11:27:51 --> Total execution time: 1.9247
INFO - 2016-11-22 11:27:51 --> Config Class Initialized
INFO - 2016-11-22 11:27:51 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:27:51 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:27:51 --> Utf8 Class Initialized
INFO - 2016-11-22 11:27:51 --> URI Class Initialized
DEBUG - 2016-11-22 11:27:51 --> No URI present. Default controller set.
INFO - 2016-11-22 11:27:51 --> Router Class Initialized
INFO - 2016-11-22 11:27:51 --> Output Class Initialized
INFO - 2016-11-22 11:27:51 --> Security Class Initialized
DEBUG - 2016-11-22 11:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:27:51 --> Input Class Initialized
INFO - 2016-11-22 11:27:51 --> Language Class Initialized
INFO - 2016-11-22 11:27:51 --> Loader Class Initialized
INFO - 2016-11-22 11:27:51 --> Helper loaded: url_helper
INFO - 2016-11-22 11:27:51 --> Helper loaded: form_helper
INFO - 2016-11-22 11:27:51 --> Database Driver Class Initialized
INFO - 2016-11-22 11:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:27:51 --> Controller Class Initialized
INFO - 2016-11-22 11:27:51 --> Model Class Initialized
INFO - 2016-11-22 11:27:51 --> Model Class Initialized
INFO - 2016-11-22 11:27:51 --> Model Class Initialized
INFO - 2016-11-22 11:27:51 --> Model Class Initialized
INFO - 2016-11-22 11:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:27:52 --> Pagination Class Initialized
INFO - 2016-11-22 11:27:52 --> Helper loaded: app_helper
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:27:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:27:52 --> Final output sent to browser
DEBUG - 2016-11-22 11:27:52 --> Total execution time: 0.6193
INFO - 2016-11-22 11:28:12 --> Config Class Initialized
INFO - 2016-11-22 11:28:12 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:28:12 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:28:12 --> Utf8 Class Initialized
INFO - 2016-11-22 11:28:12 --> URI Class Initialized
DEBUG - 2016-11-22 11:28:12 --> No URI present. Default controller set.
INFO - 2016-11-22 11:28:12 --> Router Class Initialized
INFO - 2016-11-22 11:28:12 --> Output Class Initialized
INFO - 2016-11-22 11:28:12 --> Security Class Initialized
DEBUG - 2016-11-22 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:28:12 --> Input Class Initialized
INFO - 2016-11-22 11:28:12 --> Language Class Initialized
INFO - 2016-11-22 11:28:12 --> Loader Class Initialized
INFO - 2016-11-22 11:28:12 --> Helper loaded: url_helper
INFO - 2016-11-22 11:28:12 --> Helper loaded: form_helper
INFO - 2016-11-22 11:28:12 --> Database Driver Class Initialized
INFO - 2016-11-22 11:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:28:12 --> Controller Class Initialized
INFO - 2016-11-22 11:28:12 --> Model Class Initialized
INFO - 2016-11-22 11:28:12 --> Model Class Initialized
INFO - 2016-11-22 11:28:12 --> Model Class Initialized
INFO - 2016-11-22 11:28:12 --> Model Class Initialized
INFO - 2016-11-22 11:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:28:12 --> Pagination Class Initialized
INFO - 2016-11-22 11:28:12 --> Helper loaded: app_helper
INFO - 2016-11-22 11:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:28:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:28:13 --> Final output sent to browser
DEBUG - 2016-11-22 11:28:13 --> Total execution time: 0.6398
INFO - 2016-11-22 11:28:21 --> Config Class Initialized
INFO - 2016-11-22 11:28:21 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:28:21 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:28:21 --> Utf8 Class Initialized
INFO - 2016-11-22 11:28:21 --> URI Class Initialized
DEBUG - 2016-11-22 11:28:22 --> No URI present. Default controller set.
INFO - 2016-11-22 11:28:22 --> Router Class Initialized
INFO - 2016-11-22 11:28:22 --> Output Class Initialized
INFO - 2016-11-22 11:28:22 --> Security Class Initialized
DEBUG - 2016-11-22 11:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:28:22 --> Input Class Initialized
INFO - 2016-11-22 11:28:22 --> Language Class Initialized
INFO - 2016-11-22 11:28:22 --> Loader Class Initialized
INFO - 2016-11-22 11:28:22 --> Helper loaded: url_helper
INFO - 2016-11-22 11:28:22 --> Helper loaded: form_helper
INFO - 2016-11-22 11:28:22 --> Database Driver Class Initialized
INFO - 2016-11-22 11:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:28:22 --> Controller Class Initialized
INFO - 2016-11-22 11:28:22 --> Model Class Initialized
INFO - 2016-11-22 11:28:22 --> Model Class Initialized
INFO - 2016-11-22 11:28:22 --> Model Class Initialized
INFO - 2016-11-22 11:28:22 --> Model Class Initialized
INFO - 2016-11-22 11:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:28:22 --> Pagination Class Initialized
INFO - 2016-11-22 11:28:22 --> Helper loaded: app_helper
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:28:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:28:22 --> Final output sent to browser
DEBUG - 2016-11-22 11:28:22 --> Total execution time: 0.6611
INFO - 2016-11-22 11:28:28 --> Config Class Initialized
INFO - 2016-11-22 11:28:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:28:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:28:28 --> Utf8 Class Initialized
INFO - 2016-11-22 11:28:28 --> URI Class Initialized
INFO - 2016-11-22 11:28:28 --> Router Class Initialized
INFO - 2016-11-22 11:28:28 --> Output Class Initialized
INFO - 2016-11-22 11:28:28 --> Security Class Initialized
DEBUG - 2016-11-22 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:28:28 --> Input Class Initialized
INFO - 2016-11-22 11:28:28 --> Language Class Initialized
INFO - 2016-11-22 11:28:28 --> Loader Class Initialized
INFO - 2016-11-22 11:28:28 --> Helper loaded: url_helper
INFO - 2016-11-22 11:28:28 --> Helper loaded: form_helper
INFO - 2016-11-22 11:28:28 --> Database Driver Class Initialized
INFO - 2016-11-22 11:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:28:28 --> Controller Class Initialized
INFO - 2016-11-22 11:28:28 --> Model Class Initialized
INFO - 2016-11-22 11:28:28 --> Form Validation Class Initialized
INFO - 2016-11-22 11:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:28:28 --> Pagination Class Initialized
INFO - 2016-11-22 11:28:28 --> Helper loaded: app_helper
INFO - 2016-11-22 11:28:28 --> Email Class Initialized
ERROR - 2016-11-22 11:28:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:28 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:28:29 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-22 11:28:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:28:29 --> Final output sent to browser
DEBUG - 2016-11-22 11:28:29 --> Total execution time: 1.5377
INFO - 2016-11-22 11:28:29 --> Config Class Initialized
INFO - 2016-11-22 11:28:29 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:28:29 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:28:29 --> Utf8 Class Initialized
INFO - 2016-11-22 11:28:29 --> URI Class Initialized
DEBUG - 2016-11-22 11:28:29 --> No URI present. Default controller set.
INFO - 2016-11-22 11:28:29 --> Router Class Initialized
INFO - 2016-11-22 11:28:29 --> Output Class Initialized
INFO - 2016-11-22 11:28:29 --> Security Class Initialized
DEBUG - 2016-11-22 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:28:29 --> Input Class Initialized
INFO - 2016-11-22 11:28:29 --> Language Class Initialized
INFO - 2016-11-22 11:28:30 --> Loader Class Initialized
INFO - 2016-11-22 11:28:30 --> Helper loaded: url_helper
INFO - 2016-11-22 11:28:30 --> Helper loaded: form_helper
INFO - 2016-11-22 11:28:30 --> Database Driver Class Initialized
INFO - 2016-11-22 11:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:28:30 --> Controller Class Initialized
INFO - 2016-11-22 11:28:30 --> Model Class Initialized
INFO - 2016-11-22 11:28:30 --> Model Class Initialized
INFO - 2016-11-22 11:28:30 --> Model Class Initialized
INFO - 2016-11-22 11:28:30 --> Model Class Initialized
INFO - 2016-11-22 11:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:28:30 --> Pagination Class Initialized
INFO - 2016-11-22 11:28:30 --> Helper loaded: app_helper
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:28:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:28:30 --> Final output sent to browser
DEBUG - 2016-11-22 11:28:30 --> Total execution time: 0.6234
INFO - 2016-11-22 11:28:41 --> Config Class Initialized
INFO - 2016-11-22 11:28:41 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:28:41 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:28:41 --> Utf8 Class Initialized
INFO - 2016-11-22 11:28:41 --> URI Class Initialized
DEBUG - 2016-11-22 11:28:41 --> No URI present. Default controller set.
INFO - 2016-11-22 11:28:41 --> Router Class Initialized
INFO - 2016-11-22 11:28:41 --> Output Class Initialized
INFO - 2016-11-22 11:28:41 --> Security Class Initialized
DEBUG - 2016-11-22 11:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:28:41 --> Input Class Initialized
INFO - 2016-11-22 11:28:41 --> Language Class Initialized
INFO - 2016-11-22 11:28:41 --> Loader Class Initialized
INFO - 2016-11-22 11:28:41 --> Helper loaded: url_helper
INFO - 2016-11-22 11:28:41 --> Helper loaded: form_helper
INFO - 2016-11-22 11:28:41 --> Database Driver Class Initialized
INFO - 2016-11-22 11:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:28:41 --> Controller Class Initialized
INFO - 2016-11-22 11:28:41 --> Model Class Initialized
INFO - 2016-11-22 11:28:41 --> Model Class Initialized
INFO - 2016-11-22 11:28:41 --> Model Class Initialized
INFO - 2016-11-22 11:28:41 --> Model Class Initialized
INFO - 2016-11-22 11:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:28:41 --> Pagination Class Initialized
INFO - 2016-11-22 11:28:41 --> Helper loaded: app_helper
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:28:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:28:42 --> Final output sent to browser
DEBUG - 2016-11-22 11:28:42 --> Total execution time: 0.6767
INFO - 2016-11-22 11:28:47 --> Config Class Initialized
INFO - 2016-11-22 11:28:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:28:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:28:47 --> Utf8 Class Initialized
INFO - 2016-11-22 11:28:47 --> URI Class Initialized
INFO - 2016-11-22 11:28:47 --> Router Class Initialized
INFO - 2016-11-22 11:28:47 --> Output Class Initialized
INFO - 2016-11-22 11:28:47 --> Security Class Initialized
DEBUG - 2016-11-22 11:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:28:47 --> Input Class Initialized
INFO - 2016-11-22 11:28:47 --> Language Class Initialized
INFO - 2016-11-22 11:28:47 --> Loader Class Initialized
INFO - 2016-11-22 11:28:47 --> Helper loaded: url_helper
INFO - 2016-11-22 11:28:47 --> Helper loaded: form_helper
INFO - 2016-11-22 11:28:47 --> Database Driver Class Initialized
INFO - 2016-11-22 11:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:28:47 --> Controller Class Initialized
INFO - 2016-11-22 11:28:47 --> Model Class Initialized
INFO - 2016-11-22 11:28:47 --> Form Validation Class Initialized
INFO - 2016-11-22 11:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:28:47 --> Pagination Class Initialized
INFO - 2016-11-22 11:28:47 --> Helper loaded: app_helper
INFO - 2016-11-22 11:28:47 --> Email Class Initialized
INFO - 2016-11-22 11:28:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:28:47 --> Final output sent to browser
DEBUG - 2016-11-22 11:28:47 --> Total execution time: 0.3823
INFO - 2016-11-22 11:29:01 --> Config Class Initialized
INFO - 2016-11-22 11:29:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:29:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:29:01 --> Utf8 Class Initialized
INFO - 2016-11-22 11:29:01 --> URI Class Initialized
DEBUG - 2016-11-22 11:29:01 --> No URI present. Default controller set.
INFO - 2016-11-22 11:29:01 --> Router Class Initialized
INFO - 2016-11-22 11:29:01 --> Output Class Initialized
INFO - 2016-11-22 11:29:01 --> Security Class Initialized
DEBUG - 2016-11-22 11:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:29:01 --> Input Class Initialized
INFO - 2016-11-22 11:29:01 --> Language Class Initialized
INFO - 2016-11-22 11:29:01 --> Loader Class Initialized
INFO - 2016-11-22 11:29:01 --> Helper loaded: url_helper
INFO - 2016-11-22 11:29:01 --> Helper loaded: form_helper
INFO - 2016-11-22 11:29:01 --> Database Driver Class Initialized
INFO - 2016-11-22 11:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:29:01 --> Controller Class Initialized
INFO - 2016-11-22 11:29:01 --> Model Class Initialized
INFO - 2016-11-22 11:29:01 --> Model Class Initialized
INFO - 2016-11-22 11:29:01 --> Model Class Initialized
INFO - 2016-11-22 11:29:01 --> Model Class Initialized
INFO - 2016-11-22 11:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:29:01 --> Pagination Class Initialized
INFO - 2016-11-22 11:29:01 --> Helper loaded: app_helper
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:29:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:29:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:29:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:29:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:29:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:29:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:29:02 --> Final output sent to browser
DEBUG - 2016-11-22 11:29:02 --> Total execution time: 0.9070
INFO - 2016-11-22 11:29:04 --> Config Class Initialized
INFO - 2016-11-22 11:29:05 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:29:05 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:29:05 --> Utf8 Class Initialized
INFO - 2016-11-22 11:29:05 --> URI Class Initialized
INFO - 2016-11-22 11:29:05 --> Router Class Initialized
INFO - 2016-11-22 11:29:05 --> Output Class Initialized
INFO - 2016-11-22 11:29:05 --> Security Class Initialized
DEBUG - 2016-11-22 11:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:29:05 --> Input Class Initialized
INFO - 2016-11-22 11:29:05 --> Language Class Initialized
INFO - 2016-11-22 11:29:05 --> Loader Class Initialized
INFO - 2016-11-22 11:29:05 --> Helper loaded: url_helper
INFO - 2016-11-22 11:29:05 --> Helper loaded: form_helper
INFO - 2016-11-22 11:29:05 --> Database Driver Class Initialized
INFO - 2016-11-22 11:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:29:05 --> Controller Class Initialized
INFO - 2016-11-22 11:29:05 --> Model Class Initialized
INFO - 2016-11-22 11:29:05 --> Form Validation Class Initialized
INFO - 2016-11-22 11:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:29:05 --> Pagination Class Initialized
INFO - 2016-11-22 11:29:05 --> Helper loaded: app_helper
INFO - 2016-11-22 11:29:05 --> Email Class Initialized
INFO - 2016-11-22 11:29:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:29:05 --> Final output sent to browser
DEBUG - 2016-11-22 11:29:05 --> Total execution time: 0.4316
INFO - 2016-11-22 11:30:19 --> Config Class Initialized
INFO - 2016-11-22 11:30:19 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:30:19 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:30:19 --> Utf8 Class Initialized
INFO - 2016-11-22 11:30:19 --> URI Class Initialized
DEBUG - 2016-11-22 11:30:19 --> No URI present. Default controller set.
INFO - 2016-11-22 11:30:19 --> Router Class Initialized
INFO - 2016-11-22 11:30:19 --> Output Class Initialized
INFO - 2016-11-22 11:30:19 --> Security Class Initialized
DEBUG - 2016-11-22 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:30:19 --> Input Class Initialized
INFO - 2016-11-22 11:30:19 --> Language Class Initialized
INFO - 2016-11-22 11:30:19 --> Loader Class Initialized
INFO - 2016-11-22 11:30:19 --> Helper loaded: url_helper
INFO - 2016-11-22 11:30:19 --> Helper loaded: form_helper
INFO - 2016-11-22 11:30:19 --> Database Driver Class Initialized
INFO - 2016-11-22 11:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:30:19 --> Controller Class Initialized
INFO - 2016-11-22 11:30:19 --> Model Class Initialized
INFO - 2016-11-22 11:30:19 --> Model Class Initialized
INFO - 2016-11-22 11:30:19 --> Model Class Initialized
INFO - 2016-11-22 11:30:19 --> Model Class Initialized
INFO - 2016-11-22 11:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:30:19 --> Pagination Class Initialized
INFO - 2016-11-22 11:30:20 --> Helper loaded: app_helper
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:30:20 --> Final output sent to browser
DEBUG - 2016-11-22 11:30:20 --> Total execution time: 0.7075
INFO - 2016-11-22 11:30:43 --> Config Class Initialized
INFO - 2016-11-22 11:30:43 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:30:43 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:30:43 --> Utf8 Class Initialized
INFO - 2016-11-22 11:30:43 --> URI Class Initialized
DEBUG - 2016-11-22 11:30:43 --> No URI present. Default controller set.
INFO - 2016-11-22 11:30:43 --> Router Class Initialized
INFO - 2016-11-22 11:30:43 --> Output Class Initialized
INFO - 2016-11-22 11:30:43 --> Security Class Initialized
DEBUG - 2016-11-22 11:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:30:43 --> Input Class Initialized
INFO - 2016-11-22 11:30:43 --> Language Class Initialized
INFO - 2016-11-22 11:30:43 --> Loader Class Initialized
INFO - 2016-11-22 11:30:43 --> Helper loaded: url_helper
INFO - 2016-11-22 11:30:43 --> Helper loaded: form_helper
INFO - 2016-11-22 11:30:43 --> Database Driver Class Initialized
INFO - 2016-11-22 11:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:30:43 --> Controller Class Initialized
INFO - 2016-11-22 11:30:43 --> Model Class Initialized
INFO - 2016-11-22 11:30:43 --> Model Class Initialized
INFO - 2016-11-22 11:30:43 --> Model Class Initialized
INFO - 2016-11-22 11:30:43 --> Model Class Initialized
INFO - 2016-11-22 11:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:30:43 --> Pagination Class Initialized
INFO - 2016-11-22 11:30:43 --> Helper loaded: app_helper
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:30:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:30:44 --> Final output sent to browser
DEBUG - 2016-11-22 11:30:44 --> Total execution time: 0.7012
INFO - 2016-11-22 11:38:22 --> Config Class Initialized
INFO - 2016-11-22 11:38:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:38:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:38:23 --> Utf8 Class Initialized
INFO - 2016-11-22 11:38:23 --> URI Class Initialized
INFO - 2016-11-22 11:38:23 --> Router Class Initialized
INFO - 2016-11-22 11:38:23 --> Output Class Initialized
INFO - 2016-11-22 11:38:23 --> Security Class Initialized
DEBUG - 2016-11-22 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:38:23 --> Input Class Initialized
INFO - 2016-11-22 11:38:23 --> Language Class Initialized
INFO - 2016-11-22 11:38:23 --> Loader Class Initialized
INFO - 2016-11-22 11:38:23 --> Helper loaded: url_helper
INFO - 2016-11-22 11:38:23 --> Helper loaded: form_helper
INFO - 2016-11-22 11:38:23 --> Database Driver Class Initialized
INFO - 2016-11-22 11:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:38:23 --> Controller Class Initialized
INFO - 2016-11-22 11:38:23 --> Model Class Initialized
INFO - 2016-11-22 11:38:23 --> Form Validation Class Initialized
INFO - 2016-11-22 11:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:38:23 --> Pagination Class Initialized
INFO - 2016-11-22 11:38:23 --> Helper loaded: app_helper
INFO - 2016-11-22 11:38:23 --> Email Class Initialized
INFO - 2016-11-22 11:38:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:38:23 --> Final output sent to browser
DEBUG - 2016-11-22 11:38:23 --> Total execution time: 0.4514
INFO - 2016-11-22 11:38:38 --> Config Class Initialized
INFO - 2016-11-22 11:38:38 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:38:38 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:38:38 --> Utf8 Class Initialized
INFO - 2016-11-22 11:38:38 --> URI Class Initialized
INFO - 2016-11-22 11:38:38 --> Router Class Initialized
INFO - 2016-11-22 11:38:38 --> Output Class Initialized
INFO - 2016-11-22 11:38:38 --> Security Class Initialized
DEBUG - 2016-11-22 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:38:38 --> Input Class Initialized
INFO - 2016-11-22 11:38:38 --> Language Class Initialized
INFO - 2016-11-22 11:38:38 --> Loader Class Initialized
INFO - 2016-11-22 11:38:38 --> Helper loaded: url_helper
INFO - 2016-11-22 11:38:38 --> Helper loaded: form_helper
INFO - 2016-11-22 11:38:39 --> Database Driver Class Initialized
INFO - 2016-11-22 11:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:38:39 --> Controller Class Initialized
INFO - 2016-11-22 11:38:39 --> Model Class Initialized
INFO - 2016-11-22 11:38:39 --> Form Validation Class Initialized
INFO - 2016-11-22 11:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:38:39 --> Pagination Class Initialized
INFO - 2016-11-22 11:38:39 --> Helper loaded: app_helper
INFO - 2016-11-22 11:38:39 --> Email Class Initialized
INFO - 2016-11-22 11:38:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:38:39 --> Final output sent to browser
DEBUG - 2016-11-22 11:38:39 --> Total execution time: 0.7477
INFO - 2016-11-22 11:39:18 --> Config Class Initialized
INFO - 2016-11-22 11:39:18 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:39:18 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:39:18 --> Utf8 Class Initialized
INFO - 2016-11-22 11:39:18 --> URI Class Initialized
DEBUG - 2016-11-22 11:39:18 --> No URI present. Default controller set.
INFO - 2016-11-22 11:39:18 --> Router Class Initialized
INFO - 2016-11-22 11:39:18 --> Output Class Initialized
INFO - 2016-11-22 11:39:18 --> Security Class Initialized
DEBUG - 2016-11-22 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:39:18 --> Input Class Initialized
INFO - 2016-11-22 11:39:18 --> Language Class Initialized
INFO - 2016-11-22 11:39:18 --> Loader Class Initialized
INFO - 2016-11-22 11:39:18 --> Helper loaded: url_helper
INFO - 2016-11-22 11:39:18 --> Helper loaded: form_helper
INFO - 2016-11-22 11:39:18 --> Database Driver Class Initialized
INFO - 2016-11-22 11:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:39:18 --> Controller Class Initialized
INFO - 2016-11-22 11:39:18 --> Model Class Initialized
INFO - 2016-11-22 11:39:18 --> Model Class Initialized
INFO - 2016-11-22 11:39:18 --> Model Class Initialized
INFO - 2016-11-22 11:39:18 --> Model Class Initialized
INFO - 2016-11-22 11:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:39:18 --> Pagination Class Initialized
INFO - 2016-11-22 11:39:18 --> Helper loaded: app_helper
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:39:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:39:18 --> Final output sent to browser
DEBUG - 2016-11-22 11:39:19 --> Total execution time: 0.6906
INFO - 2016-11-22 11:39:24 --> Config Class Initialized
INFO - 2016-11-22 11:39:24 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:39:24 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:39:24 --> Utf8 Class Initialized
INFO - 2016-11-22 11:39:24 --> URI Class Initialized
INFO - 2016-11-22 11:39:24 --> Router Class Initialized
INFO - 2016-11-22 11:39:24 --> Output Class Initialized
INFO - 2016-11-22 11:39:24 --> Security Class Initialized
DEBUG - 2016-11-22 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:39:25 --> Input Class Initialized
INFO - 2016-11-22 11:39:25 --> Language Class Initialized
INFO - 2016-11-22 11:39:25 --> Loader Class Initialized
INFO - 2016-11-22 11:39:25 --> Helper loaded: url_helper
INFO - 2016-11-22 11:39:25 --> Helper loaded: form_helper
INFO - 2016-11-22 11:39:25 --> Database Driver Class Initialized
INFO - 2016-11-22 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:39:25 --> Controller Class Initialized
INFO - 2016-11-22 11:39:25 --> Model Class Initialized
INFO - 2016-11-22 11:39:25 --> Form Validation Class Initialized
INFO - 2016-11-22 11:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:39:25 --> Pagination Class Initialized
INFO - 2016-11-22 11:39:25 --> Helper loaded: app_helper
INFO - 2016-11-22 11:39:25 --> Email Class Initialized
INFO - 2016-11-22 11:39:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:39:25 --> Final output sent to browser
DEBUG - 2016-11-22 11:39:25 --> Total execution time: 0.5056
INFO - 2016-11-22 11:39:37 --> Config Class Initialized
INFO - 2016-11-22 11:39:37 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:39:37 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:39:37 --> Utf8 Class Initialized
INFO - 2016-11-22 11:39:37 --> URI Class Initialized
DEBUG - 2016-11-22 11:39:37 --> No URI present. Default controller set.
INFO - 2016-11-22 11:39:37 --> Router Class Initialized
INFO - 2016-11-22 11:39:37 --> Output Class Initialized
INFO - 2016-11-22 11:39:37 --> Security Class Initialized
DEBUG - 2016-11-22 11:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:39:37 --> Input Class Initialized
INFO - 2016-11-22 11:39:37 --> Language Class Initialized
INFO - 2016-11-22 11:39:37 --> Loader Class Initialized
INFO - 2016-11-22 11:39:37 --> Helper loaded: url_helper
INFO - 2016-11-22 11:39:37 --> Helper loaded: form_helper
INFO - 2016-11-22 11:39:37 --> Database Driver Class Initialized
INFO - 2016-11-22 11:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:39:37 --> Controller Class Initialized
INFO - 2016-11-22 11:39:37 --> Model Class Initialized
INFO - 2016-11-22 11:39:37 --> Model Class Initialized
INFO - 2016-11-22 11:39:37 --> Model Class Initialized
INFO - 2016-11-22 11:39:37 --> Model Class Initialized
INFO - 2016-11-22 11:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:39:37 --> Pagination Class Initialized
INFO - 2016-11-22 11:39:37 --> Helper loaded: app_helper
INFO - 2016-11-22 11:39:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:39:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:39:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:39:38 --> Final output sent to browser
DEBUG - 2016-11-22 11:39:38 --> Total execution time: 1.1494
INFO - 2016-11-22 11:40:01 --> Config Class Initialized
INFO - 2016-11-22 11:40:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:40:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:40:01 --> Utf8 Class Initialized
INFO - 2016-11-22 11:40:01 --> URI Class Initialized
INFO - 2016-11-22 11:40:01 --> Router Class Initialized
INFO - 2016-11-22 11:40:01 --> Output Class Initialized
INFO - 2016-11-22 11:40:01 --> Security Class Initialized
DEBUG - 2016-11-22 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:40:01 --> Input Class Initialized
INFO - 2016-11-22 11:40:01 --> Language Class Initialized
INFO - 2016-11-22 11:40:01 --> Loader Class Initialized
INFO - 2016-11-22 11:40:01 --> Helper loaded: url_helper
INFO - 2016-11-22 11:40:01 --> Helper loaded: form_helper
INFO - 2016-11-22 11:40:01 --> Database Driver Class Initialized
INFO - 2016-11-22 11:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:40:01 --> Controller Class Initialized
INFO - 2016-11-22 11:40:01 --> Model Class Initialized
INFO - 2016-11-22 11:40:01 --> Form Validation Class Initialized
INFO - 2016-11-22 11:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:40:01 --> Pagination Class Initialized
INFO - 2016-11-22 11:40:01 --> Helper loaded: app_helper
INFO - 2016-11-22 11:40:01 --> Email Class Initialized
INFO - 2016-11-22 11:40:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:40:01 --> Final output sent to browser
DEBUG - 2016-11-22 11:40:01 --> Total execution time: 0.4427
INFO - 2016-11-22 11:40:37 --> Config Class Initialized
INFO - 2016-11-22 11:40:37 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:40:37 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:40:37 --> Utf8 Class Initialized
INFO - 2016-11-22 11:40:37 --> URI Class Initialized
DEBUG - 2016-11-22 11:40:37 --> No URI present. Default controller set.
INFO - 2016-11-22 11:40:37 --> Router Class Initialized
INFO - 2016-11-22 11:40:37 --> Output Class Initialized
INFO - 2016-11-22 11:40:37 --> Security Class Initialized
DEBUG - 2016-11-22 11:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:40:37 --> Input Class Initialized
INFO - 2016-11-22 11:40:37 --> Language Class Initialized
INFO - 2016-11-22 11:40:37 --> Loader Class Initialized
INFO - 2016-11-22 11:40:37 --> Helper loaded: url_helper
INFO - 2016-11-22 11:40:37 --> Helper loaded: form_helper
INFO - 2016-11-22 11:40:37 --> Database Driver Class Initialized
INFO - 2016-11-22 11:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:40:37 --> Controller Class Initialized
INFO - 2016-11-22 11:40:37 --> Model Class Initialized
INFO - 2016-11-22 11:40:37 --> Model Class Initialized
INFO - 2016-11-22 11:40:37 --> Model Class Initialized
INFO - 2016-11-22 11:40:37 --> Model Class Initialized
INFO - 2016-11-22 11:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:40:37 --> Pagination Class Initialized
INFO - 2016-11-22 11:40:37 --> Helper loaded: app_helper
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:40:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:40:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:40:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:40:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:40:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:40:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:40:38 --> Final output sent to browser
DEBUG - 2016-11-22 11:40:38 --> Total execution time: 0.6812
INFO - 2016-11-22 11:40:44 --> Config Class Initialized
INFO - 2016-11-22 11:40:44 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:40:44 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:40:44 --> Utf8 Class Initialized
INFO - 2016-11-22 11:40:44 --> URI Class Initialized
DEBUG - 2016-11-22 11:40:44 --> No URI present. Default controller set.
INFO - 2016-11-22 11:40:44 --> Router Class Initialized
INFO - 2016-11-22 11:40:44 --> Output Class Initialized
INFO - 2016-11-22 11:40:44 --> Security Class Initialized
DEBUG - 2016-11-22 11:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:40:44 --> Input Class Initialized
INFO - 2016-11-22 11:40:44 --> Language Class Initialized
INFO - 2016-11-22 11:40:44 --> Loader Class Initialized
INFO - 2016-11-22 11:40:44 --> Helper loaded: url_helper
INFO - 2016-11-22 11:40:44 --> Helper loaded: form_helper
INFO - 2016-11-22 11:40:44 --> Database Driver Class Initialized
INFO - 2016-11-22 11:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:40:44 --> Controller Class Initialized
INFO - 2016-11-22 11:40:44 --> Model Class Initialized
INFO - 2016-11-22 11:40:44 --> Model Class Initialized
INFO - 2016-11-22 11:40:44 --> Model Class Initialized
INFO - 2016-11-22 11:40:44 --> Model Class Initialized
INFO - 2016-11-22 11:40:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:40:44 --> Pagination Class Initialized
INFO - 2016-11-22 11:40:44 --> Helper loaded: app_helper
INFO - 2016-11-22 11:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:40:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:40:45 --> Final output sent to browser
DEBUG - 2016-11-22 11:40:45 --> Total execution time: 0.6890
INFO - 2016-11-22 11:41:18 --> Config Class Initialized
INFO - 2016-11-22 11:41:18 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:41:18 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:41:18 --> Utf8 Class Initialized
INFO - 2016-11-22 11:41:18 --> URI Class Initialized
DEBUG - 2016-11-22 11:41:18 --> No URI present. Default controller set.
INFO - 2016-11-22 11:41:18 --> Router Class Initialized
INFO - 2016-11-22 11:41:18 --> Output Class Initialized
INFO - 2016-11-22 11:41:18 --> Security Class Initialized
DEBUG - 2016-11-22 11:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:41:18 --> Input Class Initialized
INFO - 2016-11-22 11:41:18 --> Language Class Initialized
INFO - 2016-11-22 11:41:18 --> Loader Class Initialized
INFO - 2016-11-22 11:41:18 --> Helper loaded: url_helper
INFO - 2016-11-22 11:41:18 --> Helper loaded: form_helper
INFO - 2016-11-22 11:41:18 --> Database Driver Class Initialized
INFO - 2016-11-22 11:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:41:18 --> Controller Class Initialized
INFO - 2016-11-22 11:41:18 --> Model Class Initialized
INFO - 2016-11-22 11:41:18 --> Model Class Initialized
INFO - 2016-11-22 11:41:18 --> Model Class Initialized
INFO - 2016-11-22 11:41:18 --> Model Class Initialized
INFO - 2016-11-22 11:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:41:19 --> Pagination Class Initialized
INFO - 2016-11-22 11:41:19 --> Helper loaded: app_helper
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:41:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:41:19 --> Final output sent to browser
DEBUG - 2016-11-22 11:41:19 --> Total execution time: 1.1242
INFO - 2016-11-22 11:41:35 --> Config Class Initialized
INFO - 2016-11-22 11:41:35 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:41:35 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:41:35 --> Utf8 Class Initialized
INFO - 2016-11-22 11:41:35 --> URI Class Initialized
INFO - 2016-11-22 11:41:35 --> Router Class Initialized
INFO - 2016-11-22 11:41:35 --> Output Class Initialized
INFO - 2016-11-22 11:41:35 --> Security Class Initialized
DEBUG - 2016-11-22 11:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:41:35 --> Input Class Initialized
INFO - 2016-11-22 11:41:35 --> Language Class Initialized
INFO - 2016-11-22 11:41:35 --> Loader Class Initialized
INFO - 2016-11-22 11:41:35 --> Helper loaded: url_helper
INFO - 2016-11-22 11:41:36 --> Helper loaded: form_helper
INFO - 2016-11-22 11:41:36 --> Database Driver Class Initialized
INFO - 2016-11-22 11:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:41:36 --> Controller Class Initialized
INFO - 2016-11-22 11:41:36 --> Model Class Initialized
INFO - 2016-11-22 11:41:36 --> Form Validation Class Initialized
INFO - 2016-11-22 11:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:41:36 --> Pagination Class Initialized
INFO - 2016-11-22 11:41:36 --> Helper loaded: app_helper
INFO - 2016-11-22 11:41:36 --> Email Class Initialized
INFO - 2016-11-22 11:41:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:41:36 --> Final output sent to browser
DEBUG - 2016-11-22 11:41:36 --> Total execution time: 0.4463
INFO - 2016-11-22 11:41:40 --> Config Class Initialized
INFO - 2016-11-22 11:41:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:41:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:41:40 --> Utf8 Class Initialized
INFO - 2016-11-22 11:41:40 --> URI Class Initialized
DEBUG - 2016-11-22 11:41:40 --> No URI present. Default controller set.
INFO - 2016-11-22 11:41:40 --> Router Class Initialized
INFO - 2016-11-22 11:41:40 --> Output Class Initialized
INFO - 2016-11-22 11:41:40 --> Security Class Initialized
DEBUG - 2016-11-22 11:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:41:40 --> Input Class Initialized
INFO - 2016-11-22 11:41:40 --> Language Class Initialized
INFO - 2016-11-22 11:41:40 --> Loader Class Initialized
INFO - 2016-11-22 11:41:40 --> Helper loaded: url_helper
INFO - 2016-11-22 11:41:40 --> Helper loaded: form_helper
INFO - 2016-11-22 11:41:40 --> Database Driver Class Initialized
INFO - 2016-11-22 11:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:41:40 --> Controller Class Initialized
INFO - 2016-11-22 11:41:40 --> Model Class Initialized
INFO - 2016-11-22 11:41:40 --> Model Class Initialized
INFO - 2016-11-22 11:41:40 --> Model Class Initialized
INFO - 2016-11-22 11:41:40 --> Model Class Initialized
INFO - 2016-11-22 11:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:41:40 --> Pagination Class Initialized
INFO - 2016-11-22 11:41:41 --> Helper loaded: app_helper
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:41:41 --> Final output sent to browser
DEBUG - 2016-11-22 11:41:41 --> Total execution time: 0.7961
INFO - 2016-11-22 11:41:46 --> Config Class Initialized
INFO - 2016-11-22 11:41:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:41:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:41:47 --> Utf8 Class Initialized
INFO - 2016-11-22 11:41:47 --> URI Class Initialized
INFO - 2016-11-22 11:41:47 --> Router Class Initialized
INFO - 2016-11-22 11:41:47 --> Output Class Initialized
INFO - 2016-11-22 11:41:47 --> Security Class Initialized
DEBUG - 2016-11-22 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:41:47 --> Input Class Initialized
INFO - 2016-11-22 11:41:47 --> Language Class Initialized
INFO - 2016-11-22 11:41:47 --> Loader Class Initialized
INFO - 2016-11-22 11:41:47 --> Helper loaded: url_helper
INFO - 2016-11-22 11:41:47 --> Helper loaded: form_helper
INFO - 2016-11-22 11:41:47 --> Database Driver Class Initialized
INFO - 2016-11-22 11:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:41:47 --> Controller Class Initialized
INFO - 2016-11-22 11:41:47 --> Model Class Initialized
INFO - 2016-11-22 11:41:47 --> Form Validation Class Initialized
INFO - 2016-11-22 11:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:41:47 --> Pagination Class Initialized
INFO - 2016-11-22 11:41:47 --> Helper loaded: app_helper
INFO - 2016-11-22 11:41:47 --> Email Class Initialized
INFO - 2016-11-22 11:41:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:41:47 --> Final output sent to browser
DEBUG - 2016-11-22 11:41:47 --> Total execution time: 0.4247
INFO - 2016-11-22 11:42:47 --> Config Class Initialized
INFO - 2016-11-22 11:42:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:42:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:42:47 --> Utf8 Class Initialized
INFO - 2016-11-22 11:42:47 --> URI Class Initialized
DEBUG - 2016-11-22 11:42:47 --> No URI present. Default controller set.
INFO - 2016-11-22 11:42:47 --> Router Class Initialized
INFO - 2016-11-22 11:42:47 --> Output Class Initialized
INFO - 2016-11-22 11:42:47 --> Security Class Initialized
DEBUG - 2016-11-22 11:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:42:47 --> Input Class Initialized
INFO - 2016-11-22 11:42:47 --> Language Class Initialized
INFO - 2016-11-22 11:42:47 --> Loader Class Initialized
INFO - 2016-11-22 11:42:47 --> Helper loaded: url_helper
INFO - 2016-11-22 11:42:47 --> Helper loaded: form_helper
INFO - 2016-11-22 11:42:47 --> Database Driver Class Initialized
INFO - 2016-11-22 11:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:42:47 --> Controller Class Initialized
INFO - 2016-11-22 11:42:47 --> Model Class Initialized
INFO - 2016-11-22 11:42:47 --> Model Class Initialized
INFO - 2016-11-22 11:42:47 --> Model Class Initialized
INFO - 2016-11-22 11:42:47 --> Model Class Initialized
INFO - 2016-11-22 11:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:42:47 --> Pagination Class Initialized
INFO - 2016-11-22 11:42:47 --> Helper loaded: app_helper
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:42:47 --> Final output sent to browser
DEBUG - 2016-11-22 11:42:47 --> Total execution time: 0.7333
INFO - 2016-11-22 11:45:04 --> Config Class Initialized
INFO - 2016-11-22 11:45:04 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:04 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:04 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:04 --> URI Class Initialized
DEBUG - 2016-11-22 11:45:04 --> No URI present. Default controller set.
INFO - 2016-11-22 11:45:04 --> Router Class Initialized
INFO - 2016-11-22 11:45:04 --> Output Class Initialized
INFO - 2016-11-22 11:45:04 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:05 --> Input Class Initialized
INFO - 2016-11-22 11:45:05 --> Language Class Initialized
INFO - 2016-11-22 11:45:05 --> Loader Class Initialized
INFO - 2016-11-22 11:45:05 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:05 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:05 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:05 --> Controller Class Initialized
INFO - 2016-11-22 11:45:05 --> Model Class Initialized
INFO - 2016-11-22 11:45:05 --> Model Class Initialized
INFO - 2016-11-22 11:45:05 --> Model Class Initialized
INFO - 2016-11-22 11:45:05 --> Model Class Initialized
INFO - 2016-11-22 11:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:05 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:05 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:45:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:45:05 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:05 --> Total execution time: 0.7159
INFO - 2016-11-22 11:45:09 --> Config Class Initialized
INFO - 2016-11-22 11:45:09 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:09 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:09 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:09 --> URI Class Initialized
INFO - 2016-11-22 11:45:10 --> Router Class Initialized
INFO - 2016-11-22 11:45:10 --> Output Class Initialized
INFO - 2016-11-22 11:45:10 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:10 --> Input Class Initialized
INFO - 2016-11-22 11:45:10 --> Language Class Initialized
INFO - 2016-11-22 11:45:10 --> Loader Class Initialized
INFO - 2016-11-22 11:45:10 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:10 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:10 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:10 --> Controller Class Initialized
INFO - 2016-11-22 11:45:10 --> Model Class Initialized
INFO - 2016-11-22 11:45:10 --> Form Validation Class Initialized
INFO - 2016-11-22 11:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:10 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:10 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:10 --> Email Class Initialized
INFO - 2016-11-22 11:45:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:10 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:10 --> Total execution time: 0.4231
INFO - 2016-11-22 11:45:24 --> Config Class Initialized
INFO - 2016-11-22 11:45:24 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:24 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:24 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:24 --> URI Class Initialized
INFO - 2016-11-22 11:45:24 --> Router Class Initialized
INFO - 2016-11-22 11:45:24 --> Output Class Initialized
INFO - 2016-11-22 11:45:24 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:24 --> Input Class Initialized
INFO - 2016-11-22 11:45:24 --> Language Class Initialized
INFO - 2016-11-22 11:45:24 --> Loader Class Initialized
INFO - 2016-11-22 11:45:24 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:24 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:24 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:24 --> Controller Class Initialized
INFO - 2016-11-22 11:45:24 --> Model Class Initialized
INFO - 2016-11-22 11:45:24 --> Form Validation Class Initialized
INFO - 2016-11-22 11:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:24 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:24 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:24 --> Email Class Initialized
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:25 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-22 11:45:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:25 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:25 --> Total execution time: 1.5376
INFO - 2016-11-22 11:45:25 --> Config Class Initialized
INFO - 2016-11-22 11:45:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:25 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:25 --> URI Class Initialized
DEBUG - 2016-11-22 11:45:25 --> No URI present. Default controller set.
INFO - 2016-11-22 11:45:25 --> Router Class Initialized
INFO - 2016-11-22 11:45:25 --> Output Class Initialized
INFO - 2016-11-22 11:45:25 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:26 --> Input Class Initialized
INFO - 2016-11-22 11:45:26 --> Language Class Initialized
INFO - 2016-11-22 11:45:26 --> Loader Class Initialized
INFO - 2016-11-22 11:45:26 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:26 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:26 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:26 --> Controller Class Initialized
INFO - 2016-11-22 11:45:26 --> Model Class Initialized
INFO - 2016-11-22 11:45:26 --> Model Class Initialized
INFO - 2016-11-22 11:45:26 --> Model Class Initialized
INFO - 2016-11-22 11:45:26 --> Model Class Initialized
INFO - 2016-11-22 11:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:26 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:26 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:45:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:45:26 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:26 --> Total execution time: 0.6726
INFO - 2016-11-22 11:45:32 --> Config Class Initialized
INFO - 2016-11-22 11:45:32 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:32 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:32 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:32 --> URI Class Initialized
INFO - 2016-11-22 11:45:32 --> Router Class Initialized
INFO - 2016-11-22 11:45:32 --> Output Class Initialized
INFO - 2016-11-22 11:45:32 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:32 --> Input Class Initialized
INFO - 2016-11-22 11:45:32 --> Language Class Initialized
INFO - 2016-11-22 11:45:32 --> Loader Class Initialized
INFO - 2016-11-22 11:45:32 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:32 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:32 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:32 --> Controller Class Initialized
INFO - 2016-11-22 11:45:32 --> Model Class Initialized
INFO - 2016-11-22 11:45:32 --> Form Validation Class Initialized
INFO - 2016-11-22 11:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:32 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:32 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:32 --> Email Class Initialized
INFO - 2016-11-22 11:45:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:32 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:32 --> Total execution time: 0.4119
INFO - 2016-11-22 11:45:36 --> Config Class Initialized
INFO - 2016-11-22 11:45:36 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:36 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:36 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:36 --> URI Class Initialized
INFO - 2016-11-22 11:45:36 --> Router Class Initialized
INFO - 2016-11-22 11:45:36 --> Output Class Initialized
INFO - 2016-11-22 11:45:36 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:36 --> Input Class Initialized
INFO - 2016-11-22 11:45:36 --> Language Class Initialized
INFO - 2016-11-22 11:45:36 --> Loader Class Initialized
INFO - 2016-11-22 11:45:36 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:36 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:36 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:36 --> Controller Class Initialized
INFO - 2016-11-22 11:45:36 --> Model Class Initialized
INFO - 2016-11-22 11:45:36 --> Form Validation Class Initialized
INFO - 2016-11-22 11:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:37 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:37 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:37 --> Email Class Initialized
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:37 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-22 11:45:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:37 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:37 --> Total execution time: 1.1926
INFO - 2016-11-22 11:45:37 --> Config Class Initialized
INFO - 2016-11-22 11:45:37 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:37 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:37 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:38 --> URI Class Initialized
DEBUG - 2016-11-22 11:45:38 --> No URI present. Default controller set.
INFO - 2016-11-22 11:45:38 --> Router Class Initialized
INFO - 2016-11-22 11:45:38 --> Output Class Initialized
INFO - 2016-11-22 11:45:38 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:38 --> Input Class Initialized
INFO - 2016-11-22 11:45:38 --> Language Class Initialized
INFO - 2016-11-22 11:45:38 --> Loader Class Initialized
INFO - 2016-11-22 11:45:38 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:38 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:38 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:38 --> Controller Class Initialized
INFO - 2016-11-22 11:45:38 --> Model Class Initialized
INFO - 2016-11-22 11:45:38 --> Model Class Initialized
INFO - 2016-11-22 11:45:38 --> Model Class Initialized
INFO - 2016-11-22 11:45:38 --> Model Class Initialized
INFO - 2016-11-22 11:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:38 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:38 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:45:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:45:38 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:38 --> Total execution time: 0.6826
INFO - 2016-11-22 11:45:42 --> Config Class Initialized
INFO - 2016-11-22 11:45:42 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:42 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:42 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:42 --> URI Class Initialized
INFO - 2016-11-22 11:45:42 --> Router Class Initialized
INFO - 2016-11-22 11:45:42 --> Output Class Initialized
INFO - 2016-11-22 11:45:42 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:42 --> Input Class Initialized
INFO - 2016-11-22 11:45:42 --> Language Class Initialized
INFO - 2016-11-22 11:45:42 --> Loader Class Initialized
INFO - 2016-11-22 11:45:42 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:42 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:42 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:42 --> Controller Class Initialized
INFO - 2016-11-22 11:45:42 --> Model Class Initialized
INFO - 2016-11-22 11:45:42 --> Form Validation Class Initialized
INFO - 2016-11-22 11:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:42 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:42 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:42 --> Email Class Initialized
INFO - 2016-11-22 11:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:42 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:42 --> Total execution time: 0.4162
INFO - 2016-11-22 11:45:47 --> Config Class Initialized
INFO - 2016-11-22 11:45:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:47 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:47 --> URI Class Initialized
INFO - 2016-11-22 11:45:47 --> Router Class Initialized
INFO - 2016-11-22 11:45:47 --> Output Class Initialized
INFO - 2016-11-22 11:45:47 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:47 --> Input Class Initialized
INFO - 2016-11-22 11:45:47 --> Language Class Initialized
INFO - 2016-11-22 11:45:47 --> Loader Class Initialized
INFO - 2016-11-22 11:45:47 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:48 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:48 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:48 --> Controller Class Initialized
INFO - 2016-11-22 11:45:48 --> Model Class Initialized
INFO - 2016-11-22 11:45:48 --> Form Validation Class Initialized
INFO - 2016-11-22 11:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:48 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:48 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:48 --> Email Class Initialized
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:48 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Notice --> Undefined variable: leavestatus C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 29
ERROR - 2016-11-22 11:45:49 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 43
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:49 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:49 --> Total execution time: 1.4433
INFO - 2016-11-22 11:45:49 --> Config Class Initialized
INFO - 2016-11-22 11:45:49 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:45:49 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:45:49 --> Utf8 Class Initialized
INFO - 2016-11-22 11:45:49 --> URI Class Initialized
DEBUG - 2016-11-22 11:45:49 --> No URI present. Default controller set.
INFO - 2016-11-22 11:45:49 --> Router Class Initialized
INFO - 2016-11-22 11:45:49 --> Output Class Initialized
INFO - 2016-11-22 11:45:49 --> Security Class Initialized
DEBUG - 2016-11-22 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:45:49 --> Input Class Initialized
INFO - 2016-11-22 11:45:49 --> Language Class Initialized
INFO - 2016-11-22 11:45:49 --> Loader Class Initialized
INFO - 2016-11-22 11:45:49 --> Helper loaded: url_helper
INFO - 2016-11-22 11:45:49 --> Helper loaded: form_helper
INFO - 2016-11-22 11:45:49 --> Database Driver Class Initialized
INFO - 2016-11-22 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:45:49 --> Controller Class Initialized
INFO - 2016-11-22 11:45:49 --> Model Class Initialized
INFO - 2016-11-22 11:45:49 --> Model Class Initialized
INFO - 2016-11-22 11:45:49 --> Model Class Initialized
INFO - 2016-11-22 11:45:49 --> Model Class Initialized
INFO - 2016-11-22 11:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:45:49 --> Pagination Class Initialized
INFO - 2016-11-22 11:45:49 --> Helper loaded: app_helper
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:45:49 --> Final output sent to browser
DEBUG - 2016-11-22 11:45:50 --> Total execution time: 0.6805
INFO - 2016-11-22 11:46:19 --> Config Class Initialized
INFO - 2016-11-22 11:46:19 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:46:19 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:46:19 --> Utf8 Class Initialized
INFO - 2016-11-22 11:46:19 --> URI Class Initialized
DEBUG - 2016-11-22 11:46:19 --> No URI present. Default controller set.
INFO - 2016-11-22 11:46:19 --> Router Class Initialized
INFO - 2016-11-22 11:46:19 --> Output Class Initialized
INFO - 2016-11-22 11:46:19 --> Security Class Initialized
DEBUG - 2016-11-22 11:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:46:19 --> Input Class Initialized
INFO - 2016-11-22 11:46:19 --> Language Class Initialized
INFO - 2016-11-22 11:46:19 --> Loader Class Initialized
INFO - 2016-11-22 11:46:19 --> Helper loaded: url_helper
INFO - 2016-11-22 11:46:19 --> Helper loaded: form_helper
INFO - 2016-11-22 11:46:19 --> Database Driver Class Initialized
INFO - 2016-11-22 11:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:46:19 --> Controller Class Initialized
INFO - 2016-11-22 11:46:19 --> Model Class Initialized
INFO - 2016-11-22 11:46:19 --> Model Class Initialized
INFO - 2016-11-22 11:46:19 --> Model Class Initialized
INFO - 2016-11-22 11:46:19 --> Model Class Initialized
INFO - 2016-11-22 11:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:46:19 --> Pagination Class Initialized
INFO - 2016-11-22 11:46:19 --> Helper loaded: app_helper
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 11:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 11:46:19 --> Final output sent to browser
DEBUG - 2016-11-22 11:46:19 --> Total execution time: 0.7146
INFO - 2016-11-22 11:46:40 --> Config Class Initialized
INFO - 2016-11-22 11:46:40 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:46:40 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:46:40 --> Utf8 Class Initialized
INFO - 2016-11-22 11:46:40 --> URI Class Initialized
INFO - 2016-11-22 11:46:40 --> Router Class Initialized
INFO - 2016-11-22 11:46:40 --> Output Class Initialized
INFO - 2016-11-22 11:46:40 --> Security Class Initialized
DEBUG - 2016-11-22 11:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:46:40 --> Input Class Initialized
INFO - 2016-11-22 11:46:40 --> Language Class Initialized
INFO - 2016-11-22 11:46:40 --> Loader Class Initialized
INFO - 2016-11-22 11:46:40 --> Helper loaded: url_helper
INFO - 2016-11-22 11:46:40 --> Helper loaded: form_helper
INFO - 2016-11-22 11:46:40 --> Database Driver Class Initialized
INFO - 2016-11-22 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:46:40 --> Controller Class Initialized
INFO - 2016-11-22 11:46:41 --> Model Class Initialized
INFO - 2016-11-22 11:46:41 --> Form Validation Class Initialized
INFO - 2016-11-22 11:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:46:41 --> Pagination Class Initialized
INFO - 2016-11-22 11:46:41 --> Helper loaded: app_helper
INFO - 2016-11-22 11:46:41 --> Email Class Initialized
INFO - 2016-11-22 11:46:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:46:41 --> Final output sent to browser
DEBUG - 2016-11-22 11:46:41 --> Total execution time: 0.5137
INFO - 2016-11-22 11:46:49 --> Config Class Initialized
INFO - 2016-11-22 11:46:49 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:46:49 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:46:49 --> Utf8 Class Initialized
INFO - 2016-11-22 11:46:49 --> URI Class Initialized
INFO - 2016-11-22 11:46:49 --> Router Class Initialized
INFO - 2016-11-22 11:46:49 --> Output Class Initialized
INFO - 2016-11-22 11:46:49 --> Security Class Initialized
DEBUG - 2016-11-22 11:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:46:49 --> Input Class Initialized
INFO - 2016-11-22 11:46:49 --> Language Class Initialized
INFO - 2016-11-22 11:46:49 --> Loader Class Initialized
INFO - 2016-11-22 11:46:49 --> Helper loaded: url_helper
INFO - 2016-11-22 11:46:49 --> Helper loaded: form_helper
INFO - 2016-11-22 11:46:49 --> Database Driver Class Initialized
INFO - 2016-11-22 11:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:46:49 --> Controller Class Initialized
INFO - 2016-11-22 11:46:49 --> Model Class Initialized
INFO - 2016-11-22 11:46:49 --> Form Validation Class Initialized
INFO - 2016-11-22 11:46:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 11:46:49 --> Final output sent to browser
DEBUG - 2016-11-22 11:46:49 --> Total execution time: 0.4501
INFO - 2016-11-22 11:46:55 --> Config Class Initialized
INFO - 2016-11-22 11:46:55 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:46:55 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:46:55 --> Utf8 Class Initialized
INFO - 2016-11-22 11:46:55 --> URI Class Initialized
INFO - 2016-11-22 11:46:55 --> Router Class Initialized
INFO - 2016-11-22 11:46:55 --> Output Class Initialized
INFO - 2016-11-22 11:46:56 --> Security Class Initialized
DEBUG - 2016-11-22 11:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:46:56 --> Input Class Initialized
INFO - 2016-11-22 11:46:56 --> Language Class Initialized
INFO - 2016-11-22 11:46:56 --> Loader Class Initialized
INFO - 2016-11-22 11:46:56 --> Helper loaded: url_helper
INFO - 2016-11-22 11:46:56 --> Helper loaded: form_helper
INFO - 2016-11-22 11:46:56 --> Database Driver Class Initialized
INFO - 2016-11-22 11:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:46:56 --> Controller Class Initialized
INFO - 2016-11-22 11:46:56 --> Model Class Initialized
INFO - 2016-11-22 11:46:56 --> Form Validation Class Initialized
INFO - 2016-11-22 11:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:46:56 --> Pagination Class Initialized
INFO - 2016-11-22 11:46:56 --> Helper loaded: app_helper
INFO - 2016-11-22 11:46:56 --> Email Class Initialized
INFO - 2016-11-22 11:46:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 11:46:56 --> Final output sent to browser
DEBUG - 2016-11-22 11:46:56 --> Total execution time: 0.4641
INFO - 2016-11-22 11:47:11 --> Config Class Initialized
INFO - 2016-11-22 11:47:11 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:47:11 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:47:11 --> Utf8 Class Initialized
INFO - 2016-11-22 11:47:11 --> URI Class Initialized
INFO - 2016-11-22 11:47:11 --> Router Class Initialized
INFO - 2016-11-22 11:47:11 --> Output Class Initialized
INFO - 2016-11-22 11:47:11 --> Security Class Initialized
DEBUG - 2016-11-22 11:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:47:11 --> Input Class Initialized
INFO - 2016-11-22 11:47:11 --> Language Class Initialized
INFO - 2016-11-22 11:47:11 --> Loader Class Initialized
INFO - 2016-11-22 11:47:11 --> Helper loaded: url_helper
INFO - 2016-11-22 11:47:11 --> Helper loaded: form_helper
INFO - 2016-11-22 11:47:11 --> Database Driver Class Initialized
INFO - 2016-11-22 11:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:47:11 --> Controller Class Initialized
INFO - 2016-11-22 11:47:11 --> Model Class Initialized
INFO - 2016-11-22 11:47:11 --> Form Validation Class Initialized
INFO - 2016-11-22 11:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:47:11 --> Pagination Class Initialized
INFO - 2016-11-22 11:47:11 --> Helper loaded: app_helper
INFO - 2016-11-22 11:47:11 --> Email Class Initialized
INFO - 2016-11-22 11:47:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:47:11 --> Final output sent to browser
DEBUG - 2016-11-22 11:47:11 --> Total execution time: 0.4241
INFO - 2016-11-22 11:47:17 --> Config Class Initialized
INFO - 2016-11-22 11:47:17 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:47:17 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:47:17 --> Utf8 Class Initialized
INFO - 2016-11-22 11:47:17 --> URI Class Initialized
INFO - 2016-11-22 11:47:17 --> Router Class Initialized
INFO - 2016-11-22 11:47:17 --> Output Class Initialized
INFO - 2016-11-22 11:47:17 --> Security Class Initialized
DEBUG - 2016-11-22 11:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:47:18 --> Input Class Initialized
INFO - 2016-11-22 11:47:18 --> Language Class Initialized
INFO - 2016-11-22 11:47:18 --> Loader Class Initialized
INFO - 2016-11-22 11:47:18 --> Helper loaded: url_helper
INFO - 2016-11-22 11:47:18 --> Helper loaded: form_helper
INFO - 2016-11-22 11:47:18 --> Database Driver Class Initialized
INFO - 2016-11-22 11:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:47:18 --> Controller Class Initialized
INFO - 2016-11-22 11:47:18 --> Model Class Initialized
INFO - 2016-11-22 11:47:18 --> Form Validation Class Initialized
INFO - 2016-11-22 11:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:47:18 --> Pagination Class Initialized
INFO - 2016-11-22 11:47:18 --> Helper loaded: app_helper
INFO - 2016-11-22 11:47:18 --> Email Class Initialized
INFO - 2016-11-22 11:47:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:47:18 --> Final output sent to browser
DEBUG - 2016-11-22 11:47:18 --> Total execution time: 0.5330
INFO - 2016-11-22 11:47:21 --> Config Class Initialized
INFO - 2016-11-22 11:47:21 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:47:21 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:47:21 --> Utf8 Class Initialized
INFO - 2016-11-22 11:47:22 --> URI Class Initialized
INFO - 2016-11-22 11:47:22 --> Router Class Initialized
INFO - 2016-11-22 11:47:22 --> Output Class Initialized
INFO - 2016-11-22 11:47:22 --> Security Class Initialized
DEBUG - 2016-11-22 11:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:47:22 --> Input Class Initialized
INFO - 2016-11-22 11:47:22 --> Language Class Initialized
INFO - 2016-11-22 11:47:22 --> Loader Class Initialized
INFO - 2016-11-22 11:47:22 --> Helper loaded: url_helper
INFO - 2016-11-22 11:47:22 --> Helper loaded: form_helper
INFO - 2016-11-22 11:47:22 --> Database Driver Class Initialized
INFO - 2016-11-22 11:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:47:22 --> Controller Class Initialized
INFO - 2016-11-22 11:47:22 --> Model Class Initialized
INFO - 2016-11-22 11:47:22 --> Form Validation Class Initialized
INFO - 2016-11-22 11:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:47:22 --> Pagination Class Initialized
INFO - 2016-11-22 11:47:22 --> Helper loaded: app_helper
INFO - 2016-11-22 11:47:22 --> Email Class Initialized
INFO - 2016-11-22 11:47:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:47:22 --> Final output sent to browser
DEBUG - 2016-11-22 11:47:22 --> Total execution time: 0.4255
INFO - 2016-11-22 11:47:26 --> Config Class Initialized
INFO - 2016-11-22 11:47:26 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:47:26 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:47:26 --> Utf8 Class Initialized
INFO - 2016-11-22 11:47:26 --> URI Class Initialized
INFO - 2016-11-22 11:47:26 --> Router Class Initialized
INFO - 2016-11-22 11:47:26 --> Output Class Initialized
INFO - 2016-11-22 11:47:26 --> Security Class Initialized
DEBUG - 2016-11-22 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:47:27 --> Input Class Initialized
INFO - 2016-11-22 11:47:27 --> Language Class Initialized
INFO - 2016-11-22 11:47:27 --> Loader Class Initialized
INFO - 2016-11-22 11:47:27 --> Helper loaded: url_helper
INFO - 2016-11-22 11:47:27 --> Helper loaded: form_helper
INFO - 2016-11-22 11:47:27 --> Database Driver Class Initialized
INFO - 2016-11-22 11:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:47:27 --> Controller Class Initialized
INFO - 2016-11-22 11:47:27 --> Model Class Initialized
INFO - 2016-11-22 11:47:27 --> Form Validation Class Initialized
INFO - 2016-11-22 11:47:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:47:27 --> Pagination Class Initialized
INFO - 2016-11-22 11:47:27 --> Helper loaded: app_helper
INFO - 2016-11-22 11:47:27 --> Email Class Initialized
INFO - 2016-11-22 11:47:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 11:47:27 --> Final output sent to browser
DEBUG - 2016-11-22 11:47:27 --> Total execution time: 0.6797
INFO - 2016-11-22 11:47:39 --> Config Class Initialized
INFO - 2016-11-22 11:47:39 --> Hooks Class Initialized
DEBUG - 2016-11-22 11:47:39 --> UTF-8 Support Enabled
INFO - 2016-11-22 11:47:39 --> Utf8 Class Initialized
INFO - 2016-11-22 11:47:39 --> URI Class Initialized
INFO - 2016-11-22 11:47:39 --> Router Class Initialized
INFO - 2016-11-22 11:47:39 --> Output Class Initialized
INFO - 2016-11-22 11:47:39 --> Security Class Initialized
DEBUG - 2016-11-22 11:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 11:47:39 --> Input Class Initialized
INFO - 2016-11-22 11:47:39 --> Language Class Initialized
INFO - 2016-11-22 11:47:39 --> Loader Class Initialized
INFO - 2016-11-22 11:47:39 --> Helper loaded: url_helper
INFO - 2016-11-22 11:47:39 --> Helper loaded: form_helper
INFO - 2016-11-22 11:47:39 --> Database Driver Class Initialized
INFO - 2016-11-22 11:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 11:47:39 --> Controller Class Initialized
INFO - 2016-11-22 11:47:39 --> Model Class Initialized
INFO - 2016-11-22 11:47:39 --> Form Validation Class Initialized
INFO - 2016-11-22 11:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 11:47:39 --> Pagination Class Initialized
INFO - 2016-11-22 11:47:39 --> Helper loaded: app_helper
INFO - 2016-11-22 11:47:39 --> Email Class Initialized
INFO - 2016-11-22 11:47:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 11:47:40 --> Final output sent to browser
DEBUG - 2016-11-22 11:47:40 --> Total execution time: 0.4232
INFO - 2016-11-22 14:41:05 --> Config Class Initialized
INFO - 2016-11-22 14:41:05 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:41:05 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:41:05 --> Utf8 Class Initialized
INFO - 2016-11-22 14:41:05 --> URI Class Initialized
DEBUG - 2016-11-22 14:41:05 --> No URI present. Default controller set.
INFO - 2016-11-22 14:41:05 --> Router Class Initialized
INFO - 2016-11-22 14:41:05 --> Output Class Initialized
INFO - 2016-11-22 14:41:05 --> Security Class Initialized
DEBUG - 2016-11-22 14:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:41:05 --> Input Class Initialized
INFO - 2016-11-22 14:41:05 --> Language Class Initialized
INFO - 2016-11-22 14:41:05 --> Loader Class Initialized
INFO - 2016-11-22 14:41:05 --> Helper loaded: url_helper
INFO - 2016-11-22 14:41:05 --> Helper loaded: form_helper
INFO - 2016-11-22 14:41:05 --> Database Driver Class Initialized
INFO - 2016-11-22 14:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:41:06 --> Controller Class Initialized
INFO - 2016-11-22 14:41:06 --> Model Class Initialized
INFO - 2016-11-22 14:41:06 --> Model Class Initialized
INFO - 2016-11-22 14:41:06 --> Model Class Initialized
INFO - 2016-11-22 14:41:06 --> Model Class Initialized
INFO - 2016-11-22 14:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:41:06 --> Pagination Class Initialized
INFO - 2016-11-22 14:41:06 --> Helper loaded: app_helper
INFO - 2016-11-22 14:41:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:41:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 14:41:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:41:06 --> Final output sent to browser
DEBUG - 2016-11-22 14:41:06 --> Total execution time: 0.6410
INFO - 2016-11-22 14:41:08 --> Config Class Initialized
INFO - 2016-11-22 14:41:08 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:41:08 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:41:08 --> Utf8 Class Initialized
INFO - 2016-11-22 14:41:08 --> URI Class Initialized
DEBUG - 2016-11-22 14:41:08 --> No URI present. Default controller set.
INFO - 2016-11-22 14:41:08 --> Router Class Initialized
INFO - 2016-11-22 14:41:08 --> Output Class Initialized
INFO - 2016-11-22 14:41:08 --> Security Class Initialized
DEBUG - 2016-11-22 14:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:41:08 --> Input Class Initialized
INFO - 2016-11-22 14:41:08 --> Language Class Initialized
INFO - 2016-11-22 14:41:08 --> Loader Class Initialized
INFO - 2016-11-22 14:41:08 --> Helper loaded: url_helper
INFO - 2016-11-22 14:41:08 --> Helper loaded: form_helper
INFO - 2016-11-22 14:41:08 --> Database Driver Class Initialized
INFO - 2016-11-22 14:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:41:08 --> Controller Class Initialized
INFO - 2016-11-22 14:41:08 --> Model Class Initialized
INFO - 2016-11-22 14:41:09 --> Model Class Initialized
INFO - 2016-11-22 14:41:09 --> Model Class Initialized
INFO - 2016-11-22 14:41:09 --> Model Class Initialized
INFO - 2016-11-22 14:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:41:09 --> Pagination Class Initialized
INFO - 2016-11-22 14:41:09 --> Helper loaded: app_helper
INFO - 2016-11-22 14:41:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:41:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 14:41:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:41:09 --> Final output sent to browser
DEBUG - 2016-11-22 14:41:09 --> Total execution time: 0.6100
INFO - 2016-11-22 14:41:25 --> Config Class Initialized
INFO - 2016-11-22 14:41:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:41:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:41:25 --> Utf8 Class Initialized
INFO - 2016-11-22 14:41:25 --> URI Class Initialized
INFO - 2016-11-22 14:41:25 --> Router Class Initialized
INFO - 2016-11-22 14:41:25 --> Output Class Initialized
INFO - 2016-11-22 14:41:25 --> Security Class Initialized
DEBUG - 2016-11-22 14:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:41:25 --> Input Class Initialized
INFO - 2016-11-22 14:41:25 --> Language Class Initialized
INFO - 2016-11-22 14:41:25 --> Loader Class Initialized
INFO - 2016-11-22 14:41:25 --> Helper loaded: url_helper
INFO - 2016-11-22 14:41:25 --> Helper loaded: form_helper
INFO - 2016-11-22 14:41:25 --> Database Driver Class Initialized
INFO - 2016-11-22 14:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:41:25 --> Controller Class Initialized
INFO - 2016-11-22 14:41:25 --> Model Class Initialized
INFO - 2016-11-22 14:41:25 --> Model Class Initialized
INFO - 2016-11-22 14:41:25 --> Model Class Initialized
INFO - 2016-11-22 14:41:25 --> Model Class Initialized
INFO - 2016-11-22 14:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:41:25 --> Pagination Class Initialized
INFO - 2016-11-22 14:41:25 --> Helper loaded: app_helper
DEBUG - 2016-11-22 14:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-22 14:41:25 --> Model Class Initialized
INFO - 2016-11-22 14:41:25 --> Final output sent to browser
DEBUG - 2016-11-22 14:41:25 --> Total execution time: 0.4623
INFO - 2016-11-22 14:41:25 --> Config Class Initialized
INFO - 2016-11-22 14:41:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:41:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:41:25 --> Utf8 Class Initialized
INFO - 2016-11-22 14:41:25 --> URI Class Initialized
DEBUG - 2016-11-22 14:41:25 --> No URI present. Default controller set.
INFO - 2016-11-22 14:41:25 --> Router Class Initialized
INFO - 2016-11-22 14:41:26 --> Output Class Initialized
INFO - 2016-11-22 14:41:26 --> Security Class Initialized
DEBUG - 2016-11-22 14:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:41:26 --> Input Class Initialized
INFO - 2016-11-22 14:41:26 --> Language Class Initialized
INFO - 2016-11-22 14:41:26 --> Loader Class Initialized
INFO - 2016-11-22 14:41:26 --> Helper loaded: url_helper
INFO - 2016-11-22 14:41:26 --> Helper loaded: form_helper
INFO - 2016-11-22 14:41:26 --> Database Driver Class Initialized
INFO - 2016-11-22 14:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:41:26 --> Controller Class Initialized
INFO - 2016-11-22 14:41:26 --> Model Class Initialized
INFO - 2016-11-22 14:41:26 --> Model Class Initialized
INFO - 2016-11-22 14:41:26 --> Model Class Initialized
INFO - 2016-11-22 14:41:26 --> Model Class Initialized
INFO - 2016-11-22 14:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:41:26 --> Pagination Class Initialized
INFO - 2016-11-22 14:41:26 --> Helper loaded: app_helper
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 14:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:41:26 --> Final output sent to browser
DEBUG - 2016-11-22 14:41:26 --> Total execution time: 0.7022
INFO - 2016-11-22 14:41:28 --> Config Class Initialized
INFO - 2016-11-22 14:41:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:41:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:41:28 --> Utf8 Class Initialized
INFO - 2016-11-22 14:41:28 --> URI Class Initialized
DEBUG - 2016-11-22 14:41:28 --> No URI present. Default controller set.
INFO - 2016-11-22 14:41:28 --> Router Class Initialized
INFO - 2016-11-22 14:41:28 --> Output Class Initialized
INFO - 2016-11-22 14:41:28 --> Security Class Initialized
DEBUG - 2016-11-22 14:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:41:28 --> Input Class Initialized
INFO - 2016-11-22 14:41:28 --> Language Class Initialized
INFO - 2016-11-22 14:41:28 --> Loader Class Initialized
INFO - 2016-11-22 14:41:28 --> Helper loaded: url_helper
INFO - 2016-11-22 14:41:28 --> Helper loaded: form_helper
INFO - 2016-11-22 14:41:28 --> Database Driver Class Initialized
INFO - 2016-11-22 14:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:41:28 --> Controller Class Initialized
INFO - 2016-11-22 14:41:28 --> Model Class Initialized
INFO - 2016-11-22 14:41:28 --> Model Class Initialized
INFO - 2016-11-22 14:41:28 --> Model Class Initialized
INFO - 2016-11-22 14:41:28 --> Model Class Initialized
INFO - 2016-11-22 14:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:41:28 --> Pagination Class Initialized
INFO - 2016-11-22 14:41:28 --> Helper loaded: app_helper
INFO - 2016-11-22 14:41:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 14:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:41:29 --> Final output sent to browser
DEBUG - 2016-11-22 14:41:29 --> Total execution time: 0.7897
INFO - 2016-11-22 14:41:42 --> Config Class Initialized
INFO - 2016-11-22 14:41:42 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:41:42 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:41:42 --> Utf8 Class Initialized
INFO - 2016-11-22 14:41:42 --> URI Class Initialized
INFO - 2016-11-22 14:41:42 --> Router Class Initialized
INFO - 2016-11-22 14:41:42 --> Output Class Initialized
INFO - 2016-11-22 14:41:42 --> Security Class Initialized
DEBUG - 2016-11-22 14:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:41:42 --> Input Class Initialized
INFO - 2016-11-22 14:41:42 --> Language Class Initialized
INFO - 2016-11-22 14:41:42 --> Loader Class Initialized
INFO - 2016-11-22 14:41:42 --> Helper loaded: url_helper
INFO - 2016-11-22 14:41:43 --> Helper loaded: form_helper
INFO - 2016-11-22 14:41:43 --> Database Driver Class Initialized
INFO - 2016-11-22 14:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:41:43 --> Controller Class Initialized
INFO - 2016-11-22 14:41:43 --> Model Class Initialized
INFO - 2016-11-22 14:41:43 --> Form Validation Class Initialized
INFO - 2016-11-22 14:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:41:43 --> Pagination Class Initialized
INFO - 2016-11-22 14:41:43 --> Helper loaded: app_helper
INFO - 2016-11-22 14:41:43 --> Email Class Initialized
INFO - 2016-11-22 14:41:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:41:43 --> Final output sent to browser
DEBUG - 2016-11-22 14:41:43 --> Total execution time: 0.4293
INFO - 2016-11-22 14:42:06 --> Config Class Initialized
INFO - 2016-11-22 14:42:06 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:42:06 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:42:06 --> Utf8 Class Initialized
INFO - 2016-11-22 14:42:06 --> URI Class Initialized
DEBUG - 2016-11-22 14:42:06 --> No URI present. Default controller set.
INFO - 2016-11-22 14:42:06 --> Router Class Initialized
INFO - 2016-11-22 14:42:06 --> Output Class Initialized
INFO - 2016-11-22 14:42:07 --> Security Class Initialized
DEBUG - 2016-11-22 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:42:07 --> Input Class Initialized
INFO - 2016-11-22 14:42:07 --> Language Class Initialized
INFO - 2016-11-22 14:42:07 --> Loader Class Initialized
INFO - 2016-11-22 14:42:07 --> Helper loaded: url_helper
INFO - 2016-11-22 14:42:07 --> Helper loaded: form_helper
INFO - 2016-11-22 14:42:07 --> Database Driver Class Initialized
INFO - 2016-11-22 14:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:42:07 --> Controller Class Initialized
INFO - 2016-11-22 14:42:07 --> Model Class Initialized
INFO - 2016-11-22 14:42:07 --> Model Class Initialized
INFO - 2016-11-22 14:42:07 --> Model Class Initialized
INFO - 2016-11-22 14:42:07 --> Model Class Initialized
INFO - 2016-11-22 14:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:42:07 --> Pagination Class Initialized
INFO - 2016-11-22 14:42:07 --> Helper loaded: app_helper
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 14:42:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:42:07 --> Final output sent to browser
DEBUG - 2016-11-22 14:42:07 --> Total execution time: 0.8024
INFO - 2016-11-22 14:42:19 --> Config Class Initialized
INFO - 2016-11-22 14:42:19 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:42:19 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:42:19 --> Utf8 Class Initialized
INFO - 2016-11-22 14:42:19 --> URI Class Initialized
INFO - 2016-11-22 14:42:19 --> Router Class Initialized
INFO - 2016-11-22 14:42:19 --> Output Class Initialized
INFO - 2016-11-22 14:42:19 --> Security Class Initialized
DEBUG - 2016-11-22 14:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:42:19 --> Input Class Initialized
INFO - 2016-11-22 14:42:19 --> Language Class Initialized
INFO - 2016-11-22 14:42:19 --> Loader Class Initialized
INFO - 2016-11-22 14:42:19 --> Helper loaded: url_helper
INFO - 2016-11-22 14:42:19 --> Helper loaded: form_helper
INFO - 2016-11-22 14:42:19 --> Database Driver Class Initialized
INFO - 2016-11-22 14:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:42:19 --> Controller Class Initialized
INFO - 2016-11-22 14:42:19 --> Model Class Initialized
INFO - 2016-11-22 14:42:19 --> Form Validation Class Initialized
INFO - 2016-11-22 14:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:42:19 --> Pagination Class Initialized
INFO - 2016-11-22 14:42:19 --> Helper loaded: app_helper
INFO - 2016-11-22 14:42:19 --> Email Class Initialized
INFO - 2016-11-22 14:42:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:42:19 --> Final output sent to browser
DEBUG - 2016-11-22 14:42:19 --> Total execution time: 0.4358
INFO - 2016-11-22 14:42:49 --> Config Class Initialized
INFO - 2016-11-22 14:42:49 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:42:49 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:42:49 --> Utf8 Class Initialized
INFO - 2016-11-22 14:42:49 --> URI Class Initialized
DEBUG - 2016-11-22 14:42:49 --> No URI present. Default controller set.
INFO - 2016-11-22 14:42:49 --> Router Class Initialized
INFO - 2016-11-22 14:42:49 --> Output Class Initialized
INFO - 2016-11-22 14:42:49 --> Security Class Initialized
DEBUG - 2016-11-22 14:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:42:49 --> Input Class Initialized
INFO - 2016-11-22 14:42:49 --> Language Class Initialized
INFO - 2016-11-22 14:42:49 --> Loader Class Initialized
INFO - 2016-11-22 14:42:49 --> Helper loaded: url_helper
INFO - 2016-11-22 14:42:49 --> Helper loaded: form_helper
INFO - 2016-11-22 14:42:49 --> Database Driver Class Initialized
INFO - 2016-11-22 14:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:42:49 --> Controller Class Initialized
INFO - 2016-11-22 14:42:49 --> Model Class Initialized
INFO - 2016-11-22 14:42:49 --> Model Class Initialized
INFO - 2016-11-22 14:42:49 --> Model Class Initialized
INFO - 2016-11-22 14:42:49 --> Model Class Initialized
INFO - 2016-11-22 14:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:42:49 --> Pagination Class Initialized
INFO - 2016-11-22 14:42:49 --> Helper loaded: app_helper
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 14:42:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:42:49 --> Final output sent to browser
DEBUG - 2016-11-22 14:42:49 --> Total execution time: 0.7582
INFO - 2016-11-22 14:44:03 --> Config Class Initialized
INFO - 2016-11-22 14:44:03 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:44:03 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:44:03 --> Utf8 Class Initialized
INFO - 2016-11-22 14:44:03 --> URI Class Initialized
DEBUG - 2016-11-22 14:44:03 --> No URI present. Default controller set.
INFO - 2016-11-22 14:44:03 --> Router Class Initialized
INFO - 2016-11-22 14:44:03 --> Output Class Initialized
INFO - 2016-11-22 14:44:03 --> Security Class Initialized
DEBUG - 2016-11-22 14:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:44:03 --> Input Class Initialized
INFO - 2016-11-22 14:44:03 --> Language Class Initialized
INFO - 2016-11-22 14:44:03 --> Loader Class Initialized
INFO - 2016-11-22 14:44:03 --> Helper loaded: url_helper
INFO - 2016-11-22 14:44:03 --> Helper loaded: form_helper
INFO - 2016-11-22 14:44:03 --> Database Driver Class Initialized
INFO - 2016-11-22 14:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:44:03 --> Controller Class Initialized
INFO - 2016-11-22 14:44:03 --> Model Class Initialized
INFO - 2016-11-22 14:44:03 --> Model Class Initialized
INFO - 2016-11-22 14:44:03 --> Model Class Initialized
INFO - 2016-11-22 14:44:03 --> Model Class Initialized
INFO - 2016-11-22 14:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:44:03 --> Pagination Class Initialized
INFO - 2016-11-22 14:44:03 --> Helper loaded: app_helper
INFO - 2016-11-22 14:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 14:44:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 14:44:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:44:04 --> Final output sent to browser
DEBUG - 2016-11-22 14:44:04 --> Total execution time: 1.1011
INFO - 2016-11-22 14:44:26 --> Config Class Initialized
INFO - 2016-11-22 14:44:26 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:44:26 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:44:26 --> Utf8 Class Initialized
INFO - 2016-11-22 14:44:26 --> URI Class Initialized
INFO - 2016-11-22 14:44:26 --> Router Class Initialized
INFO - 2016-11-22 14:44:26 --> Output Class Initialized
INFO - 2016-11-22 14:44:26 --> Security Class Initialized
DEBUG - 2016-11-22 14:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:44:27 --> Input Class Initialized
INFO - 2016-11-22 14:44:27 --> Language Class Initialized
INFO - 2016-11-22 14:44:27 --> Loader Class Initialized
INFO - 2016-11-22 14:44:27 --> Helper loaded: url_helper
INFO - 2016-11-22 14:44:27 --> Helper loaded: form_helper
INFO - 2016-11-22 14:44:27 --> Database Driver Class Initialized
INFO - 2016-11-22 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:44:27 --> Controller Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:44:27 --> Pagination Class Initialized
INFO - 2016-11-22 14:44:27 --> Helper loaded: app_helper
DEBUG - 2016-11-22 14:44:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-22 14:44:27 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-22 14:44:27 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-22 14:44:27 --> Config Class Initialized
INFO - 2016-11-22 14:44:27 --> Hooks Class Initialized
DEBUG - 2016-11-22 14:44:27 --> UTF-8 Support Enabled
INFO - 2016-11-22 14:44:27 --> Utf8 Class Initialized
INFO - 2016-11-22 14:44:27 --> URI Class Initialized
DEBUG - 2016-11-22 14:44:27 --> No URI present. Default controller set.
INFO - 2016-11-22 14:44:27 --> Router Class Initialized
INFO - 2016-11-22 14:44:27 --> Output Class Initialized
INFO - 2016-11-22 14:44:27 --> Security Class Initialized
DEBUG - 2016-11-22 14:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 14:44:27 --> Input Class Initialized
INFO - 2016-11-22 14:44:27 --> Language Class Initialized
INFO - 2016-11-22 14:44:27 --> Loader Class Initialized
INFO - 2016-11-22 14:44:27 --> Helper loaded: url_helper
INFO - 2016-11-22 14:44:27 --> Helper loaded: form_helper
INFO - 2016-11-22 14:44:27 --> Database Driver Class Initialized
INFO - 2016-11-22 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 14:44:27 --> Controller Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Model Class Initialized
INFO - 2016-11-22 14:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 14:44:27 --> Pagination Class Initialized
INFO - 2016-11-22 14:44:27 --> Helper loaded: app_helper
INFO - 2016-11-22 14:44:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 14:44:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 14:44:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 14:44:27 --> Final output sent to browser
DEBUG - 2016-11-22 14:44:27 --> Total execution time: 0.5272
INFO - 2016-11-22 21:15:23 --> Config Class Initialized
INFO - 2016-11-22 21:15:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:23 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:23 --> URI Class Initialized
INFO - 2016-11-22 21:15:23 --> Router Class Initialized
INFO - 2016-11-22 21:15:23 --> Output Class Initialized
INFO - 2016-11-22 21:15:23 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:23 --> Input Class Initialized
INFO - 2016-11-22 21:15:23 --> Language Class Initialized
INFO - 2016-11-22 21:15:23 --> Loader Class Initialized
INFO - 2016-11-22 21:15:23 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:23 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:23 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:23 --> Controller Class Initialized
INFO - 2016-11-22 21:15:23 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:24 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:24 --> Helper loaded: app_helper
DEBUG - 2016-11-22 21:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:24 --> Total execution time: 1.1653
INFO - 2016-11-22 21:15:24 --> Config Class Initialized
INFO - 2016-11-22 21:15:24 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:24 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:24 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:24 --> URI Class Initialized
DEBUG - 2016-11-22 21:15:24 --> No URI present. Default controller set.
INFO - 2016-11-22 21:15:24 --> Router Class Initialized
INFO - 2016-11-22 21:15:24 --> Output Class Initialized
INFO - 2016-11-22 21:15:24 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:24 --> Input Class Initialized
INFO - 2016-11-22 21:15:24 --> Language Class Initialized
INFO - 2016-11-22 21:15:24 --> Loader Class Initialized
INFO - 2016-11-22 21:15:24 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:24 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:24 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:24 --> Controller Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Model Class Initialized
INFO - 2016-11-22 21:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:24 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:24 --> Helper loaded: app_helper
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:15:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:15:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:15:25 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:25 --> Total execution time: 0.7582
INFO - 2016-11-22 21:15:38 --> Config Class Initialized
INFO - 2016-11-22 21:15:38 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:38 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:38 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:38 --> URI Class Initialized
INFO - 2016-11-22 21:15:38 --> Router Class Initialized
INFO - 2016-11-22 21:15:38 --> Output Class Initialized
INFO - 2016-11-22 21:15:38 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:38 --> Input Class Initialized
INFO - 2016-11-22 21:15:38 --> Language Class Initialized
INFO - 2016-11-22 21:15:38 --> Loader Class Initialized
INFO - 2016-11-22 21:15:38 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:38 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:38 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:38 --> Controller Class Initialized
INFO - 2016-11-22 21:15:39 --> Model Class Initialized
INFO - 2016-11-22 21:15:39 --> Form Validation Class Initialized
INFO - 2016-11-22 21:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:39 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:39 --> Helper loaded: app_helper
INFO - 2016-11-22 21:15:39 --> Email Class Initialized
INFO - 2016-11-22 21:15:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:15:39 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:39 --> Total execution time: 0.5568
INFO - 2016-11-22 21:15:41 --> Config Class Initialized
INFO - 2016-11-22 21:15:41 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:41 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:41 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:41 --> URI Class Initialized
INFO - 2016-11-22 21:15:41 --> Router Class Initialized
INFO - 2016-11-22 21:15:41 --> Output Class Initialized
INFO - 2016-11-22 21:15:41 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:41 --> Input Class Initialized
INFO - 2016-11-22 21:15:41 --> Language Class Initialized
INFO - 2016-11-22 21:15:41 --> Loader Class Initialized
INFO - 2016-11-22 21:15:41 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:41 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:41 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:41 --> Controller Class Initialized
INFO - 2016-11-22 21:15:41 --> Model Class Initialized
INFO - 2016-11-22 21:15:41 --> Form Validation Class Initialized
INFO - 2016-11-22 21:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:41 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:41 --> Helper loaded: app_helper
INFO - 2016-11-22 21:15:41 --> Email Class Initialized
INFO - 2016-11-22 21:15:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:15:41 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:41 --> Total execution time: 0.5161
INFO - 2016-11-22 21:15:47 --> Config Class Initialized
INFO - 2016-11-22 21:15:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:47 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:47 --> URI Class Initialized
INFO - 2016-11-22 21:15:47 --> Router Class Initialized
INFO - 2016-11-22 21:15:47 --> Output Class Initialized
INFO - 2016-11-22 21:15:47 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:47 --> Input Class Initialized
INFO - 2016-11-22 21:15:47 --> Language Class Initialized
INFO - 2016-11-22 21:15:47 --> Loader Class Initialized
INFO - 2016-11-22 21:15:47 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:47 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:47 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:47 --> Controller Class Initialized
INFO - 2016-11-22 21:15:47 --> Model Class Initialized
INFO - 2016-11-22 21:15:47 --> Model Class Initialized
INFO - 2016-11-22 21:15:47 --> Model Class Initialized
INFO - 2016-11-22 21:15:47 --> Model Class Initialized
INFO - 2016-11-22 21:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:47 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:47 --> Helper loaded: app_helper
DEBUG - 2016-11-22 21:15:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-22 21:15:47 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-22 21:15:47 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-22 21:15:47 --> Config Class Initialized
INFO - 2016-11-22 21:15:47 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:47 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:47 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:47 --> URI Class Initialized
DEBUG - 2016-11-22 21:15:47 --> No URI present. Default controller set.
INFO - 2016-11-22 21:15:47 --> Router Class Initialized
INFO - 2016-11-22 21:15:47 --> Output Class Initialized
INFO - 2016-11-22 21:15:47 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:48 --> Input Class Initialized
INFO - 2016-11-22 21:15:48 --> Language Class Initialized
INFO - 2016-11-22 21:15:48 --> Loader Class Initialized
INFO - 2016-11-22 21:15:48 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:48 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:48 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:48 --> Controller Class Initialized
INFO - 2016-11-22 21:15:48 --> Model Class Initialized
INFO - 2016-11-22 21:15:48 --> Model Class Initialized
INFO - 2016-11-22 21:15:48 --> Model Class Initialized
INFO - 2016-11-22 21:15:48 --> Model Class Initialized
INFO - 2016-11-22 21:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:48 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:48 --> Helper loaded: app_helper
INFO - 2016-11-22 21:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-22 21:15:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:15:48 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:48 --> Total execution time: 0.5951
INFO - 2016-11-22 21:15:55 --> Config Class Initialized
INFO - 2016-11-22 21:15:55 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:56 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:56 --> URI Class Initialized
INFO - 2016-11-22 21:15:56 --> Router Class Initialized
INFO - 2016-11-22 21:15:56 --> Output Class Initialized
INFO - 2016-11-22 21:15:56 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:56 --> Input Class Initialized
INFO - 2016-11-22 21:15:56 --> Language Class Initialized
INFO - 2016-11-22 21:15:56 --> Loader Class Initialized
INFO - 2016-11-22 21:15:56 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:56 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:56 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:56 --> Controller Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:56 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:56 --> Helper loaded: app_helper
DEBUG - 2016-11-22 21:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:56 --> Total execution time: 0.5415
INFO - 2016-11-22 21:15:56 --> Config Class Initialized
INFO - 2016-11-22 21:15:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:15:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:15:56 --> Utf8 Class Initialized
INFO - 2016-11-22 21:15:56 --> URI Class Initialized
DEBUG - 2016-11-22 21:15:56 --> No URI present. Default controller set.
INFO - 2016-11-22 21:15:56 --> Router Class Initialized
INFO - 2016-11-22 21:15:56 --> Output Class Initialized
INFO - 2016-11-22 21:15:56 --> Security Class Initialized
DEBUG - 2016-11-22 21:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:15:56 --> Input Class Initialized
INFO - 2016-11-22 21:15:56 --> Language Class Initialized
INFO - 2016-11-22 21:15:56 --> Loader Class Initialized
INFO - 2016-11-22 21:15:56 --> Helper loaded: url_helper
INFO - 2016-11-22 21:15:56 --> Helper loaded: form_helper
INFO - 2016-11-22 21:15:56 --> Database Driver Class Initialized
INFO - 2016-11-22 21:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:15:56 --> Controller Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Model Class Initialized
INFO - 2016-11-22 21:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:15:57 --> Pagination Class Initialized
INFO - 2016-11-22 21:15:57 --> Helper loaded: app_helper
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:15:57 --> Final output sent to browser
DEBUG - 2016-11-22 21:15:57 --> Total execution time: 0.7315
INFO - 2016-11-22 21:16:04 --> Config Class Initialized
INFO - 2016-11-22 21:16:04 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:16:04 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:16:04 --> Utf8 Class Initialized
INFO - 2016-11-22 21:16:04 --> URI Class Initialized
INFO - 2016-11-22 21:16:04 --> Router Class Initialized
INFO - 2016-11-22 21:16:04 --> Output Class Initialized
INFO - 2016-11-22 21:16:04 --> Security Class Initialized
DEBUG - 2016-11-22 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:16:04 --> Input Class Initialized
INFO - 2016-11-22 21:16:04 --> Language Class Initialized
INFO - 2016-11-22 21:16:04 --> Loader Class Initialized
INFO - 2016-11-22 21:16:04 --> Helper loaded: url_helper
INFO - 2016-11-22 21:16:04 --> Helper loaded: form_helper
INFO - 2016-11-22 21:16:04 --> Database Driver Class Initialized
INFO - 2016-11-22 21:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:16:04 --> Controller Class Initialized
INFO - 2016-11-22 21:16:04 --> Model Class Initialized
INFO - 2016-11-22 21:16:04 --> Form Validation Class Initialized
INFO - 2016-11-22 21:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:16:04 --> Pagination Class Initialized
INFO - 2016-11-22 21:16:04 --> Helper loaded: app_helper
INFO - 2016-11-22 21:16:04 --> Email Class Initialized
INFO - 2016-11-22 21:16:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:16:05 --> Final output sent to browser
DEBUG - 2016-11-22 21:16:05 --> Total execution time: 0.5367
INFO - 2016-11-22 21:16:42 --> Config Class Initialized
INFO - 2016-11-22 21:16:42 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:16:42 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:16:42 --> Utf8 Class Initialized
INFO - 2016-11-22 21:16:42 --> URI Class Initialized
INFO - 2016-11-22 21:16:42 --> Router Class Initialized
INFO - 2016-11-22 21:16:42 --> Output Class Initialized
INFO - 2016-11-22 21:16:42 --> Security Class Initialized
DEBUG - 2016-11-22 21:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:16:42 --> Input Class Initialized
INFO - 2016-11-22 21:16:42 --> Language Class Initialized
INFO - 2016-11-22 21:16:42 --> Loader Class Initialized
INFO - 2016-11-22 21:16:42 --> Helper loaded: url_helper
INFO - 2016-11-22 21:16:42 --> Helper loaded: form_helper
INFO - 2016-11-22 21:16:42 --> Database Driver Class Initialized
INFO - 2016-11-22 21:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:16:42 --> Controller Class Initialized
INFO - 2016-11-22 21:16:42 --> Model Class Initialized
INFO - 2016-11-22 21:16:42 --> Form Validation Class Initialized
INFO - 2016-11-22 21:16:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:16:42 --> Final output sent to browser
DEBUG - 2016-11-22 21:16:42 --> Total execution time: 0.4082
INFO - 2016-11-22 21:16:51 --> Config Class Initialized
INFO - 2016-11-22 21:16:51 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:16:51 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:16:51 --> Utf8 Class Initialized
INFO - 2016-11-22 21:16:51 --> URI Class Initialized
DEBUG - 2016-11-22 21:16:51 --> No URI present. Default controller set.
INFO - 2016-11-22 21:16:51 --> Router Class Initialized
INFO - 2016-11-22 21:16:51 --> Output Class Initialized
INFO - 2016-11-22 21:16:51 --> Security Class Initialized
DEBUG - 2016-11-22 21:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:16:51 --> Input Class Initialized
INFO - 2016-11-22 21:16:51 --> Language Class Initialized
INFO - 2016-11-22 21:16:51 --> Loader Class Initialized
INFO - 2016-11-22 21:16:51 --> Helper loaded: url_helper
INFO - 2016-11-22 21:16:51 --> Helper loaded: form_helper
INFO - 2016-11-22 21:16:51 --> Database Driver Class Initialized
INFO - 2016-11-22 21:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:16:51 --> Controller Class Initialized
INFO - 2016-11-22 21:16:51 --> Model Class Initialized
INFO - 2016-11-22 21:16:51 --> Model Class Initialized
INFO - 2016-11-22 21:16:51 --> Model Class Initialized
INFO - 2016-11-22 21:16:51 --> Model Class Initialized
INFO - 2016-11-22 21:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:16:51 --> Pagination Class Initialized
INFO - 2016-11-22 21:16:51 --> Helper loaded: app_helper
INFO - 2016-11-22 21:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:16:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:16:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:16:52 --> Final output sent to browser
DEBUG - 2016-11-22 21:16:52 --> Total execution time: 0.8184
INFO - 2016-11-22 21:17:01 --> Config Class Initialized
INFO - 2016-11-22 21:17:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:17:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:17:01 --> Utf8 Class Initialized
INFO - 2016-11-22 21:17:02 --> URI Class Initialized
INFO - 2016-11-22 21:17:02 --> Router Class Initialized
INFO - 2016-11-22 21:17:02 --> Output Class Initialized
INFO - 2016-11-22 21:17:02 --> Security Class Initialized
DEBUG - 2016-11-22 21:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:17:02 --> Input Class Initialized
INFO - 2016-11-22 21:17:02 --> Language Class Initialized
INFO - 2016-11-22 21:17:02 --> Loader Class Initialized
INFO - 2016-11-22 21:17:02 --> Helper loaded: url_helper
INFO - 2016-11-22 21:17:02 --> Helper loaded: form_helper
INFO - 2016-11-22 21:17:02 --> Database Driver Class Initialized
INFO - 2016-11-22 21:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:17:02 --> Controller Class Initialized
INFO - 2016-11-22 21:17:02 --> Model Class Initialized
INFO - 2016-11-22 21:17:02 --> Form Validation Class Initialized
INFO - 2016-11-22 21:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:17:02 --> Pagination Class Initialized
INFO - 2016-11-22 21:17:02 --> Helper loaded: app_helper
INFO - 2016-11-22 21:17:02 --> Email Class Initialized
INFO - 2016-11-22 21:17:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:17:02 --> Final output sent to browser
DEBUG - 2016-11-22 21:17:02 --> Total execution time: 0.5058
INFO - 2016-11-22 21:17:26 --> Config Class Initialized
INFO - 2016-11-22 21:17:26 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:17:26 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:17:26 --> Utf8 Class Initialized
INFO - 2016-11-22 21:17:26 --> URI Class Initialized
INFO - 2016-11-22 21:17:26 --> Router Class Initialized
INFO - 2016-11-22 21:17:26 --> Output Class Initialized
INFO - 2016-11-22 21:17:26 --> Security Class Initialized
DEBUG - 2016-11-22 21:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:17:26 --> Input Class Initialized
INFO - 2016-11-22 21:17:26 --> Language Class Initialized
INFO - 2016-11-22 21:17:26 --> Loader Class Initialized
INFO - 2016-11-22 21:17:26 --> Helper loaded: url_helper
INFO - 2016-11-22 21:17:26 --> Helper loaded: form_helper
INFO - 2016-11-22 21:17:26 --> Database Driver Class Initialized
INFO - 2016-11-22 21:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:17:26 --> Controller Class Initialized
INFO - 2016-11-22 21:17:26 --> Model Class Initialized
INFO - 2016-11-22 21:17:26 --> Form Validation Class Initialized
INFO - 2016-11-22 21:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:17:26 --> Pagination Class Initialized
INFO - 2016-11-22 21:17:26 --> Helper loaded: app_helper
INFO - 2016-11-22 21:17:26 --> Email Class Initialized
INFO - 2016-11-22 21:17:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:17:26 --> Final output sent to browser
DEBUG - 2016-11-22 21:17:26 --> Total execution time: 0.5144
INFO - 2016-11-22 21:31:37 --> Config Class Initialized
INFO - 2016-11-22 21:31:37 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:31:38 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:31:38 --> Utf8 Class Initialized
INFO - 2016-11-22 21:31:38 --> URI Class Initialized
DEBUG - 2016-11-22 21:31:38 --> No URI present. Default controller set.
INFO - 2016-11-22 21:31:38 --> Router Class Initialized
INFO - 2016-11-22 21:31:38 --> Output Class Initialized
INFO - 2016-11-22 21:31:38 --> Security Class Initialized
DEBUG - 2016-11-22 21:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:31:38 --> Input Class Initialized
INFO - 2016-11-22 21:31:38 --> Language Class Initialized
INFO - 2016-11-22 21:31:38 --> Loader Class Initialized
INFO - 2016-11-22 21:31:38 --> Helper loaded: url_helper
INFO - 2016-11-22 21:31:38 --> Helper loaded: form_helper
INFO - 2016-11-22 21:31:38 --> Database Driver Class Initialized
INFO - 2016-11-22 21:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:31:38 --> Controller Class Initialized
INFO - 2016-11-22 21:31:39 --> Model Class Initialized
INFO - 2016-11-22 21:31:39 --> Model Class Initialized
INFO - 2016-11-22 21:31:39 --> Model Class Initialized
INFO - 2016-11-22 21:31:39 --> Model Class Initialized
INFO - 2016-11-22 21:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:31:39 --> Pagination Class Initialized
INFO - 2016-11-22 21:31:39 --> Helper loaded: app_helper
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:31:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:31:39 --> Final output sent to browser
DEBUG - 2016-11-22 21:31:39 --> Total execution time: 2.0600
INFO - 2016-11-22 21:32:02 --> Config Class Initialized
INFO - 2016-11-22 21:32:02 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:32:02 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:32:02 --> Utf8 Class Initialized
INFO - 2016-11-22 21:32:02 --> URI Class Initialized
INFO - 2016-11-22 21:32:02 --> Router Class Initialized
INFO - 2016-11-22 21:32:02 --> Output Class Initialized
INFO - 2016-11-22 21:32:02 --> Security Class Initialized
DEBUG - 2016-11-22 21:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:32:02 --> Input Class Initialized
INFO - 2016-11-22 21:32:02 --> Language Class Initialized
INFO - 2016-11-22 21:32:02 --> Loader Class Initialized
INFO - 2016-11-22 21:32:03 --> Helper loaded: url_helper
INFO - 2016-11-22 21:32:03 --> Helper loaded: form_helper
INFO - 2016-11-22 21:32:03 --> Database Driver Class Initialized
INFO - 2016-11-22 21:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:32:03 --> Controller Class Initialized
INFO - 2016-11-22 21:32:03 --> Model Class Initialized
INFO - 2016-11-22 21:32:03 --> Form Validation Class Initialized
INFO - 2016-11-22 21:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:32:03 --> Pagination Class Initialized
INFO - 2016-11-22 21:32:03 --> Helper loaded: app_helper
INFO - 2016-11-22 21:32:03 --> Email Class Initialized
INFO - 2016-11-22 21:32:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 20:32:03 --> Query error: Table 'lms.employeee' doesn't exist - Invalid query: SELECT `em`.`email`, `lt`.`typeName`
FROM `employeee` `em`
LEFT JOIN `applicationData` as `ad` ON `em`.`id` = `ad`.`idEmployee`
LEFT JOIN `leavetype` as `lt` ON `lt`.`id` = `ad`.`idLeaveType`
WHERE `em`.`idRole` IN(4, 5)
AND `ad`.`bDeleted` =0
INFO - 2016-11-22 20:32:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-22 21:32:26 --> Config Class Initialized
INFO - 2016-11-22 21:32:26 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:32:26 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:32:26 --> Utf8 Class Initialized
INFO - 2016-11-22 21:32:26 --> URI Class Initialized
INFO - 2016-11-22 21:32:26 --> Router Class Initialized
INFO - 2016-11-22 21:32:26 --> Output Class Initialized
INFO - 2016-11-22 21:32:26 --> Security Class Initialized
DEBUG - 2016-11-22 21:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:32:26 --> Input Class Initialized
INFO - 2016-11-22 21:32:26 --> Language Class Initialized
INFO - 2016-11-22 21:32:26 --> Loader Class Initialized
INFO - 2016-11-22 21:32:26 --> Helper loaded: url_helper
INFO - 2016-11-22 21:32:26 --> Helper loaded: form_helper
INFO - 2016-11-22 21:32:26 --> Database Driver Class Initialized
INFO - 2016-11-22 21:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:32:26 --> Controller Class Initialized
INFO - 2016-11-22 21:32:26 --> Model Class Initialized
INFO - 2016-11-22 21:32:26 --> Form Validation Class Initialized
INFO - 2016-11-22 21:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:32:26 --> Pagination Class Initialized
INFO - 2016-11-22 21:32:26 --> Helper loaded: app_helper
INFO - 2016-11-22 21:32:26 --> Email Class Initialized
INFO - 2016-11-22 21:32:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:32:56 --> Config Class Initialized
INFO - 2016-11-22 21:32:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:32:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:32:56 --> Utf8 Class Initialized
INFO - 2016-11-22 21:32:56 --> URI Class Initialized
INFO - 2016-11-22 21:32:56 --> Router Class Initialized
INFO - 2016-11-22 21:32:56 --> Output Class Initialized
INFO - 2016-11-22 21:32:56 --> Security Class Initialized
DEBUG - 2016-11-22 21:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:32:56 --> Input Class Initialized
INFO - 2016-11-22 21:32:56 --> Language Class Initialized
INFO - 2016-11-22 21:32:56 --> Loader Class Initialized
INFO - 2016-11-22 21:32:56 --> Helper loaded: url_helper
INFO - 2016-11-22 21:32:56 --> Helper loaded: form_helper
INFO - 2016-11-22 21:32:56 --> Database Driver Class Initialized
INFO - 2016-11-22 21:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:32:56 --> Controller Class Initialized
INFO - 2016-11-22 21:32:56 --> Model Class Initialized
INFO - 2016-11-22 21:32:56 --> Form Validation Class Initialized
INFO - 2016-11-22 21:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:32:56 --> Pagination Class Initialized
INFO - 2016-11-22 21:32:56 --> Helper loaded: app_helper
INFO - 2016-11-22 21:32:56 --> Email Class Initialized
INFO - 2016-11-22 21:32:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:33:36 --> Config Class Initialized
INFO - 2016-11-22 21:33:36 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:33:36 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:33:36 --> Utf8 Class Initialized
INFO - 2016-11-22 21:33:36 --> URI Class Initialized
DEBUG - 2016-11-22 21:33:36 --> No URI present. Default controller set.
INFO - 2016-11-22 21:33:36 --> Router Class Initialized
INFO - 2016-11-22 21:33:36 --> Output Class Initialized
INFO - 2016-11-22 21:33:36 --> Security Class Initialized
DEBUG - 2016-11-22 21:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:33:36 --> Input Class Initialized
INFO - 2016-11-22 21:33:36 --> Language Class Initialized
INFO - 2016-11-22 21:33:36 --> Loader Class Initialized
INFO - 2016-11-22 21:33:36 --> Helper loaded: url_helper
INFO - 2016-11-22 21:33:36 --> Helper loaded: form_helper
INFO - 2016-11-22 21:33:36 --> Database Driver Class Initialized
INFO - 2016-11-22 21:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:33:36 --> Controller Class Initialized
INFO - 2016-11-22 21:33:36 --> Model Class Initialized
INFO - 2016-11-22 21:33:36 --> Model Class Initialized
INFO - 2016-11-22 21:33:36 --> Model Class Initialized
INFO - 2016-11-22 21:33:36 --> Model Class Initialized
INFO - 2016-11-22 21:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:33:36 --> Pagination Class Initialized
INFO - 2016-11-22 21:33:36 --> Helper loaded: app_helper
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:33:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:33:37 --> Final output sent to browser
DEBUG - 2016-11-22 21:33:37 --> Total execution time: 0.8294
INFO - 2016-11-22 21:34:41 --> Config Class Initialized
INFO - 2016-11-22 21:34:41 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:34:41 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:34:41 --> Utf8 Class Initialized
INFO - 2016-11-22 21:34:41 --> URI Class Initialized
INFO - 2016-11-22 21:34:41 --> Router Class Initialized
INFO - 2016-11-22 21:34:41 --> Output Class Initialized
INFO - 2016-11-22 21:34:41 --> Security Class Initialized
DEBUG - 2016-11-22 21:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:34:41 --> Input Class Initialized
INFO - 2016-11-22 21:34:41 --> Language Class Initialized
INFO - 2016-11-22 21:34:41 --> Loader Class Initialized
INFO - 2016-11-22 21:34:41 --> Helper loaded: url_helper
INFO - 2016-11-22 21:34:41 --> Helper loaded: form_helper
INFO - 2016-11-22 21:34:42 --> Database Driver Class Initialized
INFO - 2016-11-22 21:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:34:42 --> Controller Class Initialized
INFO - 2016-11-22 21:34:42 --> Model Class Initialized
INFO - 2016-11-22 21:34:42 --> Form Validation Class Initialized
INFO - 2016-11-22 21:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:34:42 --> Pagination Class Initialized
INFO - 2016-11-22 21:34:42 --> Helper loaded: app_helper
INFO - 2016-11-22 21:34:42 --> Email Class Initialized
INFO - 2016-11-22 21:34:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:36:04 --> Config Class Initialized
INFO - 2016-11-22 21:36:04 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:36:04 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:36:04 --> Utf8 Class Initialized
INFO - 2016-11-22 21:36:04 --> URI Class Initialized
INFO - 2016-11-22 21:36:04 --> Router Class Initialized
INFO - 2016-11-22 21:36:04 --> Output Class Initialized
INFO - 2016-11-22 21:36:04 --> Security Class Initialized
DEBUG - 2016-11-22 21:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:36:04 --> Input Class Initialized
INFO - 2016-11-22 21:36:04 --> Language Class Initialized
INFO - 2016-11-22 21:36:04 --> Loader Class Initialized
INFO - 2016-11-22 21:36:04 --> Helper loaded: url_helper
INFO - 2016-11-22 21:36:05 --> Helper loaded: form_helper
INFO - 2016-11-22 21:36:05 --> Database Driver Class Initialized
INFO - 2016-11-22 21:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:36:05 --> Controller Class Initialized
INFO - 2016-11-22 21:36:05 --> Model Class Initialized
INFO - 2016-11-22 21:36:05 --> Form Validation Class Initialized
INFO - 2016-11-22 21:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:36:05 --> Pagination Class Initialized
INFO - 2016-11-22 21:36:05 --> Helper loaded: app_helper
INFO - 2016-11-22 21:36:05 --> Email Class Initialized
INFO - 2016-11-22 21:36:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:42:16 --> Config Class Initialized
INFO - 2016-11-22 21:42:16 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:42:16 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:42:16 --> Utf8 Class Initialized
INFO - 2016-11-22 21:42:16 --> URI Class Initialized
INFO - 2016-11-22 21:42:16 --> Router Class Initialized
INFO - 2016-11-22 21:42:16 --> Output Class Initialized
INFO - 2016-11-22 21:42:16 --> Security Class Initialized
DEBUG - 2016-11-22 21:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:42:16 --> Input Class Initialized
INFO - 2016-11-22 21:42:16 --> Language Class Initialized
INFO - 2016-11-22 21:42:16 --> Loader Class Initialized
INFO - 2016-11-22 21:42:16 --> Helper loaded: url_helper
INFO - 2016-11-22 21:42:16 --> Helper loaded: form_helper
INFO - 2016-11-22 21:42:16 --> Database Driver Class Initialized
INFO - 2016-11-22 21:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:42:16 --> Controller Class Initialized
INFO - 2016-11-22 21:42:16 --> Model Class Initialized
INFO - 2016-11-22 21:42:16 --> Form Validation Class Initialized
INFO - 2016-11-22 21:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:42:17 --> Pagination Class Initialized
INFO - 2016-11-22 21:42:17 --> Helper loaded: app_helper
INFO - 2016-11-22 21:42:17 --> Email Class Initialized
INFO - 2016-11-22 21:42:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:42:27 --> Config Class Initialized
INFO - 2016-11-22 21:42:27 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:42:27 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:42:27 --> Utf8 Class Initialized
INFO - 2016-11-22 21:42:27 --> URI Class Initialized
DEBUG - 2016-11-22 21:42:27 --> No URI present. Default controller set.
INFO - 2016-11-22 21:42:27 --> Router Class Initialized
INFO - 2016-11-22 21:42:27 --> Output Class Initialized
INFO - 2016-11-22 21:42:27 --> Security Class Initialized
DEBUG - 2016-11-22 21:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:42:27 --> Input Class Initialized
INFO - 2016-11-22 21:42:27 --> Language Class Initialized
INFO - 2016-11-22 21:42:27 --> Loader Class Initialized
INFO - 2016-11-22 21:42:28 --> Helper loaded: url_helper
INFO - 2016-11-22 21:42:28 --> Helper loaded: form_helper
INFO - 2016-11-22 21:42:28 --> Database Driver Class Initialized
INFO - 2016-11-22 21:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:42:28 --> Controller Class Initialized
INFO - 2016-11-22 21:42:28 --> Model Class Initialized
INFO - 2016-11-22 21:42:28 --> Model Class Initialized
INFO - 2016-11-22 21:42:28 --> Model Class Initialized
INFO - 2016-11-22 21:42:28 --> Model Class Initialized
INFO - 2016-11-22 21:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:42:28 --> Pagination Class Initialized
INFO - 2016-11-22 21:42:28 --> Helper loaded: app_helper
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:42:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:42:28 --> Final output sent to browser
DEBUG - 2016-11-22 21:42:28 --> Total execution time: 0.8780
INFO - 2016-11-22 21:43:01 --> Config Class Initialized
INFO - 2016-11-22 21:43:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:43:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:43:01 --> Utf8 Class Initialized
INFO - 2016-11-22 21:43:01 --> URI Class Initialized
INFO - 2016-11-22 21:43:01 --> Router Class Initialized
INFO - 2016-11-22 21:43:01 --> Output Class Initialized
INFO - 2016-11-22 21:43:01 --> Security Class Initialized
DEBUG - 2016-11-22 21:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:43:01 --> Input Class Initialized
INFO - 2016-11-22 21:43:02 --> Language Class Initialized
INFO - 2016-11-22 21:43:02 --> Loader Class Initialized
INFO - 2016-11-22 21:43:02 --> Helper loaded: url_helper
INFO - 2016-11-22 21:43:02 --> Helper loaded: form_helper
INFO - 2016-11-22 21:43:02 --> Database Driver Class Initialized
INFO - 2016-11-22 21:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:43:02 --> Controller Class Initialized
INFO - 2016-11-22 21:43:02 --> Model Class Initialized
INFO - 2016-11-22 21:43:02 --> Form Validation Class Initialized
INFO - 2016-11-22 21:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:43:02 --> Pagination Class Initialized
INFO - 2016-11-22 21:43:02 --> Helper loaded: app_helper
INFO - 2016-11-22 21:43:02 --> Email Class Initialized
INFO - 2016-11-22 21:43:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:43:51 --> Config Class Initialized
INFO - 2016-11-22 21:43:51 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:43:51 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:43:51 --> Utf8 Class Initialized
INFO - 2016-11-22 21:43:51 --> URI Class Initialized
DEBUG - 2016-11-22 21:43:51 --> No URI present. Default controller set.
INFO - 2016-11-22 21:43:51 --> Router Class Initialized
INFO - 2016-11-22 21:43:52 --> Output Class Initialized
INFO - 2016-11-22 21:43:52 --> Security Class Initialized
DEBUG - 2016-11-22 21:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:43:52 --> Input Class Initialized
INFO - 2016-11-22 21:43:52 --> Language Class Initialized
INFO - 2016-11-22 21:43:52 --> Loader Class Initialized
INFO - 2016-11-22 21:43:52 --> Helper loaded: url_helper
INFO - 2016-11-22 21:43:52 --> Helper loaded: form_helper
INFO - 2016-11-22 21:43:52 --> Database Driver Class Initialized
INFO - 2016-11-22 21:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:43:52 --> Controller Class Initialized
INFO - 2016-11-22 21:43:52 --> Model Class Initialized
INFO - 2016-11-22 21:43:52 --> Model Class Initialized
INFO - 2016-11-22 21:43:52 --> Model Class Initialized
INFO - 2016-11-22 21:43:52 --> Model Class Initialized
INFO - 2016-11-22 21:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:43:52 --> Pagination Class Initialized
INFO - 2016-11-22 21:43:52 --> Helper loaded: app_helper
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:43:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:43:52 --> Final output sent to browser
DEBUG - 2016-11-22 21:43:52 --> Total execution time: 0.8769
INFO - 2016-11-22 21:44:14 --> Config Class Initialized
INFO - 2016-11-22 21:44:14 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:44:14 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:44:14 --> Utf8 Class Initialized
INFO - 2016-11-22 21:44:14 --> URI Class Initialized
INFO - 2016-11-22 21:44:14 --> Router Class Initialized
INFO - 2016-11-22 21:44:14 --> Output Class Initialized
INFO - 2016-11-22 21:44:14 --> Security Class Initialized
DEBUG - 2016-11-22 21:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:44:14 --> Input Class Initialized
INFO - 2016-11-22 21:44:14 --> Language Class Initialized
INFO - 2016-11-22 21:44:14 --> Loader Class Initialized
INFO - 2016-11-22 21:44:14 --> Helper loaded: url_helper
INFO - 2016-11-22 21:44:14 --> Helper loaded: form_helper
INFO - 2016-11-22 21:44:14 --> Database Driver Class Initialized
INFO - 2016-11-22 21:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:44:14 --> Controller Class Initialized
INFO - 2016-11-22 21:44:14 --> Model Class Initialized
INFO - 2016-11-22 21:44:14 --> Form Validation Class Initialized
INFO - 2016-11-22 21:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:44:14 --> Pagination Class Initialized
INFO - 2016-11-22 21:44:14 --> Helper loaded: app_helper
INFO - 2016-11-22 21:44:14 --> Email Class Initialized
INFO - 2016-11-22 21:44:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:46:01 --> Config Class Initialized
INFO - 2016-11-22 21:46:01 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:46:01 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:46:01 --> Utf8 Class Initialized
INFO - 2016-11-22 21:46:01 --> URI Class Initialized
INFO - 2016-11-22 21:46:01 --> Router Class Initialized
INFO - 2016-11-22 21:46:01 --> Output Class Initialized
INFO - 2016-11-22 21:46:01 --> Security Class Initialized
DEBUG - 2016-11-22 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:46:01 --> Input Class Initialized
INFO - 2016-11-22 21:46:01 --> Language Class Initialized
INFO - 2016-11-22 21:46:01 --> Loader Class Initialized
INFO - 2016-11-22 21:46:01 --> Helper loaded: url_helper
INFO - 2016-11-22 21:46:01 --> Helper loaded: form_helper
INFO - 2016-11-22 21:46:01 --> Database Driver Class Initialized
INFO - 2016-11-22 21:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:46:01 --> Controller Class Initialized
INFO - 2016-11-22 21:46:01 --> Model Class Initialized
INFO - 2016-11-22 21:46:01 --> Form Validation Class Initialized
INFO - 2016-11-22 21:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:46:01 --> Pagination Class Initialized
INFO - 2016-11-22 21:46:01 --> Helper loaded: app_helper
INFO - 2016-11-22 21:46:01 --> Email Class Initialized
INFO - 2016-11-22 21:46:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 20:46:01 --> Query error: Unknown column 'lt.typeName' in 'field list' - Invalid query: SELECT `em`.`email`, `lt`.`typeName`
FROM `employee` `em`
LEFT JOIN `applicationData` as `ad` ON `em`.`id` = `ad`.`idEmployee`
WHERE `em`.`idRole` IN(4, 5)
AND `ad`.`bDeleted` =0
INFO - 2016-11-22 20:46:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-22 21:46:15 --> Config Class Initialized
INFO - 2016-11-22 21:46:15 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:46:15 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:46:15 --> Utf8 Class Initialized
INFO - 2016-11-22 21:46:16 --> URI Class Initialized
INFO - 2016-11-22 21:46:16 --> Router Class Initialized
INFO - 2016-11-22 21:46:16 --> Output Class Initialized
INFO - 2016-11-22 21:46:16 --> Security Class Initialized
DEBUG - 2016-11-22 21:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:46:16 --> Input Class Initialized
INFO - 2016-11-22 21:46:16 --> Language Class Initialized
INFO - 2016-11-22 21:46:16 --> Loader Class Initialized
INFO - 2016-11-22 21:46:16 --> Helper loaded: url_helper
INFO - 2016-11-22 21:46:16 --> Helper loaded: form_helper
INFO - 2016-11-22 21:46:16 --> Database Driver Class Initialized
INFO - 2016-11-22 21:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:46:16 --> Controller Class Initialized
INFO - 2016-11-22 21:46:16 --> Model Class Initialized
INFO - 2016-11-22 21:46:16 --> Form Validation Class Initialized
INFO - 2016-11-22 21:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:46:16 --> Pagination Class Initialized
INFO - 2016-11-22 21:46:16 --> Helper loaded: app_helper
INFO - 2016-11-22 21:46:16 --> Email Class Initialized
INFO - 2016-11-22 21:46:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:46:22 --> Config Class Initialized
INFO - 2016-11-22 21:46:22 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:46:22 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:46:22 --> Utf8 Class Initialized
INFO - 2016-11-22 21:46:22 --> URI Class Initialized
DEBUG - 2016-11-22 21:46:22 --> No URI present. Default controller set.
INFO - 2016-11-22 21:46:22 --> Router Class Initialized
INFO - 2016-11-22 21:46:22 --> Output Class Initialized
INFO - 2016-11-22 21:46:22 --> Security Class Initialized
DEBUG - 2016-11-22 21:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:46:22 --> Input Class Initialized
INFO - 2016-11-22 21:46:22 --> Language Class Initialized
INFO - 2016-11-22 21:46:22 --> Loader Class Initialized
INFO - 2016-11-22 21:46:22 --> Helper loaded: url_helper
INFO - 2016-11-22 21:46:22 --> Helper loaded: form_helper
INFO - 2016-11-22 21:46:22 --> Database Driver Class Initialized
INFO - 2016-11-22 21:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:46:22 --> Controller Class Initialized
INFO - 2016-11-22 21:46:22 --> Model Class Initialized
INFO - 2016-11-22 21:46:22 --> Model Class Initialized
INFO - 2016-11-22 21:46:22 --> Model Class Initialized
INFO - 2016-11-22 21:46:22 --> Model Class Initialized
INFO - 2016-11-22 21:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:46:23 --> Pagination Class Initialized
INFO - 2016-11-22 21:46:23 --> Helper loaded: app_helper
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 21:46:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 21:46:23 --> Final output sent to browser
DEBUG - 2016-11-22 21:46:23 --> Total execution time: 0.9235
INFO - 2016-11-22 21:46:48 --> Config Class Initialized
INFO - 2016-11-22 21:46:48 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:46:48 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:46:48 --> Utf8 Class Initialized
INFO - 2016-11-22 21:46:48 --> URI Class Initialized
INFO - 2016-11-22 21:46:48 --> Router Class Initialized
INFO - 2016-11-22 21:46:48 --> Output Class Initialized
INFO - 2016-11-22 21:46:48 --> Security Class Initialized
DEBUG - 2016-11-22 21:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:46:48 --> Input Class Initialized
INFO - 2016-11-22 21:46:49 --> Language Class Initialized
INFO - 2016-11-22 21:46:49 --> Loader Class Initialized
INFO - 2016-11-22 21:46:49 --> Helper loaded: url_helper
INFO - 2016-11-22 21:46:49 --> Helper loaded: form_helper
INFO - 2016-11-22 21:46:49 --> Database Driver Class Initialized
INFO - 2016-11-22 21:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:46:49 --> Controller Class Initialized
INFO - 2016-11-22 21:46:49 --> Model Class Initialized
INFO - 2016-11-22 21:46:49 --> Form Validation Class Initialized
INFO - 2016-11-22 21:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:46:49 --> Pagination Class Initialized
INFO - 2016-11-22 21:46:49 --> Helper loaded: app_helper
INFO - 2016-11-22 21:46:49 --> Email Class Initialized
INFO - 2016-11-22 21:46:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:52:32 --> Config Class Initialized
INFO - 2016-11-22 21:52:32 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:52:32 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:52:32 --> Utf8 Class Initialized
INFO - 2016-11-22 21:52:32 --> URI Class Initialized
INFO - 2016-11-22 21:52:33 --> Router Class Initialized
INFO - 2016-11-22 21:52:33 --> Output Class Initialized
INFO - 2016-11-22 21:52:33 --> Security Class Initialized
DEBUG - 2016-11-22 21:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:52:33 --> Input Class Initialized
INFO - 2016-11-22 21:52:33 --> Language Class Initialized
INFO - 2016-11-22 21:52:33 --> Loader Class Initialized
INFO - 2016-11-22 21:52:33 --> Helper loaded: url_helper
INFO - 2016-11-22 21:52:33 --> Helper loaded: form_helper
INFO - 2016-11-22 21:52:33 --> Database Driver Class Initialized
INFO - 2016-11-22 21:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:52:33 --> Controller Class Initialized
INFO - 2016-11-22 21:52:33 --> Model Class Initialized
INFO - 2016-11-22 21:52:33 --> Form Validation Class Initialized
INFO - 2016-11-22 21:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:52:33 --> Pagination Class Initialized
INFO - 2016-11-22 21:52:33 --> Helper loaded: app_helper
INFO - 2016-11-22 21:52:33 --> Email Class Initialized
INFO - 2016-11-22 21:52:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:52:56 --> Config Class Initialized
INFO - 2016-11-22 21:52:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:52:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:52:56 --> Utf8 Class Initialized
INFO - 2016-11-22 21:52:56 --> URI Class Initialized
INFO - 2016-11-22 21:52:56 --> Router Class Initialized
INFO - 2016-11-22 21:52:56 --> Output Class Initialized
INFO - 2016-11-22 21:52:56 --> Security Class Initialized
DEBUG - 2016-11-22 21:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:52:56 --> Input Class Initialized
INFO - 2016-11-22 21:52:56 --> Language Class Initialized
INFO - 2016-11-22 21:52:56 --> Loader Class Initialized
INFO - 2016-11-22 21:52:56 --> Helper loaded: url_helper
INFO - 2016-11-22 21:52:56 --> Helper loaded: form_helper
INFO - 2016-11-22 21:52:56 --> Database Driver Class Initialized
INFO - 2016-11-22 21:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:52:56 --> Controller Class Initialized
INFO - 2016-11-22 21:52:56 --> Model Class Initialized
INFO - 2016-11-22 21:52:56 --> Form Validation Class Initialized
INFO - 2016-11-22 21:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:52:56 --> Pagination Class Initialized
INFO - 2016-11-22 21:52:56 --> Helper loaded: app_helper
INFO - 2016-11-22 21:52:56 --> Email Class Initialized
INFO - 2016-11-22 21:52:56 --> Config Class Initialized
INFO - 2016-11-22 21:52:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:52:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:52:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:52:56 --> Utf8 Class Initialized
INFO - 2016-11-22 21:52:57 --> URI Class Initialized
INFO - 2016-11-22 21:52:57 --> Router Class Initialized
INFO - 2016-11-22 21:52:57 --> Output Class Initialized
INFO - 2016-11-22 21:52:57 --> Security Class Initialized
DEBUG - 2016-11-22 21:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:52:57 --> Input Class Initialized
INFO - 2016-11-22 21:52:57 --> Language Class Initialized
INFO - 2016-11-22 21:52:57 --> Loader Class Initialized
INFO - 2016-11-22 21:52:57 --> Helper loaded: url_helper
INFO - 2016-11-22 21:52:57 --> Helper loaded: form_helper
INFO - 2016-11-22 21:52:57 --> Database Driver Class Initialized
INFO - 2016-11-22 21:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:52:57 --> Controller Class Initialized
INFO - 2016-11-22 21:52:57 --> Model Class Initialized
INFO - 2016-11-22 21:52:57 --> Form Validation Class Initialized
INFO - 2016-11-22 21:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:52:57 --> Pagination Class Initialized
INFO - 2016-11-22 21:52:57 --> Helper loaded: app_helper
INFO - 2016-11-22 21:52:57 --> Email Class Initialized
INFO - 2016-11-22 21:52:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:54:54 --> Config Class Initialized
INFO - 2016-11-22 21:54:54 --> Hooks Class Initialized
DEBUG - 2016-11-22 21:54:54 --> UTF-8 Support Enabled
INFO - 2016-11-22 21:54:54 --> Utf8 Class Initialized
INFO - 2016-11-22 21:54:54 --> URI Class Initialized
INFO - 2016-11-22 21:54:54 --> Router Class Initialized
INFO - 2016-11-22 21:54:54 --> Output Class Initialized
INFO - 2016-11-22 21:54:54 --> Security Class Initialized
DEBUG - 2016-11-22 21:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 21:54:54 --> Input Class Initialized
INFO - 2016-11-22 21:54:54 --> Language Class Initialized
INFO - 2016-11-22 21:54:54 --> Loader Class Initialized
INFO - 2016-11-22 21:54:54 --> Helper loaded: url_helper
INFO - 2016-11-22 21:54:54 --> Helper loaded: form_helper
INFO - 2016-11-22 21:54:54 --> Database Driver Class Initialized
INFO - 2016-11-22 21:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 21:54:55 --> Controller Class Initialized
INFO - 2016-11-22 21:54:55 --> Model Class Initialized
INFO - 2016-11-22 21:54:55 --> Form Validation Class Initialized
INFO - 2016-11-22 21:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 21:54:55 --> Pagination Class Initialized
INFO - 2016-11-22 21:54:55 --> Helper loaded: app_helper
INFO - 2016-11-22 21:54:55 --> Email Class Initialized
INFO - 2016-11-22 21:54:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:00:25 --> Config Class Initialized
INFO - 2016-11-22 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:00:25 --> Utf8 Class Initialized
INFO - 2016-11-22 22:00:25 --> URI Class Initialized
INFO - 2016-11-22 22:00:25 --> Router Class Initialized
INFO - 2016-11-22 22:00:25 --> Output Class Initialized
INFO - 2016-11-22 22:00:25 --> Security Class Initialized
DEBUG - 2016-11-22 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:00:26 --> Input Class Initialized
INFO - 2016-11-22 22:00:26 --> Language Class Initialized
INFO - 2016-11-22 22:00:26 --> Loader Class Initialized
INFO - 2016-11-22 22:00:26 --> Helper loaded: url_helper
INFO - 2016-11-22 22:00:26 --> Helper loaded: form_helper
INFO - 2016-11-22 22:00:26 --> Database Driver Class Initialized
INFO - 2016-11-22 22:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:00:26 --> Controller Class Initialized
INFO - 2016-11-22 22:00:26 --> Model Class Initialized
INFO - 2016-11-22 22:00:26 --> Form Validation Class Initialized
INFO - 2016-11-22 22:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:00:26 --> Pagination Class Initialized
INFO - 2016-11-22 22:00:26 --> Helper loaded: app_helper
INFO - 2016-11-22 22:00:26 --> Email Class Initialized
INFO - 2016-11-22 22:00:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:04:03 --> Config Class Initialized
INFO - 2016-11-22 22:04:03 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:04:03 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:04:03 --> Utf8 Class Initialized
INFO - 2016-11-22 22:04:03 --> URI Class Initialized
INFO - 2016-11-22 22:04:03 --> Router Class Initialized
INFO - 2016-11-22 22:04:03 --> Output Class Initialized
INFO - 2016-11-22 22:04:03 --> Security Class Initialized
DEBUG - 2016-11-22 22:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:04:03 --> Input Class Initialized
INFO - 2016-11-22 22:04:03 --> Language Class Initialized
INFO - 2016-11-22 22:04:03 --> Loader Class Initialized
INFO - 2016-11-22 22:04:03 --> Helper loaded: url_helper
INFO - 2016-11-22 22:04:03 --> Helper loaded: form_helper
INFO - 2016-11-22 22:04:03 --> Database Driver Class Initialized
INFO - 2016-11-22 22:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:04:03 --> Controller Class Initialized
INFO - 2016-11-22 22:04:03 --> Model Class Initialized
INFO - 2016-11-22 22:04:03 --> Form Validation Class Initialized
INFO - 2016-11-22 22:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:04:03 --> Pagination Class Initialized
INFO - 2016-11-22 22:04:03 --> Helper loaded: app_helper
INFO - 2016-11-22 22:04:03 --> Email Class Initialized
INFO - 2016-11-22 22:04:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:04:14 --> Config Class Initialized
INFO - 2016-11-22 22:04:14 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:04:14 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:04:14 --> Utf8 Class Initialized
INFO - 2016-11-22 22:04:14 --> URI Class Initialized
INFO - 2016-11-22 22:04:14 --> Router Class Initialized
INFO - 2016-11-22 22:04:14 --> Output Class Initialized
INFO - 2016-11-22 22:04:14 --> Security Class Initialized
DEBUG - 2016-11-22 22:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:04:14 --> Input Class Initialized
INFO - 2016-11-22 22:04:14 --> Language Class Initialized
INFO - 2016-11-22 22:04:14 --> Loader Class Initialized
INFO - 2016-11-22 22:04:14 --> Helper loaded: url_helper
INFO - 2016-11-22 22:04:14 --> Helper loaded: form_helper
INFO - 2016-11-22 22:04:14 --> Database Driver Class Initialized
INFO - 2016-11-22 22:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:04:14 --> Controller Class Initialized
INFO - 2016-11-22 22:04:15 --> Model Class Initialized
INFO - 2016-11-22 22:04:15 --> Form Validation Class Initialized
INFO - 2016-11-22 22:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:04:15 --> Pagination Class Initialized
INFO - 2016-11-22 22:04:15 --> Helper loaded: app_helper
INFO - 2016-11-22 22:04:15 --> Email Class Initialized
INFO - 2016-11-22 22:04:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:05:50 --> Config Class Initialized
INFO - 2016-11-22 22:05:50 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:05:50 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:05:50 --> Utf8 Class Initialized
INFO - 2016-11-22 22:05:50 --> URI Class Initialized
INFO - 2016-11-22 22:05:50 --> Router Class Initialized
INFO - 2016-11-22 22:05:50 --> Output Class Initialized
INFO - 2016-11-22 22:05:50 --> Security Class Initialized
DEBUG - 2016-11-22 22:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:05:50 --> Input Class Initialized
INFO - 2016-11-22 22:05:50 --> Language Class Initialized
INFO - 2016-11-22 22:05:50 --> Loader Class Initialized
INFO - 2016-11-22 22:05:50 --> Helper loaded: url_helper
INFO - 2016-11-22 22:05:50 --> Helper loaded: form_helper
INFO - 2016-11-22 22:05:50 --> Database Driver Class Initialized
INFO - 2016-11-22 22:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:05:50 --> Controller Class Initialized
INFO - 2016-11-22 22:05:50 --> Model Class Initialized
INFO - 2016-11-22 22:05:50 --> Form Validation Class Initialized
INFO - 2016-11-22 22:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:05:50 --> Pagination Class Initialized
INFO - 2016-11-22 22:05:50 --> Helper loaded: app_helper
INFO - 2016-11-22 22:05:50 --> Email Class Initialized
INFO - 2016-11-22 22:05:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:06:10 --> Config Class Initialized
INFO - 2016-11-22 22:06:10 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:06:10 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:06:10 --> Utf8 Class Initialized
INFO - 2016-11-22 22:06:10 --> URI Class Initialized
INFO - 2016-11-22 22:06:10 --> Router Class Initialized
INFO - 2016-11-22 22:06:10 --> Output Class Initialized
INFO - 2016-11-22 22:06:10 --> Security Class Initialized
DEBUG - 2016-11-22 22:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:06:10 --> Input Class Initialized
INFO - 2016-11-22 22:06:10 --> Language Class Initialized
INFO - 2016-11-22 22:06:10 --> Loader Class Initialized
INFO - 2016-11-22 22:06:10 --> Helper loaded: url_helper
INFO - 2016-11-22 22:06:10 --> Helper loaded: form_helper
INFO - 2016-11-22 22:06:10 --> Database Driver Class Initialized
INFO - 2016-11-22 22:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:06:10 --> Controller Class Initialized
INFO - 2016-11-22 22:06:10 --> Model Class Initialized
INFO - 2016-11-22 22:06:10 --> Form Validation Class Initialized
INFO - 2016-11-22 22:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:06:10 --> Pagination Class Initialized
INFO - 2016-11-22 22:06:10 --> Helper loaded: app_helper
INFO - 2016-11-22 22:06:10 --> Email Class Initialized
INFO - 2016-11-22 22:06:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:06:36 --> Config Class Initialized
INFO - 2016-11-22 22:06:36 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:06:36 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:06:36 --> Utf8 Class Initialized
INFO - 2016-11-22 22:06:36 --> URI Class Initialized
INFO - 2016-11-22 22:06:36 --> Router Class Initialized
INFO - 2016-11-22 22:06:36 --> Output Class Initialized
INFO - 2016-11-22 22:06:36 --> Security Class Initialized
DEBUG - 2016-11-22 22:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:06:37 --> Input Class Initialized
INFO - 2016-11-22 22:06:37 --> Language Class Initialized
INFO - 2016-11-22 22:06:37 --> Loader Class Initialized
INFO - 2016-11-22 22:06:37 --> Helper loaded: url_helper
INFO - 2016-11-22 22:06:37 --> Helper loaded: form_helper
INFO - 2016-11-22 22:06:37 --> Database Driver Class Initialized
INFO - 2016-11-22 22:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:06:37 --> Controller Class Initialized
INFO - 2016-11-22 22:06:37 --> Model Class Initialized
INFO - 2016-11-22 22:06:37 --> Form Validation Class Initialized
INFO - 2016-11-22 22:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:06:37 --> Pagination Class Initialized
INFO - 2016-11-22 22:06:37 --> Helper loaded: app_helper
INFO - 2016-11-22 22:06:37 --> Email Class Initialized
INFO - 2016-11-22 22:06:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:07:25 --> Config Class Initialized
INFO - 2016-11-22 22:07:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:07:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:07:25 --> Utf8 Class Initialized
INFO - 2016-11-22 22:07:25 --> URI Class Initialized
INFO - 2016-11-22 22:07:25 --> Router Class Initialized
INFO - 2016-11-22 22:07:25 --> Output Class Initialized
INFO - 2016-11-22 22:07:25 --> Security Class Initialized
DEBUG - 2016-11-22 22:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:07:25 --> Input Class Initialized
INFO - 2016-11-22 22:07:25 --> Language Class Initialized
INFO - 2016-11-22 22:07:25 --> Loader Class Initialized
INFO - 2016-11-22 22:07:25 --> Helper loaded: url_helper
INFO - 2016-11-22 22:07:25 --> Helper loaded: form_helper
INFO - 2016-11-22 22:07:25 --> Database Driver Class Initialized
INFO - 2016-11-22 22:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:07:25 --> Controller Class Initialized
INFO - 2016-11-22 22:07:25 --> Model Class Initialized
INFO - 2016-11-22 22:07:25 --> Form Validation Class Initialized
INFO - 2016-11-22 22:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:07:25 --> Pagination Class Initialized
INFO - 2016-11-22 22:07:25 --> Helper loaded: app_helper
INFO - 2016-11-22 22:07:25 --> Email Class Initialized
INFO - 2016-11-22 22:07:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:08:06 --> Config Class Initialized
INFO - 2016-11-22 22:08:06 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:08:06 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:08:06 --> Utf8 Class Initialized
INFO - 2016-11-22 22:08:06 --> URI Class Initialized
INFO - 2016-11-22 22:08:06 --> Router Class Initialized
INFO - 2016-11-22 22:08:06 --> Output Class Initialized
INFO - 2016-11-22 22:08:06 --> Security Class Initialized
DEBUG - 2016-11-22 22:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:08:06 --> Input Class Initialized
INFO - 2016-11-22 22:08:06 --> Language Class Initialized
INFO - 2016-11-22 22:08:06 --> Loader Class Initialized
INFO - 2016-11-22 22:08:06 --> Helper loaded: url_helper
INFO - 2016-11-22 22:08:06 --> Helper loaded: form_helper
INFO - 2016-11-22 22:08:06 --> Database Driver Class Initialized
INFO - 2016-11-22 22:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:08:06 --> Controller Class Initialized
INFO - 2016-11-22 22:08:06 --> Model Class Initialized
INFO - 2016-11-22 22:08:06 --> Form Validation Class Initialized
INFO - 2016-11-22 22:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:08:06 --> Pagination Class Initialized
INFO - 2016-11-22 22:08:06 --> Helper loaded: app_helper
INFO - 2016-11-22 22:08:06 --> Email Class Initialized
INFO - 2016-11-22 22:08:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:08:33 --> Config Class Initialized
INFO - 2016-11-22 22:08:33 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:08:33 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:08:33 --> Utf8 Class Initialized
INFO - 2016-11-22 22:08:33 --> URI Class Initialized
INFO - 2016-11-22 22:08:33 --> Router Class Initialized
INFO - 2016-11-22 22:08:33 --> Output Class Initialized
INFO - 2016-11-22 22:08:33 --> Security Class Initialized
DEBUG - 2016-11-22 22:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:08:33 --> Input Class Initialized
INFO - 2016-11-22 22:08:33 --> Language Class Initialized
INFO - 2016-11-22 22:08:33 --> Loader Class Initialized
INFO - 2016-11-22 22:08:33 --> Helper loaded: url_helper
INFO - 2016-11-22 22:08:33 --> Helper loaded: form_helper
INFO - 2016-11-22 22:08:33 --> Database Driver Class Initialized
INFO - 2016-11-22 22:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:08:33 --> Controller Class Initialized
INFO - 2016-11-22 22:08:33 --> Model Class Initialized
INFO - 2016-11-22 22:08:33 --> Form Validation Class Initialized
INFO - 2016-11-22 22:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:08:33 --> Pagination Class Initialized
INFO - 2016-11-22 22:08:33 --> Helper loaded: app_helper
INFO - 2016-11-22 22:08:34 --> Email Class Initialized
INFO - 2016-11-22 22:08:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:11:02 --> Config Class Initialized
INFO - 2016-11-22 22:11:02 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:11:02 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:11:02 --> Utf8 Class Initialized
INFO - 2016-11-22 22:11:02 --> URI Class Initialized
INFO - 2016-11-22 22:11:02 --> Router Class Initialized
INFO - 2016-11-22 22:11:02 --> Output Class Initialized
INFO - 2016-11-22 22:11:02 --> Security Class Initialized
DEBUG - 2016-11-22 22:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:11:02 --> Input Class Initialized
INFO - 2016-11-22 22:11:02 --> Language Class Initialized
INFO - 2016-11-22 22:11:02 --> Loader Class Initialized
INFO - 2016-11-22 22:11:02 --> Helper loaded: url_helper
INFO - 2016-11-22 22:11:02 --> Helper loaded: form_helper
INFO - 2016-11-22 22:11:02 --> Database Driver Class Initialized
INFO - 2016-11-22 22:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:11:02 --> Controller Class Initialized
INFO - 2016-11-22 22:11:02 --> Model Class Initialized
INFO - 2016-11-22 22:11:02 --> Form Validation Class Initialized
INFO - 2016-11-22 22:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:11:02 --> Pagination Class Initialized
INFO - 2016-11-22 22:11:02 --> Helper loaded: app_helper
INFO - 2016-11-22 22:11:02 --> Email Class Initialized
INFO - 2016-11-22 22:11:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:14:58 --> Config Class Initialized
INFO - 2016-11-22 22:14:58 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:14:58 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:14:58 --> Utf8 Class Initialized
INFO - 2016-11-22 22:14:58 --> URI Class Initialized
INFO - 2016-11-22 22:14:58 --> Router Class Initialized
INFO - 2016-11-22 22:14:58 --> Output Class Initialized
INFO - 2016-11-22 22:14:58 --> Security Class Initialized
DEBUG - 2016-11-22 22:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:14:58 --> Input Class Initialized
INFO - 2016-11-22 22:14:58 --> Language Class Initialized
INFO - 2016-11-22 22:14:58 --> Loader Class Initialized
INFO - 2016-11-22 22:14:58 --> Helper loaded: url_helper
INFO - 2016-11-22 22:14:58 --> Helper loaded: form_helper
INFO - 2016-11-22 22:14:58 --> Database Driver Class Initialized
INFO - 2016-11-22 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:14:59 --> Controller Class Initialized
INFO - 2016-11-22 22:14:59 --> Model Class Initialized
INFO - 2016-11-22 22:14:59 --> Form Validation Class Initialized
INFO - 2016-11-22 22:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:14:59 --> Pagination Class Initialized
INFO - 2016-11-22 22:14:59 --> Helper loaded: app_helper
INFO - 2016-11-22 22:14:59 --> Email Class Initialized
INFO - 2016-11-22 22:14:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:16:25 --> Config Class Initialized
INFO - 2016-11-22 22:16:25 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:16:25 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:16:25 --> Utf8 Class Initialized
INFO - 2016-11-22 22:16:25 --> URI Class Initialized
INFO - 2016-11-22 22:16:25 --> Router Class Initialized
INFO - 2016-11-22 22:16:25 --> Output Class Initialized
INFO - 2016-11-22 22:16:25 --> Security Class Initialized
DEBUG - 2016-11-22 22:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:16:25 --> Input Class Initialized
INFO - 2016-11-22 22:16:25 --> Language Class Initialized
INFO - 2016-11-22 22:16:25 --> Loader Class Initialized
INFO - 2016-11-22 22:16:25 --> Helper loaded: url_helper
INFO - 2016-11-22 22:16:25 --> Helper loaded: form_helper
INFO - 2016-11-22 22:16:25 --> Database Driver Class Initialized
INFO - 2016-11-22 22:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:16:25 --> Controller Class Initialized
INFO - 2016-11-22 22:16:25 --> Model Class Initialized
INFO - 2016-11-22 22:16:25 --> Form Validation Class Initialized
INFO - 2016-11-22 22:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:16:25 --> Pagination Class Initialized
INFO - 2016-11-22 22:16:25 --> Helper loaded: app_helper
INFO - 2016-11-22 22:16:25 --> Email Class Initialized
INFO - 2016-11-22 22:16:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:16:39 --> Config Class Initialized
INFO - 2016-11-22 22:16:39 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:16:39 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:16:39 --> Utf8 Class Initialized
INFO - 2016-11-22 22:16:39 --> URI Class Initialized
INFO - 2016-11-22 22:16:39 --> Router Class Initialized
INFO - 2016-11-22 22:16:39 --> Output Class Initialized
INFO - 2016-11-22 22:16:39 --> Security Class Initialized
DEBUG - 2016-11-22 22:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:16:39 --> Input Class Initialized
INFO - 2016-11-22 22:16:39 --> Language Class Initialized
INFO - 2016-11-22 22:16:39 --> Loader Class Initialized
INFO - 2016-11-22 22:16:39 --> Helper loaded: url_helper
INFO - 2016-11-22 22:16:39 --> Helper loaded: form_helper
INFO - 2016-11-22 22:16:39 --> Database Driver Class Initialized
INFO - 2016-11-22 22:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:16:39 --> Controller Class Initialized
INFO - 2016-11-22 22:16:39 --> Model Class Initialized
INFO - 2016-11-22 22:16:39 --> Form Validation Class Initialized
INFO - 2016-11-22 22:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:16:39 --> Pagination Class Initialized
INFO - 2016-11-22 22:16:39 --> Helper loaded: app_helper
INFO - 2016-11-22 22:16:39 --> Email Class Initialized
INFO - 2016-11-22 22:16:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:17:05 --> Config Class Initialized
INFO - 2016-11-22 22:17:05 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:17:05 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:17:05 --> Utf8 Class Initialized
INFO - 2016-11-22 22:17:05 --> URI Class Initialized
DEBUG - 2016-11-22 22:17:05 --> No URI present. Default controller set.
INFO - 2016-11-22 22:17:05 --> Router Class Initialized
INFO - 2016-11-22 22:17:05 --> Output Class Initialized
INFO - 2016-11-22 22:17:05 --> Security Class Initialized
DEBUG - 2016-11-22 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:17:05 --> Input Class Initialized
INFO - 2016-11-22 22:17:05 --> Language Class Initialized
INFO - 2016-11-22 22:17:05 --> Loader Class Initialized
INFO - 2016-11-22 22:17:05 --> Helper loaded: url_helper
INFO - 2016-11-22 22:17:05 --> Helper loaded: form_helper
INFO - 2016-11-22 22:17:05 --> Database Driver Class Initialized
INFO - 2016-11-22 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:17:05 --> Controller Class Initialized
INFO - 2016-11-22 22:17:05 --> Model Class Initialized
INFO - 2016-11-22 22:17:05 --> Model Class Initialized
INFO - 2016-11-22 22:17:05 --> Model Class Initialized
INFO - 2016-11-22 22:17:06 --> Model Class Initialized
INFO - 2016-11-22 22:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:17:06 --> Pagination Class Initialized
INFO - 2016-11-22 22:17:06 --> Helper loaded: app_helper
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 22:17:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 22:17:06 --> Final output sent to browser
DEBUG - 2016-11-22 22:17:06 --> Total execution time: 0.8990
INFO - 2016-11-22 22:21:42 --> Config Class Initialized
INFO - 2016-11-22 22:21:42 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:21:42 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:21:42 --> Utf8 Class Initialized
INFO - 2016-11-22 22:21:42 --> URI Class Initialized
INFO - 2016-11-22 22:21:42 --> Router Class Initialized
INFO - 2016-11-22 22:21:42 --> Output Class Initialized
INFO - 2016-11-22 22:21:42 --> Security Class Initialized
DEBUG - 2016-11-22 22:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:21:42 --> Input Class Initialized
INFO - 2016-11-22 22:21:42 --> Language Class Initialized
INFO - 2016-11-22 22:21:42 --> Loader Class Initialized
INFO - 2016-11-22 22:21:42 --> Helper loaded: url_helper
INFO - 2016-11-22 22:21:42 --> Helper loaded: form_helper
INFO - 2016-11-22 22:21:42 --> Database Driver Class Initialized
INFO - 2016-11-22 22:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:21:42 --> Controller Class Initialized
INFO - 2016-11-22 22:21:42 --> Model Class Initialized
INFO - 2016-11-22 22:21:42 --> Form Validation Class Initialized
INFO - 2016-11-22 22:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:21:42 --> Pagination Class Initialized
INFO - 2016-11-22 22:21:43 --> Helper loaded: app_helper
INFO - 2016-11-22 22:21:43 --> Email Class Initialized
INFO - 2016-11-22 22:21:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:21:54 --> Config Class Initialized
INFO - 2016-11-22 22:21:54 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:21:54 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:21:54 --> Utf8 Class Initialized
INFO - 2016-11-22 22:21:54 --> URI Class Initialized
INFO - 2016-11-22 22:21:54 --> Router Class Initialized
INFO - 2016-11-22 22:21:54 --> Output Class Initialized
INFO - 2016-11-22 22:21:54 --> Security Class Initialized
DEBUG - 2016-11-22 22:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:21:55 --> Input Class Initialized
INFO - 2016-11-22 22:21:55 --> Language Class Initialized
INFO - 2016-11-22 22:21:55 --> Loader Class Initialized
INFO - 2016-11-22 22:21:55 --> Helper loaded: url_helper
INFO - 2016-11-22 22:21:55 --> Helper loaded: form_helper
INFO - 2016-11-22 22:21:55 --> Database Driver Class Initialized
INFO - 2016-11-22 22:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:21:55 --> Controller Class Initialized
INFO - 2016-11-22 22:21:55 --> Model Class Initialized
INFO - 2016-11-22 22:21:55 --> Form Validation Class Initialized
INFO - 2016-11-22 22:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:21:55 --> Pagination Class Initialized
INFO - 2016-11-22 22:21:55 --> Helper loaded: app_helper
INFO - 2016-11-22 22:21:55 --> Email Class Initialized
INFO - 2016-11-22 22:21:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:22:20 --> Config Class Initialized
INFO - 2016-11-22 22:22:20 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:22:20 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:22:20 --> Utf8 Class Initialized
INFO - 2016-11-22 22:22:20 --> URI Class Initialized
INFO - 2016-11-22 22:22:20 --> Router Class Initialized
INFO - 2016-11-22 22:22:20 --> Output Class Initialized
INFO - 2016-11-22 22:22:20 --> Security Class Initialized
DEBUG - 2016-11-22 22:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:22:20 --> Input Class Initialized
INFO - 2016-11-22 22:22:20 --> Language Class Initialized
INFO - 2016-11-22 22:22:20 --> Loader Class Initialized
INFO - 2016-11-22 22:22:20 --> Helper loaded: url_helper
INFO - 2016-11-22 22:22:20 --> Helper loaded: form_helper
INFO - 2016-11-22 22:22:20 --> Database Driver Class Initialized
INFO - 2016-11-22 22:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:22:20 --> Controller Class Initialized
INFO - 2016-11-22 22:22:20 --> Model Class Initialized
INFO - 2016-11-22 22:22:20 --> Form Validation Class Initialized
INFO - 2016-11-22 22:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:22:20 --> Pagination Class Initialized
INFO - 2016-11-22 22:22:20 --> Helper loaded: app_helper
INFO - 2016-11-22 22:22:20 --> Email Class Initialized
INFO - 2016-11-22 22:22:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:22:35 --> Config Class Initialized
INFO - 2016-11-22 22:22:35 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:22:35 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:22:35 --> Utf8 Class Initialized
INFO - 2016-11-22 22:22:35 --> URI Class Initialized
INFO - 2016-11-22 22:22:35 --> Router Class Initialized
INFO - 2016-11-22 22:22:35 --> Output Class Initialized
INFO - 2016-11-22 22:22:35 --> Security Class Initialized
DEBUG - 2016-11-22 22:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:22:35 --> Input Class Initialized
INFO - 2016-11-22 22:22:35 --> Language Class Initialized
INFO - 2016-11-22 22:22:35 --> Loader Class Initialized
INFO - 2016-11-22 22:22:36 --> Helper loaded: url_helper
INFO - 2016-11-22 22:22:36 --> Helper loaded: form_helper
INFO - 2016-11-22 22:22:36 --> Database Driver Class Initialized
INFO - 2016-11-22 22:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:22:36 --> Controller Class Initialized
INFO - 2016-11-22 22:22:36 --> Model Class Initialized
INFO - 2016-11-22 22:22:36 --> Form Validation Class Initialized
INFO - 2016-11-22 22:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:22:36 --> Pagination Class Initialized
INFO - 2016-11-22 22:22:36 --> Helper loaded: app_helper
INFO - 2016-11-22 22:22:36 --> Email Class Initialized
INFO - 2016-11-22 22:22:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:47:28 --> Config Class Initialized
INFO - 2016-11-22 22:47:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:47:28 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:47:28 --> Utf8 Class Initialized
INFO - 2016-11-22 22:47:28 --> URI Class Initialized
INFO - 2016-11-22 22:47:28 --> Router Class Initialized
INFO - 2016-11-22 22:47:28 --> Output Class Initialized
INFO - 2016-11-22 22:47:28 --> Security Class Initialized
DEBUG - 2016-11-22 22:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:47:28 --> Input Class Initialized
INFO - 2016-11-22 22:47:28 --> Language Class Initialized
INFO - 2016-11-22 22:47:28 --> Loader Class Initialized
INFO - 2016-11-22 22:47:28 --> Helper loaded: url_helper
INFO - 2016-11-22 22:47:28 --> Helper loaded: form_helper
INFO - 2016-11-22 22:47:28 --> Database Driver Class Initialized
INFO - 2016-11-22 22:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:47:28 --> Controller Class Initialized
INFO - 2016-11-22 22:47:28 --> Model Class Initialized
INFO - 2016-11-22 22:47:28 --> Form Validation Class Initialized
INFO - 2016-11-22 22:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:47:28 --> Pagination Class Initialized
INFO - 2016-11-22 22:47:28 --> Helper loaded: app_helper
INFO - 2016-11-22 22:47:28 --> Email Class Initialized
INFO - 2016-11-22 22:47:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 21:47:29 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\LMS\app\views\email_template.php 19
INFO - 2016-11-22 22:48:24 --> Config Class Initialized
INFO - 2016-11-22 22:48:24 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:48:24 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:48:24 --> Utf8 Class Initialized
INFO - 2016-11-22 22:48:24 --> URI Class Initialized
INFO - 2016-11-22 22:48:24 --> Router Class Initialized
INFO - 2016-11-22 22:48:24 --> Output Class Initialized
INFO - 2016-11-22 22:48:24 --> Security Class Initialized
DEBUG - 2016-11-22 22:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:48:24 --> Input Class Initialized
INFO - 2016-11-22 22:48:24 --> Language Class Initialized
INFO - 2016-11-22 22:48:24 --> Loader Class Initialized
INFO - 2016-11-22 22:48:24 --> Helper loaded: url_helper
INFO - 2016-11-22 22:48:24 --> Helper loaded: form_helper
INFO - 2016-11-22 22:48:24 --> Database Driver Class Initialized
INFO - 2016-11-22 22:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:48:24 --> Controller Class Initialized
INFO - 2016-11-22 22:48:24 --> Model Class Initialized
INFO - 2016-11-22 22:48:24 --> Form Validation Class Initialized
INFO - 2016-11-22 22:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:48:24 --> Pagination Class Initialized
INFO - 2016-11-22 22:48:24 --> Helper loaded: app_helper
INFO - 2016-11-22 22:48:24 --> Email Class Initialized
INFO - 2016-11-22 22:48:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 21:48:24 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\LMS\app\views\email_template.php 19
INFO - 2016-11-22 22:48:28 --> Config Class Initialized
INFO - 2016-11-22 22:48:28 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:48:29 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:48:29 --> Utf8 Class Initialized
INFO - 2016-11-22 22:48:29 --> URI Class Initialized
DEBUG - 2016-11-22 22:48:29 --> No URI present. Default controller set.
INFO - 2016-11-22 22:48:29 --> Router Class Initialized
INFO - 2016-11-22 22:48:29 --> Output Class Initialized
INFO - 2016-11-22 22:48:29 --> Security Class Initialized
DEBUG - 2016-11-22 22:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:48:29 --> Input Class Initialized
INFO - 2016-11-22 22:48:29 --> Language Class Initialized
INFO - 2016-11-22 22:48:29 --> Loader Class Initialized
INFO - 2016-11-22 22:48:29 --> Helper loaded: url_helper
INFO - 2016-11-22 22:48:29 --> Helper loaded: form_helper
INFO - 2016-11-22 22:48:29 --> Database Driver Class Initialized
INFO - 2016-11-22 22:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:48:29 --> Controller Class Initialized
INFO - 2016-11-22 22:48:29 --> Model Class Initialized
INFO - 2016-11-22 22:48:29 --> Model Class Initialized
INFO - 2016-11-22 22:48:29 --> Model Class Initialized
INFO - 2016-11-22 22:48:29 --> Model Class Initialized
INFO - 2016-11-22 22:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:48:29 --> Pagination Class Initialized
INFO - 2016-11-22 22:48:29 --> Helper loaded: app_helper
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-22 22:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-22 22:48:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-22 22:48:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-22 22:48:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-22 22:48:30 --> Final output sent to browser
DEBUG - 2016-11-22 22:48:30 --> Total execution time: 1.1627
INFO - 2016-11-22 22:48:53 --> Config Class Initialized
INFO - 2016-11-22 22:48:53 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:48:53 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:48:53 --> Utf8 Class Initialized
INFO - 2016-11-22 22:48:53 --> URI Class Initialized
INFO - 2016-11-22 22:48:53 --> Router Class Initialized
INFO - 2016-11-22 22:48:53 --> Output Class Initialized
INFO - 2016-11-22 22:48:53 --> Security Class Initialized
DEBUG - 2016-11-22 22:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:48:53 --> Input Class Initialized
INFO - 2016-11-22 22:48:53 --> Language Class Initialized
INFO - 2016-11-22 22:48:53 --> Loader Class Initialized
INFO - 2016-11-22 22:48:53 --> Helper loaded: url_helper
INFO - 2016-11-22 22:48:53 --> Helper loaded: form_helper
INFO - 2016-11-22 22:48:53 --> Database Driver Class Initialized
INFO - 2016-11-22 22:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:48:53 --> Controller Class Initialized
INFO - 2016-11-22 22:48:53 --> Model Class Initialized
INFO - 2016-11-22 22:48:53 --> Form Validation Class Initialized
INFO - 2016-11-22 22:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:48:53 --> Pagination Class Initialized
INFO - 2016-11-22 22:48:53 --> Helper loaded: app_helper
INFO - 2016-11-22 22:48:54 --> Email Class Initialized
INFO - 2016-11-22 22:48:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 21:48:54 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\LMS\app\views\email_template.php 19
INFO - 2016-11-22 22:52:33 --> Config Class Initialized
INFO - 2016-11-22 22:52:33 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:52:33 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:52:33 --> Utf8 Class Initialized
INFO - 2016-11-22 22:52:33 --> URI Class Initialized
INFO - 2016-11-22 22:52:33 --> Router Class Initialized
INFO - 2016-11-22 22:52:33 --> Output Class Initialized
INFO - 2016-11-22 22:52:33 --> Security Class Initialized
DEBUG - 2016-11-22 22:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:52:33 --> Input Class Initialized
INFO - 2016-11-22 22:52:33 --> Language Class Initialized
INFO - 2016-11-22 22:52:33 --> Loader Class Initialized
INFO - 2016-11-22 22:52:33 --> Helper loaded: url_helper
INFO - 2016-11-22 22:52:33 --> Helper loaded: form_helper
INFO - 2016-11-22 22:52:33 --> Database Driver Class Initialized
INFO - 2016-11-22 22:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:52:34 --> Controller Class Initialized
INFO - 2016-11-22 22:52:34 --> Model Class Initialized
INFO - 2016-11-22 22:52:34 --> Form Validation Class Initialized
INFO - 2016-11-22 22:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:52:34 --> Pagination Class Initialized
INFO - 2016-11-22 22:52:34 --> Helper loaded: app_helper
INFO - 2016-11-22 22:52:34 --> Email Class Initialized
INFO - 2016-11-22 22:52:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:52:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-22 21:52:34 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-22 21:52:34 --> Severity: Warning --> strpos() expects parameter 1 to be string, object given C:\xampp\htdocs\LMS\sys\libraries\Email.php 831
ERROR - 2016-11-22 21:52:34 --> Severity: Warning --> preg_split() expects parameter 2 to be string, object given C:\xampp\htdocs\LMS\sys\libraries\Email.php 832
ERROR - 2016-11-22 21:52:34 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\LMS\sys\libraries\Email.php 617
ERROR - 2016-11-22 21:52:34 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-22 21:52:34 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-22 21:52:34 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-22 21:52:34 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-22 21:52:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:52:34 --> Final output sent to browser
DEBUG - 2016-11-22 21:52:34 --> Total execution time: 0.9669
INFO - 2016-11-22 22:56:30 --> Config Class Initialized
INFO - 2016-11-22 22:56:30 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:56:30 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:56:30 --> Utf8 Class Initialized
INFO - 2016-11-22 22:56:30 --> URI Class Initialized
INFO - 2016-11-22 22:56:30 --> Router Class Initialized
INFO - 2016-11-22 22:56:30 --> Output Class Initialized
INFO - 2016-11-22 22:56:30 --> Security Class Initialized
DEBUG - 2016-11-22 22:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:56:30 --> Input Class Initialized
INFO - 2016-11-22 22:56:30 --> Language Class Initialized
INFO - 2016-11-22 22:56:30 --> Loader Class Initialized
INFO - 2016-11-22 22:56:30 --> Helper loaded: url_helper
INFO - 2016-11-22 22:56:30 --> Helper loaded: form_helper
INFO - 2016-11-22 22:56:30 --> Database Driver Class Initialized
INFO - 2016-11-22 22:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:56:30 --> Controller Class Initialized
INFO - 2016-11-22 22:56:30 --> Model Class Initialized
INFO - 2016-11-22 22:56:30 --> Form Validation Class Initialized
INFO - 2016-11-22 22:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:56:30 --> Pagination Class Initialized
INFO - 2016-11-22 22:56:30 --> Helper loaded: app_helper
INFO - 2016-11-22 22:56:30 --> Email Class Initialized
INFO - 2016-11-22 22:56:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:56:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-22 21:56:31 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-22 21:56:31 --> Severity: Warning --> strpos() expects parameter 1 to be string, object given C:\xampp\htdocs\LMS\sys\libraries\Email.php 831
ERROR - 2016-11-22 21:56:31 --> Severity: Warning --> preg_split() expects parameter 2 to be string, object given C:\xampp\htdocs\LMS\sys\libraries\Email.php 832
ERROR - 2016-11-22 21:56:31 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\LMS\sys\libraries\Email.php 617
ERROR - 2016-11-22 21:56:31 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
ERROR - 2016-11-22 21:56:31 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-22 21:56:31 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-22 21:56:31 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-22 21:56:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:56:31 --> Final output sent to browser
DEBUG - 2016-11-22 21:56:31 --> Total execution time: 0.9225
INFO - 2016-11-22 22:57:23 --> Config Class Initialized
INFO - 2016-11-22 22:57:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:57:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:57:23 --> Utf8 Class Initialized
INFO - 2016-11-22 22:57:23 --> URI Class Initialized
INFO - 2016-11-22 22:57:23 --> Router Class Initialized
INFO - 2016-11-22 22:57:23 --> Output Class Initialized
INFO - 2016-11-22 22:57:23 --> Security Class Initialized
DEBUG - 2016-11-22 22:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:57:23 --> Input Class Initialized
INFO - 2016-11-22 22:57:23 --> Language Class Initialized
INFO - 2016-11-22 22:57:23 --> Loader Class Initialized
INFO - 2016-11-22 22:57:23 --> Helper loaded: url_helper
INFO - 2016-11-22 22:57:23 --> Helper loaded: form_helper
INFO - 2016-11-22 22:57:23 --> Database Driver Class Initialized
INFO - 2016-11-22 22:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:57:23 --> Controller Class Initialized
INFO - 2016-11-22 22:57:23 --> Model Class Initialized
INFO - 2016-11-22 22:57:23 --> Form Validation Class Initialized
INFO - 2016-11-22 22:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:57:23 --> Pagination Class Initialized
INFO - 2016-11-22 22:57:23 --> Helper loaded: app_helper
INFO - 2016-11-22 22:57:23 --> Email Class Initialized
INFO - 2016-11-22 22:57:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 21:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\/email_template.php
DEBUG - 2016-11-22 21:57:24 --> Config file loaded: C:\xampp\htdocs\LMS\app\config/email.php
ERROR - 2016-11-22 21:57:24 --> Severity: Warning --> strpos() expects parameter 1 to be string, object given C:\xampp\htdocs\LMS\sys\libraries\Email.php 831
ERROR - 2016-11-22 21:57:24 --> Severity: Warning --> preg_split() expects parameter 2 to be string, object given C:\xampp\htdocs\LMS\sys\libraries\Email.php 832
ERROR - 2016-11-22 21:57:24 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\LMS\sys\libraries\Email.php 617
ERROR - 2016-11-22 21:57:29 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.critsend.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\LMS\sys\libraries\Email.php 1990
INFO - 2016-11-22 21:57:29 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-11-22 21:57:29 --> Severity: Notice --> Undefined variable: pagination_links C:\xampp\htdocs\LMS\app\views\employee\apply_leave_sidebar.php 27
INFO - 2016-11-22 21:57:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-22 21:57:30 --> Final output sent to browser
DEBUG - 2016-11-22 21:57:30 --> Total execution time: 6.6744
INFO - 2016-11-22 22:58:29 --> Config Class Initialized
INFO - 2016-11-22 22:58:29 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:58:29 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:58:29 --> Utf8 Class Initialized
INFO - 2016-11-22 22:58:29 --> URI Class Initialized
INFO - 2016-11-22 22:58:29 --> Router Class Initialized
INFO - 2016-11-22 22:58:29 --> Output Class Initialized
INFO - 2016-11-22 22:58:29 --> Security Class Initialized
DEBUG - 2016-11-22 22:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:58:29 --> Input Class Initialized
INFO - 2016-11-22 22:58:29 --> Language Class Initialized
INFO - 2016-11-22 22:58:29 --> Loader Class Initialized
INFO - 2016-11-22 22:58:29 --> Helper loaded: url_helper
INFO - 2016-11-22 22:58:30 --> Helper loaded: form_helper
INFO - 2016-11-22 22:58:30 --> Database Driver Class Initialized
INFO - 2016-11-22 22:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:58:30 --> Controller Class Initialized
INFO - 2016-11-22 22:58:30 --> Model Class Initialized
INFO - 2016-11-22 22:58:30 --> Form Validation Class Initialized
INFO - 2016-11-22 22:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:58:30 --> Pagination Class Initialized
INFO - 2016-11-22 22:58:30 --> Helper loaded: app_helper
INFO - 2016-11-22 22:58:30 --> Email Class Initialized
INFO - 2016-11-22 22:58:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:58:55 --> Config Class Initialized
INFO - 2016-11-22 22:58:55 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:58:55 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:58:55 --> Utf8 Class Initialized
INFO - 2016-11-22 22:58:55 --> URI Class Initialized
INFO - 2016-11-22 22:58:55 --> Router Class Initialized
INFO - 2016-11-22 22:58:55 --> Output Class Initialized
INFO - 2016-11-22 22:58:55 --> Security Class Initialized
DEBUG - 2016-11-22 22:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:58:55 --> Input Class Initialized
INFO - 2016-11-22 22:58:55 --> Language Class Initialized
INFO - 2016-11-22 22:58:55 --> Loader Class Initialized
INFO - 2016-11-22 22:58:55 --> Helper loaded: url_helper
INFO - 2016-11-22 22:58:55 --> Helper loaded: form_helper
INFO - 2016-11-22 22:58:55 --> Database Driver Class Initialized
INFO - 2016-11-22 22:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:58:55 --> Controller Class Initialized
INFO - 2016-11-22 22:58:55 --> Model Class Initialized
INFO - 2016-11-22 22:58:55 --> Form Validation Class Initialized
INFO - 2016-11-22 22:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:58:55 --> Pagination Class Initialized
INFO - 2016-11-22 22:58:55 --> Helper loaded: app_helper
INFO - 2016-11-22 22:58:55 --> Email Class Initialized
INFO - 2016-11-22 22:58:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 22:59:55 --> Config Class Initialized
INFO - 2016-11-22 22:59:55 --> Hooks Class Initialized
DEBUG - 2016-11-22 22:59:55 --> UTF-8 Support Enabled
INFO - 2016-11-22 22:59:55 --> Utf8 Class Initialized
INFO - 2016-11-22 22:59:55 --> URI Class Initialized
INFO - 2016-11-22 22:59:55 --> Router Class Initialized
INFO - 2016-11-22 22:59:55 --> Output Class Initialized
INFO - 2016-11-22 22:59:55 --> Security Class Initialized
DEBUG - 2016-11-22 22:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 22:59:55 --> Input Class Initialized
INFO - 2016-11-22 22:59:55 --> Language Class Initialized
INFO - 2016-11-22 22:59:55 --> Loader Class Initialized
INFO - 2016-11-22 22:59:55 --> Helper loaded: url_helper
INFO - 2016-11-22 22:59:55 --> Helper loaded: form_helper
INFO - 2016-11-22 22:59:55 --> Database Driver Class Initialized
INFO - 2016-11-22 22:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 22:59:55 --> Controller Class Initialized
INFO - 2016-11-22 22:59:55 --> Model Class Initialized
INFO - 2016-11-22 22:59:55 --> Form Validation Class Initialized
INFO - 2016-11-22 22:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 22:59:55 --> Pagination Class Initialized
INFO - 2016-11-22 22:59:55 --> Helper loaded: app_helper
INFO - 2016-11-22 22:59:55 --> Email Class Initialized
INFO - 2016-11-22 22:59:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 21:59:56 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
INFO - 2016-11-22 23:00:20 --> Config Class Initialized
INFO - 2016-11-22 23:00:20 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:00:20 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:00:20 --> Utf8 Class Initialized
INFO - 2016-11-22 23:00:20 --> URI Class Initialized
INFO - 2016-11-22 23:00:20 --> Router Class Initialized
INFO - 2016-11-22 23:00:20 --> Output Class Initialized
INFO - 2016-11-22 23:00:20 --> Security Class Initialized
DEBUG - 2016-11-22 23:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:00:20 --> Input Class Initialized
INFO - 2016-11-22 23:00:20 --> Language Class Initialized
INFO - 2016-11-22 23:00:20 --> Loader Class Initialized
INFO - 2016-11-22 23:00:20 --> Helper loaded: url_helper
INFO - 2016-11-22 23:00:20 --> Helper loaded: form_helper
INFO - 2016-11-22 23:00:20 --> Database Driver Class Initialized
INFO - 2016-11-22 23:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:00:20 --> Controller Class Initialized
INFO - 2016-11-22 23:00:20 --> Model Class Initialized
INFO - 2016-11-22 23:00:20 --> Form Validation Class Initialized
INFO - 2016-11-22 23:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:00:20 --> Pagination Class Initialized
INFO - 2016-11-22 23:00:20 --> Helper loaded: app_helper
INFO - 2016-11-22 23:00:20 --> Email Class Initialized
INFO - 2016-11-22 23:00:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 22:00:20 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
INFO - 2016-11-22 23:00:31 --> Config Class Initialized
INFO - 2016-11-22 23:00:31 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:00:31 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:00:31 --> Utf8 Class Initialized
INFO - 2016-11-22 23:00:31 --> URI Class Initialized
INFO - 2016-11-22 23:00:31 --> Router Class Initialized
INFO - 2016-11-22 23:00:31 --> Output Class Initialized
INFO - 2016-11-22 23:00:31 --> Security Class Initialized
DEBUG - 2016-11-22 23:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:00:31 --> Input Class Initialized
INFO - 2016-11-22 23:00:31 --> Language Class Initialized
INFO - 2016-11-22 23:00:31 --> Loader Class Initialized
INFO - 2016-11-22 23:00:31 --> Helper loaded: url_helper
INFO - 2016-11-22 23:00:31 --> Helper loaded: form_helper
INFO - 2016-11-22 23:00:31 --> Database Driver Class Initialized
INFO - 2016-11-22 23:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:00:31 --> Controller Class Initialized
INFO - 2016-11-22 23:00:31 --> Model Class Initialized
INFO - 2016-11-22 23:00:31 --> Form Validation Class Initialized
INFO - 2016-11-22 23:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:00:31 --> Pagination Class Initialized
INFO - 2016-11-22 23:00:31 --> Helper loaded: app_helper
INFO - 2016-11-22 23:00:31 --> Email Class Initialized
INFO - 2016-11-22 23:00:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 23:10:11 --> Config Class Initialized
INFO - 2016-11-22 23:10:11 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:10:11 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:10:11 --> Utf8 Class Initialized
INFO - 2016-11-22 23:10:11 --> URI Class Initialized
INFO - 2016-11-22 23:10:11 --> Router Class Initialized
INFO - 2016-11-22 23:10:11 --> Output Class Initialized
INFO - 2016-11-22 23:10:11 --> Security Class Initialized
DEBUG - 2016-11-22 23:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:10:11 --> Input Class Initialized
INFO - 2016-11-22 23:10:11 --> Language Class Initialized
INFO - 2016-11-22 23:10:11 --> Loader Class Initialized
INFO - 2016-11-22 23:10:11 --> Helper loaded: url_helper
INFO - 2016-11-22 23:10:11 --> Helper loaded: form_helper
INFO - 2016-11-22 23:10:11 --> Database Driver Class Initialized
INFO - 2016-11-22 23:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:10:12 --> Controller Class Initialized
INFO - 2016-11-22 23:10:12 --> Model Class Initialized
INFO - 2016-11-22 23:10:12 --> Form Validation Class Initialized
INFO - 2016-11-22 23:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:10:12 --> Pagination Class Initialized
INFO - 2016-11-22 23:10:12 --> Helper loaded: app_helper
INFO - 2016-11-22 23:10:12 --> Email Class Initialized
INFO - 2016-11-22 23:10:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 23:10:56 --> Config Class Initialized
INFO - 2016-11-22 23:10:56 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:10:56 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:10:56 --> Utf8 Class Initialized
INFO - 2016-11-22 23:10:56 --> URI Class Initialized
INFO - 2016-11-22 23:10:57 --> Router Class Initialized
INFO - 2016-11-22 23:10:57 --> Output Class Initialized
INFO - 2016-11-22 23:10:57 --> Security Class Initialized
DEBUG - 2016-11-22 23:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:10:57 --> Input Class Initialized
INFO - 2016-11-22 23:10:57 --> Language Class Initialized
ERROR - 2016-11-22 23:10:57 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
INFO - 2016-11-22 23:12:46 --> Config Class Initialized
INFO - 2016-11-22 23:12:46 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:12:46 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:12:46 --> Utf8 Class Initialized
INFO - 2016-11-22 23:12:46 --> URI Class Initialized
INFO - 2016-11-22 23:12:46 --> Router Class Initialized
INFO - 2016-11-22 23:12:46 --> Output Class Initialized
INFO - 2016-11-22 23:12:46 --> Security Class Initialized
DEBUG - 2016-11-22 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:12:46 --> Input Class Initialized
INFO - 2016-11-22 23:12:46 --> Language Class Initialized
ERROR - 2016-11-22 23:12:46 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
INFO - 2016-11-22 23:12:50 --> Config Class Initialized
INFO - 2016-11-22 23:12:50 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:12:50 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:12:50 --> Utf8 Class Initialized
INFO - 2016-11-22 23:12:50 --> URI Class Initialized
INFO - 2016-11-22 23:12:50 --> Router Class Initialized
INFO - 2016-11-22 23:12:50 --> Output Class Initialized
INFO - 2016-11-22 23:12:50 --> Security Class Initialized
DEBUG - 2016-11-22 23:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:12:50 --> Input Class Initialized
INFO - 2016-11-22 23:12:50 --> Language Class Initialized
ERROR - 2016-11-22 23:12:50 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 173
INFO - 2016-11-22 23:12:57 --> Config Class Initialized
INFO - 2016-11-22 23:12:57 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:12:57 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:12:57 --> Utf8 Class Initialized
INFO - 2016-11-22 23:12:57 --> URI Class Initialized
INFO - 2016-11-22 23:12:57 --> Router Class Initialized
INFO - 2016-11-22 23:12:57 --> Output Class Initialized
INFO - 2016-11-22 23:12:57 --> Security Class Initialized
DEBUG - 2016-11-22 23:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:12:57 --> Input Class Initialized
INFO - 2016-11-22 23:12:57 --> Language Class Initialized
INFO - 2016-11-22 23:12:57 --> Loader Class Initialized
INFO - 2016-11-22 23:12:57 --> Helper loaded: url_helper
INFO - 2016-11-22 23:12:57 --> Helper loaded: form_helper
INFO - 2016-11-22 23:12:57 --> Database Driver Class Initialized
INFO - 2016-11-22 23:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:12:57 --> Controller Class Initialized
INFO - 2016-11-22 23:12:57 --> Model Class Initialized
INFO - 2016-11-22 23:12:57 --> Form Validation Class Initialized
INFO - 2016-11-22 23:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:12:57 --> Pagination Class Initialized
INFO - 2016-11-22 23:12:57 --> Helper loaded: app_helper
INFO - 2016-11-22 23:12:57 --> Email Class Initialized
INFO - 2016-11-22 23:12:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 23:14:23 --> Config Class Initialized
INFO - 2016-11-22 23:14:23 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:14:23 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:14:23 --> Utf8 Class Initialized
INFO - 2016-11-22 23:14:23 --> URI Class Initialized
INFO - 2016-11-22 23:14:23 --> Router Class Initialized
INFO - 2016-11-22 23:14:23 --> Output Class Initialized
INFO - 2016-11-22 23:14:23 --> Security Class Initialized
DEBUG - 2016-11-22 23:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:14:23 --> Input Class Initialized
INFO - 2016-11-22 23:14:23 --> Language Class Initialized
INFO - 2016-11-22 23:14:23 --> Loader Class Initialized
INFO - 2016-11-22 23:14:23 --> Helper loaded: url_helper
INFO - 2016-11-22 23:14:23 --> Helper loaded: form_helper
INFO - 2016-11-22 23:14:23 --> Database Driver Class Initialized
INFO - 2016-11-22 23:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:14:23 --> Controller Class Initialized
INFO - 2016-11-22 23:14:23 --> Model Class Initialized
INFO - 2016-11-22 23:14:23 --> Form Validation Class Initialized
INFO - 2016-11-22 23:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:14:23 --> Pagination Class Initialized
INFO - 2016-11-22 23:14:23 --> Helper loaded: app_helper
INFO - 2016-11-22 23:14:23 --> Email Class Initialized
INFO - 2016-11-22 23:14:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 22:14:23 --> Severity: Error --> Call to a member function result() on array C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 34
INFO - 2016-11-22 23:14:57 --> Config Class Initialized
INFO - 2016-11-22 23:14:57 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:14:57 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:14:57 --> Utf8 Class Initialized
INFO - 2016-11-22 23:14:57 --> URI Class Initialized
INFO - 2016-11-22 23:14:57 --> Router Class Initialized
INFO - 2016-11-22 23:14:57 --> Output Class Initialized
INFO - 2016-11-22 23:14:58 --> Security Class Initialized
DEBUG - 2016-11-22 23:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:14:58 --> Input Class Initialized
INFO - 2016-11-22 23:14:58 --> Language Class Initialized
INFO - 2016-11-22 23:14:58 --> Loader Class Initialized
INFO - 2016-11-22 23:14:58 --> Helper loaded: url_helper
INFO - 2016-11-22 23:14:58 --> Helper loaded: form_helper
INFO - 2016-11-22 23:14:58 --> Database Driver Class Initialized
INFO - 2016-11-22 23:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:14:58 --> Controller Class Initialized
INFO - 2016-11-22 23:14:58 --> Model Class Initialized
INFO - 2016-11-22 23:14:58 --> Form Validation Class Initialized
INFO - 2016-11-22 23:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:14:58 --> Pagination Class Initialized
INFO - 2016-11-22 23:14:58 --> Helper loaded: app_helper
INFO - 2016-11-22 23:14:58 --> Email Class Initialized
INFO - 2016-11-22 23:14:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-22 22:14:58 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\LMS\app\models\Leave_application_m.php 34
INFO - 2016-11-22 23:15:21 --> Config Class Initialized
INFO - 2016-11-22 23:15:21 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:15:21 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:15:21 --> Utf8 Class Initialized
INFO - 2016-11-22 23:15:21 --> URI Class Initialized
INFO - 2016-11-22 23:15:21 --> Router Class Initialized
INFO - 2016-11-22 23:15:21 --> Output Class Initialized
INFO - 2016-11-22 23:15:21 --> Security Class Initialized
DEBUG - 2016-11-22 23:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:15:21 --> Input Class Initialized
INFO - 2016-11-22 23:15:21 --> Language Class Initialized
INFO - 2016-11-22 23:15:21 --> Loader Class Initialized
INFO - 2016-11-22 23:15:21 --> Helper loaded: url_helper
INFO - 2016-11-22 23:15:21 --> Helper loaded: form_helper
INFO - 2016-11-22 23:15:21 --> Database Driver Class Initialized
INFO - 2016-11-22 23:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:15:21 --> Controller Class Initialized
INFO - 2016-11-22 23:15:21 --> Model Class Initialized
INFO - 2016-11-22 23:15:21 --> Form Validation Class Initialized
INFO - 2016-11-22 23:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:15:21 --> Pagination Class Initialized
INFO - 2016-11-22 23:15:21 --> Helper loaded: app_helper
INFO - 2016-11-22 23:15:21 --> Email Class Initialized
INFO - 2016-11-22 23:15:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-22 23:16:36 --> Config Class Initialized
INFO - 2016-11-22 23:16:36 --> Hooks Class Initialized
DEBUG - 2016-11-22 23:16:36 --> UTF-8 Support Enabled
INFO - 2016-11-22 23:16:36 --> Utf8 Class Initialized
INFO - 2016-11-22 23:16:36 --> URI Class Initialized
INFO - 2016-11-22 23:16:36 --> Router Class Initialized
INFO - 2016-11-22 23:16:36 --> Output Class Initialized
INFO - 2016-11-22 23:16:36 --> Security Class Initialized
DEBUG - 2016-11-22 23:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-22 23:16:37 --> Input Class Initialized
INFO - 2016-11-22 23:16:37 --> Language Class Initialized
INFO - 2016-11-22 23:16:37 --> Loader Class Initialized
INFO - 2016-11-22 23:16:37 --> Helper loaded: url_helper
INFO - 2016-11-22 23:16:37 --> Helper loaded: form_helper
INFO - 2016-11-22 23:16:37 --> Database Driver Class Initialized
INFO - 2016-11-22 23:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-22 23:16:37 --> Controller Class Initialized
INFO - 2016-11-22 23:16:37 --> Model Class Initialized
INFO - 2016-11-22 23:16:37 --> Form Validation Class Initialized
INFO - 2016-11-22 23:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-22 23:16:37 --> Pagination Class Initialized
INFO - 2016-11-22 23:16:37 --> Helper loaded: app_helper
INFO - 2016-11-22 23:16:37 --> Email Class Initialized
INFO - 2016-11-22 23:16:37 --> Language file loaded: language/english/form_validation_lang.php
