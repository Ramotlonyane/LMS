<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-24 09:34:34 --> Config Class Initialized
INFO - 2016-10-24 09:34:34 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:34:34 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:34:34 --> Utf8 Class Initialized
INFO - 2016-10-24 09:34:34 --> URI Class Initialized
DEBUG - 2016-10-24 09:34:34 --> No URI present. Default controller set.
INFO - 2016-10-24 09:34:34 --> Router Class Initialized
INFO - 2016-10-24 09:34:34 --> Output Class Initialized
INFO - 2016-10-24 09:34:34 --> Security Class Initialized
DEBUG - 2016-10-24 09:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:34:34 --> Input Class Initialized
INFO - 2016-10-24 09:34:34 --> Language Class Initialized
INFO - 2016-10-24 09:34:34 --> Loader Class Initialized
INFO - 2016-10-24 09:34:34 --> Helper loaded: url_helper
INFO - 2016-10-24 09:34:34 --> Helper loaded: form_helper
INFO - 2016-10-24 09:34:34 --> Database Driver Class Initialized
INFO - 2016-10-24 09:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:34:34 --> Controller Class Initialized
INFO - 2016-10-24 09:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 09:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-24 09:34:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 09:34:34 --> Final output sent to browser
DEBUG - 2016-10-24 09:34:34 --> Total execution time: 0.1606
INFO - 2016-10-24 09:34:43 --> Config Class Initialized
INFO - 2016-10-24 09:34:43 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:34:43 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:34:43 --> Utf8 Class Initialized
INFO - 2016-10-24 09:34:43 --> URI Class Initialized
INFO - 2016-10-24 09:34:43 --> Router Class Initialized
INFO - 2016-10-24 09:34:43 --> Output Class Initialized
INFO - 2016-10-24 09:34:43 --> Security Class Initialized
DEBUG - 2016-10-24 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:34:43 --> Input Class Initialized
INFO - 2016-10-24 09:34:43 --> Language Class Initialized
INFO - 2016-10-24 09:34:43 --> Loader Class Initialized
INFO - 2016-10-24 09:34:43 --> Helper loaded: url_helper
INFO - 2016-10-24 09:34:43 --> Helper loaded: form_helper
INFO - 2016-10-24 09:34:43 --> Database Driver Class Initialized
INFO - 2016-10-24 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:34:43 --> Controller Class Initialized
DEBUG - 2016-10-24 09:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-24 09:34:43 --> Model Class Initialized
INFO - 2016-10-24 09:34:43 --> Final output sent to browser
DEBUG - 2016-10-24 09:34:43 --> Total execution time: 0.0148
INFO - 2016-10-24 09:34:43 --> Config Class Initialized
INFO - 2016-10-24 09:34:43 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:34:43 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:34:43 --> Utf8 Class Initialized
INFO - 2016-10-24 09:34:43 --> URI Class Initialized
DEBUG - 2016-10-24 09:34:43 --> No URI present. Default controller set.
INFO - 2016-10-24 09:34:43 --> Router Class Initialized
INFO - 2016-10-24 09:34:43 --> Output Class Initialized
INFO - 2016-10-24 09:34:43 --> Security Class Initialized
DEBUG - 2016-10-24 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:34:43 --> Input Class Initialized
INFO - 2016-10-24 09:34:43 --> Language Class Initialized
INFO - 2016-10-24 09:34:43 --> Loader Class Initialized
INFO - 2016-10-24 09:34:43 --> Helper loaded: url_helper
INFO - 2016-10-24 09:34:43 --> Helper loaded: form_helper
INFO - 2016-10-24 09:34:43 --> Database Driver Class Initialized
INFO - 2016-10-24 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:34:43 --> Controller Class Initialized
INFO - 2016-10-24 09:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 09:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 09:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 09:34:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 09:34:43 --> Final output sent to browser
DEBUG - 2016-10-24 09:34:43 --> Total execution time: 0.0250
INFO - 2016-10-24 09:34:46 --> Config Class Initialized
INFO - 2016-10-24 09:34:46 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:34:46 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:34:46 --> Utf8 Class Initialized
INFO - 2016-10-24 09:34:46 --> URI Class Initialized
DEBUG - 2016-10-24 09:34:46 --> No URI present. Default controller set.
INFO - 2016-10-24 09:34:46 --> Router Class Initialized
INFO - 2016-10-24 09:34:46 --> Output Class Initialized
INFO - 2016-10-24 09:34:46 --> Security Class Initialized
DEBUG - 2016-10-24 09:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:34:46 --> Input Class Initialized
INFO - 2016-10-24 09:34:46 --> Language Class Initialized
INFO - 2016-10-24 09:34:46 --> Loader Class Initialized
INFO - 2016-10-24 09:34:46 --> Helper loaded: url_helper
INFO - 2016-10-24 09:34:46 --> Helper loaded: form_helper
INFO - 2016-10-24 09:34:46 --> Database Driver Class Initialized
INFO - 2016-10-24 09:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:34:46 --> Controller Class Initialized
INFO - 2016-10-24 09:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 09:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 09:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 09:34:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 09:34:46 --> Final output sent to browser
DEBUG - 2016-10-24 09:34:46 --> Total execution time: 0.0077
INFO - 2016-10-24 09:46:16 --> Config Class Initialized
INFO - 2016-10-24 09:46:16 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:46:16 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:46:16 --> Utf8 Class Initialized
INFO - 2016-10-24 09:46:16 --> URI Class Initialized
DEBUG - 2016-10-24 09:46:16 --> No URI present. Default controller set.
INFO - 2016-10-24 09:46:16 --> Router Class Initialized
INFO - 2016-10-24 09:46:16 --> Output Class Initialized
INFO - 2016-10-24 09:46:16 --> Security Class Initialized
DEBUG - 2016-10-24 09:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:46:16 --> Input Class Initialized
INFO - 2016-10-24 09:46:16 --> Language Class Initialized
INFO - 2016-10-24 09:46:16 --> Loader Class Initialized
INFO - 2016-10-24 09:46:16 --> Helper loaded: url_helper
INFO - 2016-10-24 09:46:16 --> Helper loaded: form_helper
INFO - 2016-10-24 09:46:16 --> Database Driver Class Initialized
INFO - 2016-10-24 09:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:46:16 --> Controller Class Initialized
INFO - 2016-10-24 09:46:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 09:46:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 09:46:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 09:46:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 09:46:16 --> Final output sent to browser
DEBUG - 2016-10-24 09:46:16 --> Total execution time: 0.0065
INFO - 2016-10-24 09:46:25 --> Config Class Initialized
INFO - 2016-10-24 09:46:25 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:46:25 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:46:25 --> Utf8 Class Initialized
INFO - 2016-10-24 09:46:25 --> URI Class Initialized
DEBUG - 2016-10-24 09:46:25 --> No URI present. Default controller set.
INFO - 2016-10-24 09:46:25 --> Router Class Initialized
INFO - 2016-10-24 09:46:25 --> Output Class Initialized
INFO - 2016-10-24 09:46:25 --> Security Class Initialized
DEBUG - 2016-10-24 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:46:25 --> Input Class Initialized
INFO - 2016-10-24 09:46:25 --> Language Class Initialized
INFO - 2016-10-24 09:46:25 --> Loader Class Initialized
INFO - 2016-10-24 09:46:25 --> Helper loaded: url_helper
INFO - 2016-10-24 09:46:25 --> Helper loaded: form_helper
INFO - 2016-10-24 09:46:25 --> Database Driver Class Initialized
INFO - 2016-10-24 09:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:46:25 --> Controller Class Initialized
INFO - 2016-10-24 09:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 09:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 09:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 09:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 09:46:25 --> Final output sent to browser
DEBUG - 2016-10-24 09:46:25 --> Total execution time: 0.0063
INFO - 2016-10-24 09:48:55 --> Config Class Initialized
INFO - 2016-10-24 09:48:55 --> Hooks Class Initialized
DEBUG - 2016-10-24 09:48:55 --> UTF-8 Support Enabled
INFO - 2016-10-24 09:48:55 --> Utf8 Class Initialized
INFO - 2016-10-24 09:48:55 --> URI Class Initialized
DEBUG - 2016-10-24 09:48:55 --> No URI present. Default controller set.
INFO - 2016-10-24 09:48:55 --> Router Class Initialized
INFO - 2016-10-24 09:48:55 --> Output Class Initialized
INFO - 2016-10-24 09:48:55 --> Security Class Initialized
DEBUG - 2016-10-24 09:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 09:48:55 --> Input Class Initialized
INFO - 2016-10-24 09:48:55 --> Language Class Initialized
INFO - 2016-10-24 09:48:55 --> Loader Class Initialized
INFO - 2016-10-24 09:48:55 --> Helper loaded: url_helper
INFO - 2016-10-24 09:48:55 --> Helper loaded: form_helper
INFO - 2016-10-24 09:48:55 --> Database Driver Class Initialized
INFO - 2016-10-24 09:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 09:48:55 --> Controller Class Initialized
INFO - 2016-10-24 09:48:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 09:48:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 09:48:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 09:48:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 09:48:55 --> Final output sent to browser
DEBUG - 2016-10-24 09:48:55 --> Total execution time: 0.0057
INFO - 2016-10-24 10:24:28 --> Config Class Initialized
INFO - 2016-10-24 10:24:28 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:24:28 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:24:28 --> Utf8 Class Initialized
INFO - 2016-10-24 10:24:28 --> URI Class Initialized
DEBUG - 2016-10-24 10:24:28 --> No URI present. Default controller set.
INFO - 2016-10-24 10:24:28 --> Router Class Initialized
INFO - 2016-10-24 10:24:28 --> Output Class Initialized
INFO - 2016-10-24 10:24:28 --> Security Class Initialized
DEBUG - 2016-10-24 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:24:28 --> Input Class Initialized
INFO - 2016-10-24 10:24:28 --> Language Class Initialized
INFO - 2016-10-24 10:24:28 --> Loader Class Initialized
INFO - 2016-10-24 10:24:28 --> Helper loaded: url_helper
INFO - 2016-10-24 10:24:28 --> Helper loaded: form_helper
INFO - 2016-10-24 10:24:28 --> Database Driver Class Initialized
INFO - 2016-10-24 10:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:24:28 --> Controller Class Initialized
INFO - 2016-10-24 10:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 10:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 10:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 10:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 10:24:28 --> Final output sent to browser
DEBUG - 2016-10-24 10:24:28 --> Total execution time: 0.0254
INFO - 2016-10-24 10:24:33 --> Config Class Initialized
INFO - 2016-10-24 10:24:33 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:24:33 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:24:33 --> Utf8 Class Initialized
INFO - 2016-10-24 10:24:33 --> URI Class Initialized
DEBUG - 2016-10-24 10:24:33 --> No URI present. Default controller set.
INFO - 2016-10-24 10:24:33 --> Router Class Initialized
INFO - 2016-10-24 10:24:33 --> Output Class Initialized
INFO - 2016-10-24 10:24:33 --> Security Class Initialized
DEBUG - 2016-10-24 10:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:24:33 --> Input Class Initialized
INFO - 2016-10-24 10:24:33 --> Language Class Initialized
INFO - 2016-10-24 10:24:33 --> Loader Class Initialized
INFO - 2016-10-24 10:24:33 --> Helper loaded: url_helper
INFO - 2016-10-24 10:24:33 --> Helper loaded: form_helper
INFO - 2016-10-24 10:24:33 --> Database Driver Class Initialized
INFO - 2016-10-24 10:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:24:33 --> Controller Class Initialized
INFO - 2016-10-24 10:24:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 10:24:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 10:24:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 10:24:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 10:24:33 --> Final output sent to browser
DEBUG - 2016-10-24 10:24:33 --> Total execution time: 0.0054
INFO - 2016-10-24 10:50:14 --> Config Class Initialized
INFO - 2016-10-24 10:50:14 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:50:14 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:50:14 --> Utf8 Class Initialized
INFO - 2016-10-24 10:50:14 --> URI Class Initialized
INFO - 2016-10-24 10:50:14 --> Router Class Initialized
INFO - 2016-10-24 10:50:14 --> Output Class Initialized
INFO - 2016-10-24 10:50:14 --> Security Class Initialized
DEBUG - 2016-10-24 10:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:50:14 --> Input Class Initialized
INFO - 2016-10-24 10:50:14 --> Language Class Initialized
INFO - 2016-10-24 10:50:14 --> Loader Class Initialized
INFO - 2016-10-24 10:50:14 --> Helper loaded: url_helper
INFO - 2016-10-24 10:50:14 --> Helper loaded: form_helper
INFO - 2016-10-24 10:50:14 --> Database Driver Class Initialized
INFO - 2016-10-24 10:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:50:14 --> Controller Class Initialized
DEBUG - 2016-10-24 10:50:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-24 10:50:14 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-24 10:50:14 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-24 10:50:14 --> Config Class Initialized
INFO - 2016-10-24 10:50:14 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:50:14 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:50:14 --> Utf8 Class Initialized
INFO - 2016-10-24 10:50:14 --> URI Class Initialized
DEBUG - 2016-10-24 10:50:14 --> No URI present. Default controller set.
INFO - 2016-10-24 10:50:14 --> Router Class Initialized
INFO - 2016-10-24 10:50:14 --> Output Class Initialized
INFO - 2016-10-24 10:50:14 --> Security Class Initialized
DEBUG - 2016-10-24 10:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:50:14 --> Input Class Initialized
INFO - 2016-10-24 10:50:14 --> Language Class Initialized
INFO - 2016-10-24 10:50:14 --> Loader Class Initialized
INFO - 2016-10-24 10:50:14 --> Helper loaded: url_helper
INFO - 2016-10-24 10:50:14 --> Helper loaded: form_helper
INFO - 2016-10-24 10:50:14 --> Database Driver Class Initialized
INFO - 2016-10-24 10:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:50:14 --> Controller Class Initialized
INFO - 2016-10-24 10:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 10:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-24 10:50:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 10:50:14 --> Final output sent to browser
DEBUG - 2016-10-24 10:50:14 --> Total execution time: 0.0045
INFO - 2016-10-24 10:50:30 --> Config Class Initialized
INFO - 2016-10-24 10:50:30 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:50:30 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:50:30 --> Utf8 Class Initialized
INFO - 2016-10-24 10:50:30 --> URI Class Initialized
INFO - 2016-10-24 10:50:30 --> Router Class Initialized
INFO - 2016-10-24 10:50:30 --> Output Class Initialized
INFO - 2016-10-24 10:50:30 --> Security Class Initialized
DEBUG - 2016-10-24 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:50:30 --> Input Class Initialized
INFO - 2016-10-24 10:50:30 --> Language Class Initialized
INFO - 2016-10-24 10:50:30 --> Loader Class Initialized
INFO - 2016-10-24 10:50:30 --> Helper loaded: url_helper
INFO - 2016-10-24 10:50:30 --> Helper loaded: form_helper
INFO - 2016-10-24 10:50:30 --> Database Driver Class Initialized
INFO - 2016-10-24 10:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:50:30 --> Controller Class Initialized
DEBUG - 2016-10-24 10:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-24 10:50:30 --> Model Class Initialized
INFO - 2016-10-24 10:50:30 --> Final output sent to browser
DEBUG - 2016-10-24 10:50:30 --> Total execution time: 0.0066
INFO - 2016-10-24 10:50:37 --> Config Class Initialized
INFO - 2016-10-24 10:50:37 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:50:37 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:50:37 --> Utf8 Class Initialized
INFO - 2016-10-24 10:50:37 --> URI Class Initialized
INFO - 2016-10-24 10:50:37 --> Router Class Initialized
INFO - 2016-10-24 10:50:37 --> Output Class Initialized
INFO - 2016-10-24 10:50:37 --> Security Class Initialized
DEBUG - 2016-10-24 10:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:50:37 --> Input Class Initialized
INFO - 2016-10-24 10:50:37 --> Language Class Initialized
INFO - 2016-10-24 10:50:37 --> Loader Class Initialized
INFO - 2016-10-24 10:50:37 --> Helper loaded: url_helper
INFO - 2016-10-24 10:50:37 --> Helper loaded: form_helper
INFO - 2016-10-24 10:50:37 --> Database Driver Class Initialized
INFO - 2016-10-24 10:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:50:37 --> Controller Class Initialized
DEBUG - 2016-10-24 10:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-24 10:50:37 --> Model Class Initialized
INFO - 2016-10-24 10:50:37 --> Final output sent to browser
DEBUG - 2016-10-24 10:50:37 --> Total execution time: 0.0057
INFO - 2016-10-24 10:50:37 --> Config Class Initialized
INFO - 2016-10-24 10:50:37 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:50:37 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:50:37 --> Utf8 Class Initialized
INFO - 2016-10-24 10:50:37 --> URI Class Initialized
DEBUG - 2016-10-24 10:50:37 --> No URI present. Default controller set.
INFO - 2016-10-24 10:50:37 --> Router Class Initialized
INFO - 2016-10-24 10:50:37 --> Output Class Initialized
INFO - 2016-10-24 10:50:37 --> Security Class Initialized
DEBUG - 2016-10-24 10:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:50:37 --> Input Class Initialized
INFO - 2016-10-24 10:50:37 --> Language Class Initialized
INFO - 2016-10-24 10:50:37 --> Loader Class Initialized
INFO - 2016-10-24 10:50:37 --> Helper loaded: url_helper
INFO - 2016-10-24 10:50:37 --> Helper loaded: form_helper
INFO - 2016-10-24 10:50:37 --> Database Driver Class Initialized
INFO - 2016-10-24 10:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:50:37 --> Controller Class Initialized
INFO - 2016-10-24 10:50:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 10:50:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 10:50:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 10:50:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 10:50:37 --> Final output sent to browser
DEBUG - 2016-10-24 10:50:37 --> Total execution time: 0.0047
INFO - 2016-10-24 10:50:41 --> Config Class Initialized
INFO - 2016-10-24 10:50:41 --> Hooks Class Initialized
DEBUG - 2016-10-24 10:50:41 --> UTF-8 Support Enabled
INFO - 2016-10-24 10:50:41 --> Utf8 Class Initialized
INFO - 2016-10-24 10:50:41 --> URI Class Initialized
DEBUG - 2016-10-24 10:50:41 --> No URI present. Default controller set.
INFO - 2016-10-24 10:50:41 --> Router Class Initialized
INFO - 2016-10-24 10:50:41 --> Output Class Initialized
INFO - 2016-10-24 10:50:41 --> Security Class Initialized
DEBUG - 2016-10-24 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 10:50:41 --> Input Class Initialized
INFO - 2016-10-24 10:50:41 --> Language Class Initialized
INFO - 2016-10-24 10:50:41 --> Loader Class Initialized
INFO - 2016-10-24 10:50:41 --> Helper loaded: url_helper
INFO - 2016-10-24 10:50:41 --> Helper loaded: form_helper
INFO - 2016-10-24 10:50:41 --> Database Driver Class Initialized
INFO - 2016-10-24 10:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 10:50:41 --> Controller Class Initialized
INFO - 2016-10-24 10:50:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 10:50:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 10:50:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 10:50:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 10:50:41 --> Final output sent to browser
DEBUG - 2016-10-24 10:50:41 --> Total execution time: 0.0054
INFO - 2016-10-24 11:56:16 --> Config Class Initialized
INFO - 2016-10-24 11:56:16 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:56:16 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:56:16 --> Utf8 Class Initialized
INFO - 2016-10-24 11:56:16 --> URI Class Initialized
INFO - 2016-10-24 11:56:16 --> Router Class Initialized
INFO - 2016-10-24 11:56:16 --> Output Class Initialized
INFO - 2016-10-24 11:56:16 --> Security Class Initialized
DEBUG - 2016-10-24 11:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:56:16 --> Input Class Initialized
INFO - 2016-10-24 11:56:16 --> Language Class Initialized
INFO - 2016-10-24 11:56:16 --> Loader Class Initialized
INFO - 2016-10-24 11:56:16 --> Helper loaded: url_helper
INFO - 2016-10-24 11:56:16 --> Helper loaded: form_helper
INFO - 2016-10-24 11:56:16 --> Database Driver Class Initialized
INFO - 2016-10-24 11:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:56:16 --> Controller Class Initialized
DEBUG - 2016-10-24 11:56:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-24 11:56:16 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-24 11:56:16 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-24 11:56:16 --> Config Class Initialized
INFO - 2016-10-24 11:56:16 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:56:16 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:56:16 --> Utf8 Class Initialized
INFO - 2016-10-24 11:56:16 --> URI Class Initialized
DEBUG - 2016-10-24 11:56:16 --> No URI present. Default controller set.
INFO - 2016-10-24 11:56:16 --> Router Class Initialized
INFO - 2016-10-24 11:56:16 --> Output Class Initialized
INFO - 2016-10-24 11:56:16 --> Security Class Initialized
DEBUG - 2016-10-24 11:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:56:16 --> Input Class Initialized
INFO - 2016-10-24 11:56:16 --> Language Class Initialized
INFO - 2016-10-24 11:56:16 --> Loader Class Initialized
INFO - 2016-10-24 11:56:16 --> Helper loaded: url_helper
INFO - 2016-10-24 11:56:16 --> Helper loaded: form_helper
INFO - 2016-10-24 11:56:16 --> Database Driver Class Initialized
INFO - 2016-10-24 11:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:56:16 --> Controller Class Initialized
INFO - 2016-10-24 11:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 11:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-24 11:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 11:56:16 --> Final output sent to browser
DEBUG - 2016-10-24 11:56:16 --> Total execution time: 0.0042
INFO - 2016-10-24 11:56:26 --> Config Class Initialized
INFO - 2016-10-24 11:56:26 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:56:26 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:56:26 --> Utf8 Class Initialized
INFO - 2016-10-24 11:56:26 --> URI Class Initialized
INFO - 2016-10-24 11:56:26 --> Router Class Initialized
INFO - 2016-10-24 11:56:26 --> Output Class Initialized
INFO - 2016-10-24 11:56:26 --> Security Class Initialized
DEBUG - 2016-10-24 11:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:56:26 --> Input Class Initialized
INFO - 2016-10-24 11:56:26 --> Language Class Initialized
INFO - 2016-10-24 11:56:26 --> Loader Class Initialized
INFO - 2016-10-24 11:56:26 --> Helper loaded: url_helper
INFO - 2016-10-24 11:56:26 --> Helper loaded: form_helper
INFO - 2016-10-24 11:56:26 --> Database Driver Class Initialized
INFO - 2016-10-24 11:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:56:26 --> Controller Class Initialized
DEBUG - 2016-10-24 11:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-24 11:56:26 --> Model Class Initialized
INFO - 2016-10-24 11:56:26 --> Final output sent to browser
DEBUG - 2016-10-24 11:56:26 --> Total execution time: 0.0086
INFO - 2016-10-24 11:56:31 --> Config Class Initialized
INFO - 2016-10-24 11:56:31 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:56:31 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:56:31 --> Utf8 Class Initialized
INFO - 2016-10-24 11:56:31 --> URI Class Initialized
INFO - 2016-10-24 11:56:31 --> Router Class Initialized
INFO - 2016-10-24 11:56:31 --> Output Class Initialized
INFO - 2016-10-24 11:56:31 --> Security Class Initialized
DEBUG - 2016-10-24 11:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:56:31 --> Input Class Initialized
INFO - 2016-10-24 11:56:31 --> Language Class Initialized
INFO - 2016-10-24 11:56:31 --> Loader Class Initialized
INFO - 2016-10-24 11:56:31 --> Helper loaded: url_helper
INFO - 2016-10-24 11:56:31 --> Helper loaded: form_helper
INFO - 2016-10-24 11:56:31 --> Database Driver Class Initialized
INFO - 2016-10-24 11:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:56:31 --> Controller Class Initialized
DEBUG - 2016-10-24 11:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-24 11:56:31 --> Model Class Initialized
INFO - 2016-10-24 11:56:31 --> Final output sent to browser
DEBUG - 2016-10-24 11:56:31 --> Total execution time: 0.0091
INFO - 2016-10-24 11:56:31 --> Config Class Initialized
INFO - 2016-10-24 11:56:31 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:56:31 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:56:31 --> Utf8 Class Initialized
INFO - 2016-10-24 11:56:31 --> URI Class Initialized
DEBUG - 2016-10-24 11:56:31 --> No URI present. Default controller set.
INFO - 2016-10-24 11:56:31 --> Router Class Initialized
INFO - 2016-10-24 11:56:31 --> Output Class Initialized
INFO - 2016-10-24 11:56:31 --> Security Class Initialized
DEBUG - 2016-10-24 11:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:56:31 --> Input Class Initialized
INFO - 2016-10-24 11:56:31 --> Language Class Initialized
INFO - 2016-10-24 11:56:31 --> Loader Class Initialized
INFO - 2016-10-24 11:56:31 --> Helper loaded: url_helper
INFO - 2016-10-24 11:56:31 --> Helper loaded: form_helper
INFO - 2016-10-24 11:56:31 --> Database Driver Class Initialized
INFO - 2016-10-24 11:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:56:31 --> Controller Class Initialized
INFO - 2016-10-24 11:56:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 11:56:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 11:56:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 11:56:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 11:56:31 --> Final output sent to browser
DEBUG - 2016-10-24 11:56:31 --> Total execution time: 0.0043
INFO - 2016-10-24 11:59:18 --> Config Class Initialized
INFO - 2016-10-24 11:59:18 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:59:18 --> Utf8 Class Initialized
INFO - 2016-10-24 11:59:18 --> URI Class Initialized
INFO - 2016-10-24 11:59:18 --> Router Class Initialized
INFO - 2016-10-24 11:59:18 --> Output Class Initialized
INFO - 2016-10-24 11:59:18 --> Security Class Initialized
DEBUG - 2016-10-24 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:59:18 --> Input Class Initialized
INFO - 2016-10-24 11:59:18 --> Language Class Initialized
INFO - 2016-10-24 11:59:18 --> Loader Class Initialized
INFO - 2016-10-24 11:59:18 --> Helper loaded: url_helper
INFO - 2016-10-24 11:59:18 --> Helper loaded: form_helper
INFO - 2016-10-24 11:59:18 --> Database Driver Class Initialized
INFO - 2016-10-24 11:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:59:18 --> Controller Class Initialized
DEBUG - 2016-10-24 11:59:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-24 11:59:18 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-24 11:59:18 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-24 11:59:18 --> Config Class Initialized
INFO - 2016-10-24 11:59:18 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:59:18 --> Utf8 Class Initialized
INFO - 2016-10-24 11:59:18 --> URI Class Initialized
DEBUG - 2016-10-24 11:59:18 --> No URI present. Default controller set.
INFO - 2016-10-24 11:59:18 --> Router Class Initialized
INFO - 2016-10-24 11:59:18 --> Output Class Initialized
INFO - 2016-10-24 11:59:18 --> Security Class Initialized
DEBUG - 2016-10-24 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:59:18 --> Input Class Initialized
INFO - 2016-10-24 11:59:18 --> Language Class Initialized
INFO - 2016-10-24 11:59:18 --> Loader Class Initialized
INFO - 2016-10-24 11:59:18 --> Helper loaded: url_helper
INFO - 2016-10-24 11:59:18 --> Helper loaded: form_helper
INFO - 2016-10-24 11:59:18 --> Database Driver Class Initialized
INFO - 2016-10-24 11:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:59:18 --> Controller Class Initialized
INFO - 2016-10-24 11:59:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 11:59:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-24 11:59:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 11:59:18 --> Final output sent to browser
DEBUG - 2016-10-24 11:59:18 --> Total execution time: 0.0051
INFO - 2016-10-24 11:59:30 --> Config Class Initialized
INFO - 2016-10-24 11:59:30 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:59:30 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:59:30 --> Utf8 Class Initialized
INFO - 2016-10-24 11:59:30 --> URI Class Initialized
INFO - 2016-10-24 11:59:30 --> Router Class Initialized
INFO - 2016-10-24 11:59:30 --> Output Class Initialized
INFO - 2016-10-24 11:59:30 --> Security Class Initialized
DEBUG - 2016-10-24 11:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:59:30 --> Input Class Initialized
INFO - 2016-10-24 11:59:30 --> Language Class Initialized
INFO - 2016-10-24 11:59:30 --> Loader Class Initialized
INFO - 2016-10-24 11:59:30 --> Helper loaded: url_helper
INFO - 2016-10-24 11:59:30 --> Helper loaded: form_helper
INFO - 2016-10-24 11:59:30 --> Database Driver Class Initialized
INFO - 2016-10-24 11:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:59:30 --> Controller Class Initialized
DEBUG - 2016-10-24 11:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-24 11:59:30 --> Model Class Initialized
INFO - 2016-10-24 11:59:30 --> Final output sent to browser
DEBUG - 2016-10-24 11:59:30 --> Total execution time: 0.0089
INFO - 2016-10-24 11:59:30 --> Config Class Initialized
INFO - 2016-10-24 11:59:30 --> Hooks Class Initialized
DEBUG - 2016-10-24 11:59:30 --> UTF-8 Support Enabled
INFO - 2016-10-24 11:59:30 --> Utf8 Class Initialized
INFO - 2016-10-24 11:59:30 --> URI Class Initialized
DEBUG - 2016-10-24 11:59:30 --> No URI present. Default controller set.
INFO - 2016-10-24 11:59:30 --> Router Class Initialized
INFO - 2016-10-24 11:59:30 --> Output Class Initialized
INFO - 2016-10-24 11:59:30 --> Security Class Initialized
DEBUG - 2016-10-24 11:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-24 11:59:30 --> Input Class Initialized
INFO - 2016-10-24 11:59:30 --> Language Class Initialized
INFO - 2016-10-24 11:59:30 --> Loader Class Initialized
INFO - 2016-10-24 11:59:30 --> Helper loaded: url_helper
INFO - 2016-10-24 11:59:30 --> Helper loaded: form_helper
INFO - 2016-10-24 11:59:30 --> Database Driver Class Initialized
INFO - 2016-10-24 11:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-24 11:59:30 --> Controller Class Initialized
INFO - 2016-10-24 11:59:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-24 11:59:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-24 11:59:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-24 11:59:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-24 11:59:30 --> Final output sent to browser
DEBUG - 2016-10-24 11:59:30 --> Total execution time: 0.0045
