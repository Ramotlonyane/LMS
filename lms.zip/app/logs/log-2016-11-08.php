<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-08 10:17:57 --> Config Class Initialized
INFO - 2016-11-08 10:17:57 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:17:57 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:17:57 --> Utf8 Class Initialized
INFO - 2016-11-08 10:17:57 --> URI Class Initialized
INFO - 2016-11-08 10:17:57 --> Router Class Initialized
INFO - 2016-11-08 10:17:57 --> Output Class Initialized
INFO - 2016-11-08 10:17:57 --> Security Class Initialized
DEBUG - 2016-11-08 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:17:58 --> Input Class Initialized
INFO - 2016-11-08 10:17:58 --> Language Class Initialized
INFO - 2016-11-08 10:17:58 --> Loader Class Initialized
INFO - 2016-11-08 10:17:58 --> Helper loaded: url_helper
INFO - 2016-11-08 10:17:58 --> Helper loaded: form_helper
INFO - 2016-11-08 10:17:58 --> Database Driver Class Initialized
INFO - 2016-11-08 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:17:59 --> Controller Class Initialized
INFO - 2016-11-08 10:17:59 --> Model Class Initialized
INFO - 2016-11-08 10:17:59 --> Model Class Initialized
DEBUG - 2016-11-08 10:17:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 10:17:59 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 10:17:59 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 10:17:59 --> Config Class Initialized
INFO - 2016-11-08 10:17:59 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:17:59 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:17:59 --> Utf8 Class Initialized
INFO - 2016-11-08 10:17:59 --> URI Class Initialized
DEBUG - 2016-11-08 10:17:59 --> No URI present. Default controller set.
INFO - 2016-11-08 10:17:59 --> Router Class Initialized
INFO - 2016-11-08 10:17:59 --> Output Class Initialized
INFO - 2016-11-08 10:17:59 --> Security Class Initialized
DEBUG - 2016-11-08 10:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:17:59 --> Input Class Initialized
INFO - 2016-11-08 10:17:59 --> Language Class Initialized
INFO - 2016-11-08 10:17:59 --> Loader Class Initialized
INFO - 2016-11-08 10:17:59 --> Helper loaded: url_helper
INFO - 2016-11-08 10:17:59 --> Helper loaded: form_helper
INFO - 2016-11-08 10:17:59 --> Database Driver Class Initialized
INFO - 2016-11-08 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:17:59 --> Controller Class Initialized
INFO - 2016-11-08 10:17:59 --> Model Class Initialized
INFO - 2016-11-08 10:17:59 --> Model Class Initialized
INFO - 2016-11-08 10:17:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 10:17:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 10:17:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 10:18:00 --> Final output sent to browser
DEBUG - 2016-11-08 10:18:00 --> Total execution time: 0.4083
INFO - 2016-11-08 10:25:13 --> Config Class Initialized
INFO - 2016-11-08 10:25:13 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:25:13 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:25:13 --> Utf8 Class Initialized
INFO - 2016-11-08 10:25:13 --> URI Class Initialized
INFO - 2016-11-08 10:25:13 --> Router Class Initialized
INFO - 2016-11-08 10:25:13 --> Output Class Initialized
INFO - 2016-11-08 10:25:13 --> Security Class Initialized
DEBUG - 2016-11-08 10:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:25:13 --> Input Class Initialized
INFO - 2016-11-08 10:25:13 --> Language Class Initialized
INFO - 2016-11-08 10:25:13 --> Loader Class Initialized
INFO - 2016-11-08 10:25:13 --> Helper loaded: url_helper
INFO - 2016-11-08 10:25:13 --> Helper loaded: form_helper
INFO - 2016-11-08 10:25:13 --> Database Driver Class Initialized
INFO - 2016-11-08 10:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:25:13 --> Controller Class Initialized
INFO - 2016-11-08 10:25:13 --> Model Class Initialized
INFO - 2016-11-08 10:25:13 --> Model Class Initialized
DEBUG - 2016-11-08 10:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 10:25:13 --> Model Class Initialized
INFO - 2016-11-08 10:25:13 --> Final output sent to browser
DEBUG - 2016-11-08 10:25:13 --> Total execution time: 0.4661
INFO - 2016-11-08 10:25:19 --> Config Class Initialized
INFO - 2016-11-08 10:25:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:25:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:25:19 --> Utf8 Class Initialized
INFO - 2016-11-08 10:25:19 --> URI Class Initialized
INFO - 2016-11-08 10:25:19 --> Router Class Initialized
INFO - 2016-11-08 10:25:19 --> Output Class Initialized
INFO - 2016-11-08 10:25:19 --> Security Class Initialized
DEBUG - 2016-11-08 10:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:25:19 --> Input Class Initialized
INFO - 2016-11-08 10:25:19 --> Language Class Initialized
INFO - 2016-11-08 10:25:19 --> Loader Class Initialized
INFO - 2016-11-08 10:25:19 --> Helper loaded: url_helper
INFO - 2016-11-08 10:25:19 --> Helper loaded: form_helper
INFO - 2016-11-08 10:25:19 --> Database Driver Class Initialized
INFO - 2016-11-08 10:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:25:19 --> Controller Class Initialized
INFO - 2016-11-08 10:25:19 --> Model Class Initialized
INFO - 2016-11-08 10:25:19 --> Model Class Initialized
DEBUG - 2016-11-08 10:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 10:25:19 --> Model Class Initialized
INFO - 2016-11-08 10:25:19 --> Final output sent to browser
DEBUG - 2016-11-08 10:25:19 --> Total execution time: 0.1693
INFO - 2016-11-08 10:26:22 --> Config Class Initialized
INFO - 2016-11-08 10:26:22 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:26:22 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:26:22 --> Utf8 Class Initialized
INFO - 2016-11-08 10:26:22 --> URI Class Initialized
INFO - 2016-11-08 10:26:22 --> Router Class Initialized
INFO - 2016-11-08 10:26:22 --> Output Class Initialized
INFO - 2016-11-08 10:26:22 --> Security Class Initialized
DEBUG - 2016-11-08 10:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:26:22 --> Input Class Initialized
INFO - 2016-11-08 10:26:22 --> Language Class Initialized
INFO - 2016-11-08 10:26:22 --> Loader Class Initialized
INFO - 2016-11-08 10:26:22 --> Helper loaded: url_helper
INFO - 2016-11-08 10:26:22 --> Helper loaded: form_helper
INFO - 2016-11-08 10:26:22 --> Database Driver Class Initialized
INFO - 2016-11-08 10:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:26:22 --> Controller Class Initialized
INFO - 2016-11-08 10:26:22 --> Model Class Initialized
INFO - 2016-11-08 10:26:22 --> Model Class Initialized
DEBUG - 2016-11-08 10:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 10:26:22 --> Model Class Initialized
INFO - 2016-11-08 10:26:22 --> Final output sent to browser
DEBUG - 2016-11-08 10:26:22 --> Total execution time: 0.1633
INFO - 2016-11-08 10:26:22 --> Config Class Initialized
INFO - 2016-11-08 10:26:22 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:26:22 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:26:22 --> Utf8 Class Initialized
INFO - 2016-11-08 10:26:22 --> URI Class Initialized
DEBUG - 2016-11-08 10:26:22 --> No URI present. Default controller set.
INFO - 2016-11-08 10:26:22 --> Router Class Initialized
INFO - 2016-11-08 10:26:22 --> Output Class Initialized
INFO - 2016-11-08 10:26:22 --> Security Class Initialized
DEBUG - 2016-11-08 10:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:26:22 --> Input Class Initialized
INFO - 2016-11-08 10:26:22 --> Language Class Initialized
INFO - 2016-11-08 10:26:22 --> Loader Class Initialized
INFO - 2016-11-08 10:26:22 --> Helper loaded: url_helper
INFO - 2016-11-08 10:26:22 --> Helper loaded: form_helper
INFO - 2016-11-08 10:26:22 --> Database Driver Class Initialized
INFO - 2016-11-08 10:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:26:22 --> Controller Class Initialized
INFO - 2016-11-08 10:26:22 --> Model Class Initialized
INFO - 2016-11-08 10:26:22 --> Model Class Initialized
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 10:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 10:26:22 --> Final output sent to browser
DEBUG - 2016-11-08 10:26:22 --> Total execution time: 0.6656
INFO - 2016-11-08 10:42:21 --> Config Class Initialized
INFO - 2016-11-08 10:42:21 --> Hooks Class Initialized
DEBUG - 2016-11-08 10:42:21 --> UTF-8 Support Enabled
INFO - 2016-11-08 10:42:21 --> Utf8 Class Initialized
INFO - 2016-11-08 10:42:21 --> URI Class Initialized
DEBUG - 2016-11-08 10:42:21 --> No URI present. Default controller set.
INFO - 2016-11-08 10:42:21 --> Router Class Initialized
INFO - 2016-11-08 10:42:21 --> Output Class Initialized
INFO - 2016-11-08 10:42:21 --> Security Class Initialized
DEBUG - 2016-11-08 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 10:42:21 --> Input Class Initialized
INFO - 2016-11-08 10:42:21 --> Language Class Initialized
INFO - 2016-11-08 10:42:21 --> Loader Class Initialized
INFO - 2016-11-08 10:42:21 --> Helper loaded: url_helper
INFO - 2016-11-08 10:42:21 --> Helper loaded: form_helper
INFO - 2016-11-08 10:42:21 --> Database Driver Class Initialized
INFO - 2016-11-08 10:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 10:42:21 --> Controller Class Initialized
INFO - 2016-11-08 10:42:21 --> Model Class Initialized
INFO - 2016-11-08 10:42:21 --> Model Class Initialized
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 10:42:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 10:42:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 10:42:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 10:42:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 10:42:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 10:42:22 --> Final output sent to browser
DEBUG - 2016-11-08 10:42:22 --> Total execution time: 0.3338
INFO - 2016-11-08 15:21:06 --> Config Class Initialized
INFO - 2016-11-08 15:21:06 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:21:06 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:21:06 --> Utf8 Class Initialized
INFO - 2016-11-08 15:21:06 --> URI Class Initialized
DEBUG - 2016-11-08 15:21:06 --> No URI present. Default controller set.
INFO - 2016-11-08 15:21:06 --> Router Class Initialized
INFO - 2016-11-08 15:21:06 --> Output Class Initialized
INFO - 2016-11-08 15:21:06 --> Security Class Initialized
DEBUG - 2016-11-08 15:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:21:07 --> Input Class Initialized
INFO - 2016-11-08 15:21:07 --> Language Class Initialized
INFO - 2016-11-08 15:21:07 --> Loader Class Initialized
INFO - 2016-11-08 15:21:07 --> Helper loaded: url_helper
INFO - 2016-11-08 15:21:07 --> Helper loaded: form_helper
INFO - 2016-11-08 15:21:07 --> Database Driver Class Initialized
INFO - 2016-11-08 15:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:21:07 --> Controller Class Initialized
INFO - 2016-11-08 15:21:07 --> Model Class Initialized
INFO - 2016-11-08 15:21:07 --> Model Class Initialized
INFO - 2016-11-08 15:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:21:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:21:07 --> Final output sent to browser
DEBUG - 2016-11-08 15:21:07 --> Total execution time: 1.5220
INFO - 2016-11-08 15:21:56 --> Config Class Initialized
INFO - 2016-11-08 15:21:56 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:21:56 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:21:56 --> Utf8 Class Initialized
INFO - 2016-11-08 15:21:56 --> URI Class Initialized
DEBUG - 2016-11-08 15:21:56 --> No URI present. Default controller set.
INFO - 2016-11-08 15:21:56 --> Router Class Initialized
INFO - 2016-11-08 15:21:56 --> Output Class Initialized
INFO - 2016-11-08 15:21:56 --> Security Class Initialized
DEBUG - 2016-11-08 15:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:21:56 --> Input Class Initialized
INFO - 2016-11-08 15:21:56 --> Language Class Initialized
INFO - 2016-11-08 15:21:56 --> Loader Class Initialized
INFO - 2016-11-08 15:21:56 --> Helper loaded: url_helper
INFO - 2016-11-08 15:21:56 --> Helper loaded: form_helper
INFO - 2016-11-08 15:21:56 --> Database Driver Class Initialized
INFO - 2016-11-08 15:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:21:56 --> Controller Class Initialized
INFO - 2016-11-08 15:21:56 --> Model Class Initialized
INFO - 2016-11-08 15:21:56 --> Model Class Initialized
INFO - 2016-11-08 15:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:21:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:21:56 --> Final output sent to browser
DEBUG - 2016-11-08 15:21:56 --> Total execution time: 0.1806
INFO - 2016-11-08 15:22:15 --> Config Class Initialized
INFO - 2016-11-08 15:22:15 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:22:15 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:22:15 --> Utf8 Class Initialized
INFO - 2016-11-08 15:22:15 --> URI Class Initialized
INFO - 2016-11-08 15:22:15 --> Router Class Initialized
INFO - 2016-11-08 15:22:15 --> Output Class Initialized
INFO - 2016-11-08 15:22:15 --> Security Class Initialized
DEBUG - 2016-11-08 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:22:15 --> Input Class Initialized
INFO - 2016-11-08 15:22:15 --> Language Class Initialized
INFO - 2016-11-08 15:22:15 --> Loader Class Initialized
INFO - 2016-11-08 15:22:15 --> Helper loaded: url_helper
INFO - 2016-11-08 15:22:15 --> Helper loaded: form_helper
INFO - 2016-11-08 15:22:15 --> Database Driver Class Initialized
INFO - 2016-11-08 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:22:15 --> Controller Class Initialized
INFO - 2016-11-08 15:22:15 --> Model Class Initialized
INFO - 2016-11-08 15:22:15 --> Model Class Initialized
DEBUG - 2016-11-08 15:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:22:15 --> Model Class Initialized
INFO - 2016-11-08 15:22:15 --> Final output sent to browser
DEBUG - 2016-11-08 15:22:15 --> Total execution time: 0.2036
INFO - 2016-11-08 15:22:15 --> Config Class Initialized
INFO - 2016-11-08 15:22:15 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:22:15 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:22:15 --> Utf8 Class Initialized
INFO - 2016-11-08 15:22:15 --> URI Class Initialized
DEBUG - 2016-11-08 15:22:15 --> No URI present. Default controller set.
INFO - 2016-11-08 15:22:15 --> Router Class Initialized
INFO - 2016-11-08 15:22:15 --> Output Class Initialized
INFO - 2016-11-08 15:22:15 --> Security Class Initialized
DEBUG - 2016-11-08 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:22:15 --> Input Class Initialized
INFO - 2016-11-08 15:22:15 --> Language Class Initialized
INFO - 2016-11-08 15:22:15 --> Loader Class Initialized
INFO - 2016-11-08 15:22:15 --> Helper loaded: url_helper
INFO - 2016-11-08 15:22:15 --> Helper loaded: form_helper
INFO - 2016-11-08 15:22:15 --> Database Driver Class Initialized
INFO - 2016-11-08 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:22:15 --> Controller Class Initialized
INFO - 2016-11-08 15:22:15 --> Model Class Initialized
INFO - 2016-11-08 15:22:15 --> Model Class Initialized
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:22:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:22:15 --> Final output sent to browser
DEBUG - 2016-11-08 15:22:15 --> Total execution time: 0.3103
INFO - 2016-11-08 15:26:25 --> Config Class Initialized
INFO - 2016-11-08 15:26:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:26:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:26:25 --> Utf8 Class Initialized
INFO - 2016-11-08 15:26:25 --> URI Class Initialized
INFO - 2016-11-08 15:26:25 --> Router Class Initialized
INFO - 2016-11-08 15:26:25 --> Output Class Initialized
INFO - 2016-11-08 15:26:25 --> Security Class Initialized
DEBUG - 2016-11-08 15:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:26:25 --> Input Class Initialized
INFO - 2016-11-08 15:26:25 --> Language Class Initialized
INFO - 2016-11-08 15:26:25 --> Loader Class Initialized
INFO - 2016-11-08 15:26:25 --> Helper loaded: url_helper
INFO - 2016-11-08 15:26:25 --> Helper loaded: form_helper
INFO - 2016-11-08 15:26:25 --> Database Driver Class Initialized
INFO - 2016-11-08 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:26:25 --> Controller Class Initialized
INFO - 2016-11-08 15:26:25 --> Model Class Initialized
INFO - 2016-11-08 15:26:25 --> Form Validation Class Initialized
INFO - 2016-11-08 15:26:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:26:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:26:25 --> Final output sent to browser
DEBUG - 2016-11-08 15:26:25 --> Total execution time: 0.4807
INFO - 2016-11-08 15:26:27 --> Config Class Initialized
INFO - 2016-11-08 15:26:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:26:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:26:27 --> Utf8 Class Initialized
INFO - 2016-11-08 15:26:27 --> URI Class Initialized
DEBUG - 2016-11-08 15:26:27 --> No URI present. Default controller set.
INFO - 2016-11-08 15:26:27 --> Router Class Initialized
INFO - 2016-11-08 15:26:27 --> Output Class Initialized
INFO - 2016-11-08 15:26:27 --> Security Class Initialized
DEBUG - 2016-11-08 15:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:26:27 --> Input Class Initialized
INFO - 2016-11-08 15:26:27 --> Language Class Initialized
INFO - 2016-11-08 15:26:27 --> Loader Class Initialized
INFO - 2016-11-08 15:26:27 --> Helper loaded: url_helper
INFO - 2016-11-08 15:26:27 --> Helper loaded: form_helper
INFO - 2016-11-08 15:26:27 --> Database Driver Class Initialized
INFO - 2016-11-08 15:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:26:27 --> Controller Class Initialized
INFO - 2016-11-08 15:26:27 --> Model Class Initialized
INFO - 2016-11-08 15:26:27 --> Model Class Initialized
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:26:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:26:27 --> Final output sent to browser
DEBUG - 2016-11-08 15:26:27 --> Total execution time: 0.2957
INFO - 2016-11-08 15:28:10 --> Config Class Initialized
INFO - 2016-11-08 15:28:10 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:28:10 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:28:10 --> Utf8 Class Initialized
INFO - 2016-11-08 15:28:10 --> URI Class Initialized
INFO - 2016-11-08 15:28:10 --> Router Class Initialized
INFO - 2016-11-08 15:28:10 --> Output Class Initialized
INFO - 2016-11-08 15:28:10 --> Security Class Initialized
DEBUG - 2016-11-08 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:28:10 --> Input Class Initialized
INFO - 2016-11-08 15:28:10 --> Language Class Initialized
INFO - 2016-11-08 15:28:10 --> Loader Class Initialized
INFO - 2016-11-08 15:28:10 --> Helper loaded: url_helper
INFO - 2016-11-08 15:28:10 --> Helper loaded: form_helper
INFO - 2016-11-08 15:28:10 --> Database Driver Class Initialized
INFO - 2016-11-08 15:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:28:10 --> Controller Class Initialized
INFO - 2016-11-08 15:28:10 --> Model Class Initialized
INFO - 2016-11-08 15:28:10 --> Form Validation Class Initialized
INFO - 2016-11-08 15:28:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:28:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:28:10 --> Final output sent to browser
DEBUG - 2016-11-08 15:28:10 --> Total execution time: 0.2867
INFO - 2016-11-08 15:28:12 --> Config Class Initialized
INFO - 2016-11-08 15:28:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:28:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:28:12 --> Utf8 Class Initialized
INFO - 2016-11-08 15:28:12 --> URI Class Initialized
DEBUG - 2016-11-08 15:28:12 --> No URI present. Default controller set.
INFO - 2016-11-08 15:28:12 --> Router Class Initialized
INFO - 2016-11-08 15:28:12 --> Output Class Initialized
INFO - 2016-11-08 15:28:12 --> Security Class Initialized
DEBUG - 2016-11-08 15:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:28:12 --> Input Class Initialized
INFO - 2016-11-08 15:28:12 --> Language Class Initialized
INFO - 2016-11-08 15:28:12 --> Loader Class Initialized
INFO - 2016-11-08 15:28:12 --> Helper loaded: url_helper
INFO - 2016-11-08 15:28:12 --> Helper loaded: form_helper
INFO - 2016-11-08 15:28:12 --> Database Driver Class Initialized
INFO - 2016-11-08 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:28:12 --> Controller Class Initialized
INFO - 2016-11-08 15:28:12 --> Model Class Initialized
INFO - 2016-11-08 15:28:12 --> Model Class Initialized
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:28:12 --> Final output sent to browser
DEBUG - 2016-11-08 15:28:12 --> Total execution time: 0.2932
INFO - 2016-11-08 15:29:52 --> Config Class Initialized
INFO - 2016-11-08 15:29:52 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:29:52 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:29:52 --> Utf8 Class Initialized
INFO - 2016-11-08 15:29:52 --> URI Class Initialized
INFO - 2016-11-08 15:29:52 --> Router Class Initialized
INFO - 2016-11-08 15:29:52 --> Output Class Initialized
INFO - 2016-11-08 15:29:52 --> Security Class Initialized
DEBUG - 2016-11-08 15:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:29:52 --> Input Class Initialized
INFO - 2016-11-08 15:29:52 --> Language Class Initialized
INFO - 2016-11-08 15:29:52 --> Loader Class Initialized
INFO - 2016-11-08 15:29:52 --> Helper loaded: url_helper
INFO - 2016-11-08 15:29:52 --> Helper loaded: form_helper
INFO - 2016-11-08 15:29:52 --> Database Driver Class Initialized
INFO - 2016-11-08 15:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:29:52 --> Controller Class Initialized
INFO - 2016-11-08 15:29:52 --> Model Class Initialized
INFO - 2016-11-08 15:29:52 --> Form Validation Class Initialized
INFO - 2016-11-08 15:29:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:29:52 --> Final output sent to browser
DEBUG - 2016-11-08 15:29:52 --> Total execution time: 0.1810
INFO - 2016-11-08 15:29:55 --> Config Class Initialized
INFO - 2016-11-08 15:29:55 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:29:55 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:29:55 --> Utf8 Class Initialized
INFO - 2016-11-08 15:29:55 --> URI Class Initialized
DEBUG - 2016-11-08 15:29:55 --> No URI present. Default controller set.
INFO - 2016-11-08 15:29:55 --> Router Class Initialized
INFO - 2016-11-08 15:29:55 --> Output Class Initialized
INFO - 2016-11-08 15:29:55 --> Security Class Initialized
DEBUG - 2016-11-08 15:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:29:55 --> Input Class Initialized
INFO - 2016-11-08 15:29:55 --> Language Class Initialized
INFO - 2016-11-08 15:29:55 --> Loader Class Initialized
INFO - 2016-11-08 15:29:55 --> Helper loaded: url_helper
INFO - 2016-11-08 15:29:55 --> Helper loaded: form_helper
INFO - 2016-11-08 15:29:55 --> Database Driver Class Initialized
INFO - 2016-11-08 15:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:29:55 --> Controller Class Initialized
INFO - 2016-11-08 15:29:55 --> Model Class Initialized
INFO - 2016-11-08 15:29:55 --> Model Class Initialized
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:29:55 --> Final output sent to browser
DEBUG - 2016-11-08 15:29:55 --> Total execution time: 0.2689
INFO - 2016-11-08 15:30:16 --> Config Class Initialized
INFO - 2016-11-08 15:30:16 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:30:16 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:30:16 --> Utf8 Class Initialized
INFO - 2016-11-08 15:30:16 --> URI Class Initialized
INFO - 2016-11-08 15:30:16 --> Router Class Initialized
INFO - 2016-11-08 15:30:16 --> Output Class Initialized
INFO - 2016-11-08 15:30:16 --> Security Class Initialized
DEBUG - 2016-11-08 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:30:16 --> Input Class Initialized
INFO - 2016-11-08 15:30:16 --> Language Class Initialized
INFO - 2016-11-08 15:30:16 --> Loader Class Initialized
INFO - 2016-11-08 15:30:16 --> Helper loaded: url_helper
INFO - 2016-11-08 15:30:16 --> Helper loaded: form_helper
INFO - 2016-11-08 15:30:16 --> Database Driver Class Initialized
INFO - 2016-11-08 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:30:16 --> Controller Class Initialized
INFO - 2016-11-08 15:30:16 --> Model Class Initialized
INFO - 2016-11-08 15:30:16 --> Form Validation Class Initialized
INFO - 2016-11-08 15:30:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:30:16 --> Final output sent to browser
DEBUG - 2016-11-08 15:30:16 --> Total execution time: 0.3053
INFO - 2016-11-08 15:30:19 --> Config Class Initialized
INFO - 2016-11-08 15:30:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:30:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:30:19 --> Utf8 Class Initialized
INFO - 2016-11-08 15:30:19 --> URI Class Initialized
DEBUG - 2016-11-08 15:30:19 --> No URI present. Default controller set.
INFO - 2016-11-08 15:30:19 --> Router Class Initialized
INFO - 2016-11-08 15:30:19 --> Output Class Initialized
INFO - 2016-11-08 15:30:19 --> Security Class Initialized
DEBUG - 2016-11-08 15:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:30:19 --> Input Class Initialized
INFO - 2016-11-08 15:30:19 --> Language Class Initialized
INFO - 2016-11-08 15:30:19 --> Loader Class Initialized
INFO - 2016-11-08 15:30:19 --> Helper loaded: url_helper
INFO - 2016-11-08 15:30:19 --> Helper loaded: form_helper
INFO - 2016-11-08 15:30:19 --> Database Driver Class Initialized
INFO - 2016-11-08 15:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:30:19 --> Controller Class Initialized
INFO - 2016-11-08 15:30:19 --> Model Class Initialized
INFO - 2016-11-08 15:30:19 --> Model Class Initialized
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:30:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:30:19 --> Final output sent to browser
DEBUG - 2016-11-08 15:30:19 --> Total execution time: 0.2846
INFO - 2016-11-08 15:30:35 --> Config Class Initialized
INFO - 2016-11-08 15:30:35 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:30:35 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:30:35 --> Utf8 Class Initialized
INFO - 2016-11-08 15:30:35 --> URI Class Initialized
INFO - 2016-11-08 15:30:35 --> Router Class Initialized
INFO - 2016-11-08 15:30:35 --> Output Class Initialized
INFO - 2016-11-08 15:30:35 --> Security Class Initialized
DEBUG - 2016-11-08 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:30:35 --> Input Class Initialized
INFO - 2016-11-08 15:30:35 --> Language Class Initialized
INFO - 2016-11-08 15:30:35 --> Loader Class Initialized
INFO - 2016-11-08 15:30:35 --> Helper loaded: url_helper
INFO - 2016-11-08 15:30:35 --> Helper loaded: form_helper
INFO - 2016-11-08 15:30:35 --> Database Driver Class Initialized
INFO - 2016-11-08 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:30:35 --> Controller Class Initialized
INFO - 2016-11-08 15:30:35 --> Model Class Initialized
INFO - 2016-11-08 15:30:35 --> Form Validation Class Initialized
INFO - 2016-11-08 15:30:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:30:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:30:35 --> Final output sent to browser
DEBUG - 2016-11-08 15:30:35 --> Total execution time: 0.2835
INFO - 2016-11-08 15:30:36 --> Config Class Initialized
INFO - 2016-11-08 15:30:36 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:30:36 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:30:36 --> Utf8 Class Initialized
INFO - 2016-11-08 15:30:36 --> URI Class Initialized
DEBUG - 2016-11-08 15:30:36 --> No URI present. Default controller set.
INFO - 2016-11-08 15:30:36 --> Router Class Initialized
INFO - 2016-11-08 15:30:36 --> Output Class Initialized
INFO - 2016-11-08 15:30:36 --> Security Class Initialized
DEBUG - 2016-11-08 15:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:30:36 --> Input Class Initialized
INFO - 2016-11-08 15:30:36 --> Language Class Initialized
INFO - 2016-11-08 15:30:36 --> Loader Class Initialized
INFO - 2016-11-08 15:30:36 --> Helper loaded: url_helper
INFO - 2016-11-08 15:30:36 --> Helper loaded: form_helper
INFO - 2016-11-08 15:30:36 --> Database Driver Class Initialized
INFO - 2016-11-08 15:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:30:36 --> Controller Class Initialized
INFO - 2016-11-08 15:30:36 --> Model Class Initialized
INFO - 2016-11-08 15:30:36 --> Model Class Initialized
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:30:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:30:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:30:37 --> Final output sent to browser
DEBUG - 2016-11-08 15:30:37 --> Total execution time: 0.3016
INFO - 2016-11-08 15:32:34 --> Config Class Initialized
INFO - 2016-11-08 15:32:34 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:32:34 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:32:34 --> Utf8 Class Initialized
INFO - 2016-11-08 15:32:34 --> URI Class Initialized
INFO - 2016-11-08 15:32:34 --> Router Class Initialized
INFO - 2016-11-08 15:32:34 --> Output Class Initialized
INFO - 2016-11-08 15:32:34 --> Security Class Initialized
DEBUG - 2016-11-08 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:32:34 --> Input Class Initialized
INFO - 2016-11-08 15:32:34 --> Language Class Initialized
INFO - 2016-11-08 15:32:34 --> Loader Class Initialized
INFO - 2016-11-08 15:32:34 --> Helper loaded: url_helper
INFO - 2016-11-08 15:32:34 --> Helper loaded: form_helper
INFO - 2016-11-08 15:32:34 --> Database Driver Class Initialized
INFO - 2016-11-08 15:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:32:35 --> Controller Class Initialized
INFO - 2016-11-08 15:32:35 --> Model Class Initialized
INFO - 2016-11-08 15:32:35 --> Form Validation Class Initialized
INFO - 2016-11-08 15:32:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:32:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:32:35 --> Final output sent to browser
DEBUG - 2016-11-08 15:32:35 --> Total execution time: 0.4125
INFO - 2016-11-08 15:32:36 --> Config Class Initialized
INFO - 2016-11-08 15:32:36 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:32:36 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:32:36 --> Utf8 Class Initialized
INFO - 2016-11-08 15:32:36 --> URI Class Initialized
DEBUG - 2016-11-08 15:32:36 --> No URI present. Default controller set.
INFO - 2016-11-08 15:32:36 --> Router Class Initialized
INFO - 2016-11-08 15:32:36 --> Output Class Initialized
INFO - 2016-11-08 15:32:36 --> Security Class Initialized
DEBUG - 2016-11-08 15:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:32:36 --> Input Class Initialized
INFO - 2016-11-08 15:32:36 --> Language Class Initialized
INFO - 2016-11-08 15:32:36 --> Loader Class Initialized
INFO - 2016-11-08 15:32:36 --> Helper loaded: url_helper
INFO - 2016-11-08 15:32:36 --> Helper loaded: form_helper
INFO - 2016-11-08 15:32:36 --> Database Driver Class Initialized
INFO - 2016-11-08 15:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:32:36 --> Controller Class Initialized
INFO - 2016-11-08 15:32:36 --> Model Class Initialized
INFO - 2016-11-08 15:32:36 --> Model Class Initialized
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:32:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:32:37 --> Final output sent to browser
DEBUG - 2016-11-08 15:32:37 --> Total execution time: 0.3098
INFO - 2016-11-08 15:33:26 --> Config Class Initialized
INFO - 2016-11-08 15:33:26 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:33:26 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:33:26 --> Utf8 Class Initialized
INFO - 2016-11-08 15:33:26 --> URI Class Initialized
INFO - 2016-11-08 15:33:26 --> Router Class Initialized
INFO - 2016-11-08 15:33:26 --> Output Class Initialized
INFO - 2016-11-08 15:33:26 --> Security Class Initialized
DEBUG - 2016-11-08 15:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:33:26 --> Input Class Initialized
INFO - 2016-11-08 15:33:26 --> Language Class Initialized
INFO - 2016-11-08 15:33:26 --> Loader Class Initialized
INFO - 2016-11-08 15:33:26 --> Helper loaded: url_helper
INFO - 2016-11-08 15:33:26 --> Helper loaded: form_helper
INFO - 2016-11-08 15:33:26 --> Database Driver Class Initialized
INFO - 2016-11-08 15:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:33:26 --> Controller Class Initialized
INFO - 2016-11-08 15:33:26 --> Model Class Initialized
INFO - 2016-11-08 15:33:26 --> Form Validation Class Initialized
INFO - 2016-11-08 15:33:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:33:26 --> Final output sent to browser
DEBUG - 2016-11-08 15:33:26 --> Total execution time: 0.2761
INFO - 2016-11-08 15:33:30 --> Config Class Initialized
INFO - 2016-11-08 15:33:30 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:33:30 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:33:30 --> Utf8 Class Initialized
INFO - 2016-11-08 15:33:30 --> URI Class Initialized
DEBUG - 2016-11-08 15:33:30 --> No URI present. Default controller set.
INFO - 2016-11-08 15:33:30 --> Router Class Initialized
INFO - 2016-11-08 15:33:30 --> Output Class Initialized
INFO - 2016-11-08 15:33:30 --> Security Class Initialized
DEBUG - 2016-11-08 15:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:33:30 --> Input Class Initialized
INFO - 2016-11-08 15:33:30 --> Language Class Initialized
INFO - 2016-11-08 15:33:30 --> Loader Class Initialized
INFO - 2016-11-08 15:33:30 --> Helper loaded: url_helper
INFO - 2016-11-08 15:33:30 --> Helper loaded: form_helper
INFO - 2016-11-08 15:33:30 --> Database Driver Class Initialized
INFO - 2016-11-08 15:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:33:30 --> Controller Class Initialized
INFO - 2016-11-08 15:33:30 --> Model Class Initialized
INFO - 2016-11-08 15:33:30 --> Model Class Initialized
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:33:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:33:30 --> Final output sent to browser
DEBUG - 2016-11-08 15:33:30 --> Total execution time: 0.2638
INFO - 2016-11-08 15:34:33 --> Config Class Initialized
INFO - 2016-11-08 15:34:33 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:34:33 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:34:33 --> Utf8 Class Initialized
INFO - 2016-11-08 15:34:33 --> URI Class Initialized
INFO - 2016-11-08 15:34:33 --> Router Class Initialized
INFO - 2016-11-08 15:34:33 --> Output Class Initialized
INFO - 2016-11-08 15:34:33 --> Security Class Initialized
DEBUG - 2016-11-08 15:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:34:33 --> Input Class Initialized
INFO - 2016-11-08 15:34:33 --> Language Class Initialized
INFO - 2016-11-08 15:34:33 --> Loader Class Initialized
INFO - 2016-11-08 15:34:33 --> Helper loaded: url_helper
INFO - 2016-11-08 15:34:33 --> Helper loaded: form_helper
INFO - 2016-11-08 15:34:33 --> Database Driver Class Initialized
INFO - 2016-11-08 15:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:34:33 --> Controller Class Initialized
INFO - 2016-11-08 15:34:33 --> Model Class Initialized
INFO - 2016-11-08 15:34:33 --> Form Validation Class Initialized
INFO - 2016-11-08 15:34:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:34:33 --> Final output sent to browser
DEBUG - 2016-11-08 15:34:33 --> Total execution time: 0.3046
INFO - 2016-11-08 15:34:35 --> Config Class Initialized
INFO - 2016-11-08 15:34:35 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:34:35 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:34:35 --> Utf8 Class Initialized
INFO - 2016-11-08 15:34:35 --> URI Class Initialized
DEBUG - 2016-11-08 15:34:35 --> No URI present. Default controller set.
INFO - 2016-11-08 15:34:35 --> Router Class Initialized
INFO - 2016-11-08 15:34:35 --> Output Class Initialized
INFO - 2016-11-08 15:34:35 --> Security Class Initialized
DEBUG - 2016-11-08 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:34:35 --> Input Class Initialized
INFO - 2016-11-08 15:34:35 --> Language Class Initialized
INFO - 2016-11-08 15:34:35 --> Loader Class Initialized
INFO - 2016-11-08 15:34:35 --> Helper loaded: url_helper
INFO - 2016-11-08 15:34:35 --> Helper loaded: form_helper
INFO - 2016-11-08 15:34:35 --> Database Driver Class Initialized
INFO - 2016-11-08 15:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:34:35 --> Controller Class Initialized
INFO - 2016-11-08 15:34:35 --> Model Class Initialized
INFO - 2016-11-08 15:34:35 --> Model Class Initialized
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:34:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:34:35 --> Final output sent to browser
DEBUG - 2016-11-08 15:34:35 --> Total execution time: 0.3304
INFO - 2016-11-08 15:34:56 --> Config Class Initialized
INFO - 2016-11-08 15:34:56 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:34:56 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:34:56 --> Utf8 Class Initialized
INFO - 2016-11-08 15:34:56 --> URI Class Initialized
INFO - 2016-11-08 15:34:56 --> Router Class Initialized
INFO - 2016-11-08 15:34:56 --> Output Class Initialized
INFO - 2016-11-08 15:34:56 --> Security Class Initialized
DEBUG - 2016-11-08 15:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:34:56 --> Input Class Initialized
INFO - 2016-11-08 15:34:56 --> Language Class Initialized
INFO - 2016-11-08 15:34:56 --> Loader Class Initialized
INFO - 2016-11-08 15:34:56 --> Helper loaded: url_helper
INFO - 2016-11-08 15:34:56 --> Helper loaded: form_helper
INFO - 2016-11-08 15:34:56 --> Database Driver Class Initialized
INFO - 2016-11-08 15:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:34:56 --> Controller Class Initialized
INFO - 2016-11-08 15:34:56 --> Model Class Initialized
INFO - 2016-11-08 15:34:57 --> Form Validation Class Initialized
INFO - 2016-11-08 15:34:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:34:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:34:57 --> Final output sent to browser
DEBUG - 2016-11-08 15:34:57 --> Total execution time: 0.2918
INFO - 2016-11-08 15:34:58 --> Config Class Initialized
INFO - 2016-11-08 15:34:58 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:34:58 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:34:58 --> Utf8 Class Initialized
INFO - 2016-11-08 15:34:58 --> URI Class Initialized
DEBUG - 2016-11-08 15:34:58 --> No URI present. Default controller set.
INFO - 2016-11-08 15:34:58 --> Router Class Initialized
INFO - 2016-11-08 15:34:58 --> Output Class Initialized
INFO - 2016-11-08 15:34:58 --> Security Class Initialized
DEBUG - 2016-11-08 15:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:34:58 --> Input Class Initialized
INFO - 2016-11-08 15:34:58 --> Language Class Initialized
INFO - 2016-11-08 15:34:59 --> Loader Class Initialized
INFO - 2016-11-08 15:34:59 --> Helper loaded: url_helper
INFO - 2016-11-08 15:34:59 --> Helper loaded: form_helper
INFO - 2016-11-08 15:34:59 --> Database Driver Class Initialized
INFO - 2016-11-08 15:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:34:59 --> Controller Class Initialized
INFO - 2016-11-08 15:34:59 --> Model Class Initialized
INFO - 2016-11-08 15:34:59 --> Model Class Initialized
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:34:59 --> Final output sent to browser
DEBUG - 2016-11-08 15:34:59 --> Total execution time: 0.6797
INFO - 2016-11-08 15:36:14 --> Config Class Initialized
INFO - 2016-11-08 15:36:14 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:36:14 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:36:14 --> Utf8 Class Initialized
INFO - 2016-11-08 15:36:14 --> URI Class Initialized
INFO - 2016-11-08 15:36:14 --> Router Class Initialized
INFO - 2016-11-08 15:36:14 --> Output Class Initialized
INFO - 2016-11-08 15:36:14 --> Security Class Initialized
DEBUG - 2016-11-08 15:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:36:14 --> Input Class Initialized
INFO - 2016-11-08 15:36:14 --> Language Class Initialized
INFO - 2016-11-08 15:36:14 --> Loader Class Initialized
INFO - 2016-11-08 15:36:14 --> Helper loaded: url_helper
INFO - 2016-11-08 15:36:14 --> Helper loaded: form_helper
INFO - 2016-11-08 15:36:14 --> Database Driver Class Initialized
INFO - 2016-11-08 15:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:36:14 --> Controller Class Initialized
INFO - 2016-11-08 15:36:14 --> Model Class Initialized
INFO - 2016-11-08 15:36:14 --> Form Validation Class Initialized
INFO - 2016-11-08 15:36:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 15:36:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:36:14 --> Final output sent to browser
DEBUG - 2016-11-08 15:36:14 --> Total execution time: 0.4751
INFO - 2016-11-08 15:36:20 --> Config Class Initialized
INFO - 2016-11-08 15:36:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:36:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:36:20 --> Utf8 Class Initialized
INFO - 2016-11-08 15:36:20 --> URI Class Initialized
DEBUG - 2016-11-08 15:36:20 --> No URI present. Default controller set.
INFO - 2016-11-08 15:36:20 --> Router Class Initialized
INFO - 2016-11-08 15:36:20 --> Output Class Initialized
INFO - 2016-11-08 15:36:20 --> Security Class Initialized
DEBUG - 2016-11-08 15:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:36:20 --> Input Class Initialized
INFO - 2016-11-08 15:36:20 --> Language Class Initialized
INFO - 2016-11-08 15:36:20 --> Loader Class Initialized
INFO - 2016-11-08 15:36:20 --> Helper loaded: url_helper
INFO - 2016-11-08 15:36:20 --> Helper loaded: form_helper
INFO - 2016-11-08 15:36:20 --> Database Driver Class Initialized
INFO - 2016-11-08 15:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:36:20 --> Controller Class Initialized
INFO - 2016-11-08 15:36:20 --> Model Class Initialized
INFO - 2016-11-08 15:36:20 --> Model Class Initialized
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:36:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:36:20 --> Final output sent to browser
DEBUG - 2016-11-08 15:36:20 --> Total execution time: 0.2741
INFO - 2016-11-08 15:36:28 --> Config Class Initialized
INFO - 2016-11-08 15:36:28 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:36:28 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:36:28 --> Utf8 Class Initialized
INFO - 2016-11-08 15:36:28 --> URI Class Initialized
INFO - 2016-11-08 15:36:28 --> Router Class Initialized
INFO - 2016-11-08 15:36:28 --> Output Class Initialized
INFO - 2016-11-08 15:36:28 --> Security Class Initialized
DEBUG - 2016-11-08 15:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:36:28 --> Input Class Initialized
INFO - 2016-11-08 15:36:28 --> Language Class Initialized
INFO - 2016-11-08 15:36:28 --> Loader Class Initialized
INFO - 2016-11-08 15:36:28 --> Helper loaded: url_helper
INFO - 2016-11-08 15:36:28 --> Helper loaded: form_helper
INFO - 2016-11-08 15:36:28 --> Database Driver Class Initialized
INFO - 2016-11-08 15:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:36:28 --> Controller Class Initialized
INFO - 2016-11-08 15:36:28 --> Model Class Initialized
INFO - 2016-11-08 15:36:28 --> Model Class Initialized
DEBUG - 2016-11-08 15:36:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:36:28 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:36:28 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:36:28 --> Config Class Initialized
INFO - 2016-11-08 15:36:28 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:36:28 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:36:28 --> Utf8 Class Initialized
INFO - 2016-11-08 15:36:28 --> URI Class Initialized
DEBUG - 2016-11-08 15:36:28 --> No URI present. Default controller set.
INFO - 2016-11-08 15:36:28 --> Router Class Initialized
INFO - 2016-11-08 15:36:28 --> Output Class Initialized
INFO - 2016-11-08 15:36:28 --> Security Class Initialized
DEBUG - 2016-11-08 15:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:36:28 --> Input Class Initialized
INFO - 2016-11-08 15:36:28 --> Language Class Initialized
INFO - 2016-11-08 15:36:28 --> Loader Class Initialized
INFO - 2016-11-08 15:36:28 --> Helper loaded: url_helper
INFO - 2016-11-08 15:36:28 --> Helper loaded: form_helper
INFO - 2016-11-08 15:36:28 --> Database Driver Class Initialized
INFO - 2016-11-08 15:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:36:28 --> Controller Class Initialized
INFO - 2016-11-08 15:36:28 --> Model Class Initialized
INFO - 2016-11-08 15:36:28 --> Model Class Initialized
INFO - 2016-11-08 15:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:36:28 --> Final output sent to browser
DEBUG - 2016-11-08 15:36:28 --> Total execution time: 0.1993
INFO - 2016-11-08 15:36:37 --> Config Class Initialized
INFO - 2016-11-08 15:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:36:37 --> Utf8 Class Initialized
INFO - 2016-11-08 15:36:37 --> URI Class Initialized
INFO - 2016-11-08 15:36:37 --> Router Class Initialized
INFO - 2016-11-08 15:36:37 --> Output Class Initialized
INFO - 2016-11-08 15:36:37 --> Security Class Initialized
DEBUG - 2016-11-08 15:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:36:37 --> Input Class Initialized
INFO - 2016-11-08 15:36:37 --> Language Class Initialized
INFO - 2016-11-08 15:36:37 --> Loader Class Initialized
INFO - 2016-11-08 15:36:37 --> Helper loaded: url_helper
INFO - 2016-11-08 15:36:37 --> Helper loaded: form_helper
INFO - 2016-11-08 15:36:37 --> Database Driver Class Initialized
INFO - 2016-11-08 15:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:36:37 --> Controller Class Initialized
INFO - 2016-11-08 15:36:37 --> Model Class Initialized
INFO - 2016-11-08 15:36:37 --> Model Class Initialized
DEBUG - 2016-11-08 15:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:36:37 --> Model Class Initialized
INFO - 2016-11-08 15:36:37 --> Final output sent to browser
DEBUG - 2016-11-08 15:36:37 --> Total execution time: 0.1752
INFO - 2016-11-08 15:36:37 --> Config Class Initialized
INFO - 2016-11-08 15:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:36:37 --> Utf8 Class Initialized
INFO - 2016-11-08 15:36:37 --> URI Class Initialized
DEBUG - 2016-11-08 15:36:37 --> No URI present. Default controller set.
INFO - 2016-11-08 15:36:37 --> Router Class Initialized
INFO - 2016-11-08 15:36:37 --> Output Class Initialized
INFO - 2016-11-08 15:36:37 --> Security Class Initialized
DEBUG - 2016-11-08 15:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:36:37 --> Input Class Initialized
INFO - 2016-11-08 15:36:37 --> Language Class Initialized
INFO - 2016-11-08 15:36:37 --> Loader Class Initialized
INFO - 2016-11-08 15:36:37 --> Helper loaded: url_helper
INFO - 2016-11-08 15:36:37 --> Helper loaded: form_helper
INFO - 2016-11-08 15:36:37 --> Database Driver Class Initialized
INFO - 2016-11-08 15:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:36:37 --> Controller Class Initialized
INFO - 2016-11-08 15:36:37 --> Model Class Initialized
INFO - 2016-11-08 15:36:37 --> Model Class Initialized
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:36:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:36:37 --> Final output sent to browser
DEBUG - 2016-11-08 15:36:37 --> Total execution time: 0.2554
INFO - 2016-11-08 15:39:33 --> Config Class Initialized
INFO - 2016-11-08 15:39:33 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:39:33 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:39:33 --> Utf8 Class Initialized
INFO - 2016-11-08 15:39:33 --> URI Class Initialized
DEBUG - 2016-11-08 15:39:33 --> No URI present. Default controller set.
INFO - 2016-11-08 15:39:33 --> Router Class Initialized
INFO - 2016-11-08 15:39:33 --> Output Class Initialized
INFO - 2016-11-08 15:39:33 --> Security Class Initialized
DEBUG - 2016-11-08 15:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:39:33 --> Input Class Initialized
INFO - 2016-11-08 15:39:33 --> Language Class Initialized
INFO - 2016-11-08 15:39:33 --> Loader Class Initialized
INFO - 2016-11-08 15:39:33 --> Helper loaded: url_helper
INFO - 2016-11-08 15:39:33 --> Helper loaded: form_helper
INFO - 2016-11-08 15:39:33 --> Database Driver Class Initialized
INFO - 2016-11-08 15:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:39:33 --> Controller Class Initialized
INFO - 2016-11-08 15:39:33 --> Model Class Initialized
INFO - 2016-11-08 15:39:33 --> Model Class Initialized
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:39:33 --> Final output sent to browser
DEBUG - 2016-11-08 15:39:33 --> Total execution time: 0.2799
INFO - 2016-11-08 15:44:39 --> Config Class Initialized
INFO - 2016-11-08 15:44:39 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:44:39 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:44:39 --> Utf8 Class Initialized
INFO - 2016-11-08 15:44:39 --> URI Class Initialized
DEBUG - 2016-11-08 15:44:39 --> No URI present. Default controller set.
INFO - 2016-11-08 15:44:39 --> Router Class Initialized
INFO - 2016-11-08 15:44:39 --> Output Class Initialized
INFO - 2016-11-08 15:44:39 --> Security Class Initialized
DEBUG - 2016-11-08 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:44:39 --> Input Class Initialized
INFO - 2016-11-08 15:44:39 --> Language Class Initialized
INFO - 2016-11-08 15:44:39 --> Loader Class Initialized
INFO - 2016-11-08 15:44:39 --> Helper loaded: url_helper
INFO - 2016-11-08 15:44:39 --> Helper loaded: form_helper
INFO - 2016-11-08 15:44:39 --> Database Driver Class Initialized
INFO - 2016-11-08 15:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:44:39 --> Controller Class Initialized
INFO - 2016-11-08 15:44:39 --> Model Class Initialized
INFO - 2016-11-08 15:44:39 --> Model Class Initialized
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:44:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:44:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:44:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:44:40 --> Final output sent to browser
DEBUG - 2016-11-08 15:44:40 --> Total execution time: 0.3294
INFO - 2016-11-08 15:44:41 --> Config Class Initialized
INFO - 2016-11-08 15:44:41 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:44:41 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:44:41 --> Utf8 Class Initialized
INFO - 2016-11-08 15:44:41 --> URI Class Initialized
INFO - 2016-11-08 15:44:41 --> Router Class Initialized
INFO - 2016-11-08 15:44:41 --> Output Class Initialized
INFO - 2016-11-08 15:44:41 --> Security Class Initialized
DEBUG - 2016-11-08 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:44:42 --> Input Class Initialized
INFO - 2016-11-08 15:44:42 --> Language Class Initialized
INFO - 2016-11-08 15:44:42 --> Loader Class Initialized
INFO - 2016-11-08 15:44:42 --> Helper loaded: url_helper
INFO - 2016-11-08 15:44:42 --> Helper loaded: form_helper
INFO - 2016-11-08 15:44:42 --> Database Driver Class Initialized
INFO - 2016-11-08 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:44:42 --> Controller Class Initialized
INFO - 2016-11-08 15:44:42 --> Model Class Initialized
INFO - 2016-11-08 15:44:42 --> Model Class Initialized
DEBUG - 2016-11-08 15:44:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:44:42 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:44:42 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:44:42 --> Config Class Initialized
INFO - 2016-11-08 15:44:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:44:42 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:44:42 --> Utf8 Class Initialized
INFO - 2016-11-08 15:44:42 --> URI Class Initialized
DEBUG - 2016-11-08 15:44:42 --> No URI present. Default controller set.
INFO - 2016-11-08 15:44:42 --> Router Class Initialized
INFO - 2016-11-08 15:44:42 --> Output Class Initialized
INFO - 2016-11-08 15:44:42 --> Security Class Initialized
DEBUG - 2016-11-08 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:44:42 --> Input Class Initialized
INFO - 2016-11-08 15:44:42 --> Language Class Initialized
INFO - 2016-11-08 15:44:42 --> Loader Class Initialized
INFO - 2016-11-08 15:44:42 --> Helper loaded: url_helper
INFO - 2016-11-08 15:44:42 --> Helper loaded: form_helper
INFO - 2016-11-08 15:44:42 --> Database Driver Class Initialized
INFO - 2016-11-08 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:44:42 --> Controller Class Initialized
INFO - 2016-11-08 15:44:42 --> Model Class Initialized
INFO - 2016-11-08 15:44:42 --> Model Class Initialized
INFO - 2016-11-08 15:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:44:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:44:42 --> Final output sent to browser
DEBUG - 2016-11-08 15:44:42 --> Total execution time: 0.2138
INFO - 2016-11-08 15:45:08 --> Config Class Initialized
INFO - 2016-11-08 15:45:08 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:08 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:08 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:08 --> URI Class Initialized
INFO - 2016-11-08 15:45:08 --> Router Class Initialized
INFO - 2016-11-08 15:45:08 --> Output Class Initialized
INFO - 2016-11-08 15:45:08 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:08 --> Input Class Initialized
INFO - 2016-11-08 15:45:08 --> Language Class Initialized
INFO - 2016-11-08 15:45:08 --> Loader Class Initialized
INFO - 2016-11-08 15:45:08 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:08 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:08 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:08 --> Controller Class Initialized
INFO - 2016-11-08 15:45:08 --> Model Class Initialized
INFO - 2016-11-08 15:45:08 --> Model Class Initialized
DEBUG - 2016-11-08 15:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:45:08 --> Model Class Initialized
INFO - 2016-11-08 15:45:08 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:08 --> Total execution time: 0.2243
INFO - 2016-11-08 15:45:08 --> Config Class Initialized
INFO - 2016-11-08 15:45:08 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:08 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:08 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:08 --> URI Class Initialized
DEBUG - 2016-11-08 15:45:08 --> No URI present. Default controller set.
INFO - 2016-11-08 15:45:08 --> Router Class Initialized
INFO - 2016-11-08 15:45:08 --> Output Class Initialized
INFO - 2016-11-08 15:45:09 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:09 --> Input Class Initialized
INFO - 2016-11-08 15:45:09 --> Language Class Initialized
INFO - 2016-11-08 15:45:09 --> Loader Class Initialized
INFO - 2016-11-08 15:45:09 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:09 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:09 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:09 --> Controller Class Initialized
INFO - 2016-11-08 15:45:09 --> Model Class Initialized
INFO - 2016-11-08 15:45:09 --> Model Class Initialized
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:45:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:45:09 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:09 --> Total execution time: 0.3802
INFO - 2016-11-08 15:45:19 --> Config Class Initialized
INFO - 2016-11-08 15:45:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:19 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:19 --> URI Class Initialized
INFO - 2016-11-08 15:45:19 --> Router Class Initialized
INFO - 2016-11-08 15:45:19 --> Output Class Initialized
INFO - 2016-11-08 15:45:19 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:19 --> Input Class Initialized
INFO - 2016-11-08 15:45:19 --> Language Class Initialized
INFO - 2016-11-08 15:45:19 --> Loader Class Initialized
INFO - 2016-11-08 15:45:19 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:19 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:19 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:19 --> Controller Class Initialized
INFO - 2016-11-08 15:45:19 --> Model Class Initialized
INFO - 2016-11-08 15:45:19 --> Model Class Initialized
DEBUG - 2016-11-08 15:45:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:45:19 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:45:19 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:45:19 --> Config Class Initialized
INFO - 2016-11-08 15:45:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:19 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:19 --> URI Class Initialized
DEBUG - 2016-11-08 15:45:19 --> No URI present. Default controller set.
INFO - 2016-11-08 15:45:19 --> Router Class Initialized
INFO - 2016-11-08 15:45:19 --> Output Class Initialized
INFO - 2016-11-08 15:45:19 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:19 --> Input Class Initialized
INFO - 2016-11-08 15:45:19 --> Language Class Initialized
INFO - 2016-11-08 15:45:19 --> Loader Class Initialized
INFO - 2016-11-08 15:45:19 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:19 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:19 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:19 --> Controller Class Initialized
INFO - 2016-11-08 15:45:19 --> Model Class Initialized
INFO - 2016-11-08 15:45:19 --> Model Class Initialized
INFO - 2016-11-08 15:45:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:45:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:45:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:45:19 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:19 --> Total execution time: 0.2098
INFO - 2016-11-08 15:45:42 --> Config Class Initialized
INFO - 2016-11-08 15:45:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:42 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:42 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:42 --> URI Class Initialized
INFO - 2016-11-08 15:45:42 --> Router Class Initialized
INFO - 2016-11-08 15:45:42 --> Output Class Initialized
INFO - 2016-11-08 15:45:42 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:42 --> Input Class Initialized
INFO - 2016-11-08 15:45:42 --> Language Class Initialized
INFO - 2016-11-08 15:45:42 --> Loader Class Initialized
INFO - 2016-11-08 15:45:42 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:42 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:42 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:42 --> Controller Class Initialized
INFO - 2016-11-08 15:45:42 --> Model Class Initialized
INFO - 2016-11-08 15:45:42 --> Model Class Initialized
DEBUG - 2016-11-08 15:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:45:42 --> Model Class Initialized
INFO - 2016-11-08 15:45:42 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:42 --> Total execution time: 0.2111
INFO - 2016-11-08 15:45:42 --> Config Class Initialized
INFO - 2016-11-08 15:45:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:42 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:42 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:42 --> URI Class Initialized
DEBUG - 2016-11-08 15:45:42 --> No URI present. Default controller set.
INFO - 2016-11-08 15:45:42 --> Router Class Initialized
INFO - 2016-11-08 15:45:42 --> Output Class Initialized
INFO - 2016-11-08 15:45:42 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:42 --> Input Class Initialized
INFO - 2016-11-08 15:45:42 --> Language Class Initialized
INFO - 2016-11-08 15:45:42 --> Loader Class Initialized
INFO - 2016-11-08 15:45:42 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:42 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:42 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:42 --> Controller Class Initialized
INFO - 2016-11-08 15:45:42 --> Model Class Initialized
INFO - 2016-11-08 15:45:42 --> Model Class Initialized
INFO - 2016-11-08 15:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:45:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:45:42 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:42 --> Total execution time: 0.2378
INFO - 2016-11-08 15:45:44 --> Config Class Initialized
INFO - 2016-11-08 15:45:44 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:44 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:44 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:44 --> URI Class Initialized
INFO - 2016-11-08 15:45:44 --> Router Class Initialized
INFO - 2016-11-08 15:45:44 --> Output Class Initialized
INFO - 2016-11-08 15:45:44 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:44 --> Input Class Initialized
INFO - 2016-11-08 15:45:44 --> Language Class Initialized
INFO - 2016-11-08 15:45:44 --> Loader Class Initialized
INFO - 2016-11-08 15:45:44 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:44 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:44 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:44 --> Controller Class Initialized
INFO - 2016-11-08 15:45:44 --> Model Class Initialized
INFO - 2016-11-08 15:45:44 --> Model Class Initialized
DEBUG - 2016-11-08 15:45:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:45:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:45:44 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:45:45 --> Config Class Initialized
INFO - 2016-11-08 15:45:45 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:45 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:45 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:45 --> URI Class Initialized
DEBUG - 2016-11-08 15:45:45 --> No URI present. Default controller set.
INFO - 2016-11-08 15:45:45 --> Router Class Initialized
INFO - 2016-11-08 15:45:45 --> Output Class Initialized
INFO - 2016-11-08 15:45:45 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:45 --> Input Class Initialized
INFO - 2016-11-08 15:45:45 --> Language Class Initialized
INFO - 2016-11-08 15:45:45 --> Loader Class Initialized
INFO - 2016-11-08 15:45:45 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:45 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:45 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:45 --> Controller Class Initialized
INFO - 2016-11-08 15:45:45 --> Model Class Initialized
INFO - 2016-11-08 15:45:45 --> Model Class Initialized
INFO - 2016-11-08 15:45:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:45:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:45:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:45:45 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:45 --> Total execution time: 0.2114
INFO - 2016-11-08 15:45:56 --> Config Class Initialized
INFO - 2016-11-08 15:45:56 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:56 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:56 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:56 --> URI Class Initialized
INFO - 2016-11-08 15:45:56 --> Router Class Initialized
INFO - 2016-11-08 15:45:56 --> Output Class Initialized
INFO - 2016-11-08 15:45:56 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:56 --> Input Class Initialized
INFO - 2016-11-08 15:45:56 --> Language Class Initialized
INFO - 2016-11-08 15:45:56 --> Loader Class Initialized
INFO - 2016-11-08 15:45:56 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:56 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:56 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:56 --> Controller Class Initialized
INFO - 2016-11-08 15:45:56 --> Model Class Initialized
INFO - 2016-11-08 15:45:56 --> Model Class Initialized
DEBUG - 2016-11-08 15:45:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:45:56 --> Model Class Initialized
INFO - 2016-11-08 15:45:56 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:56 --> Total execution time: 0.2192
INFO - 2016-11-08 15:45:56 --> Config Class Initialized
INFO - 2016-11-08 15:45:56 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:45:56 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:45:56 --> Utf8 Class Initialized
INFO - 2016-11-08 15:45:56 --> URI Class Initialized
DEBUG - 2016-11-08 15:45:56 --> No URI present. Default controller set.
INFO - 2016-11-08 15:45:56 --> Router Class Initialized
INFO - 2016-11-08 15:45:56 --> Output Class Initialized
INFO - 2016-11-08 15:45:56 --> Security Class Initialized
DEBUG - 2016-11-08 15:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:45:56 --> Input Class Initialized
INFO - 2016-11-08 15:45:56 --> Language Class Initialized
INFO - 2016-11-08 15:45:56 --> Loader Class Initialized
INFO - 2016-11-08 15:45:56 --> Helper loaded: url_helper
INFO - 2016-11-08 15:45:56 --> Helper loaded: form_helper
INFO - 2016-11-08 15:45:56 --> Database Driver Class Initialized
INFO - 2016-11-08 15:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:45:56 --> Controller Class Initialized
INFO - 2016-11-08 15:45:56 --> Model Class Initialized
INFO - 2016-11-08 15:45:56 --> Model Class Initialized
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:45:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:45:56 --> Final output sent to browser
DEBUG - 2016-11-08 15:45:56 --> Total execution time: 0.3753
INFO - 2016-11-08 15:46:17 --> Config Class Initialized
INFO - 2016-11-08 15:46:17 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:46:17 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:46:17 --> Utf8 Class Initialized
INFO - 2016-11-08 15:46:17 --> URI Class Initialized
INFO - 2016-11-08 15:46:17 --> Router Class Initialized
INFO - 2016-11-08 15:46:17 --> Output Class Initialized
INFO - 2016-11-08 15:46:17 --> Security Class Initialized
DEBUG - 2016-11-08 15:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:46:17 --> Input Class Initialized
INFO - 2016-11-08 15:46:17 --> Language Class Initialized
INFO - 2016-11-08 15:46:17 --> Loader Class Initialized
INFO - 2016-11-08 15:46:17 --> Helper loaded: url_helper
INFO - 2016-11-08 15:46:18 --> Helper loaded: form_helper
INFO - 2016-11-08 15:46:18 --> Database Driver Class Initialized
INFO - 2016-11-08 15:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:46:18 --> Controller Class Initialized
INFO - 2016-11-08 15:46:18 --> Model Class Initialized
INFO - 2016-11-08 15:46:18 --> Model Class Initialized
DEBUG - 2016-11-08 15:46:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:46:18 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:46:18 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:46:18 --> Config Class Initialized
INFO - 2016-11-08 15:46:18 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:46:18 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:46:18 --> Utf8 Class Initialized
INFO - 2016-11-08 15:46:18 --> URI Class Initialized
DEBUG - 2016-11-08 15:46:18 --> No URI present. Default controller set.
INFO - 2016-11-08 15:46:18 --> Router Class Initialized
INFO - 2016-11-08 15:46:18 --> Output Class Initialized
INFO - 2016-11-08 15:46:18 --> Security Class Initialized
DEBUG - 2016-11-08 15:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:46:18 --> Input Class Initialized
INFO - 2016-11-08 15:46:18 --> Language Class Initialized
INFO - 2016-11-08 15:46:18 --> Loader Class Initialized
INFO - 2016-11-08 15:46:18 --> Helper loaded: url_helper
INFO - 2016-11-08 15:46:18 --> Helper loaded: form_helper
INFO - 2016-11-08 15:46:18 --> Database Driver Class Initialized
INFO - 2016-11-08 15:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:46:18 --> Controller Class Initialized
INFO - 2016-11-08 15:46:18 --> Model Class Initialized
INFO - 2016-11-08 15:46:18 --> Model Class Initialized
INFO - 2016-11-08 15:46:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:46:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:46:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:46:18 --> Final output sent to browser
DEBUG - 2016-11-08 15:46:18 --> Total execution time: 0.3646
INFO - 2016-11-08 15:46:35 --> Config Class Initialized
INFO - 2016-11-08 15:46:35 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:46:35 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:46:35 --> Utf8 Class Initialized
INFO - 2016-11-08 15:46:35 --> URI Class Initialized
DEBUG - 2016-11-08 15:46:35 --> No URI present. Default controller set.
INFO - 2016-11-08 15:46:35 --> Router Class Initialized
INFO - 2016-11-08 15:46:35 --> Output Class Initialized
INFO - 2016-11-08 15:46:35 --> Security Class Initialized
DEBUG - 2016-11-08 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:46:35 --> Input Class Initialized
INFO - 2016-11-08 15:46:35 --> Language Class Initialized
INFO - 2016-11-08 15:46:35 --> Loader Class Initialized
INFO - 2016-11-08 15:46:35 --> Helper loaded: url_helper
INFO - 2016-11-08 15:46:35 --> Helper loaded: form_helper
INFO - 2016-11-08 15:46:35 --> Database Driver Class Initialized
INFO - 2016-11-08 15:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:46:35 --> Controller Class Initialized
INFO - 2016-11-08 15:46:35 --> Model Class Initialized
INFO - 2016-11-08 15:46:35 --> Model Class Initialized
INFO - 2016-11-08 15:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:46:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:46:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:46:36 --> Final output sent to browser
DEBUG - 2016-11-08 15:46:36 --> Total execution time: 0.2347
INFO - 2016-11-08 15:46:50 --> Config Class Initialized
INFO - 2016-11-08 15:46:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:46:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:46:50 --> Utf8 Class Initialized
INFO - 2016-11-08 15:46:50 --> URI Class Initialized
DEBUG - 2016-11-08 15:46:50 --> No URI present. Default controller set.
INFO - 2016-11-08 15:46:50 --> Router Class Initialized
INFO - 2016-11-08 15:46:50 --> Output Class Initialized
INFO - 2016-11-08 15:46:50 --> Security Class Initialized
DEBUG - 2016-11-08 15:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:46:50 --> Input Class Initialized
INFO - 2016-11-08 15:46:50 --> Language Class Initialized
INFO - 2016-11-08 15:46:50 --> Loader Class Initialized
INFO - 2016-11-08 15:46:50 --> Helper loaded: url_helper
INFO - 2016-11-08 15:46:50 --> Helper loaded: form_helper
INFO - 2016-11-08 15:46:50 --> Database Driver Class Initialized
INFO - 2016-11-08 15:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:46:50 --> Controller Class Initialized
INFO - 2016-11-08 15:46:50 --> Model Class Initialized
INFO - 2016-11-08 15:46:50 --> Model Class Initialized
INFO - 2016-11-08 15:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:46:50 --> Final output sent to browser
DEBUG - 2016-11-08 15:46:50 --> Total execution time: 0.2248
INFO - 2016-11-08 15:47:12 --> Config Class Initialized
INFO - 2016-11-08 15:47:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:47:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:47:12 --> Utf8 Class Initialized
INFO - 2016-11-08 15:47:12 --> URI Class Initialized
INFO - 2016-11-08 15:47:12 --> Router Class Initialized
INFO - 2016-11-08 15:47:12 --> Output Class Initialized
INFO - 2016-11-08 15:47:12 --> Security Class Initialized
DEBUG - 2016-11-08 15:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:47:12 --> Input Class Initialized
INFO - 2016-11-08 15:47:12 --> Language Class Initialized
INFO - 2016-11-08 15:47:12 --> Loader Class Initialized
INFO - 2016-11-08 15:47:12 --> Helper loaded: url_helper
INFO - 2016-11-08 15:47:12 --> Helper loaded: form_helper
INFO - 2016-11-08 15:47:12 --> Database Driver Class Initialized
INFO - 2016-11-08 15:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:47:12 --> Controller Class Initialized
INFO - 2016-11-08 15:47:12 --> Model Class Initialized
INFO - 2016-11-08 15:47:12 --> Model Class Initialized
DEBUG - 2016-11-08 15:47:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:47:12 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:47:12 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:47:12 --> Config Class Initialized
INFO - 2016-11-08 15:47:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:47:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:47:12 --> Utf8 Class Initialized
INFO - 2016-11-08 15:47:12 --> URI Class Initialized
DEBUG - 2016-11-08 15:47:12 --> No URI present. Default controller set.
INFO - 2016-11-08 15:47:12 --> Router Class Initialized
INFO - 2016-11-08 15:47:13 --> Output Class Initialized
INFO - 2016-11-08 15:47:13 --> Security Class Initialized
DEBUG - 2016-11-08 15:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:47:13 --> Input Class Initialized
INFO - 2016-11-08 15:47:13 --> Language Class Initialized
INFO - 2016-11-08 15:47:13 --> Loader Class Initialized
INFO - 2016-11-08 15:47:13 --> Helper loaded: url_helper
INFO - 2016-11-08 15:47:13 --> Helper loaded: form_helper
INFO - 2016-11-08 15:47:13 --> Database Driver Class Initialized
INFO - 2016-11-08 15:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:47:13 --> Controller Class Initialized
INFO - 2016-11-08 15:47:13 --> Model Class Initialized
INFO - 2016-11-08 15:47:13 --> Model Class Initialized
INFO - 2016-11-08 15:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:47:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:47:13 --> Final output sent to browser
DEBUG - 2016-11-08 15:47:13 --> Total execution time: 0.2130
INFO - 2016-11-08 15:47:25 --> Config Class Initialized
INFO - 2016-11-08 15:47:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:47:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:47:25 --> Utf8 Class Initialized
INFO - 2016-11-08 15:47:25 --> URI Class Initialized
INFO - 2016-11-08 15:47:25 --> Router Class Initialized
INFO - 2016-11-08 15:47:25 --> Output Class Initialized
INFO - 2016-11-08 15:47:25 --> Security Class Initialized
DEBUG - 2016-11-08 15:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:47:25 --> Input Class Initialized
INFO - 2016-11-08 15:47:25 --> Language Class Initialized
INFO - 2016-11-08 15:47:25 --> Loader Class Initialized
INFO - 2016-11-08 15:47:25 --> Helper loaded: url_helper
INFO - 2016-11-08 15:47:25 --> Helper loaded: form_helper
INFO - 2016-11-08 15:47:25 --> Database Driver Class Initialized
INFO - 2016-11-08 15:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:47:25 --> Controller Class Initialized
INFO - 2016-11-08 15:47:25 --> Model Class Initialized
INFO - 2016-11-08 15:47:25 --> Model Class Initialized
DEBUG - 2016-11-08 15:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:47:25 --> Model Class Initialized
INFO - 2016-11-08 15:47:25 --> Final output sent to browser
DEBUG - 2016-11-08 15:47:25 --> Total execution time: 0.2181
INFO - 2016-11-08 15:47:25 --> Config Class Initialized
INFO - 2016-11-08 15:47:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:47:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:47:25 --> Utf8 Class Initialized
INFO - 2016-11-08 15:47:25 --> URI Class Initialized
DEBUG - 2016-11-08 15:47:25 --> No URI present. Default controller set.
INFO - 2016-11-08 15:47:25 --> Router Class Initialized
INFO - 2016-11-08 15:47:25 --> Output Class Initialized
INFO - 2016-11-08 15:47:25 --> Security Class Initialized
DEBUG - 2016-11-08 15:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:47:25 --> Input Class Initialized
INFO - 2016-11-08 15:47:25 --> Language Class Initialized
INFO - 2016-11-08 15:47:25 --> Loader Class Initialized
INFO - 2016-11-08 15:47:25 --> Helper loaded: url_helper
INFO - 2016-11-08 15:47:25 --> Helper loaded: form_helper
INFO - 2016-11-08 15:47:25 --> Database Driver Class Initialized
INFO - 2016-11-08 15:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:47:25 --> Controller Class Initialized
INFO - 2016-11-08 15:47:25 --> Model Class Initialized
INFO - 2016-11-08 15:47:25 --> Model Class Initialized
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:47:25 --> Final output sent to browser
DEBUG - 2016-11-08 15:47:25 --> Total execution time: 0.2885
INFO - 2016-11-08 15:56:09 --> Config Class Initialized
INFO - 2016-11-08 15:56:09 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:56:09 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:56:09 --> Utf8 Class Initialized
INFO - 2016-11-08 15:56:09 --> URI Class Initialized
DEBUG - 2016-11-08 15:56:09 --> No URI present. Default controller set.
INFO - 2016-11-08 15:56:09 --> Router Class Initialized
INFO - 2016-11-08 15:56:09 --> Output Class Initialized
INFO - 2016-11-08 15:56:09 --> Security Class Initialized
DEBUG - 2016-11-08 15:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:56:09 --> Input Class Initialized
INFO - 2016-11-08 15:56:09 --> Language Class Initialized
INFO - 2016-11-08 15:56:10 --> Loader Class Initialized
INFO - 2016-11-08 15:56:10 --> Helper loaded: url_helper
INFO - 2016-11-08 15:56:10 --> Helper loaded: form_helper
INFO - 2016-11-08 15:56:10 --> Database Driver Class Initialized
INFO - 2016-11-08 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:56:10 --> Controller Class Initialized
INFO - 2016-11-08 15:56:10 --> Model Class Initialized
INFO - 2016-11-08 15:56:10 --> Model Class Initialized
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:56:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:56:10 --> Final output sent to browser
DEBUG - 2016-11-08 15:56:10 --> Total execution time: 0.3805
INFO - 2016-11-08 15:56:45 --> Config Class Initialized
INFO - 2016-11-08 15:56:45 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:56:45 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:56:45 --> Utf8 Class Initialized
INFO - 2016-11-08 15:56:45 --> URI Class Initialized
INFO - 2016-11-08 15:56:45 --> Router Class Initialized
INFO - 2016-11-08 15:56:45 --> Output Class Initialized
INFO - 2016-11-08 15:56:45 --> Security Class Initialized
DEBUG - 2016-11-08 15:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:56:45 --> Input Class Initialized
INFO - 2016-11-08 15:56:45 --> Language Class Initialized
INFO - 2016-11-08 15:56:45 --> Loader Class Initialized
INFO - 2016-11-08 15:56:45 --> Helper loaded: url_helper
INFO - 2016-11-08 15:56:45 --> Helper loaded: form_helper
INFO - 2016-11-08 15:56:45 --> Database Driver Class Initialized
INFO - 2016-11-08 15:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:56:46 --> Controller Class Initialized
INFO - 2016-11-08 15:56:46 --> Model Class Initialized
INFO - 2016-11-08 15:56:46 --> Model Class Initialized
DEBUG - 2016-11-08 15:56:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 15:56:46 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-08 15:56:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-08 15:56:46 --> Config Class Initialized
INFO - 2016-11-08 15:56:46 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:56:46 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:56:46 --> Utf8 Class Initialized
INFO - 2016-11-08 15:56:46 --> URI Class Initialized
DEBUG - 2016-11-08 15:56:46 --> No URI present. Default controller set.
INFO - 2016-11-08 15:56:46 --> Router Class Initialized
INFO - 2016-11-08 15:56:46 --> Output Class Initialized
INFO - 2016-11-08 15:56:46 --> Security Class Initialized
DEBUG - 2016-11-08 15:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:56:46 --> Input Class Initialized
INFO - 2016-11-08 15:56:46 --> Language Class Initialized
INFO - 2016-11-08 15:56:46 --> Loader Class Initialized
INFO - 2016-11-08 15:56:46 --> Helper loaded: url_helper
INFO - 2016-11-08 15:56:46 --> Helper loaded: form_helper
INFO - 2016-11-08 15:56:46 --> Database Driver Class Initialized
INFO - 2016-11-08 15:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:56:46 --> Controller Class Initialized
INFO - 2016-11-08 15:56:46 --> Model Class Initialized
INFO - 2016-11-08 15:56:46 --> Model Class Initialized
INFO - 2016-11-08 15:56:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:56:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 15:56:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:56:46 --> Final output sent to browser
DEBUG - 2016-11-08 15:56:46 --> Total execution time: 0.2237
INFO - 2016-11-08 15:56:58 --> Config Class Initialized
INFO - 2016-11-08 15:56:58 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:56:58 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:56:58 --> Utf8 Class Initialized
INFO - 2016-11-08 15:56:58 --> URI Class Initialized
INFO - 2016-11-08 15:56:58 --> Router Class Initialized
INFO - 2016-11-08 15:56:58 --> Output Class Initialized
INFO - 2016-11-08 15:56:58 --> Security Class Initialized
DEBUG - 2016-11-08 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:56:58 --> Input Class Initialized
INFO - 2016-11-08 15:56:58 --> Language Class Initialized
INFO - 2016-11-08 15:56:58 --> Loader Class Initialized
INFO - 2016-11-08 15:56:58 --> Helper loaded: url_helper
INFO - 2016-11-08 15:56:58 --> Helper loaded: form_helper
INFO - 2016-11-08 15:56:58 --> Database Driver Class Initialized
INFO - 2016-11-08 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:56:58 --> Controller Class Initialized
INFO - 2016-11-08 15:56:58 --> Model Class Initialized
INFO - 2016-11-08 15:56:58 --> Model Class Initialized
DEBUG - 2016-11-08 15:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 15:56:58 --> Model Class Initialized
INFO - 2016-11-08 15:56:58 --> Final output sent to browser
DEBUG - 2016-11-08 15:56:58 --> Total execution time: 0.2215
INFO - 2016-11-08 15:56:58 --> Config Class Initialized
INFO - 2016-11-08 15:56:58 --> Hooks Class Initialized
DEBUG - 2016-11-08 15:56:58 --> UTF-8 Support Enabled
INFO - 2016-11-08 15:56:58 --> Utf8 Class Initialized
INFO - 2016-11-08 15:56:58 --> URI Class Initialized
DEBUG - 2016-11-08 15:56:58 --> No URI present. Default controller set.
INFO - 2016-11-08 15:56:58 --> Router Class Initialized
INFO - 2016-11-08 15:56:58 --> Output Class Initialized
INFO - 2016-11-08 15:56:58 --> Security Class Initialized
DEBUG - 2016-11-08 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 15:56:58 --> Input Class Initialized
INFO - 2016-11-08 15:56:59 --> Language Class Initialized
INFO - 2016-11-08 15:56:59 --> Loader Class Initialized
INFO - 2016-11-08 15:56:59 --> Helper loaded: url_helper
INFO - 2016-11-08 15:56:59 --> Helper loaded: form_helper
INFO - 2016-11-08 15:56:59 --> Database Driver Class Initialized
INFO - 2016-11-08 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 15:56:59 --> Controller Class Initialized
INFO - 2016-11-08 15:56:59 --> Model Class Initialized
INFO - 2016-11-08 15:56:59 --> Model Class Initialized
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 15:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 15:56:59 --> Final output sent to browser
DEBUG - 2016-11-08 15:56:59 --> Total execution time: 0.2689
INFO - 2016-11-08 16:00:38 --> Config Class Initialized
INFO - 2016-11-08 16:00:38 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:00:38 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:00:38 --> Utf8 Class Initialized
INFO - 2016-11-08 16:00:38 --> URI Class Initialized
DEBUG - 2016-11-08 16:00:38 --> No URI present. Default controller set.
INFO - 2016-11-08 16:00:38 --> Router Class Initialized
INFO - 2016-11-08 16:00:38 --> Output Class Initialized
INFO - 2016-11-08 16:00:38 --> Security Class Initialized
DEBUG - 2016-11-08 16:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:00:38 --> Input Class Initialized
INFO - 2016-11-08 16:00:38 --> Language Class Initialized
INFO - 2016-11-08 16:00:38 --> Loader Class Initialized
INFO - 2016-11-08 16:00:38 --> Helper loaded: url_helper
INFO - 2016-11-08 16:00:38 --> Helper loaded: form_helper
INFO - 2016-11-08 16:00:38 --> Database Driver Class Initialized
INFO - 2016-11-08 16:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:00:38 --> Controller Class Initialized
INFO - 2016-11-08 16:00:38 --> Model Class Initialized
INFO - 2016-11-08 16:00:38 --> Model Class Initialized
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:00:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:00:39 --> Final output sent to browser
DEBUG - 2016-11-08 16:00:39 --> Total execution time: 0.3348
INFO - 2016-11-08 16:00:58 --> Config Class Initialized
INFO - 2016-11-08 16:00:58 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:00:58 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:00:58 --> Utf8 Class Initialized
INFO - 2016-11-08 16:00:58 --> URI Class Initialized
DEBUG - 2016-11-08 16:00:58 --> No URI present. Default controller set.
INFO - 2016-11-08 16:00:58 --> Router Class Initialized
INFO - 2016-11-08 16:00:58 --> Output Class Initialized
INFO - 2016-11-08 16:00:58 --> Security Class Initialized
DEBUG - 2016-11-08 16:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:00:58 --> Input Class Initialized
INFO - 2016-11-08 16:00:58 --> Language Class Initialized
INFO - 2016-11-08 16:00:58 --> Loader Class Initialized
INFO - 2016-11-08 16:00:58 --> Helper loaded: url_helper
INFO - 2016-11-08 16:00:58 --> Helper loaded: form_helper
INFO - 2016-11-08 16:00:58 --> Database Driver Class Initialized
INFO - 2016-11-08 16:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:00:58 --> Controller Class Initialized
INFO - 2016-11-08 16:00:58 --> Model Class Initialized
INFO - 2016-11-08 16:00:58 --> Model Class Initialized
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:00:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:00:58 --> Final output sent to browser
DEBUG - 2016-11-08 16:00:58 --> Total execution time: 0.3109
INFO - 2016-11-08 16:02:14 --> Config Class Initialized
INFO - 2016-11-08 16:02:14 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:02:14 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:02:14 --> Utf8 Class Initialized
INFO - 2016-11-08 16:02:14 --> URI Class Initialized
DEBUG - 2016-11-08 16:02:14 --> No URI present. Default controller set.
INFO - 2016-11-08 16:02:14 --> Router Class Initialized
INFO - 2016-11-08 16:02:14 --> Output Class Initialized
INFO - 2016-11-08 16:02:14 --> Security Class Initialized
DEBUG - 2016-11-08 16:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:02:14 --> Input Class Initialized
INFO - 2016-11-08 16:02:14 --> Language Class Initialized
INFO - 2016-11-08 16:02:14 --> Loader Class Initialized
INFO - 2016-11-08 16:02:14 --> Helper loaded: url_helper
INFO - 2016-11-08 16:02:14 --> Helper loaded: form_helper
INFO - 2016-11-08 16:02:14 --> Database Driver Class Initialized
INFO - 2016-11-08 16:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:02:14 --> Controller Class Initialized
INFO - 2016-11-08 16:02:14 --> Model Class Initialized
INFO - 2016-11-08 16:02:14 --> Model Class Initialized
INFO - 2016-11-08 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:02:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:02:15 --> Final output sent to browser
DEBUG - 2016-11-08 16:02:15 --> Total execution time: 0.2746
INFO - 2016-11-08 16:02:52 --> Config Class Initialized
INFO - 2016-11-08 16:02:52 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:02:52 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:02:52 --> Utf8 Class Initialized
INFO - 2016-11-08 16:02:52 --> URI Class Initialized
DEBUG - 2016-11-08 16:02:52 --> No URI present. Default controller set.
INFO - 2016-11-08 16:02:52 --> Router Class Initialized
INFO - 2016-11-08 16:02:52 --> Output Class Initialized
INFO - 2016-11-08 16:02:52 --> Security Class Initialized
DEBUG - 2016-11-08 16:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:02:52 --> Input Class Initialized
INFO - 2016-11-08 16:02:52 --> Language Class Initialized
INFO - 2016-11-08 16:02:52 --> Loader Class Initialized
INFO - 2016-11-08 16:02:52 --> Helper loaded: url_helper
INFO - 2016-11-08 16:02:52 --> Helper loaded: form_helper
INFO - 2016-11-08 16:02:52 --> Database Driver Class Initialized
INFO - 2016-11-08 16:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:02:52 --> Controller Class Initialized
INFO - 2016-11-08 16:02:52 --> Model Class Initialized
INFO - 2016-11-08 16:02:52 --> Model Class Initialized
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:02:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:02:52 --> Final output sent to browser
DEBUG - 2016-11-08 16:02:52 --> Total execution time: 0.3238
INFO - 2016-11-08 16:04:53 --> Config Class Initialized
INFO - 2016-11-08 16:04:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:04:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:04:53 --> Utf8 Class Initialized
INFO - 2016-11-08 16:04:53 --> URI Class Initialized
DEBUG - 2016-11-08 16:04:53 --> No URI present. Default controller set.
INFO - 2016-11-08 16:04:53 --> Router Class Initialized
INFO - 2016-11-08 16:04:53 --> Output Class Initialized
INFO - 2016-11-08 16:04:53 --> Security Class Initialized
DEBUG - 2016-11-08 16:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:04:53 --> Input Class Initialized
INFO - 2016-11-08 16:04:53 --> Language Class Initialized
INFO - 2016-11-08 16:04:53 --> Loader Class Initialized
INFO - 2016-11-08 16:04:53 --> Helper loaded: url_helper
INFO - 2016-11-08 16:04:53 --> Helper loaded: form_helper
INFO - 2016-11-08 16:04:53 --> Database Driver Class Initialized
INFO - 2016-11-08 16:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:04:53 --> Controller Class Initialized
INFO - 2016-11-08 16:04:53 --> Model Class Initialized
INFO - 2016-11-08 16:04:53 --> Model Class Initialized
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:04:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:04:53 --> Final output sent to browser
DEBUG - 2016-11-08 16:04:53 --> Total execution time: 0.2937
INFO - 2016-11-08 16:06:24 --> Config Class Initialized
INFO - 2016-11-08 16:06:24 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:06:24 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:06:24 --> Utf8 Class Initialized
INFO - 2016-11-08 16:06:24 --> URI Class Initialized
DEBUG - 2016-11-08 16:06:24 --> No URI present. Default controller set.
INFO - 2016-11-08 16:06:24 --> Router Class Initialized
INFO - 2016-11-08 16:06:24 --> Output Class Initialized
INFO - 2016-11-08 16:06:24 --> Security Class Initialized
DEBUG - 2016-11-08 16:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:06:24 --> Input Class Initialized
INFO - 2016-11-08 16:06:24 --> Language Class Initialized
INFO - 2016-11-08 16:06:24 --> Loader Class Initialized
INFO - 2016-11-08 16:06:24 --> Helper loaded: url_helper
INFO - 2016-11-08 16:06:24 --> Helper loaded: form_helper
INFO - 2016-11-08 16:06:24 --> Database Driver Class Initialized
INFO - 2016-11-08 16:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:06:24 --> Controller Class Initialized
INFO - 2016-11-08 16:06:24 --> Model Class Initialized
INFO - 2016-11-08 16:06:25 --> Model Class Initialized
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:06:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:06:25 --> Final output sent to browser
DEBUG - 2016-11-08 16:06:25 --> Total execution time: 0.2948
INFO - 2016-11-08 16:06:45 --> Config Class Initialized
INFO - 2016-11-08 16:06:45 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:06:45 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:06:45 --> Utf8 Class Initialized
INFO - 2016-11-08 16:06:45 --> URI Class Initialized
DEBUG - 2016-11-08 16:06:45 --> No URI present. Default controller set.
INFO - 2016-11-08 16:06:45 --> Router Class Initialized
INFO - 2016-11-08 16:06:45 --> Output Class Initialized
INFO - 2016-11-08 16:06:45 --> Security Class Initialized
DEBUG - 2016-11-08 16:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:06:45 --> Input Class Initialized
INFO - 2016-11-08 16:06:45 --> Language Class Initialized
INFO - 2016-11-08 16:06:45 --> Loader Class Initialized
INFO - 2016-11-08 16:06:45 --> Helper loaded: url_helper
INFO - 2016-11-08 16:06:45 --> Helper loaded: form_helper
INFO - 2016-11-08 16:06:45 --> Database Driver Class Initialized
INFO - 2016-11-08 16:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:06:45 --> Controller Class Initialized
INFO - 2016-11-08 16:06:45 --> Model Class Initialized
INFO - 2016-11-08 16:06:45 --> Model Class Initialized
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:06:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:06:45 --> Final output sent to browser
DEBUG - 2016-11-08 16:06:45 --> Total execution time: 0.3120
INFO - 2016-11-08 16:11:26 --> Config Class Initialized
INFO - 2016-11-08 16:11:26 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:11:26 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:11:26 --> Utf8 Class Initialized
INFO - 2016-11-08 16:11:26 --> URI Class Initialized
DEBUG - 2016-11-08 16:11:26 --> No URI present. Default controller set.
INFO - 2016-11-08 16:11:26 --> Router Class Initialized
INFO - 2016-11-08 16:11:26 --> Output Class Initialized
INFO - 2016-11-08 16:11:26 --> Security Class Initialized
DEBUG - 2016-11-08 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:11:26 --> Input Class Initialized
INFO - 2016-11-08 16:11:26 --> Language Class Initialized
INFO - 2016-11-08 16:11:26 --> Loader Class Initialized
INFO - 2016-11-08 16:11:26 --> Helper loaded: url_helper
INFO - 2016-11-08 16:11:26 --> Helper loaded: form_helper
INFO - 2016-11-08 16:11:26 --> Database Driver Class Initialized
INFO - 2016-11-08 16:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:11:26 --> Controller Class Initialized
INFO - 2016-11-08 16:11:26 --> Model Class Initialized
INFO - 2016-11-08 16:11:26 --> Model Class Initialized
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:11:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:11:26 --> Final output sent to browser
DEBUG - 2016-11-08 16:11:26 --> Total execution time: 0.3213
INFO - 2016-11-08 16:15:14 --> Config Class Initialized
INFO - 2016-11-08 16:15:14 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:15:14 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:15:14 --> Utf8 Class Initialized
INFO - 2016-11-08 16:15:14 --> URI Class Initialized
DEBUG - 2016-11-08 16:15:14 --> No URI present. Default controller set.
INFO - 2016-11-08 16:15:14 --> Router Class Initialized
INFO - 2016-11-08 16:15:14 --> Output Class Initialized
INFO - 2016-11-08 16:15:14 --> Security Class Initialized
DEBUG - 2016-11-08 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:15:15 --> Input Class Initialized
INFO - 2016-11-08 16:15:15 --> Language Class Initialized
INFO - 2016-11-08 16:15:15 --> Loader Class Initialized
INFO - 2016-11-08 16:15:15 --> Helper loaded: url_helper
INFO - 2016-11-08 16:15:15 --> Helper loaded: form_helper
INFO - 2016-11-08 16:15:15 --> Database Driver Class Initialized
INFO - 2016-11-08 16:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:15:15 --> Controller Class Initialized
INFO - 2016-11-08 16:15:15 --> Model Class Initialized
INFO - 2016-11-08 16:15:15 --> Model Class Initialized
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:15:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:15:15 --> Final output sent to browser
DEBUG - 2016-11-08 16:15:15 --> Total execution time: 0.3132
INFO - 2016-11-08 16:15:57 --> Config Class Initialized
INFO - 2016-11-08 16:15:57 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:15:57 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:15:57 --> Utf8 Class Initialized
INFO - 2016-11-08 16:15:57 --> URI Class Initialized
DEBUG - 2016-11-08 16:15:57 --> No URI present. Default controller set.
INFO - 2016-11-08 16:15:57 --> Router Class Initialized
INFO - 2016-11-08 16:15:57 --> Output Class Initialized
INFO - 2016-11-08 16:15:57 --> Security Class Initialized
DEBUG - 2016-11-08 16:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:15:57 --> Input Class Initialized
INFO - 2016-11-08 16:15:57 --> Language Class Initialized
INFO - 2016-11-08 16:15:57 --> Loader Class Initialized
INFO - 2016-11-08 16:15:57 --> Helper loaded: url_helper
INFO - 2016-11-08 16:15:57 --> Helper loaded: form_helper
INFO - 2016-11-08 16:15:57 --> Database Driver Class Initialized
INFO - 2016-11-08 16:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:15:57 --> Controller Class Initialized
INFO - 2016-11-08 16:15:57 --> Model Class Initialized
INFO - 2016-11-08 16:15:57 --> Model Class Initialized
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:15:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:15:57 --> Final output sent to browser
DEBUG - 2016-11-08 16:15:57 --> Total execution time: 0.3105
INFO - 2016-11-08 16:16:54 --> Config Class Initialized
INFO - 2016-11-08 16:16:54 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:16:54 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:16:54 --> Utf8 Class Initialized
INFO - 2016-11-08 16:16:54 --> URI Class Initialized
DEBUG - 2016-11-08 16:16:54 --> No URI present. Default controller set.
INFO - 2016-11-08 16:16:54 --> Router Class Initialized
INFO - 2016-11-08 16:16:54 --> Output Class Initialized
INFO - 2016-11-08 16:16:54 --> Security Class Initialized
DEBUG - 2016-11-08 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:16:54 --> Input Class Initialized
INFO - 2016-11-08 16:16:54 --> Language Class Initialized
INFO - 2016-11-08 16:16:54 --> Loader Class Initialized
INFO - 2016-11-08 16:16:54 --> Helper loaded: url_helper
INFO - 2016-11-08 16:16:54 --> Helper loaded: form_helper
INFO - 2016-11-08 16:16:54 --> Database Driver Class Initialized
INFO - 2016-11-08 16:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:16:54 --> Controller Class Initialized
INFO - 2016-11-08 16:16:54 --> Model Class Initialized
INFO - 2016-11-08 16:16:54 --> Model Class Initialized
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:16:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:16:54 --> Final output sent to browser
DEBUG - 2016-11-08 16:16:54 --> Total execution time: 0.3739
INFO - 2016-11-08 16:17:27 --> Config Class Initialized
INFO - 2016-11-08 16:17:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:17:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:17:27 --> Utf8 Class Initialized
INFO - 2016-11-08 16:17:27 --> URI Class Initialized
DEBUG - 2016-11-08 16:17:27 --> No URI present. Default controller set.
INFO - 2016-11-08 16:17:27 --> Router Class Initialized
INFO - 2016-11-08 16:17:27 --> Output Class Initialized
INFO - 2016-11-08 16:17:27 --> Security Class Initialized
DEBUG - 2016-11-08 16:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:17:27 --> Input Class Initialized
INFO - 2016-11-08 16:17:27 --> Language Class Initialized
INFO - 2016-11-08 16:17:27 --> Loader Class Initialized
INFO - 2016-11-08 16:17:27 --> Helper loaded: url_helper
INFO - 2016-11-08 16:17:27 --> Helper loaded: form_helper
INFO - 2016-11-08 16:17:27 --> Database Driver Class Initialized
INFO - 2016-11-08 16:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:17:27 --> Controller Class Initialized
INFO - 2016-11-08 16:17:27 --> Model Class Initialized
INFO - 2016-11-08 16:17:27 --> Model Class Initialized
INFO - 2016-11-08 16:17:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:17:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:17:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:17:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:17:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:17:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:17:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:17:28 --> Final output sent to browser
DEBUG - 2016-11-08 16:17:28 --> Total execution time: 0.3331
INFO - 2016-11-08 16:19:36 --> Config Class Initialized
INFO - 2016-11-08 16:19:36 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:19:36 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:19:36 --> Utf8 Class Initialized
INFO - 2016-11-08 16:19:36 --> URI Class Initialized
DEBUG - 2016-11-08 16:19:36 --> No URI present. Default controller set.
INFO - 2016-11-08 16:19:36 --> Router Class Initialized
INFO - 2016-11-08 16:19:36 --> Output Class Initialized
INFO - 2016-11-08 16:19:36 --> Security Class Initialized
DEBUG - 2016-11-08 16:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:19:36 --> Input Class Initialized
INFO - 2016-11-08 16:19:36 --> Language Class Initialized
INFO - 2016-11-08 16:19:36 --> Loader Class Initialized
INFO - 2016-11-08 16:19:36 --> Helper loaded: url_helper
INFO - 2016-11-08 16:19:36 --> Helper loaded: form_helper
INFO - 2016-11-08 16:19:36 --> Database Driver Class Initialized
INFO - 2016-11-08 16:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:19:36 --> Controller Class Initialized
INFO - 2016-11-08 16:19:36 --> Model Class Initialized
INFO - 2016-11-08 16:19:36 --> Model Class Initialized
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:19:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:19:36 --> Final output sent to browser
DEBUG - 2016-11-08 16:19:36 --> Total execution time: 0.3530
INFO - 2016-11-08 16:20:07 --> Config Class Initialized
INFO - 2016-11-08 16:20:07 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:20:07 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:20:07 --> Utf8 Class Initialized
INFO - 2016-11-08 16:20:07 --> URI Class Initialized
DEBUG - 2016-11-08 16:20:07 --> No URI present. Default controller set.
INFO - 2016-11-08 16:20:07 --> Router Class Initialized
INFO - 2016-11-08 16:20:07 --> Output Class Initialized
INFO - 2016-11-08 16:20:07 --> Security Class Initialized
DEBUG - 2016-11-08 16:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:20:07 --> Input Class Initialized
INFO - 2016-11-08 16:20:07 --> Language Class Initialized
INFO - 2016-11-08 16:20:07 --> Loader Class Initialized
INFO - 2016-11-08 16:20:07 --> Helper loaded: url_helper
INFO - 2016-11-08 16:20:07 --> Helper loaded: form_helper
INFO - 2016-11-08 16:20:07 --> Database Driver Class Initialized
INFO - 2016-11-08 16:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:20:07 --> Controller Class Initialized
INFO - 2016-11-08 16:20:07 --> Model Class Initialized
INFO - 2016-11-08 16:20:07 --> Model Class Initialized
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:20:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:20:07 --> Final output sent to browser
DEBUG - 2016-11-08 16:20:07 --> Total execution time: 0.3117
INFO - 2016-11-08 16:20:22 --> Config Class Initialized
INFO - 2016-11-08 16:20:22 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:20:22 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:20:22 --> Utf8 Class Initialized
INFO - 2016-11-08 16:20:22 --> URI Class Initialized
DEBUG - 2016-11-08 16:20:22 --> No URI present. Default controller set.
INFO - 2016-11-08 16:20:22 --> Router Class Initialized
INFO - 2016-11-08 16:20:22 --> Output Class Initialized
INFO - 2016-11-08 16:20:22 --> Security Class Initialized
DEBUG - 2016-11-08 16:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:20:22 --> Input Class Initialized
INFO - 2016-11-08 16:20:22 --> Language Class Initialized
INFO - 2016-11-08 16:20:22 --> Loader Class Initialized
INFO - 2016-11-08 16:20:22 --> Helper loaded: url_helper
INFO - 2016-11-08 16:20:22 --> Helper loaded: form_helper
INFO - 2016-11-08 16:20:22 --> Database Driver Class Initialized
INFO - 2016-11-08 16:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:20:22 --> Controller Class Initialized
INFO - 2016-11-08 16:20:22 --> Model Class Initialized
INFO - 2016-11-08 16:20:22 --> Model Class Initialized
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:20:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:20:22 --> Final output sent to browser
DEBUG - 2016-11-08 16:20:23 --> Total execution time: 0.3160
INFO - 2016-11-08 16:21:02 --> Config Class Initialized
INFO - 2016-11-08 16:21:02 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:21:02 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:21:02 --> Utf8 Class Initialized
INFO - 2016-11-08 16:21:02 --> URI Class Initialized
DEBUG - 2016-11-08 16:21:02 --> No URI present. Default controller set.
INFO - 2016-11-08 16:21:02 --> Router Class Initialized
INFO - 2016-11-08 16:21:02 --> Output Class Initialized
INFO - 2016-11-08 16:21:02 --> Security Class Initialized
DEBUG - 2016-11-08 16:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:21:02 --> Input Class Initialized
INFO - 2016-11-08 16:21:02 --> Language Class Initialized
INFO - 2016-11-08 16:21:02 --> Loader Class Initialized
INFO - 2016-11-08 16:21:02 --> Helper loaded: url_helper
INFO - 2016-11-08 16:21:02 --> Helper loaded: form_helper
INFO - 2016-11-08 16:21:02 --> Database Driver Class Initialized
INFO - 2016-11-08 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:21:02 --> Controller Class Initialized
INFO - 2016-11-08 16:21:02 --> Model Class Initialized
INFO - 2016-11-08 16:21:02 --> Model Class Initialized
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:21:02 --> Final output sent to browser
DEBUG - 2016-11-08 16:21:02 --> Total execution time: 0.3002
INFO - 2016-11-08 16:21:27 --> Config Class Initialized
INFO - 2016-11-08 16:21:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:21:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:21:27 --> Utf8 Class Initialized
INFO - 2016-11-08 16:21:27 --> URI Class Initialized
DEBUG - 2016-11-08 16:21:27 --> No URI present. Default controller set.
INFO - 2016-11-08 16:21:27 --> Router Class Initialized
INFO - 2016-11-08 16:21:27 --> Output Class Initialized
INFO - 2016-11-08 16:21:27 --> Security Class Initialized
DEBUG - 2016-11-08 16:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:21:27 --> Input Class Initialized
INFO - 2016-11-08 16:21:27 --> Language Class Initialized
INFO - 2016-11-08 16:21:27 --> Loader Class Initialized
INFO - 2016-11-08 16:21:27 --> Helper loaded: url_helper
INFO - 2016-11-08 16:21:27 --> Helper loaded: form_helper
INFO - 2016-11-08 16:21:27 --> Database Driver Class Initialized
INFO - 2016-11-08 16:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:21:27 --> Controller Class Initialized
INFO - 2016-11-08 16:21:27 --> Model Class Initialized
INFO - 2016-11-08 16:21:27 --> Model Class Initialized
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:21:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:21:28 --> Final output sent to browser
DEBUG - 2016-11-08 16:21:28 --> Total execution time: 0.3256
INFO - 2016-11-08 16:23:25 --> Config Class Initialized
INFO - 2016-11-08 16:23:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:23:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:23:25 --> Utf8 Class Initialized
INFO - 2016-11-08 16:23:25 --> URI Class Initialized
DEBUG - 2016-11-08 16:23:25 --> No URI present. Default controller set.
INFO - 2016-11-08 16:23:25 --> Router Class Initialized
INFO - 2016-11-08 16:23:25 --> Output Class Initialized
INFO - 2016-11-08 16:23:25 --> Security Class Initialized
DEBUG - 2016-11-08 16:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:23:26 --> Input Class Initialized
INFO - 2016-11-08 16:23:26 --> Language Class Initialized
INFO - 2016-11-08 16:23:26 --> Loader Class Initialized
INFO - 2016-11-08 16:23:26 --> Helper loaded: url_helper
INFO - 2016-11-08 16:23:26 --> Helper loaded: form_helper
INFO - 2016-11-08 16:23:26 --> Database Driver Class Initialized
INFO - 2016-11-08 16:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:23:26 --> Controller Class Initialized
INFO - 2016-11-08 16:23:26 --> Model Class Initialized
INFO - 2016-11-08 16:23:26 --> Model Class Initialized
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:23:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:23:26 --> Final output sent to browser
DEBUG - 2016-11-08 16:23:26 --> Total execution time: 0.3671
INFO - 2016-11-08 16:24:08 --> Config Class Initialized
INFO - 2016-11-08 16:24:08 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:24:08 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:24:08 --> Utf8 Class Initialized
INFO - 2016-11-08 16:24:08 --> URI Class Initialized
DEBUG - 2016-11-08 16:24:09 --> No URI present. Default controller set.
INFO - 2016-11-08 16:24:09 --> Router Class Initialized
INFO - 2016-11-08 16:24:09 --> Output Class Initialized
INFO - 2016-11-08 16:24:09 --> Security Class Initialized
DEBUG - 2016-11-08 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:24:09 --> Input Class Initialized
INFO - 2016-11-08 16:24:09 --> Language Class Initialized
INFO - 2016-11-08 16:24:09 --> Loader Class Initialized
INFO - 2016-11-08 16:24:09 --> Helper loaded: url_helper
INFO - 2016-11-08 16:24:09 --> Helper loaded: form_helper
INFO - 2016-11-08 16:24:09 --> Database Driver Class Initialized
INFO - 2016-11-08 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:24:09 --> Controller Class Initialized
INFO - 2016-11-08 16:24:09 --> Model Class Initialized
INFO - 2016-11-08 16:24:09 --> Model Class Initialized
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:24:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:24:09 --> Final output sent to browser
DEBUG - 2016-11-08 16:24:09 --> Total execution time: 0.3983
INFO - 2016-11-08 16:25:22 --> Config Class Initialized
INFO - 2016-11-08 16:25:22 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:25:22 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:25:22 --> Utf8 Class Initialized
INFO - 2016-11-08 16:25:22 --> URI Class Initialized
DEBUG - 2016-11-08 16:25:22 --> No URI present. Default controller set.
INFO - 2016-11-08 16:25:23 --> Router Class Initialized
INFO - 2016-11-08 16:25:23 --> Output Class Initialized
INFO - 2016-11-08 16:25:23 --> Security Class Initialized
DEBUG - 2016-11-08 16:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:25:23 --> Input Class Initialized
INFO - 2016-11-08 16:25:23 --> Language Class Initialized
INFO - 2016-11-08 16:25:23 --> Loader Class Initialized
INFO - 2016-11-08 16:25:23 --> Helper loaded: url_helper
INFO - 2016-11-08 16:25:23 --> Helper loaded: form_helper
INFO - 2016-11-08 16:25:23 --> Database Driver Class Initialized
INFO - 2016-11-08 16:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:25:23 --> Controller Class Initialized
INFO - 2016-11-08 16:25:23 --> Model Class Initialized
INFO - 2016-11-08 16:25:23 --> Model Class Initialized
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:25:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:25:23 --> Final output sent to browser
DEBUG - 2016-11-08 16:25:23 --> Total execution time: 0.3210
INFO - 2016-11-08 16:27:03 --> Config Class Initialized
INFO - 2016-11-08 16:27:03 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:27:03 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:27:03 --> Utf8 Class Initialized
INFO - 2016-11-08 16:27:03 --> URI Class Initialized
DEBUG - 2016-11-08 16:27:03 --> No URI present. Default controller set.
INFO - 2016-11-08 16:27:03 --> Router Class Initialized
INFO - 2016-11-08 16:27:03 --> Output Class Initialized
INFO - 2016-11-08 16:27:03 --> Security Class Initialized
DEBUG - 2016-11-08 16:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:27:03 --> Input Class Initialized
INFO - 2016-11-08 16:27:03 --> Language Class Initialized
INFO - 2016-11-08 16:27:03 --> Loader Class Initialized
INFO - 2016-11-08 16:27:03 --> Helper loaded: url_helper
INFO - 2016-11-08 16:27:03 --> Helper loaded: form_helper
INFO - 2016-11-08 16:27:03 --> Database Driver Class Initialized
INFO - 2016-11-08 16:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:27:03 --> Controller Class Initialized
INFO - 2016-11-08 16:27:03 --> Model Class Initialized
INFO - 2016-11-08 16:27:03 --> Model Class Initialized
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:27:03 --> Final output sent to browser
DEBUG - 2016-11-08 16:27:03 --> Total execution time: 0.3335
INFO - 2016-11-08 16:29:03 --> Config Class Initialized
INFO - 2016-11-08 16:29:03 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:29:03 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:29:03 --> Utf8 Class Initialized
INFO - 2016-11-08 16:29:03 --> URI Class Initialized
DEBUG - 2016-11-08 16:29:03 --> No URI present. Default controller set.
INFO - 2016-11-08 16:29:03 --> Router Class Initialized
INFO - 2016-11-08 16:29:03 --> Output Class Initialized
INFO - 2016-11-08 16:29:03 --> Security Class Initialized
DEBUG - 2016-11-08 16:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:29:03 --> Input Class Initialized
INFO - 2016-11-08 16:29:03 --> Language Class Initialized
INFO - 2016-11-08 16:29:03 --> Loader Class Initialized
INFO - 2016-11-08 16:29:03 --> Helper loaded: url_helper
INFO - 2016-11-08 16:29:03 --> Helper loaded: form_helper
INFO - 2016-11-08 16:29:03 --> Database Driver Class Initialized
INFO - 2016-11-08 16:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:29:03 --> Controller Class Initialized
INFO - 2016-11-08 16:29:03 --> Model Class Initialized
INFO - 2016-11-08 16:29:03 --> Model Class Initialized
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:29:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:29:03 --> Final output sent to browser
DEBUG - 2016-11-08 16:29:03 --> Total execution time: 0.3301
INFO - 2016-11-08 16:29:55 --> Config Class Initialized
INFO - 2016-11-08 16:29:55 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:29:55 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:29:55 --> Utf8 Class Initialized
INFO - 2016-11-08 16:29:55 --> URI Class Initialized
DEBUG - 2016-11-08 16:29:55 --> No URI present. Default controller set.
INFO - 2016-11-08 16:29:55 --> Router Class Initialized
INFO - 2016-11-08 16:29:55 --> Output Class Initialized
INFO - 2016-11-08 16:29:55 --> Security Class Initialized
DEBUG - 2016-11-08 16:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:29:55 --> Input Class Initialized
INFO - 2016-11-08 16:29:55 --> Language Class Initialized
INFO - 2016-11-08 16:29:55 --> Loader Class Initialized
INFO - 2016-11-08 16:29:55 --> Helper loaded: url_helper
INFO - 2016-11-08 16:29:55 --> Helper loaded: form_helper
INFO - 2016-11-08 16:29:55 --> Database Driver Class Initialized
INFO - 2016-11-08 16:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:29:55 --> Controller Class Initialized
INFO - 2016-11-08 16:29:55 --> Model Class Initialized
INFO - 2016-11-08 16:29:55 --> Model Class Initialized
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:29:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:29:55 --> Final output sent to browser
DEBUG - 2016-11-08 16:29:55 --> Total execution time: 0.3364
INFO - 2016-11-08 16:31:54 --> Config Class Initialized
INFO - 2016-11-08 16:31:54 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:31:54 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:31:54 --> Utf8 Class Initialized
INFO - 2016-11-08 16:31:54 --> URI Class Initialized
DEBUG - 2016-11-08 16:31:54 --> No URI present. Default controller set.
INFO - 2016-11-08 16:31:54 --> Router Class Initialized
INFO - 2016-11-08 16:31:54 --> Output Class Initialized
INFO - 2016-11-08 16:31:54 --> Security Class Initialized
DEBUG - 2016-11-08 16:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:31:54 --> Input Class Initialized
INFO - 2016-11-08 16:31:54 --> Language Class Initialized
INFO - 2016-11-08 16:31:54 --> Loader Class Initialized
INFO - 2016-11-08 16:31:54 --> Helper loaded: url_helper
INFO - 2016-11-08 16:31:54 --> Helper loaded: form_helper
INFO - 2016-11-08 16:31:54 --> Database Driver Class Initialized
INFO - 2016-11-08 16:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:31:54 --> Controller Class Initialized
INFO - 2016-11-08 16:31:54 --> Model Class Initialized
INFO - 2016-11-08 16:31:54 --> Model Class Initialized
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:31:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:31:54 --> Final output sent to browser
DEBUG - 2016-11-08 16:31:54 --> Total execution time: 0.3370
INFO - 2016-11-08 16:32:10 --> Config Class Initialized
INFO - 2016-11-08 16:32:10 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:32:10 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:32:10 --> Utf8 Class Initialized
INFO - 2016-11-08 16:32:10 --> URI Class Initialized
DEBUG - 2016-11-08 16:32:10 --> No URI present. Default controller set.
INFO - 2016-11-08 16:32:10 --> Router Class Initialized
INFO - 2016-11-08 16:32:10 --> Output Class Initialized
INFO - 2016-11-08 16:32:10 --> Security Class Initialized
DEBUG - 2016-11-08 16:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:32:10 --> Input Class Initialized
INFO - 2016-11-08 16:32:10 --> Language Class Initialized
INFO - 2016-11-08 16:32:10 --> Loader Class Initialized
INFO - 2016-11-08 16:32:10 --> Helper loaded: url_helper
INFO - 2016-11-08 16:32:10 --> Helper loaded: form_helper
INFO - 2016-11-08 16:32:10 --> Database Driver Class Initialized
INFO - 2016-11-08 16:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:32:10 --> Controller Class Initialized
INFO - 2016-11-08 16:32:10 --> Model Class Initialized
INFO - 2016-11-08 16:32:10 --> Model Class Initialized
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:32:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:32:10 --> Final output sent to browser
DEBUG - 2016-11-08 16:32:10 --> Total execution time: 0.3501
INFO - 2016-11-08 16:32:32 --> Config Class Initialized
INFO - 2016-11-08 16:32:32 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:32:32 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:32:32 --> Utf8 Class Initialized
INFO - 2016-11-08 16:32:32 --> URI Class Initialized
DEBUG - 2016-11-08 16:32:32 --> No URI present. Default controller set.
INFO - 2016-11-08 16:32:32 --> Router Class Initialized
INFO - 2016-11-08 16:32:32 --> Output Class Initialized
INFO - 2016-11-08 16:32:32 --> Security Class Initialized
DEBUG - 2016-11-08 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:32:32 --> Input Class Initialized
INFO - 2016-11-08 16:32:32 --> Language Class Initialized
INFO - 2016-11-08 16:32:32 --> Loader Class Initialized
INFO - 2016-11-08 16:32:32 --> Helper loaded: url_helper
INFO - 2016-11-08 16:32:32 --> Helper loaded: form_helper
INFO - 2016-11-08 16:32:32 --> Database Driver Class Initialized
INFO - 2016-11-08 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:32:32 --> Controller Class Initialized
INFO - 2016-11-08 16:32:32 --> Model Class Initialized
INFO - 2016-11-08 16:32:32 --> Model Class Initialized
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:32:32 --> Final output sent to browser
DEBUG - 2016-11-08 16:32:32 --> Total execution time: 0.3379
INFO - 2016-11-08 16:34:14 --> Config Class Initialized
INFO - 2016-11-08 16:34:14 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:34:14 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:34:14 --> Utf8 Class Initialized
INFO - 2016-11-08 16:34:14 --> URI Class Initialized
DEBUG - 2016-11-08 16:34:14 --> No URI present. Default controller set.
INFO - 2016-11-08 16:34:14 --> Router Class Initialized
INFO - 2016-11-08 16:34:14 --> Output Class Initialized
INFO - 2016-11-08 16:34:14 --> Security Class Initialized
DEBUG - 2016-11-08 16:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:34:14 --> Input Class Initialized
INFO - 2016-11-08 16:34:14 --> Language Class Initialized
INFO - 2016-11-08 16:34:14 --> Loader Class Initialized
INFO - 2016-11-08 16:34:14 --> Helper loaded: url_helper
INFO - 2016-11-08 16:34:14 --> Helper loaded: form_helper
INFO - 2016-11-08 16:34:14 --> Database Driver Class Initialized
INFO - 2016-11-08 16:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:34:14 --> Controller Class Initialized
INFO - 2016-11-08 16:34:14 --> Model Class Initialized
INFO - 2016-11-08 16:34:14 --> Model Class Initialized
INFO - 2016-11-08 16:34:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:34:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:34:15 --> Final output sent to browser
DEBUG - 2016-11-08 16:34:15 --> Total execution time: 0.3268
INFO - 2016-11-08 16:34:42 --> Config Class Initialized
INFO - 2016-11-08 16:34:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:34:42 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:34:42 --> Utf8 Class Initialized
INFO - 2016-11-08 16:34:42 --> URI Class Initialized
DEBUG - 2016-11-08 16:34:42 --> No URI present. Default controller set.
INFO - 2016-11-08 16:34:42 --> Router Class Initialized
INFO - 2016-11-08 16:34:42 --> Output Class Initialized
INFO - 2016-11-08 16:34:42 --> Security Class Initialized
DEBUG - 2016-11-08 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:34:42 --> Input Class Initialized
INFO - 2016-11-08 16:34:42 --> Language Class Initialized
INFO - 2016-11-08 16:34:42 --> Loader Class Initialized
INFO - 2016-11-08 16:34:42 --> Helper loaded: url_helper
INFO - 2016-11-08 16:34:42 --> Helper loaded: form_helper
INFO - 2016-11-08 16:34:42 --> Database Driver Class Initialized
INFO - 2016-11-08 16:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:34:42 --> Controller Class Initialized
INFO - 2016-11-08 16:34:42 --> Model Class Initialized
INFO - 2016-11-08 16:34:42 --> Model Class Initialized
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:34:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:34:42 --> Final output sent to browser
DEBUG - 2016-11-08 16:34:42 --> Total execution time: 0.3437
INFO - 2016-11-08 16:34:48 --> Config Class Initialized
INFO - 2016-11-08 16:34:48 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:34:48 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:34:48 --> Utf8 Class Initialized
INFO - 2016-11-08 16:34:48 --> URI Class Initialized
DEBUG - 2016-11-08 16:34:48 --> No URI present. Default controller set.
INFO - 2016-11-08 16:34:48 --> Router Class Initialized
INFO - 2016-11-08 16:34:48 --> Output Class Initialized
INFO - 2016-11-08 16:34:48 --> Security Class Initialized
DEBUG - 2016-11-08 16:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:34:48 --> Input Class Initialized
INFO - 2016-11-08 16:34:48 --> Language Class Initialized
INFO - 2016-11-08 16:34:48 --> Loader Class Initialized
INFO - 2016-11-08 16:34:48 --> Helper loaded: url_helper
INFO - 2016-11-08 16:34:48 --> Helper loaded: form_helper
INFO - 2016-11-08 16:34:48 --> Database Driver Class Initialized
INFO - 2016-11-08 16:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:34:48 --> Controller Class Initialized
INFO - 2016-11-08 16:34:48 --> Model Class Initialized
INFO - 2016-11-08 16:34:48 --> Model Class Initialized
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:34:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:34:48 --> Final output sent to browser
DEBUG - 2016-11-08 16:34:48 --> Total execution time: 0.3337
INFO - 2016-11-08 16:34:50 --> Config Class Initialized
INFO - 2016-11-08 16:34:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:34:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:34:50 --> Utf8 Class Initialized
INFO - 2016-11-08 16:34:50 --> URI Class Initialized
INFO - 2016-11-08 16:34:50 --> Router Class Initialized
INFO - 2016-11-08 16:34:50 --> Output Class Initialized
INFO - 2016-11-08 16:34:50 --> Security Class Initialized
DEBUG - 2016-11-08 16:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:34:51 --> Input Class Initialized
INFO - 2016-11-08 16:34:51 --> Language Class Initialized
INFO - 2016-11-08 16:34:51 --> Loader Class Initialized
INFO - 2016-11-08 16:34:51 --> Helper loaded: url_helper
INFO - 2016-11-08 16:34:51 --> Helper loaded: form_helper
INFO - 2016-11-08 16:34:51 --> Database Driver Class Initialized
INFO - 2016-11-08 16:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:34:51 --> Controller Class Initialized
INFO - 2016-11-08 16:34:51 --> Final output sent to browser
DEBUG - 2016-11-08 16:34:51 --> Total execution time: 0.2154
INFO - 2016-11-08 16:34:53 --> Config Class Initialized
INFO - 2016-11-08 16:34:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:34:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:34:53 --> Utf8 Class Initialized
INFO - 2016-11-08 16:34:53 --> URI Class Initialized
DEBUG - 2016-11-08 16:34:53 --> No URI present. Default controller set.
INFO - 2016-11-08 16:34:53 --> Router Class Initialized
INFO - 2016-11-08 16:34:53 --> Output Class Initialized
INFO - 2016-11-08 16:34:53 --> Security Class Initialized
DEBUG - 2016-11-08 16:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:34:53 --> Input Class Initialized
INFO - 2016-11-08 16:34:53 --> Language Class Initialized
INFO - 2016-11-08 16:34:53 --> Loader Class Initialized
INFO - 2016-11-08 16:34:53 --> Helper loaded: url_helper
INFO - 2016-11-08 16:34:53 --> Helper loaded: form_helper
INFO - 2016-11-08 16:34:53 --> Database Driver Class Initialized
INFO - 2016-11-08 16:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:34:53 --> Controller Class Initialized
INFO - 2016-11-08 16:34:53 --> Model Class Initialized
INFO - 2016-11-08 16:34:53 --> Model Class Initialized
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:34:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:34:53 --> Final output sent to browser
DEBUG - 2016-11-08 16:34:53 --> Total execution time: 0.3157
INFO - 2016-11-08 16:37:12 --> Config Class Initialized
INFO - 2016-11-08 16:37:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:37:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:37:12 --> Utf8 Class Initialized
INFO - 2016-11-08 16:37:12 --> URI Class Initialized
INFO - 2016-11-08 16:37:12 --> Router Class Initialized
INFO - 2016-11-08 16:37:12 --> Output Class Initialized
INFO - 2016-11-08 16:37:12 --> Security Class Initialized
DEBUG - 2016-11-08 16:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:37:12 --> Input Class Initialized
INFO - 2016-11-08 16:37:12 --> Language Class Initialized
INFO - 2016-11-08 16:37:12 --> Loader Class Initialized
INFO - 2016-11-08 16:37:12 --> Helper loaded: url_helper
INFO - 2016-11-08 16:37:12 --> Helper loaded: form_helper
INFO - 2016-11-08 16:37:12 --> Database Driver Class Initialized
INFO - 2016-11-08 16:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:37:12 --> Controller Class Initialized
INFO - 2016-11-08 16:37:12 --> Final output sent to browser
DEBUG - 2016-11-08 16:37:12 --> Total execution time: 0.2295
INFO - 2016-11-08 16:37:16 --> Config Class Initialized
INFO - 2016-11-08 16:37:16 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:37:16 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:37:16 --> Utf8 Class Initialized
INFO - 2016-11-08 16:37:16 --> URI Class Initialized
DEBUG - 2016-11-08 16:37:16 --> No URI present. Default controller set.
INFO - 2016-11-08 16:37:16 --> Router Class Initialized
INFO - 2016-11-08 16:37:16 --> Output Class Initialized
INFO - 2016-11-08 16:37:16 --> Security Class Initialized
DEBUG - 2016-11-08 16:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:37:16 --> Input Class Initialized
INFO - 2016-11-08 16:37:16 --> Language Class Initialized
INFO - 2016-11-08 16:37:16 --> Loader Class Initialized
INFO - 2016-11-08 16:37:16 --> Helper loaded: url_helper
INFO - 2016-11-08 16:37:16 --> Helper loaded: form_helper
INFO - 2016-11-08 16:37:16 --> Database Driver Class Initialized
INFO - 2016-11-08 16:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:37:16 --> Controller Class Initialized
INFO - 2016-11-08 16:37:16 --> Model Class Initialized
INFO - 2016-11-08 16:37:16 --> Model Class Initialized
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:37:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:37:16 --> Final output sent to browser
DEBUG - 2016-11-08 16:37:16 --> Total execution time: 0.3165
INFO - 2016-11-08 16:44:54 --> Config Class Initialized
INFO - 2016-11-08 16:44:54 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:44:54 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:44:54 --> Utf8 Class Initialized
INFO - 2016-11-08 16:44:54 --> URI Class Initialized
DEBUG - 2016-11-08 16:44:54 --> No URI present. Default controller set.
INFO - 2016-11-08 16:44:54 --> Router Class Initialized
INFO - 2016-11-08 16:44:54 --> Output Class Initialized
INFO - 2016-11-08 16:44:54 --> Security Class Initialized
DEBUG - 2016-11-08 16:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:44:54 --> Input Class Initialized
INFO - 2016-11-08 16:44:54 --> Language Class Initialized
INFO - 2016-11-08 16:44:54 --> Loader Class Initialized
INFO - 2016-11-08 16:44:54 --> Helper loaded: url_helper
INFO - 2016-11-08 16:44:54 --> Helper loaded: form_helper
INFO - 2016-11-08 16:44:54 --> Database Driver Class Initialized
INFO - 2016-11-08 16:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:44:54 --> Controller Class Initialized
INFO - 2016-11-08 16:44:54 --> Model Class Initialized
INFO - 2016-11-08 16:44:54 --> Model Class Initialized
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:44:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:44:54 --> Final output sent to browser
DEBUG - 2016-11-08 16:44:54 --> Total execution time: 0.3702
INFO - 2016-11-08 16:48:20 --> Config Class Initialized
INFO - 2016-11-08 16:48:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:48:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:48:20 --> Utf8 Class Initialized
INFO - 2016-11-08 16:48:20 --> URI Class Initialized
DEBUG - 2016-11-08 16:48:20 --> No URI present. Default controller set.
INFO - 2016-11-08 16:48:20 --> Router Class Initialized
INFO - 2016-11-08 16:48:20 --> Output Class Initialized
INFO - 2016-11-08 16:48:20 --> Security Class Initialized
DEBUG - 2016-11-08 16:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:48:20 --> Input Class Initialized
INFO - 2016-11-08 16:48:20 --> Language Class Initialized
INFO - 2016-11-08 16:48:20 --> Loader Class Initialized
INFO - 2016-11-08 16:48:20 --> Helper loaded: url_helper
INFO - 2016-11-08 16:48:20 --> Helper loaded: form_helper
INFO - 2016-11-08 16:48:20 --> Database Driver Class Initialized
INFO - 2016-11-08 16:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:48:20 --> Controller Class Initialized
INFO - 2016-11-08 16:48:20 --> Model Class Initialized
INFO - 2016-11-08 16:48:20 --> Model Class Initialized
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:48:20 --> Final output sent to browser
DEBUG - 2016-11-08 16:48:20 --> Total execution time: 0.3166
INFO - 2016-11-08 16:48:23 --> Config Class Initialized
INFO - 2016-11-08 16:48:23 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:48:23 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:48:23 --> Utf8 Class Initialized
INFO - 2016-11-08 16:48:23 --> URI Class Initialized
INFO - 2016-11-08 16:48:23 --> Router Class Initialized
INFO - 2016-11-08 16:48:23 --> Output Class Initialized
INFO - 2016-11-08 16:48:23 --> Security Class Initialized
DEBUG - 2016-11-08 16:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:48:23 --> Input Class Initialized
INFO - 2016-11-08 16:48:23 --> Language Class Initialized
INFO - 2016-11-08 16:48:23 --> Loader Class Initialized
INFO - 2016-11-08 16:48:23 --> Helper loaded: url_helper
INFO - 2016-11-08 16:48:23 --> Helper loaded: form_helper
INFO - 2016-11-08 16:48:23 --> Database Driver Class Initialized
INFO - 2016-11-08 16:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:48:23 --> Controller Class Initialized
INFO - 2016-11-08 16:48:23 --> Form Validation Class Initialized
INFO - 2016-11-08 16:48:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 16:48:23 --> Final output sent to browser
DEBUG - 2016-11-08 16:48:23 --> Total execution time: 0.3941
INFO - 2016-11-08 16:48:29 --> Config Class Initialized
INFO - 2016-11-08 16:48:29 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:48:29 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:48:29 --> Utf8 Class Initialized
INFO - 2016-11-08 16:48:29 --> URI Class Initialized
DEBUG - 2016-11-08 16:48:29 --> No URI present. Default controller set.
INFO - 2016-11-08 16:48:29 --> Router Class Initialized
INFO - 2016-11-08 16:48:29 --> Output Class Initialized
INFO - 2016-11-08 16:48:29 --> Security Class Initialized
DEBUG - 2016-11-08 16:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:48:29 --> Input Class Initialized
INFO - 2016-11-08 16:48:29 --> Language Class Initialized
INFO - 2016-11-08 16:48:29 --> Loader Class Initialized
INFO - 2016-11-08 16:48:29 --> Helper loaded: url_helper
INFO - 2016-11-08 16:48:29 --> Helper loaded: form_helper
INFO - 2016-11-08 16:48:29 --> Database Driver Class Initialized
INFO - 2016-11-08 16:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:48:29 --> Controller Class Initialized
INFO - 2016-11-08 16:48:29 --> Model Class Initialized
INFO - 2016-11-08 16:48:29 --> Model Class Initialized
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:48:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:48:29 --> Final output sent to browser
DEBUG - 2016-11-08 16:48:29 --> Total execution time: 0.3398
INFO - 2016-11-08 16:53:50 --> Config Class Initialized
INFO - 2016-11-08 16:53:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:53:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:53:50 --> Utf8 Class Initialized
INFO - 2016-11-08 16:53:50 --> URI Class Initialized
DEBUG - 2016-11-08 16:53:50 --> No URI present. Default controller set.
INFO - 2016-11-08 16:53:50 --> Router Class Initialized
INFO - 2016-11-08 16:53:50 --> Output Class Initialized
INFO - 2016-11-08 16:53:50 --> Security Class Initialized
DEBUG - 2016-11-08 16:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:53:50 --> Input Class Initialized
INFO - 2016-11-08 16:53:50 --> Language Class Initialized
INFO - 2016-11-08 16:53:50 --> Loader Class Initialized
INFO - 2016-11-08 16:53:50 --> Helper loaded: url_helper
INFO - 2016-11-08 16:53:50 --> Helper loaded: form_helper
INFO - 2016-11-08 16:53:50 --> Database Driver Class Initialized
INFO - 2016-11-08 16:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:53:50 --> Controller Class Initialized
INFO - 2016-11-08 16:53:50 --> Model Class Initialized
INFO - 2016-11-08 16:53:50 --> Model Class Initialized
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:53:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:53:50 --> Final output sent to browser
DEBUG - 2016-11-08 16:53:50 --> Total execution time: 0.3889
INFO - 2016-11-08 16:53:53 --> Config Class Initialized
INFO - 2016-11-08 16:53:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:53:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:53:53 --> Utf8 Class Initialized
INFO - 2016-11-08 16:53:53 --> URI Class Initialized
INFO - 2016-11-08 16:53:53 --> Router Class Initialized
INFO - 2016-11-08 16:53:53 --> Output Class Initialized
INFO - 2016-11-08 16:53:53 --> Security Class Initialized
DEBUG - 2016-11-08 16:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:53:53 --> Input Class Initialized
INFO - 2016-11-08 16:53:53 --> Language Class Initialized
INFO - 2016-11-08 16:53:53 --> Loader Class Initialized
INFO - 2016-11-08 16:53:53 --> Helper loaded: url_helper
INFO - 2016-11-08 16:53:53 --> Helper loaded: form_helper
INFO - 2016-11-08 16:53:53 --> Database Driver Class Initialized
INFO - 2016-11-08 16:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:53:53 --> Controller Class Initialized
ERROR - 2016-11-08 16:53:53 --> Severity: error --> Exception: C:\xampp\htdocs\LMS\app\models/Leave_application_m.php exists, but doesn't declare class Leave_application_m C:\xampp\htdocs\LMS\sys\core\Loader.php 336
INFO - 2016-11-08 16:54:15 --> Config Class Initialized
INFO - 2016-11-08 16:54:15 --> Hooks Class Initialized
DEBUG - 2016-11-08 16:54:15 --> UTF-8 Support Enabled
INFO - 2016-11-08 16:54:15 --> Utf8 Class Initialized
INFO - 2016-11-08 16:54:15 --> URI Class Initialized
DEBUG - 2016-11-08 16:54:15 --> No URI present. Default controller set.
INFO - 2016-11-08 16:54:15 --> Router Class Initialized
INFO - 2016-11-08 16:54:15 --> Output Class Initialized
INFO - 2016-11-08 16:54:15 --> Security Class Initialized
DEBUG - 2016-11-08 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 16:54:15 --> Input Class Initialized
INFO - 2016-11-08 16:54:15 --> Language Class Initialized
INFO - 2016-11-08 16:54:15 --> Loader Class Initialized
INFO - 2016-11-08 16:54:15 --> Helper loaded: url_helper
INFO - 2016-11-08 16:54:15 --> Helper loaded: form_helper
INFO - 2016-11-08 16:54:15 --> Database Driver Class Initialized
INFO - 2016-11-08 16:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 16:54:15 --> Controller Class Initialized
INFO - 2016-11-08 16:54:15 --> Model Class Initialized
INFO - 2016-11-08 16:54:15 --> Model Class Initialized
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 16:54:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 16:54:15 --> Final output sent to browser
DEBUG - 2016-11-08 16:54:15 --> Total execution time: 0.3317
INFO - 2016-11-08 17:10:07 --> Config Class Initialized
INFO - 2016-11-08 17:10:07 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:10:07 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:10:07 --> Utf8 Class Initialized
INFO - 2016-11-08 17:10:07 --> URI Class Initialized
INFO - 2016-11-08 17:10:08 --> Router Class Initialized
INFO - 2016-11-08 17:10:08 --> Output Class Initialized
INFO - 2016-11-08 17:10:08 --> Security Class Initialized
DEBUG - 2016-11-08 17:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:10:08 --> Input Class Initialized
INFO - 2016-11-08 17:10:08 --> Language Class Initialized
INFO - 2016-11-08 17:10:08 --> Loader Class Initialized
INFO - 2016-11-08 17:10:08 --> Helper loaded: url_helper
INFO - 2016-11-08 17:10:08 --> Helper loaded: form_helper
INFO - 2016-11-08 17:10:08 --> Database Driver Class Initialized
INFO - 2016-11-08 17:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:10:08 --> Controller Class Initialized
ERROR - 2016-11-08 17:10:08 --> Severity: error --> Exception: C:\xampp\htdocs\LMS\app\models/Leave_application_m.php exists, but doesn't declare class Leave_application_m C:\xampp\htdocs\LMS\sys\core\Loader.php 336
INFO - 2016-11-08 17:10:10 --> Config Class Initialized
INFO - 2016-11-08 17:10:10 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:10:10 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:10:10 --> Utf8 Class Initialized
INFO - 2016-11-08 17:10:10 --> URI Class Initialized
DEBUG - 2016-11-08 17:10:10 --> No URI present. Default controller set.
INFO - 2016-11-08 17:10:10 --> Router Class Initialized
INFO - 2016-11-08 17:10:10 --> Output Class Initialized
INFO - 2016-11-08 17:10:10 --> Security Class Initialized
DEBUG - 2016-11-08 17:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:10:10 --> Input Class Initialized
INFO - 2016-11-08 17:10:10 --> Language Class Initialized
INFO - 2016-11-08 17:10:10 --> Loader Class Initialized
INFO - 2016-11-08 17:10:10 --> Helper loaded: url_helper
INFO - 2016-11-08 17:10:10 --> Helper loaded: form_helper
INFO - 2016-11-08 17:10:10 --> Database Driver Class Initialized
INFO - 2016-11-08 17:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:10:10 --> Controller Class Initialized
INFO - 2016-11-08 17:10:10 --> Model Class Initialized
INFO - 2016-11-08 17:10:10 --> Model Class Initialized
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:10:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:10:10 --> Final output sent to browser
DEBUG - 2016-11-08 17:10:10 --> Total execution time: 0.3560
INFO - 2016-11-08 17:18:33 --> Config Class Initialized
INFO - 2016-11-08 17:18:33 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:18:33 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:18:33 --> Utf8 Class Initialized
INFO - 2016-11-08 17:18:33 --> URI Class Initialized
DEBUG - 2016-11-08 17:18:33 --> No URI present. Default controller set.
INFO - 2016-11-08 17:18:33 --> Router Class Initialized
INFO - 2016-11-08 17:18:33 --> Output Class Initialized
INFO - 2016-11-08 17:18:33 --> Security Class Initialized
DEBUG - 2016-11-08 17:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:18:33 --> Input Class Initialized
INFO - 2016-11-08 17:18:33 --> Language Class Initialized
INFO - 2016-11-08 17:18:33 --> Loader Class Initialized
INFO - 2016-11-08 17:18:33 --> Helper loaded: url_helper
INFO - 2016-11-08 17:18:33 --> Helper loaded: form_helper
INFO - 2016-11-08 17:18:33 --> Database Driver Class Initialized
INFO - 2016-11-08 17:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:18:33 --> Controller Class Initialized
INFO - 2016-11-08 17:18:33 --> Model Class Initialized
INFO - 2016-11-08 17:18:33 --> Model Class Initialized
INFO - 2016-11-08 17:18:33 --> Model Class Initialized
INFO - 2016-11-08 17:18:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:18:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:18:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:18:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:18:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:18:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:18:34 --> Final output sent to browser
DEBUG - 2016-11-08 17:18:34 --> Total execution time: 0.3447
INFO - 2016-11-08 17:47:06 --> Config Class Initialized
INFO - 2016-11-08 17:47:06 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:47:06 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:47:06 --> Utf8 Class Initialized
INFO - 2016-11-08 17:47:06 --> URI Class Initialized
DEBUG - 2016-11-08 17:47:06 --> No URI present. Default controller set.
INFO - 2016-11-08 17:47:06 --> Router Class Initialized
INFO - 2016-11-08 17:47:06 --> Output Class Initialized
INFO - 2016-11-08 17:47:06 --> Security Class Initialized
DEBUG - 2016-11-08 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:47:06 --> Input Class Initialized
INFO - 2016-11-08 17:47:06 --> Language Class Initialized
INFO - 2016-11-08 17:47:06 --> Loader Class Initialized
INFO - 2016-11-08 17:47:06 --> Helper loaded: url_helper
INFO - 2016-11-08 17:47:06 --> Helper loaded: form_helper
INFO - 2016-11-08 17:47:06 --> Database Driver Class Initialized
INFO - 2016-11-08 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:47:06 --> Controller Class Initialized
INFO - 2016-11-08 17:47:06 --> Model Class Initialized
INFO - 2016-11-08 17:47:06 --> Model Class Initialized
INFO - 2016-11-08 17:47:06 --> Model Class Initialized
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:47:06 --> Final output sent to browser
DEBUG - 2016-11-08 17:47:06 --> Total execution time: 0.3390
INFO - 2016-11-08 17:51:04 --> Config Class Initialized
INFO - 2016-11-08 17:51:04 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:51:04 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:51:04 --> Utf8 Class Initialized
INFO - 2016-11-08 17:51:04 --> URI Class Initialized
DEBUG - 2016-11-08 17:51:04 --> No URI present. Default controller set.
INFO - 2016-11-08 17:51:04 --> Router Class Initialized
INFO - 2016-11-08 17:51:04 --> Output Class Initialized
INFO - 2016-11-08 17:51:04 --> Security Class Initialized
DEBUG - 2016-11-08 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:51:04 --> Input Class Initialized
INFO - 2016-11-08 17:51:04 --> Language Class Initialized
INFO - 2016-11-08 17:51:04 --> Loader Class Initialized
INFO - 2016-11-08 17:51:04 --> Helper loaded: url_helper
INFO - 2016-11-08 17:51:04 --> Helper loaded: form_helper
INFO - 2016-11-08 17:51:04 --> Database Driver Class Initialized
INFO - 2016-11-08 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:51:04 --> Controller Class Initialized
INFO - 2016-11-08 17:51:04 --> Model Class Initialized
INFO - 2016-11-08 17:51:04 --> Model Class Initialized
INFO - 2016-11-08 17:51:04 --> Model Class Initialized
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:51:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:51:04 --> Final output sent to browser
DEBUG - 2016-11-08 17:51:04 --> Total execution time: 0.3616
INFO - 2016-11-08 17:51:07 --> Config Class Initialized
INFO - 2016-11-08 17:51:07 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:51:07 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:51:07 --> Utf8 Class Initialized
INFO - 2016-11-08 17:51:07 --> URI Class Initialized
INFO - 2016-11-08 17:51:07 --> Router Class Initialized
INFO - 2016-11-08 17:51:07 --> Output Class Initialized
INFO - 2016-11-08 17:51:07 --> Security Class Initialized
DEBUG - 2016-11-08 17:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:51:07 --> Input Class Initialized
INFO - 2016-11-08 17:51:07 --> Language Class Initialized
ERROR - 2016-11-08 17:51:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 57
INFO - 2016-11-08 17:51:31 --> Config Class Initialized
INFO - 2016-11-08 17:51:31 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:51:31 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:51:31 --> Utf8 Class Initialized
INFO - 2016-11-08 17:51:31 --> URI Class Initialized
INFO - 2016-11-08 17:51:31 --> Router Class Initialized
INFO - 2016-11-08 17:51:31 --> Output Class Initialized
INFO - 2016-11-08 17:51:31 --> Security Class Initialized
DEBUG - 2016-11-08 17:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:51:31 --> Input Class Initialized
INFO - 2016-11-08 17:51:31 --> Language Class Initialized
INFO - 2016-11-08 17:51:31 --> Loader Class Initialized
INFO - 2016-11-08 17:51:31 --> Helper loaded: url_helper
INFO - 2016-11-08 17:51:31 --> Helper loaded: form_helper
INFO - 2016-11-08 17:51:31 --> Database Driver Class Initialized
INFO - 2016-11-08 17:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:51:31 --> Controller Class Initialized
INFO - 2016-11-08 17:51:31 --> Model Class Initialized
INFO - 2016-11-08 17:51:31 --> Form Validation Class Initialized
INFO - 2016-11-08 17:51:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 17:51:31 --> Final output sent to browser
DEBUG - 2016-11-08 17:51:31 --> Total execution time: 0.2405
INFO - 2016-11-08 17:52:16 --> Config Class Initialized
INFO - 2016-11-08 17:52:16 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:52:16 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:52:16 --> Utf8 Class Initialized
INFO - 2016-11-08 17:52:16 --> URI Class Initialized
DEBUG - 2016-11-08 17:52:16 --> No URI present. Default controller set.
INFO - 2016-11-08 17:52:16 --> Router Class Initialized
INFO - 2016-11-08 17:52:16 --> Output Class Initialized
INFO - 2016-11-08 17:52:16 --> Security Class Initialized
DEBUG - 2016-11-08 17:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:52:16 --> Input Class Initialized
INFO - 2016-11-08 17:52:16 --> Language Class Initialized
INFO - 2016-11-08 17:52:16 --> Loader Class Initialized
INFO - 2016-11-08 17:52:16 --> Helper loaded: url_helper
INFO - 2016-11-08 17:52:16 --> Helper loaded: form_helper
INFO - 2016-11-08 17:52:16 --> Database Driver Class Initialized
INFO - 2016-11-08 17:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:52:16 --> Controller Class Initialized
INFO - 2016-11-08 17:52:16 --> Model Class Initialized
INFO - 2016-11-08 17:52:16 --> Model Class Initialized
INFO - 2016-11-08 17:52:16 --> Model Class Initialized
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:52:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:52:16 --> Final output sent to browser
DEBUG - 2016-11-08 17:52:16 --> Total execution time: 0.3580
INFO - 2016-11-08 17:53:44 --> Config Class Initialized
INFO - 2016-11-08 17:53:44 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:53:44 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:53:44 --> Utf8 Class Initialized
INFO - 2016-11-08 17:53:44 --> URI Class Initialized
DEBUG - 2016-11-08 17:53:44 --> No URI present. Default controller set.
INFO - 2016-11-08 17:53:44 --> Router Class Initialized
INFO - 2016-11-08 17:53:44 --> Output Class Initialized
INFO - 2016-11-08 17:53:44 --> Security Class Initialized
DEBUG - 2016-11-08 17:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:53:44 --> Input Class Initialized
INFO - 2016-11-08 17:53:44 --> Language Class Initialized
INFO - 2016-11-08 17:53:44 --> Loader Class Initialized
INFO - 2016-11-08 17:53:44 --> Helper loaded: url_helper
INFO - 2016-11-08 17:53:44 --> Helper loaded: form_helper
INFO - 2016-11-08 17:53:44 --> Database Driver Class Initialized
INFO - 2016-11-08 17:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:53:44 --> Controller Class Initialized
INFO - 2016-11-08 17:53:44 --> Model Class Initialized
INFO - 2016-11-08 17:53:44 --> Model Class Initialized
INFO - 2016-11-08 17:53:44 --> Model Class Initialized
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:53:44 --> Final output sent to browser
DEBUG - 2016-11-08 17:53:44 --> Total execution time: 0.3387
INFO - 2016-11-08 17:54:31 --> Config Class Initialized
INFO - 2016-11-08 17:54:31 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:54:31 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:54:31 --> Utf8 Class Initialized
INFO - 2016-11-08 17:54:31 --> URI Class Initialized
INFO - 2016-11-08 17:54:31 --> Router Class Initialized
INFO - 2016-11-08 17:54:31 --> Output Class Initialized
INFO - 2016-11-08 17:54:31 --> Security Class Initialized
DEBUG - 2016-11-08 17:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:54:31 --> Input Class Initialized
INFO - 2016-11-08 17:54:31 --> Language Class Initialized
INFO - 2016-11-08 17:54:31 --> Loader Class Initialized
INFO - 2016-11-08 17:54:31 --> Helper loaded: url_helper
INFO - 2016-11-08 17:54:31 --> Helper loaded: form_helper
INFO - 2016-11-08 17:54:32 --> Database Driver Class Initialized
INFO - 2016-11-08 17:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:54:32 --> Controller Class Initialized
INFO - 2016-11-08 17:54:32 --> Model Class Initialized
INFO - 2016-11-08 17:54:32 --> Form Validation Class Initialized
INFO - 2016-11-08 17:54:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-08 17:54:32 --> Query error: Unknown column 'surname' in 'field list' - Invalid query: INSERT INTO `applicationData` (`surname`, `initial`, `telephone`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-20', '10', '1', '2016-11-08 17:54:32', NULL, NULL)
INFO - 2016-11-08 17:54:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-08 17:56:00 --> Config Class Initialized
INFO - 2016-11-08 17:56:00 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:56:00 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:56:00 --> Utf8 Class Initialized
INFO - 2016-11-08 17:56:00 --> URI Class Initialized
DEBUG - 2016-11-08 17:56:00 --> No URI present. Default controller set.
INFO - 2016-11-08 17:56:00 --> Router Class Initialized
INFO - 2016-11-08 17:56:00 --> Output Class Initialized
INFO - 2016-11-08 17:56:00 --> Security Class Initialized
DEBUG - 2016-11-08 17:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:56:00 --> Input Class Initialized
INFO - 2016-11-08 17:56:00 --> Language Class Initialized
INFO - 2016-11-08 17:56:00 --> Loader Class Initialized
INFO - 2016-11-08 17:56:00 --> Helper loaded: url_helper
INFO - 2016-11-08 17:56:00 --> Helper loaded: form_helper
INFO - 2016-11-08 17:56:00 --> Database Driver Class Initialized
INFO - 2016-11-08 17:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:56:00 --> Controller Class Initialized
INFO - 2016-11-08 17:56:00 --> Model Class Initialized
INFO - 2016-11-08 17:56:00 --> Model Class Initialized
INFO - 2016-11-08 17:56:00 --> Model Class Initialized
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:56:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:56:00 --> Final output sent to browser
DEBUG - 2016-11-08 17:56:00 --> Total execution time: 0.3511
INFO - 2016-11-08 17:56:04 --> Config Class Initialized
INFO - 2016-11-08 17:56:04 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:56:04 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:56:04 --> Utf8 Class Initialized
INFO - 2016-11-08 17:56:04 --> URI Class Initialized
INFO - 2016-11-08 17:56:04 --> Router Class Initialized
INFO - 2016-11-08 17:56:04 --> Output Class Initialized
INFO - 2016-11-08 17:56:04 --> Security Class Initialized
DEBUG - 2016-11-08 17:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:56:04 --> Input Class Initialized
INFO - 2016-11-08 17:56:04 --> Language Class Initialized
INFO - 2016-11-08 17:56:04 --> Loader Class Initialized
INFO - 2016-11-08 17:56:04 --> Helper loaded: url_helper
INFO - 2016-11-08 17:56:04 --> Helper loaded: form_helper
INFO - 2016-11-08 17:56:04 --> Database Driver Class Initialized
INFO - 2016-11-08 17:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:56:04 --> Controller Class Initialized
INFO - 2016-11-08 17:56:04 --> Model Class Initialized
INFO - 2016-11-08 17:56:04 --> Form Validation Class Initialized
INFO - 2016-11-08 17:56:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-08 17:56:04 --> Query error: Unknown column 'endDate' in 'field list' - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-20', '10', '1', '2016-11-08 17:56:04', NULL, NULL)
INFO - 2016-11-08 17:56:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-08 17:56:37 --> Config Class Initialized
INFO - 2016-11-08 17:56:37 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:56:37 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:56:37 --> Utf8 Class Initialized
INFO - 2016-11-08 17:56:37 --> URI Class Initialized
DEBUG - 2016-11-08 17:56:37 --> No URI present. Default controller set.
INFO - 2016-11-08 17:56:37 --> Router Class Initialized
INFO - 2016-11-08 17:56:37 --> Output Class Initialized
INFO - 2016-11-08 17:56:37 --> Security Class Initialized
DEBUG - 2016-11-08 17:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:56:37 --> Input Class Initialized
INFO - 2016-11-08 17:56:37 --> Language Class Initialized
INFO - 2016-11-08 17:56:37 --> Loader Class Initialized
INFO - 2016-11-08 17:56:37 --> Helper loaded: url_helper
INFO - 2016-11-08 17:56:37 --> Helper loaded: form_helper
INFO - 2016-11-08 17:56:37 --> Database Driver Class Initialized
INFO - 2016-11-08 17:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:56:37 --> Controller Class Initialized
INFO - 2016-11-08 17:56:37 --> Model Class Initialized
INFO - 2016-11-08 17:56:37 --> Model Class Initialized
INFO - 2016-11-08 17:56:37 --> Model Class Initialized
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:56:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:56:37 --> Final output sent to browser
DEBUG - 2016-11-08 17:56:37 --> Total execution time: 0.3690
INFO - 2016-11-08 17:56:40 --> Config Class Initialized
INFO - 2016-11-08 17:56:40 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:56:40 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:56:40 --> Utf8 Class Initialized
INFO - 2016-11-08 17:56:40 --> URI Class Initialized
INFO - 2016-11-08 17:56:40 --> Router Class Initialized
INFO - 2016-11-08 17:56:40 --> Output Class Initialized
INFO - 2016-11-08 17:56:40 --> Security Class Initialized
DEBUG - 2016-11-08 17:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:56:40 --> Input Class Initialized
INFO - 2016-11-08 17:56:40 --> Language Class Initialized
INFO - 2016-11-08 17:56:40 --> Loader Class Initialized
INFO - 2016-11-08 17:56:40 --> Helper loaded: url_helper
INFO - 2016-11-08 17:56:40 --> Helper loaded: form_helper
INFO - 2016-11-08 17:56:40 --> Database Driver Class Initialized
INFO - 2016-11-08 17:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:56:40 --> Controller Class Initialized
INFO - 2016-11-08 17:56:40 --> Model Class Initialized
INFO - 2016-11-08 17:56:40 --> Form Validation Class Initialized
INFO - 2016-11-08 17:56:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 17:56:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:56:40 --> Final output sent to browser
DEBUG - 2016-11-08 17:56:40 --> Total execution time: 0.3665
INFO - 2016-11-08 17:56:42 --> Config Class Initialized
INFO - 2016-11-08 17:56:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:56:42 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:56:42 --> Utf8 Class Initialized
INFO - 2016-11-08 17:56:42 --> URI Class Initialized
DEBUG - 2016-11-08 17:56:42 --> No URI present. Default controller set.
INFO - 2016-11-08 17:56:42 --> Router Class Initialized
INFO - 2016-11-08 17:56:42 --> Output Class Initialized
INFO - 2016-11-08 17:56:42 --> Security Class Initialized
DEBUG - 2016-11-08 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:56:42 --> Input Class Initialized
INFO - 2016-11-08 17:56:42 --> Language Class Initialized
INFO - 2016-11-08 17:56:42 --> Loader Class Initialized
INFO - 2016-11-08 17:56:42 --> Helper loaded: url_helper
INFO - 2016-11-08 17:56:42 --> Helper loaded: form_helper
INFO - 2016-11-08 17:56:42 --> Database Driver Class Initialized
INFO - 2016-11-08 17:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:56:42 --> Controller Class Initialized
INFO - 2016-11-08 17:56:42 --> Model Class Initialized
INFO - 2016-11-08 17:56:42 --> Model Class Initialized
INFO - 2016-11-08 17:56:42 --> Model Class Initialized
INFO - 2016-11-08 17:56:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:56:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:56:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:56:43 --> Final output sent to browser
DEBUG - 2016-11-08 17:56:43 --> Total execution time: 0.3614
INFO - 2016-11-08 17:59:25 --> Config Class Initialized
INFO - 2016-11-08 17:59:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:59:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:59:25 --> Utf8 Class Initialized
INFO - 2016-11-08 17:59:25 --> URI Class Initialized
DEBUG - 2016-11-08 17:59:25 --> No URI present. Default controller set.
INFO - 2016-11-08 17:59:25 --> Router Class Initialized
INFO - 2016-11-08 17:59:25 --> Output Class Initialized
INFO - 2016-11-08 17:59:25 --> Security Class Initialized
DEBUG - 2016-11-08 17:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:59:25 --> Input Class Initialized
INFO - 2016-11-08 17:59:25 --> Language Class Initialized
INFO - 2016-11-08 17:59:25 --> Loader Class Initialized
INFO - 2016-11-08 17:59:25 --> Helper loaded: url_helper
INFO - 2016-11-08 17:59:25 --> Helper loaded: form_helper
INFO - 2016-11-08 17:59:25 --> Database Driver Class Initialized
INFO - 2016-11-08 17:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:59:25 --> Controller Class Initialized
INFO - 2016-11-08 17:59:25 --> Model Class Initialized
INFO - 2016-11-08 17:59:25 --> Model Class Initialized
INFO - 2016-11-08 17:59:25 --> Model Class Initialized
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:59:25 --> Final output sent to browser
DEBUG - 2016-11-08 17:59:25 --> Total execution time: 0.3362
INFO - 2016-11-08 17:59:27 --> Config Class Initialized
INFO - 2016-11-08 17:59:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:59:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:59:27 --> Utf8 Class Initialized
INFO - 2016-11-08 17:59:27 --> URI Class Initialized
INFO - 2016-11-08 17:59:27 --> Router Class Initialized
INFO - 2016-11-08 17:59:27 --> Output Class Initialized
INFO - 2016-11-08 17:59:27 --> Security Class Initialized
DEBUG - 2016-11-08 17:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:59:27 --> Input Class Initialized
INFO - 2016-11-08 17:59:27 --> Language Class Initialized
INFO - 2016-11-08 17:59:27 --> Loader Class Initialized
INFO - 2016-11-08 17:59:27 --> Helper loaded: url_helper
INFO - 2016-11-08 17:59:27 --> Helper loaded: form_helper
INFO - 2016-11-08 17:59:27 --> Database Driver Class Initialized
INFO - 2016-11-08 17:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:59:27 --> Controller Class Initialized
INFO - 2016-11-08 17:59:27 --> Model Class Initialized
INFO - 2016-11-08 17:59:30 --> Config Class Initialized
INFO - 2016-11-08 17:59:30 --> Hooks Class Initialized
DEBUG - 2016-11-08 17:59:30 --> UTF-8 Support Enabled
INFO - 2016-11-08 17:59:30 --> Utf8 Class Initialized
INFO - 2016-11-08 17:59:30 --> URI Class Initialized
DEBUG - 2016-11-08 17:59:30 --> No URI present. Default controller set.
INFO - 2016-11-08 17:59:30 --> Router Class Initialized
INFO - 2016-11-08 17:59:30 --> Output Class Initialized
INFO - 2016-11-08 17:59:30 --> Security Class Initialized
DEBUG - 2016-11-08 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 17:59:30 --> Input Class Initialized
INFO - 2016-11-08 17:59:30 --> Language Class Initialized
INFO - 2016-11-08 17:59:30 --> Loader Class Initialized
INFO - 2016-11-08 17:59:30 --> Helper loaded: url_helper
INFO - 2016-11-08 17:59:30 --> Helper loaded: form_helper
INFO - 2016-11-08 17:59:30 --> Database Driver Class Initialized
INFO - 2016-11-08 17:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 17:59:30 --> Controller Class Initialized
INFO - 2016-11-08 17:59:30 --> Model Class Initialized
INFO - 2016-11-08 17:59:30 --> Model Class Initialized
INFO - 2016-11-08 17:59:30 --> Model Class Initialized
INFO - 2016-11-08 17:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 17:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 17:59:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 17:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 17:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 17:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 17:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 17:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 17:59:31 --> Final output sent to browser
DEBUG - 2016-11-08 17:59:31 --> Total execution time: 0.3730
INFO - 2016-11-08 18:00:06 --> Config Class Initialized
INFO - 2016-11-08 18:00:06 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:00:06 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:00:06 --> Utf8 Class Initialized
INFO - 2016-11-08 18:00:06 --> URI Class Initialized
DEBUG - 2016-11-08 18:00:06 --> No URI present. Default controller set.
INFO - 2016-11-08 18:00:06 --> Router Class Initialized
INFO - 2016-11-08 18:00:06 --> Output Class Initialized
INFO - 2016-11-08 18:00:06 --> Security Class Initialized
DEBUG - 2016-11-08 18:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:00:06 --> Input Class Initialized
INFO - 2016-11-08 18:00:06 --> Language Class Initialized
INFO - 2016-11-08 18:00:06 --> Loader Class Initialized
INFO - 2016-11-08 18:00:06 --> Helper loaded: url_helper
INFO - 2016-11-08 18:00:06 --> Helper loaded: form_helper
INFO - 2016-11-08 18:00:06 --> Database Driver Class Initialized
INFO - 2016-11-08 18:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:00:06 --> Controller Class Initialized
INFO - 2016-11-08 18:00:06 --> Model Class Initialized
INFO - 2016-11-08 18:00:06 --> Model Class Initialized
INFO - 2016-11-08 18:00:06 --> Model Class Initialized
INFO - 2016-11-08 18:00:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:00:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:00:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:00:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:00:07 --> Final output sent to browser
DEBUG - 2016-11-08 18:00:07 --> Total execution time: 0.3578
INFO - 2016-11-08 18:00:09 --> Config Class Initialized
INFO - 2016-11-08 18:00:09 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:00:09 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:00:09 --> Utf8 Class Initialized
INFO - 2016-11-08 18:00:09 --> URI Class Initialized
INFO - 2016-11-08 18:00:09 --> Router Class Initialized
INFO - 2016-11-08 18:00:09 --> Output Class Initialized
INFO - 2016-11-08 18:00:09 --> Security Class Initialized
DEBUG - 2016-11-08 18:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:00:09 --> Input Class Initialized
INFO - 2016-11-08 18:00:09 --> Language Class Initialized
INFO - 2016-11-08 18:00:09 --> Loader Class Initialized
INFO - 2016-11-08 18:00:09 --> Helper loaded: url_helper
INFO - 2016-11-08 18:00:09 --> Helper loaded: form_helper
INFO - 2016-11-08 18:00:09 --> Database Driver Class Initialized
INFO - 2016-11-08 18:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:00:09 --> Controller Class Initialized
INFO - 2016-11-08 18:00:09 --> Model Class Initialized
INFO - 2016-11-08 18:00:12 --> Config Class Initialized
INFO - 2016-11-08 18:00:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:00:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:00:12 --> Utf8 Class Initialized
INFO - 2016-11-08 18:00:12 --> URI Class Initialized
DEBUG - 2016-11-08 18:00:12 --> No URI present. Default controller set.
INFO - 2016-11-08 18:00:12 --> Router Class Initialized
INFO - 2016-11-08 18:00:12 --> Output Class Initialized
INFO - 2016-11-08 18:00:12 --> Security Class Initialized
DEBUG - 2016-11-08 18:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:00:12 --> Input Class Initialized
INFO - 2016-11-08 18:00:12 --> Language Class Initialized
INFO - 2016-11-08 18:00:12 --> Loader Class Initialized
INFO - 2016-11-08 18:00:12 --> Helper loaded: url_helper
INFO - 2016-11-08 18:00:12 --> Helper loaded: form_helper
INFO - 2016-11-08 18:00:12 --> Database Driver Class Initialized
INFO - 2016-11-08 18:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:00:12 --> Controller Class Initialized
INFO - 2016-11-08 18:00:12 --> Model Class Initialized
INFO - 2016-11-08 18:00:12 --> Model Class Initialized
INFO - 2016-11-08 18:00:12 --> Model Class Initialized
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:00:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:00:12 --> Final output sent to browser
DEBUG - 2016-11-08 18:00:12 --> Total execution time: 0.3724
INFO - 2016-11-08 18:01:39 --> Config Class Initialized
INFO - 2016-11-08 18:01:39 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:01:40 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:01:40 --> Utf8 Class Initialized
INFO - 2016-11-08 18:01:40 --> URI Class Initialized
DEBUG - 2016-11-08 18:01:40 --> No URI present. Default controller set.
INFO - 2016-11-08 18:01:40 --> Router Class Initialized
INFO - 2016-11-08 18:01:40 --> Output Class Initialized
INFO - 2016-11-08 18:01:40 --> Security Class Initialized
DEBUG - 2016-11-08 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:01:40 --> Input Class Initialized
INFO - 2016-11-08 18:01:40 --> Language Class Initialized
INFO - 2016-11-08 18:01:40 --> Loader Class Initialized
INFO - 2016-11-08 18:01:40 --> Helper loaded: url_helper
INFO - 2016-11-08 18:01:40 --> Helper loaded: form_helper
INFO - 2016-11-08 18:01:40 --> Database Driver Class Initialized
INFO - 2016-11-08 18:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:01:40 --> Controller Class Initialized
INFO - 2016-11-08 18:01:40 --> Model Class Initialized
INFO - 2016-11-08 18:01:40 --> Model Class Initialized
INFO - 2016-11-08 18:01:40 --> Model Class Initialized
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:01:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:01:40 --> Final output sent to browser
DEBUG - 2016-11-08 18:01:40 --> Total execution time: 0.3828
INFO - 2016-11-08 18:01:41 --> Config Class Initialized
INFO - 2016-11-08 18:01:41 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:01:41 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:01:41 --> Utf8 Class Initialized
INFO - 2016-11-08 18:01:41 --> URI Class Initialized
DEBUG - 2016-11-08 18:01:41 --> No URI present. Default controller set.
INFO - 2016-11-08 18:01:41 --> Router Class Initialized
INFO - 2016-11-08 18:01:41 --> Output Class Initialized
INFO - 2016-11-08 18:01:41 --> Security Class Initialized
DEBUG - 2016-11-08 18:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:01:41 --> Input Class Initialized
INFO - 2016-11-08 18:01:41 --> Language Class Initialized
INFO - 2016-11-08 18:01:41 --> Loader Class Initialized
INFO - 2016-11-08 18:01:41 --> Helper loaded: url_helper
INFO - 2016-11-08 18:01:41 --> Helper loaded: form_helper
INFO - 2016-11-08 18:01:41 --> Database Driver Class Initialized
INFO - 2016-11-08 18:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:01:41 --> Controller Class Initialized
INFO - 2016-11-08 18:01:41 --> Model Class Initialized
INFO - 2016-11-08 18:01:41 --> Model Class Initialized
INFO - 2016-11-08 18:01:41 --> Model Class Initialized
INFO - 2016-11-08 18:01:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:01:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:01:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:01:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:01:42 --> Final output sent to browser
DEBUG - 2016-11-08 18:01:42 --> Total execution time: 0.4030
INFO - 2016-11-08 18:01:46 --> Config Class Initialized
INFO - 2016-11-08 18:01:46 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:01:46 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:01:46 --> Utf8 Class Initialized
INFO - 2016-11-08 18:01:46 --> URI Class Initialized
INFO - 2016-11-08 18:01:46 --> Router Class Initialized
INFO - 2016-11-08 18:01:46 --> Output Class Initialized
INFO - 2016-11-08 18:01:46 --> Security Class Initialized
DEBUG - 2016-11-08 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:01:46 --> Input Class Initialized
INFO - 2016-11-08 18:01:46 --> Language Class Initialized
INFO - 2016-11-08 18:01:46 --> Loader Class Initialized
INFO - 2016-11-08 18:01:46 --> Helper loaded: url_helper
INFO - 2016-11-08 18:01:46 --> Helper loaded: form_helper
INFO - 2016-11-08 18:01:46 --> Database Driver Class Initialized
INFO - 2016-11-08 18:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:01:46 --> Controller Class Initialized
INFO - 2016-11-08 18:01:46 --> Model Class Initialized
INFO - 2016-11-08 18:01:46 --> Form Validation Class Initialized
INFO - 2016-11-08 18:01:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:01:46 --> Final output sent to browser
DEBUG - 2016-11-08 18:01:46 --> Total execution time: 0.3949
INFO - 2016-11-08 18:01:48 --> Config Class Initialized
INFO - 2016-11-08 18:01:48 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:01:48 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:01:48 --> Utf8 Class Initialized
INFO - 2016-11-08 18:01:48 --> URI Class Initialized
DEBUG - 2016-11-08 18:01:48 --> No URI present. Default controller set.
INFO - 2016-11-08 18:01:48 --> Router Class Initialized
INFO - 2016-11-08 18:01:48 --> Output Class Initialized
INFO - 2016-11-08 18:01:48 --> Security Class Initialized
DEBUG - 2016-11-08 18:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:01:48 --> Input Class Initialized
INFO - 2016-11-08 18:01:48 --> Language Class Initialized
INFO - 2016-11-08 18:01:48 --> Loader Class Initialized
INFO - 2016-11-08 18:01:48 --> Helper loaded: url_helper
INFO - 2016-11-08 18:01:48 --> Helper loaded: form_helper
INFO - 2016-11-08 18:01:48 --> Database Driver Class Initialized
INFO - 2016-11-08 18:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:01:48 --> Controller Class Initialized
INFO - 2016-11-08 18:01:48 --> Model Class Initialized
INFO - 2016-11-08 18:01:48 --> Model Class Initialized
INFO - 2016-11-08 18:01:48 --> Model Class Initialized
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:01:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:01:48 --> Final output sent to browser
DEBUG - 2016-11-08 18:01:48 --> Total execution time: 0.4243
INFO - 2016-11-08 18:09:35 --> Config Class Initialized
INFO - 2016-11-08 18:09:35 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:09:35 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:09:35 --> Utf8 Class Initialized
INFO - 2016-11-08 18:09:35 --> URI Class Initialized
DEBUG - 2016-11-08 18:09:35 --> No URI present. Default controller set.
INFO - 2016-11-08 18:09:35 --> Router Class Initialized
INFO - 2016-11-08 18:09:35 --> Output Class Initialized
INFO - 2016-11-08 18:09:35 --> Security Class Initialized
DEBUG - 2016-11-08 18:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:09:35 --> Input Class Initialized
INFO - 2016-11-08 18:09:35 --> Language Class Initialized
INFO - 2016-11-08 18:09:35 --> Loader Class Initialized
INFO - 2016-11-08 18:09:35 --> Helper loaded: url_helper
INFO - 2016-11-08 18:09:35 --> Helper loaded: form_helper
INFO - 2016-11-08 18:09:35 --> Database Driver Class Initialized
INFO - 2016-11-08 18:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:09:35 --> Controller Class Initialized
INFO - 2016-11-08 18:09:35 --> Model Class Initialized
INFO - 2016-11-08 18:09:35 --> Model Class Initialized
INFO - 2016-11-08 18:09:35 --> Model Class Initialized
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:09:35 --> Final output sent to browser
DEBUG - 2016-11-08 18:09:35 --> Total execution time: 0.4457
INFO - 2016-11-08 18:09:38 --> Config Class Initialized
INFO - 2016-11-08 18:09:38 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:09:38 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:09:38 --> Utf8 Class Initialized
INFO - 2016-11-08 18:09:38 --> URI Class Initialized
INFO - 2016-11-08 18:09:38 --> Router Class Initialized
INFO - 2016-11-08 18:09:38 --> Output Class Initialized
INFO - 2016-11-08 18:09:38 --> Security Class Initialized
DEBUG - 2016-11-08 18:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:09:38 --> Input Class Initialized
INFO - 2016-11-08 18:09:38 --> Language Class Initialized
INFO - 2016-11-08 18:09:38 --> Loader Class Initialized
INFO - 2016-11-08 18:09:38 --> Helper loaded: url_helper
INFO - 2016-11-08 18:09:38 --> Helper loaded: form_helper
INFO - 2016-11-08 18:09:38 --> Database Driver Class Initialized
INFO - 2016-11-08 18:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:09:38 --> Controller Class Initialized
INFO - 2016-11-08 18:09:38 --> Model Class Initialized
INFO - 2016-11-08 18:09:38 --> Form Validation Class Initialized
INFO - 2016-11-08 18:09:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-08 18:09:38 --> Unable to find callback validation rule: compareDates
ERROR - 2016-11-08 18:09:38 --> Could not find the language line "form_validation_compareDates"
INFO - 2016-11-08 18:09:38 --> Final output sent to browser
DEBUG - 2016-11-08 18:09:38 --> Total execution time: 0.2794
INFO - 2016-11-08 18:09:44 --> Config Class Initialized
INFO - 2016-11-08 18:09:44 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:09:44 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:09:44 --> Utf8 Class Initialized
INFO - 2016-11-08 18:09:44 --> URI Class Initialized
DEBUG - 2016-11-08 18:09:44 --> No URI present. Default controller set.
INFO - 2016-11-08 18:09:44 --> Router Class Initialized
INFO - 2016-11-08 18:09:44 --> Output Class Initialized
INFO - 2016-11-08 18:09:44 --> Security Class Initialized
DEBUG - 2016-11-08 18:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:09:44 --> Input Class Initialized
INFO - 2016-11-08 18:09:44 --> Language Class Initialized
INFO - 2016-11-08 18:09:44 --> Loader Class Initialized
INFO - 2016-11-08 18:09:44 --> Helper loaded: url_helper
INFO - 2016-11-08 18:09:44 --> Helper loaded: form_helper
INFO - 2016-11-08 18:09:44 --> Database Driver Class Initialized
INFO - 2016-11-08 18:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:09:44 --> Controller Class Initialized
INFO - 2016-11-08 18:09:45 --> Model Class Initialized
INFO - 2016-11-08 18:09:45 --> Model Class Initialized
INFO - 2016-11-08 18:09:45 --> Model Class Initialized
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:09:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:09:45 --> Final output sent to browser
DEBUG - 2016-11-08 18:09:45 --> Total execution time: 0.3782
INFO - 2016-11-08 18:17:54 --> Config Class Initialized
INFO - 2016-11-08 18:17:54 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:17:54 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:17:54 --> Utf8 Class Initialized
INFO - 2016-11-08 18:17:55 --> URI Class Initialized
DEBUG - 2016-11-08 18:17:55 --> No URI present. Default controller set.
INFO - 2016-11-08 18:17:55 --> Router Class Initialized
INFO - 2016-11-08 18:17:55 --> Output Class Initialized
INFO - 2016-11-08 18:17:55 --> Security Class Initialized
DEBUG - 2016-11-08 18:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:17:55 --> Input Class Initialized
INFO - 2016-11-08 18:17:55 --> Language Class Initialized
INFO - 2016-11-08 18:17:55 --> Loader Class Initialized
INFO - 2016-11-08 18:17:55 --> Helper loaded: url_helper
INFO - 2016-11-08 18:17:55 --> Helper loaded: form_helper
INFO - 2016-11-08 18:17:55 --> Database Driver Class Initialized
INFO - 2016-11-08 18:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:17:55 --> Controller Class Initialized
INFO - 2016-11-08 18:17:55 --> Model Class Initialized
INFO - 2016-11-08 18:17:55 --> Model Class Initialized
INFO - 2016-11-08 18:17:55 --> Model Class Initialized
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:17:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:17:55 --> Final output sent to browser
DEBUG - 2016-11-08 18:17:55 --> Total execution time: 0.3910
INFO - 2016-11-08 18:17:57 --> Config Class Initialized
INFO - 2016-11-08 18:17:57 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:17:57 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:17:57 --> Utf8 Class Initialized
INFO - 2016-11-08 18:17:57 --> URI Class Initialized
INFO - 2016-11-08 18:17:57 --> Router Class Initialized
INFO - 2016-11-08 18:17:57 --> Output Class Initialized
INFO - 2016-11-08 18:17:57 --> Security Class Initialized
DEBUG - 2016-11-08 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:17:57 --> Input Class Initialized
INFO - 2016-11-08 18:17:57 --> Language Class Initialized
INFO - 2016-11-08 18:17:57 --> Loader Class Initialized
INFO - 2016-11-08 18:17:57 --> Helper loaded: url_helper
INFO - 2016-11-08 18:17:57 --> Helper loaded: form_helper
INFO - 2016-11-08 18:17:57 --> Database Driver Class Initialized
INFO - 2016-11-08 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:17:57 --> Controller Class Initialized
INFO - 2016-11-08 18:17:57 --> Model Class Initialized
INFO - 2016-11-08 18:17:57 --> Form Validation Class Initialized
INFO - 2016-11-08 18:17:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-08 18:17:57 --> Unable to find callback validation rule: compareDates
ERROR - 2016-11-08 18:17:57 --> Could not find the language line "form_validation_compareDates"
INFO - 2016-11-08 18:17:57 --> Final output sent to browser
DEBUG - 2016-11-08 18:17:57 --> Total execution time: 0.2593
INFO - 2016-11-08 18:19:19 --> Config Class Initialized
INFO - 2016-11-08 18:19:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:19:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:19:19 --> Utf8 Class Initialized
INFO - 2016-11-08 18:19:19 --> URI Class Initialized
INFO - 2016-11-08 18:19:19 --> Router Class Initialized
INFO - 2016-11-08 18:19:19 --> Output Class Initialized
INFO - 2016-11-08 18:19:19 --> Security Class Initialized
DEBUG - 2016-11-08 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:19:19 --> Input Class Initialized
INFO - 2016-11-08 18:19:19 --> Language Class Initialized
INFO - 2016-11-08 18:19:19 --> Loader Class Initialized
INFO - 2016-11-08 18:19:19 --> Helper loaded: url_helper
INFO - 2016-11-08 18:19:19 --> Helper loaded: form_helper
INFO - 2016-11-08 18:19:19 --> Database Driver Class Initialized
INFO - 2016-11-08 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:19:19 --> Controller Class Initialized
INFO - 2016-11-08 18:19:19 --> Model Class Initialized
INFO - 2016-11-08 18:19:19 --> Form Validation Class Initialized
INFO - 2016-11-08 18:19:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-08 18:19:19 --> Unable to find callback validation rule: compareDates
ERROR - 2016-11-08 18:19:19 --> Could not find the language line "form_validation_compareDates"
INFO - 2016-11-08 18:19:19 --> Final output sent to browser
DEBUG - 2016-11-08 18:19:19 --> Total execution time: 0.2820
INFO - 2016-11-08 18:19:21 --> Config Class Initialized
INFO - 2016-11-08 18:19:21 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:19:21 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:19:21 --> Utf8 Class Initialized
INFO - 2016-11-08 18:19:21 --> URI Class Initialized
DEBUG - 2016-11-08 18:19:21 --> No URI present. Default controller set.
INFO - 2016-11-08 18:19:21 --> Router Class Initialized
INFO - 2016-11-08 18:19:21 --> Output Class Initialized
INFO - 2016-11-08 18:19:21 --> Security Class Initialized
DEBUG - 2016-11-08 18:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:19:21 --> Input Class Initialized
INFO - 2016-11-08 18:19:21 --> Language Class Initialized
INFO - 2016-11-08 18:19:21 --> Loader Class Initialized
INFO - 2016-11-08 18:19:21 --> Helper loaded: url_helper
INFO - 2016-11-08 18:19:21 --> Helper loaded: form_helper
INFO - 2016-11-08 18:19:21 --> Database Driver Class Initialized
INFO - 2016-11-08 18:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:19:21 --> Controller Class Initialized
INFO - 2016-11-08 18:19:21 --> Model Class Initialized
INFO - 2016-11-08 18:19:21 --> Model Class Initialized
INFO - 2016-11-08 18:19:21 --> Model Class Initialized
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:19:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:19:21 --> Final output sent to browser
DEBUG - 2016-11-08 18:19:21 --> Total execution time: 0.4167
INFO - 2016-11-08 18:19:25 --> Config Class Initialized
INFO - 2016-11-08 18:19:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:19:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:19:25 --> Utf8 Class Initialized
INFO - 2016-11-08 18:19:25 --> URI Class Initialized
INFO - 2016-11-08 18:19:25 --> Router Class Initialized
INFO - 2016-11-08 18:19:25 --> Output Class Initialized
INFO - 2016-11-08 18:19:25 --> Security Class Initialized
DEBUG - 2016-11-08 18:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:19:25 --> Input Class Initialized
INFO - 2016-11-08 18:19:25 --> Language Class Initialized
INFO - 2016-11-08 18:19:25 --> Loader Class Initialized
INFO - 2016-11-08 18:19:25 --> Helper loaded: url_helper
INFO - 2016-11-08 18:19:25 --> Helper loaded: form_helper
INFO - 2016-11-08 18:19:25 --> Database Driver Class Initialized
INFO - 2016-11-08 18:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:19:25 --> Controller Class Initialized
INFO - 2016-11-08 18:19:25 --> Model Class Initialized
INFO - 2016-11-08 18:19:25 --> Form Validation Class Initialized
INFO - 2016-11-08 18:19:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-08 18:19:25 --> Unable to find callback validation rule: compareDates
ERROR - 2016-11-08 18:19:25 --> Could not find the language line "form_validation_compareDates"
INFO - 2016-11-08 18:19:25 --> Final output sent to browser
DEBUG - 2016-11-08 18:19:25 --> Total execution time: 0.2786
INFO - 2016-11-08 18:21:40 --> Config Class Initialized
INFO - 2016-11-08 18:21:40 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:21:40 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:21:40 --> Utf8 Class Initialized
INFO - 2016-11-08 18:21:40 --> URI Class Initialized
INFO - 2016-11-08 18:21:40 --> Router Class Initialized
INFO - 2016-11-08 18:21:40 --> Output Class Initialized
INFO - 2016-11-08 18:21:40 --> Security Class Initialized
DEBUG - 2016-11-08 18:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:21:40 --> Input Class Initialized
INFO - 2016-11-08 18:21:40 --> Language Class Initialized
INFO - 2016-11-08 18:21:40 --> Loader Class Initialized
INFO - 2016-11-08 18:21:40 --> Helper loaded: url_helper
INFO - 2016-11-08 18:21:40 --> Helper loaded: form_helper
INFO - 2016-11-08 18:21:40 --> Database Driver Class Initialized
INFO - 2016-11-08 18:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:21:40 --> Controller Class Initialized
INFO - 2016-11-08 18:21:40 --> Model Class Initialized
INFO - 2016-11-08 18:21:40 --> Form Validation Class Initialized
INFO - 2016-11-08 18:21:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-08 18:21:40 --> Unable to find callback validation rule: compareDates
ERROR - 2016-11-08 18:21:40 --> Could not find the language line "form_validation_compareDates"
INFO - 2016-11-08 18:21:40 --> Final output sent to browser
DEBUG - 2016-11-08 18:21:40 --> Total execution time: 0.2841
INFO - 2016-11-08 18:23:05 --> Config Class Initialized
INFO - 2016-11-08 18:23:05 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:23:05 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:23:05 --> Utf8 Class Initialized
INFO - 2016-11-08 18:23:05 --> URI Class Initialized
INFO - 2016-11-08 18:23:05 --> Router Class Initialized
INFO - 2016-11-08 18:23:05 --> Output Class Initialized
INFO - 2016-11-08 18:23:05 --> Security Class Initialized
DEBUG - 2016-11-08 18:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:23:05 --> Input Class Initialized
INFO - 2016-11-08 18:23:05 --> Language Class Initialized
INFO - 2016-11-08 18:23:05 --> Loader Class Initialized
INFO - 2016-11-08 18:23:05 --> Helper loaded: url_helper
INFO - 2016-11-08 18:23:05 --> Helper loaded: form_helper
INFO - 2016-11-08 18:23:05 --> Database Driver Class Initialized
INFO - 2016-11-08 18:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:23:05 --> Controller Class Initialized
INFO - 2016-11-08 18:23:05 --> Model Class Initialized
INFO - 2016-11-08 18:23:05 --> Form Validation Class Initialized
INFO - 2016-11-08 18:23:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:23:05 --> Final output sent to browser
DEBUG - 2016-11-08 18:23:05 --> Total execution time: 0.2540
INFO - 2016-11-08 18:27:01 --> Config Class Initialized
INFO - 2016-11-08 18:27:01 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:01 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:01 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:01 --> URI Class Initialized
INFO - 2016-11-08 18:27:01 --> Router Class Initialized
INFO - 2016-11-08 18:27:01 --> Output Class Initialized
INFO - 2016-11-08 18:27:01 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:01 --> Input Class Initialized
INFO - 2016-11-08 18:27:01 --> Language Class Initialized
INFO - 2016-11-08 18:27:01 --> Loader Class Initialized
INFO - 2016-11-08 18:27:01 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:02 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:02 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:02 --> Controller Class Initialized
INFO - 2016-11-08 18:27:02 --> Model Class Initialized
INFO - 2016-11-08 18:27:02 --> Form Validation Class Initialized
INFO - 2016-11-08 18:27:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:27:02 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:02 --> Total execution time: 0.2739
INFO - 2016-11-08 18:27:03 --> Config Class Initialized
INFO - 2016-11-08 18:27:03 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:03 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:03 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:03 --> URI Class Initialized
DEBUG - 2016-11-08 18:27:03 --> No URI present. Default controller set.
INFO - 2016-11-08 18:27:03 --> Router Class Initialized
INFO - 2016-11-08 18:27:03 --> Output Class Initialized
INFO - 2016-11-08 18:27:03 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:03 --> Input Class Initialized
INFO - 2016-11-08 18:27:03 --> Language Class Initialized
INFO - 2016-11-08 18:27:03 --> Loader Class Initialized
INFO - 2016-11-08 18:27:03 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:03 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:03 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:03 --> Controller Class Initialized
INFO - 2016-11-08 18:27:03 --> Model Class Initialized
INFO - 2016-11-08 18:27:03 --> Model Class Initialized
INFO - 2016-11-08 18:27:03 --> Model Class Initialized
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:27:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:27:03 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:03 --> Total execution time: 0.4103
INFO - 2016-11-08 18:27:05 --> Config Class Initialized
INFO - 2016-11-08 18:27:05 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:05 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:05 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:05 --> URI Class Initialized
DEBUG - 2016-11-08 18:27:05 --> No URI present. Default controller set.
INFO - 2016-11-08 18:27:05 --> Router Class Initialized
INFO - 2016-11-08 18:27:05 --> Output Class Initialized
INFO - 2016-11-08 18:27:05 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:05 --> Input Class Initialized
INFO - 2016-11-08 18:27:05 --> Language Class Initialized
INFO - 2016-11-08 18:27:05 --> Loader Class Initialized
INFO - 2016-11-08 18:27:05 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:05 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:05 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:05 --> Controller Class Initialized
INFO - 2016-11-08 18:27:05 --> Model Class Initialized
INFO - 2016-11-08 18:27:05 --> Model Class Initialized
INFO - 2016-11-08 18:27:05 --> Model Class Initialized
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:27:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:27:05 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:05 --> Total execution time: 0.4334
INFO - 2016-11-08 18:27:10 --> Config Class Initialized
INFO - 2016-11-08 18:27:10 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:10 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:10 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:10 --> URI Class Initialized
INFO - 2016-11-08 18:27:10 --> Router Class Initialized
INFO - 2016-11-08 18:27:10 --> Output Class Initialized
INFO - 2016-11-08 18:27:10 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:10 --> Input Class Initialized
INFO - 2016-11-08 18:27:10 --> Language Class Initialized
INFO - 2016-11-08 18:27:10 --> Loader Class Initialized
INFO - 2016-11-08 18:27:10 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:10 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:10 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:10 --> Controller Class Initialized
INFO - 2016-11-08 18:27:10 --> Model Class Initialized
INFO - 2016-11-08 18:27:10 --> Form Validation Class Initialized
INFO - 2016-11-08 18:27:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:27:10 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:10 --> Total execution time: 0.2748
INFO - 2016-11-08 18:27:53 --> Config Class Initialized
INFO - 2016-11-08 18:27:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:53 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:53 --> URI Class Initialized
INFO - 2016-11-08 18:27:53 --> Router Class Initialized
INFO - 2016-11-08 18:27:53 --> Output Class Initialized
INFO - 2016-11-08 18:27:53 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:53 --> Input Class Initialized
INFO - 2016-11-08 18:27:53 --> Language Class Initialized
INFO - 2016-11-08 18:27:53 --> Loader Class Initialized
INFO - 2016-11-08 18:27:53 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:53 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:53 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:53 --> Controller Class Initialized
INFO - 2016-11-08 18:27:53 --> Model Class Initialized
INFO - 2016-11-08 18:27:53 --> Form Validation Class Initialized
INFO - 2016-11-08 18:27:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:27:53 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:53 --> Total execution time: 0.2599
INFO - 2016-11-08 18:27:55 --> Config Class Initialized
INFO - 2016-11-08 18:27:55 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:55 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:55 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:55 --> URI Class Initialized
DEBUG - 2016-11-08 18:27:55 --> No URI present. Default controller set.
INFO - 2016-11-08 18:27:55 --> Router Class Initialized
INFO - 2016-11-08 18:27:55 --> Output Class Initialized
INFO - 2016-11-08 18:27:55 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:55 --> Input Class Initialized
INFO - 2016-11-08 18:27:55 --> Language Class Initialized
INFO - 2016-11-08 18:27:55 --> Loader Class Initialized
INFO - 2016-11-08 18:27:55 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:55 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:55 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:55 --> Controller Class Initialized
INFO - 2016-11-08 18:27:55 --> Model Class Initialized
INFO - 2016-11-08 18:27:55 --> Model Class Initialized
INFO - 2016-11-08 18:27:55 --> Model Class Initialized
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:27:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:27:55 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:55 --> Total execution time: 0.3995
INFO - 2016-11-08 18:27:58 --> Config Class Initialized
INFO - 2016-11-08 18:27:58 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:27:58 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:27:58 --> Utf8 Class Initialized
INFO - 2016-11-08 18:27:58 --> URI Class Initialized
INFO - 2016-11-08 18:27:58 --> Router Class Initialized
INFO - 2016-11-08 18:27:58 --> Output Class Initialized
INFO - 2016-11-08 18:27:58 --> Security Class Initialized
DEBUG - 2016-11-08 18:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:27:58 --> Input Class Initialized
INFO - 2016-11-08 18:27:58 --> Language Class Initialized
INFO - 2016-11-08 18:27:58 --> Loader Class Initialized
INFO - 2016-11-08 18:27:58 --> Helper loaded: url_helper
INFO - 2016-11-08 18:27:58 --> Helper loaded: form_helper
INFO - 2016-11-08 18:27:58 --> Database Driver Class Initialized
INFO - 2016-11-08 18:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:27:58 --> Controller Class Initialized
INFO - 2016-11-08 18:27:58 --> Model Class Initialized
INFO - 2016-11-08 18:27:59 --> Form Validation Class Initialized
INFO - 2016-11-08 18:27:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:27:59 --> Final output sent to browser
DEBUG - 2016-11-08 18:27:59 --> Total execution time: 0.2654
INFO - 2016-11-08 18:28:00 --> Config Class Initialized
INFO - 2016-11-08 18:28:00 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:00 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:00 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:00 --> URI Class Initialized
DEBUG - 2016-11-08 18:28:00 --> No URI present. Default controller set.
INFO - 2016-11-08 18:28:00 --> Router Class Initialized
INFO - 2016-11-08 18:28:00 --> Output Class Initialized
INFO - 2016-11-08 18:28:00 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:00 --> Input Class Initialized
INFO - 2016-11-08 18:28:00 --> Language Class Initialized
INFO - 2016-11-08 18:28:00 --> Loader Class Initialized
INFO - 2016-11-08 18:28:00 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:00 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:00 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:00 --> Controller Class Initialized
INFO - 2016-11-08 18:28:00 --> Model Class Initialized
INFO - 2016-11-08 18:28:00 --> Model Class Initialized
INFO - 2016-11-08 18:28:00 --> Model Class Initialized
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:28:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:28:00 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:00 --> Total execution time: 0.4485
INFO - 2016-11-08 18:28:40 --> Config Class Initialized
INFO - 2016-11-08 18:28:40 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:40 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:40 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:40 --> URI Class Initialized
DEBUG - 2016-11-08 18:28:40 --> No URI present. Default controller set.
INFO - 2016-11-08 18:28:40 --> Router Class Initialized
INFO - 2016-11-08 18:28:40 --> Output Class Initialized
INFO - 2016-11-08 18:28:40 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:40 --> Input Class Initialized
INFO - 2016-11-08 18:28:40 --> Language Class Initialized
INFO - 2016-11-08 18:28:40 --> Loader Class Initialized
INFO - 2016-11-08 18:28:41 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:41 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:41 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:41 --> Controller Class Initialized
INFO - 2016-11-08 18:28:41 --> Model Class Initialized
INFO - 2016-11-08 18:28:41 --> Model Class Initialized
INFO - 2016-11-08 18:28:41 --> Model Class Initialized
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:28:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:28:41 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:41 --> Total execution time: 0.8648
INFO - 2016-11-08 18:28:44 --> Config Class Initialized
INFO - 2016-11-08 18:28:44 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:44 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:44 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:44 --> URI Class Initialized
INFO - 2016-11-08 18:28:44 --> Router Class Initialized
INFO - 2016-11-08 18:28:44 --> Output Class Initialized
INFO - 2016-11-08 18:28:44 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:44 --> Input Class Initialized
INFO - 2016-11-08 18:28:44 --> Language Class Initialized
INFO - 2016-11-08 18:28:44 --> Loader Class Initialized
INFO - 2016-11-08 18:28:44 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:44 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:44 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:44 --> Controller Class Initialized
INFO - 2016-11-08 18:28:44 --> Model Class Initialized
INFO - 2016-11-08 18:28:44 --> Form Validation Class Initialized
INFO - 2016-11-08 18:28:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:28:44 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:44 --> Total execution time: 0.3260
INFO - 2016-11-08 18:28:45 --> Config Class Initialized
INFO - 2016-11-08 18:28:45 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:45 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:45 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:45 --> URI Class Initialized
DEBUG - 2016-11-08 18:28:45 --> No URI present. Default controller set.
INFO - 2016-11-08 18:28:45 --> Router Class Initialized
INFO - 2016-11-08 18:28:45 --> Output Class Initialized
INFO - 2016-11-08 18:28:45 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:45 --> Input Class Initialized
INFO - 2016-11-08 18:28:46 --> Language Class Initialized
INFO - 2016-11-08 18:28:46 --> Loader Class Initialized
INFO - 2016-11-08 18:28:46 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:46 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:46 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:46 --> Controller Class Initialized
INFO - 2016-11-08 18:28:46 --> Model Class Initialized
INFO - 2016-11-08 18:28:46 --> Model Class Initialized
INFO - 2016-11-08 18:28:46 --> Model Class Initialized
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:28:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:28:46 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:46 --> Total execution time: 0.5112
INFO - 2016-11-08 18:28:49 --> Config Class Initialized
INFO - 2016-11-08 18:28:49 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:49 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:49 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:49 --> URI Class Initialized
INFO - 2016-11-08 18:28:49 --> Router Class Initialized
INFO - 2016-11-08 18:28:49 --> Output Class Initialized
INFO - 2016-11-08 18:28:49 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:49 --> Input Class Initialized
INFO - 2016-11-08 18:28:49 --> Language Class Initialized
INFO - 2016-11-08 18:28:49 --> Loader Class Initialized
INFO - 2016-11-08 18:28:49 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:49 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:49 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:49 --> Controller Class Initialized
INFO - 2016-11-08 18:28:49 --> Model Class Initialized
INFO - 2016-11-08 18:28:49 --> Form Validation Class Initialized
INFO - 2016-11-08 18:28:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:28:49 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:49 --> Total execution time: 0.2786
INFO - 2016-11-08 18:28:50 --> Config Class Initialized
INFO - 2016-11-08 18:28:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:50 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:50 --> URI Class Initialized
DEBUG - 2016-11-08 18:28:50 --> No URI present. Default controller set.
INFO - 2016-11-08 18:28:50 --> Router Class Initialized
INFO - 2016-11-08 18:28:50 --> Output Class Initialized
INFO - 2016-11-08 18:28:50 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:50 --> Input Class Initialized
INFO - 2016-11-08 18:28:50 --> Language Class Initialized
INFO - 2016-11-08 18:28:50 --> Loader Class Initialized
INFO - 2016-11-08 18:28:50 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:50 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:50 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:50 --> Controller Class Initialized
INFO - 2016-11-08 18:28:50 --> Model Class Initialized
INFO - 2016-11-08 18:28:50 --> Model Class Initialized
INFO - 2016-11-08 18:28:50 --> Model Class Initialized
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:28:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:28:51 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:51 --> Total execution time: 0.5313
INFO - 2016-11-08 18:28:53 --> Config Class Initialized
INFO - 2016-11-08 18:28:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:28:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:28:53 --> Utf8 Class Initialized
INFO - 2016-11-08 18:28:53 --> URI Class Initialized
INFO - 2016-11-08 18:28:53 --> Router Class Initialized
INFO - 2016-11-08 18:28:53 --> Output Class Initialized
INFO - 2016-11-08 18:28:53 --> Security Class Initialized
DEBUG - 2016-11-08 18:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:28:53 --> Input Class Initialized
INFO - 2016-11-08 18:28:53 --> Language Class Initialized
INFO - 2016-11-08 18:28:53 --> Loader Class Initialized
INFO - 2016-11-08 18:28:53 --> Helper loaded: url_helper
INFO - 2016-11-08 18:28:53 --> Helper loaded: form_helper
INFO - 2016-11-08 18:28:53 --> Database Driver Class Initialized
INFO - 2016-11-08 18:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:28:53 --> Controller Class Initialized
INFO - 2016-11-08 18:28:53 --> Model Class Initialized
INFO - 2016-11-08 18:28:53 --> Form Validation Class Initialized
INFO - 2016-11-08 18:28:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:28:54 --> Final output sent to browser
DEBUG - 2016-11-08 18:28:54 --> Total execution time: 0.3484
INFO - 2016-11-08 18:29:13 --> Config Class Initialized
INFO - 2016-11-08 18:29:13 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:13 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:13 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:13 --> URI Class Initialized
INFO - 2016-11-08 18:29:13 --> Router Class Initialized
INFO - 2016-11-08 18:29:13 --> Output Class Initialized
INFO - 2016-11-08 18:29:13 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:13 --> Input Class Initialized
INFO - 2016-11-08 18:29:13 --> Language Class Initialized
INFO - 2016-11-08 18:29:13 --> Loader Class Initialized
INFO - 2016-11-08 18:29:13 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:14 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:14 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:14 --> Controller Class Initialized
INFO - 2016-11-08 18:29:14 --> Model Class Initialized
INFO - 2016-11-08 18:29:14 --> Model Class Initialized
INFO - 2016-11-08 18:29:14 --> Model Class Initialized
DEBUG - 2016-11-08 18:29:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 18:29:14 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-08 18:29:14 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-08 18:29:14 --> Config Class Initialized
INFO - 2016-11-08 18:29:14 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:14 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:14 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:14 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:14 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:14 --> Router Class Initialized
INFO - 2016-11-08 18:29:14 --> Output Class Initialized
INFO - 2016-11-08 18:29:14 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:14 --> Input Class Initialized
INFO - 2016-11-08 18:29:14 --> Language Class Initialized
INFO - 2016-11-08 18:29:14 --> Loader Class Initialized
INFO - 2016-11-08 18:29:14 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:14 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:14 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:14 --> Controller Class Initialized
INFO - 2016-11-08 18:29:14 --> Model Class Initialized
INFO - 2016-11-08 18:29:14 --> Model Class Initialized
INFO - 2016-11-08 18:29:14 --> Model Class Initialized
INFO - 2016-11-08 18:29:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 18:29:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:14 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:14 --> Total execution time: 0.3744
INFO - 2016-11-08 18:29:27 --> Config Class Initialized
INFO - 2016-11-08 18:29:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:27 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:27 --> URI Class Initialized
INFO - 2016-11-08 18:29:27 --> Router Class Initialized
INFO - 2016-11-08 18:29:27 --> Output Class Initialized
INFO - 2016-11-08 18:29:27 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:27 --> Input Class Initialized
INFO - 2016-11-08 18:29:27 --> Language Class Initialized
INFO - 2016-11-08 18:29:27 --> Loader Class Initialized
INFO - 2016-11-08 18:29:27 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:27 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:27 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:27 --> Controller Class Initialized
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
DEBUG - 2016-11-08 18:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
INFO - 2016-11-08 18:29:27 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:27 --> Total execution time: 0.2765
INFO - 2016-11-08 18:29:27 --> Config Class Initialized
INFO - 2016-11-08 18:29:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:27 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:27 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:27 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:27 --> Router Class Initialized
INFO - 2016-11-08 18:29:27 --> Output Class Initialized
INFO - 2016-11-08 18:29:27 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:27 --> Input Class Initialized
INFO - 2016-11-08 18:29:27 --> Language Class Initialized
INFO - 2016-11-08 18:29:27 --> Loader Class Initialized
INFO - 2016-11-08 18:29:27 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:27 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:27 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:27 --> Controller Class Initialized
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
INFO - 2016-11-08 18:29:27 --> Model Class Initialized
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:27 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:27 --> Total execution time: 0.3811
INFO - 2016-11-08 18:29:32 --> Config Class Initialized
INFO - 2016-11-08 18:29:32 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:32 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:32 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:32 --> URI Class Initialized
INFO - 2016-11-08 18:29:32 --> Router Class Initialized
INFO - 2016-11-08 18:29:32 --> Output Class Initialized
INFO - 2016-11-08 18:29:32 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:32 --> Input Class Initialized
INFO - 2016-11-08 18:29:32 --> Language Class Initialized
INFO - 2016-11-08 18:29:32 --> Loader Class Initialized
INFO - 2016-11-08 18:29:32 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:32 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:32 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:32 --> Controller Class Initialized
INFO - 2016-11-08 18:29:32 --> Model Class Initialized
INFO - 2016-11-08 18:29:32 --> Form Validation Class Initialized
INFO - 2016-11-08 18:29:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:29:32 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:32 --> Total execution time: 0.2758
INFO - 2016-11-08 18:29:34 --> Config Class Initialized
INFO - 2016-11-08 18:29:34 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:34 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:34 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:34 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:34 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:34 --> Router Class Initialized
INFO - 2016-11-08 18:29:34 --> Output Class Initialized
INFO - 2016-11-08 18:29:34 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:34 --> Input Class Initialized
INFO - 2016-11-08 18:29:34 --> Language Class Initialized
INFO - 2016-11-08 18:29:34 --> Loader Class Initialized
INFO - 2016-11-08 18:29:34 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:34 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:34 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:34 --> Controller Class Initialized
INFO - 2016-11-08 18:29:34 --> Model Class Initialized
INFO - 2016-11-08 18:29:34 --> Model Class Initialized
INFO - 2016-11-08 18:29:34 --> Model Class Initialized
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:29:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:34 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:34 --> Total execution time: 0.4173
INFO - 2016-11-08 18:29:39 --> Config Class Initialized
INFO - 2016-11-08 18:29:39 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:39 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:39 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:39 --> URI Class Initialized
INFO - 2016-11-08 18:29:40 --> Router Class Initialized
INFO - 2016-11-08 18:29:40 --> Output Class Initialized
INFO - 2016-11-08 18:29:40 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:40 --> Input Class Initialized
INFO - 2016-11-08 18:29:40 --> Language Class Initialized
INFO - 2016-11-08 18:29:40 --> Loader Class Initialized
INFO - 2016-11-08 18:29:40 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:40 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:40 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:40 --> Controller Class Initialized
INFO - 2016-11-08 18:29:40 --> Model Class Initialized
INFO - 2016-11-08 18:29:40 --> Form Validation Class Initialized
INFO - 2016-11-08 18:29:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:29:40 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:40 --> Total execution time: 0.2667
INFO - 2016-11-08 18:29:41 --> Config Class Initialized
INFO - 2016-11-08 18:29:41 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:41 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:41 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:41 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:41 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:41 --> Router Class Initialized
INFO - 2016-11-08 18:29:41 --> Output Class Initialized
INFO - 2016-11-08 18:29:41 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:41 --> Input Class Initialized
INFO - 2016-11-08 18:29:41 --> Language Class Initialized
INFO - 2016-11-08 18:29:41 --> Loader Class Initialized
INFO - 2016-11-08 18:29:41 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:41 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:41 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:41 --> Controller Class Initialized
INFO - 2016-11-08 18:29:41 --> Model Class Initialized
INFO - 2016-11-08 18:29:41 --> Model Class Initialized
INFO - 2016-11-08 18:29:41 --> Model Class Initialized
INFO - 2016-11-08 18:29:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:29:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:29:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:29:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:29:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:29:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:42 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:42 --> Total execution time: 0.4643
INFO - 2016-11-08 18:29:44 --> Config Class Initialized
INFO - 2016-11-08 18:29:44 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:44 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:44 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:44 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:44 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:44 --> Router Class Initialized
INFO - 2016-11-08 18:29:44 --> Output Class Initialized
INFO - 2016-11-08 18:29:44 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:44 --> Input Class Initialized
INFO - 2016-11-08 18:29:44 --> Language Class Initialized
INFO - 2016-11-08 18:29:44 --> Loader Class Initialized
INFO - 2016-11-08 18:29:44 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:44 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:44 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:45 --> Controller Class Initialized
INFO - 2016-11-08 18:29:45 --> Model Class Initialized
INFO - 2016-11-08 18:29:45 --> Model Class Initialized
INFO - 2016-11-08 18:29:45 --> Model Class Initialized
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:29:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:45 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:45 --> Total execution time: 0.4337
INFO - 2016-11-08 18:29:49 --> Config Class Initialized
INFO - 2016-11-08 18:29:49 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:49 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:49 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:49 --> URI Class Initialized
INFO - 2016-11-08 18:29:49 --> Router Class Initialized
INFO - 2016-11-08 18:29:49 --> Output Class Initialized
INFO - 2016-11-08 18:29:49 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:49 --> Input Class Initialized
INFO - 2016-11-08 18:29:49 --> Language Class Initialized
INFO - 2016-11-08 18:29:49 --> Loader Class Initialized
INFO - 2016-11-08 18:29:49 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:49 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:49 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:50 --> Controller Class Initialized
INFO - 2016-11-08 18:29:50 --> Model Class Initialized
INFO - 2016-11-08 18:29:50 --> Form Validation Class Initialized
INFO - 2016-11-08 18:29:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:29:50 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:50 --> Total execution time: 0.2725
INFO - 2016-11-08 18:29:51 --> Config Class Initialized
INFO - 2016-11-08 18:29:51 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:51 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:51 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:51 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:51 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:51 --> Router Class Initialized
INFO - 2016-11-08 18:29:51 --> Output Class Initialized
INFO - 2016-11-08 18:29:51 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:51 --> Input Class Initialized
INFO - 2016-11-08 18:29:51 --> Language Class Initialized
INFO - 2016-11-08 18:29:51 --> Loader Class Initialized
INFO - 2016-11-08 18:29:51 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:51 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:51 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:51 --> Controller Class Initialized
INFO - 2016-11-08 18:29:51 --> Model Class Initialized
INFO - 2016-11-08 18:29:51 --> Model Class Initialized
INFO - 2016-11-08 18:29:51 --> Model Class Initialized
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:29:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:51 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:51 --> Total execution time: 0.4360
INFO - 2016-11-08 18:29:54 --> Config Class Initialized
INFO - 2016-11-08 18:29:54 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:54 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:54 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:54 --> URI Class Initialized
INFO - 2016-11-08 18:29:54 --> Router Class Initialized
INFO - 2016-11-08 18:29:54 --> Output Class Initialized
INFO - 2016-11-08 18:29:54 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:54 --> Input Class Initialized
INFO - 2016-11-08 18:29:54 --> Language Class Initialized
INFO - 2016-11-08 18:29:54 --> Loader Class Initialized
INFO - 2016-11-08 18:29:54 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:54 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:54 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:54 --> Controller Class Initialized
INFO - 2016-11-08 18:29:54 --> Model Class Initialized
INFO - 2016-11-08 18:29:54 --> Form Validation Class Initialized
INFO - 2016-11-08 18:29:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:29:54 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:54 --> Total execution time: 0.2693
INFO - 2016-11-08 18:29:56 --> Config Class Initialized
INFO - 2016-11-08 18:29:56 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:56 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:56 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:56 --> URI Class Initialized
DEBUG - 2016-11-08 18:29:56 --> No URI present. Default controller set.
INFO - 2016-11-08 18:29:56 --> Router Class Initialized
INFO - 2016-11-08 18:29:56 --> Output Class Initialized
INFO - 2016-11-08 18:29:56 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:56 --> Input Class Initialized
INFO - 2016-11-08 18:29:56 --> Language Class Initialized
INFO - 2016-11-08 18:29:56 --> Loader Class Initialized
INFO - 2016-11-08 18:29:56 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:56 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:56 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:56 --> Controller Class Initialized
INFO - 2016-11-08 18:29:56 --> Model Class Initialized
INFO - 2016-11-08 18:29:56 --> Model Class Initialized
INFO - 2016-11-08 18:29:56 --> Model Class Initialized
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:29:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:29:56 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:56 --> Total execution time: 0.4565
INFO - 2016-11-08 18:29:59 --> Config Class Initialized
INFO - 2016-11-08 18:29:59 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:29:59 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:29:59 --> Utf8 Class Initialized
INFO - 2016-11-08 18:29:59 --> URI Class Initialized
INFO - 2016-11-08 18:29:59 --> Router Class Initialized
INFO - 2016-11-08 18:29:59 --> Output Class Initialized
INFO - 2016-11-08 18:29:59 --> Security Class Initialized
DEBUG - 2016-11-08 18:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:29:59 --> Input Class Initialized
INFO - 2016-11-08 18:29:59 --> Language Class Initialized
INFO - 2016-11-08 18:29:59 --> Loader Class Initialized
INFO - 2016-11-08 18:29:59 --> Helper loaded: url_helper
INFO - 2016-11-08 18:29:59 --> Helper loaded: form_helper
INFO - 2016-11-08 18:29:59 --> Database Driver Class Initialized
INFO - 2016-11-08 18:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:29:59 --> Controller Class Initialized
INFO - 2016-11-08 18:29:59 --> Model Class Initialized
INFO - 2016-11-08 18:29:59 --> Form Validation Class Initialized
INFO - 2016-11-08 18:29:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:29:59 --> Final output sent to browser
DEBUG - 2016-11-08 18:29:59 --> Total execution time: 0.2679
INFO - 2016-11-08 18:30:01 --> Config Class Initialized
INFO - 2016-11-08 18:30:01 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:30:01 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:30:01 --> Utf8 Class Initialized
INFO - 2016-11-08 18:30:01 --> URI Class Initialized
DEBUG - 2016-11-08 18:30:01 --> No URI present. Default controller set.
INFO - 2016-11-08 18:30:01 --> Router Class Initialized
INFO - 2016-11-08 18:30:01 --> Output Class Initialized
INFO - 2016-11-08 18:30:01 --> Security Class Initialized
DEBUG - 2016-11-08 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:30:01 --> Input Class Initialized
INFO - 2016-11-08 18:30:01 --> Language Class Initialized
INFO - 2016-11-08 18:30:01 --> Loader Class Initialized
INFO - 2016-11-08 18:30:01 --> Helper loaded: url_helper
INFO - 2016-11-08 18:30:01 --> Helper loaded: form_helper
INFO - 2016-11-08 18:30:01 --> Database Driver Class Initialized
INFO - 2016-11-08 18:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:30:01 --> Controller Class Initialized
INFO - 2016-11-08 18:30:01 --> Model Class Initialized
INFO - 2016-11-08 18:30:01 --> Model Class Initialized
INFO - 2016-11-08 18:30:01 --> Model Class Initialized
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:30:01 --> Final output sent to browser
DEBUG - 2016-11-08 18:30:01 --> Total execution time: 0.4641
INFO - 2016-11-08 18:30:19 --> Config Class Initialized
INFO - 2016-11-08 18:30:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:30:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:30:19 --> Utf8 Class Initialized
INFO - 2016-11-08 18:30:19 --> URI Class Initialized
INFO - 2016-11-08 18:30:19 --> Router Class Initialized
INFO - 2016-11-08 18:30:19 --> Output Class Initialized
INFO - 2016-11-08 18:30:19 --> Security Class Initialized
DEBUG - 2016-11-08 18:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:30:19 --> Input Class Initialized
INFO - 2016-11-08 18:30:19 --> Language Class Initialized
INFO - 2016-11-08 18:30:19 --> Loader Class Initialized
INFO - 2016-11-08 18:30:19 --> Helper loaded: url_helper
INFO - 2016-11-08 18:30:19 --> Helper loaded: form_helper
INFO - 2016-11-08 18:30:19 --> Database Driver Class Initialized
INFO - 2016-11-08 18:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:30:19 --> Controller Class Initialized
INFO - 2016-11-08 18:30:19 --> Model Class Initialized
INFO - 2016-11-08 18:30:19 --> Form Validation Class Initialized
INFO - 2016-11-08 18:30:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:30:19 --> Final output sent to browser
DEBUG - 2016-11-08 18:30:19 --> Total execution time: 0.2619
INFO - 2016-11-08 18:30:20 --> Config Class Initialized
INFO - 2016-11-08 18:30:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:30:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:30:20 --> Utf8 Class Initialized
INFO - 2016-11-08 18:30:20 --> URI Class Initialized
DEBUG - 2016-11-08 18:30:20 --> No URI present. Default controller set.
INFO - 2016-11-08 18:30:20 --> Router Class Initialized
INFO - 2016-11-08 18:30:21 --> Output Class Initialized
INFO - 2016-11-08 18:30:21 --> Security Class Initialized
DEBUG - 2016-11-08 18:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:30:21 --> Input Class Initialized
INFO - 2016-11-08 18:30:21 --> Language Class Initialized
INFO - 2016-11-08 18:30:21 --> Loader Class Initialized
INFO - 2016-11-08 18:30:21 --> Helper loaded: url_helper
INFO - 2016-11-08 18:30:21 --> Helper loaded: form_helper
INFO - 2016-11-08 18:30:21 --> Database Driver Class Initialized
INFO - 2016-11-08 18:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:30:21 --> Controller Class Initialized
INFO - 2016-11-08 18:30:21 --> Model Class Initialized
INFO - 2016-11-08 18:30:21 --> Model Class Initialized
INFO - 2016-11-08 18:30:21 --> Model Class Initialized
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:30:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:30:21 --> Final output sent to browser
DEBUG - 2016-11-08 18:30:21 --> Total execution time: 0.4275
INFO - 2016-11-08 18:30:22 --> Config Class Initialized
INFO - 2016-11-08 18:30:22 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:30:22 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:30:22 --> Utf8 Class Initialized
INFO - 2016-11-08 18:30:22 --> URI Class Initialized
DEBUG - 2016-11-08 18:30:22 --> No URI present. Default controller set.
INFO - 2016-11-08 18:30:22 --> Router Class Initialized
INFO - 2016-11-08 18:30:22 --> Output Class Initialized
INFO - 2016-11-08 18:30:22 --> Security Class Initialized
DEBUG - 2016-11-08 18:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:30:22 --> Input Class Initialized
INFO - 2016-11-08 18:30:22 --> Language Class Initialized
INFO - 2016-11-08 18:30:22 --> Loader Class Initialized
INFO - 2016-11-08 18:30:22 --> Helper loaded: url_helper
INFO - 2016-11-08 18:30:22 --> Helper loaded: form_helper
INFO - 2016-11-08 18:30:22 --> Database Driver Class Initialized
INFO - 2016-11-08 18:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:30:22 --> Controller Class Initialized
INFO - 2016-11-08 18:30:22 --> Model Class Initialized
INFO - 2016-11-08 18:30:22 --> Model Class Initialized
INFO - 2016-11-08 18:30:22 --> Model Class Initialized
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:30:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:30:22 --> Final output sent to browser
DEBUG - 2016-11-08 18:30:23 --> Total execution time: 0.4680
INFO - 2016-11-08 18:30:32 --> Config Class Initialized
INFO - 2016-11-08 18:30:32 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:30:32 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:30:32 --> Utf8 Class Initialized
INFO - 2016-11-08 18:30:32 --> URI Class Initialized
DEBUG - 2016-11-08 18:30:32 --> No URI present. Default controller set.
INFO - 2016-11-08 18:30:32 --> Router Class Initialized
INFO - 2016-11-08 18:30:32 --> Output Class Initialized
INFO - 2016-11-08 18:30:32 --> Security Class Initialized
DEBUG - 2016-11-08 18:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:30:32 --> Input Class Initialized
INFO - 2016-11-08 18:30:32 --> Language Class Initialized
INFO - 2016-11-08 18:30:32 --> Loader Class Initialized
INFO - 2016-11-08 18:30:32 --> Helper loaded: url_helper
INFO - 2016-11-08 18:30:32 --> Helper loaded: form_helper
INFO - 2016-11-08 18:30:32 --> Database Driver Class Initialized
INFO - 2016-11-08 18:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:30:32 --> Controller Class Initialized
INFO - 2016-11-08 18:30:32 --> Model Class Initialized
INFO - 2016-11-08 18:30:32 --> Model Class Initialized
INFO - 2016-11-08 18:30:32 --> Model Class Initialized
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:30:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:30:32 --> Final output sent to browser
DEBUG - 2016-11-08 18:30:32 --> Total execution time: 0.4185
INFO - 2016-11-08 18:30:42 --> Config Class Initialized
INFO - 2016-11-08 18:30:43 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:30:43 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:30:43 --> Utf8 Class Initialized
INFO - 2016-11-08 18:30:43 --> URI Class Initialized
DEBUG - 2016-11-08 18:30:43 --> No URI present. Default controller set.
INFO - 2016-11-08 18:30:43 --> Router Class Initialized
INFO - 2016-11-08 18:30:43 --> Output Class Initialized
INFO - 2016-11-08 18:30:43 --> Security Class Initialized
DEBUG - 2016-11-08 18:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:30:43 --> Input Class Initialized
INFO - 2016-11-08 18:30:43 --> Language Class Initialized
INFO - 2016-11-08 18:30:43 --> Loader Class Initialized
INFO - 2016-11-08 18:30:43 --> Helper loaded: url_helper
INFO - 2016-11-08 18:30:43 --> Helper loaded: form_helper
INFO - 2016-11-08 18:30:43 --> Database Driver Class Initialized
INFO - 2016-11-08 18:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:30:43 --> Controller Class Initialized
INFO - 2016-11-08 18:30:43 --> Model Class Initialized
INFO - 2016-11-08 18:30:43 --> Model Class Initialized
INFO - 2016-11-08 18:30:43 --> Model Class Initialized
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:30:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:30:43 --> Final output sent to browser
DEBUG - 2016-11-08 18:30:43 --> Total execution time: 0.4075
INFO - 2016-11-08 18:31:08 --> Config Class Initialized
INFO - 2016-11-08 18:31:08 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:08 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:08 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:08 --> URI Class Initialized
DEBUG - 2016-11-08 18:31:08 --> No URI present. Default controller set.
INFO - 2016-11-08 18:31:08 --> Router Class Initialized
INFO - 2016-11-08 18:31:08 --> Output Class Initialized
INFO - 2016-11-08 18:31:08 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:08 --> Input Class Initialized
INFO - 2016-11-08 18:31:08 --> Language Class Initialized
INFO - 2016-11-08 18:31:08 --> Loader Class Initialized
INFO - 2016-11-08 18:31:08 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:08 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:08 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:08 --> Controller Class Initialized
INFO - 2016-11-08 18:31:08 --> Model Class Initialized
INFO - 2016-11-08 18:31:09 --> Model Class Initialized
INFO - 2016-11-08 18:31:09 --> Model Class Initialized
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:31:09 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:09 --> Total execution time: 0.4444
INFO - 2016-11-08 18:31:09 --> Config Class Initialized
INFO - 2016-11-08 18:31:09 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:09 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:09 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:09 --> URI Class Initialized
DEBUG - 2016-11-08 18:31:09 --> No URI present. Default controller set.
INFO - 2016-11-08 18:31:09 --> Router Class Initialized
INFO - 2016-11-08 18:31:09 --> Output Class Initialized
INFO - 2016-11-08 18:31:09 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:09 --> Input Class Initialized
INFO - 2016-11-08 18:31:09 --> Language Class Initialized
INFO - 2016-11-08 18:31:09 --> Loader Class Initialized
INFO - 2016-11-08 18:31:09 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:09 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:09 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:09 --> Controller Class Initialized
INFO - 2016-11-08 18:31:09 --> Model Class Initialized
INFO - 2016-11-08 18:31:09 --> Model Class Initialized
INFO - 2016-11-08 18:31:09 --> Model Class Initialized
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:31:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:31:09 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:09 --> Total execution time: 0.4380
INFO - 2016-11-08 18:31:10 --> Config Class Initialized
INFO - 2016-11-08 18:31:10 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:10 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:10 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:10 --> URI Class Initialized
DEBUG - 2016-11-08 18:31:10 --> No URI present. Default controller set.
INFO - 2016-11-08 18:31:10 --> Router Class Initialized
INFO - 2016-11-08 18:31:10 --> Output Class Initialized
INFO - 2016-11-08 18:31:10 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:10 --> Input Class Initialized
INFO - 2016-11-08 18:31:10 --> Language Class Initialized
INFO - 2016-11-08 18:31:10 --> Loader Class Initialized
INFO - 2016-11-08 18:31:10 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:10 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:10 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:10 --> Controller Class Initialized
INFO - 2016-11-08 18:31:10 --> Model Class Initialized
INFO - 2016-11-08 18:31:10 --> Model Class Initialized
INFO - 2016-11-08 18:31:10 --> Model Class Initialized
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:31:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:31:10 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:10 --> Total execution time: 0.4150
INFO - 2016-11-08 18:31:12 --> Config Class Initialized
INFO - 2016-11-08 18:31:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:12 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:12 --> URI Class Initialized
INFO - 2016-11-08 18:31:12 --> Router Class Initialized
INFO - 2016-11-08 18:31:12 --> Output Class Initialized
INFO - 2016-11-08 18:31:12 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:12 --> Input Class Initialized
INFO - 2016-11-08 18:31:12 --> Language Class Initialized
INFO - 2016-11-08 18:31:12 --> Loader Class Initialized
INFO - 2016-11-08 18:31:12 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:12 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:12 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:12 --> Controller Class Initialized
INFO - 2016-11-08 18:31:12 --> Model Class Initialized
INFO - 2016-11-08 18:31:12 --> Form Validation Class Initialized
INFO - 2016-11-08 18:31:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:31:12 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:12 --> Total execution time: 0.2953
INFO - 2016-11-08 18:31:16 --> Config Class Initialized
INFO - 2016-11-08 18:31:16 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:16 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:16 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:16 --> URI Class Initialized
DEBUG - 2016-11-08 18:31:16 --> No URI present. Default controller set.
INFO - 2016-11-08 18:31:16 --> Router Class Initialized
INFO - 2016-11-08 18:31:16 --> Output Class Initialized
INFO - 2016-11-08 18:31:16 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:16 --> Input Class Initialized
INFO - 2016-11-08 18:31:16 --> Language Class Initialized
INFO - 2016-11-08 18:31:16 --> Loader Class Initialized
INFO - 2016-11-08 18:31:16 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:16 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:16 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:16 --> Controller Class Initialized
INFO - 2016-11-08 18:31:16 --> Model Class Initialized
INFO - 2016-11-08 18:31:16 --> Model Class Initialized
INFO - 2016-11-08 18:31:16 --> Model Class Initialized
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:31:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:31:16 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:16 --> Total execution time: 0.4207
INFO - 2016-11-08 18:31:19 --> Config Class Initialized
INFO - 2016-11-08 18:31:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:19 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:19 --> URI Class Initialized
INFO - 2016-11-08 18:31:19 --> Router Class Initialized
INFO - 2016-11-08 18:31:19 --> Output Class Initialized
INFO - 2016-11-08 18:31:19 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:19 --> Input Class Initialized
INFO - 2016-11-08 18:31:19 --> Language Class Initialized
INFO - 2016-11-08 18:31:19 --> Loader Class Initialized
INFO - 2016-11-08 18:31:19 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:19 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:19 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:19 --> Controller Class Initialized
INFO - 2016-11-08 18:31:19 --> Model Class Initialized
INFO - 2016-11-08 18:31:19 --> Form Validation Class Initialized
INFO - 2016-11-08 18:31:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:31:19 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:19 --> Total execution time: 0.2543
INFO - 2016-11-08 18:31:31 --> Config Class Initialized
INFO - 2016-11-08 18:31:31 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:31 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:31 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:31 --> URI Class Initialized
DEBUG - 2016-11-08 18:31:31 --> No URI present. Default controller set.
INFO - 2016-11-08 18:31:31 --> Router Class Initialized
INFO - 2016-11-08 18:31:31 --> Output Class Initialized
INFO - 2016-11-08 18:31:31 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:31 --> Input Class Initialized
INFO - 2016-11-08 18:31:31 --> Language Class Initialized
INFO - 2016-11-08 18:31:31 --> Loader Class Initialized
INFO - 2016-11-08 18:31:31 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:31 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:31 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:31 --> Controller Class Initialized
INFO - 2016-11-08 18:31:31 --> Model Class Initialized
INFO - 2016-11-08 18:31:31 --> Model Class Initialized
INFO - 2016-11-08 18:31:31 --> Model Class Initialized
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:31:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:31:31 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:31 --> Total execution time: 0.4364
INFO - 2016-11-08 18:31:34 --> Config Class Initialized
INFO - 2016-11-08 18:31:34 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:34 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:34 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:34 --> URI Class Initialized
INFO - 2016-11-08 18:31:34 --> Router Class Initialized
INFO - 2016-11-08 18:31:34 --> Output Class Initialized
INFO - 2016-11-08 18:31:34 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:34 --> Input Class Initialized
INFO - 2016-11-08 18:31:34 --> Language Class Initialized
INFO - 2016-11-08 18:31:34 --> Loader Class Initialized
INFO - 2016-11-08 18:31:34 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:34 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:34 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:34 --> Controller Class Initialized
INFO - 2016-11-08 18:31:34 --> Model Class Initialized
INFO - 2016-11-08 18:31:34 --> Form Validation Class Initialized
INFO - 2016-11-08 18:31:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:31:34 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:34 --> Total execution time: 0.2713
INFO - 2016-11-08 18:31:37 --> Config Class Initialized
INFO - 2016-11-08 18:31:37 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:31:37 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:31:37 --> Utf8 Class Initialized
INFO - 2016-11-08 18:31:37 --> URI Class Initialized
DEBUG - 2016-11-08 18:31:37 --> No URI present. Default controller set.
INFO - 2016-11-08 18:31:37 --> Router Class Initialized
INFO - 2016-11-08 18:31:37 --> Output Class Initialized
INFO - 2016-11-08 18:31:37 --> Security Class Initialized
DEBUG - 2016-11-08 18:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:31:37 --> Input Class Initialized
INFO - 2016-11-08 18:31:37 --> Language Class Initialized
INFO - 2016-11-08 18:31:37 --> Loader Class Initialized
INFO - 2016-11-08 18:31:37 --> Helper loaded: url_helper
INFO - 2016-11-08 18:31:37 --> Helper loaded: form_helper
INFO - 2016-11-08 18:31:37 --> Database Driver Class Initialized
INFO - 2016-11-08 18:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:31:37 --> Controller Class Initialized
INFO - 2016-11-08 18:31:37 --> Model Class Initialized
INFO - 2016-11-08 18:31:37 --> Model Class Initialized
INFO - 2016-11-08 18:31:37 --> Model Class Initialized
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:31:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:31:37 --> Final output sent to browser
DEBUG - 2016-11-08 18:31:37 --> Total execution time: 0.4555
INFO - 2016-11-08 18:32:47 --> Config Class Initialized
INFO - 2016-11-08 18:32:47 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:32:47 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:32:47 --> Utf8 Class Initialized
INFO - 2016-11-08 18:32:47 --> URI Class Initialized
DEBUG - 2016-11-08 18:32:47 --> No URI present. Default controller set.
INFO - 2016-11-08 18:32:47 --> Router Class Initialized
INFO - 2016-11-08 18:32:47 --> Output Class Initialized
INFO - 2016-11-08 18:32:47 --> Security Class Initialized
DEBUG - 2016-11-08 18:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:32:47 --> Input Class Initialized
INFO - 2016-11-08 18:32:47 --> Language Class Initialized
INFO - 2016-11-08 18:32:47 --> Loader Class Initialized
INFO - 2016-11-08 18:32:47 --> Helper loaded: url_helper
INFO - 2016-11-08 18:32:47 --> Helper loaded: form_helper
INFO - 2016-11-08 18:32:47 --> Database Driver Class Initialized
INFO - 2016-11-08 18:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:32:47 --> Controller Class Initialized
INFO - 2016-11-08 18:32:47 --> Model Class Initialized
INFO - 2016-11-08 18:32:47 --> Model Class Initialized
INFO - 2016-11-08 18:32:47 --> Model Class Initialized
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:32:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:32:47 --> Final output sent to browser
DEBUG - 2016-11-08 18:32:47 --> Total execution time: 0.4272
INFO - 2016-11-08 18:32:49 --> Config Class Initialized
INFO - 2016-11-08 18:32:49 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:32:49 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:32:49 --> Utf8 Class Initialized
INFO - 2016-11-08 18:32:49 --> URI Class Initialized
INFO - 2016-11-08 18:32:49 --> Router Class Initialized
INFO - 2016-11-08 18:32:49 --> Output Class Initialized
INFO - 2016-11-08 18:32:49 --> Security Class Initialized
DEBUG - 2016-11-08 18:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:32:49 --> Input Class Initialized
INFO - 2016-11-08 18:32:49 --> Language Class Initialized
INFO - 2016-11-08 18:32:49 --> Loader Class Initialized
INFO - 2016-11-08 18:32:49 --> Helper loaded: url_helper
INFO - 2016-11-08 18:32:49 --> Helper loaded: form_helper
INFO - 2016-11-08 18:32:49 --> Database Driver Class Initialized
INFO - 2016-11-08 18:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:32:49 --> Controller Class Initialized
INFO - 2016-11-08 18:32:49 --> Model Class Initialized
INFO - 2016-11-08 18:32:50 --> Form Validation Class Initialized
INFO - 2016-11-08 18:32:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:32:50 --> Final output sent to browser
DEBUG - 2016-11-08 18:32:50 --> Total execution time: 0.3008
INFO - 2016-11-08 18:32:51 --> Config Class Initialized
INFO - 2016-11-08 18:32:51 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:32:51 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:32:51 --> Utf8 Class Initialized
INFO - 2016-11-08 18:32:51 --> URI Class Initialized
DEBUG - 2016-11-08 18:32:51 --> No URI present. Default controller set.
INFO - 2016-11-08 18:32:51 --> Router Class Initialized
INFO - 2016-11-08 18:32:51 --> Output Class Initialized
INFO - 2016-11-08 18:32:51 --> Security Class Initialized
DEBUG - 2016-11-08 18:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:32:51 --> Input Class Initialized
INFO - 2016-11-08 18:32:51 --> Language Class Initialized
INFO - 2016-11-08 18:32:51 --> Loader Class Initialized
INFO - 2016-11-08 18:32:51 --> Helper loaded: url_helper
INFO - 2016-11-08 18:32:51 --> Helper loaded: form_helper
INFO - 2016-11-08 18:32:51 --> Database Driver Class Initialized
INFO - 2016-11-08 18:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:32:51 --> Controller Class Initialized
INFO - 2016-11-08 18:32:51 --> Model Class Initialized
INFO - 2016-11-08 18:32:51 --> Model Class Initialized
INFO - 2016-11-08 18:32:51 --> Model Class Initialized
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:32:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:32:51 --> Final output sent to browser
DEBUG - 2016-11-08 18:32:51 --> Total execution time: 0.4985
INFO - 2016-11-08 18:32:59 --> Config Class Initialized
INFO - 2016-11-08 18:32:59 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:32:59 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:32:59 --> Utf8 Class Initialized
INFO - 2016-11-08 18:32:59 --> URI Class Initialized
DEBUG - 2016-11-08 18:32:59 --> No URI present. Default controller set.
INFO - 2016-11-08 18:32:59 --> Router Class Initialized
INFO - 2016-11-08 18:32:59 --> Output Class Initialized
INFO - 2016-11-08 18:32:59 --> Security Class Initialized
DEBUG - 2016-11-08 18:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:32:59 --> Input Class Initialized
INFO - 2016-11-08 18:32:59 --> Language Class Initialized
INFO - 2016-11-08 18:32:59 --> Loader Class Initialized
INFO - 2016-11-08 18:32:59 --> Helper loaded: url_helper
INFO - 2016-11-08 18:32:59 --> Helper loaded: form_helper
INFO - 2016-11-08 18:32:59 --> Database Driver Class Initialized
INFO - 2016-11-08 18:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:32:59 --> Controller Class Initialized
INFO - 2016-11-08 18:32:59 --> Model Class Initialized
INFO - 2016-11-08 18:32:59 --> Model Class Initialized
INFO - 2016-11-08 18:32:59 --> Model Class Initialized
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:32:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:32:59 --> Final output sent to browser
DEBUG - 2016-11-08 18:32:59 --> Total execution time: 0.4234
INFO - 2016-11-08 18:33:01 --> Config Class Initialized
INFO - 2016-11-08 18:33:01 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:33:01 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:33:01 --> Utf8 Class Initialized
INFO - 2016-11-08 18:33:01 --> URI Class Initialized
INFO - 2016-11-08 18:33:01 --> Router Class Initialized
INFO - 2016-11-08 18:33:01 --> Output Class Initialized
INFO - 2016-11-08 18:33:01 --> Security Class Initialized
DEBUG - 2016-11-08 18:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:33:01 --> Input Class Initialized
INFO - 2016-11-08 18:33:01 --> Language Class Initialized
INFO - 2016-11-08 18:33:01 --> Loader Class Initialized
INFO - 2016-11-08 18:33:01 --> Helper loaded: url_helper
INFO - 2016-11-08 18:33:01 --> Helper loaded: form_helper
INFO - 2016-11-08 18:33:01 --> Database Driver Class Initialized
INFO - 2016-11-08 18:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:33:01 --> Controller Class Initialized
INFO - 2016-11-08 18:33:01 --> Model Class Initialized
INFO - 2016-11-08 18:33:01 --> Form Validation Class Initialized
INFO - 2016-11-08 18:33:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:33:01 --> Final output sent to browser
DEBUG - 2016-11-08 18:33:01 --> Total execution time: 0.2817
INFO - 2016-11-08 18:33:03 --> Config Class Initialized
INFO - 2016-11-08 18:33:03 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:33:03 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:33:03 --> Utf8 Class Initialized
INFO - 2016-11-08 18:33:03 --> URI Class Initialized
DEBUG - 2016-11-08 18:33:03 --> No URI present. Default controller set.
INFO - 2016-11-08 18:33:03 --> Router Class Initialized
INFO - 2016-11-08 18:33:03 --> Output Class Initialized
INFO - 2016-11-08 18:33:03 --> Security Class Initialized
DEBUG - 2016-11-08 18:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:33:04 --> Input Class Initialized
INFO - 2016-11-08 18:33:04 --> Language Class Initialized
INFO - 2016-11-08 18:33:04 --> Loader Class Initialized
INFO - 2016-11-08 18:33:04 --> Helper loaded: url_helper
INFO - 2016-11-08 18:33:04 --> Helper loaded: form_helper
INFO - 2016-11-08 18:33:04 --> Database Driver Class Initialized
INFO - 2016-11-08 18:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:33:04 --> Controller Class Initialized
INFO - 2016-11-08 18:33:04 --> Model Class Initialized
INFO - 2016-11-08 18:33:04 --> Model Class Initialized
INFO - 2016-11-08 18:33:04 --> Model Class Initialized
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:33:04 --> Final output sent to browser
DEBUG - 2016-11-08 18:33:04 --> Total execution time: 0.4571
INFO - 2016-11-08 18:33:43 --> Config Class Initialized
INFO - 2016-11-08 18:33:43 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:33:43 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:33:43 --> Utf8 Class Initialized
INFO - 2016-11-08 18:33:43 --> URI Class Initialized
INFO - 2016-11-08 18:33:43 --> Router Class Initialized
INFO - 2016-11-08 18:33:43 --> Output Class Initialized
INFO - 2016-11-08 18:33:43 --> Security Class Initialized
DEBUG - 2016-11-08 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:33:43 --> Input Class Initialized
INFO - 2016-11-08 18:33:43 --> Language Class Initialized
INFO - 2016-11-08 18:33:43 --> Loader Class Initialized
INFO - 2016-11-08 18:33:43 --> Helper loaded: url_helper
INFO - 2016-11-08 18:33:43 --> Helper loaded: form_helper
INFO - 2016-11-08 18:33:43 --> Database Driver Class Initialized
INFO - 2016-11-08 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:33:43 --> Controller Class Initialized
INFO - 2016-11-08 18:33:43 --> Model Class Initialized
INFO - 2016-11-08 18:33:43 --> Form Validation Class Initialized
INFO - 2016-11-08 18:33:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:33:44 --> Final output sent to browser
DEBUG - 2016-11-08 18:33:44 --> Total execution time: 0.2708
INFO - 2016-11-08 18:33:45 --> Config Class Initialized
INFO - 2016-11-08 18:33:45 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:33:45 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:33:45 --> Utf8 Class Initialized
INFO - 2016-11-08 18:33:45 --> URI Class Initialized
DEBUG - 2016-11-08 18:33:45 --> No URI present. Default controller set.
INFO - 2016-11-08 18:33:45 --> Router Class Initialized
INFO - 2016-11-08 18:33:45 --> Output Class Initialized
INFO - 2016-11-08 18:33:45 --> Security Class Initialized
DEBUG - 2016-11-08 18:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:33:45 --> Input Class Initialized
INFO - 2016-11-08 18:33:45 --> Language Class Initialized
INFO - 2016-11-08 18:33:45 --> Loader Class Initialized
INFO - 2016-11-08 18:33:45 --> Helper loaded: url_helper
INFO - 2016-11-08 18:33:45 --> Helper loaded: form_helper
INFO - 2016-11-08 18:33:45 --> Database Driver Class Initialized
INFO - 2016-11-08 18:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:33:45 --> Controller Class Initialized
INFO - 2016-11-08 18:33:45 --> Model Class Initialized
INFO - 2016-11-08 18:33:45 --> Model Class Initialized
INFO - 2016-11-08 18:33:45 --> Model Class Initialized
INFO - 2016-11-08 18:33:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:33:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:33:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:33:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:33:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:33:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:33:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:33:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:33:46 --> Final output sent to browser
DEBUG - 2016-11-08 18:33:46 --> Total execution time: 0.5059
INFO - 2016-11-08 18:37:06 --> Config Class Initialized
INFO - 2016-11-08 18:37:06 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:06 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:06 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:06 --> URI Class Initialized
DEBUG - 2016-11-08 18:37:06 --> No URI present. Default controller set.
INFO - 2016-11-08 18:37:06 --> Router Class Initialized
INFO - 2016-11-08 18:37:06 --> Output Class Initialized
INFO - 2016-11-08 18:37:06 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:06 --> Input Class Initialized
INFO - 2016-11-08 18:37:06 --> Language Class Initialized
INFO - 2016-11-08 18:37:06 --> Loader Class Initialized
INFO - 2016-11-08 18:37:06 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:06 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:06 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:06 --> Controller Class Initialized
INFO - 2016-11-08 18:37:06 --> Model Class Initialized
INFO - 2016-11-08 18:37:06 --> Model Class Initialized
INFO - 2016-11-08 18:37:06 --> Model Class Initialized
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:37:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:37:06 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:06 --> Total execution time: 0.4146
INFO - 2016-11-08 18:37:08 --> Config Class Initialized
INFO - 2016-11-08 18:37:08 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:08 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:08 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:09 --> URI Class Initialized
INFO - 2016-11-08 18:37:09 --> Router Class Initialized
INFO - 2016-11-08 18:37:09 --> Output Class Initialized
INFO - 2016-11-08 18:37:09 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:09 --> Input Class Initialized
INFO - 2016-11-08 18:37:09 --> Language Class Initialized
INFO - 2016-11-08 18:37:09 --> Loader Class Initialized
INFO - 2016-11-08 18:37:09 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:09 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:09 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:09 --> Controller Class Initialized
INFO - 2016-11-08 18:37:09 --> Model Class Initialized
INFO - 2016-11-08 18:37:09 --> Form Validation Class Initialized
INFO - 2016-11-08 18:37:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:37:09 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:09 --> Total execution time: 0.2727
INFO - 2016-11-08 18:37:12 --> Config Class Initialized
INFO - 2016-11-08 18:37:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:12 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:12 --> URI Class Initialized
DEBUG - 2016-11-08 18:37:12 --> No URI present. Default controller set.
INFO - 2016-11-08 18:37:12 --> Router Class Initialized
INFO - 2016-11-08 18:37:12 --> Output Class Initialized
INFO - 2016-11-08 18:37:12 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:12 --> Input Class Initialized
INFO - 2016-11-08 18:37:12 --> Language Class Initialized
INFO - 2016-11-08 18:37:12 --> Loader Class Initialized
INFO - 2016-11-08 18:37:12 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:12 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:12 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:12 --> Controller Class Initialized
INFO - 2016-11-08 18:37:12 --> Model Class Initialized
INFO - 2016-11-08 18:37:12 --> Model Class Initialized
INFO - 2016-11-08 18:37:12 --> Model Class Initialized
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:37:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:37:12 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:12 --> Total execution time: 0.4175
INFO - 2016-11-08 18:37:15 --> Config Class Initialized
INFO - 2016-11-08 18:37:15 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:15 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:15 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:15 --> URI Class Initialized
INFO - 2016-11-08 18:37:15 --> Router Class Initialized
INFO - 2016-11-08 18:37:15 --> Output Class Initialized
INFO - 2016-11-08 18:37:15 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:15 --> Input Class Initialized
INFO - 2016-11-08 18:37:15 --> Language Class Initialized
INFO - 2016-11-08 18:37:15 --> Loader Class Initialized
INFO - 2016-11-08 18:37:15 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:15 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:15 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:15 --> Controller Class Initialized
INFO - 2016-11-08 18:37:15 --> Model Class Initialized
INFO - 2016-11-08 18:37:15 --> Form Validation Class Initialized
INFO - 2016-11-08 18:37:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:37:15 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:15 --> Total execution time: 0.2845
INFO - 2016-11-08 18:37:17 --> Config Class Initialized
INFO - 2016-11-08 18:37:17 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:17 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:17 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:17 --> URI Class Initialized
DEBUG - 2016-11-08 18:37:17 --> No URI present. Default controller set.
INFO - 2016-11-08 18:37:17 --> Router Class Initialized
INFO - 2016-11-08 18:37:17 --> Output Class Initialized
INFO - 2016-11-08 18:37:17 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:17 --> Input Class Initialized
INFO - 2016-11-08 18:37:17 --> Language Class Initialized
INFO - 2016-11-08 18:37:17 --> Loader Class Initialized
INFO - 2016-11-08 18:37:17 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:17 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:17 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:17 --> Controller Class Initialized
INFO - 2016-11-08 18:37:17 --> Model Class Initialized
INFO - 2016-11-08 18:37:17 --> Model Class Initialized
INFO - 2016-11-08 18:37:17 --> Model Class Initialized
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:37:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:37:17 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:17 --> Total execution time: 0.5066
INFO - 2016-11-08 18:37:41 --> Config Class Initialized
INFO - 2016-11-08 18:37:41 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:41 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:41 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:41 --> URI Class Initialized
DEBUG - 2016-11-08 18:37:41 --> No URI present. Default controller set.
INFO - 2016-11-08 18:37:41 --> Router Class Initialized
INFO - 2016-11-08 18:37:41 --> Output Class Initialized
INFO - 2016-11-08 18:37:41 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:41 --> Input Class Initialized
INFO - 2016-11-08 18:37:41 --> Language Class Initialized
INFO - 2016-11-08 18:37:41 --> Loader Class Initialized
INFO - 2016-11-08 18:37:41 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:41 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:41 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:41 --> Controller Class Initialized
INFO - 2016-11-08 18:37:41 --> Model Class Initialized
INFO - 2016-11-08 18:37:41 --> Model Class Initialized
INFO - 2016-11-08 18:37:41 --> Model Class Initialized
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:37:41 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:41 --> Total execution time: 0.4970
INFO - 2016-11-08 18:37:43 --> Config Class Initialized
INFO - 2016-11-08 18:37:43 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:43 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:43 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:43 --> URI Class Initialized
INFO - 2016-11-08 18:37:43 --> Router Class Initialized
INFO - 2016-11-08 18:37:43 --> Output Class Initialized
INFO - 2016-11-08 18:37:43 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:43 --> Input Class Initialized
INFO - 2016-11-08 18:37:43 --> Language Class Initialized
INFO - 2016-11-08 18:37:43 --> Loader Class Initialized
INFO - 2016-11-08 18:37:43 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:43 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:43 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:43 --> Controller Class Initialized
INFO - 2016-11-08 18:37:43 --> Model Class Initialized
INFO - 2016-11-08 18:37:43 --> Form Validation Class Initialized
INFO - 2016-11-08 18:37:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:37:43 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:43 --> Total execution time: 0.3004
INFO - 2016-11-08 18:37:46 --> Config Class Initialized
INFO - 2016-11-08 18:37:46 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:46 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:46 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:46 --> URI Class Initialized
DEBUG - 2016-11-08 18:37:46 --> No URI present. Default controller set.
INFO - 2016-11-08 18:37:46 --> Router Class Initialized
INFO - 2016-11-08 18:37:46 --> Output Class Initialized
INFO - 2016-11-08 18:37:46 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:46 --> Input Class Initialized
INFO - 2016-11-08 18:37:46 --> Language Class Initialized
INFO - 2016-11-08 18:37:46 --> Loader Class Initialized
INFO - 2016-11-08 18:37:46 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:46 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:46 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:46 --> Controller Class Initialized
INFO - 2016-11-08 18:37:46 --> Model Class Initialized
INFO - 2016-11-08 18:37:46 --> Model Class Initialized
INFO - 2016-11-08 18:37:46 --> Model Class Initialized
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:37:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:37:46 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:46 --> Total execution time: 0.4423
INFO - 2016-11-08 18:37:48 --> Config Class Initialized
INFO - 2016-11-08 18:37:48 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:48 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:48 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:48 --> URI Class Initialized
DEBUG - 2016-11-08 18:37:48 --> No URI present. Default controller set.
INFO - 2016-11-08 18:37:48 --> Router Class Initialized
INFO - 2016-11-08 18:37:48 --> Output Class Initialized
INFO - 2016-11-08 18:37:48 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:48 --> Input Class Initialized
INFO - 2016-11-08 18:37:48 --> Language Class Initialized
INFO - 2016-11-08 18:37:48 --> Loader Class Initialized
INFO - 2016-11-08 18:37:48 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:48 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:48 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:48 --> Controller Class Initialized
INFO - 2016-11-08 18:37:48 --> Model Class Initialized
INFO - 2016-11-08 18:37:48 --> Model Class Initialized
INFO - 2016-11-08 18:37:48 --> Model Class Initialized
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:37:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:37:48 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:48 --> Total execution time: 0.5172
INFO - 2016-11-08 18:37:50 --> Config Class Initialized
INFO - 2016-11-08 18:37:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:37:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:37:50 --> Utf8 Class Initialized
INFO - 2016-11-08 18:37:50 --> URI Class Initialized
INFO - 2016-11-08 18:37:50 --> Router Class Initialized
INFO - 2016-11-08 18:37:50 --> Output Class Initialized
INFO - 2016-11-08 18:37:50 --> Security Class Initialized
DEBUG - 2016-11-08 18:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:37:50 --> Input Class Initialized
INFO - 2016-11-08 18:37:50 --> Language Class Initialized
INFO - 2016-11-08 18:37:50 --> Loader Class Initialized
INFO - 2016-11-08 18:37:50 --> Helper loaded: url_helper
INFO - 2016-11-08 18:37:50 --> Helper loaded: form_helper
INFO - 2016-11-08 18:37:50 --> Database Driver Class Initialized
INFO - 2016-11-08 18:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:37:50 --> Controller Class Initialized
INFO - 2016-11-08 18:37:50 --> Model Class Initialized
INFO - 2016-11-08 18:37:50 --> Form Validation Class Initialized
INFO - 2016-11-08 18:37:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:37:50 --> Final output sent to browser
DEBUG - 2016-11-08 18:37:50 --> Total execution time: 0.3356
INFO - 2016-11-08 18:39:46 --> Config Class Initialized
INFO - 2016-11-08 18:39:46 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:39:46 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:39:46 --> Utf8 Class Initialized
INFO - 2016-11-08 18:39:46 --> URI Class Initialized
INFO - 2016-11-08 18:39:46 --> Router Class Initialized
INFO - 2016-11-08 18:39:46 --> Output Class Initialized
INFO - 2016-11-08 18:39:47 --> Security Class Initialized
DEBUG - 2016-11-08 18:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:39:47 --> Input Class Initialized
INFO - 2016-11-08 18:39:47 --> Language Class Initialized
INFO - 2016-11-08 18:39:47 --> Loader Class Initialized
INFO - 2016-11-08 18:39:47 --> Helper loaded: url_helper
INFO - 2016-11-08 18:39:47 --> Helper loaded: form_helper
INFO - 2016-11-08 18:39:47 --> Database Driver Class Initialized
INFO - 2016-11-08 18:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:39:47 --> Controller Class Initialized
INFO - 2016-11-08 18:39:47 --> Model Class Initialized
INFO - 2016-11-08 18:39:47 --> Form Validation Class Initialized
INFO - 2016-11-08 18:39:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:39:47 --> Final output sent to browser
DEBUG - 2016-11-08 18:39:47 --> Total execution time: 0.2999
INFO - 2016-11-08 18:39:48 --> Config Class Initialized
INFO - 2016-11-08 18:39:48 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:39:48 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:39:48 --> Utf8 Class Initialized
INFO - 2016-11-08 18:39:48 --> URI Class Initialized
DEBUG - 2016-11-08 18:39:48 --> No URI present. Default controller set.
INFO - 2016-11-08 18:39:48 --> Router Class Initialized
INFO - 2016-11-08 18:39:48 --> Output Class Initialized
INFO - 2016-11-08 18:39:48 --> Security Class Initialized
DEBUG - 2016-11-08 18:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:39:48 --> Input Class Initialized
INFO - 2016-11-08 18:39:48 --> Language Class Initialized
INFO - 2016-11-08 18:39:48 --> Loader Class Initialized
INFO - 2016-11-08 18:39:48 --> Helper loaded: url_helper
INFO - 2016-11-08 18:39:48 --> Helper loaded: form_helper
INFO - 2016-11-08 18:39:48 --> Database Driver Class Initialized
INFO - 2016-11-08 18:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:39:48 --> Controller Class Initialized
INFO - 2016-11-08 18:39:48 --> Model Class Initialized
INFO - 2016-11-08 18:39:48 --> Model Class Initialized
INFO - 2016-11-08 18:39:48 --> Model Class Initialized
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:39:48 --> Final output sent to browser
DEBUG - 2016-11-08 18:39:48 --> Total execution time: 0.4299
INFO - 2016-11-08 18:40:12 --> Config Class Initialized
INFO - 2016-11-08 18:40:12 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:40:12 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:40:12 --> Utf8 Class Initialized
INFO - 2016-11-08 18:40:12 --> URI Class Initialized
INFO - 2016-11-08 18:40:12 --> Router Class Initialized
INFO - 2016-11-08 18:40:12 --> Output Class Initialized
INFO - 2016-11-08 18:40:12 --> Security Class Initialized
DEBUG - 2016-11-08 18:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:40:12 --> Input Class Initialized
INFO - 2016-11-08 18:40:12 --> Language Class Initialized
INFO - 2016-11-08 18:40:12 --> Loader Class Initialized
INFO - 2016-11-08 18:40:12 --> Helper loaded: url_helper
INFO - 2016-11-08 18:40:12 --> Helper loaded: form_helper
INFO - 2016-11-08 18:40:12 --> Database Driver Class Initialized
INFO - 2016-11-08 18:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:40:12 --> Controller Class Initialized
INFO - 2016-11-08 18:40:12 --> Model Class Initialized
INFO - 2016-11-08 18:40:12 --> Form Validation Class Initialized
INFO - 2016-11-08 18:40:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:40:12 --> Final output sent to browser
DEBUG - 2016-11-08 18:40:12 --> Total execution time: 0.2929
INFO - 2016-11-08 18:40:15 --> Config Class Initialized
INFO - 2016-11-08 18:40:15 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:40:15 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:40:15 --> Utf8 Class Initialized
INFO - 2016-11-08 18:40:15 --> URI Class Initialized
DEBUG - 2016-11-08 18:40:15 --> No URI present. Default controller set.
INFO - 2016-11-08 18:40:15 --> Router Class Initialized
INFO - 2016-11-08 18:40:15 --> Output Class Initialized
INFO - 2016-11-08 18:40:15 --> Security Class Initialized
DEBUG - 2016-11-08 18:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:40:15 --> Input Class Initialized
INFO - 2016-11-08 18:40:15 --> Language Class Initialized
INFO - 2016-11-08 18:40:15 --> Loader Class Initialized
INFO - 2016-11-08 18:40:15 --> Helper loaded: url_helper
INFO - 2016-11-08 18:40:15 --> Helper loaded: form_helper
INFO - 2016-11-08 18:40:15 --> Database Driver Class Initialized
INFO - 2016-11-08 18:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:40:15 --> Controller Class Initialized
INFO - 2016-11-08 18:40:15 --> Model Class Initialized
INFO - 2016-11-08 18:40:15 --> Model Class Initialized
INFO - 2016-11-08 18:40:15 --> Model Class Initialized
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:40:15 --> Final output sent to browser
DEBUG - 2016-11-08 18:40:15 --> Total execution time: 0.4286
INFO - 2016-11-08 18:40:46 --> Config Class Initialized
INFO - 2016-11-08 18:40:46 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:40:46 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:40:46 --> Utf8 Class Initialized
INFO - 2016-11-08 18:40:46 --> URI Class Initialized
DEBUG - 2016-11-08 18:40:46 --> No URI present. Default controller set.
INFO - 2016-11-08 18:40:46 --> Router Class Initialized
INFO - 2016-11-08 18:40:47 --> Output Class Initialized
INFO - 2016-11-08 18:40:47 --> Security Class Initialized
DEBUG - 2016-11-08 18:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:40:47 --> Input Class Initialized
INFO - 2016-11-08 18:40:47 --> Language Class Initialized
INFO - 2016-11-08 18:40:47 --> Loader Class Initialized
INFO - 2016-11-08 18:40:47 --> Helper loaded: url_helper
INFO - 2016-11-08 18:40:47 --> Helper loaded: form_helper
INFO - 2016-11-08 18:40:47 --> Database Driver Class Initialized
INFO - 2016-11-08 18:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:40:47 --> Controller Class Initialized
INFO - 2016-11-08 18:40:47 --> Model Class Initialized
INFO - 2016-11-08 18:40:47 --> Model Class Initialized
INFO - 2016-11-08 18:40:47 --> Model Class Initialized
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:40:47 --> Final output sent to browser
DEBUG - 2016-11-08 18:40:47 --> Total execution time: 0.4141
INFO - 2016-11-08 18:40:50 --> Config Class Initialized
INFO - 2016-11-08 18:40:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:40:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:40:50 --> Utf8 Class Initialized
INFO - 2016-11-08 18:40:50 --> URI Class Initialized
INFO - 2016-11-08 18:40:50 --> Router Class Initialized
INFO - 2016-11-08 18:40:50 --> Output Class Initialized
INFO - 2016-11-08 18:40:50 --> Security Class Initialized
DEBUG - 2016-11-08 18:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:40:50 --> Input Class Initialized
INFO - 2016-11-08 18:40:50 --> Language Class Initialized
INFO - 2016-11-08 18:40:50 --> Loader Class Initialized
INFO - 2016-11-08 18:40:50 --> Helper loaded: url_helper
INFO - 2016-11-08 18:40:50 --> Helper loaded: form_helper
INFO - 2016-11-08 18:40:50 --> Database Driver Class Initialized
INFO - 2016-11-08 18:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:40:50 --> Controller Class Initialized
INFO - 2016-11-08 18:40:50 --> Model Class Initialized
INFO - 2016-11-08 18:40:50 --> Form Validation Class Initialized
INFO - 2016-11-08 18:40:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:40:50 --> Final output sent to browser
DEBUG - 2016-11-08 18:40:50 --> Total execution time: 0.2877
INFO - 2016-11-08 18:40:53 --> Config Class Initialized
INFO - 2016-11-08 18:40:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:40:54 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:40:54 --> Utf8 Class Initialized
INFO - 2016-11-08 18:40:54 --> URI Class Initialized
DEBUG - 2016-11-08 18:40:54 --> No URI present. Default controller set.
INFO - 2016-11-08 18:40:54 --> Router Class Initialized
INFO - 2016-11-08 18:40:54 --> Output Class Initialized
INFO - 2016-11-08 18:40:54 --> Security Class Initialized
DEBUG - 2016-11-08 18:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:40:54 --> Input Class Initialized
INFO - 2016-11-08 18:40:54 --> Language Class Initialized
INFO - 2016-11-08 18:40:54 --> Loader Class Initialized
INFO - 2016-11-08 18:40:54 --> Helper loaded: url_helper
INFO - 2016-11-08 18:40:54 --> Helper loaded: form_helper
INFO - 2016-11-08 18:40:54 --> Database Driver Class Initialized
INFO - 2016-11-08 18:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:40:54 --> Controller Class Initialized
INFO - 2016-11-08 18:40:54 --> Model Class Initialized
INFO - 2016-11-08 18:40:54 --> Model Class Initialized
INFO - 2016-11-08 18:40:54 --> Model Class Initialized
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:40:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:40:54 --> Final output sent to browser
DEBUG - 2016-11-08 18:40:54 --> Total execution time: 0.4546
INFO - 2016-11-08 18:41:17 --> Config Class Initialized
INFO - 2016-11-08 18:41:17 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:41:17 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:41:17 --> Utf8 Class Initialized
INFO - 2016-11-08 18:41:17 --> URI Class Initialized
DEBUG - 2016-11-08 18:41:17 --> No URI present. Default controller set.
INFO - 2016-11-08 18:41:17 --> Router Class Initialized
INFO - 2016-11-08 18:41:17 --> Output Class Initialized
INFO - 2016-11-08 18:41:17 --> Security Class Initialized
DEBUG - 2016-11-08 18:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:41:17 --> Input Class Initialized
INFO - 2016-11-08 18:41:17 --> Language Class Initialized
INFO - 2016-11-08 18:41:17 --> Loader Class Initialized
INFO - 2016-11-08 18:41:17 --> Helper loaded: url_helper
INFO - 2016-11-08 18:41:17 --> Helper loaded: form_helper
INFO - 2016-11-08 18:41:17 --> Database Driver Class Initialized
INFO - 2016-11-08 18:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:41:17 --> Controller Class Initialized
INFO - 2016-11-08 18:41:17 --> Model Class Initialized
INFO - 2016-11-08 18:41:17 --> Model Class Initialized
INFO - 2016-11-08 18:41:17 --> Model Class Initialized
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:41:17 --> Final output sent to browser
DEBUG - 2016-11-08 18:41:18 --> Total execution time: 0.4707
INFO - 2016-11-08 18:41:20 --> Config Class Initialized
INFO - 2016-11-08 18:41:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:41:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:41:20 --> Utf8 Class Initialized
INFO - 2016-11-08 18:41:20 --> URI Class Initialized
INFO - 2016-11-08 18:41:20 --> Router Class Initialized
INFO - 2016-11-08 18:41:20 --> Output Class Initialized
INFO - 2016-11-08 18:41:20 --> Security Class Initialized
DEBUG - 2016-11-08 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:41:20 --> Input Class Initialized
INFO - 2016-11-08 18:41:20 --> Language Class Initialized
INFO - 2016-11-08 18:41:20 --> Loader Class Initialized
INFO - 2016-11-08 18:41:20 --> Helper loaded: url_helper
INFO - 2016-11-08 18:41:20 --> Helper loaded: form_helper
INFO - 2016-11-08 18:41:20 --> Database Driver Class Initialized
INFO - 2016-11-08 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:41:20 --> Controller Class Initialized
INFO - 2016-11-08 18:41:20 --> Model Class Initialized
INFO - 2016-11-08 18:41:20 --> Form Validation Class Initialized
INFO - 2016-11-08 18:41:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:41:20 --> Final output sent to browser
DEBUG - 2016-11-08 18:41:20 --> Total execution time: 0.3022
INFO - 2016-11-08 18:41:22 --> Config Class Initialized
INFO - 2016-11-08 18:41:22 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:41:22 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:41:22 --> Utf8 Class Initialized
INFO - 2016-11-08 18:41:22 --> URI Class Initialized
DEBUG - 2016-11-08 18:41:22 --> No URI present. Default controller set.
INFO - 2016-11-08 18:41:22 --> Router Class Initialized
INFO - 2016-11-08 18:41:22 --> Output Class Initialized
INFO - 2016-11-08 18:41:22 --> Security Class Initialized
DEBUG - 2016-11-08 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:41:22 --> Input Class Initialized
INFO - 2016-11-08 18:41:22 --> Language Class Initialized
INFO - 2016-11-08 18:41:22 --> Loader Class Initialized
INFO - 2016-11-08 18:41:22 --> Helper loaded: url_helper
INFO - 2016-11-08 18:41:22 --> Helper loaded: form_helper
INFO - 2016-11-08 18:41:22 --> Database Driver Class Initialized
INFO - 2016-11-08 18:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:41:22 --> Controller Class Initialized
INFO - 2016-11-08 18:41:22 --> Model Class Initialized
INFO - 2016-11-08 18:41:22 --> Model Class Initialized
INFO - 2016-11-08 18:41:22 --> Model Class Initialized
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:41:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:41:22 --> Final output sent to browser
DEBUG - 2016-11-08 18:41:22 --> Total execution time: 0.5127
INFO - 2016-11-08 18:44:15 --> Config Class Initialized
INFO - 2016-11-08 18:44:15 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:44:15 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:44:15 --> Utf8 Class Initialized
INFO - 2016-11-08 18:44:15 --> URI Class Initialized
DEBUG - 2016-11-08 18:44:15 --> No URI present. Default controller set.
INFO - 2016-11-08 18:44:15 --> Router Class Initialized
INFO - 2016-11-08 18:44:15 --> Output Class Initialized
INFO - 2016-11-08 18:44:15 --> Security Class Initialized
DEBUG - 2016-11-08 18:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:44:15 --> Input Class Initialized
INFO - 2016-11-08 18:44:15 --> Language Class Initialized
INFO - 2016-11-08 18:44:15 --> Loader Class Initialized
INFO - 2016-11-08 18:44:15 --> Helper loaded: url_helper
INFO - 2016-11-08 18:44:15 --> Helper loaded: form_helper
INFO - 2016-11-08 18:44:15 --> Database Driver Class Initialized
INFO - 2016-11-08 18:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:44:15 --> Controller Class Initialized
INFO - 2016-11-08 18:44:15 --> Model Class Initialized
INFO - 2016-11-08 18:44:15 --> Model Class Initialized
INFO - 2016-11-08 18:44:15 --> Model Class Initialized
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:44:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:44:15 --> Final output sent to browser
DEBUG - 2016-11-08 18:44:15 --> Total execution time: 0.4244
INFO - 2016-11-08 18:44:18 --> Config Class Initialized
INFO - 2016-11-08 18:44:18 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:44:18 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:44:18 --> Utf8 Class Initialized
INFO - 2016-11-08 18:44:18 --> URI Class Initialized
INFO - 2016-11-08 18:44:18 --> Router Class Initialized
INFO - 2016-11-08 18:44:18 --> Output Class Initialized
INFO - 2016-11-08 18:44:18 --> Security Class Initialized
DEBUG - 2016-11-08 18:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:44:18 --> Input Class Initialized
INFO - 2016-11-08 18:44:18 --> Language Class Initialized
INFO - 2016-11-08 18:44:18 --> Loader Class Initialized
INFO - 2016-11-08 18:44:18 --> Helper loaded: url_helper
INFO - 2016-11-08 18:44:18 --> Helper loaded: form_helper
INFO - 2016-11-08 18:44:18 --> Database Driver Class Initialized
INFO - 2016-11-08 18:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:44:18 --> Controller Class Initialized
INFO - 2016-11-08 18:44:18 --> Model Class Initialized
INFO - 2016-11-08 18:44:18 --> Form Validation Class Initialized
INFO - 2016-11-08 18:44:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:44:18 --> Final output sent to browser
DEBUG - 2016-11-08 18:44:18 --> Total execution time: 0.2931
INFO - 2016-11-08 18:44:20 --> Config Class Initialized
INFO - 2016-11-08 18:44:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:44:20 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:44:20 --> Utf8 Class Initialized
INFO - 2016-11-08 18:44:20 --> URI Class Initialized
DEBUG - 2016-11-08 18:44:20 --> No URI present. Default controller set.
INFO - 2016-11-08 18:44:20 --> Router Class Initialized
INFO - 2016-11-08 18:44:20 --> Output Class Initialized
INFO - 2016-11-08 18:44:20 --> Security Class Initialized
DEBUG - 2016-11-08 18:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:44:20 --> Input Class Initialized
INFO - 2016-11-08 18:44:20 --> Language Class Initialized
INFO - 2016-11-08 18:44:20 --> Loader Class Initialized
INFO - 2016-11-08 18:44:20 --> Helper loaded: url_helper
INFO - 2016-11-08 18:44:20 --> Helper loaded: form_helper
INFO - 2016-11-08 18:44:20 --> Database Driver Class Initialized
INFO - 2016-11-08 18:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:44:20 --> Controller Class Initialized
INFO - 2016-11-08 18:44:20 --> Model Class Initialized
INFO - 2016-11-08 18:44:20 --> Model Class Initialized
INFO - 2016-11-08 18:44:20 --> Model Class Initialized
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:44:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:44:20 --> Final output sent to browser
DEBUG - 2016-11-08 18:44:20 --> Total execution time: 0.4366
INFO - 2016-11-08 18:45:18 --> Config Class Initialized
INFO - 2016-11-08 18:45:18 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:45:18 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:45:18 --> Utf8 Class Initialized
INFO - 2016-11-08 18:45:18 --> URI Class Initialized
INFO - 2016-11-08 18:45:18 --> Router Class Initialized
INFO - 2016-11-08 18:45:18 --> Output Class Initialized
INFO - 2016-11-08 18:45:18 --> Security Class Initialized
DEBUG - 2016-11-08 18:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:45:18 --> Input Class Initialized
INFO - 2016-11-08 18:45:18 --> Language Class Initialized
INFO - 2016-11-08 18:45:18 --> Loader Class Initialized
INFO - 2016-11-08 18:45:18 --> Helper loaded: url_helper
INFO - 2016-11-08 18:45:18 --> Helper loaded: form_helper
INFO - 2016-11-08 18:45:18 --> Database Driver Class Initialized
INFO - 2016-11-08 18:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:45:18 --> Controller Class Initialized
INFO - 2016-11-08 18:45:18 --> Model Class Initialized
INFO - 2016-11-08 18:45:18 --> Model Class Initialized
INFO - 2016-11-08 18:45:18 --> Model Class Initialized
DEBUG - 2016-11-08 18:45:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 18:45:18 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-08 18:45:18 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-08 18:45:18 --> Config Class Initialized
INFO - 2016-11-08 18:45:18 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:45:18 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:45:18 --> Utf8 Class Initialized
INFO - 2016-11-08 18:45:18 --> URI Class Initialized
DEBUG - 2016-11-08 18:45:18 --> No URI present. Default controller set.
INFO - 2016-11-08 18:45:18 --> Router Class Initialized
INFO - 2016-11-08 18:45:18 --> Output Class Initialized
INFO - 2016-11-08 18:45:18 --> Security Class Initialized
DEBUG - 2016-11-08 18:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:45:18 --> Input Class Initialized
INFO - 2016-11-08 18:45:18 --> Language Class Initialized
INFO - 2016-11-08 18:45:18 --> Loader Class Initialized
INFO - 2016-11-08 18:45:18 --> Helper loaded: url_helper
INFO - 2016-11-08 18:45:18 --> Helper loaded: form_helper
INFO - 2016-11-08 18:45:18 --> Database Driver Class Initialized
INFO - 2016-11-08 18:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:45:18 --> Controller Class Initialized
INFO - 2016-11-08 18:45:18 --> Model Class Initialized
INFO - 2016-11-08 18:45:18 --> Model Class Initialized
INFO - 2016-11-08 18:45:18 --> Model Class Initialized
INFO - 2016-11-08 18:45:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:45:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 18:45:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:45:18 --> Final output sent to browser
DEBUG - 2016-11-08 18:45:18 --> Total execution time: 0.3570
INFO - 2016-11-08 18:45:48 --> Config Class Initialized
INFO - 2016-11-08 18:45:48 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:45:48 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:45:48 --> Utf8 Class Initialized
INFO - 2016-11-08 18:45:48 --> URI Class Initialized
INFO - 2016-11-08 18:45:48 --> Router Class Initialized
INFO - 2016-11-08 18:45:48 --> Output Class Initialized
INFO - 2016-11-08 18:45:48 --> Security Class Initialized
DEBUG - 2016-11-08 18:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:45:48 --> Input Class Initialized
INFO - 2016-11-08 18:45:48 --> Language Class Initialized
INFO - 2016-11-08 18:45:48 --> Loader Class Initialized
INFO - 2016-11-08 18:45:48 --> Helper loaded: url_helper
INFO - 2016-11-08 18:45:48 --> Helper loaded: form_helper
INFO - 2016-11-08 18:45:48 --> Database Driver Class Initialized
INFO - 2016-11-08 18:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:45:48 --> Controller Class Initialized
INFO - 2016-11-08 18:45:48 --> Model Class Initialized
INFO - 2016-11-08 18:45:48 --> Model Class Initialized
INFO - 2016-11-08 18:45:48 --> Model Class Initialized
DEBUG - 2016-11-08 18:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 18:45:48 --> Model Class Initialized
INFO - 2016-11-08 18:45:48 --> Final output sent to browser
DEBUG - 2016-11-08 18:45:48 --> Total execution time: 0.3270
INFO - 2016-11-08 18:45:56 --> Config Class Initialized
INFO - 2016-11-08 18:45:56 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:45:56 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:45:56 --> Utf8 Class Initialized
INFO - 2016-11-08 18:45:56 --> URI Class Initialized
INFO - 2016-11-08 18:45:56 --> Router Class Initialized
INFO - 2016-11-08 18:45:56 --> Output Class Initialized
INFO - 2016-11-08 18:45:56 --> Security Class Initialized
DEBUG - 2016-11-08 18:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:45:56 --> Input Class Initialized
INFO - 2016-11-08 18:45:56 --> Language Class Initialized
INFO - 2016-11-08 18:45:56 --> Loader Class Initialized
INFO - 2016-11-08 18:45:56 --> Helper loaded: url_helper
INFO - 2016-11-08 18:45:56 --> Helper loaded: form_helper
INFO - 2016-11-08 18:45:56 --> Database Driver Class Initialized
INFO - 2016-11-08 18:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:45:57 --> Controller Class Initialized
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
DEBUG - 2016-11-08 18:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
INFO - 2016-11-08 18:45:57 --> Final output sent to browser
DEBUG - 2016-11-08 18:45:57 --> Total execution time: 0.3303
INFO - 2016-11-08 18:45:57 --> Config Class Initialized
INFO - 2016-11-08 18:45:57 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:45:57 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:45:57 --> Utf8 Class Initialized
INFO - 2016-11-08 18:45:57 --> URI Class Initialized
DEBUG - 2016-11-08 18:45:57 --> No URI present. Default controller set.
INFO - 2016-11-08 18:45:57 --> Router Class Initialized
INFO - 2016-11-08 18:45:57 --> Output Class Initialized
INFO - 2016-11-08 18:45:57 --> Security Class Initialized
DEBUG - 2016-11-08 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:45:57 --> Input Class Initialized
INFO - 2016-11-08 18:45:57 --> Language Class Initialized
INFO - 2016-11-08 18:45:57 --> Loader Class Initialized
INFO - 2016-11-08 18:45:57 --> Helper loaded: url_helper
INFO - 2016-11-08 18:45:57 --> Helper loaded: form_helper
INFO - 2016-11-08 18:45:57 --> Database Driver Class Initialized
INFO - 2016-11-08 18:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:45:57 --> Controller Class Initialized
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
INFO - 2016-11-08 18:45:57 --> Model Class Initialized
INFO - 2016-11-08 18:45:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:45:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:45:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:45:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:45:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:45:57 --> Final output sent to browser
DEBUG - 2016-11-08 18:45:57 --> Total execution time: 0.3870
INFO - 2016-11-08 18:46:28 --> Config Class Initialized
INFO - 2016-11-08 18:46:28 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:46:28 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:46:28 --> Utf8 Class Initialized
INFO - 2016-11-08 18:46:28 --> URI Class Initialized
DEBUG - 2016-11-08 18:46:28 --> No URI present. Default controller set.
INFO - 2016-11-08 18:46:28 --> Router Class Initialized
INFO - 2016-11-08 18:46:28 --> Output Class Initialized
INFO - 2016-11-08 18:46:28 --> Security Class Initialized
DEBUG - 2016-11-08 18:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:46:28 --> Input Class Initialized
INFO - 2016-11-08 18:46:28 --> Language Class Initialized
INFO - 2016-11-08 18:46:28 --> Loader Class Initialized
INFO - 2016-11-08 18:46:28 --> Helper loaded: url_helper
INFO - 2016-11-08 18:46:28 --> Helper loaded: form_helper
INFO - 2016-11-08 18:46:28 --> Database Driver Class Initialized
INFO - 2016-11-08 18:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:46:28 --> Controller Class Initialized
INFO - 2016-11-08 18:46:28 --> Model Class Initialized
INFO - 2016-11-08 18:46:28 --> Model Class Initialized
INFO - 2016-11-08 18:46:28 --> Model Class Initialized
INFO - 2016-11-08 18:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:46:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:46:28 --> Final output sent to browser
DEBUG - 2016-11-08 18:46:28 --> Total execution time: 0.4014
INFO - 2016-11-08 18:46:32 --> Config Class Initialized
INFO - 2016-11-08 18:46:32 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:46:32 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:46:32 --> Utf8 Class Initialized
INFO - 2016-11-08 18:46:32 --> URI Class Initialized
DEBUG - 2016-11-08 18:46:32 --> No URI present. Default controller set.
INFO - 2016-11-08 18:46:32 --> Router Class Initialized
INFO - 2016-11-08 18:46:32 --> Output Class Initialized
INFO - 2016-11-08 18:46:32 --> Security Class Initialized
DEBUG - 2016-11-08 18:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:46:32 --> Input Class Initialized
INFO - 2016-11-08 18:46:32 --> Language Class Initialized
INFO - 2016-11-08 18:46:32 --> Loader Class Initialized
INFO - 2016-11-08 18:46:32 --> Helper loaded: url_helper
INFO - 2016-11-08 18:46:32 --> Helper loaded: form_helper
INFO - 2016-11-08 18:46:32 --> Database Driver Class Initialized
INFO - 2016-11-08 18:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:46:32 --> Controller Class Initialized
INFO - 2016-11-08 18:46:32 --> Model Class Initialized
INFO - 2016-11-08 18:46:32 --> Model Class Initialized
INFO - 2016-11-08 18:46:32 --> Model Class Initialized
INFO - 2016-11-08 18:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:46:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:46:32 --> Final output sent to browser
DEBUG - 2016-11-08 18:46:32 --> Total execution time: 0.4030
INFO - 2016-11-08 18:46:53 --> Config Class Initialized
INFO - 2016-11-08 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:46:53 --> Utf8 Class Initialized
INFO - 2016-11-08 18:46:53 --> URI Class Initialized
DEBUG - 2016-11-08 18:46:53 --> No URI present. Default controller set.
INFO - 2016-11-08 18:46:53 --> Router Class Initialized
INFO - 2016-11-08 18:46:53 --> Output Class Initialized
INFO - 2016-11-08 18:46:53 --> Security Class Initialized
DEBUG - 2016-11-08 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:46:53 --> Input Class Initialized
INFO - 2016-11-08 18:46:53 --> Language Class Initialized
INFO - 2016-11-08 18:46:53 --> Loader Class Initialized
INFO - 2016-11-08 18:46:53 --> Helper loaded: url_helper
INFO - 2016-11-08 18:46:53 --> Helper loaded: form_helper
INFO - 2016-11-08 18:46:53 --> Database Driver Class Initialized
INFO - 2016-11-08 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:46:53 --> Controller Class Initialized
INFO - 2016-11-08 18:46:53 --> Model Class Initialized
INFO - 2016-11-08 18:46:53 --> Model Class Initialized
INFO - 2016-11-08 18:46:53 --> Model Class Initialized
INFO - 2016-11-08 18:46:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:46:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:46:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:46:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:46:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:46:53 --> Final output sent to browser
DEBUG - 2016-11-08 18:46:53 --> Total execution time: 0.4365
INFO - 2016-11-08 18:46:53 --> Config Class Initialized
INFO - 2016-11-08 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:46:53 --> Utf8 Class Initialized
INFO - 2016-11-08 18:46:53 --> URI Class Initialized
DEBUG - 2016-11-08 18:46:53 --> No URI present. Default controller set.
INFO - 2016-11-08 18:46:53 --> Router Class Initialized
INFO - 2016-11-08 18:46:53 --> Output Class Initialized
INFO - 2016-11-08 18:46:53 --> Security Class Initialized
DEBUG - 2016-11-08 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:46:53 --> Input Class Initialized
INFO - 2016-11-08 18:46:53 --> Language Class Initialized
INFO - 2016-11-08 18:46:53 --> Loader Class Initialized
INFO - 2016-11-08 18:46:53 --> Helper loaded: url_helper
INFO - 2016-11-08 18:46:53 --> Helper loaded: form_helper
INFO - 2016-11-08 18:46:54 --> Database Driver Class Initialized
INFO - 2016-11-08 18:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:46:54 --> Controller Class Initialized
INFO - 2016-11-08 18:46:54 --> Model Class Initialized
INFO - 2016-11-08 18:46:54 --> Model Class Initialized
INFO - 2016-11-08 18:46:54 --> Model Class Initialized
INFO - 2016-11-08 18:46:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:46:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:46:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:46:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:46:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:46:54 --> Final output sent to browser
DEBUG - 2016-11-08 18:46:54 --> Total execution time: 0.4248
INFO - 2016-11-08 18:51:47 --> Config Class Initialized
INFO - 2016-11-08 18:51:47 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:51:47 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:51:47 --> Utf8 Class Initialized
INFO - 2016-11-08 18:51:47 --> URI Class Initialized
DEBUG - 2016-11-08 18:51:47 --> No URI present. Default controller set.
INFO - 2016-11-08 18:51:47 --> Router Class Initialized
INFO - 2016-11-08 18:51:47 --> Output Class Initialized
INFO - 2016-11-08 18:51:47 --> Security Class Initialized
DEBUG - 2016-11-08 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:51:47 --> Input Class Initialized
INFO - 2016-11-08 18:51:47 --> Language Class Initialized
INFO - 2016-11-08 18:51:47 --> Loader Class Initialized
INFO - 2016-11-08 18:51:47 --> Helper loaded: url_helper
INFO - 2016-11-08 18:51:47 --> Helper loaded: form_helper
INFO - 2016-11-08 18:51:47 --> Database Driver Class Initialized
INFO - 2016-11-08 18:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:51:47 --> Controller Class Initialized
INFO - 2016-11-08 18:51:47 --> Model Class Initialized
INFO - 2016-11-08 18:51:47 --> Model Class Initialized
INFO - 2016-11-08 18:51:47 --> Model Class Initialized
INFO - 2016-11-08 18:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:51:47 --> Final output sent to browser
DEBUG - 2016-11-08 18:51:47 --> Total execution time: 0.3989
INFO - 2016-11-08 18:51:49 --> Config Class Initialized
INFO - 2016-11-08 18:51:49 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:51:49 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:51:49 --> Utf8 Class Initialized
INFO - 2016-11-08 18:51:49 --> URI Class Initialized
INFO - 2016-11-08 18:51:49 --> Router Class Initialized
INFO - 2016-11-08 18:51:49 --> Output Class Initialized
INFO - 2016-11-08 18:51:49 --> Security Class Initialized
DEBUG - 2016-11-08 18:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:51:49 --> Input Class Initialized
INFO - 2016-11-08 18:51:49 --> Language Class Initialized
INFO - 2016-11-08 18:51:49 --> Loader Class Initialized
INFO - 2016-11-08 18:51:49 --> Helper loaded: url_helper
INFO - 2016-11-08 18:51:49 --> Helper loaded: form_helper
INFO - 2016-11-08 18:51:49 --> Database Driver Class Initialized
INFO - 2016-11-08 18:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:51:49 --> Controller Class Initialized
INFO - 2016-11-08 18:51:49 --> Model Class Initialized
INFO - 2016-11-08 18:51:49 --> Model Class Initialized
INFO - 2016-11-08 18:51:49 --> Model Class Initialized
DEBUG - 2016-11-08 18:51:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 18:51:49 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-08 18:51:49 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-08 18:51:50 --> Config Class Initialized
INFO - 2016-11-08 18:51:50 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:51:50 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:51:50 --> Utf8 Class Initialized
INFO - 2016-11-08 18:51:50 --> URI Class Initialized
DEBUG - 2016-11-08 18:51:50 --> No URI present. Default controller set.
INFO - 2016-11-08 18:51:50 --> Router Class Initialized
INFO - 2016-11-08 18:51:50 --> Output Class Initialized
INFO - 2016-11-08 18:51:50 --> Security Class Initialized
DEBUG - 2016-11-08 18:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:51:50 --> Input Class Initialized
INFO - 2016-11-08 18:51:50 --> Language Class Initialized
INFO - 2016-11-08 18:51:50 --> Loader Class Initialized
INFO - 2016-11-08 18:51:50 --> Helper loaded: url_helper
INFO - 2016-11-08 18:51:50 --> Helper loaded: form_helper
INFO - 2016-11-08 18:51:50 --> Database Driver Class Initialized
INFO - 2016-11-08 18:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:51:50 --> Controller Class Initialized
INFO - 2016-11-08 18:51:50 --> Model Class Initialized
INFO - 2016-11-08 18:51:50 --> Model Class Initialized
INFO - 2016-11-08 18:51:50 --> Model Class Initialized
INFO - 2016-11-08 18:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 18:51:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:51:50 --> Final output sent to browser
DEBUG - 2016-11-08 18:51:50 --> Total execution time: 0.3626
INFO - 2016-11-08 18:52:20 --> Config Class Initialized
INFO - 2016-11-08 18:52:20 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:52:21 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:52:21 --> Utf8 Class Initialized
INFO - 2016-11-08 18:52:21 --> URI Class Initialized
INFO - 2016-11-08 18:52:21 --> Router Class Initialized
INFO - 2016-11-08 18:52:21 --> Output Class Initialized
INFO - 2016-11-08 18:52:21 --> Security Class Initialized
DEBUG - 2016-11-08 18:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:52:21 --> Input Class Initialized
INFO - 2016-11-08 18:52:21 --> Language Class Initialized
INFO - 2016-11-08 18:52:21 --> Loader Class Initialized
INFO - 2016-11-08 18:52:21 --> Helper loaded: url_helper
INFO - 2016-11-08 18:52:21 --> Helper loaded: form_helper
INFO - 2016-11-08 18:52:21 --> Database Driver Class Initialized
INFO - 2016-11-08 18:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:52:21 --> Controller Class Initialized
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
DEBUG - 2016-11-08 18:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
INFO - 2016-11-08 18:52:21 --> Final output sent to browser
DEBUG - 2016-11-08 18:52:21 --> Total execution time: 0.3554
INFO - 2016-11-08 18:52:21 --> Config Class Initialized
INFO - 2016-11-08 18:52:21 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:52:21 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:52:21 --> Utf8 Class Initialized
INFO - 2016-11-08 18:52:21 --> URI Class Initialized
DEBUG - 2016-11-08 18:52:21 --> No URI present. Default controller set.
INFO - 2016-11-08 18:52:21 --> Router Class Initialized
INFO - 2016-11-08 18:52:21 --> Output Class Initialized
INFO - 2016-11-08 18:52:21 --> Security Class Initialized
DEBUG - 2016-11-08 18:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:52:21 --> Input Class Initialized
INFO - 2016-11-08 18:52:21 --> Language Class Initialized
INFO - 2016-11-08 18:52:21 --> Loader Class Initialized
INFO - 2016-11-08 18:52:21 --> Helper loaded: url_helper
INFO - 2016-11-08 18:52:21 --> Helper loaded: form_helper
INFO - 2016-11-08 18:52:21 --> Database Driver Class Initialized
INFO - 2016-11-08 18:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:52:21 --> Controller Class Initialized
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
INFO - 2016-11-08 18:52:21 --> Model Class Initialized
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:52:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:52:21 --> Final output sent to browser
DEBUG - 2016-11-08 18:52:21 --> Total execution time: 0.4343
INFO - 2016-11-08 18:52:25 --> Config Class Initialized
INFO - 2016-11-08 18:52:25 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:52:25 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:52:25 --> Utf8 Class Initialized
INFO - 2016-11-08 18:52:25 --> URI Class Initialized
INFO - 2016-11-08 18:52:25 --> Router Class Initialized
INFO - 2016-11-08 18:52:25 --> Output Class Initialized
INFO - 2016-11-08 18:52:25 --> Security Class Initialized
DEBUG - 2016-11-08 18:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:52:25 --> Input Class Initialized
INFO - 2016-11-08 18:52:25 --> Language Class Initialized
INFO - 2016-11-08 18:52:25 --> Loader Class Initialized
INFO - 2016-11-08 18:52:25 --> Helper loaded: url_helper
INFO - 2016-11-08 18:52:25 --> Helper loaded: form_helper
INFO - 2016-11-08 18:52:25 --> Database Driver Class Initialized
INFO - 2016-11-08 18:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:52:25 --> Controller Class Initialized
INFO - 2016-11-08 18:52:25 --> Model Class Initialized
INFO - 2016-11-08 18:52:25 --> Form Validation Class Initialized
INFO - 2016-11-08 18:52:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:52:25 --> Final output sent to browser
DEBUG - 2016-11-08 18:52:25 --> Total execution time: 0.3144
INFO - 2016-11-08 18:52:27 --> Config Class Initialized
INFO - 2016-11-08 18:52:27 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:52:27 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:52:27 --> Utf8 Class Initialized
INFO - 2016-11-08 18:52:27 --> URI Class Initialized
DEBUG - 2016-11-08 18:52:27 --> No URI present. Default controller set.
INFO - 2016-11-08 18:52:27 --> Router Class Initialized
INFO - 2016-11-08 18:52:27 --> Output Class Initialized
INFO - 2016-11-08 18:52:27 --> Security Class Initialized
DEBUG - 2016-11-08 18:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:52:27 --> Input Class Initialized
INFO - 2016-11-08 18:52:27 --> Language Class Initialized
INFO - 2016-11-08 18:52:27 --> Loader Class Initialized
INFO - 2016-11-08 18:52:27 --> Helper loaded: url_helper
INFO - 2016-11-08 18:52:27 --> Helper loaded: form_helper
INFO - 2016-11-08 18:52:27 --> Database Driver Class Initialized
INFO - 2016-11-08 18:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:52:27 --> Controller Class Initialized
INFO - 2016-11-08 18:52:27 --> Model Class Initialized
INFO - 2016-11-08 18:52:27 --> Model Class Initialized
INFO - 2016-11-08 18:52:27 --> Model Class Initialized
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:52:27 --> Final output sent to browser
DEBUG - 2016-11-08 18:52:27 --> Total execution time: 0.4914
INFO - 2016-11-08 18:53:01 --> Config Class Initialized
INFO - 2016-11-08 18:53:01 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:53:01 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:53:01 --> Utf8 Class Initialized
INFO - 2016-11-08 18:53:01 --> URI Class Initialized
DEBUG - 2016-11-08 18:53:01 --> No URI present. Default controller set.
INFO - 2016-11-08 18:53:01 --> Router Class Initialized
INFO - 2016-11-08 18:53:01 --> Output Class Initialized
INFO - 2016-11-08 18:53:01 --> Security Class Initialized
DEBUG - 2016-11-08 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:53:01 --> Input Class Initialized
INFO - 2016-11-08 18:53:01 --> Language Class Initialized
INFO - 2016-11-08 18:53:01 --> Loader Class Initialized
INFO - 2016-11-08 18:53:01 --> Helper loaded: url_helper
INFO - 2016-11-08 18:53:01 --> Helper loaded: form_helper
INFO - 2016-11-08 18:53:01 --> Database Driver Class Initialized
INFO - 2016-11-08 18:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:53:01 --> Controller Class Initialized
INFO - 2016-11-08 18:53:01 --> Model Class Initialized
INFO - 2016-11-08 18:53:01 --> Model Class Initialized
INFO - 2016-11-08 18:53:01 --> Model Class Initialized
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:53:01 --> Final output sent to browser
DEBUG - 2016-11-08 18:53:01 --> Total execution time: 0.4684
INFO - 2016-11-08 18:53:04 --> Config Class Initialized
INFO - 2016-11-08 18:53:04 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:53:04 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:53:04 --> Utf8 Class Initialized
INFO - 2016-11-08 18:53:04 --> URI Class Initialized
INFO - 2016-11-08 18:53:04 --> Router Class Initialized
INFO - 2016-11-08 18:53:04 --> Output Class Initialized
INFO - 2016-11-08 18:53:04 --> Security Class Initialized
DEBUG - 2016-11-08 18:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:53:04 --> Input Class Initialized
INFO - 2016-11-08 18:53:04 --> Language Class Initialized
INFO - 2016-11-08 18:53:04 --> Loader Class Initialized
INFO - 2016-11-08 18:53:04 --> Helper loaded: url_helper
INFO - 2016-11-08 18:53:04 --> Helper loaded: form_helper
INFO - 2016-11-08 18:53:04 --> Database Driver Class Initialized
INFO - 2016-11-08 18:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:53:04 --> Controller Class Initialized
INFO - 2016-11-08 18:53:04 --> Model Class Initialized
INFO - 2016-11-08 18:53:04 --> Form Validation Class Initialized
INFO - 2016-11-08 18:53:59 --> Config Class Initialized
INFO - 2016-11-08 18:53:59 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:53:59 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:53:59 --> Utf8 Class Initialized
INFO - 2016-11-08 18:53:59 --> URI Class Initialized
INFO - 2016-11-08 18:53:59 --> Router Class Initialized
INFO - 2016-11-08 18:53:59 --> Output Class Initialized
INFO - 2016-11-08 18:53:59 --> Security Class Initialized
DEBUG - 2016-11-08 18:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:53:59 --> Input Class Initialized
INFO - 2016-11-08 18:53:59 --> Language Class Initialized
INFO - 2016-11-08 18:53:59 --> Loader Class Initialized
INFO - 2016-11-08 18:53:59 --> Helper loaded: url_helper
INFO - 2016-11-08 18:53:59 --> Helper loaded: form_helper
INFO - 2016-11-08 18:53:59 --> Database Driver Class Initialized
INFO - 2016-11-08 18:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:53:59 --> Controller Class Initialized
INFO - 2016-11-08 18:53:59 --> Model Class Initialized
INFO - 2016-11-08 18:53:59 --> Form Validation Class Initialized
INFO - 2016-11-08 18:57:05 --> Config Class Initialized
INFO - 2016-11-08 18:57:05 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:57:05 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:57:05 --> Utf8 Class Initialized
INFO - 2016-11-08 18:57:05 --> URI Class Initialized
INFO - 2016-11-08 18:57:05 --> Router Class Initialized
INFO - 2016-11-08 18:57:05 --> Output Class Initialized
INFO - 2016-11-08 18:57:05 --> Security Class Initialized
DEBUG - 2016-11-08 18:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:57:05 --> Input Class Initialized
INFO - 2016-11-08 18:57:05 --> Language Class Initialized
INFO - 2016-11-08 18:57:05 --> Loader Class Initialized
INFO - 2016-11-08 18:57:05 --> Helper loaded: url_helper
INFO - 2016-11-08 18:57:05 --> Helper loaded: form_helper
INFO - 2016-11-08 18:57:05 --> Database Driver Class Initialized
INFO - 2016-11-08 18:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:57:05 --> Controller Class Initialized
INFO - 2016-11-08 18:57:05 --> Model Class Initialized
INFO - 2016-11-08 18:57:06 --> Form Validation Class Initialized
INFO - 2016-11-08 18:57:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:57:06 --> Final output sent to browser
DEBUG - 2016-11-08 18:57:06 --> Total execution time: 0.3142
INFO - 2016-11-08 18:58:18 --> Config Class Initialized
INFO - 2016-11-08 18:58:18 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:58:18 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:58:18 --> Utf8 Class Initialized
INFO - 2016-11-08 18:58:18 --> URI Class Initialized
INFO - 2016-11-08 18:58:18 --> Router Class Initialized
INFO - 2016-11-08 18:58:18 --> Output Class Initialized
INFO - 2016-11-08 18:58:18 --> Security Class Initialized
DEBUG - 2016-11-08 18:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:58:18 --> Input Class Initialized
INFO - 2016-11-08 18:58:18 --> Language Class Initialized
INFO - 2016-11-08 18:58:18 --> Loader Class Initialized
INFO - 2016-11-08 18:58:18 --> Helper loaded: url_helper
INFO - 2016-11-08 18:58:18 --> Helper loaded: form_helper
INFO - 2016-11-08 18:58:18 --> Database Driver Class Initialized
INFO - 2016-11-08 18:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:58:18 --> Controller Class Initialized
INFO - 2016-11-08 18:58:18 --> Model Class Initialized
INFO - 2016-11-08 18:58:18 --> Form Validation Class Initialized
INFO - 2016-11-08 18:58:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:58:18 --> Final output sent to browser
DEBUG - 2016-11-08 18:58:18 --> Total execution time: 0.3280
INFO - 2016-11-08 18:58:19 --> Config Class Initialized
INFO - 2016-11-08 18:58:19 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:58:19 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:58:19 --> Utf8 Class Initialized
INFO - 2016-11-08 18:58:19 --> URI Class Initialized
DEBUG - 2016-11-08 18:58:19 --> No URI present. Default controller set.
INFO - 2016-11-08 18:58:19 --> Router Class Initialized
INFO - 2016-11-08 18:58:19 --> Output Class Initialized
INFO - 2016-11-08 18:58:19 --> Security Class Initialized
DEBUG - 2016-11-08 18:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:58:19 --> Input Class Initialized
INFO - 2016-11-08 18:58:19 --> Language Class Initialized
INFO - 2016-11-08 18:58:19 --> Loader Class Initialized
INFO - 2016-11-08 18:58:19 --> Helper loaded: url_helper
INFO - 2016-11-08 18:58:20 --> Helper loaded: form_helper
INFO - 2016-11-08 18:58:20 --> Database Driver Class Initialized
INFO - 2016-11-08 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:58:20 --> Controller Class Initialized
INFO - 2016-11-08 18:58:20 --> Model Class Initialized
INFO - 2016-11-08 18:58:20 --> Model Class Initialized
INFO - 2016-11-08 18:58:20 --> Model Class Initialized
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:58:20 --> Final output sent to browser
DEBUG - 2016-11-08 18:58:20 --> Total execution time: 0.5051
INFO - 2016-11-08 18:58:41 --> Config Class Initialized
INFO - 2016-11-08 18:58:41 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:58:41 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:58:41 --> Utf8 Class Initialized
INFO - 2016-11-08 18:58:41 --> URI Class Initialized
INFO - 2016-11-08 18:58:41 --> Router Class Initialized
INFO - 2016-11-08 18:58:41 --> Output Class Initialized
INFO - 2016-11-08 18:58:41 --> Security Class Initialized
DEBUG - 2016-11-08 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:58:41 --> Input Class Initialized
INFO - 2016-11-08 18:58:41 --> Language Class Initialized
INFO - 2016-11-08 18:58:41 --> Loader Class Initialized
INFO - 2016-11-08 18:58:41 --> Helper loaded: url_helper
INFO - 2016-11-08 18:58:41 --> Helper loaded: form_helper
INFO - 2016-11-08 18:58:41 --> Database Driver Class Initialized
INFO - 2016-11-08 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:58:41 --> Controller Class Initialized
INFO - 2016-11-08 18:58:41 --> Model Class Initialized
INFO - 2016-11-08 18:58:41 --> Form Validation Class Initialized
INFO - 2016-11-08 18:58:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-08 18:58:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:58:41 --> Final output sent to browser
DEBUG - 2016-11-08 18:58:41 --> Total execution time: 0.4251
INFO - 2016-11-08 18:58:42 --> Config Class Initialized
INFO - 2016-11-08 18:58:42 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:58:42 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:58:42 --> Utf8 Class Initialized
INFO - 2016-11-08 18:58:42 --> URI Class Initialized
DEBUG - 2016-11-08 18:58:42 --> No URI present. Default controller set.
INFO - 2016-11-08 18:58:42 --> Router Class Initialized
INFO - 2016-11-08 18:58:42 --> Output Class Initialized
INFO - 2016-11-08 18:58:43 --> Security Class Initialized
DEBUG - 2016-11-08 18:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:58:43 --> Input Class Initialized
INFO - 2016-11-08 18:58:43 --> Language Class Initialized
INFO - 2016-11-08 18:58:43 --> Loader Class Initialized
INFO - 2016-11-08 18:58:43 --> Helper loaded: url_helper
INFO - 2016-11-08 18:58:43 --> Helper loaded: form_helper
INFO - 2016-11-08 18:58:43 --> Database Driver Class Initialized
INFO - 2016-11-08 18:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:58:43 --> Controller Class Initialized
INFO - 2016-11-08 18:58:43 --> Model Class Initialized
INFO - 2016-11-08 18:58:43 --> Model Class Initialized
INFO - 2016-11-08 18:58:43 --> Model Class Initialized
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-08 18:58:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:58:43 --> Final output sent to browser
DEBUG - 2016-11-08 18:58:43 --> Total execution time: 0.5209
INFO - 2016-11-08 18:59:24 --> Config Class Initialized
INFO - 2016-11-08 18:59:24 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:59:24 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:59:24 --> Utf8 Class Initialized
INFO - 2016-11-08 18:59:24 --> URI Class Initialized
INFO - 2016-11-08 18:59:24 --> Router Class Initialized
INFO - 2016-11-08 18:59:24 --> Output Class Initialized
INFO - 2016-11-08 18:59:24 --> Security Class Initialized
DEBUG - 2016-11-08 18:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:59:24 --> Input Class Initialized
INFO - 2016-11-08 18:59:24 --> Language Class Initialized
INFO - 2016-11-08 18:59:24 --> Loader Class Initialized
INFO - 2016-11-08 18:59:24 --> Helper loaded: url_helper
INFO - 2016-11-08 18:59:24 --> Helper loaded: form_helper
INFO - 2016-11-08 18:59:24 --> Database Driver Class Initialized
INFO - 2016-11-08 18:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:59:24 --> Controller Class Initialized
INFO - 2016-11-08 18:59:24 --> Model Class Initialized
INFO - 2016-11-08 18:59:24 --> Model Class Initialized
INFO - 2016-11-08 18:59:24 --> Model Class Initialized
DEBUG - 2016-11-08 18:59:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-08 18:59:24 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
ERROR - 2016-11-08 18:59:24 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 127
INFO - 2016-11-08 18:59:24 --> Config Class Initialized
INFO - 2016-11-08 18:59:24 --> Hooks Class Initialized
DEBUG - 2016-11-08 18:59:24 --> UTF-8 Support Enabled
INFO - 2016-11-08 18:59:24 --> Utf8 Class Initialized
INFO - 2016-11-08 18:59:24 --> URI Class Initialized
DEBUG - 2016-11-08 18:59:24 --> No URI present. Default controller set.
INFO - 2016-11-08 18:59:24 --> Router Class Initialized
INFO - 2016-11-08 18:59:24 --> Output Class Initialized
INFO - 2016-11-08 18:59:24 --> Security Class Initialized
DEBUG - 2016-11-08 18:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-08 18:59:24 --> Input Class Initialized
INFO - 2016-11-08 18:59:24 --> Language Class Initialized
INFO - 2016-11-08 18:59:24 --> Loader Class Initialized
INFO - 2016-11-08 18:59:24 --> Helper loaded: url_helper
INFO - 2016-11-08 18:59:24 --> Helper loaded: form_helper
INFO - 2016-11-08 18:59:24 --> Database Driver Class Initialized
INFO - 2016-11-08 18:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-08 18:59:24 --> Controller Class Initialized
INFO - 2016-11-08 18:59:24 --> Model Class Initialized
INFO - 2016-11-08 18:59:24 --> Model Class Initialized
INFO - 2016-11-08 18:59:24 --> Model Class Initialized
INFO - 2016-11-08 18:59:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-08 18:59:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-08 18:59:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-08 18:59:24 --> Final output sent to browser
DEBUG - 2016-11-08 18:59:24 --> Total execution time: 0.3717
