<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-29 10:56:56 --> Config Class Initialized
INFO - 2016-11-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:56:57 --> Utf8 Class Initialized
INFO - 2016-11-29 10:56:57 --> URI Class Initialized
DEBUG - 2016-11-29 10:56:57 --> No URI present. Default controller set.
INFO - 2016-11-29 10:56:57 --> Router Class Initialized
INFO - 2016-11-29 10:56:57 --> Output Class Initialized
INFO - 2016-11-29 10:56:58 --> Security Class Initialized
DEBUG - 2016-11-29 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:56:58 --> Input Class Initialized
INFO - 2016-11-29 10:56:58 --> Language Class Initialized
INFO - 2016-11-29 10:56:58 --> Loader Class Initialized
INFO - 2016-11-29 10:56:58 --> Helper loaded: url_helper
INFO - 2016-11-29 10:56:58 --> Helper loaded: form_helper
INFO - 2016-11-29 10:56:58 --> Database Driver Class Initialized
INFO - 2016-11-29 10:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:56:59 --> Controller Class Initialized
INFO - 2016-11-29 10:56:59 --> Model Class Initialized
INFO - 2016-11-29 10:56:59 --> Model Class Initialized
INFO - 2016-11-29 10:56:59 --> Model Class Initialized
INFO - 2016-11-29 10:56:59 --> Model Class Initialized
INFO - 2016-11-29 10:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:56:59 --> Pagination Class Initialized
INFO - 2016-11-29 10:56:59 --> Helper loaded: app_helper
INFO - 2016-11-29 10:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 10:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:56:59 --> Final output sent to browser
DEBUG - 2016-11-29 10:56:59 --> Total execution time: 3.1733
INFO - 2016-11-29 10:57:04 --> Config Class Initialized
INFO - 2016-11-29 10:57:04 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:57:04 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:57:04 --> Utf8 Class Initialized
INFO - 2016-11-29 10:57:04 --> URI Class Initialized
DEBUG - 2016-11-29 10:57:04 --> No URI present. Default controller set.
INFO - 2016-11-29 10:57:04 --> Router Class Initialized
INFO - 2016-11-29 10:57:04 --> Output Class Initialized
INFO - 2016-11-29 10:57:04 --> Security Class Initialized
DEBUG - 2016-11-29 10:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:57:04 --> Input Class Initialized
INFO - 2016-11-29 10:57:04 --> Language Class Initialized
INFO - 2016-11-29 10:57:04 --> Loader Class Initialized
INFO - 2016-11-29 10:57:04 --> Helper loaded: url_helper
INFO - 2016-11-29 10:57:04 --> Helper loaded: form_helper
INFO - 2016-11-29 10:57:04 --> Database Driver Class Initialized
INFO - 2016-11-29 10:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:57:05 --> Controller Class Initialized
INFO - 2016-11-29 10:57:05 --> Model Class Initialized
INFO - 2016-11-29 10:57:05 --> Model Class Initialized
INFO - 2016-11-29 10:57:05 --> Model Class Initialized
INFO - 2016-11-29 10:57:05 --> Model Class Initialized
INFO - 2016-11-29 10:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:57:05 --> Pagination Class Initialized
INFO - 2016-11-29 10:57:05 --> Helper loaded: app_helper
INFO - 2016-11-29 10:57:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:57:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 10:57:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:57:05 --> Final output sent to browser
DEBUG - 2016-11-29 10:57:05 --> Total execution time: 0.7562
INFO - 2016-11-29 10:57:36 --> Config Class Initialized
INFO - 2016-11-29 10:57:36 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:57:36 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:57:36 --> Utf8 Class Initialized
INFO - 2016-11-29 10:57:36 --> URI Class Initialized
DEBUG - 2016-11-29 10:57:36 --> No URI present. Default controller set.
INFO - 2016-11-29 10:57:36 --> Router Class Initialized
INFO - 2016-11-29 10:57:36 --> Output Class Initialized
INFO - 2016-11-29 10:57:36 --> Security Class Initialized
DEBUG - 2016-11-29 10:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:57:37 --> Input Class Initialized
INFO - 2016-11-29 10:57:37 --> Language Class Initialized
INFO - 2016-11-29 10:57:37 --> Loader Class Initialized
INFO - 2016-11-29 10:57:37 --> Helper loaded: url_helper
INFO - 2016-11-29 10:57:37 --> Helper loaded: form_helper
INFO - 2016-11-29 10:57:37 --> Database Driver Class Initialized
INFO - 2016-11-29 10:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:57:37 --> Controller Class Initialized
INFO - 2016-11-29 10:57:37 --> Model Class Initialized
INFO - 2016-11-29 10:57:37 --> Model Class Initialized
INFO - 2016-11-29 10:57:37 --> Model Class Initialized
INFO - 2016-11-29 10:57:37 --> Model Class Initialized
INFO - 2016-11-29 10:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:57:37 --> Pagination Class Initialized
INFO - 2016-11-29 10:57:37 --> Helper loaded: app_helper
INFO - 2016-11-29 10:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 10:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:57:37 --> Final output sent to browser
DEBUG - 2016-11-29 10:57:37 --> Total execution time: 0.4590
INFO - 2016-11-29 10:57:52 --> Config Class Initialized
INFO - 2016-11-29 10:57:52 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:57:52 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:57:52 --> Utf8 Class Initialized
INFO - 2016-11-29 10:57:52 --> URI Class Initialized
INFO - 2016-11-29 10:57:52 --> Router Class Initialized
INFO - 2016-11-29 10:57:52 --> Output Class Initialized
INFO - 2016-11-29 10:57:52 --> Security Class Initialized
DEBUG - 2016-11-29 10:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:57:52 --> Input Class Initialized
INFO - 2016-11-29 10:57:52 --> Language Class Initialized
INFO - 2016-11-29 10:57:52 --> Loader Class Initialized
INFO - 2016-11-29 10:57:52 --> Helper loaded: url_helper
INFO - 2016-11-29 10:57:52 --> Helper loaded: form_helper
INFO - 2016-11-29 10:57:52 --> Database Driver Class Initialized
INFO - 2016-11-29 10:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:57:52 --> Controller Class Initialized
INFO - 2016-11-29 10:57:52 --> Model Class Initialized
INFO - 2016-11-29 10:57:52 --> Model Class Initialized
INFO - 2016-11-29 10:57:52 --> Model Class Initialized
INFO - 2016-11-29 10:57:52 --> Model Class Initialized
INFO - 2016-11-29 10:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:57:52 --> Pagination Class Initialized
INFO - 2016-11-29 10:57:52 --> Helper loaded: app_helper
DEBUG - 2016-11-29 10:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 10:57:52 --> Model Class Initialized
INFO - 2016-11-29 10:57:53 --> Final output sent to browser
DEBUG - 2016-11-29 10:57:53 --> Total execution time: 0.5610
INFO - 2016-11-29 10:57:53 --> Config Class Initialized
INFO - 2016-11-29 10:57:53 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:57:53 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:57:53 --> Utf8 Class Initialized
INFO - 2016-11-29 10:57:53 --> URI Class Initialized
DEBUG - 2016-11-29 10:57:53 --> No URI present. Default controller set.
INFO - 2016-11-29 10:57:53 --> Router Class Initialized
INFO - 2016-11-29 10:57:53 --> Output Class Initialized
INFO - 2016-11-29 10:57:53 --> Security Class Initialized
DEBUG - 2016-11-29 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:57:53 --> Input Class Initialized
INFO - 2016-11-29 10:57:53 --> Language Class Initialized
INFO - 2016-11-29 10:57:53 --> Loader Class Initialized
INFO - 2016-11-29 10:57:53 --> Helper loaded: url_helper
INFO - 2016-11-29 10:57:53 --> Helper loaded: form_helper
INFO - 2016-11-29 10:57:53 --> Database Driver Class Initialized
INFO - 2016-11-29 10:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:57:53 --> Controller Class Initialized
INFO - 2016-11-29 10:57:53 --> Model Class Initialized
INFO - 2016-11-29 10:57:53 --> Model Class Initialized
INFO - 2016-11-29 10:57:53 --> Model Class Initialized
INFO - 2016-11-29 10:57:53 --> Model Class Initialized
INFO - 2016-11-29 10:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:57:53 --> Pagination Class Initialized
INFO - 2016-11-29 10:57:53 --> Helper loaded: app_helper
INFO - 2016-11-29 10:57:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:57:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 10:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 10:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 10:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 10:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 10:57:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:57:54 --> Final output sent to browser
DEBUG - 2016-11-29 10:57:54 --> Total execution time: 1.2541
INFO - 2016-11-29 10:58:04 --> Config Class Initialized
INFO - 2016-11-29 10:58:04 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:04 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:04 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:04 --> URI Class Initialized
INFO - 2016-11-29 10:58:04 --> Router Class Initialized
INFO - 2016-11-29 10:58:04 --> Output Class Initialized
INFO - 2016-11-29 10:58:04 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:04 --> Input Class Initialized
INFO - 2016-11-29 10:58:04 --> Language Class Initialized
INFO - 2016-11-29 10:58:04 --> Loader Class Initialized
INFO - 2016-11-29 10:58:04 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:04 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:04 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:04 --> Controller Class Initialized
INFO - 2016-11-29 10:58:04 --> Model Class Initialized
INFO - 2016-11-29 10:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:04 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:04 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:58:04 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:04 --> Total execution time: 0.4064
INFO - 2016-11-29 10:58:08 --> Config Class Initialized
INFO - 2016-11-29 10:58:08 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:08 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:08 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:08 --> URI Class Initialized
INFO - 2016-11-29 10:58:08 --> Router Class Initialized
INFO - 2016-11-29 10:58:08 --> Output Class Initialized
INFO - 2016-11-29 10:58:08 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:08 --> Input Class Initialized
INFO - 2016-11-29 10:58:08 --> Language Class Initialized
INFO - 2016-11-29 10:58:08 --> Loader Class Initialized
INFO - 2016-11-29 10:58:08 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:08 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:08 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:08 --> Controller Class Initialized
INFO - 2016-11-29 10:58:08 --> Model Class Initialized
INFO - 2016-11-29 10:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:08 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:08 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:58:08 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:08 --> Total execution time: 0.2133
INFO - 2016-11-29 10:58:12 --> Config Class Initialized
INFO - 2016-11-29 10:58:12 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:12 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:12 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:12 --> URI Class Initialized
INFO - 2016-11-29 10:58:12 --> Router Class Initialized
INFO - 2016-11-29 10:58:12 --> Output Class Initialized
INFO - 2016-11-29 10:58:12 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:12 --> Input Class Initialized
INFO - 2016-11-29 10:58:12 --> Language Class Initialized
INFO - 2016-11-29 10:58:12 --> Loader Class Initialized
INFO - 2016-11-29 10:58:12 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:12 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:12 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:12 --> Controller Class Initialized
INFO - 2016-11-29 10:58:12 --> Model Class Initialized
INFO - 2016-11-29 10:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:12 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:12 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:58:12 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:12 --> Total execution time: 0.2584
INFO - 2016-11-29 10:58:16 --> Config Class Initialized
INFO - 2016-11-29 10:58:16 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:16 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:16 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:16 --> URI Class Initialized
INFO - 2016-11-29 10:58:16 --> Router Class Initialized
INFO - 2016-11-29 10:58:16 --> Output Class Initialized
INFO - 2016-11-29 10:58:16 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:16 --> Input Class Initialized
INFO - 2016-11-29 10:58:16 --> Language Class Initialized
INFO - 2016-11-29 10:58:16 --> Loader Class Initialized
INFO - 2016-11-29 10:58:16 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:16 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:16 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:16 --> Controller Class Initialized
INFO - 2016-11-29 10:58:16 --> Model Class Initialized
INFO - 2016-11-29 10:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:16 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:16 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:58:16 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:16 --> Total execution time: 0.3189
INFO - 2016-11-29 10:58:19 --> Config Class Initialized
INFO - 2016-11-29 10:58:19 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:19 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:19 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:19 --> URI Class Initialized
INFO - 2016-11-29 10:58:19 --> Router Class Initialized
INFO - 2016-11-29 10:58:19 --> Output Class Initialized
INFO - 2016-11-29 10:58:19 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:19 --> Input Class Initialized
INFO - 2016-11-29 10:58:19 --> Language Class Initialized
INFO - 2016-11-29 10:58:19 --> Loader Class Initialized
INFO - 2016-11-29 10:58:19 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:19 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:19 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:19 --> Controller Class Initialized
INFO - 2016-11-29 10:58:19 --> Model Class Initialized
INFO - 2016-11-29 10:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:19 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:19 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:19 --> Form Validation Class Initialized
INFO - 2016-11-29 10:58:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 10:58:19 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:19 --> Total execution time: 0.2703
INFO - 2016-11-29 10:58:21 --> Config Class Initialized
INFO - 2016-11-29 10:58:21 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:21 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:21 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:21 --> URI Class Initialized
DEBUG - 2016-11-29 10:58:21 --> No URI present. Default controller set.
INFO - 2016-11-29 10:58:21 --> Router Class Initialized
INFO - 2016-11-29 10:58:21 --> Output Class Initialized
INFO - 2016-11-29 10:58:21 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:21 --> Input Class Initialized
INFO - 2016-11-29 10:58:21 --> Language Class Initialized
INFO - 2016-11-29 10:58:21 --> Loader Class Initialized
INFO - 2016-11-29 10:58:21 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:21 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:21 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:21 --> Controller Class Initialized
INFO - 2016-11-29 10:58:21 --> Model Class Initialized
INFO - 2016-11-29 10:58:21 --> Model Class Initialized
INFO - 2016-11-29 10:58:21 --> Model Class Initialized
INFO - 2016-11-29 10:58:21 --> Model Class Initialized
INFO - 2016-11-29 10:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:21 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:21 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 10:58:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:58:21 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:21 --> Total execution time: 0.4064
INFO - 2016-11-29 10:58:48 --> Config Class Initialized
INFO - 2016-11-29 10:58:48 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:58:48 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:58:48 --> Utf8 Class Initialized
INFO - 2016-11-29 10:58:48 --> URI Class Initialized
DEBUG - 2016-11-29 10:58:48 --> No URI present. Default controller set.
INFO - 2016-11-29 10:58:48 --> Router Class Initialized
INFO - 2016-11-29 10:58:48 --> Output Class Initialized
INFO - 2016-11-29 10:58:48 --> Security Class Initialized
DEBUG - 2016-11-29 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:58:48 --> Input Class Initialized
INFO - 2016-11-29 10:58:48 --> Language Class Initialized
INFO - 2016-11-29 10:58:48 --> Loader Class Initialized
INFO - 2016-11-29 10:58:48 --> Helper loaded: url_helper
INFO - 2016-11-29 10:58:48 --> Helper loaded: form_helper
INFO - 2016-11-29 10:58:48 --> Database Driver Class Initialized
INFO - 2016-11-29 10:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:58:48 --> Controller Class Initialized
INFO - 2016-11-29 10:58:48 --> Model Class Initialized
INFO - 2016-11-29 10:58:48 --> Model Class Initialized
INFO - 2016-11-29 10:58:48 --> Model Class Initialized
INFO - 2016-11-29 10:58:48 --> Model Class Initialized
INFO - 2016-11-29 10:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:58:48 --> Pagination Class Initialized
INFO - 2016-11-29 10:58:48 --> Helper loaded: app_helper
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 10:58:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:58:48 --> Final output sent to browser
DEBUG - 2016-11-29 10:58:48 --> Total execution time: 0.3402
INFO - 2016-11-29 10:59:05 --> Config Class Initialized
INFO - 2016-11-29 10:59:05 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:59:05 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:59:05 --> Utf8 Class Initialized
INFO - 2016-11-29 10:59:05 --> URI Class Initialized
INFO - 2016-11-29 10:59:05 --> Router Class Initialized
INFO - 2016-11-29 10:59:05 --> Output Class Initialized
INFO - 2016-11-29 10:59:05 --> Security Class Initialized
DEBUG - 2016-11-29 10:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:59:06 --> Input Class Initialized
INFO - 2016-11-29 10:59:06 --> Language Class Initialized
INFO - 2016-11-29 10:59:06 --> Loader Class Initialized
INFO - 2016-11-29 10:59:06 --> Helper loaded: url_helper
INFO - 2016-11-29 10:59:06 --> Helper loaded: form_helper
INFO - 2016-11-29 10:59:06 --> Database Driver Class Initialized
INFO - 2016-11-29 10:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:59:06 --> Controller Class Initialized
INFO - 2016-11-29 10:59:06 --> Model Class Initialized
INFO - 2016-11-29 10:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:59:06 --> Pagination Class Initialized
INFO - 2016-11-29 10:59:06 --> Helper loaded: app_helper
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:59:06 --> Final output sent to browser
DEBUG - 2016-11-29 10:59:06 --> Total execution time: 0.3788
INFO - 2016-11-29 10:59:06 --> Config Class Initialized
INFO - 2016-11-29 10:59:06 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:59:06 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:59:06 --> Utf8 Class Initialized
INFO - 2016-11-29 10:59:06 --> URI Class Initialized
DEBUG - 2016-11-29 10:59:06 --> No URI present. Default controller set.
INFO - 2016-11-29 10:59:06 --> Router Class Initialized
INFO - 2016-11-29 10:59:06 --> Output Class Initialized
INFO - 2016-11-29 10:59:06 --> Security Class Initialized
DEBUG - 2016-11-29 10:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:59:06 --> Input Class Initialized
INFO - 2016-11-29 10:59:06 --> Language Class Initialized
INFO - 2016-11-29 10:59:06 --> Loader Class Initialized
INFO - 2016-11-29 10:59:06 --> Helper loaded: url_helper
INFO - 2016-11-29 10:59:06 --> Helper loaded: form_helper
INFO - 2016-11-29 10:59:06 --> Database Driver Class Initialized
INFO - 2016-11-29 10:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:59:06 --> Controller Class Initialized
INFO - 2016-11-29 10:59:06 --> Model Class Initialized
INFO - 2016-11-29 10:59:06 --> Model Class Initialized
INFO - 2016-11-29 10:59:06 --> Model Class Initialized
INFO - 2016-11-29 10:59:06 --> Model Class Initialized
INFO - 2016-11-29 10:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:59:06 --> Pagination Class Initialized
INFO - 2016-11-29 10:59:06 --> Helper loaded: app_helper
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 10:59:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 10:59:06 --> Final output sent to browser
DEBUG - 2016-11-29 10:59:06 --> Total execution time: 0.3787
INFO - 2016-11-29 10:59:19 --> Config Class Initialized
INFO - 2016-11-29 10:59:19 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:59:19 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:59:19 --> Utf8 Class Initialized
INFO - 2016-11-29 10:59:19 --> URI Class Initialized
INFO - 2016-11-29 10:59:19 --> Router Class Initialized
INFO - 2016-11-29 10:59:19 --> Output Class Initialized
INFO - 2016-11-29 10:59:19 --> Security Class Initialized
DEBUG - 2016-11-29 10:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:59:19 --> Input Class Initialized
INFO - 2016-11-29 10:59:19 --> Language Class Initialized
INFO - 2016-11-29 10:59:19 --> Loader Class Initialized
INFO - 2016-11-29 10:59:19 --> Helper loaded: url_helper
INFO - 2016-11-29 10:59:19 --> Helper loaded: form_helper
INFO - 2016-11-29 10:59:19 --> Database Driver Class Initialized
INFO - 2016-11-29 10:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:59:19 --> Controller Class Initialized
INFO - 2016-11-29 10:59:19 --> Model Class Initialized
INFO - 2016-11-29 10:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:59:19 --> Pagination Class Initialized
INFO - 2016-11-29 10:59:19 --> Helper loaded: app_helper
INFO - 2016-11-29 10:59:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:59:19 --> Final output sent to browser
DEBUG - 2016-11-29 10:59:19 --> Total execution time: 0.2012
INFO - 2016-11-29 10:59:23 --> Config Class Initialized
INFO - 2016-11-29 10:59:23 --> Hooks Class Initialized
DEBUG - 2016-11-29 10:59:23 --> UTF-8 Support Enabled
INFO - 2016-11-29 10:59:23 --> Utf8 Class Initialized
INFO - 2016-11-29 10:59:23 --> URI Class Initialized
INFO - 2016-11-29 10:59:23 --> Router Class Initialized
INFO - 2016-11-29 10:59:23 --> Output Class Initialized
INFO - 2016-11-29 10:59:23 --> Security Class Initialized
DEBUG - 2016-11-29 10:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 10:59:23 --> Input Class Initialized
INFO - 2016-11-29 10:59:23 --> Language Class Initialized
INFO - 2016-11-29 10:59:23 --> Loader Class Initialized
INFO - 2016-11-29 10:59:23 --> Helper loaded: url_helper
INFO - 2016-11-29 10:59:23 --> Helper loaded: form_helper
INFO - 2016-11-29 10:59:23 --> Database Driver Class Initialized
INFO - 2016-11-29 10:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 10:59:23 --> Controller Class Initialized
INFO - 2016-11-29 10:59:23 --> Model Class Initialized
INFO - 2016-11-29 10:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 10:59:23 --> Pagination Class Initialized
INFO - 2016-11-29 10:59:23 --> Helper loaded: app_helper
INFO - 2016-11-29 10:59:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 10:59:23 --> Final output sent to browser
DEBUG - 2016-11-29 10:59:23 --> Total execution time: 0.3083
INFO - 2016-11-29 11:00:18 --> Config Class Initialized
INFO - 2016-11-29 11:00:18 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:00:18 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:00:18 --> Utf8 Class Initialized
INFO - 2016-11-29 11:00:18 --> URI Class Initialized
INFO - 2016-11-29 11:00:18 --> Router Class Initialized
INFO - 2016-11-29 11:00:18 --> Output Class Initialized
INFO - 2016-11-29 11:00:18 --> Security Class Initialized
DEBUG - 2016-11-29 11:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:00:18 --> Input Class Initialized
INFO - 2016-11-29 11:00:18 --> Language Class Initialized
INFO - 2016-11-29 11:00:18 --> Loader Class Initialized
INFO - 2016-11-29 11:00:18 --> Helper loaded: url_helper
INFO - 2016-11-29 11:00:18 --> Helper loaded: form_helper
INFO - 2016-11-29 11:00:18 --> Database Driver Class Initialized
INFO - 2016-11-29 11:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:00:18 --> Controller Class Initialized
INFO - 2016-11-29 11:00:18 --> Model Class Initialized
INFO - 2016-11-29 11:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:00:18 --> Pagination Class Initialized
INFO - 2016-11-29 11:00:18 --> Helper loaded: app_helper
INFO - 2016-11-29 11:00:18 --> Form Validation Class Initialized
INFO - 2016-11-29 11:00:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:00:18 --> Final output sent to browser
DEBUG - 2016-11-29 11:00:18 --> Total execution time: 0.2539
INFO - 2016-11-29 11:00:20 --> Config Class Initialized
INFO - 2016-11-29 11:00:20 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:00:20 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:00:20 --> Utf8 Class Initialized
INFO - 2016-11-29 11:00:20 --> URI Class Initialized
DEBUG - 2016-11-29 11:00:20 --> No URI present. Default controller set.
INFO - 2016-11-29 11:00:20 --> Router Class Initialized
INFO - 2016-11-29 11:00:20 --> Output Class Initialized
INFO - 2016-11-29 11:00:20 --> Security Class Initialized
DEBUG - 2016-11-29 11:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:00:20 --> Input Class Initialized
INFO - 2016-11-29 11:00:20 --> Language Class Initialized
INFO - 2016-11-29 11:00:20 --> Loader Class Initialized
INFO - 2016-11-29 11:00:20 --> Helper loaded: url_helper
INFO - 2016-11-29 11:00:20 --> Helper loaded: form_helper
INFO - 2016-11-29 11:00:20 --> Database Driver Class Initialized
INFO - 2016-11-29 11:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:00:20 --> Controller Class Initialized
INFO - 2016-11-29 11:00:20 --> Model Class Initialized
INFO - 2016-11-29 11:00:20 --> Model Class Initialized
INFO - 2016-11-29 11:00:20 --> Model Class Initialized
INFO - 2016-11-29 11:00:20 --> Model Class Initialized
INFO - 2016-11-29 11:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:00:20 --> Pagination Class Initialized
INFO - 2016-11-29 11:00:20 --> Helper loaded: app_helper
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:00:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:00:21 --> Final output sent to browser
DEBUG - 2016-11-29 11:00:21 --> Total execution time: 0.4796
INFO - 2016-11-29 11:01:12 --> Config Class Initialized
INFO - 2016-11-29 11:01:12 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:01:12 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:01:12 --> Utf8 Class Initialized
INFO - 2016-11-29 11:01:12 --> URI Class Initialized
DEBUG - 2016-11-29 11:01:12 --> No URI present. Default controller set.
INFO - 2016-11-29 11:01:12 --> Router Class Initialized
INFO - 2016-11-29 11:01:12 --> Output Class Initialized
INFO - 2016-11-29 11:01:12 --> Security Class Initialized
DEBUG - 2016-11-29 11:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:01:12 --> Input Class Initialized
INFO - 2016-11-29 11:01:12 --> Language Class Initialized
INFO - 2016-11-29 11:01:12 --> Loader Class Initialized
INFO - 2016-11-29 11:01:12 --> Helper loaded: url_helper
INFO - 2016-11-29 11:01:12 --> Helper loaded: form_helper
INFO - 2016-11-29 11:01:12 --> Database Driver Class Initialized
INFO - 2016-11-29 11:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:01:12 --> Controller Class Initialized
INFO - 2016-11-29 11:01:12 --> Model Class Initialized
INFO - 2016-11-29 11:01:12 --> Model Class Initialized
INFO - 2016-11-29 11:01:12 --> Model Class Initialized
INFO - 2016-11-29 11:01:12 --> Model Class Initialized
INFO - 2016-11-29 11:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:01:12 --> Pagination Class Initialized
INFO - 2016-11-29 11:01:12 --> Helper loaded: app_helper
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:01:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:01:12 --> Final output sent to browser
DEBUG - 2016-11-29 11:01:12 --> Total execution time: 0.3573
INFO - 2016-11-29 11:01:22 --> Config Class Initialized
INFO - 2016-11-29 11:01:22 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:01:22 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:01:22 --> Utf8 Class Initialized
INFO - 2016-11-29 11:01:22 --> URI Class Initialized
INFO - 2016-11-29 11:01:22 --> Router Class Initialized
INFO - 2016-11-29 11:01:22 --> Output Class Initialized
INFO - 2016-11-29 11:01:22 --> Security Class Initialized
DEBUG - 2016-11-29 11:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:01:22 --> Input Class Initialized
INFO - 2016-11-29 11:01:22 --> Language Class Initialized
INFO - 2016-11-29 11:01:22 --> Loader Class Initialized
INFO - 2016-11-29 11:01:22 --> Helper loaded: url_helper
INFO - 2016-11-29 11:01:22 --> Helper loaded: form_helper
INFO - 2016-11-29 11:01:22 --> Database Driver Class Initialized
INFO - 2016-11-29 11:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:01:22 --> Controller Class Initialized
INFO - 2016-11-29 11:01:22 --> Model Class Initialized
INFO - 2016-11-29 11:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:01:22 --> Pagination Class Initialized
INFO - 2016-11-29 11:01:22 --> Helper loaded: app_helper
INFO - 2016-11-29 11:01:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:01:22 --> Final output sent to browser
DEBUG - 2016-11-29 11:01:22 --> Total execution time: 0.3168
INFO - 2016-11-29 11:01:33 --> Config Class Initialized
INFO - 2016-11-29 11:01:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:01:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:01:33 --> Utf8 Class Initialized
INFO - 2016-11-29 11:01:33 --> URI Class Initialized
DEBUG - 2016-11-29 11:01:33 --> No URI present. Default controller set.
INFO - 2016-11-29 11:01:33 --> Router Class Initialized
INFO - 2016-11-29 11:01:33 --> Output Class Initialized
INFO - 2016-11-29 11:01:33 --> Security Class Initialized
DEBUG - 2016-11-29 11:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:01:33 --> Input Class Initialized
INFO - 2016-11-29 11:01:33 --> Language Class Initialized
INFO - 2016-11-29 11:01:33 --> Loader Class Initialized
INFO - 2016-11-29 11:01:33 --> Helper loaded: url_helper
INFO - 2016-11-29 11:01:33 --> Helper loaded: form_helper
INFO - 2016-11-29 11:01:33 --> Database Driver Class Initialized
INFO - 2016-11-29 11:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:01:33 --> Controller Class Initialized
INFO - 2016-11-29 11:01:33 --> Model Class Initialized
INFO - 2016-11-29 11:01:33 --> Model Class Initialized
INFO - 2016-11-29 11:01:33 --> Model Class Initialized
INFO - 2016-11-29 11:01:33 --> Model Class Initialized
INFO - 2016-11-29 11:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:01:34 --> Pagination Class Initialized
INFO - 2016-11-29 11:01:34 --> Helper loaded: app_helper
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:01:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:01:34 --> Final output sent to browser
DEBUG - 2016-11-29 11:01:34 --> Total execution time: 0.3778
INFO - 2016-11-29 11:02:07 --> Config Class Initialized
INFO - 2016-11-29 11:02:07 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:02:07 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:02:07 --> Utf8 Class Initialized
INFO - 2016-11-29 11:02:07 --> URI Class Initialized
INFO - 2016-11-29 11:02:07 --> Router Class Initialized
INFO - 2016-11-29 11:02:07 --> Output Class Initialized
INFO - 2016-11-29 11:02:07 --> Security Class Initialized
DEBUG - 2016-11-29 11:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:02:07 --> Input Class Initialized
INFO - 2016-11-29 11:02:07 --> Language Class Initialized
INFO - 2016-11-29 11:02:07 --> Loader Class Initialized
INFO - 2016-11-29 11:02:07 --> Helper loaded: url_helper
INFO - 2016-11-29 11:02:07 --> Helper loaded: form_helper
INFO - 2016-11-29 11:02:07 --> Database Driver Class Initialized
INFO - 2016-11-29 11:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:02:07 --> Controller Class Initialized
INFO - 2016-11-29 11:02:07 --> Model Class Initialized
INFO - 2016-11-29 11:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:02:08 --> Pagination Class Initialized
INFO - 2016-11-29 11:02:08 --> Helper loaded: app_helper
INFO - 2016-11-29 11:02:08 --> Form Validation Class Initialized
INFO - 2016-11-29 11:02:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:02:08 --> Final output sent to browser
DEBUG - 2016-11-29 11:02:08 --> Total execution time: 0.3678
INFO - 2016-11-29 11:02:13 --> Config Class Initialized
INFO - 2016-11-29 11:02:13 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:02:13 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:02:13 --> Utf8 Class Initialized
INFO - 2016-11-29 11:02:13 --> URI Class Initialized
INFO - 2016-11-29 11:02:13 --> Router Class Initialized
INFO - 2016-11-29 11:02:13 --> Output Class Initialized
INFO - 2016-11-29 11:02:13 --> Security Class Initialized
DEBUG - 2016-11-29 11:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:02:13 --> Input Class Initialized
INFO - 2016-11-29 11:02:13 --> Language Class Initialized
INFO - 2016-11-29 11:02:13 --> Loader Class Initialized
INFO - 2016-11-29 11:02:13 --> Helper loaded: url_helper
INFO - 2016-11-29 11:02:13 --> Helper loaded: form_helper
INFO - 2016-11-29 11:02:13 --> Database Driver Class Initialized
INFO - 2016-11-29 11:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:02:13 --> Controller Class Initialized
INFO - 2016-11-29 11:02:13 --> Model Class Initialized
INFO - 2016-11-29 11:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:02:13 --> Pagination Class Initialized
INFO - 2016-11-29 11:02:13 --> Helper loaded: app_helper
INFO - 2016-11-29 11:02:13 --> Form Validation Class Initialized
INFO - 2016-11-29 11:02:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:02:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:02:14 --> Final output sent to browser
DEBUG - 2016-11-29 11:02:14 --> Total execution time: 0.3623
INFO - 2016-11-29 11:02:59 --> Config Class Initialized
INFO - 2016-11-29 11:02:59 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:02:59 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:02:59 --> Utf8 Class Initialized
INFO - 2016-11-29 11:02:59 --> URI Class Initialized
INFO - 2016-11-29 11:02:59 --> Router Class Initialized
INFO - 2016-11-29 11:02:59 --> Output Class Initialized
INFO - 2016-11-29 11:02:59 --> Security Class Initialized
DEBUG - 2016-11-29 11:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:02:59 --> Input Class Initialized
INFO - 2016-11-29 11:02:59 --> Language Class Initialized
INFO - 2016-11-29 11:02:59 --> Loader Class Initialized
INFO - 2016-11-29 11:02:59 --> Helper loaded: url_helper
INFO - 2016-11-29 11:02:59 --> Helper loaded: form_helper
INFO - 2016-11-29 11:02:59 --> Database Driver Class Initialized
INFO - 2016-11-29 11:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:02:59 --> Controller Class Initialized
INFO - 2016-11-29 11:02:59 --> Model Class Initialized
INFO - 2016-11-29 11:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:02:59 --> Pagination Class Initialized
INFO - 2016-11-29 11:02:59 --> Helper loaded: app_helper
INFO - 2016-11-29 11:02:59 --> Form Validation Class Initialized
INFO - 2016-11-29 11:02:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:02:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:02:59 --> Final output sent to browser
DEBUG - 2016-11-29 11:02:59 --> Total execution time: 0.3836
INFO - 2016-11-29 11:03:55 --> Config Class Initialized
INFO - 2016-11-29 11:03:55 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:03:55 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:03:55 --> Utf8 Class Initialized
INFO - 2016-11-29 11:03:55 --> URI Class Initialized
DEBUG - 2016-11-29 11:03:55 --> No URI present. Default controller set.
INFO - 2016-11-29 11:03:55 --> Router Class Initialized
INFO - 2016-11-29 11:03:55 --> Output Class Initialized
INFO - 2016-11-29 11:03:55 --> Security Class Initialized
DEBUG - 2016-11-29 11:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:03:55 --> Input Class Initialized
INFO - 2016-11-29 11:03:55 --> Language Class Initialized
INFO - 2016-11-29 11:03:55 --> Loader Class Initialized
INFO - 2016-11-29 11:03:55 --> Helper loaded: url_helper
INFO - 2016-11-29 11:03:55 --> Helper loaded: form_helper
INFO - 2016-11-29 11:03:55 --> Database Driver Class Initialized
INFO - 2016-11-29 11:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:03:55 --> Controller Class Initialized
INFO - 2016-11-29 11:03:55 --> Model Class Initialized
INFO - 2016-11-29 11:03:55 --> Model Class Initialized
INFO - 2016-11-29 11:03:55 --> Model Class Initialized
INFO - 2016-11-29 11:03:56 --> Model Class Initialized
INFO - 2016-11-29 11:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:03:56 --> Pagination Class Initialized
INFO - 2016-11-29 11:03:56 --> Helper loaded: app_helper
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:03:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:03:56 --> Final output sent to browser
DEBUG - 2016-11-29 11:03:56 --> Total execution time: 0.5815
INFO - 2016-11-29 11:03:59 --> Config Class Initialized
INFO - 2016-11-29 11:03:59 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:03:59 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:03:59 --> Utf8 Class Initialized
INFO - 2016-11-29 11:03:59 --> URI Class Initialized
INFO - 2016-11-29 11:03:59 --> Router Class Initialized
INFO - 2016-11-29 11:03:59 --> Output Class Initialized
INFO - 2016-11-29 11:03:59 --> Security Class Initialized
DEBUG - 2016-11-29 11:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:03:59 --> Input Class Initialized
INFO - 2016-11-29 11:03:59 --> Language Class Initialized
INFO - 2016-11-29 11:03:59 --> Loader Class Initialized
INFO - 2016-11-29 11:03:59 --> Helper loaded: url_helper
INFO - 2016-11-29 11:03:59 --> Helper loaded: form_helper
INFO - 2016-11-29 11:03:59 --> Database Driver Class Initialized
INFO - 2016-11-29 11:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:03:59 --> Controller Class Initialized
INFO - 2016-11-29 11:03:59 --> Model Class Initialized
INFO - 2016-11-29 11:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:03:59 --> Pagination Class Initialized
INFO - 2016-11-29 11:03:59 --> Helper loaded: app_helper
INFO - 2016-11-29 11:03:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:03:59 --> Final output sent to browser
DEBUG - 2016-11-29 11:03:59 --> Total execution time: 0.2374
INFO - 2016-11-29 11:04:09 --> Config Class Initialized
INFO - 2016-11-29 11:04:09 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:04:09 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:04:09 --> Utf8 Class Initialized
INFO - 2016-11-29 11:04:09 --> URI Class Initialized
INFO - 2016-11-29 11:04:09 --> Router Class Initialized
INFO - 2016-11-29 11:04:09 --> Output Class Initialized
INFO - 2016-11-29 11:04:09 --> Security Class Initialized
DEBUG - 2016-11-29 11:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:04:09 --> Input Class Initialized
INFO - 2016-11-29 11:04:09 --> Language Class Initialized
INFO - 2016-11-29 11:04:09 --> Loader Class Initialized
INFO - 2016-11-29 11:04:09 --> Helper loaded: url_helper
INFO - 2016-11-29 11:04:09 --> Helper loaded: form_helper
INFO - 2016-11-29 11:04:09 --> Database Driver Class Initialized
INFO - 2016-11-29 11:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:04:09 --> Controller Class Initialized
INFO - 2016-11-29 11:04:09 --> Model Class Initialized
INFO - 2016-11-29 11:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:04:09 --> Pagination Class Initialized
INFO - 2016-11-29 11:04:09 --> Helper loaded: app_helper
INFO - 2016-11-29 11:04:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:04:10 --> Final output sent to browser
DEBUG - 2016-11-29 11:04:10 --> Total execution time: 0.4688
INFO - 2016-11-29 11:04:13 --> Config Class Initialized
INFO - 2016-11-29 11:04:13 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:04:13 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:04:13 --> Utf8 Class Initialized
INFO - 2016-11-29 11:04:13 --> URI Class Initialized
INFO - 2016-11-29 11:04:13 --> Router Class Initialized
INFO - 2016-11-29 11:04:13 --> Output Class Initialized
INFO - 2016-11-29 11:04:13 --> Security Class Initialized
DEBUG - 2016-11-29 11:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:04:13 --> Input Class Initialized
INFO - 2016-11-29 11:04:13 --> Language Class Initialized
INFO - 2016-11-29 11:04:13 --> Loader Class Initialized
INFO - 2016-11-29 11:04:13 --> Helper loaded: url_helper
INFO - 2016-11-29 11:04:13 --> Helper loaded: form_helper
INFO - 2016-11-29 11:04:13 --> Database Driver Class Initialized
INFO - 2016-11-29 11:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:04:13 --> Controller Class Initialized
INFO - 2016-11-29 11:04:13 --> Model Class Initialized
INFO - 2016-11-29 11:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:04:13 --> Pagination Class Initialized
INFO - 2016-11-29 11:04:14 --> Helper loaded: app_helper
INFO - 2016-11-29 11:04:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:04:14 --> Final output sent to browser
DEBUG - 2016-11-29 11:04:14 --> Total execution time: 0.2630
INFO - 2016-11-29 11:05:30 --> Config Class Initialized
INFO - 2016-11-29 11:05:30 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:05:30 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:05:30 --> Utf8 Class Initialized
INFO - 2016-11-29 11:05:30 --> URI Class Initialized
DEBUG - 2016-11-29 11:05:30 --> No URI present. Default controller set.
INFO - 2016-11-29 11:05:30 --> Router Class Initialized
INFO - 2016-11-29 11:05:30 --> Output Class Initialized
INFO - 2016-11-29 11:05:30 --> Security Class Initialized
DEBUG - 2016-11-29 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:05:30 --> Input Class Initialized
INFO - 2016-11-29 11:05:31 --> Language Class Initialized
INFO - 2016-11-29 11:05:31 --> Loader Class Initialized
INFO - 2016-11-29 11:05:31 --> Helper loaded: url_helper
INFO - 2016-11-29 11:05:31 --> Helper loaded: form_helper
INFO - 2016-11-29 11:05:31 --> Database Driver Class Initialized
INFO - 2016-11-29 11:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:05:32 --> Controller Class Initialized
INFO - 2016-11-29 11:05:32 --> Model Class Initialized
INFO - 2016-11-29 11:05:32 --> Model Class Initialized
INFO - 2016-11-29 11:05:32 --> Model Class Initialized
INFO - 2016-11-29 11:05:32 --> Model Class Initialized
INFO - 2016-11-29 11:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:05:32 --> Pagination Class Initialized
INFO - 2016-11-29 11:05:32 --> Helper loaded: app_helper
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:05:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:05:32 --> Final output sent to browser
DEBUG - 2016-11-29 11:05:32 --> Total execution time: 2.5874
INFO - 2016-11-29 11:05:45 --> Config Class Initialized
INFO - 2016-11-29 11:05:45 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:05:45 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:05:45 --> Utf8 Class Initialized
INFO - 2016-11-29 11:05:45 --> URI Class Initialized
INFO - 2016-11-29 11:05:45 --> Router Class Initialized
INFO - 2016-11-29 11:05:45 --> Output Class Initialized
INFO - 2016-11-29 11:05:45 --> Security Class Initialized
DEBUG - 2016-11-29 11:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:05:45 --> Input Class Initialized
INFO - 2016-11-29 11:05:45 --> Language Class Initialized
INFO - 2016-11-29 11:05:45 --> Loader Class Initialized
INFO - 2016-11-29 11:05:45 --> Helper loaded: url_helper
INFO - 2016-11-29 11:05:45 --> Helper loaded: form_helper
INFO - 2016-11-29 11:05:45 --> Database Driver Class Initialized
INFO - 2016-11-29 11:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:05:45 --> Controller Class Initialized
INFO - 2016-11-29 11:05:45 --> Model Class Initialized
INFO - 2016-11-29 11:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:05:45 --> Pagination Class Initialized
INFO - 2016-11-29 11:05:45 --> Helper loaded: app_helper
INFO - 2016-11-29 11:05:45 --> Form Validation Class Initialized
INFO - 2016-11-29 11:05:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:05:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:05:45 --> Final output sent to browser
DEBUG - 2016-11-29 11:05:45 --> Total execution time: 0.4342
INFO - 2016-11-29 11:06:14 --> Config Class Initialized
INFO - 2016-11-29 11:06:14 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:06:14 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:06:14 --> Utf8 Class Initialized
INFO - 2016-11-29 11:06:14 --> URI Class Initialized
INFO - 2016-11-29 11:06:14 --> Router Class Initialized
INFO - 2016-11-29 11:06:14 --> Output Class Initialized
INFO - 2016-11-29 11:06:14 --> Security Class Initialized
DEBUG - 2016-11-29 11:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:06:14 --> Input Class Initialized
INFO - 2016-11-29 11:06:14 --> Language Class Initialized
INFO - 2016-11-29 11:06:14 --> Loader Class Initialized
INFO - 2016-11-29 11:06:14 --> Helper loaded: url_helper
INFO - 2016-11-29 11:06:14 --> Helper loaded: form_helper
INFO - 2016-11-29 11:06:14 --> Database Driver Class Initialized
INFO - 2016-11-29 11:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:06:14 --> Controller Class Initialized
INFO - 2016-11-29 11:06:14 --> Model Class Initialized
INFO - 2016-11-29 11:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:06:14 --> Pagination Class Initialized
INFO - 2016-11-29 11:06:14 --> Helper loaded: app_helper
INFO - 2016-11-29 11:06:14 --> Form Validation Class Initialized
INFO - 2016-11-29 11:06:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:06:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:06:14 --> Final output sent to browser
DEBUG - 2016-11-29 11:06:14 --> Total execution time: 0.4292
INFO - 2016-11-29 11:07:46 --> Config Class Initialized
INFO - 2016-11-29 11:07:46 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:07:46 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:07:46 --> Utf8 Class Initialized
INFO - 2016-11-29 11:07:46 --> URI Class Initialized
DEBUG - 2016-11-29 11:07:46 --> No URI present. Default controller set.
INFO - 2016-11-29 11:07:46 --> Router Class Initialized
INFO - 2016-11-29 11:07:46 --> Output Class Initialized
INFO - 2016-11-29 11:07:46 --> Security Class Initialized
DEBUG - 2016-11-29 11:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:07:46 --> Input Class Initialized
INFO - 2016-11-29 11:07:46 --> Language Class Initialized
INFO - 2016-11-29 11:07:46 --> Loader Class Initialized
INFO - 2016-11-29 11:07:46 --> Helper loaded: url_helper
INFO - 2016-11-29 11:07:46 --> Helper loaded: form_helper
INFO - 2016-11-29 11:07:47 --> Database Driver Class Initialized
INFO - 2016-11-29 11:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:07:47 --> Controller Class Initialized
INFO - 2016-11-29 11:07:47 --> Model Class Initialized
INFO - 2016-11-29 11:07:47 --> Model Class Initialized
INFO - 2016-11-29 11:07:47 --> Model Class Initialized
INFO - 2016-11-29 11:07:47 --> Model Class Initialized
INFO - 2016-11-29 11:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:07:47 --> Pagination Class Initialized
INFO - 2016-11-29 11:07:47 --> Helper loaded: app_helper
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:07:47 --> Final output sent to browser
DEBUG - 2016-11-29 11:07:47 --> Total execution time: 0.3774
INFO - 2016-11-29 11:08:03 --> Config Class Initialized
INFO - 2016-11-29 11:08:03 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:08:03 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:08:03 --> Utf8 Class Initialized
INFO - 2016-11-29 11:08:03 --> URI Class Initialized
INFO - 2016-11-29 11:08:03 --> Router Class Initialized
INFO - 2016-11-29 11:08:03 --> Output Class Initialized
INFO - 2016-11-29 11:08:03 --> Security Class Initialized
DEBUG - 2016-11-29 11:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:08:03 --> Input Class Initialized
INFO - 2016-11-29 11:08:03 --> Language Class Initialized
INFO - 2016-11-29 11:08:03 --> Loader Class Initialized
INFO - 2016-11-29 11:08:03 --> Helper loaded: url_helper
INFO - 2016-11-29 11:08:04 --> Helper loaded: form_helper
INFO - 2016-11-29 11:08:04 --> Database Driver Class Initialized
INFO - 2016-11-29 11:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:08:04 --> Controller Class Initialized
INFO - 2016-11-29 11:08:04 --> Model Class Initialized
INFO - 2016-11-29 11:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:08:04 --> Pagination Class Initialized
INFO - 2016-11-29 11:08:04 --> Helper loaded: app_helper
INFO - 2016-11-29 11:08:04 --> Form Validation Class Initialized
INFO - 2016-11-29 11:08:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:08:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:08:04 --> Final output sent to browser
DEBUG - 2016-11-29 11:08:04 --> Total execution time: 0.4903
INFO - 2016-11-29 11:08:43 --> Config Class Initialized
INFO - 2016-11-29 11:08:43 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:08:43 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:08:43 --> Utf8 Class Initialized
INFO - 2016-11-29 11:08:43 --> URI Class Initialized
DEBUG - 2016-11-29 11:08:43 --> No URI present. Default controller set.
INFO - 2016-11-29 11:08:43 --> Router Class Initialized
INFO - 2016-11-29 11:08:43 --> Output Class Initialized
INFO - 2016-11-29 11:08:43 --> Security Class Initialized
DEBUG - 2016-11-29 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:08:43 --> Input Class Initialized
INFO - 2016-11-29 11:08:43 --> Language Class Initialized
INFO - 2016-11-29 11:08:43 --> Loader Class Initialized
INFO - 2016-11-29 11:08:43 --> Helper loaded: url_helper
INFO - 2016-11-29 11:08:43 --> Helper loaded: form_helper
INFO - 2016-11-29 11:08:43 --> Database Driver Class Initialized
INFO - 2016-11-29 11:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:08:43 --> Controller Class Initialized
INFO - 2016-11-29 11:08:43 --> Model Class Initialized
INFO - 2016-11-29 11:08:43 --> Model Class Initialized
INFO - 2016-11-29 11:08:43 --> Model Class Initialized
INFO - 2016-11-29 11:08:43 --> Model Class Initialized
INFO - 2016-11-29 11:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:08:43 --> Pagination Class Initialized
INFO - 2016-11-29 11:08:43 --> Helper loaded: app_helper
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:08:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:08:43 --> Final output sent to browser
DEBUG - 2016-11-29 11:08:43 --> Total execution time: 0.4397
INFO - 2016-11-29 11:08:57 --> Config Class Initialized
INFO - 2016-11-29 11:08:57 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:08:57 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:08:57 --> Utf8 Class Initialized
INFO - 2016-11-29 11:08:57 --> URI Class Initialized
INFO - 2016-11-29 11:08:57 --> Router Class Initialized
INFO - 2016-11-29 11:08:57 --> Output Class Initialized
INFO - 2016-11-29 11:08:57 --> Security Class Initialized
DEBUG - 2016-11-29 11:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:08:57 --> Input Class Initialized
INFO - 2016-11-29 11:08:57 --> Language Class Initialized
INFO - 2016-11-29 11:08:57 --> Loader Class Initialized
INFO - 2016-11-29 11:08:57 --> Helper loaded: url_helper
INFO - 2016-11-29 11:08:57 --> Helper loaded: form_helper
INFO - 2016-11-29 11:08:57 --> Database Driver Class Initialized
INFO - 2016-11-29 11:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:08:57 --> Controller Class Initialized
INFO - 2016-11-29 11:08:57 --> Model Class Initialized
INFO - 2016-11-29 11:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:08:57 --> Pagination Class Initialized
INFO - 2016-11-29 11:08:57 --> Helper loaded: app_helper
INFO - 2016-11-29 11:08:57 --> Form Validation Class Initialized
INFO - 2016-11-29 11:08:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:08:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:08:57 --> Final output sent to browser
DEBUG - 2016-11-29 11:08:57 --> Total execution time: 0.4359
INFO - 2016-11-29 11:09:06 --> Config Class Initialized
INFO - 2016-11-29 11:09:06 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:09:06 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:09:06 --> Utf8 Class Initialized
INFO - 2016-11-29 11:09:06 --> URI Class Initialized
INFO - 2016-11-29 11:09:06 --> Router Class Initialized
INFO - 2016-11-29 11:09:06 --> Output Class Initialized
INFO - 2016-11-29 11:09:06 --> Security Class Initialized
DEBUG - 2016-11-29 11:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:09:06 --> Input Class Initialized
INFO - 2016-11-29 11:09:06 --> Language Class Initialized
INFO - 2016-11-29 11:09:06 --> Loader Class Initialized
INFO - 2016-11-29 11:09:06 --> Helper loaded: url_helper
INFO - 2016-11-29 11:09:06 --> Helper loaded: form_helper
INFO - 2016-11-29 11:09:06 --> Database Driver Class Initialized
INFO - 2016-11-29 11:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:09:06 --> Controller Class Initialized
INFO - 2016-11-29 11:09:06 --> Model Class Initialized
INFO - 2016-11-29 11:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:09:06 --> Pagination Class Initialized
INFO - 2016-11-29 11:09:06 --> Helper loaded: app_helper
INFO - 2016-11-29 11:09:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:09:06 --> Final output sent to browser
DEBUG - 2016-11-29 11:09:06 --> Total execution time: 0.2531
INFO - 2016-11-29 11:09:45 --> Config Class Initialized
INFO - 2016-11-29 11:09:45 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:09:45 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:09:45 --> Utf8 Class Initialized
INFO - 2016-11-29 11:09:45 --> URI Class Initialized
DEBUG - 2016-11-29 11:09:45 --> No URI present. Default controller set.
INFO - 2016-11-29 11:09:45 --> Router Class Initialized
INFO - 2016-11-29 11:09:45 --> Output Class Initialized
INFO - 2016-11-29 11:09:45 --> Security Class Initialized
DEBUG - 2016-11-29 11:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:09:45 --> Input Class Initialized
INFO - 2016-11-29 11:09:45 --> Language Class Initialized
INFO - 2016-11-29 11:09:45 --> Loader Class Initialized
INFO - 2016-11-29 11:09:45 --> Helper loaded: url_helper
INFO - 2016-11-29 11:09:45 --> Helper loaded: form_helper
INFO - 2016-11-29 11:09:45 --> Database Driver Class Initialized
INFO - 2016-11-29 11:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:09:46 --> Controller Class Initialized
INFO - 2016-11-29 11:09:46 --> Model Class Initialized
INFO - 2016-11-29 11:09:46 --> Model Class Initialized
INFO - 2016-11-29 11:09:46 --> Model Class Initialized
INFO - 2016-11-29 11:09:46 --> Model Class Initialized
INFO - 2016-11-29 11:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:09:46 --> Pagination Class Initialized
INFO - 2016-11-29 11:09:46 --> Helper loaded: app_helper
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 11:09:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 11:09:46 --> Final output sent to browser
DEBUG - 2016-11-29 11:09:46 --> Total execution time: 0.5543
INFO - 2016-11-29 11:09:49 --> Config Class Initialized
INFO - 2016-11-29 11:09:49 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:09:49 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:09:49 --> Utf8 Class Initialized
INFO - 2016-11-29 11:09:49 --> URI Class Initialized
INFO - 2016-11-29 11:09:49 --> Router Class Initialized
INFO - 2016-11-29 11:09:49 --> Output Class Initialized
INFO - 2016-11-29 11:09:49 --> Security Class Initialized
DEBUG - 2016-11-29 11:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:09:49 --> Input Class Initialized
INFO - 2016-11-29 11:09:49 --> Language Class Initialized
INFO - 2016-11-29 11:09:49 --> Loader Class Initialized
INFO - 2016-11-29 11:09:49 --> Helper loaded: url_helper
INFO - 2016-11-29 11:09:49 --> Helper loaded: form_helper
INFO - 2016-11-29 11:09:49 --> Database Driver Class Initialized
INFO - 2016-11-29 11:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:09:49 --> Controller Class Initialized
INFO - 2016-11-29 11:09:49 --> Model Class Initialized
INFO - 2016-11-29 11:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:09:49 --> Pagination Class Initialized
INFO - 2016-11-29 11:09:49 --> Helper loaded: app_helper
INFO - 2016-11-29 11:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 11:09:49 --> Final output sent to browser
DEBUG - 2016-11-29 11:09:50 --> Total execution time: 0.3640
INFO - 2016-11-29 11:09:55 --> Config Class Initialized
INFO - 2016-11-29 11:09:55 --> Hooks Class Initialized
DEBUG - 2016-11-29 11:09:55 --> UTF-8 Support Enabled
INFO - 2016-11-29 11:09:55 --> Utf8 Class Initialized
INFO - 2016-11-29 11:09:55 --> URI Class Initialized
INFO - 2016-11-29 11:09:55 --> Router Class Initialized
INFO - 2016-11-29 11:09:55 --> Output Class Initialized
INFO - 2016-11-29 11:09:55 --> Security Class Initialized
DEBUG - 2016-11-29 11:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 11:09:55 --> Input Class Initialized
INFO - 2016-11-29 11:09:55 --> Language Class Initialized
INFO - 2016-11-29 11:09:55 --> Loader Class Initialized
INFO - 2016-11-29 11:09:55 --> Helper loaded: url_helper
INFO - 2016-11-29 11:09:55 --> Helper loaded: form_helper
INFO - 2016-11-29 11:09:55 --> Database Driver Class Initialized
INFO - 2016-11-29 11:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 11:09:55 --> Controller Class Initialized
INFO - 2016-11-29 11:09:55 --> Model Class Initialized
INFO - 2016-11-29 11:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 11:09:55 --> Pagination Class Initialized
INFO - 2016-11-29 11:09:55 --> Helper loaded: app_helper
INFO - 2016-11-29 11:09:55 --> Form Validation Class Initialized
INFO - 2016-11-29 11:09:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 11:09:55 --> Final output sent to browser
DEBUG - 2016-11-29 11:09:55 --> Total execution time: 0.3520
INFO - 2016-11-29 14:38:58 --> Config Class Initialized
INFO - 2016-11-29 14:38:58 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:38:58 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:38:58 --> Utf8 Class Initialized
INFO - 2016-11-29 14:38:58 --> URI Class Initialized
INFO - 2016-11-29 14:38:58 --> Router Class Initialized
INFO - 2016-11-29 14:38:58 --> Output Class Initialized
INFO - 2016-11-29 14:38:58 --> Config Class Initialized
INFO - 2016-11-29 14:38:58 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:38:58 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:38:58 --> Utf8 Class Initialized
INFO - 2016-11-29 14:38:58 --> Security Class Initialized
INFO - 2016-11-29 14:38:58 --> URI Class Initialized
INFO - 2016-11-29 14:38:58 --> Router Class Initialized
INFO - 2016-11-29 14:38:58 --> Output Class Initialized
INFO - 2016-11-29 14:38:58 --> Security Class Initialized
DEBUG - 2016-11-29 14:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-29 14:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:38:59 --> Input Class Initialized
INFO - 2016-11-29 14:38:59 --> Input Class Initialized
INFO - 2016-11-29 14:38:59 --> Language Class Initialized
INFO - 2016-11-29 14:38:59 --> Language Class Initialized
INFO - 2016-11-29 14:38:59 --> Loader Class Initialized
INFO - 2016-11-29 14:38:59 --> Loader Class Initialized
INFO - 2016-11-29 14:38:59 --> Helper loaded: url_helper
INFO - 2016-11-29 14:38:59 --> Helper loaded: url_helper
INFO - 2016-11-29 14:38:59 --> Helper loaded: form_helper
INFO - 2016-11-29 14:38:59 --> Helper loaded: form_helper
INFO - 2016-11-29 14:38:59 --> Database Driver Class Initialized
INFO - 2016-11-29 14:38:59 --> Database Driver Class Initialized
INFO - 2016-11-29 14:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:38:59 --> Controller Class Initialized
INFO - 2016-11-29 14:38:59 --> Controller Class Initialized
INFO - 2016-11-29 14:38:59 --> Model Class Initialized
INFO - 2016-11-29 14:38:59 --> Model Class Initialized
INFO - 2016-11-29 14:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:38:59 --> Pagination Class Initialized
INFO - 2016-11-29 14:38:59 --> Pagination Class Initialized
INFO - 2016-11-29 14:38:59 --> Helper loaded: app_helper
INFO - 2016-11-29 14:38:59 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:00 --> Config Class Initialized
INFO - 2016-11-29 14:39:00 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:00 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:00 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:00 --> URI Class Initialized
INFO - 2016-11-29 14:39:00 --> Router Class Initialized
INFO - 2016-11-29 14:39:00 --> Output Class Initialized
INFO - 2016-11-29 14:39:00 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:00 --> Input Class Initialized
INFO - 2016-11-29 14:39:00 --> Language Class Initialized
INFO - 2016-11-29 14:39:00 --> Loader Class Initialized
INFO - 2016-11-29 14:39:00 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:00 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:00 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:00 --> Controller Class Initialized
INFO - 2016-11-29 14:39:00 --> Model Class Initialized
INFO - 2016-11-29 14:39:00 --> Model Class Initialized
INFO - 2016-11-29 14:39:00 --> Model Class Initialized
INFO - 2016-11-29 14:39:00 --> Model Class Initialized
INFO - 2016-11-29 14:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:00 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:00 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 14:39:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:00 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:00 --> Total execution time: 0.6961
INFO - 2016-11-29 14:39:00 --> Config Class Initialized
INFO - 2016-11-29 14:39:00 --> Config Class Initialized
INFO - 2016-11-29 14:39:00 --> Hooks Class Initialized
INFO - 2016-11-29 14:39:00 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:00 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:00 --> Utf8 Class Initialized
DEBUG - 2016-11-29 14:39:00 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:00 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:01 --> URI Class Initialized
INFO - 2016-11-29 14:39:01 --> URI Class Initialized
DEBUG - 2016-11-29 14:39:01 --> No URI present. Default controller set.
INFO - 2016-11-29 14:39:01 --> Router Class Initialized
INFO - 2016-11-29 14:39:01 --> Router Class Initialized
INFO - 2016-11-29 14:39:01 --> Output Class Initialized
INFO - 2016-11-29 14:39:01 --> Output Class Initialized
INFO - 2016-11-29 14:39:01 --> Security Class Initialized
INFO - 2016-11-29 14:39:01 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-29 14:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:01 --> Input Class Initialized
INFO - 2016-11-29 14:39:01 --> Input Class Initialized
INFO - 2016-11-29 14:39:01 --> Language Class Initialized
INFO - 2016-11-29 14:39:01 --> Language Class Initialized
INFO - 2016-11-29 14:39:01 --> Loader Class Initialized
INFO - 2016-11-29 14:39:01 --> Loader Class Initialized
INFO - 2016-11-29 14:39:01 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:01 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:01 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:01 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:01 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:01 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:01 --> Controller Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:01 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:01 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 14:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:01 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:01 --> Total execution time: 0.7831
INFO - 2016-11-29 14:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:01 --> Controller Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Model Class Initialized
INFO - 2016-11-29 14:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:01 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:01 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 14:39:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:01 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:01 --> Total execution time: 0.9534
INFO - 2016-11-29 14:39:16 --> Config Class Initialized
INFO - 2016-11-29 14:39:16 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:16 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:16 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:16 --> URI Class Initialized
INFO - 2016-11-29 14:39:16 --> Router Class Initialized
INFO - 2016-11-29 14:39:16 --> Output Class Initialized
INFO - 2016-11-29 14:39:16 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:16 --> Input Class Initialized
INFO - 2016-11-29 14:39:16 --> Language Class Initialized
INFO - 2016-11-29 14:39:16 --> Loader Class Initialized
INFO - 2016-11-29 14:39:16 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:16 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:16 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:16 --> Controller Class Initialized
INFO - 2016-11-29 14:39:16 --> Model Class Initialized
INFO - 2016-11-29 14:39:16 --> Model Class Initialized
INFO - 2016-11-29 14:39:16 --> Model Class Initialized
INFO - 2016-11-29 14:39:16 --> Model Class Initialized
INFO - 2016-11-29 14:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:16 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:16 --> Helper loaded: app_helper
DEBUG - 2016-11-29 14:39:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-29 14:39:16 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-29 14:39:16 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-29 14:39:16 --> Config Class Initialized
INFO - 2016-11-29 14:39:16 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:16 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:17 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:17 --> URI Class Initialized
DEBUG - 2016-11-29 14:39:17 --> No URI present. Default controller set.
INFO - 2016-11-29 14:39:17 --> Router Class Initialized
INFO - 2016-11-29 14:39:17 --> Output Class Initialized
INFO - 2016-11-29 14:39:17 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:17 --> Input Class Initialized
INFO - 2016-11-29 14:39:17 --> Language Class Initialized
INFO - 2016-11-29 14:39:17 --> Loader Class Initialized
INFO - 2016-11-29 14:39:17 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:17 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:17 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:17 --> Controller Class Initialized
INFO - 2016-11-29 14:39:17 --> Model Class Initialized
INFO - 2016-11-29 14:39:17 --> Model Class Initialized
INFO - 2016-11-29 14:39:17 --> Model Class Initialized
INFO - 2016-11-29 14:39:17 --> Model Class Initialized
INFO - 2016-11-29 14:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:17 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:17 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 14:39:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:17 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:17 --> Total execution time: 0.3770
INFO - 2016-11-29 14:39:22 --> Config Class Initialized
INFO - 2016-11-29 14:39:22 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:22 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:22 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:22 --> URI Class Initialized
DEBUG - 2016-11-29 14:39:22 --> No URI present. Default controller set.
INFO - 2016-11-29 14:39:22 --> Router Class Initialized
INFO - 2016-11-29 14:39:22 --> Output Class Initialized
INFO - 2016-11-29 14:39:22 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:22 --> Input Class Initialized
INFO - 2016-11-29 14:39:22 --> Language Class Initialized
INFO - 2016-11-29 14:39:22 --> Loader Class Initialized
INFO - 2016-11-29 14:39:22 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:22 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:22 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:22 --> Controller Class Initialized
INFO - 2016-11-29 14:39:22 --> Model Class Initialized
INFO - 2016-11-29 14:39:22 --> Model Class Initialized
INFO - 2016-11-29 14:39:22 --> Model Class Initialized
INFO - 2016-11-29 14:39:22 --> Model Class Initialized
INFO - 2016-11-29 14:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:22 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:22 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 14:39:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:22 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:22 --> Total execution time: 0.4086
INFO - 2016-11-29 14:39:32 --> Config Class Initialized
INFO - 2016-11-29 14:39:32 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:32 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:32 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:32 --> URI Class Initialized
INFO - 2016-11-29 14:39:32 --> Router Class Initialized
INFO - 2016-11-29 14:39:32 --> Output Class Initialized
INFO - 2016-11-29 14:39:32 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:32 --> Input Class Initialized
INFO - 2016-11-29 14:39:32 --> Language Class Initialized
INFO - 2016-11-29 14:39:32 --> Loader Class Initialized
INFO - 2016-11-29 14:39:32 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:32 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:32 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:32 --> Controller Class Initialized
INFO - 2016-11-29 14:39:32 --> Model Class Initialized
INFO - 2016-11-29 14:39:32 --> Model Class Initialized
INFO - 2016-11-29 14:39:32 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:33 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:33 --> Helper loaded: app_helper
DEBUG - 2016-11-29 14:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-29 14:39:33 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:33 --> Total execution time: 0.5887
INFO - 2016-11-29 14:39:33 --> Config Class Initialized
INFO - 2016-11-29 14:39:33 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:33 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:33 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:33 --> URI Class Initialized
DEBUG - 2016-11-29 14:39:33 --> No URI present. Default controller set.
INFO - 2016-11-29 14:39:33 --> Router Class Initialized
INFO - 2016-11-29 14:39:33 --> Output Class Initialized
INFO - 2016-11-29 14:39:33 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:33 --> Input Class Initialized
INFO - 2016-11-29 14:39:33 --> Language Class Initialized
INFO - 2016-11-29 14:39:33 --> Loader Class Initialized
INFO - 2016-11-29 14:39:33 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:33 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:33 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:33 --> Controller Class Initialized
INFO - 2016-11-29 14:39:33 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Model Class Initialized
INFO - 2016-11-29 14:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:33 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:33 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 14:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:33 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:33 --> Total execution time: 0.5789
INFO - 2016-11-29 14:39:39 --> Config Class Initialized
INFO - 2016-11-29 14:39:39 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:39 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:39 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:39 --> URI Class Initialized
INFO - 2016-11-29 14:39:39 --> Router Class Initialized
INFO - 2016-11-29 14:39:39 --> Output Class Initialized
INFO - 2016-11-29 14:39:39 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:39 --> Input Class Initialized
INFO - 2016-11-29 14:39:39 --> Language Class Initialized
INFO - 2016-11-29 14:39:39 --> Loader Class Initialized
INFO - 2016-11-29 14:39:39 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:39 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:39 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:39 --> Controller Class Initialized
INFO - 2016-11-29 14:39:39 --> Model Class Initialized
INFO - 2016-11-29 14:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:39 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:39 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:40 --> Form Validation Class Initialized
INFO - 2016-11-29 14:39:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-29 14:39:40 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:40 --> Total execution time: 0.4592
INFO - 2016-11-29 14:39:42 --> Config Class Initialized
INFO - 2016-11-29 14:39:42 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:42 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:42 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:42 --> URI Class Initialized
DEBUG - 2016-11-29 14:39:42 --> No URI present. Default controller set.
INFO - 2016-11-29 14:39:42 --> Router Class Initialized
INFO - 2016-11-29 14:39:42 --> Output Class Initialized
INFO - 2016-11-29 14:39:42 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:42 --> Input Class Initialized
INFO - 2016-11-29 14:39:42 --> Language Class Initialized
INFO - 2016-11-29 14:39:42 --> Loader Class Initialized
INFO - 2016-11-29 14:39:42 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:42 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:42 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:42 --> Controller Class Initialized
INFO - 2016-11-29 14:39:42 --> Model Class Initialized
INFO - 2016-11-29 14:39:42 --> Model Class Initialized
INFO - 2016-11-29 14:39:42 --> Model Class Initialized
INFO - 2016-11-29 14:39:42 --> Model Class Initialized
INFO - 2016-11-29 14:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:42 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:42 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 14:39:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:39:42 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:42 --> Total execution time: 0.5217
INFO - 2016-11-29 14:39:47 --> Config Class Initialized
INFO - 2016-11-29 14:39:47 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:47 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:47 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:47 --> URI Class Initialized
INFO - 2016-11-29 14:39:47 --> Router Class Initialized
INFO - 2016-11-29 14:39:47 --> Output Class Initialized
INFO - 2016-11-29 14:39:47 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:47 --> Input Class Initialized
INFO - 2016-11-29 14:39:47 --> Language Class Initialized
INFO - 2016-11-29 14:39:47 --> Loader Class Initialized
INFO - 2016-11-29 14:39:47 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:47 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:47 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:48 --> Controller Class Initialized
INFO - 2016-11-29 14:39:48 --> Model Class Initialized
INFO - 2016-11-29 14:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:48 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:48 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 14:39:48 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:48 --> Total execution time: 0.2910
INFO - 2016-11-29 14:39:50 --> Config Class Initialized
INFO - 2016-11-29 14:39:50 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:39:50 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:39:50 --> Utf8 Class Initialized
INFO - 2016-11-29 14:39:50 --> URI Class Initialized
INFO - 2016-11-29 14:39:50 --> Router Class Initialized
INFO - 2016-11-29 14:39:50 --> Output Class Initialized
INFO - 2016-11-29 14:39:50 --> Security Class Initialized
DEBUG - 2016-11-29 14:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:39:50 --> Input Class Initialized
INFO - 2016-11-29 14:39:50 --> Language Class Initialized
INFO - 2016-11-29 14:39:50 --> Loader Class Initialized
INFO - 2016-11-29 14:39:50 --> Helper loaded: url_helper
INFO - 2016-11-29 14:39:50 --> Helper loaded: form_helper
INFO - 2016-11-29 14:39:50 --> Database Driver Class Initialized
INFO - 2016-11-29 14:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:39:51 --> Controller Class Initialized
INFO - 2016-11-29 14:39:51 --> Model Class Initialized
INFO - 2016-11-29 14:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:39:51 --> Pagination Class Initialized
INFO - 2016-11-29 14:39:51 --> Helper loaded: app_helper
INFO - 2016-11-29 14:39:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 14:39:51 --> Final output sent to browser
DEBUG - 2016-11-29 14:39:51 --> Total execution time: 0.2875
INFO - 2016-11-29 14:40:14 --> Config Class Initialized
INFO - 2016-11-29 14:40:14 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:40:14 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:40:14 --> Utf8 Class Initialized
INFO - 2016-11-29 14:40:14 --> URI Class Initialized
INFO - 2016-11-29 14:40:14 --> Router Class Initialized
INFO - 2016-11-29 14:40:14 --> Output Class Initialized
INFO - 2016-11-29 14:40:14 --> Security Class Initialized
DEBUG - 2016-11-29 14:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:40:14 --> Input Class Initialized
INFO - 2016-11-29 14:40:14 --> Language Class Initialized
INFO - 2016-11-29 14:40:14 --> Loader Class Initialized
INFO - 2016-11-29 14:40:14 --> Helper loaded: url_helper
INFO - 2016-11-29 14:40:14 --> Helper loaded: form_helper
INFO - 2016-11-29 14:40:14 --> Database Driver Class Initialized
INFO - 2016-11-29 14:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:40:15 --> Controller Class Initialized
INFO - 2016-11-29 14:40:15 --> Model Class Initialized
INFO - 2016-11-29 14:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:40:15 --> Pagination Class Initialized
INFO - 2016-11-29 14:40:15 --> Helper loaded: app_helper
INFO - 2016-11-29 14:40:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 14:40:15 --> Final output sent to browser
DEBUG - 2016-11-29 14:40:15 --> Total execution time: 0.2994
INFO - 2016-11-29 14:47:55 --> Config Class Initialized
INFO - 2016-11-29 14:47:55 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:47:55 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:47:55 --> Utf8 Class Initialized
INFO - 2016-11-29 14:47:55 --> URI Class Initialized
DEBUG - 2016-11-29 14:47:56 --> No URI present. Default controller set.
INFO - 2016-11-29 14:47:56 --> Router Class Initialized
INFO - 2016-11-29 14:47:56 --> Output Class Initialized
INFO - 2016-11-29 14:47:56 --> Security Class Initialized
DEBUG - 2016-11-29 14:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:47:56 --> Input Class Initialized
INFO - 2016-11-29 14:47:56 --> Language Class Initialized
INFO - 2016-11-29 14:47:56 --> Loader Class Initialized
INFO - 2016-11-29 14:47:56 --> Helper loaded: url_helper
INFO - 2016-11-29 14:47:56 --> Helper loaded: form_helper
INFO - 2016-11-29 14:47:56 --> Database Driver Class Initialized
INFO - 2016-11-29 14:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:47:56 --> Controller Class Initialized
INFO - 2016-11-29 14:47:56 --> Model Class Initialized
INFO - 2016-11-29 14:47:56 --> Model Class Initialized
INFO - 2016-11-29 14:47:56 --> Model Class Initialized
INFO - 2016-11-29 14:47:56 --> Model Class Initialized
INFO - 2016-11-29 14:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:47:56 --> Pagination Class Initialized
INFO - 2016-11-29 14:47:56 --> Helper loaded: app_helper
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_records.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/add_leave_record_sidebar.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\hrm/leave_records_reports.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-29 14:47:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:47:56 --> Final output sent to browser
DEBUG - 2016-11-29 14:47:56 --> Total execution time: 0.5501
INFO - 2016-11-29 14:48:05 --> Config Class Initialized
INFO - 2016-11-29 14:48:05 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:48:05 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:48:05 --> Utf8 Class Initialized
INFO - 2016-11-29 14:48:05 --> URI Class Initialized
INFO - 2016-11-29 14:48:05 --> Router Class Initialized
INFO - 2016-11-29 14:48:05 --> Output Class Initialized
INFO - 2016-11-29 14:48:05 --> Security Class Initialized
DEBUG - 2016-11-29 14:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:48:05 --> Input Class Initialized
INFO - 2016-11-29 14:48:05 --> Language Class Initialized
INFO - 2016-11-29 14:48:05 --> Loader Class Initialized
INFO - 2016-11-29 14:48:05 --> Helper loaded: url_helper
INFO - 2016-11-29 14:48:05 --> Helper loaded: form_helper
INFO - 2016-11-29 14:48:05 --> Database Driver Class Initialized
INFO - 2016-11-29 14:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:48:05 --> Controller Class Initialized
INFO - 2016-11-29 14:48:05 --> Model Class Initialized
INFO - 2016-11-29 14:48:05 --> Model Class Initialized
INFO - 2016-11-29 14:48:05 --> Model Class Initialized
INFO - 2016-11-29 14:48:05 --> Model Class Initialized
INFO - 2016-11-29 14:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:48:05 --> Pagination Class Initialized
INFO - 2016-11-29 14:48:06 --> Helper loaded: app_helper
DEBUG - 2016-11-29 14:48:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-29 14:48:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
ERROR - 2016-11-29 14:48:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 166
INFO - 2016-11-29 14:48:06 --> Config Class Initialized
INFO - 2016-11-29 14:48:06 --> Hooks Class Initialized
DEBUG - 2016-11-29 14:48:06 --> UTF-8 Support Enabled
INFO - 2016-11-29 14:48:06 --> Utf8 Class Initialized
INFO - 2016-11-29 14:48:06 --> URI Class Initialized
DEBUG - 2016-11-29 14:48:06 --> No URI present. Default controller set.
INFO - 2016-11-29 14:48:06 --> Router Class Initialized
INFO - 2016-11-29 14:48:06 --> Output Class Initialized
INFO - 2016-11-29 14:48:06 --> Security Class Initialized
DEBUG - 2016-11-29 14:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-29 14:48:06 --> Input Class Initialized
INFO - 2016-11-29 14:48:06 --> Language Class Initialized
INFO - 2016-11-29 14:48:06 --> Loader Class Initialized
INFO - 2016-11-29 14:48:06 --> Helper loaded: url_helper
INFO - 2016-11-29 14:48:06 --> Helper loaded: form_helper
INFO - 2016-11-29 14:48:06 --> Database Driver Class Initialized
INFO - 2016-11-29 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-29 14:48:06 --> Controller Class Initialized
INFO - 2016-11-29 14:48:06 --> Model Class Initialized
INFO - 2016-11-29 14:48:06 --> Model Class Initialized
INFO - 2016-11-29 14:48:06 --> Model Class Initialized
INFO - 2016-11-29 14:48:06 --> Model Class Initialized
INFO - 2016-11-29 14:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-11-29 14:48:06 --> Pagination Class Initialized
INFO - 2016-11-29 14:48:06 --> Helper loaded: app_helper
INFO - 2016-11-29 14:48:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-29 14:48:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-29 14:48:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-29 14:48:06 --> Final output sent to browser
DEBUG - 2016-11-29 14:48:06 --> Total execution time: 0.3941
