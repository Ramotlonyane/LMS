<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-16 16:56:38 --> Config Class Initialized
INFO - 2016-10-16 16:56:38 --> Hooks Class Initialized
DEBUG - 2016-10-16 16:56:38 --> UTF-8 Support Enabled
INFO - 2016-10-16 16:56:38 --> Utf8 Class Initialized
INFO - 2016-10-16 16:56:38 --> URI Class Initialized
DEBUG - 2016-10-16 16:56:38 --> No URI present. Default controller set.
INFO - 2016-10-16 16:56:38 --> Router Class Initialized
INFO - 2016-10-16 16:56:38 --> Output Class Initialized
INFO - 2016-10-16 16:56:38 --> Security Class Initialized
DEBUG - 2016-10-16 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 16:56:38 --> Input Class Initialized
INFO - 2016-10-16 16:56:38 --> Language Class Initialized
INFO - 2016-10-16 16:56:38 --> Loader Class Initialized
INFO - 2016-10-16 16:56:38 --> Controller Class Initialized
INFO - 2016-10-16 16:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\welcome_message.php
INFO - 2016-10-16 16:56:38 --> Final output sent to browser
DEBUG - 2016-10-16 16:56:38 --> Total execution time: 0.8758
INFO - 2016-10-16 16:57:19 --> Config Class Initialized
INFO - 2016-10-16 16:57:19 --> Hooks Class Initialized
DEBUG - 2016-10-16 16:57:19 --> UTF-8 Support Enabled
INFO - 2016-10-16 16:57:19 --> Utf8 Class Initialized
INFO - 2016-10-16 16:57:19 --> URI Class Initialized
DEBUG - 2016-10-16 16:57:19 --> No URI present. Default controller set.
INFO - 2016-10-16 16:57:19 --> Router Class Initialized
INFO - 2016-10-16 16:57:19 --> Output Class Initialized
INFO - 2016-10-16 16:57:19 --> Security Class Initialized
DEBUG - 2016-10-16 16:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 16:57:19 --> Input Class Initialized
INFO - 2016-10-16 16:57:19 --> Language Class Initialized
INFO - 2016-10-16 16:57:19 --> Loader Class Initialized
INFO - 2016-10-16 16:57:19 --> Controller Class Initialized
INFO - 2016-10-16 16:57:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\welcome_message.php
INFO - 2016-10-16 16:57:19 --> Final output sent to browser
DEBUG - 2016-10-16 16:57:19 --> Total execution time: 0.1782
INFO - 2016-10-16 17:02:03 --> Config Class Initialized
INFO - 2016-10-16 17:02:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:02:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:02:03 --> Utf8 Class Initialized
INFO - 2016-10-16 17:02:03 --> URI Class Initialized
DEBUG - 2016-10-16 17:02:03 --> No URI present. Default controller set.
INFO - 2016-10-16 17:02:03 --> Router Class Initialized
INFO - 2016-10-16 17:02:03 --> Output Class Initialized
INFO - 2016-10-16 17:02:03 --> Security Class Initialized
DEBUG - 2016-10-16 17:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:02:03 --> Input Class Initialized
INFO - 2016-10-16 17:02:03 --> Language Class Initialized
INFO - 2016-10-16 17:02:03 --> Loader Class Initialized
INFO - 2016-10-16 17:02:03 --> Controller Class Initialized
ERROR - 2016-10-16 17:02:03 --> Severity: Notice --> Undefined property: Auth::$session C:\xampp\htdocs\LMS\app\controllers\Auth.php 11
ERROR - 2016-10-16 17:02:03 --> Severity: Error --> Call to a member function userdata() on null C:\xampp\htdocs\LMS\app\controllers\Auth.php 11
INFO - 2016-10-16 17:05:03 --> Config Class Initialized
INFO - 2016-10-16 17:05:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:05:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:05:03 --> Utf8 Class Initialized
INFO - 2016-10-16 17:05:03 --> URI Class Initialized
DEBUG - 2016-10-16 17:05:03 --> No URI present. Default controller set.
INFO - 2016-10-16 17:05:03 --> Router Class Initialized
INFO - 2016-10-16 17:05:03 --> Output Class Initialized
INFO - 2016-10-16 17:05:03 --> Security Class Initialized
DEBUG - 2016-10-16 17:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:05:03 --> Input Class Initialized
INFO - 2016-10-16 17:05:03 --> Language Class Initialized
INFO - 2016-10-16 17:05:03 --> Loader Class Initialized
INFO - 2016-10-16 17:05:03 --> Helper loaded: url_helper
INFO - 2016-10-16 17:05:03 --> Helper loaded: form_helper
INFO - 2016-10-16 17:05:03 --> Database Driver Class Initialized
INFO - 2016-10-16 17:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:05:03 --> Controller Class Initialized
INFO - 2016-10-16 17:12:08 --> Config Class Initialized
INFO - 2016-10-16 17:12:08 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:12:08 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:12:08 --> Utf8 Class Initialized
INFO - 2016-10-16 17:12:08 --> URI Class Initialized
DEBUG - 2016-10-16 17:12:08 --> No URI present. Default controller set.
INFO - 2016-10-16 17:12:08 --> Router Class Initialized
INFO - 2016-10-16 17:12:08 --> Output Class Initialized
INFO - 2016-10-16 17:12:08 --> Security Class Initialized
DEBUG - 2016-10-16 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:12:08 --> Input Class Initialized
INFO - 2016-10-16 17:12:08 --> Language Class Initialized
INFO - 2016-10-16 17:12:08 --> Loader Class Initialized
INFO - 2016-10-16 17:12:08 --> Helper loaded: url_helper
INFO - 2016-10-16 17:12:09 --> Helper loaded: form_helper
INFO - 2016-10-16 17:12:09 --> Database Driver Class Initialized
INFO - 2016-10-16 17:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:12:09 --> Controller Class Initialized
INFO - 2016-10-16 17:12:46 --> Config Class Initialized
INFO - 2016-10-16 17:12:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:12:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:12:46 --> Utf8 Class Initialized
INFO - 2016-10-16 17:12:46 --> URI Class Initialized
DEBUG - 2016-10-16 17:12:46 --> No URI present. Default controller set.
INFO - 2016-10-16 17:12:46 --> Router Class Initialized
INFO - 2016-10-16 17:12:46 --> Output Class Initialized
INFO - 2016-10-16 17:12:46 --> Security Class Initialized
DEBUG - 2016-10-16 17:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:12:46 --> Input Class Initialized
INFO - 2016-10-16 17:12:46 --> Language Class Initialized
ERROR - 2016-10-16 17:12:46 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\LMS\app\controllers\Auth.php 20
INFO - 2016-10-16 17:13:42 --> Config Class Initialized
INFO - 2016-10-16 17:13:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:13:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:13:42 --> Utf8 Class Initialized
INFO - 2016-10-16 17:13:42 --> URI Class Initialized
DEBUG - 2016-10-16 17:13:42 --> No URI present. Default controller set.
INFO - 2016-10-16 17:13:42 --> Router Class Initialized
INFO - 2016-10-16 17:13:42 --> Output Class Initialized
INFO - 2016-10-16 17:13:42 --> Security Class Initialized
DEBUG - 2016-10-16 17:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:13:42 --> Input Class Initialized
INFO - 2016-10-16 17:13:42 --> Language Class Initialized
INFO - 2016-10-16 17:13:42 --> Loader Class Initialized
INFO - 2016-10-16 17:13:42 --> Helper loaded: url_helper
INFO - 2016-10-16 17:13:42 --> Helper loaded: form_helper
INFO - 2016-10-16 17:13:42 --> Database Driver Class Initialized
INFO - 2016-10-16 17:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:13:42 --> Controller Class Initialized
INFO - 2016-10-16 17:13:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:13:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:14:13 --> Config Class Initialized
INFO - 2016-10-16 17:14:13 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:14:13 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:14:13 --> Utf8 Class Initialized
INFO - 2016-10-16 17:14:13 --> URI Class Initialized
DEBUG - 2016-10-16 17:14:13 --> No URI present. Default controller set.
INFO - 2016-10-16 17:14:13 --> Router Class Initialized
INFO - 2016-10-16 17:14:13 --> Output Class Initialized
INFO - 2016-10-16 17:14:13 --> Security Class Initialized
DEBUG - 2016-10-16 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:14:13 --> Input Class Initialized
INFO - 2016-10-16 17:14:13 --> Language Class Initialized
INFO - 2016-10-16 17:14:13 --> Loader Class Initialized
INFO - 2016-10-16 17:14:13 --> Helper loaded: url_helper
INFO - 2016-10-16 17:14:13 --> Helper loaded: form_helper
INFO - 2016-10-16 17:14:13 --> Database Driver Class Initialized
INFO - 2016-10-16 17:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:14:13 --> Controller Class Initialized
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:14:13 --> Form Validation Class Initialized
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:14:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:14:13 --> Final output sent to browser
DEBUG - 2016-10-16 17:14:13 --> Total execution time: 0.2441
INFO - 2016-10-16 17:16:55 --> Config Class Initialized
INFO - 2016-10-16 17:16:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:16:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:16:55 --> Utf8 Class Initialized
INFO - 2016-10-16 17:16:55 --> URI Class Initialized
DEBUG - 2016-10-16 17:16:55 --> No URI present. Default controller set.
INFO - 2016-10-16 17:16:55 --> Router Class Initialized
INFO - 2016-10-16 17:16:55 --> Output Class Initialized
INFO - 2016-10-16 17:16:55 --> Security Class Initialized
DEBUG - 2016-10-16 17:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:16:55 --> Input Class Initialized
INFO - 2016-10-16 17:16:55 --> Language Class Initialized
INFO - 2016-10-16 17:16:55 --> Loader Class Initialized
INFO - 2016-10-16 17:16:55 --> Helper loaded: url_helper
INFO - 2016-10-16 17:16:55 --> Helper loaded: form_helper
INFO - 2016-10-16 17:16:55 --> Database Driver Class Initialized
INFO - 2016-10-16 17:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:16:55 --> Controller Class Initialized
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:16:55 --> Form Validation Class Initialized
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:16:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:16:55 --> Final output sent to browser
DEBUG - 2016-10-16 17:16:55 --> Total execution time: 0.2873
INFO - 2016-10-16 17:17:23 --> Config Class Initialized
INFO - 2016-10-16 17:17:23 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:17:23 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:17:23 --> Utf8 Class Initialized
INFO - 2016-10-16 17:17:23 --> URI Class Initialized
DEBUG - 2016-10-16 17:17:23 --> No URI present. Default controller set.
INFO - 2016-10-16 17:17:23 --> Router Class Initialized
INFO - 2016-10-16 17:17:23 --> Output Class Initialized
INFO - 2016-10-16 17:17:23 --> Security Class Initialized
DEBUG - 2016-10-16 17:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:17:23 --> Input Class Initialized
INFO - 2016-10-16 17:17:23 --> Language Class Initialized
INFO - 2016-10-16 17:17:23 --> Loader Class Initialized
INFO - 2016-10-16 17:17:23 --> Helper loaded: url_helper
INFO - 2016-10-16 17:17:23 --> Helper loaded: form_helper
INFO - 2016-10-16 17:17:23 --> Database Driver Class Initialized
INFO - 2016-10-16 17:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:17:23 --> Controller Class Initialized
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:17:23 --> Form Validation Class Initialized
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:17:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:17:23 --> Final output sent to browser
DEBUG - 2016-10-16 17:17:23 --> Total execution time: 0.2178
INFO - 2016-10-16 17:18:22 --> Config Class Initialized
INFO - 2016-10-16 17:18:22 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:18:22 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:18:22 --> Utf8 Class Initialized
INFO - 2016-10-16 17:18:22 --> URI Class Initialized
DEBUG - 2016-10-16 17:18:22 --> No URI present. Default controller set.
INFO - 2016-10-16 17:18:22 --> Router Class Initialized
INFO - 2016-10-16 17:18:22 --> Output Class Initialized
INFO - 2016-10-16 17:18:22 --> Security Class Initialized
DEBUG - 2016-10-16 17:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:18:22 --> Input Class Initialized
INFO - 2016-10-16 17:18:22 --> Language Class Initialized
INFO - 2016-10-16 17:18:22 --> Loader Class Initialized
INFO - 2016-10-16 17:18:22 --> Helper loaded: url_helper
INFO - 2016-10-16 17:18:22 --> Helper loaded: form_helper
INFO - 2016-10-16 17:18:22 --> Database Driver Class Initialized
INFO - 2016-10-16 17:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:18:22 --> Controller Class Initialized
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:18:22 --> Form Validation Class Initialized
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:18:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:18:22 --> Final output sent to browser
DEBUG - 2016-10-16 17:18:22 --> Total execution time: 0.2627
INFO - 2016-10-16 17:20:15 --> Config Class Initialized
INFO - 2016-10-16 17:20:15 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:20:15 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:20:15 --> Utf8 Class Initialized
INFO - 2016-10-16 17:20:15 --> URI Class Initialized
DEBUG - 2016-10-16 17:20:15 --> No URI present. Default controller set.
INFO - 2016-10-16 17:20:15 --> Router Class Initialized
INFO - 2016-10-16 17:20:15 --> Output Class Initialized
INFO - 2016-10-16 17:20:15 --> Security Class Initialized
DEBUG - 2016-10-16 17:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:20:15 --> Input Class Initialized
INFO - 2016-10-16 17:20:15 --> Language Class Initialized
INFO - 2016-10-16 17:20:15 --> Loader Class Initialized
INFO - 2016-10-16 17:20:15 --> Helper loaded: url_helper
INFO - 2016-10-16 17:20:15 --> Helper loaded: form_helper
INFO - 2016-10-16 17:20:15 --> Database Driver Class Initialized
INFO - 2016-10-16 17:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:20:15 --> Controller Class Initialized
INFO - 2016-10-16 17:20:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:20:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:20:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:20:15 --> Form Validation Class Initialized
INFO - 2016-10-16 17:20:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:20:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:20:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:20:15 --> Final output sent to browser
DEBUG - 2016-10-16 17:20:15 --> Total execution time: 0.2604
INFO - 2016-10-16 17:20:39 --> Config Class Initialized
INFO - 2016-10-16 17:20:39 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:20:39 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:20:39 --> Utf8 Class Initialized
INFO - 2016-10-16 17:20:39 --> URI Class Initialized
DEBUG - 2016-10-16 17:20:39 --> No URI present. Default controller set.
INFO - 2016-10-16 17:20:39 --> Router Class Initialized
INFO - 2016-10-16 17:20:39 --> Output Class Initialized
INFO - 2016-10-16 17:20:39 --> Security Class Initialized
DEBUG - 2016-10-16 17:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:20:39 --> Input Class Initialized
INFO - 2016-10-16 17:20:39 --> Language Class Initialized
INFO - 2016-10-16 17:20:39 --> Loader Class Initialized
INFO - 2016-10-16 17:20:39 --> Helper loaded: url_helper
INFO - 2016-10-16 17:20:39 --> Helper loaded: form_helper
INFO - 2016-10-16 17:20:39 --> Database Driver Class Initialized
INFO - 2016-10-16 17:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:20:39 --> Controller Class Initialized
INFO - 2016-10-16 17:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:20:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:20:39 --> Form Validation Class Initialized
INFO - 2016-10-16 17:20:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:20:39 --> Model Class Initialized
ERROR - 2016-10-16 17:20:39 --> Query error: No database selected - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'admin'
INFO - 2016-10-16 17:20:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-16 17:20:48 --> Config Class Initialized
INFO - 2016-10-16 17:20:48 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:20:48 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:20:48 --> Utf8 Class Initialized
INFO - 2016-10-16 17:20:48 --> URI Class Initialized
DEBUG - 2016-10-16 17:20:48 --> No URI present. Default controller set.
INFO - 2016-10-16 17:20:48 --> Router Class Initialized
INFO - 2016-10-16 17:20:48 --> Output Class Initialized
INFO - 2016-10-16 17:20:48 --> Security Class Initialized
DEBUG - 2016-10-16 17:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:20:48 --> Input Class Initialized
INFO - 2016-10-16 17:20:48 --> Language Class Initialized
INFO - 2016-10-16 17:20:48 --> Loader Class Initialized
INFO - 2016-10-16 17:20:48 --> Helper loaded: url_helper
INFO - 2016-10-16 17:20:48 --> Helper loaded: form_helper
INFO - 2016-10-16 17:20:48 --> Database Driver Class Initialized
INFO - 2016-10-16 17:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:20:48 --> Controller Class Initialized
INFO - 2016-10-16 17:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:20:48 --> Form Validation Class Initialized
INFO - 2016-10-16 17:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:20:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:20:48 --> Final output sent to browser
DEBUG - 2016-10-16 17:20:48 --> Total execution time: 0.2793
INFO - 2016-10-16 17:22:05 --> Config Class Initialized
INFO - 2016-10-16 17:22:05 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:22:05 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:22:05 --> Utf8 Class Initialized
INFO - 2016-10-16 17:22:05 --> URI Class Initialized
DEBUG - 2016-10-16 17:22:06 --> No URI present. Default controller set.
INFO - 2016-10-16 17:22:06 --> Router Class Initialized
INFO - 2016-10-16 17:22:06 --> Output Class Initialized
INFO - 2016-10-16 17:22:06 --> Security Class Initialized
DEBUG - 2016-10-16 17:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:22:06 --> Input Class Initialized
INFO - 2016-10-16 17:22:06 --> Language Class Initialized
ERROR - 2016-10-16 17:22:06 --> Severity: Error --> Class 'MY_Controller' not found C:\xampp\htdocs\LMS\app\controllers\Auth.php 7
INFO - 2016-10-16 17:22:21 --> Config Class Initialized
INFO - 2016-10-16 17:22:21 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:22:21 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:22:21 --> Utf8 Class Initialized
INFO - 2016-10-16 17:22:21 --> URI Class Initialized
DEBUG - 2016-10-16 17:22:21 --> No URI present. Default controller set.
INFO - 2016-10-16 17:22:21 --> Router Class Initialized
INFO - 2016-10-16 17:22:21 --> Output Class Initialized
INFO - 2016-10-16 17:22:21 --> Security Class Initialized
DEBUG - 2016-10-16 17:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:22:21 --> Input Class Initialized
INFO - 2016-10-16 17:22:21 --> Language Class Initialized
INFO - 2016-10-16 17:22:21 --> Loader Class Initialized
INFO - 2016-10-16 17:22:21 --> Helper loaded: url_helper
INFO - 2016-10-16 17:22:21 --> Helper loaded: form_helper
INFO - 2016-10-16 17:22:21 --> Database Driver Class Initialized
INFO - 2016-10-16 17:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:22:21 --> Controller Class Initialized
INFO - 2016-10-16 17:23:56 --> Config Class Initialized
INFO - 2016-10-16 17:23:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:23:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:23:56 --> Utf8 Class Initialized
INFO - 2016-10-16 17:23:56 --> URI Class Initialized
DEBUG - 2016-10-16 17:23:56 --> No URI present. Default controller set.
INFO - 2016-10-16 17:23:56 --> Router Class Initialized
INFO - 2016-10-16 17:23:56 --> Output Class Initialized
INFO - 2016-10-16 17:23:56 --> Security Class Initialized
DEBUG - 2016-10-16 17:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:23:56 --> Input Class Initialized
INFO - 2016-10-16 17:23:56 --> Language Class Initialized
INFO - 2016-10-16 17:23:56 --> Loader Class Initialized
INFO - 2016-10-16 17:23:56 --> Helper loaded: url_helper
INFO - 2016-10-16 17:23:56 --> Helper loaded: form_helper
INFO - 2016-10-16 17:23:56 --> Database Driver Class Initialized
INFO - 2016-10-16 17:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:23:56 --> Controller Class Initialized
INFO - 2016-10-16 17:31:24 --> Config Class Initialized
INFO - 2016-10-16 17:31:24 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:31:24 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:31:24 --> Utf8 Class Initialized
INFO - 2016-10-16 17:31:24 --> URI Class Initialized
DEBUG - 2016-10-16 17:31:24 --> No URI present. Default controller set.
INFO - 2016-10-16 17:31:24 --> Router Class Initialized
INFO - 2016-10-16 17:31:24 --> Output Class Initialized
INFO - 2016-10-16 17:31:24 --> Security Class Initialized
DEBUG - 2016-10-16 17:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:31:24 --> Input Class Initialized
INFO - 2016-10-16 17:31:24 --> Language Class Initialized
INFO - 2016-10-16 17:31:24 --> Loader Class Initialized
INFO - 2016-10-16 17:31:24 --> Helper loaded: url_helper
INFO - 2016-10-16 17:31:24 --> Helper loaded: form_helper
INFO - 2016-10-16 17:31:24 --> Database Driver Class Initialized
INFO - 2016-10-16 17:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:31:24 --> Controller Class Initialized
INFO - 2016-10-16 17:32:58 --> Config Class Initialized
INFO - 2016-10-16 17:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:32:58 --> Utf8 Class Initialized
INFO - 2016-10-16 17:32:58 --> URI Class Initialized
DEBUG - 2016-10-16 17:32:58 --> No URI present. Default controller set.
INFO - 2016-10-16 17:32:58 --> Router Class Initialized
INFO - 2016-10-16 17:32:58 --> Output Class Initialized
INFO - 2016-10-16 17:32:58 --> Security Class Initialized
DEBUG - 2016-10-16 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:32:58 --> Input Class Initialized
INFO - 2016-10-16 17:32:58 --> Language Class Initialized
INFO - 2016-10-16 17:32:58 --> Loader Class Initialized
INFO - 2016-10-16 17:32:58 --> Helper loaded: url_helper
INFO - 2016-10-16 17:32:58 --> Helper loaded: form_helper
INFO - 2016-10-16 17:32:58 --> Database Driver Class Initialized
INFO - 2016-10-16 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:32:58 --> Controller Class Initialized
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:32:58 --> Form Validation Class Initialized
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:32:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:32:58 --> Final output sent to browser
DEBUG - 2016-10-16 17:32:58 --> Total execution time: 0.2336
INFO - 2016-10-16 17:33:14 --> Config Class Initialized
INFO - 2016-10-16 17:33:14 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:33:14 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:33:14 --> Utf8 Class Initialized
INFO - 2016-10-16 17:33:14 --> URI Class Initialized
DEBUG - 2016-10-16 17:33:14 --> No URI present. Default controller set.
INFO - 2016-10-16 17:33:14 --> Router Class Initialized
INFO - 2016-10-16 17:33:14 --> Output Class Initialized
INFO - 2016-10-16 17:33:14 --> Security Class Initialized
DEBUG - 2016-10-16 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:33:14 --> Input Class Initialized
INFO - 2016-10-16 17:33:14 --> Language Class Initialized
INFO - 2016-10-16 17:33:14 --> Loader Class Initialized
INFO - 2016-10-16 17:33:14 --> Helper loaded: url_helper
INFO - 2016-10-16 17:33:14 --> Helper loaded: form_helper
INFO - 2016-10-16 17:33:14 --> Database Driver Class Initialized
INFO - 2016-10-16 17:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:33:14 --> Controller Class Initialized
INFO - 2016-10-16 17:33:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:33:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:33:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:33:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:33:14 --> Form Validation Class Initialized
INFO - 2016-10-16 17:33:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:33:14 --> Model Class Initialized
ERROR - 2016-10-16 17:33:14 --> Query error: No database selected - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'admin'
INFO - 2016-10-16 17:33:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-16 17:34:18 --> Config Class Initialized
INFO - 2016-10-16 17:34:18 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:34:18 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:34:18 --> Utf8 Class Initialized
INFO - 2016-10-16 17:34:18 --> URI Class Initialized
DEBUG - 2016-10-16 17:34:18 --> No URI present. Default controller set.
INFO - 2016-10-16 17:34:18 --> Router Class Initialized
INFO - 2016-10-16 17:34:18 --> Output Class Initialized
INFO - 2016-10-16 17:34:18 --> Security Class Initialized
DEBUG - 2016-10-16 17:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:34:18 --> Input Class Initialized
INFO - 2016-10-16 17:34:18 --> Language Class Initialized
INFO - 2016-10-16 17:34:18 --> Loader Class Initialized
INFO - 2016-10-16 17:34:18 --> Helper loaded: url_helper
INFO - 2016-10-16 17:34:18 --> Helper loaded: form_helper
INFO - 2016-10-16 17:34:18 --> Database Driver Class Initialized
INFO - 2016-10-16 17:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:34:18 --> Controller Class Initialized
INFO - 2016-10-16 17:34:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:34:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:34:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:34:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:34:18 --> Form Validation Class Initialized
INFO - 2016-10-16 17:34:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:34:18 --> Model Class Initialized
ERROR - 2016-10-16 17:34:18 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 17:34:18 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
ERROR - 2016-10-16 17:34:18 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 39
INFO - 2016-10-16 17:34:23 --> Config Class Initialized
INFO - 2016-10-16 17:34:23 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:34:24 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:34:24 --> Utf8 Class Initialized
INFO - 2016-10-16 17:34:24 --> URI Class Initialized
DEBUG - 2016-10-16 17:34:24 --> No URI present. Default controller set.
INFO - 2016-10-16 17:34:24 --> Router Class Initialized
INFO - 2016-10-16 17:34:24 --> Output Class Initialized
INFO - 2016-10-16 17:34:24 --> Security Class Initialized
DEBUG - 2016-10-16 17:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:34:24 --> Input Class Initialized
INFO - 2016-10-16 17:34:24 --> Language Class Initialized
INFO - 2016-10-16 17:34:24 --> Loader Class Initialized
INFO - 2016-10-16 17:34:24 --> Helper loaded: url_helper
INFO - 2016-10-16 17:34:24 --> Helper loaded: form_helper
INFO - 2016-10-16 17:34:24 --> Database Driver Class Initialized
INFO - 2016-10-16 17:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:34:24 --> Controller Class Initialized
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:34:24 --> Form Validation Class Initialized
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:34:24 --> Final output sent to browser
DEBUG - 2016-10-16 17:34:24 --> Total execution time: 0.2673
INFO - 2016-10-16 17:35:33 --> Config Class Initialized
INFO - 2016-10-16 17:35:33 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:35:33 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:35:33 --> Utf8 Class Initialized
INFO - 2016-10-16 17:35:33 --> URI Class Initialized
DEBUG - 2016-10-16 17:35:33 --> No URI present. Default controller set.
INFO - 2016-10-16 17:35:33 --> Router Class Initialized
INFO - 2016-10-16 17:35:33 --> Output Class Initialized
INFO - 2016-10-16 17:35:33 --> Security Class Initialized
DEBUG - 2016-10-16 17:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:35:33 --> Input Class Initialized
INFO - 2016-10-16 17:35:33 --> Language Class Initialized
INFO - 2016-10-16 17:35:33 --> Loader Class Initialized
INFO - 2016-10-16 17:35:34 --> Helper loaded: url_helper
INFO - 2016-10-16 17:35:34 --> Helper loaded: form_helper
INFO - 2016-10-16 17:35:34 --> Database Driver Class Initialized
INFO - 2016-10-16 17:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:35:34 --> Controller Class Initialized
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:35:34 --> Form Validation Class Initialized
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:35:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:35:34 --> Final output sent to browser
DEBUG - 2016-10-16 17:35:34 --> Total execution time: 0.2342
INFO - 2016-10-16 17:36:25 --> Config Class Initialized
INFO - 2016-10-16 17:36:25 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:36:25 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:36:25 --> Utf8 Class Initialized
INFO - 2016-10-16 17:36:25 --> URI Class Initialized
DEBUG - 2016-10-16 17:36:25 --> No URI present. Default controller set.
INFO - 2016-10-16 17:36:25 --> Router Class Initialized
INFO - 2016-10-16 17:36:25 --> Output Class Initialized
INFO - 2016-10-16 17:36:25 --> Security Class Initialized
DEBUG - 2016-10-16 17:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:36:25 --> Input Class Initialized
INFO - 2016-10-16 17:36:25 --> Language Class Initialized
INFO - 2016-10-16 17:36:25 --> Loader Class Initialized
INFO - 2016-10-16 17:36:25 --> Helper loaded: url_helper
INFO - 2016-10-16 17:36:25 --> Helper loaded: form_helper
INFO - 2016-10-16 17:36:25 --> Database Driver Class Initialized
INFO - 2016-10-16 17:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:36:25 --> Controller Class Initialized
INFO - 2016-10-16 17:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:36:25 --> Form Validation Class Initialized
INFO - 2016-10-16 17:36:25 --> Final output sent to browser
DEBUG - 2016-10-16 17:36:25 --> Total execution time: 0.2239
INFO - 2016-10-16 17:36:31 --> Config Class Initialized
INFO - 2016-10-16 17:36:31 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:36:31 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:36:31 --> Utf8 Class Initialized
INFO - 2016-10-16 17:36:31 --> URI Class Initialized
DEBUG - 2016-10-16 17:36:31 --> No URI present. Default controller set.
INFO - 2016-10-16 17:36:31 --> Router Class Initialized
INFO - 2016-10-16 17:36:31 --> Output Class Initialized
INFO - 2016-10-16 17:36:31 --> Security Class Initialized
DEBUG - 2016-10-16 17:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:36:31 --> Input Class Initialized
INFO - 2016-10-16 17:36:31 --> Language Class Initialized
INFO - 2016-10-16 17:36:31 --> Loader Class Initialized
INFO - 2016-10-16 17:36:31 --> Helper loaded: url_helper
INFO - 2016-10-16 17:36:31 --> Helper loaded: form_helper
INFO - 2016-10-16 17:36:31 --> Database Driver Class Initialized
INFO - 2016-10-16 17:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:36:31 --> Controller Class Initialized
INFO - 2016-10-16 17:36:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:36:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:36:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:36:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:36:31 --> Form Validation Class Initialized
INFO - 2016-10-16 17:36:31 --> Final output sent to browser
DEBUG - 2016-10-16 17:36:31 --> Total execution time: 0.2500
INFO - 2016-10-16 17:36:34 --> Config Class Initialized
INFO - 2016-10-16 17:36:34 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:36:34 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:36:34 --> Utf8 Class Initialized
INFO - 2016-10-16 17:36:34 --> URI Class Initialized
DEBUG - 2016-10-16 17:36:34 --> No URI present. Default controller set.
INFO - 2016-10-16 17:36:34 --> Router Class Initialized
INFO - 2016-10-16 17:36:34 --> Output Class Initialized
INFO - 2016-10-16 17:36:34 --> Security Class Initialized
DEBUG - 2016-10-16 17:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:36:34 --> Input Class Initialized
INFO - 2016-10-16 17:36:34 --> Language Class Initialized
INFO - 2016-10-16 17:36:34 --> Loader Class Initialized
INFO - 2016-10-16 17:36:34 --> Helper loaded: url_helper
INFO - 2016-10-16 17:36:34 --> Helper loaded: form_helper
INFO - 2016-10-16 17:36:34 --> Database Driver Class Initialized
INFO - 2016-10-16 17:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:36:34 --> Controller Class Initialized
INFO - 2016-10-16 17:36:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:36:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:36:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:36:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:36:34 --> Form Validation Class Initialized
INFO - 2016-10-16 17:36:34 --> Final output sent to browser
DEBUG - 2016-10-16 17:36:34 --> Total execution time: 0.2785
INFO - 2016-10-16 17:37:08 --> Config Class Initialized
INFO - 2016-10-16 17:37:08 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:37:08 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:37:08 --> Utf8 Class Initialized
INFO - 2016-10-16 17:37:08 --> URI Class Initialized
DEBUG - 2016-10-16 17:37:08 --> No URI present. Default controller set.
INFO - 2016-10-16 17:37:08 --> Router Class Initialized
INFO - 2016-10-16 17:37:08 --> Output Class Initialized
INFO - 2016-10-16 17:37:08 --> Security Class Initialized
DEBUG - 2016-10-16 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:37:08 --> Input Class Initialized
INFO - 2016-10-16 17:37:08 --> Language Class Initialized
INFO - 2016-10-16 17:37:08 --> Loader Class Initialized
INFO - 2016-10-16 17:37:08 --> Helper loaded: url_helper
INFO - 2016-10-16 17:37:08 --> Helper loaded: form_helper
INFO - 2016-10-16 17:37:08 --> Database Driver Class Initialized
INFO - 2016-10-16 17:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:37:08 --> Controller Class Initialized
INFO - 2016-10-16 17:37:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:37:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:37:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:37:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:37:08 --> Form Validation Class Initialized
INFO - 2016-10-16 17:37:08 --> Final output sent to browser
DEBUG - 2016-10-16 17:37:08 --> Total execution time: 0.2771
INFO - 2016-10-16 17:38:35 --> Config Class Initialized
INFO - 2016-10-16 17:38:35 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:38:35 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:38:35 --> Utf8 Class Initialized
INFO - 2016-10-16 17:38:35 --> URI Class Initialized
DEBUG - 2016-10-16 17:38:35 --> No URI present. Default controller set.
INFO - 2016-10-16 17:38:35 --> Router Class Initialized
INFO - 2016-10-16 17:38:35 --> Output Class Initialized
INFO - 2016-10-16 17:38:35 --> Security Class Initialized
DEBUG - 2016-10-16 17:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:38:35 --> Input Class Initialized
INFO - 2016-10-16 17:38:35 --> Language Class Initialized
INFO - 2016-10-16 17:38:35 --> Loader Class Initialized
INFO - 2016-10-16 17:38:35 --> Helper loaded: url_helper
INFO - 2016-10-16 17:38:35 --> Helper loaded: form_helper
INFO - 2016-10-16 17:38:35 --> Database Driver Class Initialized
INFO - 2016-10-16 17:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:38:35 --> Controller Class Initialized
INFO - 2016-10-16 17:38:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:38:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:38:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:38:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:38:35 --> Form Validation Class Initialized
INFO - 2016-10-16 17:38:35 --> Final output sent to browser
DEBUG - 2016-10-16 17:38:35 --> Total execution time: 0.2932
INFO - 2016-10-16 17:38:38 --> Config Class Initialized
INFO - 2016-10-16 17:38:38 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:38:38 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:38:38 --> Utf8 Class Initialized
INFO - 2016-10-16 17:38:38 --> URI Class Initialized
DEBUG - 2016-10-16 17:38:38 --> No URI present. Default controller set.
INFO - 2016-10-16 17:38:38 --> Router Class Initialized
INFO - 2016-10-16 17:38:38 --> Output Class Initialized
INFO - 2016-10-16 17:38:38 --> Security Class Initialized
DEBUG - 2016-10-16 17:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:38:38 --> Input Class Initialized
INFO - 2016-10-16 17:38:38 --> Language Class Initialized
INFO - 2016-10-16 17:38:38 --> Loader Class Initialized
INFO - 2016-10-16 17:38:38 --> Helper loaded: url_helper
INFO - 2016-10-16 17:38:38 --> Helper loaded: form_helper
INFO - 2016-10-16 17:38:38 --> Database Driver Class Initialized
INFO - 2016-10-16 17:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:38:38 --> Controller Class Initialized
INFO - 2016-10-16 17:38:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:38:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:38:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:38:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:38:38 --> Form Validation Class Initialized
INFO - 2016-10-16 17:38:38 --> Final output sent to browser
DEBUG - 2016-10-16 17:38:38 --> Total execution time: 0.3268
INFO - 2016-10-16 17:39:17 --> Config Class Initialized
INFO - 2016-10-16 17:39:17 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:39:17 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:39:17 --> Utf8 Class Initialized
INFO - 2016-10-16 17:39:17 --> URI Class Initialized
INFO - 2016-10-16 17:39:17 --> Router Class Initialized
INFO - 2016-10-16 17:39:17 --> Output Class Initialized
INFO - 2016-10-16 17:39:17 --> Security Class Initialized
DEBUG - 2016-10-16 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:39:17 --> Input Class Initialized
INFO - 2016-10-16 17:39:17 --> Language Class Initialized
INFO - 2016-10-16 17:39:17 --> Loader Class Initialized
INFO - 2016-10-16 17:39:17 --> Helper loaded: url_helper
INFO - 2016-10-16 17:39:17 --> Helper loaded: form_helper
INFO - 2016-10-16 17:39:17 --> Database Driver Class Initialized
INFO - 2016-10-16 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:39:17 --> Controller Class Initialized
INFO - 2016-10-16 17:39:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:39:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:39:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:39:17 --> Final output sent to browser
DEBUG - 2016-10-16 17:39:17 --> Total execution time: 0.2232
INFO - 2016-10-16 17:39:47 --> Config Class Initialized
INFO - 2016-10-16 17:39:47 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:39:47 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:39:47 --> Utf8 Class Initialized
INFO - 2016-10-16 17:39:48 --> URI Class Initialized
DEBUG - 2016-10-16 17:39:48 --> No URI present. Default controller set.
INFO - 2016-10-16 17:39:48 --> Router Class Initialized
INFO - 2016-10-16 17:39:48 --> Output Class Initialized
INFO - 2016-10-16 17:39:48 --> Security Class Initialized
DEBUG - 2016-10-16 17:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:39:48 --> Input Class Initialized
INFO - 2016-10-16 17:39:48 --> Language Class Initialized
INFO - 2016-10-16 17:39:48 --> Loader Class Initialized
INFO - 2016-10-16 17:39:48 --> Helper loaded: url_helper
INFO - 2016-10-16 17:39:48 --> Helper loaded: form_helper
INFO - 2016-10-16 17:39:48 --> Database Driver Class Initialized
INFO - 2016-10-16 17:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:39:48 --> Controller Class Initialized
INFO - 2016-10-16 17:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:39:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:39:48 --> Form Validation Class Initialized
INFO - 2016-10-16 17:39:48 --> Final output sent to browser
DEBUG - 2016-10-16 17:39:48 --> Total execution time: 0.2137
INFO - 2016-10-16 17:39:55 --> Config Class Initialized
INFO - 2016-10-16 17:39:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:39:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:39:55 --> Utf8 Class Initialized
INFO - 2016-10-16 17:39:55 --> URI Class Initialized
DEBUG - 2016-10-16 17:39:55 --> No URI present. Default controller set.
INFO - 2016-10-16 17:39:55 --> Router Class Initialized
INFO - 2016-10-16 17:39:55 --> Output Class Initialized
INFO - 2016-10-16 17:39:55 --> Security Class Initialized
DEBUG - 2016-10-16 17:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:39:56 --> Input Class Initialized
INFO - 2016-10-16 17:39:56 --> Language Class Initialized
INFO - 2016-10-16 17:39:56 --> Loader Class Initialized
INFO - 2016-10-16 17:39:56 --> Helper loaded: url_helper
INFO - 2016-10-16 17:39:56 --> Helper loaded: form_helper
INFO - 2016-10-16 17:39:56 --> Database Driver Class Initialized
INFO - 2016-10-16 17:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:39:56 --> Controller Class Initialized
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:39:56 --> Form Validation Class Initialized
INFO - 2016-10-16 17:39:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:39:56 --> Model Class Initialized
ERROR - 2016-10-16 17:39:56 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 17:39:56 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
ERROR - 2016-10-16 17:39:56 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 39
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:39:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:39:56 --> Final output sent to browser
DEBUG - 2016-10-16 17:39:56 --> Total execution time: 0.3131
INFO - 2016-10-16 17:40:21 --> Config Class Initialized
INFO - 2016-10-16 17:40:21 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:40:21 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:40:21 --> Utf8 Class Initialized
INFO - 2016-10-16 17:40:21 --> URI Class Initialized
DEBUG - 2016-10-16 17:40:21 --> No URI present. Default controller set.
INFO - 2016-10-16 17:40:21 --> Router Class Initialized
INFO - 2016-10-16 17:40:21 --> Output Class Initialized
INFO - 2016-10-16 17:40:21 --> Security Class Initialized
DEBUG - 2016-10-16 17:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:40:21 --> Input Class Initialized
INFO - 2016-10-16 17:40:21 --> Language Class Initialized
INFO - 2016-10-16 17:40:21 --> Loader Class Initialized
INFO - 2016-10-16 17:40:21 --> Helper loaded: url_helper
INFO - 2016-10-16 17:40:21 --> Helper loaded: form_helper
INFO - 2016-10-16 17:40:21 --> Database Driver Class Initialized
INFO - 2016-10-16 17:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:40:21 --> Controller Class Initialized
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:40:21 --> Form Validation Class Initialized
INFO - 2016-10-16 17:40:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:40:21 --> Model Class Initialized
ERROR - 2016-10-16 17:40:21 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 17:40:21 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
ERROR - 2016-10-16 17:40:21 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 39
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:40:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:40:21 --> Final output sent to browser
DEBUG - 2016-10-16 17:40:21 --> Total execution time: 0.3640
INFO - 2016-10-16 17:40:33 --> Config Class Initialized
INFO - 2016-10-16 17:40:33 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:40:33 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:40:33 --> Utf8 Class Initialized
INFO - 2016-10-16 17:40:33 --> URI Class Initialized
INFO - 2016-10-16 17:40:33 --> Router Class Initialized
INFO - 2016-10-16 17:40:33 --> Output Class Initialized
INFO - 2016-10-16 17:40:33 --> Security Class Initialized
DEBUG - 2016-10-16 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:40:33 --> Input Class Initialized
INFO - 2016-10-16 17:40:34 --> Language Class Initialized
INFO - 2016-10-16 17:40:34 --> Loader Class Initialized
INFO - 2016-10-16 17:40:34 --> Helper loaded: url_helper
INFO - 2016-10-16 17:40:34 --> Helper loaded: form_helper
INFO - 2016-10-16 17:40:34 --> Database Driver Class Initialized
INFO - 2016-10-16 17:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:40:34 --> Controller Class Initialized
INFO - 2016-10-16 17:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:40:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:40:34 --> Final output sent to browser
DEBUG - 2016-10-16 17:40:34 --> Total execution time: 0.2168
INFO - 2016-10-16 17:40:44 --> Config Class Initialized
INFO - 2016-10-16 17:40:44 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:40:44 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:40:44 --> Utf8 Class Initialized
INFO - 2016-10-16 17:40:44 --> URI Class Initialized
INFO - 2016-10-16 17:40:44 --> Router Class Initialized
INFO - 2016-10-16 17:40:44 --> Output Class Initialized
INFO - 2016-10-16 17:40:44 --> Security Class Initialized
DEBUG - 2016-10-16 17:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:40:44 --> Input Class Initialized
INFO - 2016-10-16 17:40:44 --> Language Class Initialized
INFO - 2016-10-16 17:40:44 --> Loader Class Initialized
INFO - 2016-10-16 17:40:44 --> Helper loaded: url_helper
INFO - 2016-10-16 17:40:44 --> Helper loaded: form_helper
INFO - 2016-10-16 17:40:44 --> Database Driver Class Initialized
INFO - 2016-10-16 17:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:40:44 --> Controller Class Initialized
INFO - 2016-10-16 17:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:40:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:40:44 --> Final output sent to browser
DEBUG - 2016-10-16 17:40:44 --> Total execution time: 0.2192
INFO - 2016-10-16 17:44:10 --> Config Class Initialized
INFO - 2016-10-16 17:44:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:44:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:44:10 --> Utf8 Class Initialized
INFO - 2016-10-16 17:44:10 --> URI Class Initialized
DEBUG - 2016-10-16 17:44:10 --> No URI present. Default controller set.
INFO - 2016-10-16 17:44:10 --> Router Class Initialized
INFO - 2016-10-16 17:44:10 --> Output Class Initialized
INFO - 2016-10-16 17:44:10 --> Security Class Initialized
DEBUG - 2016-10-16 17:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:44:10 --> Input Class Initialized
INFO - 2016-10-16 17:44:10 --> Language Class Initialized
INFO - 2016-10-16 17:44:10 --> Loader Class Initialized
INFO - 2016-10-16 17:44:10 --> Helper loaded: url_helper
INFO - 2016-10-16 17:44:10 --> Helper loaded: form_helper
INFO - 2016-10-16 17:44:10 --> Database Driver Class Initialized
INFO - 2016-10-16 17:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:44:10 --> Controller Class Initialized
INFO - 2016-10-16 17:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:44:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:44:10 --> Final output sent to browser
DEBUG - 2016-10-16 17:44:10 --> Total execution time: 0.2130
INFO - 2016-10-16 17:44:18 --> Config Class Initialized
INFO - 2016-10-16 17:44:18 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:44:18 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:44:18 --> Utf8 Class Initialized
INFO - 2016-10-16 17:44:18 --> URI Class Initialized
DEBUG - 2016-10-16 17:44:18 --> No URI present. Default controller set.
INFO - 2016-10-16 17:44:18 --> Router Class Initialized
INFO - 2016-10-16 17:44:18 --> Output Class Initialized
INFO - 2016-10-16 17:44:18 --> Security Class Initialized
DEBUG - 2016-10-16 17:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:44:18 --> Input Class Initialized
INFO - 2016-10-16 17:44:18 --> Language Class Initialized
INFO - 2016-10-16 17:44:18 --> Loader Class Initialized
INFO - 2016-10-16 17:44:18 --> Helper loaded: url_helper
INFO - 2016-10-16 17:44:18 --> Helper loaded: form_helper
INFO - 2016-10-16 17:44:18 --> Database Driver Class Initialized
INFO - 2016-10-16 17:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:44:18 --> Controller Class Initialized
INFO - 2016-10-16 17:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:44:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:44:18 --> Final output sent to browser
DEBUG - 2016-10-16 17:44:18 --> Total execution time: 0.2122
INFO - 2016-10-16 17:44:26 --> Config Class Initialized
INFO - 2016-10-16 17:44:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:44:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:44:26 --> Utf8 Class Initialized
INFO - 2016-10-16 17:44:26 --> URI Class Initialized
DEBUG - 2016-10-16 17:44:26 --> No URI present. Default controller set.
INFO - 2016-10-16 17:44:26 --> Router Class Initialized
INFO - 2016-10-16 17:44:26 --> Output Class Initialized
INFO - 2016-10-16 17:44:26 --> Security Class Initialized
DEBUG - 2016-10-16 17:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:44:26 --> Input Class Initialized
INFO - 2016-10-16 17:44:26 --> Language Class Initialized
INFO - 2016-10-16 17:44:26 --> Loader Class Initialized
INFO - 2016-10-16 17:44:26 --> Helper loaded: url_helper
INFO - 2016-10-16 17:44:26 --> Helper loaded: form_helper
INFO - 2016-10-16 17:44:26 --> Database Driver Class Initialized
INFO - 2016-10-16 17:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:44:26 --> Controller Class Initialized
INFO - 2016-10-16 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:44:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:44:26 --> Final output sent to browser
DEBUG - 2016-10-16 17:44:26 --> Total execution time: 0.2337
INFO - 2016-10-16 17:44:37 --> Config Class Initialized
INFO - 2016-10-16 17:44:37 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:44:37 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:44:37 --> Utf8 Class Initialized
INFO - 2016-10-16 17:44:37 --> URI Class Initialized
DEBUG - 2016-10-16 17:44:37 --> No URI present. Default controller set.
INFO - 2016-10-16 17:44:37 --> Router Class Initialized
INFO - 2016-10-16 17:44:37 --> Output Class Initialized
INFO - 2016-10-16 17:44:37 --> Security Class Initialized
DEBUG - 2016-10-16 17:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:44:37 --> Input Class Initialized
INFO - 2016-10-16 17:44:37 --> Language Class Initialized
INFO - 2016-10-16 17:44:37 --> Loader Class Initialized
INFO - 2016-10-16 17:44:37 --> Helper loaded: url_helper
INFO - 2016-10-16 17:44:37 --> Helper loaded: form_helper
INFO - 2016-10-16 17:44:37 --> Database Driver Class Initialized
INFO - 2016-10-16 17:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:44:37 --> Controller Class Initialized
INFO - 2016-10-16 17:44:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:44:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:44:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:44:37 --> Final output sent to browser
DEBUG - 2016-10-16 17:44:37 --> Total execution time: 0.2511
INFO - 2016-10-16 17:44:53 --> Config Class Initialized
INFO - 2016-10-16 17:44:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:44:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:44:53 --> Utf8 Class Initialized
INFO - 2016-10-16 17:44:53 --> URI Class Initialized
DEBUG - 2016-10-16 17:44:53 --> No URI present. Default controller set.
INFO - 2016-10-16 17:44:53 --> Router Class Initialized
INFO - 2016-10-16 17:44:53 --> Output Class Initialized
INFO - 2016-10-16 17:44:53 --> Security Class Initialized
DEBUG - 2016-10-16 17:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:44:53 --> Input Class Initialized
INFO - 2016-10-16 17:44:53 --> Language Class Initialized
INFO - 2016-10-16 17:44:53 --> Loader Class Initialized
INFO - 2016-10-16 17:44:53 --> Helper loaded: url_helper
INFO - 2016-10-16 17:44:53 --> Helper loaded: form_helper
INFO - 2016-10-16 17:44:53 --> Database Driver Class Initialized
INFO - 2016-10-16 17:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:44:53 --> Controller Class Initialized
INFO - 2016-10-16 17:44:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:44:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:44:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:44:53 --> Final output sent to browser
DEBUG - 2016-10-16 17:44:53 --> Total execution time: 0.2376
INFO - 2016-10-16 17:46:27 --> Config Class Initialized
INFO - 2016-10-16 17:46:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:46:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:46:27 --> Utf8 Class Initialized
INFO - 2016-10-16 17:46:27 --> URI Class Initialized
DEBUG - 2016-10-16 17:46:27 --> No URI present. Default controller set.
INFO - 2016-10-16 17:46:27 --> Router Class Initialized
INFO - 2016-10-16 17:46:27 --> Output Class Initialized
INFO - 2016-10-16 17:46:27 --> Security Class Initialized
DEBUG - 2016-10-16 17:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:46:27 --> Input Class Initialized
INFO - 2016-10-16 17:46:27 --> Language Class Initialized
INFO - 2016-10-16 17:46:27 --> Loader Class Initialized
INFO - 2016-10-16 17:46:27 --> Helper loaded: url_helper
INFO - 2016-10-16 17:46:27 --> Helper loaded: form_helper
INFO - 2016-10-16 17:46:27 --> Database Driver Class Initialized
INFO - 2016-10-16 17:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:46:27 --> Controller Class Initialized
INFO - 2016-10-16 17:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:46:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:46:27 --> Final output sent to browser
DEBUG - 2016-10-16 17:46:27 --> Total execution time: 0.2300
INFO - 2016-10-16 17:46:29 --> Config Class Initialized
INFO - 2016-10-16 17:46:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:46:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:46:29 --> Utf8 Class Initialized
INFO - 2016-10-16 17:46:29 --> URI Class Initialized
DEBUG - 2016-10-16 17:46:29 --> No URI present. Default controller set.
INFO - 2016-10-16 17:46:29 --> Router Class Initialized
INFO - 2016-10-16 17:46:29 --> Output Class Initialized
INFO - 2016-10-16 17:46:29 --> Security Class Initialized
DEBUG - 2016-10-16 17:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:46:29 --> Input Class Initialized
INFO - 2016-10-16 17:46:29 --> Language Class Initialized
INFO - 2016-10-16 17:46:29 --> Loader Class Initialized
INFO - 2016-10-16 17:46:29 --> Helper loaded: url_helper
INFO - 2016-10-16 17:46:29 --> Helper loaded: form_helper
INFO - 2016-10-16 17:46:29 --> Database Driver Class Initialized
INFO - 2016-10-16 17:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:46:29 --> Controller Class Initialized
INFO - 2016-10-16 17:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:46:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:46:29 --> Final output sent to browser
DEBUG - 2016-10-16 17:46:29 --> Total execution time: 0.2418
INFO - 2016-10-16 17:52:22 --> Config Class Initialized
INFO - 2016-10-16 17:52:22 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:52:22 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:52:22 --> Utf8 Class Initialized
INFO - 2016-10-16 17:52:22 --> URI Class Initialized
DEBUG - 2016-10-16 17:52:22 --> No URI present. Default controller set.
INFO - 2016-10-16 17:52:22 --> Router Class Initialized
INFO - 2016-10-16 17:52:22 --> Output Class Initialized
INFO - 2016-10-16 17:52:22 --> Security Class Initialized
DEBUG - 2016-10-16 17:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:52:22 --> Input Class Initialized
INFO - 2016-10-16 17:52:22 --> Language Class Initialized
INFO - 2016-10-16 17:52:22 --> Loader Class Initialized
INFO - 2016-10-16 17:52:22 --> Helper loaded: url_helper
INFO - 2016-10-16 17:52:22 --> Helper loaded: form_helper
INFO - 2016-10-16 17:52:22 --> Database Driver Class Initialized
INFO - 2016-10-16 17:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:52:22 --> Controller Class Initialized
INFO - 2016-10-16 17:52:22 --> Form Validation Class Initialized
INFO - 2016-10-16 17:52:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:52:22 --> Final output sent to browser
DEBUG - 2016-10-16 17:52:22 --> Total execution time: 0.2403
INFO - 2016-10-16 17:52:40 --> Config Class Initialized
INFO - 2016-10-16 17:52:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:52:40 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:52:40 --> Utf8 Class Initialized
INFO - 2016-10-16 17:52:40 --> URI Class Initialized
DEBUG - 2016-10-16 17:52:40 --> No URI present. Default controller set.
INFO - 2016-10-16 17:52:40 --> Router Class Initialized
INFO - 2016-10-16 17:52:40 --> Output Class Initialized
INFO - 2016-10-16 17:52:40 --> Security Class Initialized
DEBUG - 2016-10-16 17:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:52:40 --> Input Class Initialized
INFO - 2016-10-16 17:52:40 --> Language Class Initialized
INFO - 2016-10-16 17:52:40 --> Loader Class Initialized
INFO - 2016-10-16 17:52:40 --> Helper loaded: url_helper
INFO - 2016-10-16 17:52:40 --> Helper loaded: form_helper
INFO - 2016-10-16 17:52:40 --> Database Driver Class Initialized
INFO - 2016-10-16 17:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:52:40 --> Controller Class Initialized
INFO - 2016-10-16 17:52:40 --> Form Validation Class Initialized
INFO - 2016-10-16 17:52:40 --> Final output sent to browser
DEBUG - 2016-10-16 17:52:40 --> Total execution time: 0.1958
INFO - 2016-10-16 17:58:06 --> Config Class Initialized
INFO - 2016-10-16 17:58:06 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:58:06 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:58:06 --> Utf8 Class Initialized
INFO - 2016-10-16 17:58:06 --> URI Class Initialized
DEBUG - 2016-10-16 17:58:06 --> No URI present. Default controller set.
INFO - 2016-10-16 17:58:06 --> Router Class Initialized
INFO - 2016-10-16 17:58:06 --> Output Class Initialized
INFO - 2016-10-16 17:58:06 --> Security Class Initialized
DEBUG - 2016-10-16 17:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:58:06 --> Input Class Initialized
INFO - 2016-10-16 17:58:06 --> Language Class Initialized
INFO - 2016-10-16 17:58:06 --> Loader Class Initialized
INFO - 2016-10-16 17:58:06 --> Helper loaded: url_helper
INFO - 2016-10-16 17:58:06 --> Helper loaded: form_helper
INFO - 2016-10-16 17:58:06 --> Database Driver Class Initialized
INFO - 2016-10-16 17:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:58:06 --> Controller Class Initialized
INFO - 2016-10-16 17:58:06 --> Form Validation Class Initialized
INFO - 2016-10-16 17:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:58:06 --> Final output sent to browser
DEBUG - 2016-10-16 17:58:06 --> Total execution time: 0.2437
INFO - 2016-10-16 17:58:13 --> Config Class Initialized
INFO - 2016-10-16 17:58:13 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:58:13 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:58:13 --> Utf8 Class Initialized
INFO - 2016-10-16 17:58:13 --> URI Class Initialized
DEBUG - 2016-10-16 17:58:13 --> No URI present. Default controller set.
INFO - 2016-10-16 17:58:13 --> Router Class Initialized
INFO - 2016-10-16 17:58:13 --> Output Class Initialized
INFO - 2016-10-16 17:58:13 --> Security Class Initialized
DEBUG - 2016-10-16 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:58:13 --> Input Class Initialized
INFO - 2016-10-16 17:58:13 --> Language Class Initialized
INFO - 2016-10-16 17:58:13 --> Loader Class Initialized
INFO - 2016-10-16 17:58:13 --> Helper loaded: url_helper
INFO - 2016-10-16 17:58:13 --> Helper loaded: form_helper
INFO - 2016-10-16 17:58:13 --> Database Driver Class Initialized
INFO - 2016-10-16 17:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:58:13 --> Controller Class Initialized
INFO - 2016-10-16 17:58:13 --> Form Validation Class Initialized
INFO - 2016-10-16 17:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:58:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:58:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:58:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:58:13 --> Final output sent to browser
DEBUG - 2016-10-16 17:58:13 --> Total execution time: 0.2538
INFO - 2016-10-16 17:58:26 --> Config Class Initialized
INFO - 2016-10-16 17:58:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:58:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:58:26 --> Utf8 Class Initialized
INFO - 2016-10-16 17:58:26 --> URI Class Initialized
DEBUG - 2016-10-16 17:58:26 --> No URI present. Default controller set.
INFO - 2016-10-16 17:58:26 --> Router Class Initialized
INFO - 2016-10-16 17:58:26 --> Output Class Initialized
INFO - 2016-10-16 17:58:26 --> Security Class Initialized
DEBUG - 2016-10-16 17:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:58:26 --> Input Class Initialized
INFO - 2016-10-16 17:58:26 --> Language Class Initialized
INFO - 2016-10-16 17:58:26 --> Loader Class Initialized
INFO - 2016-10-16 17:58:26 --> Helper loaded: url_helper
INFO - 2016-10-16 17:58:26 --> Helper loaded: form_helper
INFO - 2016-10-16 17:58:26 --> Database Driver Class Initialized
INFO - 2016-10-16 17:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:58:26 --> Controller Class Initialized
INFO - 2016-10-16 17:58:26 --> Form Validation Class Initialized
INFO - 2016-10-16 17:58:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:58:26 --> Model Class Initialized
ERROR - 2016-10-16 17:58:26 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 17:58:26 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 31
INFO - 2016-10-16 17:58:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:58:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:58:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:58:26 --> Final output sent to browser
DEBUG - 2016-10-16 17:58:26 --> Total execution time: 0.2985
INFO - 2016-10-16 17:58:42 --> Config Class Initialized
INFO - 2016-10-16 17:58:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:58:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:58:42 --> Utf8 Class Initialized
INFO - 2016-10-16 17:58:42 --> URI Class Initialized
DEBUG - 2016-10-16 17:58:42 --> No URI present. Default controller set.
INFO - 2016-10-16 17:58:42 --> Router Class Initialized
INFO - 2016-10-16 17:58:42 --> Output Class Initialized
INFO - 2016-10-16 17:58:42 --> Security Class Initialized
DEBUG - 2016-10-16 17:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:58:42 --> Input Class Initialized
INFO - 2016-10-16 17:58:42 --> Language Class Initialized
INFO - 2016-10-16 17:58:42 --> Loader Class Initialized
INFO - 2016-10-16 17:58:42 --> Helper loaded: url_helper
INFO - 2016-10-16 17:58:42 --> Helper loaded: form_helper
INFO - 2016-10-16 17:58:42 --> Database Driver Class Initialized
INFO - 2016-10-16 17:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:58:42 --> Controller Class Initialized
INFO - 2016-10-16 17:58:42 --> Form Validation Class Initialized
INFO - 2016-10-16 17:58:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:58:42 --> Model Class Initialized
ERROR - 2016-10-16 17:58:42 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 17:58:42 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 31
INFO - 2016-10-16 17:58:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:58:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:58:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:58:42 --> Final output sent to browser
DEBUG - 2016-10-16 17:58:42 --> Total execution time: 0.3526
INFO - 2016-10-16 17:58:51 --> Config Class Initialized
INFO - 2016-10-16 17:58:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:58:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:58:51 --> Utf8 Class Initialized
INFO - 2016-10-16 17:58:51 --> URI Class Initialized
DEBUG - 2016-10-16 17:58:51 --> No URI present. Default controller set.
INFO - 2016-10-16 17:58:51 --> Router Class Initialized
INFO - 2016-10-16 17:58:51 --> Output Class Initialized
INFO - 2016-10-16 17:58:51 --> Security Class Initialized
DEBUG - 2016-10-16 17:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:58:51 --> Input Class Initialized
INFO - 2016-10-16 17:58:51 --> Language Class Initialized
INFO - 2016-10-16 17:58:51 --> Loader Class Initialized
INFO - 2016-10-16 17:58:51 --> Helper loaded: url_helper
INFO - 2016-10-16 17:58:51 --> Helper loaded: form_helper
INFO - 2016-10-16 17:58:51 --> Database Driver Class Initialized
INFO - 2016-10-16 17:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:58:51 --> Controller Class Initialized
INFO - 2016-10-16 17:58:51 --> Form Validation Class Initialized
INFO - 2016-10-16 17:58:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 17:58:51 --> Model Class Initialized
ERROR - 2016-10-16 17:58:51 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 17:58:51 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 31
ERROR - 2016-10-16 17:58:51 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 34
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 17:58:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 17:58:51 --> Final output sent to browser
DEBUG - 2016-10-16 17:58:51 --> Total execution time: 0.3464
INFO - 2016-10-16 17:59:04 --> Config Class Initialized
INFO - 2016-10-16 17:59:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:59:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:59:04 --> Utf8 Class Initialized
INFO - 2016-10-16 17:59:04 --> URI Class Initialized
INFO - 2016-10-16 17:59:04 --> Router Class Initialized
INFO - 2016-10-16 17:59:04 --> Output Class Initialized
INFO - 2016-10-16 17:59:04 --> Security Class Initialized
DEBUG - 2016-10-16 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:59:04 --> Input Class Initialized
INFO - 2016-10-16 17:59:04 --> Language Class Initialized
INFO - 2016-10-16 17:59:04 --> Loader Class Initialized
INFO - 2016-10-16 17:59:04 --> Helper loaded: url_helper
INFO - 2016-10-16 17:59:04 --> Helper loaded: form_helper
INFO - 2016-10-16 17:59:04 --> Database Driver Class Initialized
INFO - 2016-10-16 17:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:59:04 --> Controller Class Initialized
INFO - 2016-10-16 18:01:14 --> Config Class Initialized
INFO - 2016-10-16 18:01:14 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:01:14 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:01:14 --> Utf8 Class Initialized
INFO - 2016-10-16 18:01:14 --> URI Class Initialized
DEBUG - 2016-10-16 18:01:14 --> No URI present. Default controller set.
INFO - 2016-10-16 18:01:14 --> Router Class Initialized
INFO - 2016-10-16 18:01:14 --> Output Class Initialized
INFO - 2016-10-16 18:01:14 --> Security Class Initialized
DEBUG - 2016-10-16 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:01:15 --> Input Class Initialized
INFO - 2016-10-16 18:01:15 --> Language Class Initialized
INFO - 2016-10-16 18:01:15 --> Loader Class Initialized
INFO - 2016-10-16 18:01:15 --> Helper loaded: url_helper
INFO - 2016-10-16 18:01:15 --> Helper loaded: form_helper
INFO - 2016-10-16 18:01:15 --> Database Driver Class Initialized
INFO - 2016-10-16 18:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:01:15 --> Controller Class Initialized
INFO - 2016-10-16 18:01:15 --> Form Validation Class Initialized
INFO - 2016-10-16 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:01:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:01:15 --> Final output sent to browser
DEBUG - 2016-10-16 18:01:15 --> Total execution time: 0.2364
INFO - 2016-10-16 18:01:21 --> Config Class Initialized
INFO - 2016-10-16 18:01:21 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:01:21 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:01:21 --> Utf8 Class Initialized
INFO - 2016-10-16 18:01:21 --> URI Class Initialized
DEBUG - 2016-10-16 18:01:21 --> No URI present. Default controller set.
INFO - 2016-10-16 18:01:21 --> Router Class Initialized
INFO - 2016-10-16 18:01:21 --> Output Class Initialized
INFO - 2016-10-16 18:01:21 --> Security Class Initialized
DEBUG - 2016-10-16 18:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:01:21 --> Input Class Initialized
INFO - 2016-10-16 18:01:21 --> Language Class Initialized
INFO - 2016-10-16 18:01:21 --> Loader Class Initialized
INFO - 2016-10-16 18:01:21 --> Helper loaded: url_helper
INFO - 2016-10-16 18:01:21 --> Helper loaded: form_helper
INFO - 2016-10-16 18:01:21 --> Database Driver Class Initialized
INFO - 2016-10-16 18:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:01:21 --> Controller Class Initialized
INFO - 2016-10-16 18:01:21 --> Form Validation Class Initialized
INFO - 2016-10-16 18:01:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:01:21 --> Model Class Initialized
ERROR - 2016-10-16 18:01:21 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 18:01:21 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 31
ERROR - 2016-10-16 18:01:21 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 34
INFO - 2016-10-16 18:01:21 --> Config Class Initialized
INFO - 2016-10-16 18:01:21 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:01:21 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:01:21 --> Utf8 Class Initialized
INFO - 2016-10-16 18:01:21 --> URI Class Initialized
DEBUG - 2016-10-16 18:01:21 --> No URI present. Default controller set.
INFO - 2016-10-16 18:01:21 --> Router Class Initialized
INFO - 2016-10-16 18:01:21 --> Output Class Initialized
INFO - 2016-10-16 18:01:21 --> Security Class Initialized
DEBUG - 2016-10-16 18:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:01:21 --> Input Class Initialized
INFO - 2016-10-16 18:01:21 --> Language Class Initialized
INFO - 2016-10-16 18:01:21 --> Loader Class Initialized
INFO - 2016-10-16 18:01:21 --> Helper loaded: url_helper
INFO - 2016-10-16 18:01:21 --> Helper loaded: form_helper
INFO - 2016-10-16 18:01:21 --> Database Driver Class Initialized
INFO - 2016-10-16 18:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:01:21 --> Controller Class Initialized
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:01:21 --> Form Validation Class Initialized
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:01:21 --> Final output sent to browser
DEBUG - 2016-10-16 18:01:21 --> Total execution time: 0.2863
INFO - 2016-10-16 18:02:04 --> Config Class Initialized
INFO - 2016-10-16 18:02:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:02:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:02:04 --> Utf8 Class Initialized
INFO - 2016-10-16 18:02:04 --> URI Class Initialized
DEBUG - 2016-10-16 18:02:04 --> No URI present. Default controller set.
INFO - 2016-10-16 18:02:04 --> Router Class Initialized
INFO - 2016-10-16 18:02:04 --> Output Class Initialized
INFO - 2016-10-16 18:02:04 --> Security Class Initialized
DEBUG - 2016-10-16 18:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:02:04 --> Input Class Initialized
INFO - 2016-10-16 18:02:04 --> Language Class Initialized
INFO - 2016-10-16 18:02:04 --> Loader Class Initialized
INFO - 2016-10-16 18:02:04 --> Helper loaded: url_helper
INFO - 2016-10-16 18:02:04 --> Helper loaded: form_helper
INFO - 2016-10-16 18:02:04 --> Database Driver Class Initialized
INFO - 2016-10-16 18:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:02:04 --> Controller Class Initialized
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:02:04 --> Form Validation Class Initialized
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:02:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:02:04 --> Final output sent to browser
DEBUG - 2016-10-16 18:02:04 --> Total execution time: 0.2863
INFO - 2016-10-16 18:02:08 --> Config Class Initialized
INFO - 2016-10-16 18:02:08 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:02:08 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:02:08 --> Utf8 Class Initialized
INFO - 2016-10-16 18:02:08 --> URI Class Initialized
DEBUG - 2016-10-16 18:02:08 --> No URI present. Default controller set.
INFO - 2016-10-16 18:02:08 --> Router Class Initialized
INFO - 2016-10-16 18:02:08 --> Output Class Initialized
INFO - 2016-10-16 18:02:08 --> Security Class Initialized
DEBUG - 2016-10-16 18:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:02:08 --> Input Class Initialized
INFO - 2016-10-16 18:02:08 --> Language Class Initialized
INFO - 2016-10-16 18:02:08 --> Loader Class Initialized
INFO - 2016-10-16 18:02:08 --> Helper loaded: url_helper
INFO - 2016-10-16 18:02:08 --> Helper loaded: form_helper
INFO - 2016-10-16 18:02:08 --> Database Driver Class Initialized
INFO - 2016-10-16 18:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:02:08 --> Controller Class Initialized
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:02:08 --> Form Validation Class Initialized
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:02:08 --> Final output sent to browser
DEBUG - 2016-10-16 18:02:08 --> Total execution time: 0.3000
INFO - 2016-10-16 18:02:12 --> Config Class Initialized
INFO - 2016-10-16 18:02:12 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:02:12 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:02:12 --> Utf8 Class Initialized
INFO - 2016-10-16 18:02:12 --> URI Class Initialized
INFO - 2016-10-16 18:02:12 --> Router Class Initialized
INFO - 2016-10-16 18:02:12 --> Output Class Initialized
INFO - 2016-10-16 18:02:12 --> Security Class Initialized
DEBUG - 2016-10-16 18:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:02:12 --> Input Class Initialized
INFO - 2016-10-16 18:02:12 --> Language Class Initialized
INFO - 2016-10-16 18:02:12 --> Loader Class Initialized
INFO - 2016-10-16 18:02:12 --> Helper loaded: url_helper
INFO - 2016-10-16 18:02:12 --> Helper loaded: form_helper
INFO - 2016-10-16 18:02:12 --> Database Driver Class Initialized
INFO - 2016-10-16 18:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:02:12 --> Controller Class Initialized
INFO - 2016-10-16 18:03:37 --> Config Class Initialized
INFO - 2016-10-16 18:03:37 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:37 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:37 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:37 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:37 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:37 --> Router Class Initialized
INFO - 2016-10-16 18:03:37 --> Output Class Initialized
INFO - 2016-10-16 18:03:37 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:37 --> Input Class Initialized
INFO - 2016-10-16 18:03:37 --> Language Class Initialized
INFO - 2016-10-16 18:03:37 --> Loader Class Initialized
INFO - 2016-10-16 18:03:37 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:37 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:37 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:37 --> Controller Class Initialized
INFO - 2016-10-16 18:03:37 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:37 --> Config Class Initialized
INFO - 2016-10-16 18:03:37 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:37 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:37 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:37 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:37 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:37 --> Router Class Initialized
INFO - 2016-10-16 18:03:37 --> Output Class Initialized
INFO - 2016-10-16 18:03:37 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:37 --> Input Class Initialized
INFO - 2016-10-16 18:03:37 --> Language Class Initialized
INFO - 2016-10-16 18:03:37 --> Loader Class Initialized
INFO - 2016-10-16 18:03:37 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:37 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:37 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:37 --> Controller Class Initialized
INFO - 2016-10-16 18:03:37 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:37 --> Config Class Initialized
INFO - 2016-10-16 18:03:37 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:37 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:37 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:37 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:37 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:37 --> Router Class Initialized
INFO - 2016-10-16 18:03:37 --> Output Class Initialized
INFO - 2016-10-16 18:03:37 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:37 --> Input Class Initialized
INFO - 2016-10-16 18:03:37 --> Language Class Initialized
INFO - 2016-10-16 18:03:37 --> Loader Class Initialized
INFO - 2016-10-16 18:03:37 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:37 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:37 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:37 --> Controller Class Initialized
INFO - 2016-10-16 18:03:37 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:37 --> Config Class Initialized
INFO - 2016-10-16 18:03:37 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:37 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:37 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:37 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:37 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:37 --> Router Class Initialized
INFO - 2016-10-16 18:03:37 --> Output Class Initialized
INFO - 2016-10-16 18:03:37 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:37 --> Input Class Initialized
INFO - 2016-10-16 18:03:37 --> Language Class Initialized
INFO - 2016-10-16 18:03:37 --> Loader Class Initialized
INFO - 2016-10-16 18:03:37 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:37 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:37 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:37 --> Controller Class Initialized
INFO - 2016-10-16 18:03:37 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:37 --> Config Class Initialized
INFO - 2016-10-16 18:03:37 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:37 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:37 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:37 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:38 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:38 --> Router Class Initialized
INFO - 2016-10-16 18:03:38 --> Output Class Initialized
INFO - 2016-10-16 18:03:38 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:38 --> Input Class Initialized
INFO - 2016-10-16 18:03:38 --> Language Class Initialized
INFO - 2016-10-16 18:03:38 --> Loader Class Initialized
INFO - 2016-10-16 18:03:38 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:38 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:38 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:38 --> Controller Class Initialized
INFO - 2016-10-16 18:03:38 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:38 --> Config Class Initialized
INFO - 2016-10-16 18:03:38 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:38 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:38 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:38 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:38 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:38 --> Router Class Initialized
INFO - 2016-10-16 18:03:38 --> Output Class Initialized
INFO - 2016-10-16 18:03:38 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:38 --> Input Class Initialized
INFO - 2016-10-16 18:03:38 --> Language Class Initialized
INFO - 2016-10-16 18:03:38 --> Loader Class Initialized
INFO - 2016-10-16 18:03:38 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:38 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:38 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:38 --> Controller Class Initialized
INFO - 2016-10-16 18:03:38 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:38 --> Config Class Initialized
INFO - 2016-10-16 18:03:38 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:38 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:38 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:38 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:38 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:38 --> Router Class Initialized
INFO - 2016-10-16 18:03:38 --> Output Class Initialized
INFO - 2016-10-16 18:03:38 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:38 --> Input Class Initialized
INFO - 2016-10-16 18:03:38 --> Language Class Initialized
INFO - 2016-10-16 18:03:38 --> Loader Class Initialized
INFO - 2016-10-16 18:03:38 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:38 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:38 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:38 --> Controller Class Initialized
INFO - 2016-10-16 18:03:38 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:38 --> Config Class Initialized
INFO - 2016-10-16 18:03:38 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:38 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:38 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:38 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:38 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:38 --> Router Class Initialized
INFO - 2016-10-16 18:03:38 --> Output Class Initialized
INFO - 2016-10-16 18:03:38 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:38 --> Input Class Initialized
INFO - 2016-10-16 18:03:38 --> Language Class Initialized
INFO - 2016-10-16 18:03:38 --> Loader Class Initialized
INFO - 2016-10-16 18:03:38 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:38 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:38 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:38 --> Controller Class Initialized
INFO - 2016-10-16 18:03:38 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:38 --> Config Class Initialized
INFO - 2016-10-16 18:03:38 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:38 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:38 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:38 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:38 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:38 --> Router Class Initialized
INFO - 2016-10-16 18:03:38 --> Output Class Initialized
INFO - 2016-10-16 18:03:38 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:38 --> Input Class Initialized
INFO - 2016-10-16 18:03:38 --> Language Class Initialized
INFO - 2016-10-16 18:03:38 --> Loader Class Initialized
INFO - 2016-10-16 18:03:38 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:38 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:38 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:39 --> Controller Class Initialized
INFO - 2016-10-16 18:03:39 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:39 --> Config Class Initialized
INFO - 2016-10-16 18:03:39 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:39 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:39 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:39 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:39 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:39 --> Router Class Initialized
INFO - 2016-10-16 18:03:39 --> Output Class Initialized
INFO - 2016-10-16 18:03:39 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:39 --> Input Class Initialized
INFO - 2016-10-16 18:03:39 --> Language Class Initialized
INFO - 2016-10-16 18:03:39 --> Loader Class Initialized
INFO - 2016-10-16 18:03:39 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:39 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:39 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:39 --> Controller Class Initialized
INFO - 2016-10-16 18:03:39 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:39 --> Config Class Initialized
INFO - 2016-10-16 18:03:39 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:39 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:39 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:39 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:39 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:39 --> Router Class Initialized
INFO - 2016-10-16 18:03:39 --> Output Class Initialized
INFO - 2016-10-16 18:03:39 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:39 --> Input Class Initialized
INFO - 2016-10-16 18:03:39 --> Language Class Initialized
INFO - 2016-10-16 18:03:39 --> Loader Class Initialized
INFO - 2016-10-16 18:03:39 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:39 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:39 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:39 --> Controller Class Initialized
INFO - 2016-10-16 18:03:39 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:39 --> Config Class Initialized
INFO - 2016-10-16 18:03:39 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:39 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:39 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:39 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:39 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:39 --> Router Class Initialized
INFO - 2016-10-16 18:03:39 --> Output Class Initialized
INFO - 2016-10-16 18:03:39 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:39 --> Input Class Initialized
INFO - 2016-10-16 18:03:39 --> Language Class Initialized
INFO - 2016-10-16 18:03:39 --> Loader Class Initialized
INFO - 2016-10-16 18:03:39 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:39 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:39 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:39 --> Controller Class Initialized
INFO - 2016-10-16 18:03:39 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:39 --> Config Class Initialized
INFO - 2016-10-16 18:03:39 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:39 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:39 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:39 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:39 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:39 --> Router Class Initialized
INFO - 2016-10-16 18:03:39 --> Output Class Initialized
INFO - 2016-10-16 18:03:39 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:39 --> Input Class Initialized
INFO - 2016-10-16 18:03:39 --> Language Class Initialized
INFO - 2016-10-16 18:03:39 --> Loader Class Initialized
INFO - 2016-10-16 18:03:39 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:39 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:39 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:39 --> Controller Class Initialized
INFO - 2016-10-16 18:03:40 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:40 --> Config Class Initialized
INFO - 2016-10-16 18:03:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:40 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:40 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:40 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:40 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:40 --> Router Class Initialized
INFO - 2016-10-16 18:03:40 --> Output Class Initialized
INFO - 2016-10-16 18:03:40 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:40 --> Input Class Initialized
INFO - 2016-10-16 18:03:40 --> Language Class Initialized
INFO - 2016-10-16 18:03:40 --> Loader Class Initialized
INFO - 2016-10-16 18:03:40 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:40 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:40 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:40 --> Controller Class Initialized
INFO - 2016-10-16 18:03:40 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:40 --> Config Class Initialized
INFO - 2016-10-16 18:03:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:40 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:40 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:40 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:40 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:40 --> Router Class Initialized
INFO - 2016-10-16 18:03:40 --> Output Class Initialized
INFO - 2016-10-16 18:03:40 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:40 --> Input Class Initialized
INFO - 2016-10-16 18:03:40 --> Language Class Initialized
INFO - 2016-10-16 18:03:40 --> Loader Class Initialized
INFO - 2016-10-16 18:03:40 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:40 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:40 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:40 --> Controller Class Initialized
INFO - 2016-10-16 18:03:40 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:40 --> Config Class Initialized
INFO - 2016-10-16 18:03:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:40 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:40 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:40 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:40 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:40 --> Router Class Initialized
INFO - 2016-10-16 18:03:40 --> Output Class Initialized
INFO - 2016-10-16 18:03:40 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:40 --> Input Class Initialized
INFO - 2016-10-16 18:03:40 --> Language Class Initialized
INFO - 2016-10-16 18:03:40 --> Loader Class Initialized
INFO - 2016-10-16 18:03:40 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:40 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:40 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:40 --> Controller Class Initialized
INFO - 2016-10-16 18:03:40 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:40 --> Config Class Initialized
INFO - 2016-10-16 18:03:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:40 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:40 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:40 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:40 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:40 --> Router Class Initialized
INFO - 2016-10-16 18:03:40 --> Output Class Initialized
INFO - 2016-10-16 18:03:40 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:40 --> Input Class Initialized
INFO - 2016-10-16 18:03:40 --> Language Class Initialized
INFO - 2016-10-16 18:03:40 --> Loader Class Initialized
INFO - 2016-10-16 18:03:40 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:40 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:40 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:40 --> Controller Class Initialized
INFO - 2016-10-16 18:03:40 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:40 --> Config Class Initialized
INFO - 2016-10-16 18:03:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:41 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:41 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:41 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:41 --> Router Class Initialized
INFO - 2016-10-16 18:03:41 --> Output Class Initialized
INFO - 2016-10-16 18:03:41 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:41 --> Input Class Initialized
INFO - 2016-10-16 18:03:41 --> Language Class Initialized
INFO - 2016-10-16 18:03:41 --> Loader Class Initialized
INFO - 2016-10-16 18:03:41 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:41 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:41 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:41 --> Controller Class Initialized
INFO - 2016-10-16 18:03:41 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:41 --> Config Class Initialized
INFO - 2016-10-16 18:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:41 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:41 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:41 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:41 --> Router Class Initialized
INFO - 2016-10-16 18:03:41 --> Output Class Initialized
INFO - 2016-10-16 18:03:41 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:41 --> Input Class Initialized
INFO - 2016-10-16 18:03:41 --> Language Class Initialized
INFO - 2016-10-16 18:03:41 --> Loader Class Initialized
INFO - 2016-10-16 18:03:41 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:41 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:41 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:41 --> Controller Class Initialized
INFO - 2016-10-16 18:03:41 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:41 --> Config Class Initialized
INFO - 2016-10-16 18:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:41 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:41 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:41 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:41 --> Router Class Initialized
INFO - 2016-10-16 18:03:41 --> Output Class Initialized
INFO - 2016-10-16 18:03:41 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:41 --> Input Class Initialized
INFO - 2016-10-16 18:03:41 --> Language Class Initialized
INFO - 2016-10-16 18:03:41 --> Loader Class Initialized
INFO - 2016-10-16 18:03:41 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:41 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:41 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:41 --> Controller Class Initialized
INFO - 2016-10-16 18:03:41 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:41 --> Config Class Initialized
INFO - 2016-10-16 18:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:41 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:41 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:41 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:41 --> Router Class Initialized
INFO - 2016-10-16 18:03:41 --> Output Class Initialized
INFO - 2016-10-16 18:03:41 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:41 --> Input Class Initialized
INFO - 2016-10-16 18:03:41 --> Language Class Initialized
INFO - 2016-10-16 18:03:41 --> Loader Class Initialized
INFO - 2016-10-16 18:03:41 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:41 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:41 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:41 --> Controller Class Initialized
INFO - 2016-10-16 18:03:41 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:42 --> Config Class Initialized
INFO - 2016-10-16 18:03:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:42 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:42 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:42 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:42 --> Router Class Initialized
INFO - 2016-10-16 18:03:42 --> Output Class Initialized
INFO - 2016-10-16 18:03:42 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:42 --> Input Class Initialized
INFO - 2016-10-16 18:03:42 --> Language Class Initialized
INFO - 2016-10-16 18:03:42 --> Loader Class Initialized
INFO - 2016-10-16 18:03:42 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:42 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:42 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:42 --> Controller Class Initialized
INFO - 2016-10-16 18:03:42 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:42 --> Config Class Initialized
INFO - 2016-10-16 18:03:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:42 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:42 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:42 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:42 --> Router Class Initialized
INFO - 2016-10-16 18:03:42 --> Output Class Initialized
INFO - 2016-10-16 18:03:42 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:42 --> Input Class Initialized
INFO - 2016-10-16 18:03:42 --> Language Class Initialized
INFO - 2016-10-16 18:03:42 --> Loader Class Initialized
INFO - 2016-10-16 18:03:42 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:42 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:42 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:42 --> Controller Class Initialized
INFO - 2016-10-16 18:03:42 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:42 --> Config Class Initialized
INFO - 2016-10-16 18:03:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:42 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:42 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:42 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:42 --> Router Class Initialized
INFO - 2016-10-16 18:03:42 --> Output Class Initialized
INFO - 2016-10-16 18:03:42 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:42 --> Input Class Initialized
INFO - 2016-10-16 18:03:42 --> Language Class Initialized
INFO - 2016-10-16 18:03:42 --> Loader Class Initialized
INFO - 2016-10-16 18:03:42 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:42 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:42 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:42 --> Controller Class Initialized
INFO - 2016-10-16 18:03:42 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:42 --> Config Class Initialized
INFO - 2016-10-16 18:03:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:42 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:42 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:42 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:43 --> Router Class Initialized
INFO - 2016-10-16 18:03:43 --> Output Class Initialized
INFO - 2016-10-16 18:03:43 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:43 --> Input Class Initialized
INFO - 2016-10-16 18:03:43 --> Language Class Initialized
INFO - 2016-10-16 18:03:43 --> Loader Class Initialized
INFO - 2016-10-16 18:03:43 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:43 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:43 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:43 --> Controller Class Initialized
INFO - 2016-10-16 18:03:43 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:43 --> Config Class Initialized
INFO - 2016-10-16 18:03:43 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:43 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:43 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:43 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:43 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:43 --> Router Class Initialized
INFO - 2016-10-16 18:03:43 --> Output Class Initialized
INFO - 2016-10-16 18:03:43 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:43 --> Input Class Initialized
INFO - 2016-10-16 18:03:43 --> Language Class Initialized
INFO - 2016-10-16 18:03:43 --> Loader Class Initialized
INFO - 2016-10-16 18:03:43 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:43 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:43 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:43 --> Controller Class Initialized
INFO - 2016-10-16 18:03:43 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:43 --> Config Class Initialized
INFO - 2016-10-16 18:03:43 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:43 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:43 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:43 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:43 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:43 --> Router Class Initialized
INFO - 2016-10-16 18:03:43 --> Output Class Initialized
INFO - 2016-10-16 18:03:43 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:43 --> Input Class Initialized
INFO - 2016-10-16 18:03:43 --> Language Class Initialized
INFO - 2016-10-16 18:03:43 --> Loader Class Initialized
INFO - 2016-10-16 18:03:43 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:43 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:43 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:43 --> Controller Class Initialized
INFO - 2016-10-16 18:03:43 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:43 --> Config Class Initialized
INFO - 2016-10-16 18:03:43 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:43 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:43 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:43 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:43 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:43 --> Router Class Initialized
INFO - 2016-10-16 18:03:43 --> Output Class Initialized
INFO - 2016-10-16 18:03:43 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:43 --> Input Class Initialized
INFO - 2016-10-16 18:03:43 --> Language Class Initialized
INFO - 2016-10-16 18:03:43 --> Loader Class Initialized
INFO - 2016-10-16 18:03:43 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:43 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:43 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:43 --> Controller Class Initialized
INFO - 2016-10-16 18:03:43 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:43 --> Config Class Initialized
INFO - 2016-10-16 18:03:43 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:43 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:44 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:44 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:44 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:44 --> Router Class Initialized
INFO - 2016-10-16 18:03:44 --> Output Class Initialized
INFO - 2016-10-16 18:03:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:44 --> Input Class Initialized
INFO - 2016-10-16 18:03:44 --> Language Class Initialized
INFO - 2016-10-16 18:03:44 --> Loader Class Initialized
INFO - 2016-10-16 18:03:44 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:44 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:44 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:44 --> Controller Class Initialized
INFO - 2016-10-16 18:03:44 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:44 --> Config Class Initialized
INFO - 2016-10-16 18:03:44 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:44 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:44 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:44 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:44 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:44 --> Router Class Initialized
INFO - 2016-10-16 18:03:44 --> Output Class Initialized
INFO - 2016-10-16 18:03:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:44 --> Input Class Initialized
INFO - 2016-10-16 18:03:44 --> Language Class Initialized
INFO - 2016-10-16 18:03:44 --> Loader Class Initialized
INFO - 2016-10-16 18:03:44 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:44 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:44 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:44 --> Controller Class Initialized
INFO - 2016-10-16 18:03:44 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:44 --> Config Class Initialized
INFO - 2016-10-16 18:03:44 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:44 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:44 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:44 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:44 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:44 --> Router Class Initialized
INFO - 2016-10-16 18:03:44 --> Output Class Initialized
INFO - 2016-10-16 18:03:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:44 --> Input Class Initialized
INFO - 2016-10-16 18:03:44 --> Language Class Initialized
INFO - 2016-10-16 18:03:44 --> Loader Class Initialized
INFO - 2016-10-16 18:03:44 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:44 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:44 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:44 --> Controller Class Initialized
INFO - 2016-10-16 18:03:44 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:44 --> Config Class Initialized
INFO - 2016-10-16 18:03:44 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:44 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:44 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:44 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:44 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:44 --> Router Class Initialized
INFO - 2016-10-16 18:03:44 --> Output Class Initialized
INFO - 2016-10-16 18:03:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:44 --> Input Class Initialized
INFO - 2016-10-16 18:03:44 --> Language Class Initialized
INFO - 2016-10-16 18:03:44 --> Loader Class Initialized
INFO - 2016-10-16 18:03:44 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:44 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:44 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:44 --> Controller Class Initialized
INFO - 2016-10-16 18:03:44 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:44 --> Config Class Initialized
INFO - 2016-10-16 18:03:44 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:44 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:44 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:44 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:44 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:44 --> Router Class Initialized
INFO - 2016-10-16 18:03:44 --> Output Class Initialized
INFO - 2016-10-16 18:03:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:45 --> Input Class Initialized
INFO - 2016-10-16 18:03:45 --> Language Class Initialized
INFO - 2016-10-16 18:03:45 --> Loader Class Initialized
INFO - 2016-10-16 18:03:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:45 --> Controller Class Initialized
INFO - 2016-10-16 18:03:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:45 --> Config Class Initialized
INFO - 2016-10-16 18:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:45 --> Router Class Initialized
INFO - 2016-10-16 18:03:45 --> Output Class Initialized
INFO - 2016-10-16 18:03:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:45 --> Input Class Initialized
INFO - 2016-10-16 18:03:45 --> Language Class Initialized
INFO - 2016-10-16 18:03:45 --> Loader Class Initialized
INFO - 2016-10-16 18:03:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:45 --> Controller Class Initialized
INFO - 2016-10-16 18:03:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:45 --> Config Class Initialized
INFO - 2016-10-16 18:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:45 --> Router Class Initialized
INFO - 2016-10-16 18:03:45 --> Output Class Initialized
INFO - 2016-10-16 18:03:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:45 --> Input Class Initialized
INFO - 2016-10-16 18:03:45 --> Language Class Initialized
INFO - 2016-10-16 18:03:45 --> Loader Class Initialized
INFO - 2016-10-16 18:03:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:45 --> Controller Class Initialized
INFO - 2016-10-16 18:03:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:45 --> Config Class Initialized
INFO - 2016-10-16 18:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:45 --> Router Class Initialized
INFO - 2016-10-16 18:03:45 --> Output Class Initialized
INFO - 2016-10-16 18:03:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:45 --> Input Class Initialized
INFO - 2016-10-16 18:03:45 --> Language Class Initialized
INFO - 2016-10-16 18:03:45 --> Loader Class Initialized
INFO - 2016-10-16 18:03:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:45 --> Controller Class Initialized
INFO - 2016-10-16 18:03:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:45 --> Config Class Initialized
INFO - 2016-10-16 18:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:45 --> Router Class Initialized
INFO - 2016-10-16 18:03:45 --> Output Class Initialized
INFO - 2016-10-16 18:03:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:45 --> Input Class Initialized
INFO - 2016-10-16 18:03:45 --> Language Class Initialized
INFO - 2016-10-16 18:03:45 --> Loader Class Initialized
INFO - 2016-10-16 18:03:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:46 --> Controller Class Initialized
INFO - 2016-10-16 18:03:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:46 --> Config Class Initialized
INFO - 2016-10-16 18:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:46 --> Router Class Initialized
INFO - 2016-10-16 18:03:46 --> Output Class Initialized
INFO - 2016-10-16 18:03:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:46 --> Input Class Initialized
INFO - 2016-10-16 18:03:46 --> Language Class Initialized
INFO - 2016-10-16 18:03:46 --> Loader Class Initialized
INFO - 2016-10-16 18:03:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:46 --> Controller Class Initialized
INFO - 2016-10-16 18:03:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:46 --> Config Class Initialized
INFO - 2016-10-16 18:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:46 --> Router Class Initialized
INFO - 2016-10-16 18:03:46 --> Output Class Initialized
INFO - 2016-10-16 18:03:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:46 --> Input Class Initialized
INFO - 2016-10-16 18:03:46 --> Language Class Initialized
INFO - 2016-10-16 18:03:46 --> Loader Class Initialized
INFO - 2016-10-16 18:03:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:46 --> Controller Class Initialized
INFO - 2016-10-16 18:03:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:46 --> Config Class Initialized
INFO - 2016-10-16 18:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:46 --> Router Class Initialized
INFO - 2016-10-16 18:03:46 --> Output Class Initialized
INFO - 2016-10-16 18:03:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:46 --> Input Class Initialized
INFO - 2016-10-16 18:03:46 --> Language Class Initialized
INFO - 2016-10-16 18:03:46 --> Loader Class Initialized
INFO - 2016-10-16 18:03:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:46 --> Controller Class Initialized
INFO - 2016-10-16 18:03:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:46 --> Config Class Initialized
INFO - 2016-10-16 18:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:46 --> Router Class Initialized
INFO - 2016-10-16 18:03:46 --> Output Class Initialized
INFO - 2016-10-16 18:03:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:46 --> Input Class Initialized
INFO - 2016-10-16 18:03:46 --> Language Class Initialized
INFO - 2016-10-16 18:03:46 --> Loader Class Initialized
INFO - 2016-10-16 18:03:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:47 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:47 --> Controller Class Initialized
INFO - 2016-10-16 18:03:47 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:47 --> Config Class Initialized
INFO - 2016-10-16 18:03:47 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:47 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:47 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:47 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:47 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:47 --> Router Class Initialized
INFO - 2016-10-16 18:03:47 --> Output Class Initialized
INFO - 2016-10-16 18:03:47 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:47 --> Input Class Initialized
INFO - 2016-10-16 18:03:47 --> Language Class Initialized
INFO - 2016-10-16 18:03:47 --> Loader Class Initialized
INFO - 2016-10-16 18:03:47 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:47 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:47 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:47 --> Controller Class Initialized
INFO - 2016-10-16 18:03:47 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:52 --> Config Class Initialized
INFO - 2016-10-16 18:03:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:52 --> Router Class Initialized
INFO - 2016-10-16 18:03:52 --> Output Class Initialized
INFO - 2016-10-16 18:03:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:52 --> Input Class Initialized
INFO - 2016-10-16 18:03:52 --> Language Class Initialized
INFO - 2016-10-16 18:03:52 --> Loader Class Initialized
INFO - 2016-10-16 18:03:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:52 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:52 --> Controller Class Initialized
INFO - 2016-10-16 18:03:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:52 --> Config Class Initialized
INFO - 2016-10-16 18:03:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:52 --> Router Class Initialized
INFO - 2016-10-16 18:03:52 --> Output Class Initialized
INFO - 2016-10-16 18:03:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:52 --> Input Class Initialized
INFO - 2016-10-16 18:03:52 --> Language Class Initialized
INFO - 2016-10-16 18:03:52 --> Loader Class Initialized
INFO - 2016-10-16 18:03:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:52 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:52 --> Controller Class Initialized
INFO - 2016-10-16 18:03:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:52 --> Config Class Initialized
INFO - 2016-10-16 18:03:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:52 --> Router Class Initialized
INFO - 2016-10-16 18:03:52 --> Output Class Initialized
INFO - 2016-10-16 18:03:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:52 --> Input Class Initialized
INFO - 2016-10-16 18:03:52 --> Language Class Initialized
INFO - 2016-10-16 18:03:52 --> Loader Class Initialized
INFO - 2016-10-16 18:03:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:53 --> Controller Class Initialized
INFO - 2016-10-16 18:03:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:53 --> Config Class Initialized
INFO - 2016-10-16 18:03:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:53 --> Router Class Initialized
INFO - 2016-10-16 18:03:53 --> Output Class Initialized
INFO - 2016-10-16 18:03:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:53 --> Input Class Initialized
INFO - 2016-10-16 18:03:53 --> Language Class Initialized
INFO - 2016-10-16 18:03:53 --> Loader Class Initialized
INFO - 2016-10-16 18:03:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:53 --> Controller Class Initialized
INFO - 2016-10-16 18:03:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:53 --> Config Class Initialized
INFO - 2016-10-16 18:03:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:53 --> Router Class Initialized
INFO - 2016-10-16 18:03:53 --> Output Class Initialized
INFO - 2016-10-16 18:03:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:53 --> Input Class Initialized
INFO - 2016-10-16 18:03:53 --> Language Class Initialized
INFO - 2016-10-16 18:03:53 --> Loader Class Initialized
INFO - 2016-10-16 18:03:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:53 --> Controller Class Initialized
INFO - 2016-10-16 18:03:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:53 --> Config Class Initialized
INFO - 2016-10-16 18:03:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:53 --> Router Class Initialized
INFO - 2016-10-16 18:03:53 --> Output Class Initialized
INFO - 2016-10-16 18:03:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:53 --> Input Class Initialized
INFO - 2016-10-16 18:03:53 --> Language Class Initialized
INFO - 2016-10-16 18:03:53 --> Loader Class Initialized
INFO - 2016-10-16 18:03:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:53 --> Controller Class Initialized
INFO - 2016-10-16 18:03:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:53 --> Config Class Initialized
INFO - 2016-10-16 18:03:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:53 --> Router Class Initialized
INFO - 2016-10-16 18:03:53 --> Output Class Initialized
INFO - 2016-10-16 18:03:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:53 --> Input Class Initialized
INFO - 2016-10-16 18:03:53 --> Language Class Initialized
INFO - 2016-10-16 18:03:53 --> Loader Class Initialized
INFO - 2016-10-16 18:03:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:54 --> Controller Class Initialized
INFO - 2016-10-16 18:03:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:54 --> Config Class Initialized
INFO - 2016-10-16 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:54 --> Router Class Initialized
INFO - 2016-10-16 18:03:54 --> Output Class Initialized
INFO - 2016-10-16 18:03:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:54 --> Input Class Initialized
INFO - 2016-10-16 18:03:54 --> Language Class Initialized
INFO - 2016-10-16 18:03:54 --> Loader Class Initialized
INFO - 2016-10-16 18:03:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:54 --> Controller Class Initialized
INFO - 2016-10-16 18:03:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:54 --> Config Class Initialized
INFO - 2016-10-16 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:54 --> Router Class Initialized
INFO - 2016-10-16 18:03:54 --> Output Class Initialized
INFO - 2016-10-16 18:03:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:54 --> Input Class Initialized
INFO - 2016-10-16 18:03:54 --> Language Class Initialized
INFO - 2016-10-16 18:03:54 --> Loader Class Initialized
INFO - 2016-10-16 18:03:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:54 --> Controller Class Initialized
INFO - 2016-10-16 18:03:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:54 --> Config Class Initialized
INFO - 2016-10-16 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:54 --> Router Class Initialized
INFO - 2016-10-16 18:03:54 --> Output Class Initialized
INFO - 2016-10-16 18:03:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:54 --> Input Class Initialized
INFO - 2016-10-16 18:03:54 --> Language Class Initialized
INFO - 2016-10-16 18:03:54 --> Loader Class Initialized
INFO - 2016-10-16 18:03:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:54 --> Controller Class Initialized
INFO - 2016-10-16 18:03:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:54 --> Config Class Initialized
INFO - 2016-10-16 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:54 --> Router Class Initialized
INFO - 2016-10-16 18:03:54 --> Output Class Initialized
INFO - 2016-10-16 18:03:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:55 --> Input Class Initialized
INFO - 2016-10-16 18:03:55 --> Language Class Initialized
INFO - 2016-10-16 18:03:55 --> Loader Class Initialized
INFO - 2016-10-16 18:03:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:55 --> Controller Class Initialized
INFO - 2016-10-16 18:03:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:55 --> Config Class Initialized
INFO - 2016-10-16 18:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:55 --> Router Class Initialized
INFO - 2016-10-16 18:03:55 --> Output Class Initialized
INFO - 2016-10-16 18:03:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:55 --> Input Class Initialized
INFO - 2016-10-16 18:03:55 --> Language Class Initialized
INFO - 2016-10-16 18:03:55 --> Loader Class Initialized
INFO - 2016-10-16 18:03:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:55 --> Controller Class Initialized
INFO - 2016-10-16 18:03:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:55 --> Config Class Initialized
INFO - 2016-10-16 18:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:55 --> Router Class Initialized
INFO - 2016-10-16 18:03:55 --> Output Class Initialized
INFO - 2016-10-16 18:03:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:55 --> Input Class Initialized
INFO - 2016-10-16 18:03:55 --> Language Class Initialized
INFO - 2016-10-16 18:03:55 --> Loader Class Initialized
INFO - 2016-10-16 18:03:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:55 --> Controller Class Initialized
INFO - 2016-10-16 18:03:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:55 --> Config Class Initialized
INFO - 2016-10-16 18:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:55 --> Router Class Initialized
INFO - 2016-10-16 18:03:55 --> Output Class Initialized
INFO - 2016-10-16 18:03:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:55 --> Input Class Initialized
INFO - 2016-10-16 18:03:55 --> Language Class Initialized
INFO - 2016-10-16 18:03:55 --> Loader Class Initialized
INFO - 2016-10-16 18:03:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:55 --> Controller Class Initialized
INFO - 2016-10-16 18:03:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:55 --> Config Class Initialized
INFO - 2016-10-16 18:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:55 --> Router Class Initialized
INFO - 2016-10-16 18:03:55 --> Output Class Initialized
INFO - 2016-10-16 18:03:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:55 --> Input Class Initialized
INFO - 2016-10-16 18:03:55 --> Language Class Initialized
INFO - 2016-10-16 18:03:55 --> Loader Class Initialized
INFO - 2016-10-16 18:03:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:56 --> Controller Class Initialized
INFO - 2016-10-16 18:03:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:56 --> Config Class Initialized
INFO - 2016-10-16 18:03:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:56 --> Router Class Initialized
INFO - 2016-10-16 18:03:56 --> Output Class Initialized
INFO - 2016-10-16 18:03:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:56 --> Input Class Initialized
INFO - 2016-10-16 18:03:56 --> Language Class Initialized
INFO - 2016-10-16 18:03:56 --> Loader Class Initialized
INFO - 2016-10-16 18:03:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:56 --> Controller Class Initialized
INFO - 2016-10-16 18:03:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:56 --> Config Class Initialized
INFO - 2016-10-16 18:03:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:56 --> Router Class Initialized
INFO - 2016-10-16 18:03:56 --> Output Class Initialized
INFO - 2016-10-16 18:03:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:56 --> Input Class Initialized
INFO - 2016-10-16 18:03:56 --> Language Class Initialized
INFO - 2016-10-16 18:03:56 --> Loader Class Initialized
INFO - 2016-10-16 18:03:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:56 --> Controller Class Initialized
INFO - 2016-10-16 18:03:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:56 --> Config Class Initialized
INFO - 2016-10-16 18:03:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:56 --> Router Class Initialized
INFO - 2016-10-16 18:03:56 --> Output Class Initialized
INFO - 2016-10-16 18:03:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:56 --> Input Class Initialized
INFO - 2016-10-16 18:03:56 --> Language Class Initialized
INFO - 2016-10-16 18:03:56 --> Loader Class Initialized
INFO - 2016-10-16 18:03:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:56 --> Controller Class Initialized
INFO - 2016-10-16 18:03:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:56 --> Config Class Initialized
INFO - 2016-10-16 18:03:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:56 --> Router Class Initialized
INFO - 2016-10-16 18:03:56 --> Output Class Initialized
INFO - 2016-10-16 18:03:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:56 --> Input Class Initialized
INFO - 2016-10-16 18:03:56 --> Language Class Initialized
INFO - 2016-10-16 18:03:56 --> Loader Class Initialized
INFO - 2016-10-16 18:03:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:57 --> Controller Class Initialized
INFO - 2016-10-16 18:03:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:57 --> Config Class Initialized
INFO - 2016-10-16 18:03:57 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:57 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:57 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:57 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:57 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:57 --> Router Class Initialized
INFO - 2016-10-16 18:03:57 --> Output Class Initialized
INFO - 2016-10-16 18:03:57 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:57 --> Input Class Initialized
INFO - 2016-10-16 18:03:57 --> Language Class Initialized
INFO - 2016-10-16 18:03:57 --> Loader Class Initialized
INFO - 2016-10-16 18:03:57 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:57 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:57 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:57 --> Controller Class Initialized
INFO - 2016-10-16 18:03:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:03:57 --> Config Class Initialized
INFO - 2016-10-16 18:03:57 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:03:57 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:03:57 --> Utf8 Class Initialized
INFO - 2016-10-16 18:03:57 --> URI Class Initialized
DEBUG - 2016-10-16 18:03:57 --> No URI present. Default controller set.
INFO - 2016-10-16 18:03:57 --> Router Class Initialized
INFO - 2016-10-16 18:03:57 --> Output Class Initialized
INFO - 2016-10-16 18:03:57 --> Security Class Initialized
DEBUG - 2016-10-16 18:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:03:57 --> Input Class Initialized
INFO - 2016-10-16 18:03:57 --> Language Class Initialized
INFO - 2016-10-16 18:03:57 --> Loader Class Initialized
INFO - 2016-10-16 18:03:57 --> Helper loaded: url_helper
INFO - 2016-10-16 18:03:57 --> Helper loaded: form_helper
INFO - 2016-10-16 18:03:57 --> Database Driver Class Initialized
INFO - 2016-10-16 18:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:03:57 --> Controller Class Initialized
INFO - 2016-10-16 18:03:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:02 --> Config Class Initialized
INFO - 2016-10-16 18:04:02 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:02 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:02 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:02 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:02 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:02 --> Router Class Initialized
INFO - 2016-10-16 18:04:02 --> Output Class Initialized
INFO - 2016-10-16 18:04:02 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:02 --> Input Class Initialized
INFO - 2016-10-16 18:04:02 --> Language Class Initialized
INFO - 2016-10-16 18:04:02 --> Loader Class Initialized
INFO - 2016-10-16 18:04:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:02 --> Controller Class Initialized
INFO - 2016-10-16 18:04:02 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:02 --> Config Class Initialized
INFO - 2016-10-16 18:04:02 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:02 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:02 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:02 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:02 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:02 --> Router Class Initialized
INFO - 2016-10-16 18:04:02 --> Output Class Initialized
INFO - 2016-10-16 18:04:02 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:02 --> Input Class Initialized
INFO - 2016-10-16 18:04:02 --> Language Class Initialized
INFO - 2016-10-16 18:04:02 --> Loader Class Initialized
INFO - 2016-10-16 18:04:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:02 --> Controller Class Initialized
INFO - 2016-10-16 18:04:02 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:02 --> Config Class Initialized
INFO - 2016-10-16 18:04:02 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:02 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:02 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:02 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:02 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:02 --> Router Class Initialized
INFO - 2016-10-16 18:04:02 --> Output Class Initialized
INFO - 2016-10-16 18:04:02 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:02 --> Input Class Initialized
INFO - 2016-10-16 18:04:02 --> Language Class Initialized
INFO - 2016-10-16 18:04:02 --> Loader Class Initialized
INFO - 2016-10-16 18:04:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:02 --> Controller Class Initialized
INFO - 2016-10-16 18:04:02 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:03 --> Config Class Initialized
INFO - 2016-10-16 18:04:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:03 --> Router Class Initialized
INFO - 2016-10-16 18:04:03 --> Output Class Initialized
INFO - 2016-10-16 18:04:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:03 --> Input Class Initialized
INFO - 2016-10-16 18:04:03 --> Language Class Initialized
INFO - 2016-10-16 18:04:03 --> Loader Class Initialized
INFO - 2016-10-16 18:04:03 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:03 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:03 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:03 --> Controller Class Initialized
INFO - 2016-10-16 18:04:03 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:03 --> Config Class Initialized
INFO - 2016-10-16 18:04:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:03 --> Router Class Initialized
INFO - 2016-10-16 18:04:03 --> Output Class Initialized
INFO - 2016-10-16 18:04:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:03 --> Input Class Initialized
INFO - 2016-10-16 18:04:03 --> Language Class Initialized
INFO - 2016-10-16 18:04:03 --> Loader Class Initialized
INFO - 2016-10-16 18:04:03 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:03 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:03 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:03 --> Controller Class Initialized
INFO - 2016-10-16 18:04:03 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:03 --> Config Class Initialized
INFO - 2016-10-16 18:04:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:03 --> Router Class Initialized
INFO - 2016-10-16 18:04:03 --> Output Class Initialized
INFO - 2016-10-16 18:04:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:03 --> Input Class Initialized
INFO - 2016-10-16 18:04:03 --> Language Class Initialized
INFO - 2016-10-16 18:04:03 --> Loader Class Initialized
INFO - 2016-10-16 18:04:03 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:03 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:03 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:03 --> Controller Class Initialized
INFO - 2016-10-16 18:04:03 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:03 --> Config Class Initialized
INFO - 2016-10-16 18:04:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:03 --> Router Class Initialized
INFO - 2016-10-16 18:04:03 --> Output Class Initialized
INFO - 2016-10-16 18:04:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:03 --> Input Class Initialized
INFO - 2016-10-16 18:04:03 --> Language Class Initialized
INFO - 2016-10-16 18:04:03 --> Loader Class Initialized
INFO - 2016-10-16 18:04:03 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:03 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:03 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:04 --> Controller Class Initialized
INFO - 2016-10-16 18:04:04 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:04 --> Config Class Initialized
INFO - 2016-10-16 18:04:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:04 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:04 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:04 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:04 --> Router Class Initialized
INFO - 2016-10-16 18:04:04 --> Output Class Initialized
INFO - 2016-10-16 18:04:04 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:04 --> Input Class Initialized
INFO - 2016-10-16 18:04:04 --> Language Class Initialized
INFO - 2016-10-16 18:04:04 --> Loader Class Initialized
INFO - 2016-10-16 18:04:04 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:04 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:04 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:04 --> Controller Class Initialized
INFO - 2016-10-16 18:04:04 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:04 --> Config Class Initialized
INFO - 2016-10-16 18:04:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:04 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:04 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:04 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:04 --> Router Class Initialized
INFO - 2016-10-16 18:04:04 --> Output Class Initialized
INFO - 2016-10-16 18:04:04 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:04 --> Input Class Initialized
INFO - 2016-10-16 18:04:04 --> Language Class Initialized
INFO - 2016-10-16 18:04:04 --> Loader Class Initialized
INFO - 2016-10-16 18:04:04 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:04 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:04 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:04 --> Controller Class Initialized
INFO - 2016-10-16 18:04:04 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:04 --> Config Class Initialized
INFO - 2016-10-16 18:04:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:04 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:04 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:04 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:04 --> Router Class Initialized
INFO - 2016-10-16 18:04:04 --> Output Class Initialized
INFO - 2016-10-16 18:04:04 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:04 --> Input Class Initialized
INFO - 2016-10-16 18:04:04 --> Language Class Initialized
INFO - 2016-10-16 18:04:04 --> Loader Class Initialized
INFO - 2016-10-16 18:04:04 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:04 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:04 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:04 --> Controller Class Initialized
INFO - 2016-10-16 18:04:04 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:04 --> Config Class Initialized
INFO - 2016-10-16 18:04:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:04 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:04 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:04 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:04 --> Router Class Initialized
INFO - 2016-10-16 18:04:04 --> Output Class Initialized
INFO - 2016-10-16 18:04:05 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:05 --> Input Class Initialized
INFO - 2016-10-16 18:04:05 --> Language Class Initialized
INFO - 2016-10-16 18:04:05 --> Loader Class Initialized
INFO - 2016-10-16 18:04:05 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:05 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:05 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:05 --> Controller Class Initialized
INFO - 2016-10-16 18:04:05 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:05 --> Config Class Initialized
INFO - 2016-10-16 18:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:05 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:05 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:05 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:05 --> Router Class Initialized
INFO - 2016-10-16 18:04:05 --> Output Class Initialized
INFO - 2016-10-16 18:04:05 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:05 --> Input Class Initialized
INFO - 2016-10-16 18:04:05 --> Language Class Initialized
INFO - 2016-10-16 18:04:05 --> Loader Class Initialized
INFO - 2016-10-16 18:04:05 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:05 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:05 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:05 --> Controller Class Initialized
INFO - 2016-10-16 18:04:05 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:05 --> Config Class Initialized
INFO - 2016-10-16 18:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:05 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:05 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:05 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:05 --> Router Class Initialized
INFO - 2016-10-16 18:04:05 --> Output Class Initialized
INFO - 2016-10-16 18:04:05 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:05 --> Input Class Initialized
INFO - 2016-10-16 18:04:05 --> Language Class Initialized
INFO - 2016-10-16 18:04:05 --> Loader Class Initialized
INFO - 2016-10-16 18:04:05 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:05 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:05 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:05 --> Controller Class Initialized
INFO - 2016-10-16 18:04:05 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:05 --> Config Class Initialized
INFO - 2016-10-16 18:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:05 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:05 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:05 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:05 --> Router Class Initialized
INFO - 2016-10-16 18:04:05 --> Output Class Initialized
INFO - 2016-10-16 18:04:05 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:05 --> Input Class Initialized
INFO - 2016-10-16 18:04:05 --> Language Class Initialized
INFO - 2016-10-16 18:04:05 --> Loader Class Initialized
INFO - 2016-10-16 18:04:05 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:05 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:05 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:06 --> Controller Class Initialized
INFO - 2016-10-16 18:04:06 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:06 --> Config Class Initialized
INFO - 2016-10-16 18:04:06 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:06 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:06 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:06 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:06 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:06 --> Router Class Initialized
INFO - 2016-10-16 18:04:06 --> Output Class Initialized
INFO - 2016-10-16 18:04:06 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:06 --> Input Class Initialized
INFO - 2016-10-16 18:04:06 --> Language Class Initialized
INFO - 2016-10-16 18:04:06 --> Loader Class Initialized
INFO - 2016-10-16 18:04:06 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:06 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:06 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:06 --> Controller Class Initialized
INFO - 2016-10-16 18:04:06 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:06 --> Config Class Initialized
INFO - 2016-10-16 18:04:06 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:06 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:06 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:06 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:06 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:06 --> Router Class Initialized
INFO - 2016-10-16 18:04:06 --> Output Class Initialized
INFO - 2016-10-16 18:04:06 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:06 --> Input Class Initialized
INFO - 2016-10-16 18:04:06 --> Language Class Initialized
INFO - 2016-10-16 18:04:06 --> Loader Class Initialized
INFO - 2016-10-16 18:04:06 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:06 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:06 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:06 --> Controller Class Initialized
INFO - 2016-10-16 18:04:06 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:06 --> Config Class Initialized
INFO - 2016-10-16 18:04:06 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:06 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:06 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:06 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:06 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:06 --> Router Class Initialized
INFO - 2016-10-16 18:04:06 --> Output Class Initialized
INFO - 2016-10-16 18:04:06 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:06 --> Input Class Initialized
INFO - 2016-10-16 18:04:06 --> Language Class Initialized
INFO - 2016-10-16 18:04:06 --> Loader Class Initialized
INFO - 2016-10-16 18:04:06 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:06 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:06 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:06 --> Controller Class Initialized
INFO - 2016-10-16 18:04:06 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:06 --> Config Class Initialized
INFO - 2016-10-16 18:04:06 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:06 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:06 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:06 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:06 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:06 --> Router Class Initialized
INFO - 2016-10-16 18:04:06 --> Output Class Initialized
INFO - 2016-10-16 18:04:06 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:06 --> Input Class Initialized
INFO - 2016-10-16 18:04:06 --> Language Class Initialized
INFO - 2016-10-16 18:04:06 --> Loader Class Initialized
INFO - 2016-10-16 18:04:07 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:07 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:07 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:07 --> Controller Class Initialized
INFO - 2016-10-16 18:04:07 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:07 --> Config Class Initialized
INFO - 2016-10-16 18:04:07 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:07 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:07 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:07 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:07 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:07 --> Router Class Initialized
INFO - 2016-10-16 18:04:07 --> Output Class Initialized
INFO - 2016-10-16 18:04:07 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:07 --> Input Class Initialized
INFO - 2016-10-16 18:04:07 --> Language Class Initialized
INFO - 2016-10-16 18:04:07 --> Loader Class Initialized
INFO - 2016-10-16 18:04:07 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:07 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:07 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:07 --> Controller Class Initialized
INFO - 2016-10-16 18:04:07 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:07 --> Config Class Initialized
INFO - 2016-10-16 18:04:07 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:07 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:07 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:07 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:07 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:07 --> Router Class Initialized
INFO - 2016-10-16 18:04:07 --> Output Class Initialized
INFO - 2016-10-16 18:04:07 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:07 --> Input Class Initialized
INFO - 2016-10-16 18:04:07 --> Language Class Initialized
INFO - 2016-10-16 18:04:07 --> Loader Class Initialized
INFO - 2016-10-16 18:04:07 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:07 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:07 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:07 --> Controller Class Initialized
INFO - 2016-10-16 18:04:07 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:25 --> Config Class Initialized
INFO - 2016-10-16 18:04:25 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:25 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:25 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:25 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:25 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:25 --> Router Class Initialized
INFO - 2016-10-16 18:04:25 --> Output Class Initialized
INFO - 2016-10-16 18:04:25 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:25 --> Input Class Initialized
INFO - 2016-10-16 18:04:25 --> Language Class Initialized
INFO - 2016-10-16 18:04:25 --> Loader Class Initialized
INFO - 2016-10-16 18:04:25 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:25 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:25 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:25 --> Controller Class Initialized
INFO - 2016-10-16 18:04:25 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:25 --> Config Class Initialized
INFO - 2016-10-16 18:04:25 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:25 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:25 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:25 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:25 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:25 --> Router Class Initialized
INFO - 2016-10-16 18:04:25 --> Output Class Initialized
INFO - 2016-10-16 18:04:25 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:25 --> Input Class Initialized
INFO - 2016-10-16 18:04:25 --> Language Class Initialized
INFO - 2016-10-16 18:04:25 --> Loader Class Initialized
INFO - 2016-10-16 18:04:25 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:25 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:25 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:25 --> Controller Class Initialized
INFO - 2016-10-16 18:04:25 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:25 --> Config Class Initialized
INFO - 2016-10-16 18:04:25 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:25 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:25 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:25 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:25 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:25 --> Router Class Initialized
INFO - 2016-10-16 18:04:25 --> Output Class Initialized
INFO - 2016-10-16 18:04:25 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:25 --> Input Class Initialized
INFO - 2016-10-16 18:04:25 --> Language Class Initialized
INFO - 2016-10-16 18:04:25 --> Loader Class Initialized
INFO - 2016-10-16 18:04:25 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:25 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:25 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:25 --> Controller Class Initialized
INFO - 2016-10-16 18:04:25 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:25 --> Config Class Initialized
INFO - 2016-10-16 18:04:25 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:25 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:25 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:25 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:25 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:25 --> Router Class Initialized
INFO - 2016-10-16 18:04:25 --> Output Class Initialized
INFO - 2016-10-16 18:04:25 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:25 --> Input Class Initialized
INFO - 2016-10-16 18:04:25 --> Language Class Initialized
INFO - 2016-10-16 18:04:25 --> Loader Class Initialized
INFO - 2016-10-16 18:04:25 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:25 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:25 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:26 --> Controller Class Initialized
INFO - 2016-10-16 18:04:26 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:26 --> Config Class Initialized
INFO - 2016-10-16 18:04:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:26 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:26 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:26 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:26 --> Router Class Initialized
INFO - 2016-10-16 18:04:26 --> Output Class Initialized
INFO - 2016-10-16 18:04:26 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:26 --> Input Class Initialized
INFO - 2016-10-16 18:04:26 --> Language Class Initialized
INFO - 2016-10-16 18:04:26 --> Loader Class Initialized
INFO - 2016-10-16 18:04:26 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:26 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:26 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:26 --> Controller Class Initialized
INFO - 2016-10-16 18:04:26 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:26 --> Config Class Initialized
INFO - 2016-10-16 18:04:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:26 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:26 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:26 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:26 --> Router Class Initialized
INFO - 2016-10-16 18:04:26 --> Output Class Initialized
INFO - 2016-10-16 18:04:26 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:26 --> Input Class Initialized
INFO - 2016-10-16 18:04:26 --> Language Class Initialized
INFO - 2016-10-16 18:04:26 --> Loader Class Initialized
INFO - 2016-10-16 18:04:26 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:26 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:26 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:26 --> Controller Class Initialized
INFO - 2016-10-16 18:04:26 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:26 --> Config Class Initialized
INFO - 2016-10-16 18:04:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:26 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:26 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:26 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:26 --> Router Class Initialized
INFO - 2016-10-16 18:04:26 --> Output Class Initialized
INFO - 2016-10-16 18:04:26 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:26 --> Input Class Initialized
INFO - 2016-10-16 18:04:26 --> Language Class Initialized
INFO - 2016-10-16 18:04:26 --> Loader Class Initialized
INFO - 2016-10-16 18:04:26 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:26 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:26 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:26 --> Controller Class Initialized
INFO - 2016-10-16 18:04:26 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:26 --> Config Class Initialized
INFO - 2016-10-16 18:04:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:26 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:26 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:26 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:26 --> Router Class Initialized
INFO - 2016-10-16 18:04:26 --> Output Class Initialized
INFO - 2016-10-16 18:04:26 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:26 --> Input Class Initialized
INFO - 2016-10-16 18:04:27 --> Language Class Initialized
INFO - 2016-10-16 18:04:27 --> Loader Class Initialized
INFO - 2016-10-16 18:04:27 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:27 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:27 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:27 --> Controller Class Initialized
INFO - 2016-10-16 18:04:27 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:27 --> Config Class Initialized
INFO - 2016-10-16 18:04:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:27 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:27 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:27 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:27 --> Router Class Initialized
INFO - 2016-10-16 18:04:27 --> Output Class Initialized
INFO - 2016-10-16 18:04:27 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:27 --> Input Class Initialized
INFO - 2016-10-16 18:04:27 --> Language Class Initialized
INFO - 2016-10-16 18:04:27 --> Loader Class Initialized
INFO - 2016-10-16 18:04:27 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:27 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:27 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:27 --> Controller Class Initialized
INFO - 2016-10-16 18:04:27 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:27 --> Config Class Initialized
INFO - 2016-10-16 18:04:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:27 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:27 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:27 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:27 --> Router Class Initialized
INFO - 2016-10-16 18:04:27 --> Output Class Initialized
INFO - 2016-10-16 18:04:27 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:27 --> Input Class Initialized
INFO - 2016-10-16 18:04:27 --> Language Class Initialized
INFO - 2016-10-16 18:04:27 --> Loader Class Initialized
INFO - 2016-10-16 18:04:27 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:27 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:27 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:27 --> Controller Class Initialized
INFO - 2016-10-16 18:04:27 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:27 --> Config Class Initialized
INFO - 2016-10-16 18:04:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:27 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:27 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:27 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:27 --> Router Class Initialized
INFO - 2016-10-16 18:04:27 --> Output Class Initialized
INFO - 2016-10-16 18:04:27 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:27 --> Input Class Initialized
INFO - 2016-10-16 18:04:27 --> Language Class Initialized
INFO - 2016-10-16 18:04:27 --> Loader Class Initialized
INFO - 2016-10-16 18:04:27 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:27 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:27 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:27 --> Controller Class Initialized
INFO - 2016-10-16 18:04:27 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:27 --> Config Class Initialized
INFO - 2016-10-16 18:04:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:27 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:27 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:27 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:28 --> Router Class Initialized
INFO - 2016-10-16 18:04:28 --> Output Class Initialized
INFO - 2016-10-16 18:04:28 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:28 --> Input Class Initialized
INFO - 2016-10-16 18:04:28 --> Language Class Initialized
INFO - 2016-10-16 18:04:28 --> Loader Class Initialized
INFO - 2016-10-16 18:04:28 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:28 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:28 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:28 --> Controller Class Initialized
INFO - 2016-10-16 18:04:28 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:28 --> Config Class Initialized
INFO - 2016-10-16 18:04:28 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:28 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:28 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:28 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:28 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:28 --> Router Class Initialized
INFO - 2016-10-16 18:04:28 --> Output Class Initialized
INFO - 2016-10-16 18:04:28 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:28 --> Input Class Initialized
INFO - 2016-10-16 18:04:28 --> Language Class Initialized
INFO - 2016-10-16 18:04:28 --> Loader Class Initialized
INFO - 2016-10-16 18:04:28 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:28 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:28 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:28 --> Controller Class Initialized
INFO - 2016-10-16 18:04:28 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:28 --> Config Class Initialized
INFO - 2016-10-16 18:04:28 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:28 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:28 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:28 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:28 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:28 --> Router Class Initialized
INFO - 2016-10-16 18:04:28 --> Output Class Initialized
INFO - 2016-10-16 18:04:28 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:28 --> Input Class Initialized
INFO - 2016-10-16 18:04:28 --> Language Class Initialized
INFO - 2016-10-16 18:04:28 --> Loader Class Initialized
INFO - 2016-10-16 18:04:28 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:28 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:28 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:28 --> Controller Class Initialized
INFO - 2016-10-16 18:04:28 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:28 --> Config Class Initialized
INFO - 2016-10-16 18:04:28 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:28 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:28 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:28 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:28 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:28 --> Router Class Initialized
INFO - 2016-10-16 18:04:28 --> Output Class Initialized
INFO - 2016-10-16 18:04:28 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:28 --> Input Class Initialized
INFO - 2016-10-16 18:04:28 --> Language Class Initialized
INFO - 2016-10-16 18:04:28 --> Loader Class Initialized
INFO - 2016-10-16 18:04:28 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:28 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:28 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:28 --> Controller Class Initialized
INFO - 2016-10-16 18:04:28 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:29 --> Config Class Initialized
INFO - 2016-10-16 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:29 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:29 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:29 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:29 --> Router Class Initialized
INFO - 2016-10-16 18:04:29 --> Output Class Initialized
INFO - 2016-10-16 18:04:29 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:29 --> Input Class Initialized
INFO - 2016-10-16 18:04:29 --> Language Class Initialized
INFO - 2016-10-16 18:04:29 --> Loader Class Initialized
INFO - 2016-10-16 18:04:29 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:29 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:29 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:29 --> Controller Class Initialized
INFO - 2016-10-16 18:04:29 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:29 --> Config Class Initialized
INFO - 2016-10-16 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:29 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:29 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:29 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:29 --> Router Class Initialized
INFO - 2016-10-16 18:04:29 --> Output Class Initialized
INFO - 2016-10-16 18:04:29 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:29 --> Input Class Initialized
INFO - 2016-10-16 18:04:29 --> Language Class Initialized
INFO - 2016-10-16 18:04:29 --> Loader Class Initialized
INFO - 2016-10-16 18:04:29 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:29 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:29 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:29 --> Controller Class Initialized
INFO - 2016-10-16 18:04:29 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:29 --> Config Class Initialized
INFO - 2016-10-16 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:29 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:29 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:29 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:29 --> Router Class Initialized
INFO - 2016-10-16 18:04:29 --> Output Class Initialized
INFO - 2016-10-16 18:04:29 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:29 --> Input Class Initialized
INFO - 2016-10-16 18:04:29 --> Language Class Initialized
INFO - 2016-10-16 18:04:29 --> Loader Class Initialized
INFO - 2016-10-16 18:04:29 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:29 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:29 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:29 --> Controller Class Initialized
INFO - 2016-10-16 18:04:29 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:29 --> Config Class Initialized
INFO - 2016-10-16 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:29 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:29 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:29 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:29 --> Router Class Initialized
INFO - 2016-10-16 18:04:29 --> Output Class Initialized
INFO - 2016-10-16 18:04:29 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:29 --> Input Class Initialized
INFO - 2016-10-16 18:04:29 --> Language Class Initialized
INFO - 2016-10-16 18:04:29 --> Loader Class Initialized
INFO - 2016-10-16 18:04:29 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:29 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:29 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:30 --> Controller Class Initialized
INFO - 2016-10-16 18:04:30 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:30 --> Config Class Initialized
INFO - 2016-10-16 18:04:30 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:30 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:30 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:30 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:30 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:30 --> Router Class Initialized
INFO - 2016-10-16 18:04:30 --> Output Class Initialized
INFO - 2016-10-16 18:04:30 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:30 --> Input Class Initialized
INFO - 2016-10-16 18:04:30 --> Language Class Initialized
INFO - 2016-10-16 18:04:30 --> Loader Class Initialized
INFO - 2016-10-16 18:04:30 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:30 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:30 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:30 --> Controller Class Initialized
INFO - 2016-10-16 18:04:30 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:46 --> Config Class Initialized
INFO - 2016-10-16 18:04:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:04:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:04:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:04:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:04:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:04:46 --> Router Class Initialized
INFO - 2016-10-16 18:04:46 --> Output Class Initialized
INFO - 2016-10-16 18:04:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:04:46 --> Input Class Initialized
INFO - 2016-10-16 18:04:46 --> Language Class Initialized
INFO - 2016-10-16 18:04:46 --> Loader Class Initialized
INFO - 2016-10-16 18:04:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:04:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:04:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:04:46 --> Controller Class Initialized
INFO - 2016-10-16 18:04:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:04:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:04:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:04:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:04:46 --> Final output sent to browser
DEBUG - 2016-10-16 18:04:46 --> Total execution time: 0.3162
INFO - 2016-10-16 18:06:17 --> Config Class Initialized
INFO - 2016-10-16 18:06:17 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:06:17 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:06:17 --> Utf8 Class Initialized
INFO - 2016-10-16 18:06:17 --> URI Class Initialized
DEBUG - 2016-10-16 18:06:17 --> No URI present. Default controller set.
INFO - 2016-10-16 18:06:17 --> Router Class Initialized
INFO - 2016-10-16 18:06:17 --> Output Class Initialized
INFO - 2016-10-16 18:06:17 --> Security Class Initialized
DEBUG - 2016-10-16 18:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:06:17 --> Input Class Initialized
INFO - 2016-10-16 18:06:17 --> Language Class Initialized
INFO - 2016-10-16 18:06:17 --> Loader Class Initialized
INFO - 2016-10-16 18:06:17 --> Helper loaded: url_helper
INFO - 2016-10-16 18:06:17 --> Helper loaded: form_helper
INFO - 2016-10-16 18:06:17 --> Database Driver Class Initialized
INFO - 2016-10-16 18:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:06:17 --> Controller Class Initialized
INFO - 2016-10-16 18:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:06:17 --> Form Validation Class Initialized
INFO - 2016-10-16 18:06:17 --> Final output sent to browser
DEBUG - 2016-10-16 18:06:17 --> Total execution time: 0.3088
INFO - 2016-10-16 18:06:27 --> Config Class Initialized
INFO - 2016-10-16 18:06:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:06:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:06:27 --> Utf8 Class Initialized
INFO - 2016-10-16 18:06:27 --> URI Class Initialized
DEBUG - 2016-10-16 18:06:27 --> No URI present. Default controller set.
INFO - 2016-10-16 18:06:27 --> Router Class Initialized
INFO - 2016-10-16 18:06:27 --> Output Class Initialized
INFO - 2016-10-16 18:06:27 --> Security Class Initialized
DEBUG - 2016-10-16 18:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:06:27 --> Input Class Initialized
INFO - 2016-10-16 18:06:27 --> Language Class Initialized
INFO - 2016-10-16 18:06:27 --> Loader Class Initialized
INFO - 2016-10-16 18:06:27 --> Helper loaded: url_helper
INFO - 2016-10-16 18:06:27 --> Helper loaded: form_helper
INFO - 2016-10-16 18:06:27 --> Database Driver Class Initialized
INFO - 2016-10-16 18:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:06:27 --> Controller Class Initialized
INFO - 2016-10-16 18:06:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:06:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:06:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:06:27 --> Form Validation Class Initialized
INFO - 2016-10-16 18:06:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:06:27 --> Model Class Initialized
ERROR - 2016-10-16 18:06:27 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 18:06:27 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
ERROR - 2016-10-16 18:06:27 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 39
INFO - 2016-10-16 18:07:03 --> Config Class Initialized
INFO - 2016-10-16 18:07:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:07:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:07:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:07:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:07:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:07:03 --> Router Class Initialized
INFO - 2016-10-16 18:07:04 --> Output Class Initialized
INFO - 2016-10-16 18:07:04 --> Security Class Initialized
DEBUG - 2016-10-16 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:07:04 --> Input Class Initialized
INFO - 2016-10-16 18:07:04 --> Language Class Initialized
INFO - 2016-10-16 18:07:04 --> Loader Class Initialized
INFO - 2016-10-16 18:07:04 --> Helper loaded: url_helper
INFO - 2016-10-16 18:07:04 --> Helper loaded: form_helper
INFO - 2016-10-16 18:07:04 --> Database Driver Class Initialized
INFO - 2016-10-16 18:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:07:04 --> Controller Class Initialized
INFO - 2016-10-16 18:07:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:07:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:07:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:07:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:07:04 --> Form Validation Class Initialized
INFO - 2016-10-16 18:07:04 --> Final output sent to browser
DEBUG - 2016-10-16 18:07:04 --> Total execution time: 0.2875
INFO - 2016-10-16 18:07:07 --> Config Class Initialized
INFO - 2016-10-16 18:07:07 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:07:07 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:07:07 --> Utf8 Class Initialized
INFO - 2016-10-16 18:07:07 --> URI Class Initialized
INFO - 2016-10-16 18:07:07 --> Router Class Initialized
INFO - 2016-10-16 18:07:07 --> Output Class Initialized
INFO - 2016-10-16 18:07:07 --> Security Class Initialized
DEBUG - 2016-10-16 18:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:07:07 --> Input Class Initialized
INFO - 2016-10-16 18:07:07 --> Language Class Initialized
INFO - 2016-10-16 18:07:08 --> Loader Class Initialized
INFO - 2016-10-16 18:07:08 --> Helper loaded: url_helper
INFO - 2016-10-16 18:07:08 --> Helper loaded: form_helper
INFO - 2016-10-16 18:07:08 --> Database Driver Class Initialized
INFO - 2016-10-16 18:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:07:08 --> Controller Class Initialized
INFO - 2016-10-16 18:07:10 --> Config Class Initialized
INFO - 2016-10-16 18:07:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:07:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:07:10 --> Utf8 Class Initialized
INFO - 2016-10-16 18:07:10 --> URI Class Initialized
DEBUG - 2016-10-16 18:07:10 --> No URI present. Default controller set.
INFO - 2016-10-16 18:07:10 --> Router Class Initialized
INFO - 2016-10-16 18:07:10 --> Output Class Initialized
INFO - 2016-10-16 18:07:10 --> Security Class Initialized
DEBUG - 2016-10-16 18:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:07:10 --> Input Class Initialized
INFO - 2016-10-16 18:07:10 --> Language Class Initialized
INFO - 2016-10-16 18:07:10 --> Loader Class Initialized
INFO - 2016-10-16 18:07:10 --> Helper loaded: url_helper
INFO - 2016-10-16 18:07:10 --> Helper loaded: form_helper
INFO - 2016-10-16 18:07:10 --> Database Driver Class Initialized
INFO - 2016-10-16 18:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:07:10 --> Controller Class Initialized
INFO - 2016-10-16 18:07:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:07:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:07:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:07:10 --> Form Validation Class Initialized
INFO - 2016-10-16 18:07:10 --> Final output sent to browser
DEBUG - 2016-10-16 18:07:10 --> Total execution time: 0.3140
INFO - 2016-10-16 18:07:18 --> Config Class Initialized
INFO - 2016-10-16 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:07:18 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:07:18 --> Utf8 Class Initialized
INFO - 2016-10-16 18:07:18 --> URI Class Initialized
DEBUG - 2016-10-16 18:07:18 --> No URI present. Default controller set.
INFO - 2016-10-16 18:07:18 --> Router Class Initialized
INFO - 2016-10-16 18:07:18 --> Output Class Initialized
INFO - 2016-10-16 18:07:18 --> Security Class Initialized
DEBUG - 2016-10-16 18:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:07:18 --> Input Class Initialized
INFO - 2016-10-16 18:07:18 --> Language Class Initialized
INFO - 2016-10-16 18:07:18 --> Loader Class Initialized
INFO - 2016-10-16 18:07:18 --> Helper loaded: url_helper
INFO - 2016-10-16 18:07:18 --> Helper loaded: form_helper
INFO - 2016-10-16 18:07:18 --> Database Driver Class Initialized
INFO - 2016-10-16 18:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:07:18 --> Controller Class Initialized
INFO - 2016-10-16 18:07:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:07:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:07:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:07:18 --> Form Validation Class Initialized
INFO - 2016-10-16 18:07:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:07:18 --> Model Class Initialized
ERROR - 2016-10-16 18:07:18 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 18:07:19 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
ERROR - 2016-10-16 18:07:19 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 39
INFO - 2016-10-16 18:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:07:19 --> Final output sent to browser
DEBUG - 2016-10-16 18:07:19 --> Total execution time: 0.4565
INFO - 2016-10-16 18:07:28 --> Config Class Initialized
INFO - 2016-10-16 18:07:28 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:07:28 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:07:28 --> Utf8 Class Initialized
INFO - 2016-10-16 18:07:28 --> URI Class Initialized
INFO - 2016-10-16 18:07:28 --> Router Class Initialized
INFO - 2016-10-16 18:07:28 --> Output Class Initialized
INFO - 2016-10-16 18:07:28 --> Security Class Initialized
DEBUG - 2016-10-16 18:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:07:28 --> Input Class Initialized
INFO - 2016-10-16 18:07:28 --> Language Class Initialized
INFO - 2016-10-16 18:07:28 --> Loader Class Initialized
INFO - 2016-10-16 18:07:28 --> Helper loaded: url_helper
INFO - 2016-10-16 18:07:28 --> Helper loaded: form_helper
INFO - 2016-10-16 18:07:28 --> Database Driver Class Initialized
INFO - 2016-10-16 18:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:07:28 --> Controller Class Initialized
INFO - 2016-10-16 18:08:17 --> Config Class Initialized
INFO - 2016-10-16 18:08:17 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:08:17 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:08:17 --> Utf8 Class Initialized
INFO - 2016-10-16 18:08:17 --> URI Class Initialized
DEBUG - 2016-10-16 18:08:17 --> No URI present. Default controller set.
INFO - 2016-10-16 18:08:17 --> Router Class Initialized
INFO - 2016-10-16 18:08:17 --> Output Class Initialized
INFO - 2016-10-16 18:08:17 --> Security Class Initialized
DEBUG - 2016-10-16 18:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:08:17 --> Input Class Initialized
INFO - 2016-10-16 18:08:17 --> Language Class Initialized
INFO - 2016-10-16 18:08:17 --> Loader Class Initialized
INFO - 2016-10-16 18:08:17 --> Helper loaded: url_helper
INFO - 2016-10-16 18:08:17 --> Helper loaded: form_helper
INFO - 2016-10-16 18:08:17 --> Database Driver Class Initialized
INFO - 2016-10-16 18:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:08:17 --> Controller Class Initialized
INFO - 2016-10-16 18:08:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:08:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:08:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:08:17 --> Form Validation Class Initialized
INFO - 2016-10-16 18:08:17 --> Final output sent to browser
DEBUG - 2016-10-16 18:08:17 --> Total execution time: 0.2978
INFO - 2016-10-16 18:08:24 --> Config Class Initialized
INFO - 2016-10-16 18:08:24 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:08:24 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:08:24 --> Utf8 Class Initialized
INFO - 2016-10-16 18:08:24 --> URI Class Initialized
DEBUG - 2016-10-16 18:08:24 --> No URI present. Default controller set.
INFO - 2016-10-16 18:08:24 --> Router Class Initialized
INFO - 2016-10-16 18:08:24 --> Output Class Initialized
INFO - 2016-10-16 18:08:24 --> Security Class Initialized
DEBUG - 2016-10-16 18:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:08:24 --> Input Class Initialized
INFO - 2016-10-16 18:08:24 --> Language Class Initialized
INFO - 2016-10-16 18:08:24 --> Loader Class Initialized
INFO - 2016-10-16 18:08:24 --> Helper loaded: url_helper
INFO - 2016-10-16 18:08:25 --> Helper loaded: form_helper
INFO - 2016-10-16 18:08:25 --> Database Driver Class Initialized
INFO - 2016-10-16 18:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:08:25 --> Controller Class Initialized
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:08:25 --> Form Validation Class Initialized
INFO - 2016-10-16 18:08:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:08:25 --> Model Class Initialized
ERROR - 2016-10-16 18:08:25 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 18:08:25 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
ERROR - 2016-10-16 18:08:25 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 39
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:08:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:08:25 --> Final output sent to browser
DEBUG - 2016-10-16 18:08:25 --> Total execution time: 0.4370
INFO - 2016-10-16 18:08:33 --> Config Class Initialized
INFO - 2016-10-16 18:08:33 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:08:33 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:08:33 --> Utf8 Class Initialized
INFO - 2016-10-16 18:08:33 --> URI Class Initialized
INFO - 2016-10-16 18:08:33 --> Router Class Initialized
INFO - 2016-10-16 18:08:33 --> Output Class Initialized
INFO - 2016-10-16 18:08:33 --> Security Class Initialized
DEBUG - 2016-10-16 18:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:08:33 --> Input Class Initialized
INFO - 2016-10-16 18:08:33 --> Language Class Initialized
INFO - 2016-10-16 18:08:33 --> Loader Class Initialized
INFO - 2016-10-16 18:08:33 --> Helper loaded: url_helper
INFO - 2016-10-16 18:08:33 --> Helper loaded: form_helper
INFO - 2016-10-16 18:08:33 --> Database Driver Class Initialized
INFO - 2016-10-16 18:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:08:33 --> Controller Class Initialized
INFO - 2016-10-16 18:08:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:08:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:08:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:08:33 --> Final output sent to browser
DEBUG - 2016-10-16 18:08:33 --> Total execution time: 0.2917
INFO - 2016-10-16 18:09:24 --> Config Class Initialized
INFO - 2016-10-16 18:09:24 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:09:24 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:09:24 --> Utf8 Class Initialized
INFO - 2016-10-16 18:09:24 --> URI Class Initialized
DEBUG - 2016-10-16 18:09:24 --> No URI present. Default controller set.
INFO - 2016-10-16 18:09:24 --> Router Class Initialized
INFO - 2016-10-16 18:09:24 --> Output Class Initialized
INFO - 2016-10-16 18:09:24 --> Security Class Initialized
DEBUG - 2016-10-16 18:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:09:24 --> Input Class Initialized
INFO - 2016-10-16 18:09:24 --> Language Class Initialized
INFO - 2016-10-16 18:09:24 --> Loader Class Initialized
INFO - 2016-10-16 18:09:24 --> Helper loaded: url_helper
INFO - 2016-10-16 18:09:24 --> Helper loaded: form_helper
INFO - 2016-10-16 18:09:24 --> Database Driver Class Initialized
INFO - 2016-10-16 18:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:09:24 --> Controller Class Initialized
INFO - 2016-10-16 18:09:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:09:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:09:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:09:24 --> Form Validation Class Initialized
INFO - 2016-10-16 18:09:24 --> Final output sent to browser
DEBUG - 2016-10-16 18:09:24 --> Total execution time: 0.2963
INFO - 2016-10-16 18:09:27 --> Config Class Initialized
INFO - 2016-10-16 18:09:27 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:09:27 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:09:27 --> Utf8 Class Initialized
INFO - 2016-10-16 18:09:27 --> URI Class Initialized
DEBUG - 2016-10-16 18:09:27 --> No URI present. Default controller set.
INFO - 2016-10-16 18:09:27 --> Router Class Initialized
INFO - 2016-10-16 18:09:27 --> Output Class Initialized
INFO - 2016-10-16 18:09:27 --> Security Class Initialized
DEBUG - 2016-10-16 18:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:09:27 --> Input Class Initialized
INFO - 2016-10-16 18:09:27 --> Language Class Initialized
INFO - 2016-10-16 18:09:27 --> Loader Class Initialized
INFO - 2016-10-16 18:09:27 --> Helper loaded: url_helper
INFO - 2016-10-16 18:09:27 --> Helper loaded: form_helper
INFO - 2016-10-16 18:09:27 --> Database Driver Class Initialized
INFO - 2016-10-16 18:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:09:27 --> Controller Class Initialized
INFO - 2016-10-16 18:09:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:09:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:09:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:09:27 --> Form Validation Class Initialized
INFO - 2016-10-16 18:09:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:09:27 --> Model Class Initialized
ERROR - 2016-10-16 18:09:27 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:09:27 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 36
INFO - 2016-10-16 18:09:27 --> Final output sent to browser
DEBUG - 2016-10-16 18:09:27 --> Total execution time: 0.3859
INFO - 2016-10-16 18:20:16 --> Config Class Initialized
INFO - 2016-10-16 18:20:16 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:20:16 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:20:16 --> Utf8 Class Initialized
INFO - 2016-10-16 18:20:16 --> URI Class Initialized
INFO - 2016-10-16 18:20:16 --> Router Class Initialized
INFO - 2016-10-16 18:20:16 --> Output Class Initialized
INFO - 2016-10-16 18:20:16 --> Security Class Initialized
DEBUG - 2016-10-16 18:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:20:16 --> Input Class Initialized
INFO - 2016-10-16 18:20:16 --> Language Class Initialized
INFO - 2016-10-16 18:20:16 --> Loader Class Initialized
INFO - 2016-10-16 18:20:16 --> Helper loaded: url_helper
INFO - 2016-10-16 18:20:16 --> Helper loaded: form_helper
INFO - 2016-10-16 18:20:16 --> Database Driver Class Initialized
INFO - 2016-10-16 18:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:20:16 --> Controller Class Initialized
INFO - 2016-10-16 18:20:16 --> Form Validation Class Initialized
INFO - 2016-10-16 18:20:16 --> Config Class Initialized
INFO - 2016-10-16 18:20:16 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:20:16 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:20:16 --> Utf8 Class Initialized
INFO - 2016-10-16 18:20:16 --> URI Class Initialized
DEBUG - 2016-10-16 18:20:16 --> No URI present. Default controller set.
INFO - 2016-10-16 18:20:16 --> Router Class Initialized
INFO - 2016-10-16 18:20:16 --> Output Class Initialized
INFO - 2016-10-16 18:20:17 --> Security Class Initialized
DEBUG - 2016-10-16 18:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:20:17 --> Input Class Initialized
INFO - 2016-10-16 18:20:17 --> Language Class Initialized
INFO - 2016-10-16 18:20:17 --> Loader Class Initialized
INFO - 2016-10-16 18:20:17 --> Helper loaded: url_helper
INFO - 2016-10-16 18:20:17 --> Helper loaded: form_helper
INFO - 2016-10-16 18:20:17 --> Database Driver Class Initialized
INFO - 2016-10-16 18:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:20:17 --> Controller Class Initialized
INFO - 2016-10-16 18:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:20:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:20:17 --> Final output sent to browser
DEBUG - 2016-10-16 18:20:17 --> Total execution time: 0.2843
INFO - 2016-10-16 18:20:29 --> Config Class Initialized
INFO - 2016-10-16 18:20:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:20:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:20:29 --> Utf8 Class Initialized
INFO - 2016-10-16 18:20:29 --> URI Class Initialized
DEBUG - 2016-10-16 18:20:29 --> No URI present. Default controller set.
INFO - 2016-10-16 18:20:29 --> Router Class Initialized
INFO - 2016-10-16 18:20:29 --> Output Class Initialized
INFO - 2016-10-16 18:20:29 --> Security Class Initialized
DEBUG - 2016-10-16 18:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:20:29 --> Input Class Initialized
INFO - 2016-10-16 18:20:29 --> Language Class Initialized
INFO - 2016-10-16 18:20:29 --> Loader Class Initialized
INFO - 2016-10-16 18:20:29 --> Helper loaded: url_helper
INFO - 2016-10-16 18:20:29 --> Helper loaded: form_helper
INFO - 2016-10-16 18:20:29 --> Database Driver Class Initialized
INFO - 2016-10-16 18:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:20:29 --> Controller Class Initialized
INFO - 2016-10-16 18:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:20:29 --> Final output sent to browser
DEBUG - 2016-10-16 18:20:29 --> Total execution time: 0.2998
INFO - 2016-10-16 18:20:39 --> Config Class Initialized
INFO - 2016-10-16 18:20:40 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:20:40 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:20:40 --> Utf8 Class Initialized
INFO - 2016-10-16 18:20:40 --> URI Class Initialized
DEBUG - 2016-10-16 18:20:40 --> No URI present. Default controller set.
INFO - 2016-10-16 18:20:40 --> Router Class Initialized
INFO - 2016-10-16 18:20:40 --> Output Class Initialized
INFO - 2016-10-16 18:20:40 --> Security Class Initialized
DEBUG - 2016-10-16 18:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:20:40 --> Input Class Initialized
INFO - 2016-10-16 18:20:40 --> Language Class Initialized
INFO - 2016-10-16 18:20:40 --> Loader Class Initialized
INFO - 2016-10-16 18:20:40 --> Helper loaded: url_helper
INFO - 2016-10-16 18:20:40 --> Helper loaded: form_helper
INFO - 2016-10-16 18:20:40 --> Database Driver Class Initialized
INFO - 2016-10-16 18:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:20:40 --> Controller Class Initialized
INFO - 2016-10-16 18:20:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:20:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:20:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:20:40 --> Final output sent to browser
DEBUG - 2016-10-16 18:20:40 --> Total execution time: 0.3287
INFO - 2016-10-16 18:20:41 --> Config Class Initialized
INFO - 2016-10-16 18:20:41 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:20:41 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:20:41 --> Utf8 Class Initialized
INFO - 2016-10-16 18:20:41 --> URI Class Initialized
DEBUG - 2016-10-16 18:20:41 --> No URI present. Default controller set.
INFO - 2016-10-16 18:20:41 --> Router Class Initialized
INFO - 2016-10-16 18:20:41 --> Output Class Initialized
INFO - 2016-10-16 18:20:41 --> Security Class Initialized
DEBUG - 2016-10-16 18:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:20:41 --> Input Class Initialized
INFO - 2016-10-16 18:20:41 --> Language Class Initialized
INFO - 2016-10-16 18:20:41 --> Loader Class Initialized
INFO - 2016-10-16 18:20:41 --> Helper loaded: url_helper
INFO - 2016-10-16 18:20:41 --> Helper loaded: form_helper
INFO - 2016-10-16 18:20:41 --> Database Driver Class Initialized
INFO - 2016-10-16 18:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:20:42 --> Controller Class Initialized
INFO - 2016-10-16 18:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:20:42 --> Final output sent to browser
DEBUG - 2016-10-16 18:20:42 --> Total execution time: 0.3377
INFO - 2016-10-16 18:22:45 --> Config Class Initialized
INFO - 2016-10-16 18:22:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:22:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:22:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:22:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:22:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:22:45 --> Router Class Initialized
INFO - 2016-10-16 18:22:45 --> Output Class Initialized
INFO - 2016-10-16 18:22:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:22:45 --> Input Class Initialized
INFO - 2016-10-16 18:22:46 --> Language Class Initialized
INFO - 2016-10-16 18:22:46 --> Loader Class Initialized
INFO - 2016-10-16 18:22:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:22:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:22:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:22:46 --> Controller Class Initialized
INFO - 2016-10-16 18:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:22:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:22:46 --> Final output sent to browser
DEBUG - 2016-10-16 18:22:46 --> Total execution time: 0.3177
INFO - 2016-10-16 18:22:53 --> Config Class Initialized
INFO - 2016-10-16 18:22:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:22:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:22:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:22:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:22:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:22:53 --> Router Class Initialized
INFO - 2016-10-16 18:22:53 --> Output Class Initialized
INFO - 2016-10-16 18:22:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:22:53 --> Input Class Initialized
INFO - 2016-10-16 18:22:53 --> Language Class Initialized
INFO - 2016-10-16 18:22:53 --> Loader Class Initialized
INFO - 2016-10-16 18:22:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:22:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:22:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:22:54 --> Controller Class Initialized
INFO - 2016-10-16 18:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:22:54 --> Final output sent to browser
DEBUG - 2016-10-16 18:22:54 --> Total execution time: 0.3173
INFO - 2016-10-16 18:29:25 --> Config Class Initialized
INFO - 2016-10-16 18:29:25 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:29:25 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:29:25 --> Utf8 Class Initialized
INFO - 2016-10-16 18:29:25 --> URI Class Initialized
DEBUG - 2016-10-16 18:29:25 --> No URI present. Default controller set.
INFO - 2016-10-16 18:29:25 --> Router Class Initialized
INFO - 2016-10-16 18:29:25 --> Output Class Initialized
INFO - 2016-10-16 18:29:25 --> Security Class Initialized
DEBUG - 2016-10-16 18:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:29:25 --> Input Class Initialized
INFO - 2016-10-16 18:29:25 --> Language Class Initialized
INFO - 2016-10-16 18:29:25 --> Loader Class Initialized
INFO - 2016-10-16 18:29:25 --> Helper loaded: url_helper
INFO - 2016-10-16 18:29:25 --> Helper loaded: form_helper
INFO - 2016-10-16 18:29:25 --> Database Driver Class Initialized
INFO - 2016-10-16 18:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:29:25 --> Controller Class Initialized
INFO - 2016-10-16 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:29:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:29:25 --> Final output sent to browser
DEBUG - 2016-10-16 18:29:25 --> Total execution time: 0.3298
INFO - 2016-10-16 18:30:08 --> Config Class Initialized
INFO - 2016-10-16 18:30:08 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:08 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:08 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:08 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:08 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:08 --> Router Class Initialized
INFO - 2016-10-16 18:30:08 --> Output Class Initialized
INFO - 2016-10-16 18:30:08 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:08 --> Input Class Initialized
INFO - 2016-10-16 18:30:08 --> Language Class Initialized
INFO - 2016-10-16 18:30:08 --> Loader Class Initialized
INFO - 2016-10-16 18:30:08 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:08 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:08 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:08 --> Controller Class Initialized
INFO - 2016-10-16 18:30:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:08 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:08 --> Total execution time: 0.3276
INFO - 2016-10-16 18:30:10 --> Config Class Initialized
INFO - 2016-10-16 18:30:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:10 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:10 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:10 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:10 --> Router Class Initialized
INFO - 2016-10-16 18:30:10 --> Output Class Initialized
INFO - 2016-10-16 18:30:10 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:10 --> Input Class Initialized
INFO - 2016-10-16 18:30:10 --> Language Class Initialized
INFO - 2016-10-16 18:30:10 --> Loader Class Initialized
INFO - 2016-10-16 18:30:10 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:10 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:10 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:10 --> Controller Class Initialized
INFO - 2016-10-16 18:30:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:10 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:10 --> Total execution time: 0.3446
INFO - 2016-10-16 18:30:11 --> Config Class Initialized
INFO - 2016-10-16 18:30:11 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:11 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:11 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:11 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:11 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:11 --> Router Class Initialized
INFO - 2016-10-16 18:30:11 --> Output Class Initialized
INFO - 2016-10-16 18:30:11 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:11 --> Input Class Initialized
INFO - 2016-10-16 18:30:11 --> Language Class Initialized
INFO - 2016-10-16 18:30:11 --> Loader Class Initialized
INFO - 2016-10-16 18:30:11 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:11 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:11 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:11 --> Controller Class Initialized
INFO - 2016-10-16 18:30:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:11 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:11 --> Total execution time: 0.3110
INFO - 2016-10-16 18:30:11 --> Config Class Initialized
INFO - 2016-10-16 18:30:11 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:11 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:11 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:11 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:11 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:11 --> Router Class Initialized
INFO - 2016-10-16 18:30:11 --> Output Class Initialized
INFO - 2016-10-16 18:30:11 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:11 --> Input Class Initialized
INFO - 2016-10-16 18:30:11 --> Language Class Initialized
INFO - 2016-10-16 18:30:11 --> Loader Class Initialized
INFO - 2016-10-16 18:30:11 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:12 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:12 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:12 --> Controller Class Initialized
INFO - 2016-10-16 18:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:12 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:12 --> Total execution time: 0.3280
INFO - 2016-10-16 18:30:17 --> Config Class Initialized
INFO - 2016-10-16 18:30:17 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:17 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:17 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:17 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:17 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:17 --> Router Class Initialized
INFO - 2016-10-16 18:30:17 --> Output Class Initialized
INFO - 2016-10-16 18:30:17 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:17 --> Input Class Initialized
INFO - 2016-10-16 18:30:17 --> Language Class Initialized
INFO - 2016-10-16 18:30:17 --> Loader Class Initialized
INFO - 2016-10-16 18:30:17 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:17 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:17 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:17 --> Controller Class Initialized
INFO - 2016-10-16 18:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:17 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:17 --> Total execution time: 0.3123
INFO - 2016-10-16 18:30:18 --> Config Class Initialized
INFO - 2016-10-16 18:30:18 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:18 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:18 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:18 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:18 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:18 --> Router Class Initialized
INFO - 2016-10-16 18:30:18 --> Output Class Initialized
INFO - 2016-10-16 18:30:18 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:18 --> Input Class Initialized
INFO - 2016-10-16 18:30:18 --> Language Class Initialized
INFO - 2016-10-16 18:30:18 --> Loader Class Initialized
INFO - 2016-10-16 18:30:18 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:18 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:18 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:18 --> Controller Class Initialized
INFO - 2016-10-16 18:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:18 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:18 --> Total execution time: 0.3432
INFO - 2016-10-16 18:30:19 --> Config Class Initialized
INFO - 2016-10-16 18:30:19 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:20 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:20 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:20 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:20 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:20 --> Router Class Initialized
INFO - 2016-10-16 18:30:20 --> Output Class Initialized
INFO - 2016-10-16 18:30:20 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:20 --> Input Class Initialized
INFO - 2016-10-16 18:30:20 --> Language Class Initialized
INFO - 2016-10-16 18:30:20 --> Loader Class Initialized
INFO - 2016-10-16 18:30:20 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:20 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:20 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:20 --> Controller Class Initialized
INFO - 2016-10-16 18:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:20 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:20 --> Total execution time: 0.3546
INFO - 2016-10-16 18:30:45 --> Config Class Initialized
INFO - 2016-10-16 18:30:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:45 --> URI Class Initialized
INFO - 2016-10-16 18:30:45 --> Router Class Initialized
INFO - 2016-10-16 18:30:45 --> Output Class Initialized
INFO - 2016-10-16 18:30:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:45 --> Input Class Initialized
INFO - 2016-10-16 18:30:45 --> Language Class Initialized
INFO - 2016-10-16 18:30:45 --> Loader Class Initialized
INFO - 2016-10-16 18:30:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:45 --> Controller Class Initialized
INFO - 2016-10-16 18:30:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:30:45 --> Config Class Initialized
INFO - 2016-10-16 18:30:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:30:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:30:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:30:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:30:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:30:45 --> Router Class Initialized
INFO - 2016-10-16 18:30:45 --> Output Class Initialized
INFO - 2016-10-16 18:30:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:30:45 --> Input Class Initialized
INFO - 2016-10-16 18:30:45 --> Language Class Initialized
INFO - 2016-10-16 18:30:45 --> Loader Class Initialized
INFO - 2016-10-16 18:30:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:30:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:30:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:30:45 --> Controller Class Initialized
INFO - 2016-10-16 18:30:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:30:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:30:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:30:46 --> Final output sent to browser
DEBUG - 2016-10-16 18:30:46 --> Total execution time: 0.2769
INFO - 2016-10-16 18:31:00 --> Config Class Initialized
INFO - 2016-10-16 18:31:00 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:31:00 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:31:00 --> Utf8 Class Initialized
INFO - 2016-10-16 18:31:00 --> URI Class Initialized
DEBUG - 2016-10-16 18:31:00 --> No URI present. Default controller set.
INFO - 2016-10-16 18:31:00 --> Router Class Initialized
INFO - 2016-10-16 18:31:00 --> Output Class Initialized
INFO - 2016-10-16 18:31:00 --> Security Class Initialized
DEBUG - 2016-10-16 18:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:31:00 --> Input Class Initialized
INFO - 2016-10-16 18:31:00 --> Language Class Initialized
INFO - 2016-10-16 18:31:00 --> Loader Class Initialized
INFO - 2016-10-16 18:31:00 --> Helper loaded: url_helper
INFO - 2016-10-16 18:31:00 --> Helper loaded: form_helper
INFO - 2016-10-16 18:31:00 --> Database Driver Class Initialized
INFO - 2016-10-16 18:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:31:00 --> Controller Class Initialized
INFO - 2016-10-16 18:31:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:31:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:31:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:31:00 --> Final output sent to browser
DEBUG - 2016-10-16 18:31:00 --> Total execution time: 0.3203
INFO - 2016-10-16 18:31:03 --> Config Class Initialized
INFO - 2016-10-16 18:31:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:31:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:31:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:31:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:31:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:31:03 --> Router Class Initialized
INFO - 2016-10-16 18:31:03 --> Output Class Initialized
INFO - 2016-10-16 18:31:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:31:03 --> Input Class Initialized
INFO - 2016-10-16 18:31:03 --> Language Class Initialized
INFO - 2016-10-16 18:31:03 --> Loader Class Initialized
INFO - 2016-10-16 18:31:03 --> Helper loaded: url_helper
INFO - 2016-10-16 18:31:03 --> Helper loaded: form_helper
INFO - 2016-10-16 18:31:03 --> Database Driver Class Initialized
INFO - 2016-10-16 18:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:31:03 --> Controller Class Initialized
INFO - 2016-10-16 18:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:31:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:31:03 --> Final output sent to browser
DEBUG - 2016-10-16 18:31:03 --> Total execution time: 0.3097
INFO - 2016-10-16 18:31:03 --> Config Class Initialized
INFO - 2016-10-16 18:31:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:31:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:31:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:31:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:31:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:31:03 --> Router Class Initialized
INFO - 2016-10-16 18:31:03 --> Output Class Initialized
INFO - 2016-10-16 18:31:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:31:03 --> Input Class Initialized
INFO - 2016-10-16 18:31:04 --> Language Class Initialized
INFO - 2016-10-16 18:31:04 --> Loader Class Initialized
INFO - 2016-10-16 18:31:04 --> Helper loaded: url_helper
INFO - 2016-10-16 18:31:04 --> Helper loaded: form_helper
INFO - 2016-10-16 18:31:04 --> Database Driver Class Initialized
INFO - 2016-10-16 18:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:31:04 --> Controller Class Initialized
INFO - 2016-10-16 18:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:31:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:31:04 --> Final output sent to browser
DEBUG - 2016-10-16 18:31:04 --> Total execution time: 0.3085
INFO - 2016-10-16 18:31:04 --> Config Class Initialized
INFO - 2016-10-16 18:31:04 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:31:04 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:31:05 --> Utf8 Class Initialized
INFO - 2016-10-16 18:31:05 --> URI Class Initialized
DEBUG - 2016-10-16 18:31:05 --> No URI present. Default controller set.
INFO - 2016-10-16 18:31:05 --> Router Class Initialized
INFO - 2016-10-16 18:31:05 --> Output Class Initialized
INFO - 2016-10-16 18:31:05 --> Security Class Initialized
DEBUG - 2016-10-16 18:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:31:05 --> Input Class Initialized
INFO - 2016-10-16 18:31:05 --> Language Class Initialized
INFO - 2016-10-16 18:31:05 --> Loader Class Initialized
INFO - 2016-10-16 18:31:05 --> Helper loaded: url_helper
INFO - 2016-10-16 18:31:05 --> Helper loaded: form_helper
INFO - 2016-10-16 18:31:05 --> Database Driver Class Initialized
INFO - 2016-10-16 18:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:31:05 --> Controller Class Initialized
INFO - 2016-10-16 18:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:31:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:31:05 --> Final output sent to browser
DEBUG - 2016-10-16 18:31:05 --> Total execution time: 0.3121
INFO - 2016-10-16 18:32:51 --> Config Class Initialized
INFO - 2016-10-16 18:32:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:51 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:51 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:51 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:51 --> Router Class Initialized
INFO - 2016-10-16 18:32:51 --> Output Class Initialized
INFO - 2016-10-16 18:32:51 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:51 --> Input Class Initialized
INFO - 2016-10-16 18:32:51 --> Language Class Initialized
INFO - 2016-10-16 18:32:51 --> Loader Class Initialized
INFO - 2016-10-16 18:32:51 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:51 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:51 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:51 --> Controller Class Initialized
INFO - 2016-10-16 18:32:51 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:32:51 --> Model Class Initialized
ERROR - 2016-10-16 18:32:51 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:32:51 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 47
INFO - 2016-10-16 18:32:51 --> Config Class Initialized
INFO - 2016-10-16 18:32:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:51 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:51 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:51 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:51 --> Router Class Initialized
INFO - 2016-10-16 18:32:51 --> Output Class Initialized
INFO - 2016-10-16 18:32:51 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:51 --> Input Class Initialized
INFO - 2016-10-16 18:32:51 --> Language Class Initialized
INFO - 2016-10-16 18:32:51 --> Loader Class Initialized
INFO - 2016-10-16 18:32:51 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:51 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:51 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:51 --> Controller Class Initialized
INFO - 2016-10-16 18:32:51 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:51 --> Config Class Initialized
INFO - 2016-10-16 18:32:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:51 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:51 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:51 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:51 --> Router Class Initialized
INFO - 2016-10-16 18:32:51 --> Output Class Initialized
INFO - 2016-10-16 18:32:51 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:51 --> Input Class Initialized
INFO - 2016-10-16 18:32:51 --> Language Class Initialized
INFO - 2016-10-16 18:32:51 --> Loader Class Initialized
INFO - 2016-10-16 18:32:51 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:51 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:51 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:52 --> Controller Class Initialized
INFO - 2016-10-16 18:32:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:52 --> Config Class Initialized
INFO - 2016-10-16 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:52 --> Router Class Initialized
INFO - 2016-10-16 18:32:52 --> Output Class Initialized
INFO - 2016-10-16 18:32:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:52 --> Input Class Initialized
INFO - 2016-10-16 18:32:52 --> Language Class Initialized
INFO - 2016-10-16 18:32:52 --> Loader Class Initialized
INFO - 2016-10-16 18:32:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:52 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:52 --> Controller Class Initialized
INFO - 2016-10-16 18:32:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:52 --> Config Class Initialized
INFO - 2016-10-16 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:52 --> Router Class Initialized
INFO - 2016-10-16 18:32:52 --> Output Class Initialized
INFO - 2016-10-16 18:32:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:52 --> Input Class Initialized
INFO - 2016-10-16 18:32:52 --> Language Class Initialized
INFO - 2016-10-16 18:32:52 --> Loader Class Initialized
INFO - 2016-10-16 18:32:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:52 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:52 --> Controller Class Initialized
INFO - 2016-10-16 18:32:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:52 --> Config Class Initialized
INFO - 2016-10-16 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:52 --> Router Class Initialized
INFO - 2016-10-16 18:32:52 --> Output Class Initialized
INFO - 2016-10-16 18:32:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:52 --> Input Class Initialized
INFO - 2016-10-16 18:32:52 --> Language Class Initialized
INFO - 2016-10-16 18:32:52 --> Loader Class Initialized
INFO - 2016-10-16 18:32:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:52 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:52 --> Controller Class Initialized
INFO - 2016-10-16 18:32:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:52 --> Config Class Initialized
INFO - 2016-10-16 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:52 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:52 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:52 --> Router Class Initialized
INFO - 2016-10-16 18:32:52 --> Output Class Initialized
INFO - 2016-10-16 18:32:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:52 --> Input Class Initialized
INFO - 2016-10-16 18:32:52 --> Language Class Initialized
INFO - 2016-10-16 18:32:52 --> Loader Class Initialized
INFO - 2016-10-16 18:32:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:53 --> Controller Class Initialized
INFO - 2016-10-16 18:32:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:53 --> Config Class Initialized
INFO - 2016-10-16 18:32:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:53 --> Router Class Initialized
INFO - 2016-10-16 18:32:53 --> Output Class Initialized
INFO - 2016-10-16 18:32:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:53 --> Input Class Initialized
INFO - 2016-10-16 18:32:53 --> Language Class Initialized
INFO - 2016-10-16 18:32:53 --> Loader Class Initialized
INFO - 2016-10-16 18:32:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:53 --> Controller Class Initialized
INFO - 2016-10-16 18:32:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:53 --> Config Class Initialized
INFO - 2016-10-16 18:32:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:53 --> Router Class Initialized
INFO - 2016-10-16 18:32:53 --> Output Class Initialized
INFO - 2016-10-16 18:32:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:53 --> Input Class Initialized
INFO - 2016-10-16 18:32:53 --> Language Class Initialized
INFO - 2016-10-16 18:32:53 --> Loader Class Initialized
INFO - 2016-10-16 18:32:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:53 --> Controller Class Initialized
INFO - 2016-10-16 18:32:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:53 --> Config Class Initialized
INFO - 2016-10-16 18:32:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:53 --> Router Class Initialized
INFO - 2016-10-16 18:32:53 --> Output Class Initialized
INFO - 2016-10-16 18:32:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:53 --> Input Class Initialized
INFO - 2016-10-16 18:32:53 --> Language Class Initialized
INFO - 2016-10-16 18:32:53 --> Loader Class Initialized
INFO - 2016-10-16 18:32:53 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:53 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:53 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:53 --> Controller Class Initialized
INFO - 2016-10-16 18:32:53 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:53 --> Config Class Initialized
INFO - 2016-10-16 18:32:53 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:53 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:53 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:53 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:53 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:53 --> Router Class Initialized
INFO - 2016-10-16 18:32:53 --> Output Class Initialized
INFO - 2016-10-16 18:32:53 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:53 --> Input Class Initialized
INFO - 2016-10-16 18:32:54 --> Language Class Initialized
INFO - 2016-10-16 18:32:54 --> Loader Class Initialized
INFO - 2016-10-16 18:32:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:54 --> Controller Class Initialized
INFO - 2016-10-16 18:32:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:54 --> Config Class Initialized
INFO - 2016-10-16 18:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:54 --> Router Class Initialized
INFO - 2016-10-16 18:32:54 --> Output Class Initialized
INFO - 2016-10-16 18:32:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:54 --> Input Class Initialized
INFO - 2016-10-16 18:32:54 --> Language Class Initialized
INFO - 2016-10-16 18:32:54 --> Loader Class Initialized
INFO - 2016-10-16 18:32:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:54 --> Controller Class Initialized
INFO - 2016-10-16 18:32:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:54 --> Config Class Initialized
INFO - 2016-10-16 18:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:54 --> Router Class Initialized
INFO - 2016-10-16 18:32:54 --> Output Class Initialized
INFO - 2016-10-16 18:32:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:54 --> Input Class Initialized
INFO - 2016-10-16 18:32:54 --> Language Class Initialized
INFO - 2016-10-16 18:32:54 --> Loader Class Initialized
INFO - 2016-10-16 18:32:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:54 --> Controller Class Initialized
INFO - 2016-10-16 18:32:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:54 --> Config Class Initialized
INFO - 2016-10-16 18:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:54 --> Router Class Initialized
INFO - 2016-10-16 18:32:54 --> Output Class Initialized
INFO - 2016-10-16 18:32:54 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:54 --> Input Class Initialized
INFO - 2016-10-16 18:32:54 --> Language Class Initialized
INFO - 2016-10-16 18:32:54 --> Loader Class Initialized
INFO - 2016-10-16 18:32:54 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:54 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:54 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:54 --> Controller Class Initialized
INFO - 2016-10-16 18:32:54 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:54 --> Config Class Initialized
INFO - 2016-10-16 18:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:54 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:54 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:54 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:54 --> Router Class Initialized
INFO - 2016-10-16 18:32:55 --> Output Class Initialized
INFO - 2016-10-16 18:32:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:55 --> Input Class Initialized
INFO - 2016-10-16 18:32:55 --> Language Class Initialized
INFO - 2016-10-16 18:32:55 --> Loader Class Initialized
INFO - 2016-10-16 18:32:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:55 --> Controller Class Initialized
INFO - 2016-10-16 18:32:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:55 --> Config Class Initialized
INFO - 2016-10-16 18:32:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:55 --> Router Class Initialized
INFO - 2016-10-16 18:32:55 --> Output Class Initialized
INFO - 2016-10-16 18:32:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:55 --> Input Class Initialized
INFO - 2016-10-16 18:32:55 --> Language Class Initialized
INFO - 2016-10-16 18:32:55 --> Loader Class Initialized
INFO - 2016-10-16 18:32:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:55 --> Controller Class Initialized
INFO - 2016-10-16 18:32:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:55 --> Config Class Initialized
INFO - 2016-10-16 18:32:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:55 --> Router Class Initialized
INFO - 2016-10-16 18:32:55 --> Output Class Initialized
INFO - 2016-10-16 18:32:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:55 --> Input Class Initialized
INFO - 2016-10-16 18:32:55 --> Language Class Initialized
INFO - 2016-10-16 18:32:55 --> Loader Class Initialized
INFO - 2016-10-16 18:32:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:55 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:55 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:55 --> Controller Class Initialized
INFO - 2016-10-16 18:32:55 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:55 --> Config Class Initialized
INFO - 2016-10-16 18:32:55 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:55 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:55 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:55 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:55 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:55 --> Router Class Initialized
INFO - 2016-10-16 18:32:55 --> Output Class Initialized
INFO - 2016-10-16 18:32:55 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:55 --> Input Class Initialized
INFO - 2016-10-16 18:32:55 --> Language Class Initialized
INFO - 2016-10-16 18:32:55 --> Loader Class Initialized
INFO - 2016-10-16 18:32:55 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:56 --> Controller Class Initialized
INFO - 2016-10-16 18:32:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:56 --> Config Class Initialized
INFO - 2016-10-16 18:32:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:56 --> Router Class Initialized
INFO - 2016-10-16 18:32:56 --> Output Class Initialized
INFO - 2016-10-16 18:32:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:56 --> Input Class Initialized
INFO - 2016-10-16 18:32:56 --> Language Class Initialized
INFO - 2016-10-16 18:32:56 --> Loader Class Initialized
INFO - 2016-10-16 18:32:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:56 --> Controller Class Initialized
INFO - 2016-10-16 18:32:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:56 --> Config Class Initialized
INFO - 2016-10-16 18:32:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:56 --> Router Class Initialized
INFO - 2016-10-16 18:32:56 --> Output Class Initialized
INFO - 2016-10-16 18:32:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:56 --> Input Class Initialized
INFO - 2016-10-16 18:32:56 --> Language Class Initialized
INFO - 2016-10-16 18:32:56 --> Loader Class Initialized
INFO - 2016-10-16 18:32:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:56 --> Controller Class Initialized
INFO - 2016-10-16 18:32:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:56 --> Config Class Initialized
INFO - 2016-10-16 18:32:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:56 --> Router Class Initialized
INFO - 2016-10-16 18:32:56 --> Output Class Initialized
INFO - 2016-10-16 18:32:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:56 --> Input Class Initialized
INFO - 2016-10-16 18:32:56 --> Language Class Initialized
INFO - 2016-10-16 18:32:56 --> Loader Class Initialized
INFO - 2016-10-16 18:32:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:56 --> Controller Class Initialized
INFO - 2016-10-16 18:32:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:57 --> Config Class Initialized
INFO - 2016-10-16 18:32:57 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:57 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:57 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:57 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:57 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:57 --> Router Class Initialized
INFO - 2016-10-16 18:32:57 --> Output Class Initialized
INFO - 2016-10-16 18:32:57 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:57 --> Input Class Initialized
INFO - 2016-10-16 18:32:57 --> Language Class Initialized
INFO - 2016-10-16 18:32:57 --> Loader Class Initialized
INFO - 2016-10-16 18:32:57 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:57 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:57 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:57 --> Controller Class Initialized
INFO - 2016-10-16 18:32:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:32:57 --> Model Class Initialized
ERROR - 2016-10-16 18:32:57 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:32:57 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 47
INFO - 2016-10-16 18:32:57 --> Config Class Initialized
INFO - 2016-10-16 18:32:57 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:57 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:57 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:57 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:57 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:57 --> Router Class Initialized
INFO - 2016-10-16 18:32:57 --> Output Class Initialized
INFO - 2016-10-16 18:32:57 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:57 --> Input Class Initialized
INFO - 2016-10-16 18:32:57 --> Language Class Initialized
INFO - 2016-10-16 18:32:57 --> Loader Class Initialized
INFO - 2016-10-16 18:32:57 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:57 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:57 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:57 --> Controller Class Initialized
INFO - 2016-10-16 18:32:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:57 --> Config Class Initialized
INFO - 2016-10-16 18:32:57 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:57 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:57 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:57 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:57 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:57 --> Router Class Initialized
INFO - 2016-10-16 18:32:57 --> Output Class Initialized
INFO - 2016-10-16 18:32:58 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:58 --> Input Class Initialized
INFO - 2016-10-16 18:32:58 --> Language Class Initialized
INFO - 2016-10-16 18:32:58 --> Loader Class Initialized
INFO - 2016-10-16 18:32:58 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:58 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:58 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:58 --> Controller Class Initialized
INFO - 2016-10-16 18:32:58 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:58 --> Config Class Initialized
INFO - 2016-10-16 18:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:58 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:58 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:58 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:58 --> Router Class Initialized
INFO - 2016-10-16 18:32:58 --> Output Class Initialized
INFO - 2016-10-16 18:32:58 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:58 --> Input Class Initialized
INFO - 2016-10-16 18:32:58 --> Language Class Initialized
INFO - 2016-10-16 18:32:58 --> Loader Class Initialized
INFO - 2016-10-16 18:32:58 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:58 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:58 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:58 --> Controller Class Initialized
INFO - 2016-10-16 18:32:58 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:58 --> Config Class Initialized
INFO - 2016-10-16 18:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:58 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:58 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:58 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:58 --> Router Class Initialized
INFO - 2016-10-16 18:32:58 --> Output Class Initialized
INFO - 2016-10-16 18:32:58 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:58 --> Input Class Initialized
INFO - 2016-10-16 18:32:58 --> Language Class Initialized
INFO - 2016-10-16 18:32:58 --> Loader Class Initialized
INFO - 2016-10-16 18:32:58 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:58 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:58 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:58 --> Controller Class Initialized
INFO - 2016-10-16 18:32:58 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:58 --> Config Class Initialized
INFO - 2016-10-16 18:32:58 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:58 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:58 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:58 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:58 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:58 --> Router Class Initialized
INFO - 2016-10-16 18:32:58 --> Output Class Initialized
INFO - 2016-10-16 18:32:58 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:58 --> Input Class Initialized
INFO - 2016-10-16 18:32:58 --> Language Class Initialized
INFO - 2016-10-16 18:32:58 --> Loader Class Initialized
INFO - 2016-10-16 18:32:58 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:59 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:59 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:59 --> Controller Class Initialized
INFO - 2016-10-16 18:32:59 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:59 --> Config Class Initialized
INFO - 2016-10-16 18:32:59 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:59 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:59 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:59 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:59 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:59 --> Router Class Initialized
INFO - 2016-10-16 18:32:59 --> Output Class Initialized
INFO - 2016-10-16 18:32:59 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:59 --> Input Class Initialized
INFO - 2016-10-16 18:32:59 --> Language Class Initialized
INFO - 2016-10-16 18:32:59 --> Loader Class Initialized
INFO - 2016-10-16 18:32:59 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:59 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:59 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:59 --> Controller Class Initialized
INFO - 2016-10-16 18:32:59 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:59 --> Config Class Initialized
INFO - 2016-10-16 18:32:59 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:59 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:59 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:59 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:59 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:59 --> Router Class Initialized
INFO - 2016-10-16 18:32:59 --> Output Class Initialized
INFO - 2016-10-16 18:32:59 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:59 --> Input Class Initialized
INFO - 2016-10-16 18:32:59 --> Language Class Initialized
INFO - 2016-10-16 18:32:59 --> Loader Class Initialized
INFO - 2016-10-16 18:32:59 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:59 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:59 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:59 --> Controller Class Initialized
INFO - 2016-10-16 18:32:59 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:59 --> Config Class Initialized
INFO - 2016-10-16 18:32:59 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:59 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:59 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:59 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:59 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:59 --> Router Class Initialized
INFO - 2016-10-16 18:32:59 --> Output Class Initialized
INFO - 2016-10-16 18:32:59 --> Security Class Initialized
DEBUG - 2016-10-16 18:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:32:59 --> Input Class Initialized
INFO - 2016-10-16 18:32:59 --> Language Class Initialized
INFO - 2016-10-16 18:32:59 --> Loader Class Initialized
INFO - 2016-10-16 18:32:59 --> Helper loaded: url_helper
INFO - 2016-10-16 18:32:59 --> Helper loaded: form_helper
INFO - 2016-10-16 18:32:59 --> Database Driver Class Initialized
INFO - 2016-10-16 18:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:32:59 --> Controller Class Initialized
INFO - 2016-10-16 18:32:59 --> Form Validation Class Initialized
INFO - 2016-10-16 18:32:59 --> Config Class Initialized
INFO - 2016-10-16 18:32:59 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:32:59 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:32:59 --> Utf8 Class Initialized
INFO - 2016-10-16 18:32:59 --> URI Class Initialized
DEBUG - 2016-10-16 18:32:59 --> No URI present. Default controller set.
INFO - 2016-10-16 18:32:59 --> Router Class Initialized
INFO - 2016-10-16 18:33:00 --> Output Class Initialized
INFO - 2016-10-16 18:33:00 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:00 --> Input Class Initialized
INFO - 2016-10-16 18:33:00 --> Language Class Initialized
INFO - 2016-10-16 18:33:00 --> Loader Class Initialized
INFO - 2016-10-16 18:33:00 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:00 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:00 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:00 --> Controller Class Initialized
INFO - 2016-10-16 18:33:00 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:00 --> Config Class Initialized
INFO - 2016-10-16 18:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:00 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:00 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:00 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:00 --> Router Class Initialized
INFO - 2016-10-16 18:33:00 --> Output Class Initialized
INFO - 2016-10-16 18:33:00 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:00 --> Input Class Initialized
INFO - 2016-10-16 18:33:00 --> Language Class Initialized
INFO - 2016-10-16 18:33:00 --> Loader Class Initialized
INFO - 2016-10-16 18:33:00 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:00 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:00 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:00 --> Controller Class Initialized
INFO - 2016-10-16 18:33:00 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:00 --> Config Class Initialized
INFO - 2016-10-16 18:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:00 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:00 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:00 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:00 --> Router Class Initialized
INFO - 2016-10-16 18:33:00 --> Output Class Initialized
INFO - 2016-10-16 18:33:00 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:00 --> Input Class Initialized
INFO - 2016-10-16 18:33:00 --> Language Class Initialized
INFO - 2016-10-16 18:33:00 --> Loader Class Initialized
INFO - 2016-10-16 18:33:00 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:00 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:00 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:00 --> Controller Class Initialized
INFO - 2016-10-16 18:33:00 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:00 --> Config Class Initialized
INFO - 2016-10-16 18:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:00 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:00 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:00 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:00 --> Router Class Initialized
INFO - 2016-10-16 18:33:00 --> Output Class Initialized
INFO - 2016-10-16 18:33:00 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:00 --> Input Class Initialized
INFO - 2016-10-16 18:33:00 --> Language Class Initialized
INFO - 2016-10-16 18:33:00 --> Loader Class Initialized
INFO - 2016-10-16 18:33:00 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:00 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:00 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:00 --> Controller Class Initialized
INFO - 2016-10-16 18:33:01 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:01 --> Config Class Initialized
INFO - 2016-10-16 18:33:01 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:01 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:01 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:01 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:01 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:01 --> Router Class Initialized
INFO - 2016-10-16 18:33:01 --> Output Class Initialized
INFO - 2016-10-16 18:33:01 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:01 --> Input Class Initialized
INFO - 2016-10-16 18:33:01 --> Language Class Initialized
INFO - 2016-10-16 18:33:01 --> Loader Class Initialized
INFO - 2016-10-16 18:33:01 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:01 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:01 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:01 --> Controller Class Initialized
INFO - 2016-10-16 18:33:01 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:01 --> Config Class Initialized
INFO - 2016-10-16 18:33:01 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:01 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:01 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:01 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:01 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:01 --> Router Class Initialized
INFO - 2016-10-16 18:33:01 --> Output Class Initialized
INFO - 2016-10-16 18:33:01 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:01 --> Input Class Initialized
INFO - 2016-10-16 18:33:01 --> Language Class Initialized
INFO - 2016-10-16 18:33:01 --> Loader Class Initialized
INFO - 2016-10-16 18:33:01 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:01 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:01 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:01 --> Controller Class Initialized
INFO - 2016-10-16 18:33:01 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:01 --> Config Class Initialized
INFO - 2016-10-16 18:33:01 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:01 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:01 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:01 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:01 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:01 --> Router Class Initialized
INFO - 2016-10-16 18:33:01 --> Output Class Initialized
INFO - 2016-10-16 18:33:01 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:01 --> Input Class Initialized
INFO - 2016-10-16 18:33:01 --> Language Class Initialized
INFO - 2016-10-16 18:33:01 --> Loader Class Initialized
INFO - 2016-10-16 18:33:01 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:01 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:01 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:01 --> Controller Class Initialized
INFO - 2016-10-16 18:33:01 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:01 --> Config Class Initialized
INFO - 2016-10-16 18:33:01 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:01 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:01 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:01 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:01 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:01 --> Router Class Initialized
INFO - 2016-10-16 18:33:01 --> Output Class Initialized
INFO - 2016-10-16 18:33:01 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:01 --> Input Class Initialized
INFO - 2016-10-16 18:33:02 --> Language Class Initialized
INFO - 2016-10-16 18:33:02 --> Loader Class Initialized
INFO - 2016-10-16 18:33:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:02 --> Controller Class Initialized
INFO - 2016-10-16 18:33:02 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:02 --> Config Class Initialized
INFO - 2016-10-16 18:33:02 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:02 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:02 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:02 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:02 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:02 --> Router Class Initialized
INFO - 2016-10-16 18:33:02 --> Output Class Initialized
INFO - 2016-10-16 18:33:02 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:02 --> Input Class Initialized
INFO - 2016-10-16 18:33:02 --> Language Class Initialized
INFO - 2016-10-16 18:33:02 --> Loader Class Initialized
INFO - 2016-10-16 18:33:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:02 --> Controller Class Initialized
INFO - 2016-10-16 18:33:02 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:02 --> Config Class Initialized
INFO - 2016-10-16 18:33:02 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:02 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:02 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:02 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:02 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:02 --> Router Class Initialized
INFO - 2016-10-16 18:33:02 --> Output Class Initialized
INFO - 2016-10-16 18:33:02 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:02 --> Input Class Initialized
INFO - 2016-10-16 18:33:02 --> Language Class Initialized
INFO - 2016-10-16 18:33:02 --> Loader Class Initialized
INFO - 2016-10-16 18:33:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:02 --> Controller Class Initialized
INFO - 2016-10-16 18:33:02 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:02 --> Config Class Initialized
INFO - 2016-10-16 18:33:02 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:02 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:02 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:02 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:02 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:02 --> Router Class Initialized
INFO - 2016-10-16 18:33:02 --> Output Class Initialized
INFO - 2016-10-16 18:33:02 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:02 --> Input Class Initialized
INFO - 2016-10-16 18:33:02 --> Language Class Initialized
INFO - 2016-10-16 18:33:02 --> Loader Class Initialized
INFO - 2016-10-16 18:33:02 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:02 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:02 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:02 --> Controller Class Initialized
INFO - 2016-10-16 18:33:03 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:03 --> Config Class Initialized
INFO - 2016-10-16 18:33:03 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:03 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:03 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:03 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:03 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:03 --> Router Class Initialized
INFO - 2016-10-16 18:33:03 --> Output Class Initialized
INFO - 2016-10-16 18:33:03 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:03 --> Input Class Initialized
INFO - 2016-10-16 18:33:03 --> Language Class Initialized
INFO - 2016-10-16 18:33:03 --> Loader Class Initialized
INFO - 2016-10-16 18:33:03 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:03 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:03 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:03 --> Controller Class Initialized
INFO - 2016-10-16 18:33:03 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:08 --> Config Class Initialized
INFO - 2016-10-16 18:33:08 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:08 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:08 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:08 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:08 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:08 --> Router Class Initialized
INFO - 2016-10-16 18:33:08 --> Output Class Initialized
INFO - 2016-10-16 18:33:08 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:08 --> Input Class Initialized
INFO - 2016-10-16 18:33:08 --> Language Class Initialized
INFO - 2016-10-16 18:33:08 --> Loader Class Initialized
INFO - 2016-10-16 18:33:08 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:08 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:08 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:08 --> Controller Class Initialized
INFO - 2016-10-16 18:33:08 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:33:08 --> Model Class Initialized
ERROR - 2016-10-16 18:33:08 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:33:08 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 47
INFO - 2016-10-16 18:33:08 --> Config Class Initialized
INFO - 2016-10-16 18:33:08 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:08 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:08 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:08 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:08 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:08 --> Router Class Initialized
INFO - 2016-10-16 18:33:08 --> Output Class Initialized
INFO - 2016-10-16 18:33:08 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:08 --> Input Class Initialized
INFO - 2016-10-16 18:33:08 --> Language Class Initialized
INFO - 2016-10-16 18:33:08 --> Loader Class Initialized
INFO - 2016-10-16 18:33:08 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:08 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:08 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:08 --> Controller Class Initialized
INFO - 2016-10-16 18:33:09 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:09 --> Config Class Initialized
INFO - 2016-10-16 18:33:09 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:09 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:09 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:09 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:09 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:09 --> Router Class Initialized
INFO - 2016-10-16 18:33:09 --> Output Class Initialized
INFO - 2016-10-16 18:33:09 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:09 --> Input Class Initialized
INFO - 2016-10-16 18:33:09 --> Language Class Initialized
INFO - 2016-10-16 18:33:09 --> Loader Class Initialized
INFO - 2016-10-16 18:33:09 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:09 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:09 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:09 --> Controller Class Initialized
INFO - 2016-10-16 18:33:09 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:09 --> Config Class Initialized
INFO - 2016-10-16 18:33:09 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:09 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:09 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:09 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:09 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:09 --> Router Class Initialized
INFO - 2016-10-16 18:33:09 --> Output Class Initialized
INFO - 2016-10-16 18:33:09 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:09 --> Input Class Initialized
INFO - 2016-10-16 18:33:09 --> Language Class Initialized
INFO - 2016-10-16 18:33:09 --> Loader Class Initialized
INFO - 2016-10-16 18:33:09 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:09 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:09 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:09 --> Controller Class Initialized
INFO - 2016-10-16 18:33:09 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:09 --> Config Class Initialized
INFO - 2016-10-16 18:33:09 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:09 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:09 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:09 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:09 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:09 --> Router Class Initialized
INFO - 2016-10-16 18:33:09 --> Output Class Initialized
INFO - 2016-10-16 18:33:09 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:09 --> Input Class Initialized
INFO - 2016-10-16 18:33:09 --> Language Class Initialized
INFO - 2016-10-16 18:33:09 --> Loader Class Initialized
INFO - 2016-10-16 18:33:09 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:09 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:09 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:09 --> Controller Class Initialized
INFO - 2016-10-16 18:33:09 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:10 --> Config Class Initialized
INFO - 2016-10-16 18:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:10 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:10 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:10 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:10 --> Router Class Initialized
INFO - 2016-10-16 18:33:10 --> Output Class Initialized
INFO - 2016-10-16 18:33:10 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:10 --> Input Class Initialized
INFO - 2016-10-16 18:33:10 --> Language Class Initialized
INFO - 2016-10-16 18:33:10 --> Loader Class Initialized
INFO - 2016-10-16 18:33:10 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:10 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:10 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:10 --> Controller Class Initialized
INFO - 2016-10-16 18:33:10 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:10 --> Config Class Initialized
INFO - 2016-10-16 18:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:10 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:10 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:10 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:10 --> Router Class Initialized
INFO - 2016-10-16 18:33:10 --> Output Class Initialized
INFO - 2016-10-16 18:33:10 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:10 --> Input Class Initialized
INFO - 2016-10-16 18:33:10 --> Language Class Initialized
INFO - 2016-10-16 18:33:10 --> Loader Class Initialized
INFO - 2016-10-16 18:33:10 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:10 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:10 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:10 --> Controller Class Initialized
INFO - 2016-10-16 18:33:10 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:10 --> Config Class Initialized
INFO - 2016-10-16 18:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:10 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:10 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:10 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:10 --> Router Class Initialized
INFO - 2016-10-16 18:33:10 --> Output Class Initialized
INFO - 2016-10-16 18:33:10 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:10 --> Input Class Initialized
INFO - 2016-10-16 18:33:10 --> Language Class Initialized
INFO - 2016-10-16 18:33:10 --> Loader Class Initialized
INFO - 2016-10-16 18:33:10 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:10 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:10 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:10 --> Controller Class Initialized
INFO - 2016-10-16 18:33:10 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:10 --> Config Class Initialized
INFO - 2016-10-16 18:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:10 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:10 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:10 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:10 --> Router Class Initialized
INFO - 2016-10-16 18:33:10 --> Output Class Initialized
INFO - 2016-10-16 18:33:11 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:11 --> Input Class Initialized
INFO - 2016-10-16 18:33:11 --> Language Class Initialized
INFO - 2016-10-16 18:33:11 --> Loader Class Initialized
INFO - 2016-10-16 18:33:11 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:11 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:11 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:11 --> Controller Class Initialized
INFO - 2016-10-16 18:33:11 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:11 --> Config Class Initialized
INFO - 2016-10-16 18:33:11 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:11 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:11 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:11 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:11 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:11 --> Router Class Initialized
INFO - 2016-10-16 18:33:11 --> Output Class Initialized
INFO - 2016-10-16 18:33:11 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:11 --> Input Class Initialized
INFO - 2016-10-16 18:33:11 --> Language Class Initialized
INFO - 2016-10-16 18:33:11 --> Loader Class Initialized
INFO - 2016-10-16 18:33:11 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:11 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:11 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:11 --> Controller Class Initialized
INFO - 2016-10-16 18:33:11 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:11 --> Config Class Initialized
INFO - 2016-10-16 18:33:11 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:11 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:11 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:11 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:11 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:11 --> Router Class Initialized
INFO - 2016-10-16 18:33:11 --> Output Class Initialized
INFO - 2016-10-16 18:33:11 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:11 --> Input Class Initialized
INFO - 2016-10-16 18:33:11 --> Language Class Initialized
INFO - 2016-10-16 18:33:11 --> Loader Class Initialized
INFO - 2016-10-16 18:33:11 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:11 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:11 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:11 --> Controller Class Initialized
INFO - 2016-10-16 18:33:11 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:11 --> Config Class Initialized
INFO - 2016-10-16 18:33:11 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:11 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:11 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:11 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:11 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:11 --> Router Class Initialized
INFO - 2016-10-16 18:33:11 --> Output Class Initialized
INFO - 2016-10-16 18:33:11 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:11 --> Input Class Initialized
INFO - 2016-10-16 18:33:11 --> Language Class Initialized
INFO - 2016-10-16 18:33:11 --> Loader Class Initialized
INFO - 2016-10-16 18:33:11 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:11 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:11 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:12 --> Controller Class Initialized
INFO - 2016-10-16 18:33:12 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:12 --> Config Class Initialized
INFO - 2016-10-16 18:33:12 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:12 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:12 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:12 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:12 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:12 --> Router Class Initialized
INFO - 2016-10-16 18:33:12 --> Output Class Initialized
INFO - 2016-10-16 18:33:12 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:12 --> Input Class Initialized
INFO - 2016-10-16 18:33:12 --> Language Class Initialized
INFO - 2016-10-16 18:33:12 --> Loader Class Initialized
INFO - 2016-10-16 18:33:12 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:12 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:12 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:12 --> Controller Class Initialized
INFO - 2016-10-16 18:33:12 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:12 --> Config Class Initialized
INFO - 2016-10-16 18:33:12 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:12 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:12 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:12 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:12 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:12 --> Router Class Initialized
INFO - 2016-10-16 18:33:12 --> Output Class Initialized
INFO - 2016-10-16 18:33:12 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:12 --> Input Class Initialized
INFO - 2016-10-16 18:33:12 --> Language Class Initialized
INFO - 2016-10-16 18:33:12 --> Loader Class Initialized
INFO - 2016-10-16 18:33:12 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:12 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:12 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:12 --> Controller Class Initialized
INFO - 2016-10-16 18:33:12 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:12 --> Config Class Initialized
INFO - 2016-10-16 18:33:12 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:12 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:12 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:12 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:12 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:12 --> Router Class Initialized
INFO - 2016-10-16 18:33:12 --> Output Class Initialized
INFO - 2016-10-16 18:33:12 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:12 --> Input Class Initialized
INFO - 2016-10-16 18:33:12 --> Language Class Initialized
INFO - 2016-10-16 18:33:12 --> Loader Class Initialized
INFO - 2016-10-16 18:33:12 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:12 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:12 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:12 --> Controller Class Initialized
INFO - 2016-10-16 18:33:12 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:12 --> Config Class Initialized
INFO - 2016-10-16 18:33:12 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:12 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:13 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:13 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:13 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:13 --> Router Class Initialized
INFO - 2016-10-16 18:33:13 --> Output Class Initialized
INFO - 2016-10-16 18:33:13 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:13 --> Input Class Initialized
INFO - 2016-10-16 18:33:13 --> Language Class Initialized
INFO - 2016-10-16 18:33:13 --> Loader Class Initialized
INFO - 2016-10-16 18:33:13 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:13 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:13 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:13 --> Controller Class Initialized
INFO - 2016-10-16 18:33:13 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:13 --> Config Class Initialized
INFO - 2016-10-16 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:13 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:13 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:13 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:13 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:13 --> Router Class Initialized
INFO - 2016-10-16 18:33:13 --> Output Class Initialized
INFO - 2016-10-16 18:33:13 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:13 --> Input Class Initialized
INFO - 2016-10-16 18:33:13 --> Language Class Initialized
INFO - 2016-10-16 18:33:13 --> Loader Class Initialized
INFO - 2016-10-16 18:33:13 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:13 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:13 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:13 --> Controller Class Initialized
INFO - 2016-10-16 18:33:13 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:13 --> Config Class Initialized
INFO - 2016-10-16 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:13 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:13 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:13 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:13 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:13 --> Router Class Initialized
INFO - 2016-10-16 18:33:13 --> Output Class Initialized
INFO - 2016-10-16 18:33:13 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:13 --> Input Class Initialized
INFO - 2016-10-16 18:33:13 --> Language Class Initialized
INFO - 2016-10-16 18:33:13 --> Loader Class Initialized
INFO - 2016-10-16 18:33:13 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:13 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:13 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:13 --> Controller Class Initialized
INFO - 2016-10-16 18:33:13 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:13 --> Config Class Initialized
INFO - 2016-10-16 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:13 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:13 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:13 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:13 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:13 --> Router Class Initialized
INFO - 2016-10-16 18:33:13 --> Output Class Initialized
INFO - 2016-10-16 18:33:13 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:13 --> Input Class Initialized
INFO - 2016-10-16 18:33:13 --> Language Class Initialized
INFO - 2016-10-16 18:33:14 --> Loader Class Initialized
INFO - 2016-10-16 18:33:14 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:14 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:14 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:14 --> Controller Class Initialized
INFO - 2016-10-16 18:33:14 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:14 --> Config Class Initialized
INFO - 2016-10-16 18:33:14 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:14 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:14 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:14 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:14 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:14 --> Router Class Initialized
INFO - 2016-10-16 18:33:14 --> Output Class Initialized
INFO - 2016-10-16 18:33:14 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:14 --> Input Class Initialized
INFO - 2016-10-16 18:33:14 --> Language Class Initialized
INFO - 2016-10-16 18:33:14 --> Loader Class Initialized
INFO - 2016-10-16 18:33:14 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:14 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:14 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:14 --> Controller Class Initialized
INFO - 2016-10-16 18:33:14 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:14 --> Config Class Initialized
INFO - 2016-10-16 18:33:14 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:14 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:14 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:14 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:14 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:14 --> Router Class Initialized
INFO - 2016-10-16 18:33:14 --> Output Class Initialized
INFO - 2016-10-16 18:33:14 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:14 --> Input Class Initialized
INFO - 2016-10-16 18:33:14 --> Language Class Initialized
INFO - 2016-10-16 18:33:14 --> Loader Class Initialized
INFO - 2016-10-16 18:33:14 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:14 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:14 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:14 --> Controller Class Initialized
INFO - 2016-10-16 18:33:14 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:44 --> Config Class Initialized
INFO - 2016-10-16 18:33:44 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:44 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:44 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:44 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:44 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:44 --> Router Class Initialized
INFO - 2016-10-16 18:33:44 --> Output Class Initialized
INFO - 2016-10-16 18:33:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:44 --> Input Class Initialized
INFO - 2016-10-16 18:33:44 --> Language Class Initialized
INFO - 2016-10-16 18:33:44 --> Loader Class Initialized
INFO - 2016-10-16 18:33:44 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:44 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:44 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:45 --> Controller Class Initialized
INFO - 2016-10-16 18:33:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:33:45 --> Model Class Initialized
ERROR - 2016-10-16 18:33:45 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:33:45 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 47
INFO - 2016-10-16 18:33:45 --> Config Class Initialized
INFO - 2016-10-16 18:33:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:45 --> Router Class Initialized
INFO - 2016-10-16 18:33:45 --> Output Class Initialized
INFO - 2016-10-16 18:33:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:45 --> Input Class Initialized
INFO - 2016-10-16 18:33:45 --> Language Class Initialized
INFO - 2016-10-16 18:33:45 --> Loader Class Initialized
INFO - 2016-10-16 18:33:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:45 --> Controller Class Initialized
INFO - 2016-10-16 18:33:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:45 --> Config Class Initialized
INFO - 2016-10-16 18:33:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:45 --> Router Class Initialized
INFO - 2016-10-16 18:33:45 --> Output Class Initialized
INFO - 2016-10-16 18:33:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:45 --> Input Class Initialized
INFO - 2016-10-16 18:33:45 --> Language Class Initialized
INFO - 2016-10-16 18:33:45 --> Loader Class Initialized
INFO - 2016-10-16 18:33:45 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:45 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:45 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:45 --> Controller Class Initialized
INFO - 2016-10-16 18:33:45 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:45 --> Config Class Initialized
INFO - 2016-10-16 18:33:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:45 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:45 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:45 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:45 --> Router Class Initialized
INFO - 2016-10-16 18:33:45 --> Output Class Initialized
INFO - 2016-10-16 18:33:45 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:45 --> Input Class Initialized
INFO - 2016-10-16 18:33:45 --> Language Class Initialized
INFO - 2016-10-16 18:33:46 --> Loader Class Initialized
INFO - 2016-10-16 18:33:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:46 --> Controller Class Initialized
INFO - 2016-10-16 18:33:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:46 --> Config Class Initialized
INFO - 2016-10-16 18:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:46 --> Router Class Initialized
INFO - 2016-10-16 18:33:46 --> Output Class Initialized
INFO - 2016-10-16 18:33:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:46 --> Input Class Initialized
INFO - 2016-10-16 18:33:46 --> Language Class Initialized
INFO - 2016-10-16 18:33:46 --> Loader Class Initialized
INFO - 2016-10-16 18:33:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:46 --> Controller Class Initialized
INFO - 2016-10-16 18:33:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:46 --> Config Class Initialized
INFO - 2016-10-16 18:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:46 --> Router Class Initialized
INFO - 2016-10-16 18:33:46 --> Output Class Initialized
INFO - 2016-10-16 18:33:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:46 --> Input Class Initialized
INFO - 2016-10-16 18:33:46 --> Language Class Initialized
INFO - 2016-10-16 18:33:46 --> Loader Class Initialized
INFO - 2016-10-16 18:33:46 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:46 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:46 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:46 --> Controller Class Initialized
INFO - 2016-10-16 18:33:46 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:46 --> Config Class Initialized
INFO - 2016-10-16 18:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:46 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:46 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:46 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:46 --> Router Class Initialized
INFO - 2016-10-16 18:33:46 --> Output Class Initialized
INFO - 2016-10-16 18:33:46 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:46 --> Input Class Initialized
INFO - 2016-10-16 18:33:46 --> Language Class Initialized
INFO - 2016-10-16 18:33:46 --> Loader Class Initialized
INFO - 2016-10-16 18:33:47 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:47 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:47 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:47 --> Controller Class Initialized
INFO - 2016-10-16 18:33:47 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:47 --> Config Class Initialized
INFO - 2016-10-16 18:33:47 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:47 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:47 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:47 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:47 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:47 --> Router Class Initialized
INFO - 2016-10-16 18:33:47 --> Output Class Initialized
INFO - 2016-10-16 18:33:47 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:47 --> Input Class Initialized
INFO - 2016-10-16 18:33:47 --> Language Class Initialized
INFO - 2016-10-16 18:33:47 --> Loader Class Initialized
INFO - 2016-10-16 18:33:47 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:47 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:47 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:47 --> Controller Class Initialized
INFO - 2016-10-16 18:33:47 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:47 --> Config Class Initialized
INFO - 2016-10-16 18:33:47 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:47 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:47 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:47 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:47 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:47 --> Router Class Initialized
INFO - 2016-10-16 18:33:47 --> Output Class Initialized
INFO - 2016-10-16 18:33:47 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:47 --> Input Class Initialized
INFO - 2016-10-16 18:33:47 --> Language Class Initialized
INFO - 2016-10-16 18:33:47 --> Loader Class Initialized
INFO - 2016-10-16 18:33:47 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:47 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:47 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:47 --> Controller Class Initialized
INFO - 2016-10-16 18:33:47 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:47 --> Config Class Initialized
INFO - 2016-10-16 18:33:47 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:47 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:47 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:47 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:47 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:47 --> Router Class Initialized
INFO - 2016-10-16 18:33:48 --> Output Class Initialized
INFO - 2016-10-16 18:33:48 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:48 --> Input Class Initialized
INFO - 2016-10-16 18:33:48 --> Language Class Initialized
INFO - 2016-10-16 18:33:48 --> Loader Class Initialized
INFO - 2016-10-16 18:33:48 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:48 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:48 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:48 --> Controller Class Initialized
INFO - 2016-10-16 18:33:48 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:48 --> Config Class Initialized
INFO - 2016-10-16 18:33:48 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:48 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:48 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:48 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:48 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:48 --> Router Class Initialized
INFO - 2016-10-16 18:33:48 --> Output Class Initialized
INFO - 2016-10-16 18:33:48 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:48 --> Input Class Initialized
INFO - 2016-10-16 18:33:48 --> Language Class Initialized
INFO - 2016-10-16 18:33:48 --> Loader Class Initialized
INFO - 2016-10-16 18:33:48 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:48 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:48 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:48 --> Controller Class Initialized
INFO - 2016-10-16 18:33:48 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:48 --> Config Class Initialized
INFO - 2016-10-16 18:33:48 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:48 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:48 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:48 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:48 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:48 --> Router Class Initialized
INFO - 2016-10-16 18:33:48 --> Output Class Initialized
INFO - 2016-10-16 18:33:48 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:48 --> Input Class Initialized
INFO - 2016-10-16 18:33:48 --> Language Class Initialized
INFO - 2016-10-16 18:33:48 --> Loader Class Initialized
INFO - 2016-10-16 18:33:48 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:48 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:48 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:48 --> Controller Class Initialized
INFO - 2016-10-16 18:33:48 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:48 --> Config Class Initialized
INFO - 2016-10-16 18:33:48 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:48 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:48 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:49 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:49 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:49 --> Router Class Initialized
INFO - 2016-10-16 18:33:49 --> Output Class Initialized
INFO - 2016-10-16 18:33:49 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:49 --> Input Class Initialized
INFO - 2016-10-16 18:33:49 --> Language Class Initialized
INFO - 2016-10-16 18:33:49 --> Loader Class Initialized
INFO - 2016-10-16 18:33:49 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:49 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:49 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:49 --> Controller Class Initialized
INFO - 2016-10-16 18:33:49 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:49 --> Config Class Initialized
INFO - 2016-10-16 18:33:49 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:49 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:49 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:49 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:49 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:49 --> Router Class Initialized
INFO - 2016-10-16 18:33:49 --> Output Class Initialized
INFO - 2016-10-16 18:33:49 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:49 --> Input Class Initialized
INFO - 2016-10-16 18:33:49 --> Language Class Initialized
INFO - 2016-10-16 18:33:49 --> Loader Class Initialized
INFO - 2016-10-16 18:33:49 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:49 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:49 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:49 --> Controller Class Initialized
INFO - 2016-10-16 18:33:49 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:49 --> Config Class Initialized
INFO - 2016-10-16 18:33:49 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:49 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:49 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:49 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:49 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:49 --> Router Class Initialized
INFO - 2016-10-16 18:33:49 --> Output Class Initialized
INFO - 2016-10-16 18:33:49 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:49 --> Input Class Initialized
INFO - 2016-10-16 18:33:49 --> Language Class Initialized
INFO - 2016-10-16 18:33:49 --> Loader Class Initialized
INFO - 2016-10-16 18:33:49 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:49 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:49 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:49 --> Controller Class Initialized
INFO - 2016-10-16 18:33:49 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:49 --> Config Class Initialized
INFO - 2016-10-16 18:33:49 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:49 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:50 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:50 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:50 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:50 --> Router Class Initialized
INFO - 2016-10-16 18:33:50 --> Output Class Initialized
INFO - 2016-10-16 18:33:50 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:50 --> Input Class Initialized
INFO - 2016-10-16 18:33:50 --> Language Class Initialized
INFO - 2016-10-16 18:33:50 --> Loader Class Initialized
INFO - 2016-10-16 18:33:50 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:50 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:50 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:50 --> Controller Class Initialized
INFO - 2016-10-16 18:33:50 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:50 --> Config Class Initialized
INFO - 2016-10-16 18:33:50 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:50 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:50 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:50 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:50 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:50 --> Router Class Initialized
INFO - 2016-10-16 18:33:50 --> Output Class Initialized
INFO - 2016-10-16 18:33:50 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:50 --> Input Class Initialized
INFO - 2016-10-16 18:33:50 --> Language Class Initialized
INFO - 2016-10-16 18:33:50 --> Loader Class Initialized
INFO - 2016-10-16 18:33:50 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:50 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:50 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:50 --> Controller Class Initialized
INFO - 2016-10-16 18:33:50 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:50 --> Config Class Initialized
INFO - 2016-10-16 18:33:50 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:50 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:50 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:50 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:50 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:50 --> Router Class Initialized
INFO - 2016-10-16 18:33:50 --> Output Class Initialized
INFO - 2016-10-16 18:33:50 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:50 --> Input Class Initialized
INFO - 2016-10-16 18:33:50 --> Language Class Initialized
INFO - 2016-10-16 18:33:50 --> Loader Class Initialized
INFO - 2016-10-16 18:33:50 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:50 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:50 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:50 --> Controller Class Initialized
INFO - 2016-10-16 18:33:50 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:50 --> Config Class Initialized
INFO - 2016-10-16 18:33:50 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:50 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:50 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:51 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:51 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:51 --> Router Class Initialized
INFO - 2016-10-16 18:33:51 --> Output Class Initialized
INFO - 2016-10-16 18:33:51 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:51 --> Input Class Initialized
INFO - 2016-10-16 18:33:51 --> Language Class Initialized
INFO - 2016-10-16 18:33:51 --> Loader Class Initialized
INFO - 2016-10-16 18:33:51 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:51 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:51 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:51 --> Controller Class Initialized
INFO - 2016-10-16 18:33:51 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:51 --> Config Class Initialized
INFO - 2016-10-16 18:33:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:51 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:51 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:51 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:51 --> Router Class Initialized
INFO - 2016-10-16 18:33:51 --> Output Class Initialized
INFO - 2016-10-16 18:33:51 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:51 --> Input Class Initialized
INFO - 2016-10-16 18:33:51 --> Language Class Initialized
INFO - 2016-10-16 18:33:51 --> Loader Class Initialized
INFO - 2016-10-16 18:33:51 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:51 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:51 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:51 --> Controller Class Initialized
INFO - 2016-10-16 18:33:51 --> Form Validation Class Initialized
INFO - 2016-10-16 18:33:51 --> Config Class Initialized
INFO - 2016-10-16 18:33:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:33:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:33:51 --> Utf8 Class Initialized
INFO - 2016-10-16 18:33:51 --> URI Class Initialized
DEBUG - 2016-10-16 18:33:51 --> No URI present. Default controller set.
INFO - 2016-10-16 18:33:51 --> Router Class Initialized
INFO - 2016-10-16 18:33:51 --> Output Class Initialized
INFO - 2016-10-16 18:33:51 --> Security Class Initialized
DEBUG - 2016-10-16 18:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:33:51 --> Input Class Initialized
INFO - 2016-10-16 18:33:51 --> Language Class Initialized
INFO - 2016-10-16 18:33:51 --> Loader Class Initialized
INFO - 2016-10-16 18:33:51 --> Helper loaded: url_helper
INFO - 2016-10-16 18:33:51 --> Helper loaded: form_helper
INFO - 2016-10-16 18:33:51 --> Database Driver Class Initialized
INFO - 2016-10-16 18:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:33:51 --> Controller Class Initialized
INFO - 2016-10-16 18:33:51 --> Form Validation Class Initialized
INFO - 2016-10-16 18:34:51 --> Config Class Initialized
INFO - 2016-10-16 18:34:51 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:34:51 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:34:51 --> Utf8 Class Initialized
INFO - 2016-10-16 18:34:52 --> URI Class Initialized
DEBUG - 2016-10-16 18:34:52 --> No URI present. Default controller set.
INFO - 2016-10-16 18:34:52 --> Router Class Initialized
INFO - 2016-10-16 18:34:52 --> Output Class Initialized
INFO - 2016-10-16 18:34:52 --> Security Class Initialized
DEBUG - 2016-10-16 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:34:52 --> Input Class Initialized
INFO - 2016-10-16 18:34:52 --> Language Class Initialized
INFO - 2016-10-16 18:34:52 --> Loader Class Initialized
INFO - 2016-10-16 18:34:52 --> Helper loaded: url_helper
INFO - 2016-10-16 18:34:52 --> Helper loaded: form_helper
INFO - 2016-10-16 18:34:52 --> Database Driver Class Initialized
INFO - 2016-10-16 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:34:52 --> Controller Class Initialized
INFO - 2016-10-16 18:34:52 --> Form Validation Class Initialized
INFO - 2016-10-16 18:34:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:34:52 --> Model Class Initialized
ERROR - 2016-10-16 18:34:52 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:34:52 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 28
INFO - 2016-10-16 18:34:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:34:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:34:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:34:52 --> Final output sent to browser
DEBUG - 2016-10-16 18:34:52 --> Total execution time: 0.4242
INFO - 2016-10-16 18:41:14 --> Config Class Initialized
INFO - 2016-10-16 18:41:14 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:41:14 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:41:14 --> Utf8 Class Initialized
INFO - 2016-10-16 18:41:14 --> URI Class Initialized
DEBUG - 2016-10-16 18:41:14 --> No URI present. Default controller set.
INFO - 2016-10-16 18:41:14 --> Router Class Initialized
INFO - 2016-10-16 18:41:14 --> Output Class Initialized
INFO - 2016-10-16 18:41:14 --> Security Class Initialized
DEBUG - 2016-10-16 18:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:41:14 --> Input Class Initialized
INFO - 2016-10-16 18:41:14 --> Language Class Initialized
INFO - 2016-10-16 18:41:14 --> Loader Class Initialized
INFO - 2016-10-16 18:41:14 --> Helper loaded: url_helper
INFO - 2016-10-16 18:41:14 --> Helper loaded: form_helper
INFO - 2016-10-16 18:41:14 --> Database Driver Class Initialized
INFO - 2016-10-16 18:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:41:14 --> Controller Class Initialized
INFO - 2016-10-16 18:41:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:41:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:14 --> Form Validation Class Initialized
INFO - 2016-10-16 18:41:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:41:14 --> Model Class Initialized
ERROR - 2016-10-16 18:41:14 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:41:14 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 30
INFO - 2016-10-16 18:41:14 --> Final output sent to browser
DEBUG - 2016-10-16 18:41:14 --> Total execution time: 0.4527
INFO - 2016-10-16 18:41:26 --> Config Class Initialized
INFO - 2016-10-16 18:41:26 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:41:26 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:41:26 --> Utf8 Class Initialized
INFO - 2016-10-16 18:41:26 --> URI Class Initialized
DEBUG - 2016-10-16 18:41:26 --> No URI present. Default controller set.
INFO - 2016-10-16 18:41:26 --> Router Class Initialized
INFO - 2016-10-16 18:41:26 --> Output Class Initialized
INFO - 2016-10-16 18:41:26 --> Security Class Initialized
DEBUG - 2016-10-16 18:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:41:26 --> Input Class Initialized
INFO - 2016-10-16 18:41:26 --> Language Class Initialized
INFO - 2016-10-16 18:41:26 --> Loader Class Initialized
INFO - 2016-10-16 18:41:26 --> Helper loaded: url_helper
INFO - 2016-10-16 18:41:26 --> Helper loaded: form_helper
INFO - 2016-10-16 18:41:26 --> Database Driver Class Initialized
INFO - 2016-10-16 18:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:41:26 --> Controller Class Initialized
INFO - 2016-10-16 18:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:41:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:26 --> Form Validation Class Initialized
INFO - 2016-10-16 18:41:26 --> Final output sent to browser
DEBUG - 2016-10-16 18:41:26 --> Total execution time: 0.3439
INFO - 2016-10-16 18:41:29 --> Config Class Initialized
INFO - 2016-10-16 18:41:29 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:41:29 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:41:29 --> Utf8 Class Initialized
INFO - 2016-10-16 18:41:29 --> URI Class Initialized
DEBUG - 2016-10-16 18:41:29 --> No URI present. Default controller set.
INFO - 2016-10-16 18:41:29 --> Router Class Initialized
INFO - 2016-10-16 18:41:29 --> Output Class Initialized
INFO - 2016-10-16 18:41:29 --> Security Class Initialized
DEBUG - 2016-10-16 18:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:41:29 --> Input Class Initialized
INFO - 2016-10-16 18:41:29 --> Language Class Initialized
INFO - 2016-10-16 18:41:29 --> Loader Class Initialized
INFO - 2016-10-16 18:41:29 --> Helper loaded: url_helper
INFO - 2016-10-16 18:41:30 --> Helper loaded: form_helper
INFO - 2016-10-16 18:41:30 --> Database Driver Class Initialized
INFO - 2016-10-16 18:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:41:30 --> Controller Class Initialized
INFO - 2016-10-16 18:41:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:41:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:30 --> Form Validation Class Initialized
INFO - 2016-10-16 18:41:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:41:30 --> Model Class Initialized
ERROR - 2016-10-16 18:41:30 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\models\Auth_model.php 35
ERROR - 2016-10-16 18:41:30 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 30
INFO - 2016-10-16 18:41:30 --> Final output sent to browser
DEBUG - 2016-10-16 18:41:30 --> Total execution time: 0.4532
INFO - 2016-10-16 18:41:41 --> Config Class Initialized
INFO - 2016-10-16 18:41:41 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:41:41 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:41:41 --> Utf8 Class Initialized
INFO - 2016-10-16 18:41:41 --> URI Class Initialized
DEBUG - 2016-10-16 18:41:41 --> No URI present. Default controller set.
INFO - 2016-10-16 18:41:41 --> Router Class Initialized
INFO - 2016-10-16 18:41:41 --> Output Class Initialized
INFO - 2016-10-16 18:41:41 --> Security Class Initialized
DEBUG - 2016-10-16 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:41:41 --> Input Class Initialized
INFO - 2016-10-16 18:41:41 --> Language Class Initialized
INFO - 2016-10-16 18:41:41 --> Loader Class Initialized
INFO - 2016-10-16 18:41:41 --> Helper loaded: url_helper
INFO - 2016-10-16 18:41:41 --> Helper loaded: form_helper
INFO - 2016-10-16 18:41:41 --> Database Driver Class Initialized
INFO - 2016-10-16 18:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:41:41 --> Controller Class Initialized
INFO - 2016-10-16 18:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:41:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:41 --> Form Validation Class Initialized
INFO - 2016-10-16 18:41:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:41:41 --> Model Class Initialized
ERROR - 2016-10-16 18:41:41 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\models\Auth_model.php 31
ERROR - 2016-10-16 18:41:41 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 30
ERROR - 2016-10-16 18:41:41 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 33
INFO - 2016-10-16 18:41:41 --> Final output sent to browser
DEBUG - 2016-10-16 18:41:41 --> Total execution time: 0.4686
INFO - 2016-10-16 18:41:56 --> Config Class Initialized
INFO - 2016-10-16 18:41:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:41:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:41:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:41:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:41:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:41:56 --> Router Class Initialized
INFO - 2016-10-16 18:41:56 --> Output Class Initialized
INFO - 2016-10-16 18:41:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:41:56 --> Input Class Initialized
INFO - 2016-10-16 18:41:56 --> Language Class Initialized
INFO - 2016-10-16 18:41:56 --> Loader Class Initialized
INFO - 2016-10-16 18:41:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:41:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:41:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:41:56 --> Controller Class Initialized
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:56 --> Form Validation Class Initialized
INFO - 2016-10-16 18:41:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-16 18:41:56 --> Model Class Initialized
ERROR - 2016-10-16 18:41:56 --> Severity: Notice --> Use of undefined constant ERR_NONE - assumed 'ERR_NONE' C:\xampp\htdocs\LMS\app\models\Auth_model.php 27
ERROR - 2016-10-16 18:41:56 --> Severity: Notice --> Use of undefined constant ERR_INVALID_USERNAME - assumed 'ERR_INVALID_USERNAME' C:\xampp\htdocs\LMS\app\controllers\Auth.php 30
ERROR - 2016-10-16 18:41:56 --> Severity: Notice --> Use of undefined constant ERR_INVALID_PASSWORD - assumed 'ERR_INVALID_PASSWORD' C:\xampp\htdocs\LMS\app\controllers\Auth.php 33
INFO - 2016-10-16 18:41:56 --> Config Class Initialized
INFO - 2016-10-16 18:41:56 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:41:56 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:41:56 --> Utf8 Class Initialized
INFO - 2016-10-16 18:41:56 --> URI Class Initialized
DEBUG - 2016-10-16 18:41:56 --> No URI present. Default controller set.
INFO - 2016-10-16 18:41:56 --> Router Class Initialized
INFO - 2016-10-16 18:41:56 --> Output Class Initialized
INFO - 2016-10-16 18:41:56 --> Security Class Initialized
DEBUG - 2016-10-16 18:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:41:56 --> Input Class Initialized
INFO - 2016-10-16 18:41:56 --> Language Class Initialized
INFO - 2016-10-16 18:41:56 --> Loader Class Initialized
INFO - 2016-10-16 18:41:56 --> Helper loaded: url_helper
INFO - 2016-10-16 18:41:56 --> Helper loaded: form_helper
INFO - 2016-10-16 18:41:56 --> Database Driver Class Initialized
INFO - 2016-10-16 18:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:41:56 --> Controller Class Initialized
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-10-16 18:41:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-10-16 18:41:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-10-16 18:41:57 --> Form Validation Class Initialized
INFO - 2016-10-16 18:41:57 --> Final output sent to browser
DEBUG - 2016-10-16 18:41:57 --> Total execution time: 0.4184
INFO - 2016-10-16 18:44:43 --> Config Class Initialized
INFO - 2016-10-16 18:44:43 --> Hooks Class Initialized
DEBUG - 2016-10-16 18:44:43 --> UTF-8 Support Enabled
INFO - 2016-10-16 18:44:43 --> Utf8 Class Initialized
INFO - 2016-10-16 18:44:43 --> URI Class Initialized
DEBUG - 2016-10-16 18:44:43 --> No URI present. Default controller set.
INFO - 2016-10-16 18:44:43 --> Router Class Initialized
INFO - 2016-10-16 18:44:43 --> Output Class Initialized
INFO - 2016-10-16 18:44:44 --> Security Class Initialized
DEBUG - 2016-10-16 18:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 18:44:44 --> Input Class Initialized
INFO - 2016-10-16 18:44:44 --> Language Class Initialized
INFO - 2016-10-16 18:44:44 --> Loader Class Initialized
INFO - 2016-10-16 18:44:44 --> Helper loaded: url_helper
INFO - 2016-10-16 18:44:44 --> Helper loaded: form_helper
INFO - 2016-10-16 18:44:44 --> Database Driver Class Initialized
INFO - 2016-10-16 18:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 18:44:44 --> Controller Class Initialized
