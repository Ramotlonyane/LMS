<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-12 00:05:16 --> Config Class Initialized
INFO - 2016-11-12 00:05:16 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:05:16 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:05:16 --> Utf8 Class Initialized
INFO - 2016-11-12 00:05:16 --> URI Class Initialized
DEBUG - 2016-11-12 00:05:16 --> No URI present. Default controller set.
INFO - 2016-11-12 00:05:16 --> Router Class Initialized
INFO - 2016-11-12 00:05:16 --> Output Class Initialized
INFO - 2016-11-12 00:05:16 --> Security Class Initialized
DEBUG - 2016-11-12 00:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:05:16 --> Input Class Initialized
INFO - 2016-11-12 00:05:16 --> Language Class Initialized
INFO - 2016-11-12 00:05:16 --> Loader Class Initialized
INFO - 2016-11-12 00:05:16 --> Helper loaded: url_helper
INFO - 2016-11-12 00:05:16 --> Helper loaded: form_helper
INFO - 2016-11-12 00:05:16 --> Database Driver Class Initialized
INFO - 2016-11-12 00:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:05:16 --> Controller Class Initialized
INFO - 2016-11-12 00:05:16 --> Model Class Initialized
INFO - 2016-11-12 00:05:16 --> Model Class Initialized
INFO - 2016-11-12 00:05:16 --> Model Class Initialized
INFO - 2016-11-12 00:05:16 --> Model Class Initialized
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:05:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:05:16 --> Final output sent to browser
DEBUG - 2016-11-12 00:05:16 --> Total execution time: 0.2719
INFO - 2016-11-12 00:06:09 --> Config Class Initialized
INFO - 2016-11-12 00:06:09 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:06:09 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:06:09 --> Utf8 Class Initialized
INFO - 2016-11-12 00:06:09 --> URI Class Initialized
DEBUG - 2016-11-12 00:06:09 --> No URI present. Default controller set.
INFO - 2016-11-12 00:06:09 --> Router Class Initialized
INFO - 2016-11-12 00:06:09 --> Output Class Initialized
INFO - 2016-11-12 00:06:09 --> Security Class Initialized
DEBUG - 2016-11-12 00:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:06:09 --> Input Class Initialized
INFO - 2016-11-12 00:06:09 --> Language Class Initialized
INFO - 2016-11-12 00:06:09 --> Loader Class Initialized
INFO - 2016-11-12 00:06:09 --> Helper loaded: url_helper
INFO - 2016-11-12 00:06:09 --> Helper loaded: form_helper
INFO - 2016-11-12 00:06:09 --> Database Driver Class Initialized
INFO - 2016-11-12 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:06:09 --> Controller Class Initialized
INFO - 2016-11-12 00:06:09 --> Model Class Initialized
INFO - 2016-11-12 00:06:09 --> Model Class Initialized
INFO - 2016-11-12 00:06:09 --> Model Class Initialized
INFO - 2016-11-12 00:06:09 --> Model Class Initialized
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:06:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:06:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:06:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:06:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:06:10 --> Final output sent to browser
DEBUG - 2016-11-12 00:06:10 --> Total execution time: 0.3470
INFO - 2016-11-12 00:06:26 --> Config Class Initialized
INFO - 2016-11-12 00:06:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:06:26 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:06:26 --> Utf8 Class Initialized
INFO - 2016-11-12 00:06:26 --> URI Class Initialized
DEBUG - 2016-11-12 00:06:26 --> No URI present. Default controller set.
INFO - 2016-11-12 00:06:26 --> Router Class Initialized
INFO - 2016-11-12 00:06:26 --> Output Class Initialized
INFO - 2016-11-12 00:06:26 --> Security Class Initialized
DEBUG - 2016-11-12 00:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:06:26 --> Input Class Initialized
INFO - 2016-11-12 00:06:26 --> Language Class Initialized
INFO - 2016-11-12 00:06:26 --> Loader Class Initialized
INFO - 2016-11-12 00:06:26 --> Helper loaded: url_helper
INFO - 2016-11-12 00:06:26 --> Helper loaded: form_helper
INFO - 2016-11-12 00:06:26 --> Database Driver Class Initialized
INFO - 2016-11-12 00:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:06:26 --> Controller Class Initialized
INFO - 2016-11-12 00:06:26 --> Model Class Initialized
INFO - 2016-11-12 00:06:26 --> Model Class Initialized
INFO - 2016-11-12 00:06:26 --> Model Class Initialized
INFO - 2016-11-12 00:06:26 --> Model Class Initialized
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:06:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:06:26 --> Final output sent to browser
DEBUG - 2016-11-12 00:06:26 --> Total execution time: 0.3265
INFO - 2016-11-12 00:07:01 --> Config Class Initialized
INFO - 2016-11-12 00:07:01 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:07:01 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:07:01 --> Utf8 Class Initialized
INFO - 2016-11-12 00:07:01 --> URI Class Initialized
DEBUG - 2016-11-12 00:07:01 --> No URI present. Default controller set.
INFO - 2016-11-12 00:07:01 --> Router Class Initialized
INFO - 2016-11-12 00:07:01 --> Output Class Initialized
INFO - 2016-11-12 00:07:01 --> Security Class Initialized
DEBUG - 2016-11-12 00:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:07:01 --> Input Class Initialized
INFO - 2016-11-12 00:07:01 --> Language Class Initialized
INFO - 2016-11-12 00:07:01 --> Loader Class Initialized
INFO - 2016-11-12 00:07:01 --> Helper loaded: url_helper
INFO - 2016-11-12 00:07:01 --> Helper loaded: form_helper
INFO - 2016-11-12 00:07:01 --> Database Driver Class Initialized
INFO - 2016-11-12 00:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:07:01 --> Controller Class Initialized
INFO - 2016-11-12 00:07:01 --> Model Class Initialized
INFO - 2016-11-12 00:07:01 --> Model Class Initialized
INFO - 2016-11-12 00:07:01 --> Model Class Initialized
INFO - 2016-11-12 00:07:01 --> Model Class Initialized
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:07:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:07:01 --> Final output sent to browser
DEBUG - 2016-11-12 00:07:01 --> Total execution time: 0.2815
INFO - 2016-11-12 00:07:23 --> Config Class Initialized
INFO - 2016-11-12 00:07:23 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:07:23 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:07:23 --> Utf8 Class Initialized
INFO - 2016-11-12 00:07:23 --> URI Class Initialized
DEBUG - 2016-11-12 00:07:23 --> No URI present. Default controller set.
INFO - 2016-11-12 00:07:23 --> Router Class Initialized
INFO - 2016-11-12 00:07:23 --> Output Class Initialized
INFO - 2016-11-12 00:07:23 --> Security Class Initialized
DEBUG - 2016-11-12 00:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:07:23 --> Input Class Initialized
INFO - 2016-11-12 00:07:23 --> Language Class Initialized
INFO - 2016-11-12 00:07:23 --> Loader Class Initialized
INFO - 2016-11-12 00:07:23 --> Helper loaded: url_helper
INFO - 2016-11-12 00:07:23 --> Helper loaded: form_helper
INFO - 2016-11-12 00:07:23 --> Database Driver Class Initialized
INFO - 2016-11-12 00:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:07:23 --> Controller Class Initialized
INFO - 2016-11-12 00:07:24 --> Model Class Initialized
INFO - 2016-11-12 00:07:24 --> Model Class Initialized
INFO - 2016-11-12 00:07:24 --> Model Class Initialized
INFO - 2016-11-12 00:07:24 --> Model Class Initialized
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:07:24 --> Final output sent to browser
DEBUG - 2016-11-12 00:07:24 --> Total execution time: 0.2806
INFO - 2016-11-12 00:10:37 --> Config Class Initialized
INFO - 2016-11-12 00:10:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:10:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:10:37 --> Utf8 Class Initialized
INFO - 2016-11-12 00:10:37 --> URI Class Initialized
DEBUG - 2016-11-12 00:10:37 --> No URI present. Default controller set.
INFO - 2016-11-12 00:10:37 --> Router Class Initialized
INFO - 2016-11-12 00:10:37 --> Output Class Initialized
INFO - 2016-11-12 00:10:37 --> Security Class Initialized
DEBUG - 2016-11-12 00:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:10:37 --> Input Class Initialized
INFO - 2016-11-12 00:10:37 --> Language Class Initialized
INFO - 2016-11-12 00:10:37 --> Loader Class Initialized
INFO - 2016-11-12 00:10:37 --> Helper loaded: url_helper
INFO - 2016-11-12 00:10:37 --> Helper loaded: form_helper
INFO - 2016-11-12 00:10:37 --> Database Driver Class Initialized
INFO - 2016-11-12 00:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:10:37 --> Controller Class Initialized
INFO - 2016-11-12 00:10:37 --> Model Class Initialized
INFO - 2016-11-12 00:10:37 --> Model Class Initialized
INFO - 2016-11-12 00:10:37 --> Model Class Initialized
INFO - 2016-11-12 00:10:37 --> Model Class Initialized
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:10:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:10:37 --> Final output sent to browser
DEBUG - 2016-11-12 00:10:37 --> Total execution time: 0.2956
INFO - 2016-11-12 00:11:00 --> Config Class Initialized
INFO - 2016-11-12 00:11:00 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:11:00 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:11:00 --> Utf8 Class Initialized
INFO - 2016-11-12 00:11:00 --> URI Class Initialized
DEBUG - 2016-11-12 00:11:00 --> No URI present. Default controller set.
INFO - 2016-11-12 00:11:00 --> Router Class Initialized
INFO - 2016-11-12 00:11:00 --> Output Class Initialized
INFO - 2016-11-12 00:11:00 --> Security Class Initialized
DEBUG - 2016-11-12 00:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:11:00 --> Input Class Initialized
INFO - 2016-11-12 00:11:00 --> Language Class Initialized
INFO - 2016-11-12 00:11:00 --> Loader Class Initialized
INFO - 2016-11-12 00:11:00 --> Helper loaded: url_helper
INFO - 2016-11-12 00:11:00 --> Helper loaded: form_helper
INFO - 2016-11-12 00:11:00 --> Database Driver Class Initialized
INFO - 2016-11-12 00:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:11:00 --> Controller Class Initialized
INFO - 2016-11-12 00:11:00 --> Model Class Initialized
INFO - 2016-11-12 00:11:00 --> Model Class Initialized
INFO - 2016-11-12 00:11:00 --> Model Class Initialized
INFO - 2016-11-12 00:11:00 --> Model Class Initialized
INFO - 2016-11-12 00:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:11:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:11:01 --> Final output sent to browser
DEBUG - 2016-11-12 00:11:01 --> Total execution time: 0.3002
INFO - 2016-11-12 00:11:05 --> Config Class Initialized
INFO - 2016-11-12 00:11:05 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:11:05 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:11:05 --> Utf8 Class Initialized
INFO - 2016-11-12 00:11:05 --> URI Class Initialized
DEBUG - 2016-11-12 00:11:05 --> No URI present. Default controller set.
INFO - 2016-11-12 00:11:05 --> Router Class Initialized
INFO - 2016-11-12 00:11:05 --> Output Class Initialized
INFO - 2016-11-12 00:11:05 --> Security Class Initialized
DEBUG - 2016-11-12 00:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:11:05 --> Input Class Initialized
INFO - 2016-11-12 00:11:05 --> Language Class Initialized
INFO - 2016-11-12 00:11:05 --> Loader Class Initialized
INFO - 2016-11-12 00:11:05 --> Helper loaded: url_helper
INFO - 2016-11-12 00:11:05 --> Helper loaded: form_helper
INFO - 2016-11-12 00:11:05 --> Database Driver Class Initialized
INFO - 2016-11-12 00:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:11:05 --> Controller Class Initialized
INFO - 2016-11-12 00:11:05 --> Model Class Initialized
INFO - 2016-11-12 00:11:05 --> Model Class Initialized
INFO - 2016-11-12 00:11:05 --> Model Class Initialized
INFO - 2016-11-12 00:11:05 --> Model Class Initialized
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:11:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:11:05 --> Final output sent to browser
DEBUG - 2016-11-12 00:11:05 --> Total execution time: 0.3033
INFO - 2016-11-12 00:11:32 --> Config Class Initialized
INFO - 2016-11-12 00:11:32 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:11:32 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:11:32 --> Utf8 Class Initialized
INFO - 2016-11-12 00:11:32 --> URI Class Initialized
DEBUG - 2016-11-12 00:11:33 --> No URI present. Default controller set.
INFO - 2016-11-12 00:11:33 --> Router Class Initialized
INFO - 2016-11-12 00:11:33 --> Output Class Initialized
INFO - 2016-11-12 00:11:33 --> Security Class Initialized
DEBUG - 2016-11-12 00:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:11:33 --> Input Class Initialized
INFO - 2016-11-12 00:11:33 --> Language Class Initialized
INFO - 2016-11-12 00:11:33 --> Loader Class Initialized
INFO - 2016-11-12 00:11:33 --> Helper loaded: url_helper
INFO - 2016-11-12 00:11:33 --> Helper loaded: form_helper
INFO - 2016-11-12 00:11:33 --> Database Driver Class Initialized
INFO - 2016-11-12 00:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:11:33 --> Controller Class Initialized
INFO - 2016-11-12 00:11:33 --> Model Class Initialized
INFO - 2016-11-12 00:11:33 --> Model Class Initialized
INFO - 2016-11-12 00:11:33 --> Model Class Initialized
INFO - 2016-11-12 00:11:33 --> Model Class Initialized
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:11:33 --> Final output sent to browser
DEBUG - 2016-11-12 00:11:33 --> Total execution time: 0.3181
INFO - 2016-11-12 00:14:40 --> Config Class Initialized
INFO - 2016-11-12 00:14:40 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:14:40 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:14:40 --> Utf8 Class Initialized
INFO - 2016-11-12 00:14:41 --> URI Class Initialized
DEBUG - 2016-11-12 00:14:41 --> No URI present. Default controller set.
INFO - 2016-11-12 00:14:41 --> Router Class Initialized
INFO - 2016-11-12 00:14:41 --> Output Class Initialized
INFO - 2016-11-12 00:14:41 --> Security Class Initialized
DEBUG - 2016-11-12 00:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:14:41 --> Input Class Initialized
INFO - 2016-11-12 00:14:41 --> Language Class Initialized
INFO - 2016-11-12 00:14:41 --> Loader Class Initialized
INFO - 2016-11-12 00:14:41 --> Helper loaded: url_helper
INFO - 2016-11-12 00:14:41 --> Helper loaded: form_helper
INFO - 2016-11-12 00:14:41 --> Database Driver Class Initialized
INFO - 2016-11-12 00:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:14:41 --> Controller Class Initialized
INFO - 2016-11-12 00:14:41 --> Model Class Initialized
INFO - 2016-11-12 00:14:41 --> Model Class Initialized
INFO - 2016-11-12 00:14:41 --> Model Class Initialized
INFO - 2016-11-12 00:14:41 --> Model Class Initialized
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:14:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:14:41 --> Final output sent to browser
DEBUG - 2016-11-12 00:14:41 --> Total execution time: 0.3222
INFO - 2016-11-12 00:16:27 --> Config Class Initialized
INFO - 2016-11-12 00:16:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:16:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:16:27 --> Utf8 Class Initialized
INFO - 2016-11-12 00:16:27 --> URI Class Initialized
DEBUG - 2016-11-12 00:16:27 --> No URI present. Default controller set.
INFO - 2016-11-12 00:16:27 --> Router Class Initialized
INFO - 2016-11-12 00:16:27 --> Output Class Initialized
INFO - 2016-11-12 00:16:27 --> Security Class Initialized
DEBUG - 2016-11-12 00:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:16:27 --> Input Class Initialized
INFO - 2016-11-12 00:16:27 --> Language Class Initialized
INFO - 2016-11-12 00:16:27 --> Loader Class Initialized
INFO - 2016-11-12 00:16:27 --> Helper loaded: url_helper
INFO - 2016-11-12 00:16:27 --> Helper loaded: form_helper
INFO - 2016-11-12 00:16:27 --> Database Driver Class Initialized
INFO - 2016-11-12 00:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:16:27 --> Controller Class Initialized
INFO - 2016-11-12 00:16:27 --> Model Class Initialized
INFO - 2016-11-12 00:16:27 --> Model Class Initialized
INFO - 2016-11-12 00:16:27 --> Model Class Initialized
INFO - 2016-11-12 00:16:27 --> Model Class Initialized
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:16:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:16:27 --> Final output sent to browser
DEBUG - 2016-11-12 00:16:27 --> Total execution time: 0.3024
INFO - 2016-11-12 00:16:42 --> Config Class Initialized
INFO - 2016-11-12 00:16:42 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:16:42 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:16:42 --> Utf8 Class Initialized
INFO - 2016-11-12 00:16:42 --> URI Class Initialized
DEBUG - 2016-11-12 00:16:42 --> No URI present. Default controller set.
INFO - 2016-11-12 00:16:42 --> Router Class Initialized
INFO - 2016-11-12 00:16:42 --> Output Class Initialized
INFO - 2016-11-12 00:16:42 --> Security Class Initialized
DEBUG - 2016-11-12 00:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:16:42 --> Input Class Initialized
INFO - 2016-11-12 00:16:42 --> Language Class Initialized
INFO - 2016-11-12 00:16:42 --> Loader Class Initialized
INFO - 2016-11-12 00:16:42 --> Helper loaded: url_helper
INFO - 2016-11-12 00:16:42 --> Helper loaded: form_helper
INFO - 2016-11-12 00:16:42 --> Database Driver Class Initialized
INFO - 2016-11-12 00:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:16:42 --> Controller Class Initialized
INFO - 2016-11-12 00:16:42 --> Model Class Initialized
INFO - 2016-11-12 00:16:42 --> Model Class Initialized
INFO - 2016-11-12 00:16:42 --> Model Class Initialized
INFO - 2016-11-12 00:16:42 --> Model Class Initialized
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:16:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:16:43 --> Final output sent to browser
DEBUG - 2016-11-12 00:16:43 --> Total execution time: 0.3286
INFO - 2016-11-12 00:16:44 --> Config Class Initialized
INFO - 2016-11-12 00:16:44 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:16:44 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:16:44 --> Utf8 Class Initialized
INFO - 2016-11-12 00:16:44 --> URI Class Initialized
DEBUG - 2016-11-12 00:16:44 --> No URI present. Default controller set.
INFO - 2016-11-12 00:16:44 --> Router Class Initialized
INFO - 2016-11-12 00:16:44 --> Output Class Initialized
INFO - 2016-11-12 00:16:44 --> Security Class Initialized
DEBUG - 2016-11-12 00:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:16:44 --> Input Class Initialized
INFO - 2016-11-12 00:16:44 --> Language Class Initialized
INFO - 2016-11-12 00:16:44 --> Loader Class Initialized
INFO - 2016-11-12 00:16:44 --> Helper loaded: url_helper
INFO - 2016-11-12 00:16:44 --> Helper loaded: form_helper
INFO - 2016-11-12 00:16:44 --> Database Driver Class Initialized
INFO - 2016-11-12 00:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:16:44 --> Controller Class Initialized
INFO - 2016-11-12 00:16:44 --> Model Class Initialized
INFO - 2016-11-12 00:16:45 --> Model Class Initialized
INFO - 2016-11-12 00:16:45 --> Model Class Initialized
INFO - 2016-11-12 00:16:45 --> Model Class Initialized
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:16:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:16:45 --> Final output sent to browser
DEBUG - 2016-11-12 00:16:45 --> Total execution time: 0.3307
INFO - 2016-11-12 00:22:09 --> Config Class Initialized
INFO - 2016-11-12 00:22:09 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:22:09 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:22:09 --> Utf8 Class Initialized
INFO - 2016-11-12 00:22:09 --> URI Class Initialized
DEBUG - 2016-11-12 00:22:09 --> No URI present. Default controller set.
INFO - 2016-11-12 00:22:09 --> Router Class Initialized
INFO - 2016-11-12 00:22:09 --> Output Class Initialized
INFO - 2016-11-12 00:22:09 --> Security Class Initialized
DEBUG - 2016-11-12 00:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:22:09 --> Input Class Initialized
INFO - 2016-11-12 00:22:09 --> Language Class Initialized
INFO - 2016-11-12 00:22:09 --> Loader Class Initialized
INFO - 2016-11-12 00:22:09 --> Helper loaded: url_helper
INFO - 2016-11-12 00:22:09 --> Helper loaded: form_helper
INFO - 2016-11-12 00:22:09 --> Database Driver Class Initialized
INFO - 2016-11-12 00:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:22:09 --> Controller Class Initialized
INFO - 2016-11-12 00:22:09 --> Model Class Initialized
INFO - 2016-11-12 00:22:09 --> Model Class Initialized
INFO - 2016-11-12 00:22:09 --> Model Class Initialized
INFO - 2016-11-12 00:22:09 --> Model Class Initialized
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:22:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:22:09 --> Final output sent to browser
DEBUG - 2016-11-12 00:22:09 --> Total execution time: 0.3356
INFO - 2016-11-12 00:24:14 --> Config Class Initialized
INFO - 2016-11-12 00:24:14 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:24:14 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:24:14 --> Utf8 Class Initialized
INFO - 2016-11-12 00:24:14 --> URI Class Initialized
INFO - 2016-11-12 00:24:14 --> Router Class Initialized
INFO - 2016-11-12 00:24:14 --> Output Class Initialized
INFO - 2016-11-12 00:24:14 --> Security Class Initialized
DEBUG - 2016-11-12 00:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:24:14 --> Input Class Initialized
INFO - 2016-11-12 00:24:14 --> Language Class Initialized
INFO - 2016-11-12 00:24:14 --> Loader Class Initialized
INFO - 2016-11-12 00:24:14 --> Helper loaded: url_helper
INFO - 2016-11-12 00:24:14 --> Helper loaded: form_helper
INFO - 2016-11-12 00:24:14 --> Database Driver Class Initialized
INFO - 2016-11-12 00:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:24:14 --> Controller Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
DEBUG - 2016-11-12 00:24:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 00:24:14 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 00:24:14 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 00:24:14 --> Config Class Initialized
INFO - 2016-11-12 00:24:14 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:24:14 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:24:14 --> Utf8 Class Initialized
INFO - 2016-11-12 00:24:14 --> URI Class Initialized
DEBUG - 2016-11-12 00:24:14 --> No URI present. Default controller set.
INFO - 2016-11-12 00:24:14 --> Router Class Initialized
INFO - 2016-11-12 00:24:14 --> Output Class Initialized
INFO - 2016-11-12 00:24:14 --> Security Class Initialized
DEBUG - 2016-11-12 00:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:24:14 --> Input Class Initialized
INFO - 2016-11-12 00:24:14 --> Language Class Initialized
INFO - 2016-11-12 00:24:14 --> Loader Class Initialized
INFO - 2016-11-12 00:24:14 --> Helper loaded: url_helper
INFO - 2016-11-12 00:24:14 --> Helper loaded: form_helper
INFO - 2016-11-12 00:24:14 --> Database Driver Class Initialized
INFO - 2016-11-12 00:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:24:14 --> Controller Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> Model Class Initialized
INFO - 2016-11-12 00:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 00:24:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:24:14 --> Final output sent to browser
DEBUG - 2016-11-12 00:24:14 --> Total execution time: 0.2776
INFO - 2016-11-12 00:24:22 --> Config Class Initialized
INFO - 2016-11-12 00:24:22 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:24:22 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:24:22 --> Utf8 Class Initialized
INFO - 2016-11-12 00:24:22 --> URI Class Initialized
INFO - 2016-11-12 00:24:22 --> Router Class Initialized
INFO - 2016-11-12 00:24:22 --> Output Class Initialized
INFO - 2016-11-12 00:24:22 --> Security Class Initialized
DEBUG - 2016-11-12 00:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:24:22 --> Input Class Initialized
INFO - 2016-11-12 00:24:22 --> Language Class Initialized
INFO - 2016-11-12 00:24:22 --> Loader Class Initialized
INFO - 2016-11-12 00:24:22 --> Helper loaded: url_helper
INFO - 2016-11-12 00:24:22 --> Helper loaded: form_helper
INFO - 2016-11-12 00:24:22 --> Database Driver Class Initialized
INFO - 2016-11-12 00:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:24:22 --> Controller Class Initialized
INFO - 2016-11-12 00:24:22 --> Model Class Initialized
INFO - 2016-11-12 00:24:22 --> Model Class Initialized
INFO - 2016-11-12 00:24:22 --> Model Class Initialized
INFO - 2016-11-12 00:24:22 --> Model Class Initialized
DEBUG - 2016-11-12 00:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 00:24:22 --> Model Class Initialized
INFO - 2016-11-12 00:24:22 --> Final output sent to browser
DEBUG - 2016-11-12 00:24:22 --> Total execution time: 0.2188
INFO - 2016-11-12 00:24:22 --> Config Class Initialized
INFO - 2016-11-12 00:24:23 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:24:23 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:24:23 --> Utf8 Class Initialized
INFO - 2016-11-12 00:24:23 --> URI Class Initialized
DEBUG - 2016-11-12 00:24:23 --> No URI present. Default controller set.
INFO - 2016-11-12 00:24:23 --> Router Class Initialized
INFO - 2016-11-12 00:24:23 --> Output Class Initialized
INFO - 2016-11-12 00:24:23 --> Security Class Initialized
DEBUG - 2016-11-12 00:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:24:23 --> Input Class Initialized
INFO - 2016-11-12 00:24:23 --> Language Class Initialized
INFO - 2016-11-12 00:24:23 --> Loader Class Initialized
INFO - 2016-11-12 00:24:23 --> Helper loaded: url_helper
INFO - 2016-11-12 00:24:23 --> Helper loaded: form_helper
INFO - 2016-11-12 00:24:23 --> Database Driver Class Initialized
INFO - 2016-11-12 00:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:24:23 --> Controller Class Initialized
INFO - 2016-11-12 00:24:23 --> Model Class Initialized
INFO - 2016-11-12 00:24:23 --> Model Class Initialized
INFO - 2016-11-12 00:24:23 --> Model Class Initialized
INFO - 2016-11-12 00:24:23 --> Model Class Initialized
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:24:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:24:23 --> Final output sent to browser
DEBUG - 2016-11-12 00:24:23 --> Total execution time: 0.3199
INFO - 2016-11-12 00:24:27 --> Config Class Initialized
INFO - 2016-11-12 00:24:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:24:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:24:27 --> Utf8 Class Initialized
INFO - 2016-11-12 00:24:27 --> URI Class Initialized
INFO - 2016-11-12 00:24:27 --> Router Class Initialized
INFO - 2016-11-12 00:24:27 --> Output Class Initialized
INFO - 2016-11-12 00:24:27 --> Security Class Initialized
DEBUG - 2016-11-12 00:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:24:27 --> Input Class Initialized
INFO - 2016-11-12 00:24:27 --> Language Class Initialized
INFO - 2016-11-12 00:24:27 --> Loader Class Initialized
INFO - 2016-11-12 00:24:28 --> Helper loaded: url_helper
INFO - 2016-11-12 00:24:28 --> Helper loaded: form_helper
INFO - 2016-11-12 00:24:28 --> Database Driver Class Initialized
INFO - 2016-11-12 00:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:24:28 --> Controller Class Initialized
INFO - 2016-11-12 00:24:28 --> Model Class Initialized
INFO - 2016-11-12 00:24:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-12 00:24:28 --> Final output sent to browser
DEBUG - 2016-11-12 00:24:28 --> Total execution time: 0.4215
INFO - 2016-11-12 00:29:49 --> Config Class Initialized
INFO - 2016-11-12 00:29:49 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:29:49 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:29:49 --> Utf8 Class Initialized
INFO - 2016-11-12 00:29:49 --> URI Class Initialized
DEBUG - 2016-11-12 00:29:49 --> No URI present. Default controller set.
INFO - 2016-11-12 00:29:50 --> Router Class Initialized
INFO - 2016-11-12 00:29:50 --> Output Class Initialized
INFO - 2016-11-12 00:29:50 --> Security Class Initialized
DEBUG - 2016-11-12 00:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:29:50 --> Input Class Initialized
INFO - 2016-11-12 00:29:50 --> Language Class Initialized
INFO - 2016-11-12 00:29:50 --> Loader Class Initialized
INFO - 2016-11-12 00:29:50 --> Helper loaded: url_helper
INFO - 2016-11-12 00:29:50 --> Helper loaded: form_helper
INFO - 2016-11-12 00:29:50 --> Database Driver Class Initialized
INFO - 2016-11-12 00:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:29:50 --> Controller Class Initialized
INFO - 2016-11-12 00:29:50 --> Model Class Initialized
INFO - 2016-11-12 00:29:50 --> Model Class Initialized
INFO - 2016-11-12 00:29:50 --> Model Class Initialized
INFO - 2016-11-12 00:29:50 --> Model Class Initialized
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:29:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:29:50 --> Final output sent to browser
DEBUG - 2016-11-12 00:29:50 --> Total execution time: 0.3077
INFO - 2016-11-12 00:29:51 --> Config Class Initialized
INFO - 2016-11-12 00:29:51 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:29:51 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:29:52 --> Utf8 Class Initialized
INFO - 2016-11-12 00:29:52 --> URI Class Initialized
INFO - 2016-11-12 00:29:52 --> Router Class Initialized
INFO - 2016-11-12 00:29:52 --> Output Class Initialized
INFO - 2016-11-12 00:29:52 --> Security Class Initialized
DEBUG - 2016-11-12 00:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:29:52 --> Input Class Initialized
INFO - 2016-11-12 00:29:52 --> Language Class Initialized
INFO - 2016-11-12 00:29:52 --> Loader Class Initialized
INFO - 2016-11-12 00:29:52 --> Helper loaded: url_helper
INFO - 2016-11-12 00:29:52 --> Helper loaded: form_helper
INFO - 2016-11-12 00:29:52 --> Database Driver Class Initialized
INFO - 2016-11-12 00:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:29:52 --> Controller Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
DEBUG - 2016-11-12 00:29:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 00:29:52 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 00:29:52 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 00:29:52 --> Config Class Initialized
INFO - 2016-11-12 00:29:52 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:29:52 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:29:52 --> Utf8 Class Initialized
INFO - 2016-11-12 00:29:52 --> URI Class Initialized
DEBUG - 2016-11-12 00:29:52 --> No URI present. Default controller set.
INFO - 2016-11-12 00:29:52 --> Router Class Initialized
INFO - 2016-11-12 00:29:52 --> Output Class Initialized
INFO - 2016-11-12 00:29:52 --> Security Class Initialized
DEBUG - 2016-11-12 00:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:29:52 --> Input Class Initialized
INFO - 2016-11-12 00:29:52 --> Language Class Initialized
INFO - 2016-11-12 00:29:52 --> Loader Class Initialized
INFO - 2016-11-12 00:29:52 --> Helper loaded: url_helper
INFO - 2016-11-12 00:29:52 --> Helper loaded: form_helper
INFO - 2016-11-12 00:29:52 --> Database Driver Class Initialized
INFO - 2016-11-12 00:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:29:52 --> Controller Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> Model Class Initialized
INFO - 2016-11-12 00:29:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:29:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 00:29:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:29:52 --> Final output sent to browser
DEBUG - 2016-11-12 00:29:52 --> Total execution time: 0.2275
INFO - 2016-11-12 00:30:01 --> Config Class Initialized
INFO - 2016-11-12 00:30:01 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:30:01 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:30:01 --> Utf8 Class Initialized
INFO - 2016-11-12 00:30:01 --> URI Class Initialized
INFO - 2016-11-12 00:30:01 --> Router Class Initialized
INFO - 2016-11-12 00:30:01 --> Output Class Initialized
INFO - 2016-11-12 00:30:01 --> Security Class Initialized
DEBUG - 2016-11-12 00:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:30:01 --> Input Class Initialized
INFO - 2016-11-12 00:30:01 --> Language Class Initialized
INFO - 2016-11-12 00:30:01 --> Loader Class Initialized
INFO - 2016-11-12 00:30:01 --> Helper loaded: url_helper
INFO - 2016-11-12 00:30:01 --> Helper loaded: form_helper
INFO - 2016-11-12 00:30:01 --> Database Driver Class Initialized
INFO - 2016-11-12 00:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:30:01 --> Controller Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
DEBUG - 2016-11-12 00:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Final output sent to browser
DEBUG - 2016-11-12 00:30:01 --> Total execution time: 0.2275
INFO - 2016-11-12 00:30:01 --> Config Class Initialized
INFO - 2016-11-12 00:30:01 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:30:01 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:30:01 --> Utf8 Class Initialized
INFO - 2016-11-12 00:30:01 --> URI Class Initialized
DEBUG - 2016-11-12 00:30:01 --> No URI present. Default controller set.
INFO - 2016-11-12 00:30:01 --> Router Class Initialized
INFO - 2016-11-12 00:30:01 --> Output Class Initialized
INFO - 2016-11-12 00:30:01 --> Security Class Initialized
DEBUG - 2016-11-12 00:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:30:01 --> Input Class Initialized
INFO - 2016-11-12 00:30:01 --> Language Class Initialized
INFO - 2016-11-12 00:30:01 --> Loader Class Initialized
INFO - 2016-11-12 00:30:01 --> Helper loaded: url_helper
INFO - 2016-11-12 00:30:01 --> Helper loaded: form_helper
INFO - 2016-11-12 00:30:01 --> Database Driver Class Initialized
INFO - 2016-11-12 00:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:30:01 --> Controller Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> Model Class Initialized
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:30:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:30:01 --> Final output sent to browser
DEBUG - 2016-11-12 00:30:01 --> Total execution time: 0.3017
INFO - 2016-11-12 00:33:04 --> Config Class Initialized
INFO - 2016-11-12 00:33:04 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:33:04 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:33:04 --> Utf8 Class Initialized
INFO - 2016-11-12 00:33:04 --> URI Class Initialized
DEBUG - 2016-11-12 00:33:04 --> No URI present. Default controller set.
INFO - 2016-11-12 00:33:04 --> Router Class Initialized
INFO - 2016-11-12 00:33:04 --> Output Class Initialized
INFO - 2016-11-12 00:33:04 --> Security Class Initialized
DEBUG - 2016-11-12 00:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:33:04 --> Input Class Initialized
INFO - 2016-11-12 00:33:04 --> Language Class Initialized
INFO - 2016-11-12 00:33:04 --> Loader Class Initialized
INFO - 2016-11-12 00:33:04 --> Helper loaded: url_helper
INFO - 2016-11-12 00:33:04 --> Helper loaded: form_helper
INFO - 2016-11-12 00:33:04 --> Database Driver Class Initialized
INFO - 2016-11-12 00:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:33:04 --> Controller Class Initialized
INFO - 2016-11-12 00:33:04 --> Model Class Initialized
INFO - 2016-11-12 00:33:04 --> Model Class Initialized
INFO - 2016-11-12 00:33:04 --> Model Class Initialized
INFO - 2016-11-12 00:33:04 --> Model Class Initialized
INFO - 2016-11-12 00:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:33:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:33:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:33:05 --> Final output sent to browser
DEBUG - 2016-11-12 00:33:05 --> Total execution time: 0.3227
INFO - 2016-11-12 00:34:01 --> Config Class Initialized
INFO - 2016-11-12 00:34:01 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:34:01 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:34:01 --> Utf8 Class Initialized
INFO - 2016-11-12 00:34:01 --> URI Class Initialized
DEBUG - 2016-11-12 00:34:01 --> No URI present. Default controller set.
INFO - 2016-11-12 00:34:01 --> Router Class Initialized
INFO - 2016-11-12 00:34:01 --> Output Class Initialized
INFO - 2016-11-12 00:34:01 --> Security Class Initialized
DEBUG - 2016-11-12 00:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:34:01 --> Input Class Initialized
INFO - 2016-11-12 00:34:01 --> Language Class Initialized
INFO - 2016-11-12 00:34:01 --> Loader Class Initialized
INFO - 2016-11-12 00:34:01 --> Helper loaded: url_helper
INFO - 2016-11-12 00:34:01 --> Helper loaded: form_helper
INFO - 2016-11-12 00:34:01 --> Database Driver Class Initialized
INFO - 2016-11-12 00:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:34:01 --> Controller Class Initialized
INFO - 2016-11-12 00:34:01 --> Model Class Initialized
INFO - 2016-11-12 00:34:01 --> Model Class Initialized
INFO - 2016-11-12 00:34:01 --> Model Class Initialized
INFO - 2016-11-12 00:34:01 --> Model Class Initialized
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:34:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:34:01 --> Final output sent to browser
DEBUG - 2016-11-12 00:34:01 --> Total execution time: 0.3466
INFO - 2016-11-12 00:34:27 --> Config Class Initialized
INFO - 2016-11-12 00:34:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:34:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:34:27 --> Utf8 Class Initialized
INFO - 2016-11-12 00:34:27 --> URI Class Initialized
DEBUG - 2016-11-12 00:34:27 --> No URI present. Default controller set.
INFO - 2016-11-12 00:34:27 --> Router Class Initialized
INFO - 2016-11-12 00:34:27 --> Output Class Initialized
INFO - 2016-11-12 00:34:27 --> Security Class Initialized
DEBUG - 2016-11-12 00:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:34:27 --> Input Class Initialized
INFO - 2016-11-12 00:34:27 --> Language Class Initialized
INFO - 2016-11-12 00:34:27 --> Loader Class Initialized
INFO - 2016-11-12 00:34:27 --> Helper loaded: url_helper
INFO - 2016-11-12 00:34:27 --> Helper loaded: form_helper
INFO - 2016-11-12 00:34:27 --> Database Driver Class Initialized
INFO - 2016-11-12 00:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:34:27 --> Controller Class Initialized
INFO - 2016-11-12 00:34:27 --> Model Class Initialized
INFO - 2016-11-12 00:34:27 --> Model Class Initialized
INFO - 2016-11-12 00:34:27 --> Model Class Initialized
INFO - 2016-11-12 00:34:27 --> Model Class Initialized
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:34:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:34:27 --> Final output sent to browser
DEBUG - 2016-11-12 00:34:27 --> Total execution time: 0.3338
INFO - 2016-11-12 00:34:58 --> Config Class Initialized
INFO - 2016-11-12 00:34:58 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:34:58 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:34:58 --> Utf8 Class Initialized
INFO - 2016-11-12 00:34:58 --> URI Class Initialized
DEBUG - 2016-11-12 00:34:58 --> No URI present. Default controller set.
INFO - 2016-11-12 00:34:58 --> Router Class Initialized
INFO - 2016-11-12 00:34:58 --> Output Class Initialized
INFO - 2016-11-12 00:34:58 --> Security Class Initialized
DEBUG - 2016-11-12 00:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:34:58 --> Input Class Initialized
INFO - 2016-11-12 00:34:58 --> Language Class Initialized
INFO - 2016-11-12 00:34:58 --> Loader Class Initialized
INFO - 2016-11-12 00:34:58 --> Helper loaded: url_helper
INFO - 2016-11-12 00:34:58 --> Helper loaded: form_helper
INFO - 2016-11-12 00:34:58 --> Database Driver Class Initialized
INFO - 2016-11-12 00:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:34:58 --> Controller Class Initialized
INFO - 2016-11-12 00:34:58 --> Model Class Initialized
INFO - 2016-11-12 00:34:58 --> Model Class Initialized
INFO - 2016-11-12 00:34:58 --> Model Class Initialized
INFO - 2016-11-12 00:34:58 --> Model Class Initialized
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:34:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:34:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:34:59 --> Final output sent to browser
DEBUG - 2016-11-12 00:34:59 --> Total execution time: 0.3467
INFO - 2016-11-12 00:35:43 --> Config Class Initialized
INFO - 2016-11-12 00:35:43 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:35:43 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:35:43 --> Utf8 Class Initialized
INFO - 2016-11-12 00:35:43 --> URI Class Initialized
DEBUG - 2016-11-12 00:35:43 --> No URI present. Default controller set.
INFO - 2016-11-12 00:35:43 --> Router Class Initialized
INFO - 2016-11-12 00:35:44 --> Output Class Initialized
INFO - 2016-11-12 00:35:44 --> Security Class Initialized
DEBUG - 2016-11-12 00:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:35:44 --> Input Class Initialized
INFO - 2016-11-12 00:35:44 --> Language Class Initialized
INFO - 2016-11-12 00:35:44 --> Loader Class Initialized
INFO - 2016-11-12 00:35:44 --> Helper loaded: url_helper
INFO - 2016-11-12 00:35:44 --> Helper loaded: form_helper
INFO - 2016-11-12 00:35:44 --> Database Driver Class Initialized
INFO - 2016-11-12 00:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:35:44 --> Controller Class Initialized
INFO - 2016-11-12 00:35:44 --> Model Class Initialized
INFO - 2016-11-12 00:35:44 --> Model Class Initialized
INFO - 2016-11-12 00:35:44 --> Model Class Initialized
INFO - 2016-11-12 00:35:44 --> Model Class Initialized
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:35:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:35:44 --> Final output sent to browser
DEBUG - 2016-11-12 00:35:44 --> Total execution time: 0.3771
INFO - 2016-11-12 00:41:17 --> Config Class Initialized
INFO - 2016-11-12 00:41:17 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:41:17 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:41:17 --> Utf8 Class Initialized
INFO - 2016-11-12 00:41:17 --> URI Class Initialized
DEBUG - 2016-11-12 00:41:17 --> No URI present. Default controller set.
INFO - 2016-11-12 00:41:17 --> Router Class Initialized
INFO - 2016-11-12 00:41:17 --> Output Class Initialized
INFO - 2016-11-12 00:41:17 --> Security Class Initialized
DEBUG - 2016-11-12 00:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:41:17 --> Input Class Initialized
INFO - 2016-11-12 00:41:17 --> Language Class Initialized
INFO - 2016-11-12 00:41:17 --> Loader Class Initialized
INFO - 2016-11-12 00:41:17 --> Helper loaded: url_helper
INFO - 2016-11-12 00:41:17 --> Helper loaded: form_helper
INFO - 2016-11-12 00:41:17 --> Database Driver Class Initialized
INFO - 2016-11-12 00:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:41:17 --> Controller Class Initialized
INFO - 2016-11-12 00:41:17 --> Model Class Initialized
INFO - 2016-11-12 00:41:17 --> Model Class Initialized
INFO - 2016-11-12 00:41:17 --> Model Class Initialized
INFO - 2016-11-12 00:41:17 --> Model Class Initialized
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:41:17 --> Final output sent to browser
DEBUG - 2016-11-12 00:41:17 --> Total execution time: 0.3312
INFO - 2016-11-12 00:42:34 --> Config Class Initialized
INFO - 2016-11-12 00:42:34 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:42:34 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:42:34 --> Utf8 Class Initialized
INFO - 2016-11-12 00:42:34 --> URI Class Initialized
DEBUG - 2016-11-12 00:42:34 --> No URI present. Default controller set.
INFO - 2016-11-12 00:42:34 --> Router Class Initialized
INFO - 2016-11-12 00:42:34 --> Output Class Initialized
INFO - 2016-11-12 00:42:34 --> Security Class Initialized
DEBUG - 2016-11-12 00:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:42:34 --> Input Class Initialized
INFO - 2016-11-12 00:42:34 --> Language Class Initialized
INFO - 2016-11-12 00:42:34 --> Loader Class Initialized
INFO - 2016-11-12 00:42:34 --> Helper loaded: url_helper
INFO - 2016-11-12 00:42:34 --> Helper loaded: form_helper
INFO - 2016-11-12 00:42:34 --> Database Driver Class Initialized
INFO - 2016-11-12 00:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:42:34 --> Controller Class Initialized
INFO - 2016-11-12 00:42:34 --> Model Class Initialized
INFO - 2016-11-12 00:42:34 --> Model Class Initialized
INFO - 2016-11-12 00:42:34 --> Model Class Initialized
INFO - 2016-11-12 00:42:34 --> Model Class Initialized
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:42:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:42:34 --> Final output sent to browser
DEBUG - 2016-11-12 00:42:34 --> Total execution time: 0.3232
INFO - 2016-11-12 00:44:13 --> Config Class Initialized
INFO - 2016-11-12 00:44:13 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:44:13 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:44:13 --> Utf8 Class Initialized
INFO - 2016-11-12 00:44:13 --> URI Class Initialized
DEBUG - 2016-11-12 00:44:13 --> No URI present. Default controller set.
INFO - 2016-11-12 00:44:13 --> Router Class Initialized
INFO - 2016-11-12 00:44:13 --> Output Class Initialized
INFO - 2016-11-12 00:44:13 --> Security Class Initialized
DEBUG - 2016-11-12 00:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:44:13 --> Input Class Initialized
INFO - 2016-11-12 00:44:13 --> Language Class Initialized
INFO - 2016-11-12 00:44:13 --> Loader Class Initialized
INFO - 2016-11-12 00:44:13 --> Helper loaded: url_helper
INFO - 2016-11-12 00:44:13 --> Helper loaded: form_helper
INFO - 2016-11-12 00:44:13 --> Database Driver Class Initialized
INFO - 2016-11-12 00:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:44:13 --> Controller Class Initialized
INFO - 2016-11-12 00:44:13 --> Model Class Initialized
INFO - 2016-11-12 00:44:13 --> Model Class Initialized
INFO - 2016-11-12 00:44:13 --> Model Class Initialized
INFO - 2016-11-12 00:44:13 --> Model Class Initialized
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:44:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:44:13 --> Final output sent to browser
DEBUG - 2016-11-12 00:44:13 --> Total execution time: 0.3586
INFO - 2016-11-12 00:44:31 --> Config Class Initialized
INFO - 2016-11-12 00:44:31 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:44:31 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:44:31 --> Utf8 Class Initialized
INFO - 2016-11-12 00:44:31 --> URI Class Initialized
DEBUG - 2016-11-12 00:44:31 --> No URI present. Default controller set.
INFO - 2016-11-12 00:44:31 --> Router Class Initialized
INFO - 2016-11-12 00:44:31 --> Output Class Initialized
INFO - 2016-11-12 00:44:31 --> Security Class Initialized
DEBUG - 2016-11-12 00:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:44:31 --> Input Class Initialized
INFO - 2016-11-12 00:44:31 --> Language Class Initialized
INFO - 2016-11-12 00:44:31 --> Loader Class Initialized
INFO - 2016-11-12 00:44:31 --> Helper loaded: url_helper
INFO - 2016-11-12 00:44:31 --> Helper loaded: form_helper
INFO - 2016-11-12 00:44:31 --> Database Driver Class Initialized
INFO - 2016-11-12 00:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:44:31 --> Controller Class Initialized
INFO - 2016-11-12 00:44:31 --> Model Class Initialized
INFO - 2016-11-12 00:44:31 --> Model Class Initialized
INFO - 2016-11-12 00:44:31 --> Model Class Initialized
INFO - 2016-11-12 00:44:31 --> Model Class Initialized
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:44:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:44:31 --> Final output sent to browser
DEBUG - 2016-11-12 00:44:31 --> Total execution time: 0.3319
INFO - 2016-11-12 00:49:44 --> Config Class Initialized
INFO - 2016-11-12 00:49:44 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:49:44 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:49:44 --> Utf8 Class Initialized
INFO - 2016-11-12 00:49:44 --> URI Class Initialized
DEBUG - 2016-11-12 00:49:44 --> No URI present. Default controller set.
INFO - 2016-11-12 00:49:44 --> Router Class Initialized
INFO - 2016-11-12 00:49:44 --> Output Class Initialized
INFO - 2016-11-12 00:49:44 --> Security Class Initialized
DEBUG - 2016-11-12 00:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:49:44 --> Input Class Initialized
INFO - 2016-11-12 00:49:44 --> Language Class Initialized
INFO - 2016-11-12 00:49:44 --> Loader Class Initialized
INFO - 2016-11-12 00:49:44 --> Helper loaded: url_helper
INFO - 2016-11-12 00:49:44 --> Helper loaded: form_helper
INFO - 2016-11-12 00:49:44 --> Database Driver Class Initialized
INFO - 2016-11-12 00:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:49:44 --> Controller Class Initialized
INFO - 2016-11-12 00:49:44 --> Model Class Initialized
INFO - 2016-11-12 00:49:44 --> Model Class Initialized
INFO - 2016-11-12 00:49:44 --> Model Class Initialized
INFO - 2016-11-12 00:49:44 --> Model Class Initialized
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:49:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:49:44 --> Final output sent to browser
DEBUG - 2016-11-12 00:49:44 --> Total execution time: 0.3448
INFO - 2016-11-12 00:51:18 --> Config Class Initialized
INFO - 2016-11-12 00:51:18 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:51:18 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:51:18 --> Utf8 Class Initialized
INFO - 2016-11-12 00:51:18 --> URI Class Initialized
DEBUG - 2016-11-12 00:51:18 --> No URI present. Default controller set.
INFO - 2016-11-12 00:51:18 --> Router Class Initialized
INFO - 2016-11-12 00:51:18 --> Output Class Initialized
INFO - 2016-11-12 00:51:18 --> Security Class Initialized
DEBUG - 2016-11-12 00:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:51:18 --> Input Class Initialized
INFO - 2016-11-12 00:51:18 --> Language Class Initialized
INFO - 2016-11-12 00:51:18 --> Loader Class Initialized
INFO - 2016-11-12 00:51:18 --> Helper loaded: url_helper
INFO - 2016-11-12 00:51:18 --> Helper loaded: form_helper
INFO - 2016-11-12 00:51:18 --> Database Driver Class Initialized
INFO - 2016-11-12 00:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:51:18 --> Controller Class Initialized
INFO - 2016-11-12 00:51:18 --> Model Class Initialized
INFO - 2016-11-12 00:51:18 --> Model Class Initialized
INFO - 2016-11-12 00:51:18 --> Model Class Initialized
INFO - 2016-11-12 00:51:18 --> Model Class Initialized
INFO - 2016-11-12 00:51:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:51:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:51:19 --> Final output sent to browser
DEBUG - 2016-11-12 00:51:19 --> Total execution time: 0.3635
INFO - 2016-11-12 00:51:34 --> Config Class Initialized
INFO - 2016-11-12 00:51:34 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:51:34 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:51:34 --> Utf8 Class Initialized
INFO - 2016-11-12 00:51:34 --> URI Class Initialized
DEBUG - 2016-11-12 00:51:34 --> No URI present. Default controller set.
INFO - 2016-11-12 00:51:34 --> Router Class Initialized
INFO - 2016-11-12 00:51:34 --> Output Class Initialized
INFO - 2016-11-12 00:51:34 --> Security Class Initialized
DEBUG - 2016-11-12 00:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:51:34 --> Input Class Initialized
INFO - 2016-11-12 00:51:34 --> Language Class Initialized
INFO - 2016-11-12 00:51:34 --> Loader Class Initialized
INFO - 2016-11-12 00:51:34 --> Helper loaded: url_helper
INFO - 2016-11-12 00:51:34 --> Helper loaded: form_helper
INFO - 2016-11-12 00:51:34 --> Database Driver Class Initialized
INFO - 2016-11-12 00:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:51:34 --> Controller Class Initialized
INFO - 2016-11-12 00:51:34 --> Model Class Initialized
INFO - 2016-11-12 00:51:34 --> Model Class Initialized
INFO - 2016-11-12 00:51:34 --> Model Class Initialized
INFO - 2016-11-12 00:51:34 --> Model Class Initialized
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:51:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:51:34 --> Final output sent to browser
DEBUG - 2016-11-12 00:51:34 --> Total execution time: 0.3822
INFO - 2016-11-12 00:54:29 --> Config Class Initialized
INFO - 2016-11-12 00:54:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:54:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:54:29 --> Utf8 Class Initialized
INFO - 2016-11-12 00:54:29 --> URI Class Initialized
DEBUG - 2016-11-12 00:54:29 --> No URI present. Default controller set.
INFO - 2016-11-12 00:54:29 --> Router Class Initialized
INFO - 2016-11-12 00:54:29 --> Output Class Initialized
INFO - 2016-11-12 00:54:29 --> Security Class Initialized
DEBUG - 2016-11-12 00:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:54:29 --> Input Class Initialized
INFO - 2016-11-12 00:54:29 --> Language Class Initialized
INFO - 2016-11-12 00:54:29 --> Loader Class Initialized
INFO - 2016-11-12 00:54:29 --> Helper loaded: url_helper
INFO - 2016-11-12 00:54:29 --> Helper loaded: form_helper
INFO - 2016-11-12 00:54:29 --> Database Driver Class Initialized
INFO - 2016-11-12 00:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:54:29 --> Controller Class Initialized
INFO - 2016-11-12 00:54:29 --> Model Class Initialized
INFO - 2016-11-12 00:54:29 --> Model Class Initialized
INFO - 2016-11-12 00:54:29 --> Model Class Initialized
INFO - 2016-11-12 00:54:29 --> Model Class Initialized
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:54:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:54:29 --> Final output sent to browser
DEBUG - 2016-11-12 00:54:29 --> Total execution time: 0.3571
INFO - 2016-11-12 00:55:26 --> Config Class Initialized
INFO - 2016-11-12 00:55:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:55:26 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:55:26 --> Utf8 Class Initialized
INFO - 2016-11-12 00:55:26 --> URI Class Initialized
DEBUG - 2016-11-12 00:55:26 --> No URI present. Default controller set.
INFO - 2016-11-12 00:55:26 --> Router Class Initialized
INFO - 2016-11-12 00:55:26 --> Output Class Initialized
INFO - 2016-11-12 00:55:26 --> Security Class Initialized
DEBUG - 2016-11-12 00:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:55:26 --> Input Class Initialized
INFO - 2016-11-12 00:55:26 --> Language Class Initialized
INFO - 2016-11-12 00:55:26 --> Loader Class Initialized
INFO - 2016-11-12 00:55:26 --> Helper loaded: url_helper
INFO - 2016-11-12 00:55:26 --> Helper loaded: form_helper
INFO - 2016-11-12 00:55:26 --> Database Driver Class Initialized
INFO - 2016-11-12 00:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:55:26 --> Controller Class Initialized
INFO - 2016-11-12 00:55:26 --> Model Class Initialized
INFO - 2016-11-12 00:55:26 --> Model Class Initialized
INFO - 2016-11-12 00:55:26 --> Model Class Initialized
INFO - 2016-11-12 00:55:26 --> Model Class Initialized
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:55:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:55:26 --> Final output sent to browser
DEBUG - 2016-11-12 00:55:26 --> Total execution time: 0.3254
INFO - 2016-11-12 00:55:50 --> Config Class Initialized
INFO - 2016-11-12 00:55:50 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:55:50 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:55:50 --> Utf8 Class Initialized
INFO - 2016-11-12 00:55:50 --> URI Class Initialized
DEBUG - 2016-11-12 00:55:50 --> No URI present. Default controller set.
INFO - 2016-11-12 00:55:50 --> Router Class Initialized
INFO - 2016-11-12 00:55:50 --> Output Class Initialized
INFO - 2016-11-12 00:55:50 --> Security Class Initialized
DEBUG - 2016-11-12 00:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:55:50 --> Input Class Initialized
INFO - 2016-11-12 00:55:50 --> Language Class Initialized
INFO - 2016-11-12 00:55:50 --> Loader Class Initialized
INFO - 2016-11-12 00:55:50 --> Helper loaded: url_helper
INFO - 2016-11-12 00:55:50 --> Helper loaded: form_helper
INFO - 2016-11-12 00:55:50 --> Database Driver Class Initialized
INFO - 2016-11-12 00:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:55:50 --> Controller Class Initialized
INFO - 2016-11-12 00:55:50 --> Model Class Initialized
INFO - 2016-11-12 00:55:50 --> Model Class Initialized
INFO - 2016-11-12 00:55:50 --> Model Class Initialized
INFO - 2016-11-12 00:55:50 --> Model Class Initialized
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:55:50 --> Final output sent to browser
DEBUG - 2016-11-12 00:55:50 --> Total execution time: 0.3255
INFO - 2016-11-12 00:56:05 --> Config Class Initialized
INFO - 2016-11-12 00:56:05 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:56:05 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:56:05 --> Utf8 Class Initialized
INFO - 2016-11-12 00:56:05 --> URI Class Initialized
DEBUG - 2016-11-12 00:56:05 --> No URI present. Default controller set.
INFO - 2016-11-12 00:56:05 --> Router Class Initialized
INFO - 2016-11-12 00:56:05 --> Output Class Initialized
INFO - 2016-11-12 00:56:05 --> Security Class Initialized
DEBUG - 2016-11-12 00:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:56:05 --> Input Class Initialized
INFO - 2016-11-12 00:56:05 --> Language Class Initialized
INFO - 2016-11-12 00:56:05 --> Loader Class Initialized
INFO - 2016-11-12 00:56:05 --> Helper loaded: url_helper
INFO - 2016-11-12 00:56:05 --> Helper loaded: form_helper
INFO - 2016-11-12 00:56:05 --> Database Driver Class Initialized
INFO - 2016-11-12 00:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:56:05 --> Controller Class Initialized
INFO - 2016-11-12 00:56:05 --> Model Class Initialized
INFO - 2016-11-12 00:56:05 --> Model Class Initialized
INFO - 2016-11-12 00:56:05 --> Model Class Initialized
INFO - 2016-11-12 00:56:05 --> Model Class Initialized
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:56:05 --> Final output sent to browser
DEBUG - 2016-11-12 00:56:05 --> Total execution time: 0.3292
INFO - 2016-11-12 00:57:22 --> Config Class Initialized
INFO - 2016-11-12 00:57:22 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:57:22 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:57:22 --> Utf8 Class Initialized
INFO - 2016-11-12 00:57:22 --> URI Class Initialized
DEBUG - 2016-11-12 00:57:22 --> No URI present. Default controller set.
INFO - 2016-11-12 00:57:22 --> Router Class Initialized
INFO - 2016-11-12 00:57:22 --> Output Class Initialized
INFO - 2016-11-12 00:57:22 --> Security Class Initialized
DEBUG - 2016-11-12 00:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:57:22 --> Input Class Initialized
INFO - 2016-11-12 00:57:22 --> Language Class Initialized
INFO - 2016-11-12 00:57:22 --> Loader Class Initialized
INFO - 2016-11-12 00:57:22 --> Helper loaded: url_helper
INFO - 2016-11-12 00:57:22 --> Helper loaded: form_helper
INFO - 2016-11-12 00:57:22 --> Database Driver Class Initialized
INFO - 2016-11-12 00:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:57:22 --> Controller Class Initialized
INFO - 2016-11-12 00:57:22 --> Model Class Initialized
INFO - 2016-11-12 00:57:22 --> Model Class Initialized
INFO - 2016-11-12 00:57:22 --> Model Class Initialized
INFO - 2016-11-12 00:57:22 --> Model Class Initialized
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:57:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:57:22 --> Final output sent to browser
DEBUG - 2016-11-12 00:57:22 --> Total execution time: 0.3508
INFO - 2016-11-12 00:57:37 --> Config Class Initialized
INFO - 2016-11-12 00:57:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:57:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:57:37 --> Utf8 Class Initialized
INFO - 2016-11-12 00:57:37 --> URI Class Initialized
DEBUG - 2016-11-12 00:57:37 --> No URI present. Default controller set.
INFO - 2016-11-12 00:57:37 --> Router Class Initialized
INFO - 2016-11-12 00:57:37 --> Output Class Initialized
INFO - 2016-11-12 00:57:37 --> Security Class Initialized
DEBUG - 2016-11-12 00:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:57:37 --> Input Class Initialized
INFO - 2016-11-12 00:57:37 --> Language Class Initialized
INFO - 2016-11-12 00:57:37 --> Loader Class Initialized
INFO - 2016-11-12 00:57:37 --> Helper loaded: url_helper
INFO - 2016-11-12 00:57:37 --> Helper loaded: form_helper
INFO - 2016-11-12 00:57:37 --> Database Driver Class Initialized
INFO - 2016-11-12 00:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:57:37 --> Controller Class Initialized
INFO - 2016-11-12 00:57:37 --> Model Class Initialized
INFO - 2016-11-12 00:57:37 --> Model Class Initialized
INFO - 2016-11-12 00:57:37 --> Model Class Initialized
INFO - 2016-11-12 00:57:37 --> Model Class Initialized
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:57:37 --> Final output sent to browser
DEBUG - 2016-11-12 00:57:37 --> Total execution time: 0.3354
INFO - 2016-11-12 00:58:10 --> Config Class Initialized
INFO - 2016-11-12 00:58:10 --> Hooks Class Initialized
DEBUG - 2016-11-12 00:58:10 --> UTF-8 Support Enabled
INFO - 2016-11-12 00:58:10 --> Utf8 Class Initialized
INFO - 2016-11-12 00:58:10 --> URI Class Initialized
DEBUG - 2016-11-12 00:58:10 --> No URI present. Default controller set.
INFO - 2016-11-12 00:58:10 --> Router Class Initialized
INFO - 2016-11-12 00:58:10 --> Output Class Initialized
INFO - 2016-11-12 00:58:10 --> Security Class Initialized
DEBUG - 2016-11-12 00:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 00:58:10 --> Input Class Initialized
INFO - 2016-11-12 00:58:10 --> Language Class Initialized
INFO - 2016-11-12 00:58:10 --> Loader Class Initialized
INFO - 2016-11-12 00:58:10 --> Helper loaded: url_helper
INFO - 2016-11-12 00:58:10 --> Helper loaded: form_helper
INFO - 2016-11-12 00:58:10 --> Database Driver Class Initialized
INFO - 2016-11-12 00:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 00:58:10 --> Controller Class Initialized
INFO - 2016-11-12 00:58:10 --> Model Class Initialized
INFO - 2016-11-12 00:58:11 --> Model Class Initialized
INFO - 2016-11-12 00:58:11 --> Model Class Initialized
INFO - 2016-11-12 00:58:11 --> Model Class Initialized
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 00:58:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 00:58:11 --> Final output sent to browser
DEBUG - 2016-11-12 00:58:11 --> Total execution time: 0.3373
INFO - 2016-11-12 01:01:14 --> Config Class Initialized
INFO - 2016-11-12 01:01:14 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:01:14 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:01:14 --> Utf8 Class Initialized
INFO - 2016-11-12 01:01:14 --> URI Class Initialized
DEBUG - 2016-11-12 01:01:14 --> No URI present. Default controller set.
INFO - 2016-11-12 01:01:14 --> Router Class Initialized
INFO - 2016-11-12 01:01:14 --> Output Class Initialized
INFO - 2016-11-12 01:01:14 --> Security Class Initialized
DEBUG - 2016-11-12 01:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:01:14 --> Input Class Initialized
INFO - 2016-11-12 01:01:14 --> Language Class Initialized
INFO - 2016-11-12 01:01:14 --> Loader Class Initialized
INFO - 2016-11-12 01:01:14 --> Helper loaded: url_helper
INFO - 2016-11-12 01:01:14 --> Helper loaded: form_helper
INFO - 2016-11-12 01:01:14 --> Database Driver Class Initialized
INFO - 2016-11-12 01:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:01:14 --> Controller Class Initialized
INFO - 2016-11-12 01:01:14 --> Model Class Initialized
INFO - 2016-11-12 01:01:14 --> Model Class Initialized
INFO - 2016-11-12 01:01:14 --> Model Class Initialized
INFO - 2016-11-12 01:01:14 --> Model Class Initialized
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:01:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:01:14 --> Final output sent to browser
DEBUG - 2016-11-12 01:01:14 --> Total execution time: 0.3596
INFO - 2016-11-12 01:01:25 --> Config Class Initialized
INFO - 2016-11-12 01:01:25 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:01:25 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:01:25 --> Utf8 Class Initialized
INFO - 2016-11-12 01:01:25 --> URI Class Initialized
DEBUG - 2016-11-12 01:01:25 --> No URI present. Default controller set.
INFO - 2016-11-12 01:01:25 --> Router Class Initialized
INFO - 2016-11-12 01:01:25 --> Output Class Initialized
INFO - 2016-11-12 01:01:25 --> Security Class Initialized
DEBUG - 2016-11-12 01:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:01:25 --> Input Class Initialized
INFO - 2016-11-12 01:01:25 --> Language Class Initialized
INFO - 2016-11-12 01:01:25 --> Loader Class Initialized
INFO - 2016-11-12 01:01:25 --> Helper loaded: url_helper
INFO - 2016-11-12 01:01:25 --> Helper loaded: form_helper
INFO - 2016-11-12 01:01:25 --> Database Driver Class Initialized
INFO - 2016-11-12 01:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:01:25 --> Controller Class Initialized
INFO - 2016-11-12 01:01:25 --> Model Class Initialized
INFO - 2016-11-12 01:01:25 --> Model Class Initialized
INFO - 2016-11-12 01:01:25 --> Model Class Initialized
INFO - 2016-11-12 01:01:25 --> Model Class Initialized
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:01:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:01:25 --> Final output sent to browser
DEBUG - 2016-11-12 01:01:25 --> Total execution time: 0.3599
INFO - 2016-11-12 01:01:47 --> Config Class Initialized
INFO - 2016-11-12 01:01:47 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:01:47 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:01:47 --> Utf8 Class Initialized
INFO - 2016-11-12 01:01:47 --> URI Class Initialized
DEBUG - 2016-11-12 01:01:47 --> No URI present. Default controller set.
INFO - 2016-11-12 01:01:47 --> Router Class Initialized
INFO - 2016-11-12 01:01:47 --> Output Class Initialized
INFO - 2016-11-12 01:01:47 --> Security Class Initialized
DEBUG - 2016-11-12 01:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:01:47 --> Input Class Initialized
INFO - 2016-11-12 01:01:47 --> Language Class Initialized
INFO - 2016-11-12 01:01:47 --> Loader Class Initialized
INFO - 2016-11-12 01:01:47 --> Helper loaded: url_helper
INFO - 2016-11-12 01:01:47 --> Helper loaded: form_helper
INFO - 2016-11-12 01:01:47 --> Database Driver Class Initialized
INFO - 2016-11-12 01:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:01:47 --> Controller Class Initialized
INFO - 2016-11-12 01:01:47 --> Model Class Initialized
INFO - 2016-11-12 01:01:47 --> Model Class Initialized
INFO - 2016-11-12 01:01:47 --> Model Class Initialized
INFO - 2016-11-12 01:01:47 --> Model Class Initialized
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:01:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:01:47 --> Final output sent to browser
DEBUG - 2016-11-12 01:01:47 --> Total execution time: 0.3556
INFO - 2016-11-12 01:03:00 --> Config Class Initialized
INFO - 2016-11-12 01:03:00 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:03:00 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:03:00 --> Utf8 Class Initialized
INFO - 2016-11-12 01:03:00 --> URI Class Initialized
DEBUG - 2016-11-12 01:03:00 --> No URI present. Default controller set.
INFO - 2016-11-12 01:03:00 --> Router Class Initialized
INFO - 2016-11-12 01:03:00 --> Output Class Initialized
INFO - 2016-11-12 01:03:00 --> Security Class Initialized
DEBUG - 2016-11-12 01:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:03:00 --> Input Class Initialized
INFO - 2016-11-12 01:03:00 --> Language Class Initialized
INFO - 2016-11-12 01:03:00 --> Loader Class Initialized
INFO - 2016-11-12 01:03:00 --> Helper loaded: url_helper
INFO - 2016-11-12 01:03:00 --> Helper loaded: form_helper
INFO - 2016-11-12 01:03:00 --> Database Driver Class Initialized
INFO - 2016-11-12 01:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:03:00 --> Controller Class Initialized
INFO - 2016-11-12 01:03:00 --> Model Class Initialized
INFO - 2016-11-12 01:03:00 --> Model Class Initialized
INFO - 2016-11-12 01:03:00 --> Model Class Initialized
INFO - 2016-11-12 01:03:00 --> Model Class Initialized
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:03:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:03:00 --> Final output sent to browser
DEBUG - 2016-11-12 01:03:00 --> Total execution time: 0.3612
INFO - 2016-11-12 01:03:26 --> Config Class Initialized
INFO - 2016-11-12 01:03:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:03:26 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:03:26 --> Utf8 Class Initialized
INFO - 2016-11-12 01:03:26 --> URI Class Initialized
DEBUG - 2016-11-12 01:03:26 --> No URI present. Default controller set.
INFO - 2016-11-12 01:03:26 --> Router Class Initialized
INFO - 2016-11-12 01:03:26 --> Output Class Initialized
INFO - 2016-11-12 01:03:26 --> Security Class Initialized
DEBUG - 2016-11-12 01:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:03:26 --> Input Class Initialized
INFO - 2016-11-12 01:03:26 --> Language Class Initialized
INFO - 2016-11-12 01:03:26 --> Loader Class Initialized
INFO - 2016-11-12 01:03:26 --> Helper loaded: url_helper
INFO - 2016-11-12 01:03:26 --> Helper loaded: form_helper
INFO - 2016-11-12 01:03:26 --> Database Driver Class Initialized
INFO - 2016-11-12 01:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:03:26 --> Controller Class Initialized
INFO - 2016-11-12 01:03:26 --> Model Class Initialized
INFO - 2016-11-12 01:03:26 --> Model Class Initialized
INFO - 2016-11-12 01:03:26 --> Model Class Initialized
INFO - 2016-11-12 01:03:26 --> Model Class Initialized
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:03:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:03:26 --> Final output sent to browser
DEBUG - 2016-11-12 01:03:26 --> Total execution time: 0.3901
INFO - 2016-11-12 01:03:34 --> Config Class Initialized
INFO - 2016-11-12 01:03:34 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:03:34 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:03:34 --> Utf8 Class Initialized
INFO - 2016-11-12 01:03:34 --> URI Class Initialized
DEBUG - 2016-11-12 01:03:34 --> No URI present. Default controller set.
INFO - 2016-11-12 01:03:34 --> Router Class Initialized
INFO - 2016-11-12 01:03:34 --> Output Class Initialized
INFO - 2016-11-12 01:03:34 --> Security Class Initialized
DEBUG - 2016-11-12 01:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:03:34 --> Input Class Initialized
INFO - 2016-11-12 01:03:35 --> Language Class Initialized
INFO - 2016-11-12 01:03:35 --> Loader Class Initialized
INFO - 2016-11-12 01:03:35 --> Helper loaded: url_helper
INFO - 2016-11-12 01:03:35 --> Helper loaded: form_helper
INFO - 2016-11-12 01:03:35 --> Database Driver Class Initialized
INFO - 2016-11-12 01:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:03:35 --> Controller Class Initialized
INFO - 2016-11-12 01:03:35 --> Model Class Initialized
INFO - 2016-11-12 01:03:35 --> Model Class Initialized
INFO - 2016-11-12 01:03:35 --> Model Class Initialized
INFO - 2016-11-12 01:03:35 --> Model Class Initialized
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:03:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:03:35 --> Final output sent to browser
DEBUG - 2016-11-12 01:03:35 --> Total execution time: 0.3951
INFO - 2016-11-12 01:05:20 --> Config Class Initialized
INFO - 2016-11-12 01:05:20 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:05:20 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:05:20 --> Utf8 Class Initialized
INFO - 2016-11-12 01:05:21 --> URI Class Initialized
DEBUG - 2016-11-12 01:05:21 --> No URI present. Default controller set.
INFO - 2016-11-12 01:05:21 --> Router Class Initialized
INFO - 2016-11-12 01:05:21 --> Output Class Initialized
INFO - 2016-11-12 01:05:21 --> Security Class Initialized
DEBUG - 2016-11-12 01:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:05:21 --> Input Class Initialized
INFO - 2016-11-12 01:05:21 --> Language Class Initialized
INFO - 2016-11-12 01:05:21 --> Loader Class Initialized
INFO - 2016-11-12 01:05:21 --> Helper loaded: url_helper
INFO - 2016-11-12 01:05:21 --> Helper loaded: form_helper
INFO - 2016-11-12 01:05:21 --> Database Driver Class Initialized
INFO - 2016-11-12 01:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:05:21 --> Controller Class Initialized
INFO - 2016-11-12 01:05:21 --> Model Class Initialized
INFO - 2016-11-12 01:05:21 --> Model Class Initialized
INFO - 2016-11-12 01:05:21 --> Model Class Initialized
INFO - 2016-11-12 01:05:21 --> Model Class Initialized
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:05:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:05:21 --> Final output sent to browser
DEBUG - 2016-11-12 01:05:21 --> Total execution time: 0.3580
INFO - 2016-11-12 01:05:54 --> Config Class Initialized
INFO - 2016-11-12 01:05:54 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:05:54 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:05:54 --> Utf8 Class Initialized
INFO - 2016-11-12 01:05:54 --> URI Class Initialized
DEBUG - 2016-11-12 01:05:54 --> No URI present. Default controller set.
INFO - 2016-11-12 01:05:54 --> Router Class Initialized
INFO - 2016-11-12 01:05:54 --> Output Class Initialized
INFO - 2016-11-12 01:05:54 --> Security Class Initialized
DEBUG - 2016-11-12 01:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:05:54 --> Input Class Initialized
INFO - 2016-11-12 01:05:54 --> Language Class Initialized
INFO - 2016-11-12 01:05:54 --> Loader Class Initialized
INFO - 2016-11-12 01:05:54 --> Helper loaded: url_helper
INFO - 2016-11-12 01:05:54 --> Helper loaded: form_helper
INFO - 2016-11-12 01:05:54 --> Database Driver Class Initialized
INFO - 2016-11-12 01:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:05:54 --> Controller Class Initialized
INFO - 2016-11-12 01:05:54 --> Model Class Initialized
INFO - 2016-11-12 01:05:54 --> Model Class Initialized
INFO - 2016-11-12 01:05:54 --> Model Class Initialized
INFO - 2016-11-12 01:05:54 --> Model Class Initialized
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:05:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:05:54 --> Final output sent to browser
DEBUG - 2016-11-12 01:05:54 --> Total execution time: 0.3596
INFO - 2016-11-12 01:06:47 --> Config Class Initialized
INFO - 2016-11-12 01:06:47 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:06:47 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:06:47 --> Utf8 Class Initialized
INFO - 2016-11-12 01:06:47 --> URI Class Initialized
DEBUG - 2016-11-12 01:06:47 --> No URI present. Default controller set.
INFO - 2016-11-12 01:06:47 --> Router Class Initialized
INFO - 2016-11-12 01:06:47 --> Output Class Initialized
INFO - 2016-11-12 01:06:47 --> Security Class Initialized
DEBUG - 2016-11-12 01:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:06:47 --> Input Class Initialized
INFO - 2016-11-12 01:06:47 --> Language Class Initialized
INFO - 2016-11-12 01:06:47 --> Loader Class Initialized
INFO - 2016-11-12 01:06:47 --> Helper loaded: url_helper
INFO - 2016-11-12 01:06:47 --> Helper loaded: form_helper
INFO - 2016-11-12 01:06:47 --> Database Driver Class Initialized
INFO - 2016-11-12 01:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:06:47 --> Controller Class Initialized
INFO - 2016-11-12 01:06:47 --> Model Class Initialized
INFO - 2016-11-12 01:06:47 --> Model Class Initialized
INFO - 2016-11-12 01:06:47 --> Model Class Initialized
INFO - 2016-11-12 01:06:47 --> Model Class Initialized
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:06:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:06:47 --> Final output sent to browser
DEBUG - 2016-11-12 01:06:47 --> Total execution time: 0.3796
INFO - 2016-11-12 01:07:46 --> Config Class Initialized
INFO - 2016-11-12 01:07:46 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:07:46 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:07:46 --> Utf8 Class Initialized
INFO - 2016-11-12 01:07:46 --> URI Class Initialized
DEBUG - 2016-11-12 01:07:46 --> No URI present. Default controller set.
INFO - 2016-11-12 01:07:46 --> Router Class Initialized
INFO - 2016-11-12 01:07:47 --> Output Class Initialized
INFO - 2016-11-12 01:07:47 --> Security Class Initialized
DEBUG - 2016-11-12 01:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:07:47 --> Input Class Initialized
INFO - 2016-11-12 01:07:47 --> Language Class Initialized
INFO - 2016-11-12 01:07:47 --> Loader Class Initialized
INFO - 2016-11-12 01:07:47 --> Helper loaded: url_helper
INFO - 2016-11-12 01:07:47 --> Helper loaded: form_helper
INFO - 2016-11-12 01:07:47 --> Database Driver Class Initialized
INFO - 2016-11-12 01:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:07:47 --> Controller Class Initialized
INFO - 2016-11-12 01:07:47 --> Model Class Initialized
INFO - 2016-11-12 01:07:47 --> Model Class Initialized
INFO - 2016-11-12 01:07:47 --> Model Class Initialized
INFO - 2016-11-12 01:07:47 --> Model Class Initialized
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:07:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:07:47 --> Final output sent to browser
DEBUG - 2016-11-12 01:07:47 --> Total execution time: 0.3720
INFO - 2016-11-12 01:11:36 --> Config Class Initialized
INFO - 2016-11-12 01:11:36 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:11:36 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:11:36 --> Utf8 Class Initialized
INFO - 2016-11-12 01:11:36 --> URI Class Initialized
DEBUG - 2016-11-12 01:11:36 --> No URI present. Default controller set.
INFO - 2016-11-12 01:11:36 --> Router Class Initialized
INFO - 2016-11-12 01:11:36 --> Output Class Initialized
INFO - 2016-11-12 01:11:36 --> Security Class Initialized
DEBUG - 2016-11-12 01:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:11:36 --> Input Class Initialized
INFO - 2016-11-12 01:11:36 --> Language Class Initialized
INFO - 2016-11-12 01:11:36 --> Loader Class Initialized
INFO - 2016-11-12 01:11:36 --> Helper loaded: url_helper
INFO - 2016-11-12 01:11:36 --> Helper loaded: form_helper
INFO - 2016-11-12 01:11:36 --> Database Driver Class Initialized
INFO - 2016-11-12 01:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:11:36 --> Controller Class Initialized
INFO - 2016-11-12 01:11:36 --> Model Class Initialized
INFO - 2016-11-12 01:11:36 --> Model Class Initialized
INFO - 2016-11-12 01:11:36 --> Model Class Initialized
INFO - 2016-11-12 01:11:36 --> Model Class Initialized
INFO - 2016-11-12 01:11:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:11:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:11:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:11:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:11:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:11:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:11:36 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 1
INFO - 2016-11-12 01:11:56 --> Config Class Initialized
INFO - 2016-11-12 01:11:56 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:11:56 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:11:56 --> Utf8 Class Initialized
INFO - 2016-11-12 01:11:56 --> URI Class Initialized
DEBUG - 2016-11-12 01:11:56 --> No URI present. Default controller set.
INFO - 2016-11-12 01:11:56 --> Router Class Initialized
INFO - 2016-11-12 01:11:56 --> Output Class Initialized
INFO - 2016-11-12 01:11:56 --> Security Class Initialized
DEBUG - 2016-11-12 01:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:11:56 --> Input Class Initialized
INFO - 2016-11-12 01:11:56 --> Language Class Initialized
INFO - 2016-11-12 01:11:56 --> Loader Class Initialized
INFO - 2016-11-12 01:11:56 --> Helper loaded: url_helper
INFO - 2016-11-12 01:11:56 --> Helper loaded: form_helper
INFO - 2016-11-12 01:11:56 --> Database Driver Class Initialized
INFO - 2016-11-12 01:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:11:56 --> Controller Class Initialized
INFO - 2016-11-12 01:11:56 --> Model Class Initialized
INFO - 2016-11-12 01:11:56 --> Model Class Initialized
INFO - 2016-11-12 01:11:56 --> Model Class Initialized
INFO - 2016-11-12 01:11:56 --> Model Class Initialized
INFO - 2016-11-12 01:11:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:11:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:11:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:11:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:11:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:11:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:11:56 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 1
INFO - 2016-11-12 01:12:29 --> Config Class Initialized
INFO - 2016-11-12 01:12:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:12:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:12:29 --> Utf8 Class Initialized
INFO - 2016-11-12 01:12:29 --> URI Class Initialized
DEBUG - 2016-11-12 01:12:29 --> No URI present. Default controller set.
INFO - 2016-11-12 01:12:29 --> Router Class Initialized
INFO - 2016-11-12 01:12:29 --> Output Class Initialized
INFO - 2016-11-12 01:12:29 --> Security Class Initialized
DEBUG - 2016-11-12 01:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:12:29 --> Input Class Initialized
INFO - 2016-11-12 01:12:29 --> Language Class Initialized
INFO - 2016-11-12 01:12:29 --> Loader Class Initialized
INFO - 2016-11-12 01:12:29 --> Helper loaded: url_helper
INFO - 2016-11-12 01:12:29 --> Helper loaded: form_helper
INFO - 2016-11-12 01:12:29 --> Database Driver Class Initialized
INFO - 2016-11-12 01:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:12:29 --> Controller Class Initialized
INFO - 2016-11-12 01:12:29 --> Model Class Initialized
INFO - 2016-11-12 01:12:29 --> Model Class Initialized
INFO - 2016-11-12 01:12:29 --> Model Class Initialized
INFO - 2016-11-12 01:12:29 --> Model Class Initialized
INFO - 2016-11-12 01:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:12:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:12:56 --> Config Class Initialized
INFO - 2016-11-12 01:12:56 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:12:56 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:12:56 --> Utf8 Class Initialized
INFO - 2016-11-12 01:12:56 --> URI Class Initialized
DEBUG - 2016-11-12 01:12:56 --> No URI present. Default controller set.
INFO - 2016-11-12 01:12:56 --> Router Class Initialized
INFO - 2016-11-12 01:12:56 --> Output Class Initialized
INFO - 2016-11-12 01:12:56 --> Security Class Initialized
DEBUG - 2016-11-12 01:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:12:56 --> Input Class Initialized
INFO - 2016-11-12 01:12:56 --> Language Class Initialized
INFO - 2016-11-12 01:12:56 --> Loader Class Initialized
INFO - 2016-11-12 01:12:56 --> Helper loaded: url_helper
INFO - 2016-11-12 01:12:56 --> Helper loaded: form_helper
INFO - 2016-11-12 01:12:56 --> Database Driver Class Initialized
INFO - 2016-11-12 01:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:12:56 --> Controller Class Initialized
INFO - 2016-11-12 01:12:56 --> Model Class Initialized
INFO - 2016-11-12 01:12:56 --> Model Class Initialized
INFO - 2016-11-12 01:12:56 --> Model Class Initialized
INFO - 2016-11-12 01:12:56 --> Model Class Initialized
INFO - 2016-11-12 01:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:12:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:12:56 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 1
INFO - 2016-11-12 01:13:08 --> Config Class Initialized
INFO - 2016-11-12 01:13:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:13:08 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:13:08 --> Utf8 Class Initialized
INFO - 2016-11-12 01:13:08 --> URI Class Initialized
DEBUG - 2016-11-12 01:13:08 --> No URI present. Default controller set.
INFO - 2016-11-12 01:13:08 --> Router Class Initialized
INFO - 2016-11-12 01:13:08 --> Output Class Initialized
INFO - 2016-11-12 01:13:08 --> Security Class Initialized
DEBUG - 2016-11-12 01:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:13:08 --> Input Class Initialized
INFO - 2016-11-12 01:13:08 --> Language Class Initialized
INFO - 2016-11-12 01:13:09 --> Loader Class Initialized
INFO - 2016-11-12 01:13:09 --> Helper loaded: url_helper
INFO - 2016-11-12 01:13:09 --> Helper loaded: form_helper
INFO - 2016-11-12 01:13:09 --> Database Driver Class Initialized
INFO - 2016-11-12 01:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:13:09 --> Controller Class Initialized
INFO - 2016-11-12 01:13:09 --> Model Class Initialized
INFO - 2016-11-12 01:13:09 --> Model Class Initialized
INFO - 2016-11-12 01:13:09 --> Model Class Initialized
INFO - 2016-11-12 01:13:09 --> Model Class Initialized
INFO - 2016-11-12 01:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:13:09 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 1
INFO - 2016-11-12 01:13:49 --> Config Class Initialized
INFO - 2016-11-12 01:13:49 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:13:49 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:13:49 --> Utf8 Class Initialized
INFO - 2016-11-12 01:13:49 --> URI Class Initialized
DEBUG - 2016-11-12 01:13:49 --> No URI present. Default controller set.
INFO - 2016-11-12 01:13:49 --> Router Class Initialized
INFO - 2016-11-12 01:13:49 --> Output Class Initialized
INFO - 2016-11-12 01:13:49 --> Security Class Initialized
DEBUG - 2016-11-12 01:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:13:49 --> Input Class Initialized
INFO - 2016-11-12 01:13:49 --> Language Class Initialized
INFO - 2016-11-12 01:13:49 --> Loader Class Initialized
INFO - 2016-11-12 01:13:49 --> Helper loaded: url_helper
INFO - 2016-11-12 01:13:49 --> Helper loaded: form_helper
INFO - 2016-11-12 01:13:49 --> Database Driver Class Initialized
INFO - 2016-11-12 01:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:13:49 --> Controller Class Initialized
INFO - 2016-11-12 01:13:49 --> Model Class Initialized
INFO - 2016-11-12 01:13:49 --> Model Class Initialized
INFO - 2016-11-12 01:13:50 --> Model Class Initialized
INFO - 2016-11-12 01:13:50 --> Model Class Initialized
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:13:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:13:50 --> Final output sent to browser
DEBUG - 2016-11-12 01:13:50 --> Total execution time: 0.3867
INFO - 2016-11-12 01:15:19 --> Config Class Initialized
INFO - 2016-11-12 01:15:19 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:15:19 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:15:19 --> Utf8 Class Initialized
INFO - 2016-11-12 01:15:19 --> URI Class Initialized
DEBUG - 2016-11-12 01:15:19 --> No URI present. Default controller set.
INFO - 2016-11-12 01:15:19 --> Router Class Initialized
INFO - 2016-11-12 01:15:19 --> Output Class Initialized
INFO - 2016-11-12 01:15:19 --> Security Class Initialized
DEBUG - 2016-11-12 01:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:15:19 --> Input Class Initialized
INFO - 2016-11-12 01:15:19 --> Language Class Initialized
INFO - 2016-11-12 01:15:19 --> Loader Class Initialized
INFO - 2016-11-12 01:15:19 --> Helper loaded: url_helper
INFO - 2016-11-12 01:15:19 --> Helper loaded: form_helper
INFO - 2016-11-12 01:15:19 --> Database Driver Class Initialized
INFO - 2016-11-12 01:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:15:19 --> Controller Class Initialized
INFO - 2016-11-12 01:15:19 --> Model Class Initialized
INFO - 2016-11-12 01:15:19 --> Model Class Initialized
INFO - 2016-11-12 01:15:19 --> Model Class Initialized
INFO - 2016-11-12 01:15:19 --> Model Class Initialized
INFO - 2016-11-12 01:15:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:15:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:15:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:15:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:15:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:15:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:15:19 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 14
INFO - 2016-11-12 01:15:56 --> Config Class Initialized
INFO - 2016-11-12 01:15:56 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:15:56 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:15:56 --> Utf8 Class Initialized
INFO - 2016-11-12 01:15:56 --> URI Class Initialized
DEBUG - 2016-11-12 01:15:56 --> No URI present. Default controller set.
INFO - 2016-11-12 01:15:56 --> Router Class Initialized
INFO - 2016-11-12 01:15:56 --> Output Class Initialized
INFO - 2016-11-12 01:15:56 --> Security Class Initialized
DEBUG - 2016-11-12 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:15:56 --> Input Class Initialized
INFO - 2016-11-12 01:15:56 --> Language Class Initialized
INFO - 2016-11-12 01:15:56 --> Loader Class Initialized
INFO - 2016-11-12 01:15:56 --> Helper loaded: url_helper
INFO - 2016-11-12 01:15:56 --> Helper loaded: form_helper
INFO - 2016-11-12 01:15:56 --> Database Driver Class Initialized
INFO - 2016-11-12 01:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:15:56 --> Controller Class Initialized
INFO - 2016-11-12 01:15:56 --> Model Class Initialized
INFO - 2016-11-12 01:15:56 --> Model Class Initialized
INFO - 2016-11-12 01:15:56 --> Model Class Initialized
INFO - 2016-11-12 01:15:56 --> Model Class Initialized
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:15:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:15:56 --> Final output sent to browser
DEBUG - 2016-11-12 01:15:56 --> Total execution time: 0.3795
INFO - 2016-11-12 01:19:58 --> Config Class Initialized
INFO - 2016-11-12 01:19:58 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:19:58 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:19:58 --> Utf8 Class Initialized
INFO - 2016-11-12 01:19:58 --> URI Class Initialized
DEBUG - 2016-11-12 01:19:58 --> No URI present. Default controller set.
INFO - 2016-11-12 01:19:58 --> Router Class Initialized
INFO - 2016-11-12 01:19:58 --> Output Class Initialized
INFO - 2016-11-12 01:19:58 --> Security Class Initialized
DEBUG - 2016-11-12 01:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:19:58 --> Input Class Initialized
INFO - 2016-11-12 01:19:58 --> Language Class Initialized
INFO - 2016-11-12 01:19:58 --> Loader Class Initialized
INFO - 2016-11-12 01:19:58 --> Helper loaded: url_helper
INFO - 2016-11-12 01:19:58 --> Helper loaded: form_helper
INFO - 2016-11-12 01:19:58 --> Database Driver Class Initialized
INFO - 2016-11-12 01:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:19:58 --> Controller Class Initialized
INFO - 2016-11-12 01:19:58 --> Model Class Initialized
INFO - 2016-11-12 01:19:58 --> Model Class Initialized
INFO - 2016-11-12 01:19:58 --> Model Class Initialized
INFO - 2016-11-12 01:19:58 --> Model Class Initialized
INFO - 2016-11-12 01:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:19:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:19:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:19:59 --> Final output sent to browser
DEBUG - 2016-11-12 01:19:59 --> Total execution time: 0.4096
INFO - 2016-11-12 01:20:29 --> Config Class Initialized
INFO - 2016-11-12 01:20:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:20:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:20:29 --> Utf8 Class Initialized
INFO - 2016-11-12 01:20:29 --> URI Class Initialized
INFO - 2016-11-12 01:20:29 --> Router Class Initialized
INFO - 2016-11-12 01:20:29 --> Output Class Initialized
INFO - 2016-11-12 01:20:29 --> Security Class Initialized
DEBUG - 2016-11-12 01:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:20:29 --> Input Class Initialized
INFO - 2016-11-12 01:20:29 --> Language Class Initialized
INFO - 2016-11-12 01:20:29 --> Loader Class Initialized
INFO - 2016-11-12 01:20:29 --> Helper loaded: url_helper
INFO - 2016-11-12 01:20:29 --> Helper loaded: form_helper
INFO - 2016-11-12 01:20:29 --> Database Driver Class Initialized
INFO - 2016-11-12 01:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:20:29 --> Controller Class Initialized
INFO - 2016-11-12 01:20:29 --> Model Class Initialized
INFO - 2016-11-12 01:20:29 --> Model Class Initialized
INFO - 2016-11-12 01:20:29 --> Model Class Initialized
INFO - 2016-11-12 01:20:29 --> Model Class Initialized
DEBUG - 2016-11-12 01:20:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 01:20:29 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 01:20:30 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 01:20:30 --> Config Class Initialized
INFO - 2016-11-12 01:20:30 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:20:30 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:20:30 --> Utf8 Class Initialized
INFO - 2016-11-12 01:20:30 --> URI Class Initialized
DEBUG - 2016-11-12 01:20:30 --> No URI present. Default controller set.
INFO - 2016-11-12 01:20:30 --> Router Class Initialized
INFO - 2016-11-12 01:20:30 --> Output Class Initialized
INFO - 2016-11-12 01:20:30 --> Security Class Initialized
DEBUG - 2016-11-12 01:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:20:30 --> Input Class Initialized
INFO - 2016-11-12 01:20:30 --> Language Class Initialized
INFO - 2016-11-12 01:20:30 --> Loader Class Initialized
INFO - 2016-11-12 01:20:30 --> Helper loaded: url_helper
INFO - 2016-11-12 01:20:30 --> Helper loaded: form_helper
INFO - 2016-11-12 01:20:30 --> Database Driver Class Initialized
INFO - 2016-11-12 01:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:20:30 --> Controller Class Initialized
INFO - 2016-11-12 01:20:30 --> Model Class Initialized
INFO - 2016-11-12 01:20:30 --> Model Class Initialized
INFO - 2016-11-12 01:20:30 --> Model Class Initialized
INFO - 2016-11-12 01:20:30 --> Model Class Initialized
INFO - 2016-11-12 01:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 01:20:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:20:30 --> Final output sent to browser
DEBUG - 2016-11-12 01:20:30 --> Total execution time: 0.2680
INFO - 2016-11-12 01:20:37 --> Config Class Initialized
INFO - 2016-11-12 01:20:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:20:38 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:20:38 --> Utf8 Class Initialized
INFO - 2016-11-12 01:20:38 --> URI Class Initialized
INFO - 2016-11-12 01:20:38 --> Router Class Initialized
INFO - 2016-11-12 01:20:38 --> Output Class Initialized
INFO - 2016-11-12 01:20:38 --> Security Class Initialized
DEBUG - 2016-11-12 01:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:20:38 --> Input Class Initialized
INFO - 2016-11-12 01:20:38 --> Language Class Initialized
INFO - 2016-11-12 01:20:38 --> Loader Class Initialized
INFO - 2016-11-12 01:20:38 --> Helper loaded: url_helper
INFO - 2016-11-12 01:20:38 --> Helper loaded: form_helper
INFO - 2016-11-12 01:20:38 --> Database Driver Class Initialized
INFO - 2016-11-12 01:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:20:38 --> Controller Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
DEBUG - 2016-11-12 01:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Final output sent to browser
DEBUG - 2016-11-12 01:20:38 --> Total execution time: 0.2683
INFO - 2016-11-12 01:20:38 --> Config Class Initialized
INFO - 2016-11-12 01:20:38 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:20:38 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:20:38 --> Utf8 Class Initialized
INFO - 2016-11-12 01:20:38 --> URI Class Initialized
DEBUG - 2016-11-12 01:20:38 --> No URI present. Default controller set.
INFO - 2016-11-12 01:20:38 --> Router Class Initialized
INFO - 2016-11-12 01:20:38 --> Output Class Initialized
INFO - 2016-11-12 01:20:38 --> Security Class Initialized
DEBUG - 2016-11-12 01:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:20:38 --> Input Class Initialized
INFO - 2016-11-12 01:20:38 --> Language Class Initialized
INFO - 2016-11-12 01:20:38 --> Loader Class Initialized
INFO - 2016-11-12 01:20:38 --> Helper loaded: url_helper
INFO - 2016-11-12 01:20:38 --> Helper loaded: form_helper
INFO - 2016-11-12 01:20:38 --> Database Driver Class Initialized
INFO - 2016-11-12 01:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:20:38 --> Controller Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> Model Class Initialized
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:20:38 --> Final output sent to browser
DEBUG - 2016-11-12 01:20:38 --> Total execution time: 0.3763
INFO - 2016-11-12 01:20:46 --> Config Class Initialized
INFO - 2016-11-12 01:20:46 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:20:46 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:20:46 --> Utf8 Class Initialized
INFO - 2016-11-12 01:20:46 --> URI Class Initialized
DEBUG - 2016-11-12 01:20:46 --> No URI present. Default controller set.
INFO - 2016-11-12 01:20:46 --> Router Class Initialized
INFO - 2016-11-12 01:20:46 --> Output Class Initialized
INFO - 2016-11-12 01:20:46 --> Security Class Initialized
DEBUG - 2016-11-12 01:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:20:46 --> Input Class Initialized
INFO - 2016-11-12 01:20:46 --> Language Class Initialized
INFO - 2016-11-12 01:20:46 --> Loader Class Initialized
INFO - 2016-11-12 01:20:46 --> Helper loaded: url_helper
INFO - 2016-11-12 01:20:46 --> Helper loaded: form_helper
INFO - 2016-11-12 01:20:46 --> Database Driver Class Initialized
INFO - 2016-11-12 01:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:20:46 --> Controller Class Initialized
INFO - 2016-11-12 01:20:46 --> Model Class Initialized
INFO - 2016-11-12 01:20:46 --> Model Class Initialized
INFO - 2016-11-12 01:20:46 --> Model Class Initialized
INFO - 2016-11-12 01:20:46 --> Model Class Initialized
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:20:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:20:46 --> Final output sent to browser
DEBUG - 2016-11-12 01:20:46 --> Total execution time: 0.4647
INFO - 2016-11-12 01:21:02 --> Config Class Initialized
INFO - 2016-11-12 01:21:02 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:21:02 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:21:02 --> Utf8 Class Initialized
INFO - 2016-11-12 01:21:02 --> URI Class Initialized
DEBUG - 2016-11-12 01:21:02 --> No URI present. Default controller set.
INFO - 2016-11-12 01:21:02 --> Router Class Initialized
INFO - 2016-11-12 01:21:02 --> Output Class Initialized
INFO - 2016-11-12 01:21:02 --> Security Class Initialized
DEBUG - 2016-11-12 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:21:02 --> Input Class Initialized
INFO - 2016-11-12 01:21:02 --> Language Class Initialized
INFO - 2016-11-12 01:21:02 --> Loader Class Initialized
INFO - 2016-11-12 01:21:02 --> Helper loaded: url_helper
INFO - 2016-11-12 01:21:02 --> Helper loaded: form_helper
INFO - 2016-11-12 01:21:02 --> Database Driver Class Initialized
INFO - 2016-11-12 01:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:21:02 --> Controller Class Initialized
INFO - 2016-11-12 01:21:02 --> Model Class Initialized
INFO - 2016-11-12 01:21:02 --> Model Class Initialized
INFO - 2016-11-12 01:21:02 --> Model Class Initialized
INFO - 2016-11-12 01:21:02 --> Model Class Initialized
INFO - 2016-11-12 01:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:21:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:21:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:21:03 --> Final output sent to browser
DEBUG - 2016-11-12 01:21:03 --> Total execution time: 0.3870
INFO - 2016-11-12 01:21:48 --> Config Class Initialized
INFO - 2016-11-12 01:21:48 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:21:48 --> Utf8 Class Initialized
INFO - 2016-11-12 01:21:48 --> URI Class Initialized
DEBUG - 2016-11-12 01:21:48 --> No URI present. Default controller set.
INFO - 2016-11-12 01:21:48 --> Router Class Initialized
INFO - 2016-11-12 01:21:48 --> Output Class Initialized
INFO - 2016-11-12 01:21:48 --> Security Class Initialized
DEBUG - 2016-11-12 01:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:21:48 --> Input Class Initialized
INFO - 2016-11-12 01:21:48 --> Language Class Initialized
INFO - 2016-11-12 01:21:48 --> Loader Class Initialized
INFO - 2016-11-12 01:21:48 --> Helper loaded: url_helper
INFO - 2016-11-12 01:21:48 --> Helper loaded: form_helper
INFO - 2016-11-12 01:21:48 --> Database Driver Class Initialized
INFO - 2016-11-12 01:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:21:48 --> Controller Class Initialized
INFO - 2016-11-12 01:21:48 --> Model Class Initialized
INFO - 2016-11-12 01:21:48 --> Model Class Initialized
INFO - 2016-11-12 01:21:48 --> Model Class Initialized
INFO - 2016-11-12 01:21:48 --> Model Class Initialized
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:21:48 --> Final output sent to browser
DEBUG - 2016-11-12 01:21:48 --> Total execution time: 0.4261
INFO - 2016-11-12 01:22:56 --> Config Class Initialized
INFO - 2016-11-12 01:22:56 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:22:56 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:22:56 --> Utf8 Class Initialized
INFO - 2016-11-12 01:22:56 --> URI Class Initialized
DEBUG - 2016-11-12 01:22:56 --> No URI present. Default controller set.
INFO - 2016-11-12 01:22:56 --> Router Class Initialized
INFO - 2016-11-12 01:22:56 --> Output Class Initialized
INFO - 2016-11-12 01:22:56 --> Security Class Initialized
DEBUG - 2016-11-12 01:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:22:56 --> Input Class Initialized
INFO - 2016-11-12 01:22:56 --> Language Class Initialized
INFO - 2016-11-12 01:22:56 --> Loader Class Initialized
INFO - 2016-11-12 01:22:56 --> Helper loaded: url_helper
INFO - 2016-11-12 01:22:56 --> Helper loaded: form_helper
INFO - 2016-11-12 01:22:56 --> Database Driver Class Initialized
INFO - 2016-11-12 01:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:22:56 --> Controller Class Initialized
INFO - 2016-11-12 01:22:56 --> Model Class Initialized
INFO - 2016-11-12 01:22:56 --> Model Class Initialized
INFO - 2016-11-12 01:22:56 --> Model Class Initialized
INFO - 2016-11-12 01:22:56 --> Model Class Initialized
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:22:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:22:56 --> Final output sent to browser
DEBUG - 2016-11-12 01:22:56 --> Total execution time: 0.3895
INFO - 2016-11-12 01:23:19 --> Config Class Initialized
INFO - 2016-11-12 01:23:19 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:23:19 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:23:19 --> Utf8 Class Initialized
INFO - 2016-11-12 01:23:19 --> URI Class Initialized
INFO - 2016-11-12 01:23:19 --> Router Class Initialized
INFO - 2016-11-12 01:23:19 --> Output Class Initialized
INFO - 2016-11-12 01:23:19 --> Security Class Initialized
DEBUG - 2016-11-12 01:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:23:19 --> Input Class Initialized
INFO - 2016-11-12 01:23:19 --> Language Class Initialized
INFO - 2016-11-12 01:23:19 --> Loader Class Initialized
INFO - 2016-11-12 01:23:19 --> Helper loaded: url_helper
INFO - 2016-11-12 01:23:19 --> Helper loaded: form_helper
INFO - 2016-11-12 01:23:19 --> Database Driver Class Initialized
INFO - 2016-11-12 01:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:23:19 --> Controller Class Initialized
INFO - 2016-11-12 01:23:19 --> Model Class Initialized
INFO - 2016-11-12 01:23:19 --> Model Class Initialized
INFO - 2016-11-12 01:23:19 --> Model Class Initialized
INFO - 2016-11-12 01:23:19 --> Model Class Initialized
DEBUG - 2016-11-12 01:23:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 01:23:19 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 01:23:19 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 01:23:19 --> Config Class Initialized
INFO - 2016-11-12 01:23:19 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:23:19 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:23:19 --> Utf8 Class Initialized
INFO - 2016-11-12 01:23:19 --> URI Class Initialized
DEBUG - 2016-11-12 01:23:19 --> No URI present. Default controller set.
INFO - 2016-11-12 01:23:19 --> Router Class Initialized
INFO - 2016-11-12 01:23:19 --> Output Class Initialized
INFO - 2016-11-12 01:23:20 --> Security Class Initialized
DEBUG - 2016-11-12 01:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:23:20 --> Input Class Initialized
INFO - 2016-11-12 01:23:20 --> Language Class Initialized
INFO - 2016-11-12 01:23:20 --> Loader Class Initialized
INFO - 2016-11-12 01:23:20 --> Helper loaded: url_helper
INFO - 2016-11-12 01:23:20 --> Helper loaded: form_helper
INFO - 2016-11-12 01:23:20 --> Database Driver Class Initialized
INFO - 2016-11-12 01:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:23:20 --> Controller Class Initialized
INFO - 2016-11-12 01:23:20 --> Model Class Initialized
INFO - 2016-11-12 01:23:20 --> Model Class Initialized
INFO - 2016-11-12 01:23:20 --> Model Class Initialized
INFO - 2016-11-12 01:23:20 --> Model Class Initialized
INFO - 2016-11-12 01:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 01:23:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:23:20 --> Final output sent to browser
DEBUG - 2016-11-12 01:23:20 --> Total execution time: 0.2850
INFO - 2016-11-12 01:23:30 --> Config Class Initialized
INFO - 2016-11-12 01:23:30 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:23:30 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:23:30 --> Utf8 Class Initialized
INFO - 2016-11-12 01:23:30 --> URI Class Initialized
INFO - 2016-11-12 01:23:30 --> Router Class Initialized
INFO - 2016-11-12 01:23:31 --> Output Class Initialized
INFO - 2016-11-12 01:23:31 --> Security Class Initialized
DEBUG - 2016-11-12 01:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:23:31 --> Input Class Initialized
INFO - 2016-11-12 01:23:31 --> Language Class Initialized
INFO - 2016-11-12 01:23:31 --> Loader Class Initialized
INFO - 2016-11-12 01:23:31 --> Helper loaded: url_helper
INFO - 2016-11-12 01:23:31 --> Helper loaded: form_helper
INFO - 2016-11-12 01:23:31 --> Database Driver Class Initialized
INFO - 2016-11-12 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:23:31 --> Controller Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
DEBUG - 2016-11-12 01:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Final output sent to browser
DEBUG - 2016-11-12 01:23:31 --> Total execution time: 0.2530
INFO - 2016-11-12 01:23:31 --> Config Class Initialized
INFO - 2016-11-12 01:23:31 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:23:31 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:23:31 --> Utf8 Class Initialized
INFO - 2016-11-12 01:23:31 --> URI Class Initialized
DEBUG - 2016-11-12 01:23:31 --> No URI present. Default controller set.
INFO - 2016-11-12 01:23:31 --> Router Class Initialized
INFO - 2016-11-12 01:23:31 --> Output Class Initialized
INFO - 2016-11-12 01:23:31 --> Security Class Initialized
DEBUG - 2016-11-12 01:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:23:31 --> Input Class Initialized
INFO - 2016-11-12 01:23:31 --> Language Class Initialized
INFO - 2016-11-12 01:23:31 --> Loader Class Initialized
INFO - 2016-11-12 01:23:31 --> Helper loaded: url_helper
INFO - 2016-11-12 01:23:31 --> Helper loaded: form_helper
INFO - 2016-11-12 01:23:31 --> Database Driver Class Initialized
INFO - 2016-11-12 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:23:31 --> Controller Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> Model Class Initialized
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:23:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:23:31 --> Final output sent to browser
DEBUG - 2016-11-12 01:23:31 --> Total execution time: 0.3925
INFO - 2016-11-12 01:30:26 --> Config Class Initialized
INFO - 2016-11-12 01:30:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:30:26 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:30:26 --> Utf8 Class Initialized
INFO - 2016-11-12 01:30:26 --> URI Class Initialized
DEBUG - 2016-11-12 01:30:26 --> No URI present. Default controller set.
INFO - 2016-11-12 01:30:26 --> Router Class Initialized
INFO - 2016-11-12 01:30:26 --> Output Class Initialized
INFO - 2016-11-12 01:30:26 --> Security Class Initialized
DEBUG - 2016-11-12 01:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:30:26 --> Input Class Initialized
INFO - 2016-11-12 01:30:26 --> Language Class Initialized
INFO - 2016-11-12 01:30:26 --> Loader Class Initialized
INFO - 2016-11-12 01:30:26 --> Helper loaded: url_helper
INFO - 2016-11-12 01:30:26 --> Helper loaded: form_helper
INFO - 2016-11-12 01:30:26 --> Database Driver Class Initialized
INFO - 2016-11-12 01:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:30:27 --> Controller Class Initialized
INFO - 2016-11-12 01:30:27 --> Model Class Initialized
INFO - 2016-11-12 01:30:27 --> Model Class Initialized
INFO - 2016-11-12 01:30:27 --> Model Class Initialized
INFO - 2016-11-12 01:30:27 --> Model Class Initialized
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:30:27 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:30:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:30:27 --> Final output sent to browser
DEBUG - 2016-11-12 01:30:27 --> Total execution time: 0.4223
INFO - 2016-11-12 01:31:18 --> Config Class Initialized
INFO - 2016-11-12 01:31:18 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:31:18 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:31:18 --> Utf8 Class Initialized
INFO - 2016-11-12 01:31:18 --> URI Class Initialized
DEBUG - 2016-11-12 01:31:18 --> No URI present. Default controller set.
INFO - 2016-11-12 01:31:18 --> Router Class Initialized
INFO - 2016-11-12 01:31:18 --> Output Class Initialized
INFO - 2016-11-12 01:31:18 --> Security Class Initialized
DEBUG - 2016-11-12 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:31:18 --> Input Class Initialized
INFO - 2016-11-12 01:31:18 --> Language Class Initialized
INFO - 2016-11-12 01:31:18 --> Loader Class Initialized
INFO - 2016-11-12 01:31:18 --> Helper loaded: url_helper
INFO - 2016-11-12 01:31:18 --> Helper loaded: form_helper
INFO - 2016-11-12 01:31:18 --> Database Driver Class Initialized
INFO - 2016-11-12 01:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:31:18 --> Controller Class Initialized
INFO - 2016-11-12 01:31:18 --> Model Class Initialized
INFO - 2016-11-12 01:31:18 --> Model Class Initialized
INFO - 2016-11-12 01:31:18 --> Model Class Initialized
INFO - 2016-11-12 01:31:18 --> Model Class Initialized
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:31:18 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:31:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:31:18 --> Final output sent to browser
DEBUG - 2016-11-12 01:31:18 --> Total execution time: 0.4144
INFO - 2016-11-12 01:34:23 --> Config Class Initialized
INFO - 2016-11-12 01:34:23 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:34:23 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:34:23 --> Utf8 Class Initialized
INFO - 2016-11-12 01:34:23 --> URI Class Initialized
DEBUG - 2016-11-12 01:34:23 --> No URI present. Default controller set.
INFO - 2016-11-12 01:34:23 --> Router Class Initialized
INFO - 2016-11-12 01:34:23 --> Output Class Initialized
INFO - 2016-11-12 01:34:24 --> Security Class Initialized
DEBUG - 2016-11-12 01:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:34:24 --> Input Class Initialized
INFO - 2016-11-12 01:34:24 --> Language Class Initialized
INFO - 2016-11-12 01:34:24 --> Loader Class Initialized
INFO - 2016-11-12 01:34:24 --> Helper loaded: url_helper
INFO - 2016-11-12 01:34:24 --> Helper loaded: form_helper
INFO - 2016-11-12 01:34:24 --> Database Driver Class Initialized
INFO - 2016-11-12 01:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:34:24 --> Controller Class Initialized
INFO - 2016-11-12 01:34:24 --> Model Class Initialized
INFO - 2016-11-12 01:34:24 --> Model Class Initialized
INFO - 2016-11-12 01:34:24 --> Model Class Initialized
INFO - 2016-11-12 01:34:24 --> Model Class Initialized
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:34:24 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:34:24 --> Final output sent to browser
DEBUG - 2016-11-12 01:34:24 --> Total execution time: 0.4488
INFO - 2016-11-12 01:36:25 --> Config Class Initialized
INFO - 2016-11-12 01:36:25 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:36:25 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:36:25 --> Utf8 Class Initialized
INFO - 2016-11-12 01:36:25 --> URI Class Initialized
DEBUG - 2016-11-12 01:36:25 --> No URI present. Default controller set.
INFO - 2016-11-12 01:36:25 --> Router Class Initialized
INFO - 2016-11-12 01:36:25 --> Output Class Initialized
INFO - 2016-11-12 01:36:25 --> Security Class Initialized
DEBUG - 2016-11-12 01:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:36:25 --> Input Class Initialized
INFO - 2016-11-12 01:36:25 --> Language Class Initialized
INFO - 2016-11-12 01:36:25 --> Loader Class Initialized
INFO - 2016-11-12 01:36:25 --> Helper loaded: url_helper
INFO - 2016-11-12 01:36:25 --> Helper loaded: form_helper
INFO - 2016-11-12 01:36:25 --> Database Driver Class Initialized
INFO - 2016-11-12 01:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:36:25 --> Controller Class Initialized
INFO - 2016-11-12 01:36:25 --> Model Class Initialized
INFO - 2016-11-12 01:36:25 --> Model Class Initialized
INFO - 2016-11-12 01:36:25 --> Model Class Initialized
INFO - 2016-11-12 01:36:25 --> Model Class Initialized
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:36:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:36:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:36:25 --> Final output sent to browser
DEBUG - 2016-11-12 01:36:25 --> Total execution time: 0.4519
INFO - 2016-11-12 01:39:10 --> Config Class Initialized
INFO - 2016-11-12 01:39:10 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:39:10 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:39:10 --> Utf8 Class Initialized
INFO - 2016-11-12 01:39:10 --> URI Class Initialized
DEBUG - 2016-11-12 01:39:10 --> No URI present. Default controller set.
INFO - 2016-11-12 01:39:10 --> Router Class Initialized
INFO - 2016-11-12 01:39:10 --> Output Class Initialized
INFO - 2016-11-12 01:39:10 --> Security Class Initialized
DEBUG - 2016-11-12 01:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:39:10 --> Input Class Initialized
INFO - 2016-11-12 01:39:10 --> Language Class Initialized
INFO - 2016-11-12 01:39:10 --> Loader Class Initialized
INFO - 2016-11-12 01:39:10 --> Helper loaded: url_helper
INFO - 2016-11-12 01:39:10 --> Helper loaded: form_helper
INFO - 2016-11-12 01:39:10 --> Database Driver Class Initialized
INFO - 2016-11-12 01:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:39:10 --> Controller Class Initialized
INFO - 2016-11-12 01:39:10 --> Model Class Initialized
INFO - 2016-11-12 01:39:10 --> Model Class Initialized
INFO - 2016-11-12 01:39:10 --> Model Class Initialized
INFO - 2016-11-12 01:39:10 --> Model Class Initialized
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:39:10 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:39:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:39:10 --> Final output sent to browser
DEBUG - 2016-11-12 01:39:10 --> Total execution time: 0.4488
INFO - 2016-11-12 01:39:33 --> Config Class Initialized
INFO - 2016-11-12 01:39:33 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:39:33 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:39:33 --> Utf8 Class Initialized
INFO - 2016-11-12 01:39:33 --> URI Class Initialized
DEBUG - 2016-11-12 01:39:33 --> No URI present. Default controller set.
INFO - 2016-11-12 01:39:33 --> Router Class Initialized
INFO - 2016-11-12 01:39:33 --> Output Class Initialized
INFO - 2016-11-12 01:39:33 --> Security Class Initialized
DEBUG - 2016-11-12 01:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:39:33 --> Input Class Initialized
INFO - 2016-11-12 01:39:33 --> Language Class Initialized
INFO - 2016-11-12 01:39:33 --> Loader Class Initialized
INFO - 2016-11-12 01:39:33 --> Helper loaded: url_helper
INFO - 2016-11-12 01:39:33 --> Helper loaded: form_helper
INFO - 2016-11-12 01:39:33 --> Database Driver Class Initialized
INFO - 2016-11-12 01:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:39:33 --> Controller Class Initialized
INFO - 2016-11-12 01:39:33 --> Model Class Initialized
INFO - 2016-11-12 01:39:33 --> Model Class Initialized
INFO - 2016-11-12 01:39:33 --> Model Class Initialized
INFO - 2016-11-12 01:39:33 --> Model Class Initialized
INFO - 2016-11-12 01:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:39:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:39:34 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:39:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:39:34 --> Final output sent to browser
DEBUG - 2016-11-12 01:39:34 --> Total execution time: 0.4501
INFO - 2016-11-12 01:41:10 --> Config Class Initialized
INFO - 2016-11-12 01:41:10 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:41:10 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:41:10 --> Utf8 Class Initialized
INFO - 2016-11-12 01:41:10 --> URI Class Initialized
DEBUG - 2016-11-12 01:41:10 --> No URI present. Default controller set.
INFO - 2016-11-12 01:41:10 --> Router Class Initialized
INFO - 2016-11-12 01:41:11 --> Output Class Initialized
INFO - 2016-11-12 01:41:11 --> Security Class Initialized
DEBUG - 2016-11-12 01:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:41:11 --> Input Class Initialized
INFO - 2016-11-12 01:41:11 --> Language Class Initialized
INFO - 2016-11-12 01:41:11 --> Loader Class Initialized
INFO - 2016-11-12 01:41:11 --> Helper loaded: url_helper
INFO - 2016-11-12 01:41:11 --> Helper loaded: form_helper
INFO - 2016-11-12 01:41:11 --> Database Driver Class Initialized
INFO - 2016-11-12 01:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:41:11 --> Controller Class Initialized
INFO - 2016-11-12 01:41:11 --> Model Class Initialized
INFO - 2016-11-12 01:41:11 --> Model Class Initialized
INFO - 2016-11-12 01:41:11 --> Model Class Initialized
INFO - 2016-11-12 01:41:11 --> Model Class Initialized
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:41:11 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:41:11 --> Final output sent to browser
DEBUG - 2016-11-12 01:41:11 --> Total execution time: 0.4354
INFO - 2016-11-12 01:41:29 --> Config Class Initialized
INFO - 2016-11-12 01:41:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:41:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:41:29 --> Utf8 Class Initialized
INFO - 2016-11-12 01:41:29 --> URI Class Initialized
DEBUG - 2016-11-12 01:41:29 --> No URI present. Default controller set.
INFO - 2016-11-12 01:41:29 --> Router Class Initialized
INFO - 2016-11-12 01:41:29 --> Output Class Initialized
INFO - 2016-11-12 01:41:29 --> Security Class Initialized
DEBUG - 2016-11-12 01:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:41:29 --> Input Class Initialized
INFO - 2016-11-12 01:41:29 --> Language Class Initialized
INFO - 2016-11-12 01:41:29 --> Loader Class Initialized
INFO - 2016-11-12 01:41:29 --> Helper loaded: url_helper
INFO - 2016-11-12 01:41:29 --> Helper loaded: form_helper
INFO - 2016-11-12 01:41:29 --> Database Driver Class Initialized
INFO - 2016-11-12 01:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:41:29 --> Controller Class Initialized
INFO - 2016-11-12 01:41:29 --> Model Class Initialized
INFO - 2016-11-12 01:41:29 --> Model Class Initialized
INFO - 2016-11-12 01:41:29 --> Model Class Initialized
INFO - 2016-11-12 01:41:29 --> Model Class Initialized
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:41:29 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:41:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:41:29 --> Final output sent to browser
DEBUG - 2016-11-12 01:41:29 --> Total execution time: 0.4934
INFO - 2016-11-12 01:47:46 --> Config Class Initialized
INFO - 2016-11-12 01:47:46 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:47:46 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:47:46 --> Utf8 Class Initialized
INFO - 2016-11-12 01:47:46 --> URI Class Initialized
DEBUG - 2016-11-12 01:47:46 --> No URI present. Default controller set.
INFO - 2016-11-12 01:47:46 --> Router Class Initialized
INFO - 2016-11-12 01:47:46 --> Output Class Initialized
INFO - 2016-11-12 01:47:46 --> Security Class Initialized
DEBUG - 2016-11-12 01:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:47:46 --> Input Class Initialized
INFO - 2016-11-12 01:47:46 --> Language Class Initialized
INFO - 2016-11-12 01:47:46 --> Loader Class Initialized
INFO - 2016-11-12 01:47:46 --> Helper loaded: url_helper
INFO - 2016-11-12 01:47:46 --> Helper loaded: form_helper
INFO - 2016-11-12 01:47:46 --> Database Driver Class Initialized
INFO - 2016-11-12 01:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:47:46 --> Controller Class Initialized
INFO - 2016-11-12 01:47:46 --> Model Class Initialized
INFO - 2016-11-12 01:47:46 --> Model Class Initialized
INFO - 2016-11-12 01:47:46 --> Model Class Initialized
INFO - 2016-11-12 01:47:46 --> Model Class Initialized
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:47:46 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:47:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:47:46 --> Final output sent to browser
DEBUG - 2016-11-12 01:47:46 --> Total execution time: 0.4304
INFO - 2016-11-12 01:49:29 --> Config Class Initialized
INFO - 2016-11-12 01:49:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:49:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:49:29 --> Utf8 Class Initialized
INFO - 2016-11-12 01:49:29 --> URI Class Initialized
DEBUG - 2016-11-12 01:49:29 --> No URI present. Default controller set.
INFO - 2016-11-12 01:49:29 --> Router Class Initialized
INFO - 2016-11-12 01:49:29 --> Output Class Initialized
INFO - 2016-11-12 01:49:29 --> Security Class Initialized
DEBUG - 2016-11-12 01:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:49:29 --> Input Class Initialized
INFO - 2016-11-12 01:49:29 --> Language Class Initialized
INFO - 2016-11-12 01:49:29 --> Loader Class Initialized
INFO - 2016-11-12 01:49:29 --> Helper loaded: url_helper
INFO - 2016-11-12 01:49:29 --> Helper loaded: form_helper
INFO - 2016-11-12 01:49:29 --> Database Driver Class Initialized
INFO - 2016-11-12 01:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:49:29 --> Controller Class Initialized
INFO - 2016-11-12 01:49:29 --> Model Class Initialized
INFO - 2016-11-12 01:49:29 --> Model Class Initialized
INFO - 2016-11-12 01:49:29 --> Model Class Initialized
INFO - 2016-11-12 01:49:29 --> Model Class Initialized
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:49:29 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 26
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:49:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:49:29 --> Final output sent to browser
DEBUG - 2016-11-12 01:49:29 --> Total execution time: 0.4493
INFO - 2016-11-12 01:50:29 --> Config Class Initialized
INFO - 2016-11-12 01:50:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:50:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:50:29 --> Utf8 Class Initialized
INFO - 2016-11-12 01:50:29 --> URI Class Initialized
DEBUG - 2016-11-12 01:50:29 --> No URI present. Default controller set.
INFO - 2016-11-12 01:50:29 --> Router Class Initialized
INFO - 2016-11-12 01:50:29 --> Output Class Initialized
INFO - 2016-11-12 01:50:29 --> Security Class Initialized
DEBUG - 2016-11-12 01:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:50:29 --> Input Class Initialized
INFO - 2016-11-12 01:50:29 --> Language Class Initialized
INFO - 2016-11-12 01:50:29 --> Loader Class Initialized
INFO - 2016-11-12 01:50:29 --> Helper loaded: url_helper
INFO - 2016-11-12 01:50:29 --> Helper loaded: form_helper
INFO - 2016-11-12 01:50:29 --> Database Driver Class Initialized
INFO - 2016-11-12 01:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:50:29 --> Controller Class Initialized
INFO - 2016-11-12 01:50:29 --> Model Class Initialized
INFO - 2016-11-12 01:50:29 --> Model Class Initialized
INFO - 2016-11-12 01:50:29 --> Model Class Initialized
INFO - 2016-11-12 01:50:29 --> Model Class Initialized
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:50:29 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 26
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:50:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:50:29 --> Final output sent to browser
DEBUG - 2016-11-12 01:50:29 --> Total execution time: 0.5122
INFO - 2016-11-12 01:50:43 --> Config Class Initialized
INFO - 2016-11-12 01:50:43 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:50:43 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:50:43 --> Utf8 Class Initialized
INFO - 2016-11-12 01:50:43 --> URI Class Initialized
DEBUG - 2016-11-12 01:50:43 --> No URI present. Default controller set.
INFO - 2016-11-12 01:50:43 --> Router Class Initialized
INFO - 2016-11-12 01:50:43 --> Output Class Initialized
INFO - 2016-11-12 01:50:43 --> Security Class Initialized
DEBUG - 2016-11-12 01:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:50:43 --> Input Class Initialized
INFO - 2016-11-12 01:50:43 --> Language Class Initialized
INFO - 2016-11-12 01:50:43 --> Loader Class Initialized
INFO - 2016-11-12 01:50:43 --> Helper loaded: url_helper
INFO - 2016-11-12 01:50:43 --> Helper loaded: form_helper
INFO - 2016-11-12 01:50:43 --> Database Driver Class Initialized
INFO - 2016-11-12 01:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:50:43 --> Controller Class Initialized
INFO - 2016-11-12 01:50:43 --> Model Class Initialized
INFO - 2016-11-12 01:50:43 --> Model Class Initialized
INFO - 2016-11-12 01:50:43 --> Model Class Initialized
INFO - 2016-11-12 01:50:43 --> Model Class Initialized
INFO - 2016-11-12 01:50:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:50:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:50:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:50:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:50:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:50:44 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:50:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:50:44 --> Final output sent to browser
DEBUG - 2016-11-12 01:50:44 --> Total execution time: 0.4311
INFO - 2016-11-12 01:53:12 --> Config Class Initialized
INFO - 2016-11-12 01:53:12 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:53:12 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:53:12 --> Utf8 Class Initialized
INFO - 2016-11-12 01:53:12 --> URI Class Initialized
DEBUG - 2016-11-12 01:53:12 --> No URI present. Default controller set.
INFO - 2016-11-12 01:53:12 --> Router Class Initialized
INFO - 2016-11-12 01:53:13 --> Output Class Initialized
INFO - 2016-11-12 01:53:13 --> Security Class Initialized
DEBUG - 2016-11-12 01:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:53:13 --> Input Class Initialized
INFO - 2016-11-12 01:53:13 --> Language Class Initialized
INFO - 2016-11-12 01:53:13 --> Loader Class Initialized
INFO - 2016-11-12 01:53:13 --> Helper loaded: url_helper
INFO - 2016-11-12 01:53:13 --> Helper loaded: form_helper
INFO - 2016-11-12 01:53:13 --> Database Driver Class Initialized
INFO - 2016-11-12 01:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:53:13 --> Controller Class Initialized
INFO - 2016-11-12 01:53:13 --> Model Class Initialized
INFO - 2016-11-12 01:53:13 --> Model Class Initialized
INFO - 2016-11-12 01:53:13 --> Model Class Initialized
INFO - 2016-11-12 01:53:13 --> Model Class Initialized
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:53:13 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:53:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:53:13 --> Final output sent to browser
DEBUG - 2016-11-12 01:53:13 --> Total execution time: 0.5566
INFO - 2016-11-12 01:53:32 --> Config Class Initialized
INFO - 2016-11-12 01:53:32 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:53:32 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:53:32 --> Utf8 Class Initialized
INFO - 2016-11-12 01:53:32 --> URI Class Initialized
DEBUG - 2016-11-12 01:53:32 --> No URI present. Default controller set.
INFO - 2016-11-12 01:53:32 --> Router Class Initialized
INFO - 2016-11-12 01:53:32 --> Output Class Initialized
INFO - 2016-11-12 01:53:32 --> Security Class Initialized
DEBUG - 2016-11-12 01:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:53:32 --> Input Class Initialized
INFO - 2016-11-12 01:53:32 --> Language Class Initialized
INFO - 2016-11-12 01:53:32 --> Loader Class Initialized
INFO - 2016-11-12 01:53:32 --> Helper loaded: url_helper
INFO - 2016-11-12 01:53:32 --> Helper loaded: form_helper
INFO - 2016-11-12 01:53:32 --> Database Driver Class Initialized
INFO - 2016-11-12 01:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:53:32 --> Controller Class Initialized
INFO - 2016-11-12 01:53:32 --> Model Class Initialized
INFO - 2016-11-12 01:53:32 --> Model Class Initialized
INFO - 2016-11-12 01:53:32 --> Model Class Initialized
INFO - 2016-11-12 01:53:32 --> Model Class Initialized
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:53:32 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:53:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:53:32 --> Final output sent to browser
DEBUG - 2016-11-12 01:53:32 --> Total execution time: 0.4398
INFO - 2016-11-12 01:54:10 --> Config Class Initialized
INFO - 2016-11-12 01:54:10 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:54:10 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:54:10 --> Utf8 Class Initialized
INFO - 2016-11-12 01:54:10 --> URI Class Initialized
DEBUG - 2016-11-12 01:54:10 --> No URI present. Default controller set.
INFO - 2016-11-12 01:54:10 --> Router Class Initialized
INFO - 2016-11-12 01:54:10 --> Output Class Initialized
INFO - 2016-11-12 01:54:10 --> Security Class Initialized
DEBUG - 2016-11-12 01:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:54:10 --> Input Class Initialized
INFO - 2016-11-12 01:54:10 --> Language Class Initialized
INFO - 2016-11-12 01:54:10 --> Loader Class Initialized
INFO - 2016-11-12 01:54:10 --> Helper loaded: url_helper
INFO - 2016-11-12 01:54:10 --> Helper loaded: form_helper
INFO - 2016-11-12 01:54:10 --> Database Driver Class Initialized
INFO - 2016-11-12 01:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:54:10 --> Controller Class Initialized
INFO - 2016-11-12 01:54:10 --> Model Class Initialized
INFO - 2016-11-12 01:54:10 --> Model Class Initialized
INFO - 2016-11-12 01:54:10 --> Model Class Initialized
INFO - 2016-11-12 01:54:10 --> Model Class Initialized
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:54:10 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:54:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:54:10 --> Final output sent to browser
DEBUG - 2016-11-12 01:54:10 --> Total execution time: 0.4477
INFO - 2016-11-12 01:54:29 --> Config Class Initialized
INFO - 2016-11-12 01:54:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 01:54:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 01:54:29 --> Utf8 Class Initialized
INFO - 2016-11-12 01:54:30 --> URI Class Initialized
DEBUG - 2016-11-12 01:54:30 --> No URI present. Default controller set.
INFO - 2016-11-12 01:54:30 --> Router Class Initialized
INFO - 2016-11-12 01:54:30 --> Output Class Initialized
INFO - 2016-11-12 01:54:30 --> Security Class Initialized
DEBUG - 2016-11-12 01:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 01:54:30 --> Input Class Initialized
INFO - 2016-11-12 01:54:30 --> Language Class Initialized
INFO - 2016-11-12 01:54:30 --> Loader Class Initialized
INFO - 2016-11-12 01:54:30 --> Helper loaded: url_helper
INFO - 2016-11-12 01:54:30 --> Helper loaded: form_helper
INFO - 2016-11-12 01:54:30 --> Database Driver Class Initialized
INFO - 2016-11-12 01:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 01:54:30 --> Controller Class Initialized
INFO - 2016-11-12 01:54:30 --> Model Class Initialized
INFO - 2016-11-12 01:54:30 --> Model Class Initialized
INFO - 2016-11-12 01:54:30 --> Model Class Initialized
INFO - 2016-11-12 01:54:30 --> Model Class Initialized
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 01:54:30 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 01:54:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 01:54:30 --> Final output sent to browser
DEBUG - 2016-11-12 01:54:30 --> Total execution time: 0.4502
INFO - 2016-11-12 19:32:09 --> Config Class Initialized
INFO - 2016-11-12 19:32:09 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:32:09 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:32:09 --> Utf8 Class Initialized
INFO - 2016-11-12 19:32:09 --> URI Class Initialized
DEBUG - 2016-11-12 19:32:09 --> No URI present. Default controller set.
INFO - 2016-11-12 19:32:09 --> Router Class Initialized
INFO - 2016-11-12 19:32:09 --> Output Class Initialized
INFO - 2016-11-12 19:32:09 --> Security Class Initialized
DEBUG - 2016-11-12 19:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:32:09 --> Input Class Initialized
INFO - 2016-11-12 19:32:09 --> Language Class Initialized
INFO - 2016-11-12 19:32:10 --> Loader Class Initialized
INFO - 2016-11-12 19:32:10 --> Helper loaded: url_helper
INFO - 2016-11-12 19:32:10 --> Helper loaded: form_helper
INFO - 2016-11-12 19:32:10 --> Database Driver Class Initialized
INFO - 2016-11-12 19:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:32:10 --> Controller Class Initialized
INFO - 2016-11-12 19:32:11 --> Model Class Initialized
INFO - 2016-11-12 19:32:11 --> Model Class Initialized
INFO - 2016-11-12 19:32:11 --> Model Class Initialized
INFO - 2016-11-12 19:32:11 --> Model Class Initialized
INFO - 2016-11-12 19:32:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:32:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 19:32:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:32:11 --> Final output sent to browser
DEBUG - 2016-11-12 19:32:11 --> Total execution time: 2.3356
INFO - 2016-11-12 19:32:28 --> Config Class Initialized
INFO - 2016-11-12 19:32:28 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:32:28 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:32:28 --> Utf8 Class Initialized
INFO - 2016-11-12 19:32:28 --> URI Class Initialized
INFO - 2016-11-12 19:32:28 --> Router Class Initialized
INFO - 2016-11-12 19:32:28 --> Output Class Initialized
INFO - 2016-11-12 19:32:28 --> Security Class Initialized
DEBUG - 2016-11-12 19:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:32:28 --> Input Class Initialized
INFO - 2016-11-12 19:32:28 --> Language Class Initialized
INFO - 2016-11-12 19:32:28 --> Loader Class Initialized
INFO - 2016-11-12 19:32:28 --> Helper loaded: url_helper
INFO - 2016-11-12 19:32:28 --> Helper loaded: form_helper
INFO - 2016-11-12 19:32:28 --> Database Driver Class Initialized
INFO - 2016-11-12 19:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:32:29 --> Controller Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
DEBUG - 2016-11-12 19:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Final output sent to browser
DEBUG - 2016-11-12 19:32:29 --> Total execution time: 0.4572
INFO - 2016-11-12 19:32:29 --> Config Class Initialized
INFO - 2016-11-12 19:32:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:32:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:32:29 --> Utf8 Class Initialized
INFO - 2016-11-12 19:32:29 --> URI Class Initialized
DEBUG - 2016-11-12 19:32:29 --> No URI present. Default controller set.
INFO - 2016-11-12 19:32:29 --> Router Class Initialized
INFO - 2016-11-12 19:32:29 --> Output Class Initialized
INFO - 2016-11-12 19:32:29 --> Security Class Initialized
DEBUG - 2016-11-12 19:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:32:29 --> Input Class Initialized
INFO - 2016-11-12 19:32:29 --> Language Class Initialized
INFO - 2016-11-12 19:32:29 --> Loader Class Initialized
INFO - 2016-11-12 19:32:29 --> Helper loaded: url_helper
INFO - 2016-11-12 19:32:29 --> Helper loaded: form_helper
INFO - 2016-11-12 19:32:29 --> Database Driver Class Initialized
INFO - 2016-11-12 19:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:32:29 --> Controller Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> Model Class Initialized
INFO - 2016-11-12 19:32:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:32:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:32:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:32:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:32:30 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:32:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:32:30 --> Final output sent to browser
DEBUG - 2016-11-12 19:32:30 --> Total execution time: 0.9479
INFO - 2016-11-12 19:35:41 --> Config Class Initialized
INFO - 2016-11-12 19:35:41 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:35:41 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:35:41 --> Utf8 Class Initialized
INFO - 2016-11-12 19:35:41 --> URI Class Initialized
DEBUG - 2016-11-12 19:35:41 --> No URI present. Default controller set.
INFO - 2016-11-12 19:35:41 --> Router Class Initialized
INFO - 2016-11-12 19:35:41 --> Output Class Initialized
INFO - 2016-11-12 19:35:41 --> Security Class Initialized
DEBUG - 2016-11-12 19:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:35:41 --> Input Class Initialized
INFO - 2016-11-12 19:35:41 --> Language Class Initialized
INFO - 2016-11-12 19:35:41 --> Loader Class Initialized
INFO - 2016-11-12 19:35:41 --> Helper loaded: url_helper
INFO - 2016-11-12 19:35:41 --> Helper loaded: form_helper
INFO - 2016-11-12 19:35:41 --> Database Driver Class Initialized
INFO - 2016-11-12 19:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:35:41 --> Controller Class Initialized
INFO - 2016-11-12 19:35:41 --> Model Class Initialized
INFO - 2016-11-12 19:35:41 --> Model Class Initialized
INFO - 2016-11-12 19:35:41 --> Model Class Initialized
INFO - 2016-11-12 19:35:41 --> Model Class Initialized
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:35:41 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:35:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:35:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:35:42 --> Final output sent to browser
DEBUG - 2016-11-12 19:35:42 --> Total execution time: 0.5379
INFO - 2016-11-12 19:36:40 --> Config Class Initialized
INFO - 2016-11-12 19:36:40 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:36:40 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:36:40 --> Utf8 Class Initialized
INFO - 2016-11-12 19:36:40 --> URI Class Initialized
DEBUG - 2016-11-12 19:36:40 --> No URI present. Default controller set.
INFO - 2016-11-12 19:36:40 --> Router Class Initialized
INFO - 2016-11-12 19:36:40 --> Output Class Initialized
INFO - 2016-11-12 19:36:40 --> Security Class Initialized
DEBUG - 2016-11-12 19:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:36:40 --> Input Class Initialized
INFO - 2016-11-12 19:36:40 --> Language Class Initialized
INFO - 2016-11-12 19:36:40 --> Loader Class Initialized
INFO - 2016-11-12 19:36:40 --> Helper loaded: url_helper
INFO - 2016-11-12 19:36:40 --> Helper loaded: form_helper
INFO - 2016-11-12 19:36:40 --> Database Driver Class Initialized
INFO - 2016-11-12 19:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:36:40 --> Controller Class Initialized
INFO - 2016-11-12 19:36:40 --> Model Class Initialized
INFO - 2016-11-12 19:36:40 --> Model Class Initialized
INFO - 2016-11-12 19:36:40 --> Model Class Initialized
INFO - 2016-11-12 19:36:40 --> Model Class Initialized
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:36:40 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:36:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:36:40 --> Final output sent to browser
DEBUG - 2016-11-12 19:36:40 --> Total execution time: 0.4170
INFO - 2016-11-12 19:37:30 --> Config Class Initialized
INFO - 2016-11-12 19:37:30 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:37:30 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:37:30 --> Utf8 Class Initialized
INFO - 2016-11-12 19:37:30 --> URI Class Initialized
DEBUG - 2016-11-12 19:37:30 --> No URI present. Default controller set.
INFO - 2016-11-12 19:37:30 --> Router Class Initialized
INFO - 2016-11-12 19:37:30 --> Output Class Initialized
INFO - 2016-11-12 19:37:30 --> Security Class Initialized
DEBUG - 2016-11-12 19:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:37:30 --> Input Class Initialized
INFO - 2016-11-12 19:37:30 --> Language Class Initialized
INFO - 2016-11-12 19:37:30 --> Loader Class Initialized
INFO - 2016-11-12 19:37:30 --> Helper loaded: url_helper
INFO - 2016-11-12 19:37:30 --> Helper loaded: form_helper
INFO - 2016-11-12 19:37:30 --> Database Driver Class Initialized
INFO - 2016-11-12 19:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:37:30 --> Controller Class Initialized
INFO - 2016-11-12 19:37:30 --> Model Class Initialized
INFO - 2016-11-12 19:37:30 --> Model Class Initialized
INFO - 2016-11-12 19:37:30 --> Model Class Initialized
INFO - 2016-11-12 19:37:30 --> Model Class Initialized
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:37:30 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:37:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:37:30 --> Final output sent to browser
DEBUG - 2016-11-12 19:37:30 --> Total execution time: 0.4395
INFO - 2016-11-12 19:37:51 --> Config Class Initialized
INFO - 2016-11-12 19:37:51 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:37:51 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:37:51 --> Utf8 Class Initialized
INFO - 2016-11-12 19:37:51 --> URI Class Initialized
DEBUG - 2016-11-12 19:37:51 --> No URI present. Default controller set.
INFO - 2016-11-12 19:37:51 --> Router Class Initialized
INFO - 2016-11-12 19:37:51 --> Output Class Initialized
INFO - 2016-11-12 19:37:51 --> Security Class Initialized
DEBUG - 2016-11-12 19:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:37:51 --> Input Class Initialized
INFO - 2016-11-12 19:37:51 --> Language Class Initialized
INFO - 2016-11-12 19:37:51 --> Loader Class Initialized
INFO - 2016-11-12 19:37:51 --> Helper loaded: url_helper
INFO - 2016-11-12 19:37:51 --> Helper loaded: form_helper
INFO - 2016-11-12 19:37:51 --> Database Driver Class Initialized
INFO - 2016-11-12 19:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:37:51 --> Controller Class Initialized
INFO - 2016-11-12 19:37:51 --> Model Class Initialized
INFO - 2016-11-12 19:37:51 --> Model Class Initialized
INFO - 2016-11-12 19:37:51 --> Model Class Initialized
INFO - 2016-11-12 19:37:51 --> Model Class Initialized
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:37:51 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:37:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:37:51 --> Final output sent to browser
DEBUG - 2016-11-12 19:37:51 --> Total execution time: 0.4319
INFO - 2016-11-12 19:38:55 --> Config Class Initialized
INFO - 2016-11-12 19:38:55 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:38:55 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:38:55 --> Utf8 Class Initialized
INFO - 2016-11-12 19:38:55 --> URI Class Initialized
DEBUG - 2016-11-12 19:38:55 --> No URI present. Default controller set.
INFO - 2016-11-12 19:38:55 --> Router Class Initialized
INFO - 2016-11-12 19:38:55 --> Output Class Initialized
INFO - 2016-11-12 19:38:55 --> Security Class Initialized
DEBUG - 2016-11-12 19:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:38:55 --> Input Class Initialized
INFO - 2016-11-12 19:38:55 --> Language Class Initialized
INFO - 2016-11-12 19:38:55 --> Loader Class Initialized
INFO - 2016-11-12 19:38:55 --> Helper loaded: url_helper
INFO - 2016-11-12 19:38:55 --> Helper loaded: form_helper
INFO - 2016-11-12 19:38:55 --> Database Driver Class Initialized
INFO - 2016-11-12 19:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:38:55 --> Controller Class Initialized
INFO - 2016-11-12 19:38:55 --> Model Class Initialized
INFO - 2016-11-12 19:38:55 --> Model Class Initialized
INFO - 2016-11-12 19:38:55 --> Model Class Initialized
INFO - 2016-11-12 19:38:55 --> Model Class Initialized
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:38:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 35
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:38:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:38:55 --> Final output sent to browser
DEBUG - 2016-11-12 19:38:55 --> Total execution time: 0.4307
INFO - 2016-11-12 19:40:47 --> Config Class Initialized
INFO - 2016-11-12 19:40:47 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:40:47 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:40:47 --> Utf8 Class Initialized
INFO - 2016-11-12 19:40:47 --> URI Class Initialized
DEBUG - 2016-11-12 19:40:47 --> No URI present. Default controller set.
INFO - 2016-11-12 19:40:47 --> Router Class Initialized
INFO - 2016-11-12 19:40:47 --> Output Class Initialized
INFO - 2016-11-12 19:40:47 --> Security Class Initialized
DEBUG - 2016-11-12 19:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:40:47 --> Input Class Initialized
INFO - 2016-11-12 19:40:47 --> Language Class Initialized
INFO - 2016-11-12 19:40:47 --> Loader Class Initialized
INFO - 2016-11-12 19:40:47 --> Helper loaded: url_helper
INFO - 2016-11-12 19:40:47 --> Helper loaded: form_helper
INFO - 2016-11-12 19:40:47 --> Database Driver Class Initialized
INFO - 2016-11-12 19:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:40:47 --> Controller Class Initialized
INFO - 2016-11-12 19:40:47 --> Model Class Initialized
INFO - 2016-11-12 19:40:47 --> Model Class Initialized
INFO - 2016-11-12 19:40:47 --> Model Class Initialized
INFO - 2016-11-12 19:40:48 --> Model Class Initialized
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:40:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 35
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:40:48 --> Final output sent to browser
DEBUG - 2016-11-12 19:40:48 --> Total execution time: 0.4754
INFO - 2016-11-12 19:41:39 --> Config Class Initialized
INFO - 2016-11-12 19:41:39 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:41:39 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:41:39 --> Utf8 Class Initialized
INFO - 2016-11-12 19:41:39 --> URI Class Initialized
DEBUG - 2016-11-12 19:41:39 --> No URI present. Default controller set.
INFO - 2016-11-12 19:41:39 --> Router Class Initialized
INFO - 2016-11-12 19:41:39 --> Output Class Initialized
INFO - 2016-11-12 19:41:39 --> Security Class Initialized
DEBUG - 2016-11-12 19:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:41:39 --> Input Class Initialized
INFO - 2016-11-12 19:41:39 --> Language Class Initialized
INFO - 2016-11-12 19:41:39 --> Loader Class Initialized
INFO - 2016-11-12 19:41:39 --> Helper loaded: url_helper
INFO - 2016-11-12 19:41:39 --> Helper loaded: form_helper
INFO - 2016-11-12 19:41:39 --> Database Driver Class Initialized
INFO - 2016-11-12 19:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:41:39 --> Controller Class Initialized
INFO - 2016-11-12 19:41:39 --> Model Class Initialized
INFO - 2016-11-12 19:41:39 --> Model Class Initialized
INFO - 2016-11-12 19:41:39 --> Model Class Initialized
INFO - 2016-11-12 19:41:39 --> Model Class Initialized
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:41:39 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 35
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:41:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:41:39 --> Final output sent to browser
DEBUG - 2016-11-12 19:41:39 --> Total execution time: 0.5582
INFO - 2016-11-12 19:43:20 --> Config Class Initialized
INFO - 2016-11-12 19:43:20 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:43:20 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:43:20 --> Utf8 Class Initialized
INFO - 2016-11-12 19:43:20 --> URI Class Initialized
DEBUG - 2016-11-12 19:43:20 --> No URI present. Default controller set.
INFO - 2016-11-12 19:43:20 --> Router Class Initialized
INFO - 2016-11-12 19:43:20 --> Output Class Initialized
INFO - 2016-11-12 19:43:20 --> Security Class Initialized
DEBUG - 2016-11-12 19:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:43:20 --> Input Class Initialized
INFO - 2016-11-12 19:43:20 --> Language Class Initialized
INFO - 2016-11-12 19:43:20 --> Loader Class Initialized
INFO - 2016-11-12 19:43:20 --> Helper loaded: url_helper
INFO - 2016-11-12 19:43:21 --> Helper loaded: form_helper
INFO - 2016-11-12 19:43:21 --> Database Driver Class Initialized
INFO - 2016-11-12 19:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:43:21 --> Controller Class Initialized
INFO - 2016-11-12 19:43:21 --> Model Class Initialized
INFO - 2016-11-12 19:43:21 --> Model Class Initialized
INFO - 2016-11-12 19:43:21 --> Model Class Initialized
INFO - 2016-11-12 19:43:21 --> Model Class Initialized
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
ERROR - 2016-11-12 19:43:21 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\LMS\app\views\manager\leave_applied.php 25
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:43:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:43:21 --> Final output sent to browser
DEBUG - 2016-11-12 19:43:21 --> Total execution time: 0.5456
INFO - 2016-11-12 19:45:10 --> Config Class Initialized
INFO - 2016-11-12 19:45:10 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:45:10 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:45:10 --> Utf8 Class Initialized
INFO - 2016-11-12 19:45:10 --> URI Class Initialized
DEBUG - 2016-11-12 19:45:10 --> No URI present. Default controller set.
INFO - 2016-11-12 19:45:10 --> Router Class Initialized
INFO - 2016-11-12 19:45:10 --> Output Class Initialized
INFO - 2016-11-12 19:45:11 --> Security Class Initialized
DEBUG - 2016-11-12 19:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:45:11 --> Input Class Initialized
INFO - 2016-11-12 19:45:11 --> Language Class Initialized
INFO - 2016-11-12 19:45:11 --> Loader Class Initialized
INFO - 2016-11-12 19:45:11 --> Helper loaded: url_helper
INFO - 2016-11-12 19:45:11 --> Helper loaded: form_helper
INFO - 2016-11-12 19:45:11 --> Database Driver Class Initialized
INFO - 2016-11-12 19:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:45:11 --> Controller Class Initialized
INFO - 2016-11-12 19:45:12 --> Model Class Initialized
INFO - 2016-11-12 19:45:12 --> Model Class Initialized
INFO - 2016-11-12 19:45:12 --> Model Class Initialized
INFO - 2016-11-12 19:45:12 --> Model Class Initialized
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:45:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:45:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:45:13 --> Final output sent to browser
DEBUG - 2016-11-12 19:45:13 --> Total execution time: 2.8998
INFO - 2016-11-12 19:45:28 --> Config Class Initialized
INFO - 2016-11-12 19:45:28 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:45:28 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:45:28 --> Utf8 Class Initialized
INFO - 2016-11-12 19:45:28 --> URI Class Initialized
DEBUG - 2016-11-12 19:45:28 --> No URI present. Default controller set.
INFO - 2016-11-12 19:45:28 --> Router Class Initialized
INFO - 2016-11-12 19:45:28 --> Output Class Initialized
INFO - 2016-11-12 19:45:28 --> Security Class Initialized
DEBUG - 2016-11-12 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:45:28 --> Input Class Initialized
INFO - 2016-11-12 19:45:28 --> Language Class Initialized
INFO - 2016-11-12 19:45:28 --> Loader Class Initialized
INFO - 2016-11-12 19:45:28 --> Helper loaded: url_helper
INFO - 2016-11-12 19:45:28 --> Helper loaded: form_helper
INFO - 2016-11-12 19:45:28 --> Database Driver Class Initialized
INFO - 2016-11-12 19:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:45:29 --> Controller Class Initialized
INFO - 2016-11-12 19:45:29 --> Model Class Initialized
INFO - 2016-11-12 19:45:29 --> Model Class Initialized
INFO - 2016-11-12 19:45:29 --> Model Class Initialized
INFO - 2016-11-12 19:45:29 --> Model Class Initialized
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:45:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:45:29 --> Final output sent to browser
DEBUG - 2016-11-12 19:45:29 --> Total execution time: 0.4928
INFO - 2016-11-12 19:46:44 --> Config Class Initialized
INFO - 2016-11-12 19:46:45 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:46:45 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:46:45 --> Utf8 Class Initialized
INFO - 2016-11-12 19:46:45 --> URI Class Initialized
DEBUG - 2016-11-12 19:46:45 --> No URI present. Default controller set.
INFO - 2016-11-12 19:46:45 --> Router Class Initialized
INFO - 2016-11-12 19:46:45 --> Output Class Initialized
INFO - 2016-11-12 19:46:45 --> Security Class Initialized
DEBUG - 2016-11-12 19:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:46:45 --> Input Class Initialized
INFO - 2016-11-12 19:46:45 --> Language Class Initialized
INFO - 2016-11-12 19:46:45 --> Loader Class Initialized
INFO - 2016-11-12 19:46:45 --> Helper loaded: url_helper
INFO - 2016-11-12 19:46:45 --> Helper loaded: form_helper
INFO - 2016-11-12 19:46:45 --> Database Driver Class Initialized
INFO - 2016-11-12 19:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:46:45 --> Controller Class Initialized
INFO - 2016-11-12 19:46:45 --> Model Class Initialized
INFO - 2016-11-12 19:46:45 --> Model Class Initialized
INFO - 2016-11-12 19:46:45 --> Model Class Initialized
INFO - 2016-11-12 19:46:45 --> Model Class Initialized
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:46:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:46:45 --> Final output sent to browser
DEBUG - 2016-11-12 19:46:45 --> Total execution time: 0.4780
INFO - 2016-11-12 19:48:43 --> Config Class Initialized
INFO - 2016-11-12 19:48:43 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:48:43 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:48:43 --> Utf8 Class Initialized
INFO - 2016-11-12 19:48:43 --> URI Class Initialized
DEBUG - 2016-11-12 19:48:43 --> No URI present. Default controller set.
INFO - 2016-11-12 19:48:43 --> Router Class Initialized
INFO - 2016-11-12 19:48:43 --> Output Class Initialized
INFO - 2016-11-12 19:48:43 --> Security Class Initialized
DEBUG - 2016-11-12 19:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:48:43 --> Input Class Initialized
INFO - 2016-11-12 19:48:43 --> Language Class Initialized
INFO - 2016-11-12 19:48:43 --> Loader Class Initialized
INFO - 2016-11-12 19:48:43 --> Helper loaded: url_helper
INFO - 2016-11-12 19:48:43 --> Helper loaded: form_helper
INFO - 2016-11-12 19:48:43 --> Database Driver Class Initialized
INFO - 2016-11-12 19:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:48:43 --> Controller Class Initialized
INFO - 2016-11-12 19:48:43 --> Model Class Initialized
INFO - 2016-11-12 19:48:43 --> Model Class Initialized
INFO - 2016-11-12 19:48:43 --> Model Class Initialized
INFO - 2016-11-12 19:48:43 --> Model Class Initialized
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:48:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:48:43 --> Final output sent to browser
DEBUG - 2016-11-12 19:48:43 --> Total execution time: 0.6629
INFO - 2016-11-12 19:50:16 --> Config Class Initialized
INFO - 2016-11-12 19:50:16 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:50:16 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:50:16 --> Utf8 Class Initialized
INFO - 2016-11-12 19:50:16 --> URI Class Initialized
DEBUG - 2016-11-12 19:50:16 --> No URI present. Default controller set.
INFO - 2016-11-12 19:50:16 --> Router Class Initialized
INFO - 2016-11-12 19:50:16 --> Output Class Initialized
INFO - 2016-11-12 19:50:17 --> Security Class Initialized
DEBUG - 2016-11-12 19:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:50:17 --> Input Class Initialized
INFO - 2016-11-12 19:50:17 --> Language Class Initialized
INFO - 2016-11-12 19:50:17 --> Loader Class Initialized
INFO - 2016-11-12 19:50:17 --> Helper loaded: url_helper
INFO - 2016-11-12 19:50:17 --> Helper loaded: form_helper
INFO - 2016-11-12 19:50:17 --> Database Driver Class Initialized
INFO - 2016-11-12 19:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:50:17 --> Controller Class Initialized
INFO - 2016-11-12 19:50:17 --> Model Class Initialized
INFO - 2016-11-12 19:50:17 --> Model Class Initialized
INFO - 2016-11-12 19:50:17 --> Model Class Initialized
INFO - 2016-11-12 19:50:17 --> Model Class Initialized
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:50:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:50:17 --> Final output sent to browser
DEBUG - 2016-11-12 19:50:17 --> Total execution time: 0.7148
INFO - 2016-11-12 19:51:39 --> Config Class Initialized
INFO - 2016-11-12 19:51:39 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:51:39 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:51:39 --> Utf8 Class Initialized
INFO - 2016-11-12 19:51:39 --> URI Class Initialized
DEBUG - 2016-11-12 19:51:39 --> No URI present. Default controller set.
INFO - 2016-11-12 19:51:39 --> Router Class Initialized
INFO - 2016-11-12 19:51:39 --> Output Class Initialized
INFO - 2016-11-12 19:51:39 --> Security Class Initialized
DEBUG - 2016-11-12 19:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:51:39 --> Input Class Initialized
INFO - 2016-11-12 19:51:39 --> Language Class Initialized
INFO - 2016-11-12 19:51:39 --> Loader Class Initialized
INFO - 2016-11-12 19:51:39 --> Helper loaded: url_helper
INFO - 2016-11-12 19:51:39 --> Helper loaded: form_helper
INFO - 2016-11-12 19:51:39 --> Database Driver Class Initialized
INFO - 2016-11-12 19:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:51:39 --> Controller Class Initialized
INFO - 2016-11-12 19:51:39 --> Model Class Initialized
INFO - 2016-11-12 19:51:39 --> Model Class Initialized
INFO - 2016-11-12 19:51:39 --> Model Class Initialized
INFO - 2016-11-12 19:51:39 --> Model Class Initialized
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:51:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:51:39 --> Final output sent to browser
DEBUG - 2016-11-12 19:51:39 --> Total execution time: 0.4971
INFO - 2016-11-12 19:52:14 --> Config Class Initialized
INFO - 2016-11-12 19:52:14 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:52:14 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:52:14 --> Utf8 Class Initialized
INFO - 2016-11-12 19:52:14 --> URI Class Initialized
DEBUG - 2016-11-12 19:52:14 --> No URI present. Default controller set.
INFO - 2016-11-12 19:52:14 --> Router Class Initialized
INFO - 2016-11-12 19:52:14 --> Output Class Initialized
INFO - 2016-11-12 19:52:14 --> Security Class Initialized
DEBUG - 2016-11-12 19:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:52:14 --> Input Class Initialized
INFO - 2016-11-12 19:52:14 --> Language Class Initialized
INFO - 2016-11-12 19:52:14 --> Loader Class Initialized
INFO - 2016-11-12 19:52:14 --> Helper loaded: url_helper
INFO - 2016-11-12 19:52:14 --> Helper loaded: form_helper
INFO - 2016-11-12 19:52:14 --> Database Driver Class Initialized
INFO - 2016-11-12 19:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:52:14 --> Controller Class Initialized
INFO - 2016-11-12 19:52:14 --> Model Class Initialized
INFO - 2016-11-12 19:52:14 --> Model Class Initialized
INFO - 2016-11-12 19:52:14 --> Model Class Initialized
INFO - 2016-11-12 19:52:14 --> Model Class Initialized
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:52:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:52:14 --> Final output sent to browser
DEBUG - 2016-11-12 19:52:14 --> Total execution time: 0.7052
INFO - 2016-11-12 19:53:05 --> Config Class Initialized
INFO - 2016-11-12 19:53:05 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:53:05 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:53:05 --> Utf8 Class Initialized
INFO - 2016-11-12 19:53:05 --> URI Class Initialized
DEBUG - 2016-11-12 19:53:05 --> No URI present. Default controller set.
INFO - 2016-11-12 19:53:05 --> Router Class Initialized
INFO - 2016-11-12 19:53:05 --> Output Class Initialized
INFO - 2016-11-12 19:53:05 --> Security Class Initialized
DEBUG - 2016-11-12 19:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:53:05 --> Input Class Initialized
INFO - 2016-11-12 19:53:05 --> Language Class Initialized
INFO - 2016-11-12 19:53:05 --> Loader Class Initialized
INFO - 2016-11-12 19:53:05 --> Helper loaded: url_helper
INFO - 2016-11-12 19:53:05 --> Helper loaded: form_helper
INFO - 2016-11-12 19:53:05 --> Database Driver Class Initialized
INFO - 2016-11-12 19:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:53:05 --> Controller Class Initialized
INFO - 2016-11-12 19:53:05 --> Model Class Initialized
INFO - 2016-11-12 19:53:05 --> Model Class Initialized
INFO - 2016-11-12 19:53:05 --> Model Class Initialized
INFO - 2016-11-12 19:53:05 --> Model Class Initialized
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:53:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:53:06 --> Final output sent to browser
DEBUG - 2016-11-12 19:53:06 --> Total execution time: 0.5433
INFO - 2016-11-12 19:54:04 --> Config Class Initialized
INFO - 2016-11-12 19:54:04 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:54:04 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:54:04 --> Utf8 Class Initialized
INFO - 2016-11-12 19:54:04 --> URI Class Initialized
DEBUG - 2016-11-12 19:54:04 --> No URI present. Default controller set.
INFO - 2016-11-12 19:54:04 --> Router Class Initialized
INFO - 2016-11-12 19:54:04 --> Output Class Initialized
INFO - 2016-11-12 19:54:04 --> Security Class Initialized
DEBUG - 2016-11-12 19:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:54:04 --> Input Class Initialized
INFO - 2016-11-12 19:54:04 --> Language Class Initialized
INFO - 2016-11-12 19:54:04 --> Loader Class Initialized
INFO - 2016-11-12 19:54:04 --> Helper loaded: url_helper
INFO - 2016-11-12 19:54:04 --> Helper loaded: form_helper
INFO - 2016-11-12 19:54:04 --> Database Driver Class Initialized
INFO - 2016-11-12 19:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:54:04 --> Controller Class Initialized
INFO - 2016-11-12 19:54:04 --> Model Class Initialized
INFO - 2016-11-12 19:54:04 --> Model Class Initialized
INFO - 2016-11-12 19:54:04 --> Model Class Initialized
INFO - 2016-11-12 19:54:04 --> Model Class Initialized
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:54:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:54:04 --> Final output sent to browser
DEBUG - 2016-11-12 19:54:04 --> Total execution time: 0.4852
INFO - 2016-11-12 19:54:48 --> Config Class Initialized
INFO - 2016-11-12 19:54:48 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:54:48 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:54:48 --> Utf8 Class Initialized
INFO - 2016-11-12 19:54:48 --> URI Class Initialized
DEBUG - 2016-11-12 19:54:48 --> No URI present. Default controller set.
INFO - 2016-11-12 19:54:48 --> Router Class Initialized
INFO - 2016-11-12 19:54:48 --> Output Class Initialized
INFO - 2016-11-12 19:54:48 --> Security Class Initialized
DEBUG - 2016-11-12 19:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:54:48 --> Input Class Initialized
INFO - 2016-11-12 19:54:48 --> Language Class Initialized
INFO - 2016-11-12 19:54:48 --> Loader Class Initialized
INFO - 2016-11-12 19:54:48 --> Helper loaded: url_helper
INFO - 2016-11-12 19:54:48 --> Helper loaded: form_helper
INFO - 2016-11-12 19:54:48 --> Database Driver Class Initialized
INFO - 2016-11-12 19:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:54:48 --> Controller Class Initialized
INFO - 2016-11-12 19:54:48 --> Model Class Initialized
INFO - 2016-11-12 19:54:48 --> Model Class Initialized
INFO - 2016-11-12 19:54:48 --> Model Class Initialized
INFO - 2016-11-12 19:54:48 --> Model Class Initialized
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:54:48 --> Final output sent to browser
DEBUG - 2016-11-12 19:54:48 --> Total execution time: 0.4749
INFO - 2016-11-12 19:55:10 --> Config Class Initialized
INFO - 2016-11-12 19:55:10 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:55:10 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:55:10 --> Utf8 Class Initialized
INFO - 2016-11-12 19:55:10 --> URI Class Initialized
DEBUG - 2016-11-12 19:55:10 --> No URI present. Default controller set.
INFO - 2016-11-12 19:55:10 --> Router Class Initialized
INFO - 2016-11-12 19:55:10 --> Output Class Initialized
INFO - 2016-11-12 19:55:10 --> Security Class Initialized
DEBUG - 2016-11-12 19:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:55:10 --> Input Class Initialized
INFO - 2016-11-12 19:55:10 --> Language Class Initialized
INFO - 2016-11-12 19:55:10 --> Loader Class Initialized
INFO - 2016-11-12 19:55:10 --> Helper loaded: url_helper
INFO - 2016-11-12 19:55:10 --> Helper loaded: form_helper
INFO - 2016-11-12 19:55:10 --> Database Driver Class Initialized
INFO - 2016-11-12 19:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:55:10 --> Controller Class Initialized
INFO - 2016-11-12 19:55:10 --> Model Class Initialized
INFO - 2016-11-12 19:55:10 --> Model Class Initialized
INFO - 2016-11-12 19:55:10 --> Model Class Initialized
INFO - 2016-11-12 19:55:10 --> Model Class Initialized
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:55:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:55:10 --> Final output sent to browser
DEBUG - 2016-11-12 19:55:10 --> Total execution time: 0.4973
INFO - 2016-11-12 19:55:37 --> Config Class Initialized
INFO - 2016-11-12 19:55:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:55:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:55:37 --> Utf8 Class Initialized
INFO - 2016-11-12 19:55:37 --> URI Class Initialized
DEBUG - 2016-11-12 19:55:37 --> No URI present. Default controller set.
INFO - 2016-11-12 19:55:37 --> Router Class Initialized
INFO - 2016-11-12 19:55:37 --> Output Class Initialized
INFO - 2016-11-12 19:55:37 --> Security Class Initialized
DEBUG - 2016-11-12 19:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:55:37 --> Input Class Initialized
INFO - 2016-11-12 19:55:37 --> Language Class Initialized
INFO - 2016-11-12 19:55:37 --> Loader Class Initialized
INFO - 2016-11-12 19:55:37 --> Helper loaded: url_helper
INFO - 2016-11-12 19:55:37 --> Helper loaded: form_helper
INFO - 2016-11-12 19:55:37 --> Database Driver Class Initialized
INFO - 2016-11-12 19:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:55:37 --> Controller Class Initialized
INFO - 2016-11-12 19:55:37 --> Model Class Initialized
INFO - 2016-11-12 19:55:37 --> Model Class Initialized
INFO - 2016-11-12 19:55:37 --> Model Class Initialized
INFO - 2016-11-12 19:55:37 --> Model Class Initialized
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:55:37 --> Final output sent to browser
DEBUG - 2016-11-12 19:55:37 --> Total execution time: 0.4671
INFO - 2016-11-12 19:55:55 --> Config Class Initialized
INFO - 2016-11-12 19:55:55 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:55:55 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:55:55 --> Utf8 Class Initialized
INFO - 2016-11-12 19:55:55 --> URI Class Initialized
DEBUG - 2016-11-12 19:55:55 --> No URI present. Default controller set.
INFO - 2016-11-12 19:55:55 --> Router Class Initialized
INFO - 2016-11-12 19:55:55 --> Output Class Initialized
INFO - 2016-11-12 19:55:55 --> Security Class Initialized
DEBUG - 2016-11-12 19:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:55:55 --> Input Class Initialized
INFO - 2016-11-12 19:55:55 --> Language Class Initialized
INFO - 2016-11-12 19:55:55 --> Loader Class Initialized
INFO - 2016-11-12 19:55:55 --> Helper loaded: url_helper
INFO - 2016-11-12 19:55:55 --> Helper loaded: form_helper
INFO - 2016-11-12 19:55:55 --> Database Driver Class Initialized
INFO - 2016-11-12 19:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:55:55 --> Controller Class Initialized
INFO - 2016-11-12 19:55:55 --> Model Class Initialized
INFO - 2016-11-12 19:55:55 --> Model Class Initialized
INFO - 2016-11-12 19:55:55 --> Model Class Initialized
INFO - 2016-11-12 19:55:55 --> Model Class Initialized
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:55:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:55:55 --> Final output sent to browser
DEBUG - 2016-11-12 19:55:55 --> Total execution time: 0.4621
INFO - 2016-11-12 19:56:26 --> Config Class Initialized
INFO - 2016-11-12 19:56:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:56:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:56:27 --> Utf8 Class Initialized
INFO - 2016-11-12 19:56:27 --> URI Class Initialized
DEBUG - 2016-11-12 19:56:27 --> No URI present. Default controller set.
INFO - 2016-11-12 19:56:27 --> Router Class Initialized
INFO - 2016-11-12 19:56:27 --> Output Class Initialized
INFO - 2016-11-12 19:56:27 --> Security Class Initialized
DEBUG - 2016-11-12 19:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:56:27 --> Input Class Initialized
INFO - 2016-11-12 19:56:27 --> Language Class Initialized
INFO - 2016-11-12 19:56:27 --> Loader Class Initialized
INFO - 2016-11-12 19:56:27 --> Helper loaded: url_helper
INFO - 2016-11-12 19:56:27 --> Helper loaded: form_helper
INFO - 2016-11-12 19:56:27 --> Database Driver Class Initialized
INFO - 2016-11-12 19:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:56:27 --> Controller Class Initialized
INFO - 2016-11-12 19:56:27 --> Model Class Initialized
INFO - 2016-11-12 19:56:27 --> Model Class Initialized
INFO - 2016-11-12 19:56:27 --> Model Class Initialized
INFO - 2016-11-12 19:56:27 --> Model Class Initialized
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:56:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:56:27 --> Final output sent to browser
DEBUG - 2016-11-12 19:56:27 --> Total execution time: 0.4286
INFO - 2016-11-12 19:57:23 --> Config Class Initialized
INFO - 2016-11-12 19:57:23 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:57:23 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:57:23 --> Utf8 Class Initialized
INFO - 2016-11-12 19:57:23 --> URI Class Initialized
DEBUG - 2016-11-12 19:57:23 --> No URI present. Default controller set.
INFO - 2016-11-12 19:57:23 --> Router Class Initialized
INFO - 2016-11-12 19:57:23 --> Output Class Initialized
INFO - 2016-11-12 19:57:23 --> Security Class Initialized
DEBUG - 2016-11-12 19:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:57:23 --> Input Class Initialized
INFO - 2016-11-12 19:57:23 --> Language Class Initialized
INFO - 2016-11-12 19:57:23 --> Loader Class Initialized
INFO - 2016-11-12 19:57:23 --> Helper loaded: url_helper
INFO - 2016-11-12 19:57:23 --> Helper loaded: form_helper
INFO - 2016-11-12 19:57:23 --> Database Driver Class Initialized
INFO - 2016-11-12 19:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:57:23 --> Controller Class Initialized
INFO - 2016-11-12 19:57:23 --> Model Class Initialized
INFO - 2016-11-12 19:57:23 --> Model Class Initialized
INFO - 2016-11-12 19:57:23 --> Model Class Initialized
INFO - 2016-11-12 19:57:23 --> Model Class Initialized
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:57:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:57:23 --> Final output sent to browser
DEBUG - 2016-11-12 19:57:23 --> Total execution time: 0.4581
INFO - 2016-11-12 19:58:20 --> Config Class Initialized
INFO - 2016-11-12 19:58:20 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:58:20 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:58:20 --> Utf8 Class Initialized
INFO - 2016-11-12 19:58:20 --> URI Class Initialized
DEBUG - 2016-11-12 19:58:20 --> No URI present. Default controller set.
INFO - 2016-11-12 19:58:20 --> Router Class Initialized
INFO - 2016-11-12 19:58:20 --> Output Class Initialized
INFO - 2016-11-12 19:58:20 --> Security Class Initialized
DEBUG - 2016-11-12 19:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:58:20 --> Input Class Initialized
INFO - 2016-11-12 19:58:20 --> Language Class Initialized
INFO - 2016-11-12 19:58:20 --> Loader Class Initialized
INFO - 2016-11-12 19:58:20 --> Helper loaded: url_helper
INFO - 2016-11-12 19:58:20 --> Helper loaded: form_helper
INFO - 2016-11-12 19:58:20 --> Database Driver Class Initialized
INFO - 2016-11-12 19:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:58:20 --> Controller Class Initialized
INFO - 2016-11-12 19:58:20 --> Model Class Initialized
INFO - 2016-11-12 19:58:20 --> Model Class Initialized
INFO - 2016-11-12 19:58:20 --> Model Class Initialized
INFO - 2016-11-12 19:58:20 --> Model Class Initialized
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:58:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:58:20 --> Final output sent to browser
DEBUG - 2016-11-12 19:58:20 --> Total execution time: 0.5063
INFO - 2016-11-12 19:58:45 --> Config Class Initialized
INFO - 2016-11-12 19:58:45 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:58:45 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:58:45 --> Utf8 Class Initialized
INFO - 2016-11-12 19:58:45 --> URI Class Initialized
DEBUG - 2016-11-12 19:58:45 --> No URI present. Default controller set.
INFO - 2016-11-12 19:58:45 --> Router Class Initialized
INFO - 2016-11-12 19:58:45 --> Output Class Initialized
INFO - 2016-11-12 19:58:46 --> Security Class Initialized
DEBUG - 2016-11-12 19:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:58:46 --> Input Class Initialized
INFO - 2016-11-12 19:58:46 --> Language Class Initialized
INFO - 2016-11-12 19:58:46 --> Loader Class Initialized
INFO - 2016-11-12 19:58:46 --> Helper loaded: url_helper
INFO - 2016-11-12 19:58:46 --> Helper loaded: form_helper
INFO - 2016-11-12 19:58:46 --> Database Driver Class Initialized
INFO - 2016-11-12 19:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:58:46 --> Controller Class Initialized
INFO - 2016-11-12 19:58:46 --> Model Class Initialized
INFO - 2016-11-12 19:58:46 --> Model Class Initialized
INFO - 2016-11-12 19:58:46 --> Model Class Initialized
INFO - 2016-11-12 19:58:46 --> Model Class Initialized
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:58:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:58:46 --> Final output sent to browser
DEBUG - 2016-11-12 19:58:46 --> Total execution time: 0.4498
INFO - 2016-11-12 19:59:34 --> Config Class Initialized
INFO - 2016-11-12 19:59:35 --> Hooks Class Initialized
DEBUG - 2016-11-12 19:59:35 --> UTF-8 Support Enabled
INFO - 2016-11-12 19:59:35 --> Utf8 Class Initialized
INFO - 2016-11-12 19:59:35 --> URI Class Initialized
DEBUG - 2016-11-12 19:59:35 --> No URI present. Default controller set.
INFO - 2016-11-12 19:59:35 --> Router Class Initialized
INFO - 2016-11-12 19:59:35 --> Output Class Initialized
INFO - 2016-11-12 19:59:35 --> Security Class Initialized
DEBUG - 2016-11-12 19:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 19:59:35 --> Input Class Initialized
INFO - 2016-11-12 19:59:35 --> Language Class Initialized
INFO - 2016-11-12 19:59:35 --> Loader Class Initialized
INFO - 2016-11-12 19:59:35 --> Helper loaded: url_helper
INFO - 2016-11-12 19:59:35 --> Helper loaded: form_helper
INFO - 2016-11-12 19:59:35 --> Database Driver Class Initialized
INFO - 2016-11-12 19:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 19:59:35 --> Controller Class Initialized
INFO - 2016-11-12 19:59:35 --> Model Class Initialized
INFO - 2016-11-12 19:59:35 --> Model Class Initialized
INFO - 2016-11-12 19:59:35 --> Model Class Initialized
INFO - 2016-11-12 19:59:35 --> Model Class Initialized
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 19:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 19:59:35 --> Final output sent to browser
DEBUG - 2016-11-12 19:59:35 --> Total execution time: 0.5003
INFO - 2016-11-12 20:00:49 --> Config Class Initialized
INFO - 2016-11-12 20:00:49 --> Hooks Class Initialized
DEBUG - 2016-11-12 20:00:49 --> UTF-8 Support Enabled
INFO - 2016-11-12 20:00:49 --> Utf8 Class Initialized
INFO - 2016-11-12 20:00:49 --> URI Class Initialized
DEBUG - 2016-11-12 20:00:49 --> No URI present. Default controller set.
INFO - 2016-11-12 20:00:49 --> Router Class Initialized
INFO - 2016-11-12 20:00:49 --> Output Class Initialized
INFO - 2016-11-12 20:00:49 --> Security Class Initialized
DEBUG - 2016-11-12 20:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 20:00:49 --> Input Class Initialized
INFO - 2016-11-12 20:00:49 --> Language Class Initialized
INFO - 2016-11-12 20:00:49 --> Loader Class Initialized
INFO - 2016-11-12 20:00:49 --> Helper loaded: url_helper
INFO - 2016-11-12 20:00:49 --> Helper loaded: form_helper
INFO - 2016-11-12 20:00:49 --> Database Driver Class Initialized
INFO - 2016-11-12 20:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 20:00:49 --> Controller Class Initialized
INFO - 2016-11-12 20:00:49 --> Model Class Initialized
INFO - 2016-11-12 20:00:49 --> Model Class Initialized
INFO - 2016-11-12 20:00:49 --> Model Class Initialized
INFO - 2016-11-12 20:00:49 --> Model Class Initialized
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 20:00:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 20:00:49 --> Final output sent to browser
DEBUG - 2016-11-12 20:00:49 --> Total execution time: 0.5142
INFO - 2016-11-12 20:03:29 --> Config Class Initialized
INFO - 2016-11-12 20:03:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 20:03:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 20:03:29 --> Utf8 Class Initialized
INFO - 2016-11-12 20:03:29 --> URI Class Initialized
DEBUG - 2016-11-12 20:03:29 --> No URI present. Default controller set.
INFO - 2016-11-12 20:03:29 --> Router Class Initialized
INFO - 2016-11-12 20:03:29 --> Output Class Initialized
INFO - 2016-11-12 20:03:29 --> Security Class Initialized
DEBUG - 2016-11-12 20:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 20:03:29 --> Input Class Initialized
INFO - 2016-11-12 20:03:29 --> Language Class Initialized
INFO - 2016-11-12 20:03:29 --> Loader Class Initialized
INFO - 2016-11-12 20:03:29 --> Helper loaded: url_helper
INFO - 2016-11-12 20:03:29 --> Helper loaded: form_helper
INFO - 2016-11-12 20:03:29 --> Database Driver Class Initialized
INFO - 2016-11-12 20:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 20:03:30 --> Controller Class Initialized
INFO - 2016-11-12 20:03:30 --> Model Class Initialized
INFO - 2016-11-12 20:03:30 --> Model Class Initialized
INFO - 2016-11-12 20:03:30 --> Model Class Initialized
INFO - 2016-11-12 20:03:30 --> Model Class Initialized
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 20:03:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 20:03:30 --> Final output sent to browser
DEBUG - 2016-11-12 20:03:30 --> Total execution time: 0.4782
INFO - 2016-11-12 21:59:29 --> Config Class Initialized
INFO - 2016-11-12 21:59:30 --> Hooks Class Initialized
DEBUG - 2016-11-12 21:59:30 --> UTF-8 Support Enabled
INFO - 2016-11-12 21:59:30 --> Utf8 Class Initialized
INFO - 2016-11-12 21:59:30 --> URI Class Initialized
DEBUG - 2016-11-12 21:59:30 --> No URI present. Default controller set.
INFO - 2016-11-12 21:59:30 --> Router Class Initialized
INFO - 2016-11-12 21:59:30 --> Output Class Initialized
INFO - 2016-11-12 21:59:30 --> Security Class Initialized
DEBUG - 2016-11-12 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 21:59:31 --> Input Class Initialized
INFO - 2016-11-12 21:59:31 --> Language Class Initialized
INFO - 2016-11-12 21:59:31 --> Loader Class Initialized
INFO - 2016-11-12 21:59:31 --> Helper loaded: url_helper
INFO - 2016-11-12 21:59:31 --> Helper loaded: form_helper
INFO - 2016-11-12 21:59:31 --> Database Driver Class Initialized
INFO - 2016-11-12 21:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 21:59:31 --> Controller Class Initialized
INFO - 2016-11-12 21:59:31 --> Model Class Initialized
INFO - 2016-11-12 21:59:31 --> Model Class Initialized
INFO - 2016-11-12 21:59:31 --> Model Class Initialized
INFO - 2016-11-12 21:59:31 --> Model Class Initialized
INFO - 2016-11-12 21:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 21:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 21:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 21:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 21:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 21:59:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 21:59:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 21:59:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 21:59:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 21:59:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 21:59:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 21:59:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 21:59:32 --> Final output sent to browser
DEBUG - 2016-11-12 21:59:32 --> Total execution time: 2.3005
INFO - 2016-11-12 22:12:15 --> Config Class Initialized
INFO - 2016-11-12 22:12:16 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:12:16 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:12:16 --> Utf8 Class Initialized
INFO - 2016-11-12 22:12:16 --> URI Class Initialized
DEBUG - 2016-11-12 22:12:16 --> No URI present. Default controller set.
INFO - 2016-11-12 22:12:16 --> Router Class Initialized
INFO - 2016-11-12 22:12:16 --> Output Class Initialized
INFO - 2016-11-12 22:12:16 --> Security Class Initialized
DEBUG - 2016-11-12 22:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:12:16 --> Input Class Initialized
INFO - 2016-11-12 22:12:16 --> Language Class Initialized
INFO - 2016-11-12 22:12:16 --> Loader Class Initialized
INFO - 2016-11-12 22:12:16 --> Helper loaded: url_helper
INFO - 2016-11-12 22:12:16 --> Helper loaded: form_helper
INFO - 2016-11-12 22:12:16 --> Database Driver Class Initialized
INFO - 2016-11-12 22:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:12:16 --> Controller Class Initialized
INFO - 2016-11-12 22:12:16 --> Model Class Initialized
INFO - 2016-11-12 22:12:16 --> Model Class Initialized
INFO - 2016-11-12 22:12:16 --> Model Class Initialized
INFO - 2016-11-12 22:12:16 --> Model Class Initialized
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:12:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:12:16 --> Final output sent to browser
DEBUG - 2016-11-12 22:12:16 --> Total execution time: 0.7799
INFO - 2016-11-12 22:13:07 --> Config Class Initialized
INFO - 2016-11-12 22:13:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:13:08 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:13:08 --> Utf8 Class Initialized
INFO - 2016-11-12 22:13:08 --> URI Class Initialized
DEBUG - 2016-11-12 22:13:09 --> No URI present. Default controller set.
INFO - 2016-11-12 22:13:09 --> Router Class Initialized
INFO - 2016-11-12 22:13:09 --> Output Class Initialized
INFO - 2016-11-12 22:13:09 --> Security Class Initialized
DEBUG - 2016-11-12 22:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:13:09 --> Input Class Initialized
INFO - 2016-11-12 22:13:09 --> Language Class Initialized
INFO - 2016-11-12 22:13:09 --> Loader Class Initialized
INFO - 2016-11-12 22:13:09 --> Helper loaded: url_helper
INFO - 2016-11-12 22:13:09 --> Helper loaded: form_helper
INFO - 2016-11-12 22:13:09 --> Database Driver Class Initialized
INFO - 2016-11-12 22:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:13:09 --> Controller Class Initialized
INFO - 2016-11-12 22:13:09 --> Model Class Initialized
INFO - 2016-11-12 22:13:09 --> Model Class Initialized
INFO - 2016-11-12 22:13:09 --> Model Class Initialized
INFO - 2016-11-12 22:13:09 --> Model Class Initialized
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:13:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:13:09 --> Final output sent to browser
DEBUG - 2016-11-12 22:13:09 --> Total execution time: 1.6422
INFO - 2016-11-12 22:18:37 --> Config Class Initialized
INFO - 2016-11-12 22:18:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:18:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:18:37 --> Utf8 Class Initialized
INFO - 2016-11-12 22:18:37 --> URI Class Initialized
DEBUG - 2016-11-12 22:18:37 --> No URI present. Default controller set.
INFO - 2016-11-12 22:18:37 --> Router Class Initialized
INFO - 2016-11-12 22:18:37 --> Output Class Initialized
INFO - 2016-11-12 22:18:37 --> Security Class Initialized
DEBUG - 2016-11-12 22:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:18:37 --> Input Class Initialized
INFO - 2016-11-12 22:18:37 --> Language Class Initialized
INFO - 2016-11-12 22:18:37 --> Loader Class Initialized
INFO - 2016-11-12 22:18:37 --> Helper loaded: url_helper
INFO - 2016-11-12 22:18:37 --> Helper loaded: form_helper
INFO - 2016-11-12 22:18:37 --> Database Driver Class Initialized
INFO - 2016-11-12 22:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:18:37 --> Controller Class Initialized
INFO - 2016-11-12 22:18:37 --> Model Class Initialized
INFO - 2016-11-12 22:18:37 --> Model Class Initialized
INFO - 2016-11-12 22:18:37 --> Model Class Initialized
INFO - 2016-11-12 22:18:37 --> Model Class Initialized
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:18:37 --> Final output sent to browser
DEBUG - 2016-11-12 22:18:37 --> Total execution time: 0.4766
INFO - 2016-11-12 22:24:34 --> Config Class Initialized
INFO - 2016-11-12 22:24:34 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:24:34 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:24:34 --> Utf8 Class Initialized
INFO - 2016-11-12 22:24:34 --> URI Class Initialized
DEBUG - 2016-11-12 22:24:34 --> No URI present. Default controller set.
INFO - 2016-11-12 22:24:34 --> Router Class Initialized
INFO - 2016-11-12 22:24:34 --> Output Class Initialized
INFO - 2016-11-12 22:24:34 --> Security Class Initialized
DEBUG - 2016-11-12 22:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:24:34 --> Input Class Initialized
INFO - 2016-11-12 22:24:34 --> Language Class Initialized
INFO - 2016-11-12 22:24:34 --> Loader Class Initialized
INFO - 2016-11-12 22:24:34 --> Helper loaded: url_helper
INFO - 2016-11-12 22:24:34 --> Helper loaded: form_helper
INFO - 2016-11-12 22:24:34 --> Database Driver Class Initialized
INFO - 2016-11-12 22:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:24:34 --> Controller Class Initialized
INFO - 2016-11-12 22:24:34 --> Model Class Initialized
INFO - 2016-11-12 22:24:34 --> Model Class Initialized
INFO - 2016-11-12 22:24:34 --> Model Class Initialized
INFO - 2016-11-12 22:24:34 --> Model Class Initialized
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:24:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:24:34 --> Final output sent to browser
DEBUG - 2016-11-12 22:24:34 --> Total execution time: 0.4561
INFO - 2016-11-12 22:26:03 --> Config Class Initialized
INFO - 2016-11-12 22:26:03 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:26:03 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:26:03 --> Utf8 Class Initialized
INFO - 2016-11-12 22:26:03 --> URI Class Initialized
DEBUG - 2016-11-12 22:26:03 --> No URI present. Default controller set.
INFO - 2016-11-12 22:26:03 --> Router Class Initialized
INFO - 2016-11-12 22:26:03 --> Output Class Initialized
INFO - 2016-11-12 22:26:03 --> Security Class Initialized
DEBUG - 2016-11-12 22:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:26:03 --> Input Class Initialized
INFO - 2016-11-12 22:26:03 --> Language Class Initialized
INFO - 2016-11-12 22:26:03 --> Loader Class Initialized
INFO - 2016-11-12 22:26:03 --> Helper loaded: url_helper
INFO - 2016-11-12 22:26:03 --> Helper loaded: form_helper
INFO - 2016-11-12 22:26:03 --> Database Driver Class Initialized
INFO - 2016-11-12 22:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:26:03 --> Controller Class Initialized
INFO - 2016-11-12 22:26:03 --> Model Class Initialized
INFO - 2016-11-12 22:26:03 --> Model Class Initialized
INFO - 2016-11-12 22:26:03 --> Model Class Initialized
INFO - 2016-11-12 22:26:03 --> Model Class Initialized
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:26:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:26:03 --> Final output sent to browser
DEBUG - 2016-11-12 22:26:03 --> Total execution time: 0.4814
INFO - 2016-11-12 22:28:06 --> Config Class Initialized
INFO - 2016-11-12 22:28:06 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:28:06 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:28:06 --> Utf8 Class Initialized
INFO - 2016-11-12 22:28:06 --> URI Class Initialized
DEBUG - 2016-11-12 22:28:06 --> No URI present. Default controller set.
INFO - 2016-11-12 22:28:06 --> Router Class Initialized
INFO - 2016-11-12 22:28:06 --> Output Class Initialized
INFO - 2016-11-12 22:28:06 --> Security Class Initialized
DEBUG - 2016-11-12 22:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:28:06 --> Input Class Initialized
INFO - 2016-11-12 22:28:06 --> Language Class Initialized
INFO - 2016-11-12 22:28:06 --> Loader Class Initialized
INFO - 2016-11-12 22:28:06 --> Helper loaded: url_helper
INFO - 2016-11-12 22:28:06 --> Helper loaded: form_helper
INFO - 2016-11-12 22:28:06 --> Database Driver Class Initialized
INFO - 2016-11-12 22:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:28:06 --> Controller Class Initialized
INFO - 2016-11-12 22:28:06 --> Model Class Initialized
INFO - 2016-11-12 22:28:06 --> Model Class Initialized
INFO - 2016-11-12 22:28:06 --> Model Class Initialized
INFO - 2016-11-12 22:28:06 --> Model Class Initialized
INFO - 2016-11-12 22:28:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:28:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:28:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:28:07 --> Final output sent to browser
DEBUG - 2016-11-12 22:28:07 --> Total execution time: 0.7078
INFO - 2016-11-12 22:35:06 --> Config Class Initialized
INFO - 2016-11-12 22:35:07 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:35:07 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:35:07 --> Utf8 Class Initialized
INFO - 2016-11-12 22:35:07 --> URI Class Initialized
DEBUG - 2016-11-12 22:35:07 --> No URI present. Default controller set.
INFO - 2016-11-12 22:35:07 --> Router Class Initialized
INFO - 2016-11-12 22:35:07 --> Output Class Initialized
INFO - 2016-11-12 22:35:07 --> Security Class Initialized
DEBUG - 2016-11-12 22:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:35:07 --> Input Class Initialized
INFO - 2016-11-12 22:35:07 --> Language Class Initialized
INFO - 2016-11-12 22:35:07 --> Loader Class Initialized
INFO - 2016-11-12 22:35:07 --> Helper loaded: url_helper
INFO - 2016-11-12 22:35:07 --> Helper loaded: form_helper
INFO - 2016-11-12 22:35:07 --> Database Driver Class Initialized
INFO - 2016-11-12 22:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:35:07 --> Controller Class Initialized
INFO - 2016-11-12 22:35:07 --> Model Class Initialized
INFO - 2016-11-12 22:35:07 --> Model Class Initialized
INFO - 2016-11-12 22:35:07 --> Model Class Initialized
INFO - 2016-11-12 22:35:07 --> Model Class Initialized
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:35:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:35:07 --> Final output sent to browser
DEBUG - 2016-11-12 22:35:07 --> Total execution time: 0.7076
INFO - 2016-11-12 22:36:18 --> Config Class Initialized
INFO - 2016-11-12 22:36:18 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:18 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:18 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:18 --> URI Class Initialized
DEBUG - 2016-11-12 22:36:18 --> No URI present. Default controller set.
INFO - 2016-11-12 22:36:18 --> Router Class Initialized
INFO - 2016-11-12 22:36:18 --> Output Class Initialized
INFO - 2016-11-12 22:36:18 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:18 --> Input Class Initialized
INFO - 2016-11-12 22:36:18 --> Language Class Initialized
INFO - 2016-11-12 22:36:18 --> Loader Class Initialized
INFO - 2016-11-12 22:36:18 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:18 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:18 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:18 --> Controller Class Initialized
INFO - 2016-11-12 22:36:18 --> Model Class Initialized
INFO - 2016-11-12 22:36:18 --> Model Class Initialized
INFO - 2016-11-12 22:36:18 --> Model Class Initialized
INFO - 2016-11-12 22:36:18 --> Model Class Initialized
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:36:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:36:18 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:18 --> Total execution time: 0.5009
INFO - 2016-11-12 22:36:27 --> Config Class Initialized
INFO - 2016-11-12 22:36:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:27 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:27 --> URI Class Initialized
DEBUG - 2016-11-12 22:36:27 --> No URI present. Default controller set.
INFO - 2016-11-12 22:36:27 --> Router Class Initialized
INFO - 2016-11-12 22:36:27 --> Output Class Initialized
INFO - 2016-11-12 22:36:27 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:27 --> Input Class Initialized
INFO - 2016-11-12 22:36:27 --> Language Class Initialized
INFO - 2016-11-12 22:36:27 --> Loader Class Initialized
INFO - 2016-11-12 22:36:27 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:27 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:27 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:27 --> Controller Class Initialized
INFO - 2016-11-12 22:36:27 --> Model Class Initialized
INFO - 2016-11-12 22:36:27 --> Model Class Initialized
INFO - 2016-11-12 22:36:27 --> Model Class Initialized
INFO - 2016-11-12 22:36:27 --> Model Class Initialized
INFO - 2016-11-12 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:36:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:36:28 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:28 --> Total execution time: 0.5234
INFO - 2016-11-12 22:36:28 --> Config Class Initialized
INFO - 2016-11-12 22:36:28 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:28 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:28 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:28 --> URI Class Initialized
DEBUG - 2016-11-12 22:36:28 --> No URI present. Default controller set.
INFO - 2016-11-12 22:36:28 --> Router Class Initialized
INFO - 2016-11-12 22:36:28 --> Output Class Initialized
INFO - 2016-11-12 22:36:28 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:28 --> Input Class Initialized
INFO - 2016-11-12 22:36:28 --> Language Class Initialized
INFO - 2016-11-12 22:36:28 --> Loader Class Initialized
INFO - 2016-11-12 22:36:28 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:28 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:28 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:28 --> Controller Class Initialized
INFO - 2016-11-12 22:36:28 --> Model Class Initialized
INFO - 2016-11-12 22:36:28 --> Model Class Initialized
INFO - 2016-11-12 22:36:28 --> Model Class Initialized
INFO - 2016-11-12 22:36:28 --> Model Class Initialized
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:36:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:36:28 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:28 --> Total execution time: 0.5186
INFO - 2016-11-12 22:36:29 --> Config Class Initialized
INFO - 2016-11-12 22:36:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:29 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:29 --> URI Class Initialized
DEBUG - 2016-11-12 22:36:29 --> No URI present. Default controller set.
INFO - 2016-11-12 22:36:29 --> Router Class Initialized
INFO - 2016-11-12 22:36:29 --> Output Class Initialized
INFO - 2016-11-12 22:36:29 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:29 --> Input Class Initialized
INFO - 2016-11-12 22:36:29 --> Language Class Initialized
INFO - 2016-11-12 22:36:29 --> Loader Class Initialized
INFO - 2016-11-12 22:36:29 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:29 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:29 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:29 --> Controller Class Initialized
INFO - 2016-11-12 22:36:29 --> Model Class Initialized
INFO - 2016-11-12 22:36:29 --> Model Class Initialized
INFO - 2016-11-12 22:36:29 --> Model Class Initialized
INFO - 2016-11-12 22:36:29 --> Model Class Initialized
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:36:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:36:29 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:29 --> Total execution time: 0.5203
INFO - 2016-11-12 22:36:37 --> Config Class Initialized
INFO - 2016-11-12 22:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:37 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:37 --> URI Class Initialized
INFO - 2016-11-12 22:36:37 --> Router Class Initialized
INFO - 2016-11-12 22:36:37 --> Output Class Initialized
INFO - 2016-11-12 22:36:37 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:37 --> Input Class Initialized
INFO - 2016-11-12 22:36:37 --> Language Class Initialized
INFO - 2016-11-12 22:36:37 --> Loader Class Initialized
INFO - 2016-11-12 22:36:37 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:37 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:37 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:37 --> Controller Class Initialized
INFO - 2016-11-12 22:36:37 --> Model Class Initialized
INFO - 2016-11-12 22:36:37 --> Model Class Initialized
INFO - 2016-11-12 22:36:37 --> Model Class Initialized
INFO - 2016-11-12 22:36:37 --> Model Class Initialized
DEBUG - 2016-11-12 22:36:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 22:36:37 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 22:36:37 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 22:36:37 --> Config Class Initialized
INFO - 2016-11-12 22:36:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:37 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:37 --> URI Class Initialized
DEBUG - 2016-11-12 22:36:37 --> No URI present. Default controller set.
INFO - 2016-11-12 22:36:38 --> Router Class Initialized
INFO - 2016-11-12 22:36:38 --> Output Class Initialized
INFO - 2016-11-12 22:36:38 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:38 --> Input Class Initialized
INFO - 2016-11-12 22:36:38 --> Language Class Initialized
INFO - 2016-11-12 22:36:38 --> Loader Class Initialized
INFO - 2016-11-12 22:36:38 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:38 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:38 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:38 --> Controller Class Initialized
INFO - 2016-11-12 22:36:38 --> Model Class Initialized
INFO - 2016-11-12 22:36:38 --> Model Class Initialized
INFO - 2016-11-12 22:36:38 --> Model Class Initialized
INFO - 2016-11-12 22:36:38 --> Model Class Initialized
INFO - 2016-11-12 22:36:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:36:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 22:36:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:36:38 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:38 --> Total execution time: 0.4006
INFO - 2016-11-12 22:36:44 --> Config Class Initialized
INFO - 2016-11-12 22:36:44 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:44 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:44 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:44 --> URI Class Initialized
INFO - 2016-11-12 22:36:44 --> Router Class Initialized
INFO - 2016-11-12 22:36:44 --> Output Class Initialized
INFO - 2016-11-12 22:36:44 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:44 --> Input Class Initialized
INFO - 2016-11-12 22:36:44 --> Language Class Initialized
INFO - 2016-11-12 22:36:44 --> Loader Class Initialized
INFO - 2016-11-12 22:36:44 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:44 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:44 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:44 --> Controller Class Initialized
INFO - 2016-11-12 22:36:44 --> Model Class Initialized
INFO - 2016-11-12 22:36:44 --> Model Class Initialized
INFO - 2016-11-12 22:36:44 --> Model Class Initialized
INFO - 2016-11-12 22:36:44 --> Model Class Initialized
DEBUG - 2016-11-12 22:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 22:36:45 --> Model Class Initialized
INFO - 2016-11-12 22:36:45 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:45 --> Total execution time: 0.3404
INFO - 2016-11-12 22:36:45 --> Config Class Initialized
INFO - 2016-11-12 22:36:45 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:36:45 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:36:45 --> Utf8 Class Initialized
INFO - 2016-11-12 22:36:45 --> URI Class Initialized
DEBUG - 2016-11-12 22:36:45 --> No URI present. Default controller set.
INFO - 2016-11-12 22:36:45 --> Router Class Initialized
INFO - 2016-11-12 22:36:45 --> Output Class Initialized
INFO - 2016-11-12 22:36:45 --> Security Class Initialized
DEBUG - 2016-11-12 22:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:36:45 --> Input Class Initialized
INFO - 2016-11-12 22:36:45 --> Language Class Initialized
INFO - 2016-11-12 22:36:45 --> Loader Class Initialized
INFO - 2016-11-12 22:36:45 --> Helper loaded: url_helper
INFO - 2016-11-12 22:36:45 --> Helper loaded: form_helper
INFO - 2016-11-12 22:36:45 --> Database Driver Class Initialized
INFO - 2016-11-12 22:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:36:45 --> Controller Class Initialized
INFO - 2016-11-12 22:36:45 --> Model Class Initialized
INFO - 2016-11-12 22:36:45 --> Model Class Initialized
INFO - 2016-11-12 22:36:45 --> Model Class Initialized
INFO - 2016-11-12 22:36:45 --> Model Class Initialized
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:36:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:36:45 --> Final output sent to browser
DEBUG - 2016-11-12 22:36:45 --> Total execution time: 0.4685
INFO - 2016-11-12 22:40:50 --> Config Class Initialized
INFO - 2016-11-12 22:40:50 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:40:50 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:40:50 --> Utf8 Class Initialized
INFO - 2016-11-12 22:40:50 --> URI Class Initialized
DEBUG - 2016-11-12 22:40:50 --> No URI present. Default controller set.
INFO - 2016-11-12 22:40:50 --> Router Class Initialized
INFO - 2016-11-12 22:40:50 --> Output Class Initialized
INFO - 2016-11-12 22:40:50 --> Security Class Initialized
DEBUG - 2016-11-12 22:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:40:50 --> Input Class Initialized
INFO - 2016-11-12 22:40:50 --> Language Class Initialized
INFO - 2016-11-12 22:40:50 --> Loader Class Initialized
INFO - 2016-11-12 22:40:50 --> Helper loaded: url_helper
INFO - 2016-11-12 22:40:50 --> Helper loaded: form_helper
INFO - 2016-11-12 22:40:50 --> Database Driver Class Initialized
INFO - 2016-11-12 22:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:40:50 --> Controller Class Initialized
INFO - 2016-11-12 22:40:50 --> Model Class Initialized
INFO - 2016-11-12 22:40:50 --> Model Class Initialized
INFO - 2016-11-12 22:40:50 --> Model Class Initialized
INFO - 2016-11-12 22:40:50 --> Model Class Initialized
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:40:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:40:50 --> Final output sent to browser
DEBUG - 2016-11-12 22:40:50 --> Total execution time: 0.5395
INFO - 2016-11-12 22:46:15 --> Config Class Initialized
INFO - 2016-11-12 22:46:15 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:46:15 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:46:15 --> Utf8 Class Initialized
INFO - 2016-11-12 22:46:15 --> URI Class Initialized
DEBUG - 2016-11-12 22:46:15 --> No URI present. Default controller set.
INFO - 2016-11-12 22:46:15 --> Router Class Initialized
INFO - 2016-11-12 22:46:15 --> Output Class Initialized
INFO - 2016-11-12 22:46:15 --> Security Class Initialized
DEBUG - 2016-11-12 22:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:46:15 --> Input Class Initialized
INFO - 2016-11-12 22:46:15 --> Language Class Initialized
INFO - 2016-11-12 22:46:15 --> Loader Class Initialized
INFO - 2016-11-12 22:46:15 --> Helper loaded: url_helper
INFO - 2016-11-12 22:46:15 --> Helper loaded: form_helper
INFO - 2016-11-12 22:46:15 --> Database Driver Class Initialized
INFO - 2016-11-12 22:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:46:15 --> Controller Class Initialized
INFO - 2016-11-12 22:46:15 --> Model Class Initialized
INFO - 2016-11-12 22:46:15 --> Model Class Initialized
INFO - 2016-11-12 22:46:15 --> Model Class Initialized
INFO - 2016-11-12 22:46:15 --> Model Class Initialized
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:46:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:46:15 --> Final output sent to browser
DEBUG - 2016-11-12 22:46:15 --> Total execution time: 0.5231
INFO - 2016-11-12 22:46:51 --> Config Class Initialized
INFO - 2016-11-12 22:46:51 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:46:51 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:46:51 --> Utf8 Class Initialized
INFO - 2016-11-12 22:46:51 --> URI Class Initialized
INFO - 2016-11-12 22:46:51 --> Router Class Initialized
INFO - 2016-11-12 22:46:51 --> Output Class Initialized
INFO - 2016-11-12 22:46:51 --> Security Class Initialized
DEBUG - 2016-11-12 22:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:46:51 --> Input Class Initialized
INFO - 2016-11-12 22:46:51 --> Language Class Initialized
INFO - 2016-11-12 22:46:51 --> Loader Class Initialized
INFO - 2016-11-12 22:46:51 --> Helper loaded: url_helper
INFO - 2016-11-12 22:46:51 --> Helper loaded: form_helper
INFO - 2016-11-12 22:46:51 --> Database Driver Class Initialized
INFO - 2016-11-12 22:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:46:51 --> Controller Class Initialized
INFO - 2016-11-12 22:46:51 --> Model Class Initialized
INFO - 2016-11-12 22:46:51 --> Model Class Initialized
INFO - 2016-11-12 22:46:51 --> Model Class Initialized
INFO - 2016-11-12 22:46:51 --> Model Class Initialized
DEBUG - 2016-11-12 22:46:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 22:46:51 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 22:46:51 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 22:46:51 --> Config Class Initialized
INFO - 2016-11-12 22:46:51 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:46:52 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:46:52 --> Utf8 Class Initialized
INFO - 2016-11-12 22:46:52 --> URI Class Initialized
DEBUG - 2016-11-12 22:46:52 --> No URI present. Default controller set.
INFO - 2016-11-12 22:46:52 --> Router Class Initialized
INFO - 2016-11-12 22:46:52 --> Output Class Initialized
INFO - 2016-11-12 22:46:52 --> Security Class Initialized
DEBUG - 2016-11-12 22:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:46:52 --> Input Class Initialized
INFO - 2016-11-12 22:46:52 --> Language Class Initialized
INFO - 2016-11-12 22:46:52 --> Loader Class Initialized
INFO - 2016-11-12 22:46:52 --> Helper loaded: url_helper
INFO - 2016-11-12 22:46:52 --> Helper loaded: form_helper
INFO - 2016-11-12 22:46:52 --> Database Driver Class Initialized
INFO - 2016-11-12 22:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:46:52 --> Controller Class Initialized
INFO - 2016-11-12 22:46:52 --> Model Class Initialized
INFO - 2016-11-12 22:46:52 --> Model Class Initialized
INFO - 2016-11-12 22:46:52 --> Model Class Initialized
INFO - 2016-11-12 22:46:52 --> Model Class Initialized
INFO - 2016-11-12 22:46:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:46:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 22:46:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:46:52 --> Final output sent to browser
DEBUG - 2016-11-12 22:46:52 --> Total execution time: 0.3900
INFO - 2016-11-12 22:47:04 --> Config Class Initialized
INFO - 2016-11-12 22:47:04 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:47:04 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:47:04 --> Utf8 Class Initialized
INFO - 2016-11-12 22:47:04 --> URI Class Initialized
INFO - 2016-11-12 22:47:04 --> Router Class Initialized
INFO - 2016-11-12 22:47:04 --> Output Class Initialized
INFO - 2016-11-12 22:47:04 --> Security Class Initialized
DEBUG - 2016-11-12 22:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:47:04 --> Input Class Initialized
INFO - 2016-11-12 22:47:04 --> Language Class Initialized
INFO - 2016-11-12 22:47:04 --> Loader Class Initialized
INFO - 2016-11-12 22:47:04 --> Helper loaded: url_helper
INFO - 2016-11-12 22:47:04 --> Helper loaded: form_helper
INFO - 2016-11-12 22:47:04 --> Database Driver Class Initialized
INFO - 2016-11-12 22:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:47:04 --> Controller Class Initialized
INFO - 2016-11-12 22:47:04 --> Model Class Initialized
INFO - 2016-11-12 22:47:04 --> Model Class Initialized
INFO - 2016-11-12 22:47:04 --> Model Class Initialized
INFO - 2016-11-12 22:47:04 --> Model Class Initialized
DEBUG - 2016-11-12 22:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 22:47:04 --> Model Class Initialized
INFO - 2016-11-12 22:47:04 --> Final output sent to browser
DEBUG - 2016-11-12 22:47:04 --> Total execution time: 0.3611
INFO - 2016-11-12 22:47:04 --> Config Class Initialized
INFO - 2016-11-12 22:47:04 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:47:04 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:47:04 --> Utf8 Class Initialized
INFO - 2016-11-12 22:47:04 --> URI Class Initialized
DEBUG - 2016-11-12 22:47:04 --> No URI present. Default controller set.
INFO - 2016-11-12 22:47:04 --> Router Class Initialized
INFO - 2016-11-12 22:47:04 --> Output Class Initialized
INFO - 2016-11-12 22:47:04 --> Security Class Initialized
DEBUG - 2016-11-12 22:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:47:04 --> Input Class Initialized
INFO - 2016-11-12 22:47:04 --> Language Class Initialized
INFO - 2016-11-12 22:47:04 --> Loader Class Initialized
INFO - 2016-11-12 22:47:04 --> Helper loaded: url_helper
INFO - 2016-11-12 22:47:04 --> Helper loaded: form_helper
INFO - 2016-11-12 22:47:04 --> Database Driver Class Initialized
INFO - 2016-11-12 22:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:47:04 --> Controller Class Initialized
INFO - 2016-11-12 22:47:04 --> Model Class Initialized
INFO - 2016-11-12 22:47:05 --> Model Class Initialized
INFO - 2016-11-12 22:47:05 --> Model Class Initialized
INFO - 2016-11-12 22:47:05 --> Model Class Initialized
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:47:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:47:05 --> Final output sent to browser
DEBUG - 2016-11-12 22:47:05 --> Total execution time: 0.5334
INFO - 2016-11-12 22:47:38 --> Config Class Initialized
INFO - 2016-11-12 22:47:38 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:47:38 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:47:38 --> Utf8 Class Initialized
INFO - 2016-11-12 22:47:38 --> URI Class Initialized
DEBUG - 2016-11-12 22:47:38 --> No URI present. Default controller set.
INFO - 2016-11-12 22:47:38 --> Router Class Initialized
INFO - 2016-11-12 22:47:38 --> Output Class Initialized
INFO - 2016-11-12 22:47:38 --> Security Class Initialized
DEBUG - 2016-11-12 22:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:47:39 --> Input Class Initialized
INFO - 2016-11-12 22:47:39 --> Language Class Initialized
INFO - 2016-11-12 22:47:39 --> Loader Class Initialized
INFO - 2016-11-12 22:47:39 --> Helper loaded: url_helper
INFO - 2016-11-12 22:47:39 --> Helper loaded: form_helper
INFO - 2016-11-12 22:47:39 --> Database Driver Class Initialized
INFO - 2016-11-12 22:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:47:39 --> Controller Class Initialized
INFO - 2016-11-12 22:47:39 --> Model Class Initialized
INFO - 2016-11-12 22:47:39 --> Model Class Initialized
INFO - 2016-11-12 22:47:39 --> Model Class Initialized
INFO - 2016-11-12 22:47:39 --> Model Class Initialized
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:47:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:47:39 --> Final output sent to browser
DEBUG - 2016-11-12 22:47:39 --> Total execution time: 0.5493
INFO - 2016-11-12 22:48:06 --> Config Class Initialized
INFO - 2016-11-12 22:48:06 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:48:06 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:48:06 --> Utf8 Class Initialized
INFO - 2016-11-12 22:48:06 --> URI Class Initialized
INFO - 2016-11-12 22:48:06 --> Router Class Initialized
INFO - 2016-11-12 22:48:06 --> Output Class Initialized
INFO - 2016-11-12 22:48:06 --> Security Class Initialized
DEBUG - 2016-11-12 22:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:48:06 --> Input Class Initialized
INFO - 2016-11-12 22:48:06 --> Language Class Initialized
INFO - 2016-11-12 22:48:06 --> Loader Class Initialized
INFO - 2016-11-12 22:48:06 --> Helper loaded: url_helper
INFO - 2016-11-12 22:48:06 --> Helper loaded: form_helper
INFO - 2016-11-12 22:48:06 --> Database Driver Class Initialized
INFO - 2016-11-12 22:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:48:06 --> Controller Class Initialized
INFO - 2016-11-12 22:48:06 --> Model Class Initialized
INFO - 2016-11-12 22:48:06 --> Model Class Initialized
INFO - 2016-11-12 22:48:06 --> Model Class Initialized
INFO - 2016-11-12 22:48:06 --> Model Class Initialized
DEBUG - 2016-11-12 22:48:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-12 22:48:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-12 22:48:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-12 22:48:06 --> Config Class Initialized
INFO - 2016-11-12 22:48:06 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:48:06 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:48:06 --> Utf8 Class Initialized
INFO - 2016-11-12 22:48:06 --> URI Class Initialized
DEBUG - 2016-11-12 22:48:06 --> No URI present. Default controller set.
INFO - 2016-11-12 22:48:06 --> Router Class Initialized
INFO - 2016-11-12 22:48:06 --> Output Class Initialized
INFO - 2016-11-12 22:48:06 --> Security Class Initialized
DEBUG - 2016-11-12 22:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:48:06 --> Input Class Initialized
INFO - 2016-11-12 22:48:06 --> Language Class Initialized
INFO - 2016-11-12 22:48:06 --> Loader Class Initialized
INFO - 2016-11-12 22:48:06 --> Helper loaded: url_helper
INFO - 2016-11-12 22:48:06 --> Helper loaded: form_helper
INFO - 2016-11-12 22:48:06 --> Database Driver Class Initialized
INFO - 2016-11-12 22:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:48:07 --> Controller Class Initialized
INFO - 2016-11-12 22:48:07 --> Model Class Initialized
INFO - 2016-11-12 22:48:07 --> Model Class Initialized
INFO - 2016-11-12 22:48:07 --> Model Class Initialized
INFO - 2016-11-12 22:48:07 --> Model Class Initialized
INFO - 2016-11-12 22:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-12 22:48:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:48:07 --> Final output sent to browser
DEBUG - 2016-11-12 22:48:07 --> Total execution time: 0.3983
INFO - 2016-11-12 22:48:15 --> Config Class Initialized
INFO - 2016-11-12 22:48:15 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:48:15 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:48:15 --> Utf8 Class Initialized
INFO - 2016-11-12 22:48:15 --> URI Class Initialized
INFO - 2016-11-12 22:48:15 --> Router Class Initialized
INFO - 2016-11-12 22:48:15 --> Output Class Initialized
INFO - 2016-11-12 22:48:15 --> Security Class Initialized
DEBUG - 2016-11-12 22:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:48:15 --> Input Class Initialized
INFO - 2016-11-12 22:48:15 --> Language Class Initialized
INFO - 2016-11-12 22:48:15 --> Loader Class Initialized
INFO - 2016-11-12 22:48:15 --> Helper loaded: url_helper
INFO - 2016-11-12 22:48:15 --> Helper loaded: form_helper
INFO - 2016-11-12 22:48:15 --> Database Driver Class Initialized
INFO - 2016-11-12 22:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:48:15 --> Controller Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
DEBUG - 2016-11-12 22:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Final output sent to browser
DEBUG - 2016-11-12 22:48:15 --> Total execution time: 0.3132
INFO - 2016-11-12 22:48:15 --> Config Class Initialized
INFO - 2016-11-12 22:48:15 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:48:15 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:48:15 --> Utf8 Class Initialized
INFO - 2016-11-12 22:48:15 --> URI Class Initialized
DEBUG - 2016-11-12 22:48:15 --> No URI present. Default controller set.
INFO - 2016-11-12 22:48:15 --> Router Class Initialized
INFO - 2016-11-12 22:48:15 --> Output Class Initialized
INFO - 2016-11-12 22:48:15 --> Security Class Initialized
DEBUG - 2016-11-12 22:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:48:15 --> Input Class Initialized
INFO - 2016-11-12 22:48:15 --> Language Class Initialized
INFO - 2016-11-12 22:48:15 --> Loader Class Initialized
INFO - 2016-11-12 22:48:15 --> Helper loaded: url_helper
INFO - 2016-11-12 22:48:15 --> Helper loaded: form_helper
INFO - 2016-11-12 22:48:15 --> Database Driver Class Initialized
INFO - 2016-11-12 22:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:48:15 --> Controller Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> Model Class Initialized
INFO - 2016-11-12 22:48:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:48:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:48:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:48:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:48:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:48:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:48:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:48:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:48:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:48:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:48:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:48:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:48:16 --> Final output sent to browser
DEBUG - 2016-11-12 22:48:16 --> Total execution time: 0.5060
INFO - 2016-11-12 22:49:38 --> Config Class Initialized
INFO - 2016-11-12 22:49:38 --> Hooks Class Initialized
DEBUG - 2016-11-12 22:49:38 --> UTF-8 Support Enabled
INFO - 2016-11-12 22:49:38 --> Utf8 Class Initialized
INFO - 2016-11-12 22:49:38 --> URI Class Initialized
DEBUG - 2016-11-12 22:49:38 --> No URI present. Default controller set.
INFO - 2016-11-12 22:49:38 --> Router Class Initialized
INFO - 2016-11-12 22:49:38 --> Output Class Initialized
INFO - 2016-11-12 22:49:38 --> Security Class Initialized
DEBUG - 2016-11-12 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 22:49:39 --> Input Class Initialized
INFO - 2016-11-12 22:49:39 --> Language Class Initialized
INFO - 2016-11-12 22:49:39 --> Loader Class Initialized
INFO - 2016-11-12 22:49:39 --> Helper loaded: url_helper
INFO - 2016-11-12 22:49:39 --> Helper loaded: form_helper
INFO - 2016-11-12 22:49:39 --> Database Driver Class Initialized
INFO - 2016-11-12 22:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 22:49:39 --> Controller Class Initialized
INFO - 2016-11-12 22:49:39 --> Model Class Initialized
INFO - 2016-11-12 22:49:39 --> Model Class Initialized
INFO - 2016-11-12 22:49:39 --> Model Class Initialized
INFO - 2016-11-12 22:49:39 --> Model Class Initialized
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 22:49:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 22:49:39 --> Final output sent to browser
DEBUG - 2016-11-12 22:49:39 --> Total execution time: 0.7592
INFO - 2016-11-12 23:06:52 --> Config Class Initialized
INFO - 2016-11-12 23:06:53 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:06:53 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:06:53 --> Utf8 Class Initialized
INFO - 2016-11-12 23:06:53 --> URI Class Initialized
DEBUG - 2016-11-12 23:06:53 --> No URI present. Default controller set.
INFO - 2016-11-12 23:06:53 --> Router Class Initialized
INFO - 2016-11-12 23:06:53 --> Output Class Initialized
INFO - 2016-11-12 23:06:53 --> Security Class Initialized
DEBUG - 2016-11-12 23:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:06:53 --> Input Class Initialized
INFO - 2016-11-12 23:06:53 --> Language Class Initialized
INFO - 2016-11-12 23:06:53 --> Loader Class Initialized
INFO - 2016-11-12 23:06:53 --> Helper loaded: url_helper
INFO - 2016-11-12 23:06:53 --> Helper loaded: form_helper
INFO - 2016-11-12 23:06:53 --> Database Driver Class Initialized
INFO - 2016-11-12 23:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:06:53 --> Controller Class Initialized
INFO - 2016-11-12 23:06:53 --> Model Class Initialized
INFO - 2016-11-12 23:06:53 --> Model Class Initialized
INFO - 2016-11-12 23:06:53 --> Model Class Initialized
INFO - 2016-11-12 23:06:53 --> Model Class Initialized
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 23:06:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 23:06:53 --> Final output sent to browser
DEBUG - 2016-11-12 23:06:53 --> Total execution time: 0.8330
INFO - 2016-11-12 23:07:34 --> Config Class Initialized
INFO - 2016-11-12 23:07:34 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:07:34 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:07:34 --> Utf8 Class Initialized
INFO - 2016-11-12 23:07:34 --> URI Class Initialized
DEBUG - 2016-11-12 23:07:34 --> No URI present. Default controller set.
INFO - 2016-11-12 23:07:34 --> Router Class Initialized
INFO - 2016-11-12 23:07:34 --> Output Class Initialized
INFO - 2016-11-12 23:07:34 --> Security Class Initialized
DEBUG - 2016-11-12 23:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:07:34 --> Input Class Initialized
INFO - 2016-11-12 23:07:34 --> Language Class Initialized
INFO - 2016-11-12 23:07:34 --> Loader Class Initialized
INFO - 2016-11-12 23:07:34 --> Helper loaded: url_helper
INFO - 2016-11-12 23:07:34 --> Helper loaded: form_helper
INFO - 2016-11-12 23:07:34 --> Database Driver Class Initialized
INFO - 2016-11-12 23:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:07:34 --> Controller Class Initialized
INFO - 2016-11-12 23:07:34 --> Model Class Initialized
INFO - 2016-11-12 23:07:34 --> Model Class Initialized
INFO - 2016-11-12 23:07:34 --> Model Class Initialized
INFO - 2016-11-12 23:07:34 --> Model Class Initialized
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 23:07:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 23:07:34 --> Final output sent to browser
DEBUG - 2016-11-12 23:07:34 --> Total execution time: 0.5302
INFO - 2016-11-12 23:07:59 --> Config Class Initialized
INFO - 2016-11-12 23:07:59 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:07:59 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:07:59 --> Utf8 Class Initialized
INFO - 2016-11-12 23:07:59 --> URI Class Initialized
DEBUG - 2016-11-12 23:07:59 --> No URI present. Default controller set.
INFO - 2016-11-12 23:07:59 --> Router Class Initialized
INFO - 2016-11-12 23:08:00 --> Output Class Initialized
INFO - 2016-11-12 23:08:00 --> Security Class Initialized
DEBUG - 2016-11-12 23:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:08:00 --> Input Class Initialized
INFO - 2016-11-12 23:08:00 --> Language Class Initialized
INFO - 2016-11-12 23:08:00 --> Loader Class Initialized
INFO - 2016-11-12 23:08:00 --> Helper loaded: url_helper
INFO - 2016-11-12 23:08:00 --> Helper loaded: form_helper
INFO - 2016-11-12 23:08:00 --> Database Driver Class Initialized
INFO - 2016-11-12 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:08:00 --> Controller Class Initialized
INFO - 2016-11-12 23:08:00 --> Model Class Initialized
INFO - 2016-11-12 23:08:00 --> Model Class Initialized
INFO - 2016-11-12 23:08:00 --> Model Class Initialized
INFO - 2016-11-12 23:08:00 --> Model Class Initialized
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 23:08:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 23:08:00 --> Final output sent to browser
DEBUG - 2016-11-12 23:08:00 --> Total execution time: 0.5499
INFO - 2016-11-12 23:09:49 --> Config Class Initialized
INFO - 2016-11-12 23:09:49 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:09:49 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:09:49 --> Utf8 Class Initialized
INFO - 2016-11-12 23:09:49 --> URI Class Initialized
DEBUG - 2016-11-12 23:09:49 --> No URI present. Default controller set.
INFO - 2016-11-12 23:09:49 --> Router Class Initialized
INFO - 2016-11-12 23:09:49 --> Output Class Initialized
INFO - 2016-11-12 23:09:49 --> Security Class Initialized
DEBUG - 2016-11-12 23:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:09:49 --> Input Class Initialized
INFO - 2016-11-12 23:09:49 --> Language Class Initialized
INFO - 2016-11-12 23:09:49 --> Loader Class Initialized
INFO - 2016-11-12 23:09:49 --> Helper loaded: url_helper
INFO - 2016-11-12 23:09:49 --> Helper loaded: form_helper
INFO - 2016-11-12 23:09:49 --> Database Driver Class Initialized
INFO - 2016-11-12 23:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:09:49 --> Controller Class Initialized
INFO - 2016-11-12 23:09:49 --> Model Class Initialized
INFO - 2016-11-12 23:09:49 --> Model Class Initialized
INFO - 2016-11-12 23:09:49 --> Model Class Initialized
INFO - 2016-11-12 23:09:49 --> Model Class Initialized
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 23:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 23:09:49 --> Final output sent to browser
DEBUG - 2016-11-12 23:09:49 --> Total execution time: 0.6105
INFO - 2016-11-12 23:11:06 --> Config Class Initialized
INFO - 2016-11-12 23:11:06 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:11:06 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:11:06 --> Utf8 Class Initialized
INFO - 2016-11-12 23:11:06 --> URI Class Initialized
DEBUG - 2016-11-12 23:11:06 --> No URI present. Default controller set.
INFO - 2016-11-12 23:11:06 --> Router Class Initialized
INFO - 2016-11-12 23:11:06 --> Output Class Initialized
INFO - 2016-11-12 23:11:06 --> Security Class Initialized
DEBUG - 2016-11-12 23:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:11:06 --> Input Class Initialized
INFO - 2016-11-12 23:11:06 --> Language Class Initialized
INFO - 2016-11-12 23:11:06 --> Loader Class Initialized
INFO - 2016-11-12 23:11:06 --> Helper loaded: url_helper
INFO - 2016-11-12 23:11:06 --> Helper loaded: form_helper
INFO - 2016-11-12 23:11:06 --> Database Driver Class Initialized
INFO - 2016-11-12 23:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:11:06 --> Controller Class Initialized
INFO - 2016-11-12 23:11:06 --> Model Class Initialized
INFO - 2016-11-12 23:11:06 --> Model Class Initialized
INFO - 2016-11-12 23:11:06 --> Model Class Initialized
INFO - 2016-11-12 23:11:06 --> Model Class Initialized
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 23:11:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 23:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 23:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 23:11:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 23:11:07 --> Final output sent to browser
DEBUG - 2016-11-12 23:11:07 --> Total execution time: 0.4980
INFO - 2016-11-12 23:13:54 --> Config Class Initialized
INFO - 2016-11-12 23:13:54 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:13:54 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:13:54 --> Utf8 Class Initialized
INFO - 2016-11-12 23:13:54 --> URI Class Initialized
DEBUG - 2016-11-12 23:13:54 --> No URI present. Default controller set.
INFO - 2016-11-12 23:13:54 --> Router Class Initialized
INFO - 2016-11-12 23:13:54 --> Output Class Initialized
INFO - 2016-11-12 23:13:54 --> Security Class Initialized
DEBUG - 2016-11-12 23:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:13:54 --> Input Class Initialized
INFO - 2016-11-12 23:13:54 --> Language Class Initialized
INFO - 2016-11-12 23:13:54 --> Loader Class Initialized
INFO - 2016-11-12 23:13:54 --> Helper loaded: url_helper
INFO - 2016-11-12 23:13:54 --> Helper loaded: form_helper
INFO - 2016-11-12 23:13:54 --> Database Driver Class Initialized
INFO - 2016-11-12 23:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:13:54 --> Controller Class Initialized
INFO - 2016-11-12 23:13:54 --> Model Class Initialized
INFO - 2016-11-12 23:13:54 --> Model Class Initialized
INFO - 2016-11-12 23:13:54 --> Model Class Initialized
INFO - 2016-11-12 23:13:54 --> Model Class Initialized
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-12 23:13:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-12 23:13:54 --> Final output sent to browser
DEBUG - 2016-11-12 23:13:54 --> Total execution time: 0.5265
