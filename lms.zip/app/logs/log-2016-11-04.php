<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-04 01:07:08 --> Config Class Initialized
INFO - 2016-11-04 01:07:08 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:07:08 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:07:08 --> Utf8 Class Initialized
INFO - 2016-11-04 01:07:08 --> URI Class Initialized
DEBUG - 2016-11-04 01:07:08 --> No URI present. Default controller set.
INFO - 2016-11-04 01:07:08 --> Router Class Initialized
INFO - 2016-11-04 01:07:09 --> Output Class Initialized
INFO - 2016-11-04 01:07:09 --> Security Class Initialized
DEBUG - 2016-11-04 01:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:07:09 --> Input Class Initialized
INFO - 2016-11-04 01:07:09 --> Language Class Initialized
INFO - 2016-11-04 01:07:09 --> Loader Class Initialized
INFO - 2016-11-04 01:07:09 --> Helper loaded: url_helper
INFO - 2016-11-04 01:07:09 --> Helper loaded: form_helper
INFO - 2016-11-04 01:07:09 --> Database Driver Class Initialized
INFO - 2016-11-04 01:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:07:10 --> Controller Class Initialized
INFO - 2016-11-04 01:07:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 01:07:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 01:07:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 01:07:10 --> Final output sent to browser
DEBUG - 2016-11-04 01:07:10 --> Total execution time: 1.4791
INFO - 2016-11-04 01:07:23 --> Config Class Initialized
INFO - 2016-11-04 01:07:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:07:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:07:23 --> Utf8 Class Initialized
INFO - 2016-11-04 01:07:23 --> URI Class Initialized
INFO - 2016-11-04 01:07:23 --> Router Class Initialized
INFO - 2016-11-04 01:07:23 --> Output Class Initialized
INFO - 2016-11-04 01:07:23 --> Security Class Initialized
DEBUG - 2016-11-04 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:07:23 --> Input Class Initialized
INFO - 2016-11-04 01:07:23 --> Language Class Initialized
INFO - 2016-11-04 01:07:23 --> Loader Class Initialized
INFO - 2016-11-04 01:07:23 --> Helper loaded: url_helper
INFO - 2016-11-04 01:07:23 --> Helper loaded: form_helper
INFO - 2016-11-04 01:07:23 --> Database Driver Class Initialized
INFO - 2016-11-04 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:07:23 --> Controller Class Initialized
DEBUG - 2016-11-04 01:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 01:07:23 --> Model Class Initialized
INFO - 2016-11-04 01:07:24 --> Final output sent to browser
DEBUG - 2016-11-04 01:07:24 --> Total execution time: 0.5541
INFO - 2016-11-04 01:07:24 --> Config Class Initialized
INFO - 2016-11-04 01:07:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:07:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:07:24 --> Utf8 Class Initialized
INFO - 2016-11-04 01:07:24 --> URI Class Initialized
DEBUG - 2016-11-04 01:07:24 --> No URI present. Default controller set.
INFO - 2016-11-04 01:07:24 --> Router Class Initialized
INFO - 2016-11-04 01:07:24 --> Output Class Initialized
INFO - 2016-11-04 01:07:24 --> Security Class Initialized
DEBUG - 2016-11-04 01:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:07:24 --> Input Class Initialized
INFO - 2016-11-04 01:07:24 --> Language Class Initialized
INFO - 2016-11-04 01:07:24 --> Loader Class Initialized
INFO - 2016-11-04 01:07:24 --> Helper loaded: url_helper
INFO - 2016-11-04 01:07:24 --> Helper loaded: form_helper
INFO - 2016-11-04 01:07:24 --> Database Driver Class Initialized
INFO - 2016-11-04 01:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:07:24 --> Controller Class Initialized
INFO - 2016-11-04 01:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 01:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 01:07:24 --> Model Class Initialized
INFO - 2016-11-04 01:07:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 01:07:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 01:07:25 --> Final output sent to browser
DEBUG - 2016-11-04 01:07:25 --> Total execution time: 1.4039
INFO - 2016-11-04 01:07:57 --> Config Class Initialized
INFO - 2016-11-04 01:07:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:07:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:07:57 --> Utf8 Class Initialized
INFO - 2016-11-04 01:07:57 --> URI Class Initialized
INFO - 2016-11-04 01:07:57 --> Router Class Initialized
INFO - 2016-11-04 01:07:57 --> Output Class Initialized
INFO - 2016-11-04 01:07:57 --> Security Class Initialized
DEBUG - 2016-11-04 01:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:07:57 --> Input Class Initialized
INFO - 2016-11-04 01:07:57 --> Language Class Initialized
INFO - 2016-11-04 01:07:57 --> Loader Class Initialized
INFO - 2016-11-04 01:07:57 --> Helper loaded: url_helper
INFO - 2016-11-04 01:07:57 --> Helper loaded: form_helper
INFO - 2016-11-04 01:07:57 --> Database Driver Class Initialized
INFO - 2016-11-04 01:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:07:57 --> Controller Class Initialized
INFO - 2016-11-04 01:07:57 --> Form Validation Class Initialized
INFO - 2016-11-04 01:07:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 01:07:57 --> Final output sent to browser
DEBUG - 2016-11-04 01:07:57 --> Total execution time: 0.2849
INFO - 2016-11-04 01:08:09 --> Config Class Initialized
INFO - 2016-11-04 01:08:09 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:08:09 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:08:09 --> Utf8 Class Initialized
INFO - 2016-11-04 01:08:09 --> URI Class Initialized
INFO - 2016-11-04 01:08:09 --> Router Class Initialized
INFO - 2016-11-04 01:08:09 --> Output Class Initialized
INFO - 2016-11-04 01:08:09 --> Security Class Initialized
DEBUG - 2016-11-04 01:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:08:09 --> Input Class Initialized
INFO - 2016-11-04 01:08:09 --> Language Class Initialized
INFO - 2016-11-04 01:08:09 --> Loader Class Initialized
INFO - 2016-11-04 01:08:09 --> Helper loaded: url_helper
INFO - 2016-11-04 01:08:09 --> Helper loaded: form_helper
INFO - 2016-11-04 01:08:09 --> Database Driver Class Initialized
INFO - 2016-11-04 01:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:08:09 --> Controller Class Initialized
INFO - 2016-11-04 01:08:09 --> Form Validation Class Initialized
INFO - 2016-11-04 01:08:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 01:08:09 --> Final output sent to browser
DEBUG - 2016-11-04 01:08:09 --> Total execution time: 0.2578
INFO - 2016-11-04 01:08:53 --> Config Class Initialized
INFO - 2016-11-04 01:08:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:08:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:08:53 --> Utf8 Class Initialized
INFO - 2016-11-04 01:08:53 --> URI Class Initialized
INFO - 2016-11-04 01:08:53 --> Router Class Initialized
INFO - 2016-11-04 01:08:53 --> Output Class Initialized
INFO - 2016-11-04 01:08:53 --> Security Class Initialized
DEBUG - 2016-11-04 01:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:08:53 --> Input Class Initialized
INFO - 2016-11-04 01:08:53 --> Language Class Initialized
INFO - 2016-11-04 01:08:53 --> Loader Class Initialized
INFO - 2016-11-04 01:08:53 --> Helper loaded: url_helper
INFO - 2016-11-04 01:08:53 --> Helper loaded: form_helper
INFO - 2016-11-04 01:08:53 --> Database Driver Class Initialized
INFO - 2016-11-04 01:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:08:53 --> Controller Class Initialized
INFO - 2016-11-04 01:08:53 --> Model Class Initialized
INFO - 2016-11-04 01:08:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 01:08:53 --> Final output sent to browser
DEBUG - 2016-11-04 01:08:53 --> Total execution time: 0.2804
INFO - 2016-11-04 01:09:07 --> Config Class Initialized
INFO - 2016-11-04 01:09:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:09:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:09:07 --> Utf8 Class Initialized
INFO - 2016-11-04 01:09:07 --> URI Class Initialized
INFO - 2016-11-04 01:09:07 --> Router Class Initialized
INFO - 2016-11-04 01:09:07 --> Output Class Initialized
INFO - 2016-11-04 01:09:07 --> Security Class Initialized
DEBUG - 2016-11-04 01:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:09:07 --> Input Class Initialized
INFO - 2016-11-04 01:09:07 --> Language Class Initialized
INFO - 2016-11-04 01:09:07 --> Loader Class Initialized
INFO - 2016-11-04 01:09:07 --> Helper loaded: url_helper
INFO - 2016-11-04 01:09:07 --> Helper loaded: form_helper
INFO - 2016-11-04 01:09:07 --> Database Driver Class Initialized
INFO - 2016-11-04 01:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:09:07 --> Controller Class Initialized
INFO - 2016-11-04 01:09:07 --> Model Class Initialized
INFO - 2016-11-04 01:09:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 01:09:07 --> Final output sent to browser
DEBUG - 2016-11-04 01:09:07 --> Total execution time: 0.1858
INFO - 2016-11-04 01:09:49 --> Config Class Initialized
INFO - 2016-11-04 01:09:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:09:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:09:49 --> Utf8 Class Initialized
INFO - 2016-11-04 01:09:49 --> URI Class Initialized
INFO - 2016-11-04 01:09:49 --> Router Class Initialized
INFO - 2016-11-04 01:09:49 --> Output Class Initialized
INFO - 2016-11-04 01:09:49 --> Security Class Initialized
DEBUG - 2016-11-04 01:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:09:49 --> Input Class Initialized
INFO - 2016-11-04 01:09:49 --> Language Class Initialized
INFO - 2016-11-04 01:09:49 --> Loader Class Initialized
INFO - 2016-11-04 01:09:49 --> Helper loaded: url_helper
INFO - 2016-11-04 01:09:49 --> Helper loaded: form_helper
INFO - 2016-11-04 01:09:49 --> Database Driver Class Initialized
INFO - 2016-11-04 01:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:09:49 --> Controller Class Initialized
DEBUG - 2016-11-04 01:09:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 01:09:49 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 98
ERROR - 2016-11-04 01:09:49 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 98
INFO - 2016-11-04 01:09:49 --> Config Class Initialized
INFO - 2016-11-04 01:09:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:09:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:09:49 --> Utf8 Class Initialized
INFO - 2016-11-04 01:09:49 --> URI Class Initialized
DEBUG - 2016-11-04 01:09:49 --> No URI present. Default controller set.
INFO - 2016-11-04 01:09:49 --> Router Class Initialized
INFO - 2016-11-04 01:09:49 --> Output Class Initialized
INFO - 2016-11-04 01:09:49 --> Security Class Initialized
DEBUG - 2016-11-04 01:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:09:49 --> Input Class Initialized
INFO - 2016-11-04 01:09:49 --> Language Class Initialized
INFO - 2016-11-04 01:09:49 --> Loader Class Initialized
INFO - 2016-11-04 01:09:49 --> Helper loaded: url_helper
INFO - 2016-11-04 01:09:49 --> Helper loaded: form_helper
INFO - 2016-11-04 01:09:49 --> Database Driver Class Initialized
INFO - 2016-11-04 01:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:09:49 --> Controller Class Initialized
INFO - 2016-11-04 01:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 01:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 01:09:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 01:09:49 --> Final output sent to browser
DEBUG - 2016-11-04 01:09:49 --> Total execution time: 0.2028
INFO - 2016-11-04 01:34:31 --> Config Class Initialized
INFO - 2016-11-04 01:34:31 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:34:31 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:34:31 --> Utf8 Class Initialized
INFO - 2016-11-04 01:34:31 --> URI Class Initialized
INFO - 2016-11-04 01:34:31 --> Router Class Initialized
INFO - 2016-11-04 01:34:32 --> Output Class Initialized
INFO - 2016-11-04 01:34:32 --> Security Class Initialized
DEBUG - 2016-11-04 01:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:34:32 --> Input Class Initialized
INFO - 2016-11-04 01:34:32 --> Language Class Initialized
INFO - 2016-11-04 01:34:32 --> Loader Class Initialized
INFO - 2016-11-04 01:34:32 --> Helper loaded: url_helper
INFO - 2016-11-04 01:34:32 --> Helper loaded: form_helper
INFO - 2016-11-04 01:34:32 --> Database Driver Class Initialized
INFO - 2016-11-04 01:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:34:33 --> Controller Class Initialized
DEBUG - 2016-11-04 01:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 01:34:33 --> Model Class Initialized
INFO - 2016-11-04 01:34:33 --> Final output sent to browser
DEBUG - 2016-11-04 01:34:33 --> Total execution time: 2.0045
INFO - 2016-11-04 01:34:33 --> Config Class Initialized
INFO - 2016-11-04 01:34:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 01:34:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 01:34:33 --> Utf8 Class Initialized
INFO - 2016-11-04 01:34:33 --> URI Class Initialized
DEBUG - 2016-11-04 01:34:33 --> No URI present. Default controller set.
INFO - 2016-11-04 01:34:33 --> Router Class Initialized
INFO - 2016-11-04 01:34:33 --> Output Class Initialized
INFO - 2016-11-04 01:34:33 --> Security Class Initialized
DEBUG - 2016-11-04 01:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 01:34:33 --> Input Class Initialized
INFO - 2016-11-04 01:34:33 --> Language Class Initialized
INFO - 2016-11-04 01:34:33 --> Loader Class Initialized
INFO - 2016-11-04 01:34:33 --> Helper loaded: url_helper
INFO - 2016-11-04 01:34:33 --> Helper loaded: form_helper
INFO - 2016-11-04 01:34:33 --> Database Driver Class Initialized
INFO - 2016-11-04 01:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 01:34:33 --> Controller Class Initialized
INFO - 2016-11-04 01:34:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 01:34:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 01:34:33 --> Model Class Initialized
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 01:34:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 01:34:34 --> Final output sent to browser
DEBUG - 2016-11-04 01:34:34 --> Total execution time: 1.0986
INFO - 2016-11-04 11:21:35 --> Config Class Initialized
INFO - 2016-11-04 11:21:35 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:21:35 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:21:35 --> Utf8 Class Initialized
INFO - 2016-11-04 11:21:35 --> URI Class Initialized
DEBUG - 2016-11-04 11:21:35 --> No URI present. Default controller set.
INFO - 2016-11-04 11:21:35 --> Router Class Initialized
INFO - 2016-11-04 11:21:35 --> Output Class Initialized
INFO - 2016-11-04 11:21:36 --> Security Class Initialized
DEBUG - 2016-11-04 11:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:21:36 --> Input Class Initialized
INFO - 2016-11-04 11:21:36 --> Language Class Initialized
INFO - 2016-11-04 11:21:36 --> Loader Class Initialized
INFO - 2016-11-04 11:21:36 --> Helper loaded: url_helper
INFO - 2016-11-04 11:21:36 --> Helper loaded: form_helper
INFO - 2016-11-04 11:21:36 --> Database Driver Class Initialized
INFO - 2016-11-04 11:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:21:36 --> Controller Class Initialized
INFO - 2016-11-04 11:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:21:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:21:36 --> Final output sent to browser
DEBUG - 2016-11-04 11:21:36 --> Total execution time: 1.6482
INFO - 2016-11-04 11:21:39 --> Config Class Initialized
INFO - 2016-11-04 11:21:39 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:21:39 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:21:39 --> Utf8 Class Initialized
INFO - 2016-11-04 11:21:39 --> URI Class Initialized
DEBUG - 2016-11-04 11:21:39 --> No URI present. Default controller set.
INFO - 2016-11-04 11:21:39 --> Router Class Initialized
INFO - 2016-11-04 11:21:39 --> Output Class Initialized
INFO - 2016-11-04 11:21:39 --> Security Class Initialized
DEBUG - 2016-11-04 11:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:21:39 --> Input Class Initialized
INFO - 2016-11-04 11:21:39 --> Language Class Initialized
INFO - 2016-11-04 11:21:39 --> Loader Class Initialized
INFO - 2016-11-04 11:21:39 --> Helper loaded: url_helper
INFO - 2016-11-04 11:21:39 --> Helper loaded: form_helper
INFO - 2016-11-04 11:21:39 --> Database Driver Class Initialized
INFO - 2016-11-04 11:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:21:39 --> Controller Class Initialized
INFO - 2016-11-04 11:21:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:21:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:21:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:21:39 --> Final output sent to browser
DEBUG - 2016-11-04 11:21:39 --> Total execution time: 0.2688
INFO - 2016-11-04 11:21:47 --> Config Class Initialized
INFO - 2016-11-04 11:21:48 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:21:48 --> Utf8 Class Initialized
INFO - 2016-11-04 11:21:48 --> URI Class Initialized
DEBUG - 2016-11-04 11:21:48 --> No URI present. Default controller set.
INFO - 2016-11-04 11:21:48 --> Router Class Initialized
INFO - 2016-11-04 11:21:48 --> Output Class Initialized
INFO - 2016-11-04 11:21:48 --> Security Class Initialized
DEBUG - 2016-11-04 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:21:48 --> Input Class Initialized
INFO - 2016-11-04 11:21:48 --> Language Class Initialized
INFO - 2016-11-04 11:21:48 --> Loader Class Initialized
INFO - 2016-11-04 11:21:48 --> Helper loaded: url_helper
INFO - 2016-11-04 11:21:48 --> Helper loaded: form_helper
INFO - 2016-11-04 11:21:48 --> Database Driver Class Initialized
INFO - 2016-11-04 11:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:21:48 --> Controller Class Initialized
INFO - 2016-11-04 11:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:21:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:21:48 --> Final output sent to browser
DEBUG - 2016-11-04 11:21:48 --> Total execution time: 0.2286
INFO - 2016-11-04 11:21:51 --> Config Class Initialized
INFO - 2016-11-04 11:21:51 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:21:51 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:21:51 --> Utf8 Class Initialized
INFO - 2016-11-04 11:21:51 --> URI Class Initialized
DEBUG - 2016-11-04 11:21:51 --> No URI present. Default controller set.
INFO - 2016-11-04 11:21:51 --> Router Class Initialized
INFO - 2016-11-04 11:21:51 --> Output Class Initialized
INFO - 2016-11-04 11:21:51 --> Security Class Initialized
DEBUG - 2016-11-04 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:21:51 --> Input Class Initialized
INFO - 2016-11-04 11:21:51 --> Language Class Initialized
INFO - 2016-11-04 11:21:51 --> Loader Class Initialized
INFO - 2016-11-04 11:21:51 --> Helper loaded: url_helper
INFO - 2016-11-04 11:21:51 --> Helper loaded: form_helper
INFO - 2016-11-04 11:21:51 --> Database Driver Class Initialized
INFO - 2016-11-04 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:21:51 --> Controller Class Initialized
INFO - 2016-11-04 11:21:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:21:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:21:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:21:51 --> Final output sent to browser
DEBUG - 2016-11-04 11:21:51 --> Total execution time: 0.2296
INFO - 2016-11-04 11:21:59 --> Config Class Initialized
INFO - 2016-11-04 11:21:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:21:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:21:59 --> Utf8 Class Initialized
INFO - 2016-11-04 11:21:59 --> URI Class Initialized
DEBUG - 2016-11-04 11:21:59 --> No URI present. Default controller set.
INFO - 2016-11-04 11:21:59 --> Router Class Initialized
INFO - 2016-11-04 11:21:59 --> Output Class Initialized
INFO - 2016-11-04 11:21:59 --> Security Class Initialized
DEBUG - 2016-11-04 11:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:21:59 --> Input Class Initialized
INFO - 2016-11-04 11:21:59 --> Language Class Initialized
INFO - 2016-11-04 11:21:59 --> Loader Class Initialized
INFO - 2016-11-04 11:21:59 --> Helper loaded: url_helper
INFO - 2016-11-04 11:21:59 --> Helper loaded: form_helper
INFO - 2016-11-04 11:21:59 --> Database Driver Class Initialized
INFO - 2016-11-04 11:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:21:59 --> Controller Class Initialized
INFO - 2016-11-04 11:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:21:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:21:59 --> Final output sent to browser
DEBUG - 2016-11-04 11:21:59 --> Total execution time: 0.2265
INFO - 2016-11-04 11:22:35 --> Config Class Initialized
INFO - 2016-11-04 11:22:35 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:22:35 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:22:35 --> Utf8 Class Initialized
INFO - 2016-11-04 11:22:35 --> URI Class Initialized
DEBUG - 2016-11-04 11:22:35 --> No URI present. Default controller set.
INFO - 2016-11-04 11:22:35 --> Router Class Initialized
INFO - 2016-11-04 11:22:35 --> Output Class Initialized
INFO - 2016-11-04 11:22:35 --> Security Class Initialized
DEBUG - 2016-11-04 11:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:22:35 --> Input Class Initialized
INFO - 2016-11-04 11:22:35 --> Language Class Initialized
INFO - 2016-11-04 11:22:35 --> Loader Class Initialized
INFO - 2016-11-04 11:22:35 --> Helper loaded: url_helper
INFO - 2016-11-04 11:22:35 --> Helper loaded: form_helper
INFO - 2016-11-04 11:22:35 --> Database Driver Class Initialized
INFO - 2016-11-04 11:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:22:35 --> Controller Class Initialized
INFO - 2016-11-04 11:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:22:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:22:35 --> Final output sent to browser
DEBUG - 2016-11-04 11:22:35 --> Total execution time: 0.2049
INFO - 2016-11-04 11:22:54 --> Config Class Initialized
INFO - 2016-11-04 11:22:54 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:22:54 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:22:54 --> Utf8 Class Initialized
INFO - 2016-11-04 11:22:54 --> URI Class Initialized
DEBUG - 2016-11-04 11:22:54 --> No URI present. Default controller set.
INFO - 2016-11-04 11:22:54 --> Router Class Initialized
INFO - 2016-11-04 11:22:54 --> Output Class Initialized
INFO - 2016-11-04 11:22:54 --> Security Class Initialized
DEBUG - 2016-11-04 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:22:54 --> Input Class Initialized
INFO - 2016-11-04 11:22:54 --> Language Class Initialized
INFO - 2016-11-04 11:22:54 --> Loader Class Initialized
INFO - 2016-11-04 11:22:54 --> Helper loaded: url_helper
INFO - 2016-11-04 11:22:54 --> Helper loaded: form_helper
INFO - 2016-11-04 11:22:54 --> Database Driver Class Initialized
INFO - 2016-11-04 11:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:22:54 --> Controller Class Initialized
INFO - 2016-11-04 11:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 11:22:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:22:54 --> Final output sent to browser
DEBUG - 2016-11-04 11:22:54 --> Total execution time: 0.1857
INFO - 2016-11-04 11:23:01 --> Config Class Initialized
INFO - 2016-11-04 11:23:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:23:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:23:01 --> Utf8 Class Initialized
INFO - 2016-11-04 11:23:01 --> URI Class Initialized
INFO - 2016-11-04 11:23:01 --> Router Class Initialized
INFO - 2016-11-04 11:23:01 --> Output Class Initialized
INFO - 2016-11-04 11:23:01 --> Security Class Initialized
DEBUG - 2016-11-04 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:23:01 --> Input Class Initialized
INFO - 2016-11-04 11:23:01 --> Language Class Initialized
INFO - 2016-11-04 11:23:01 --> Loader Class Initialized
INFO - 2016-11-04 11:23:01 --> Helper loaded: url_helper
INFO - 2016-11-04 11:23:01 --> Helper loaded: form_helper
INFO - 2016-11-04 11:23:01 --> Database Driver Class Initialized
INFO - 2016-11-04 11:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:23:01 --> Controller Class Initialized
DEBUG - 2016-11-04 11:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 11:23:01 --> Model Class Initialized
INFO - 2016-11-04 11:23:01 --> Final output sent to browser
DEBUG - 2016-11-04 11:23:01 --> Total execution time: 0.4422
INFO - 2016-11-04 11:23:01 --> Config Class Initialized
INFO - 2016-11-04 11:23:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:23:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:23:01 --> Utf8 Class Initialized
INFO - 2016-11-04 11:23:01 --> URI Class Initialized
DEBUG - 2016-11-04 11:23:01 --> No URI present. Default controller set.
INFO - 2016-11-04 11:23:01 --> Router Class Initialized
INFO - 2016-11-04 11:23:01 --> Output Class Initialized
INFO - 2016-11-04 11:23:01 --> Security Class Initialized
DEBUG - 2016-11-04 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:23:01 --> Input Class Initialized
INFO - 2016-11-04 11:23:01 --> Language Class Initialized
INFO - 2016-11-04 11:23:01 --> Loader Class Initialized
INFO - 2016-11-04 11:23:01 --> Helper loaded: url_helper
INFO - 2016-11-04 11:23:01 --> Helper loaded: form_helper
INFO - 2016-11-04 11:23:01 --> Database Driver Class Initialized
INFO - 2016-11-04 11:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:23:01 --> Controller Class Initialized
INFO - 2016-11-04 11:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:23:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:23:02 --> Model Class Initialized
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:23:02 --> Final output sent to browser
DEBUG - 2016-11-04 11:23:02 --> Total execution time: 0.4826
INFO - 2016-11-04 11:45:49 --> Config Class Initialized
INFO - 2016-11-04 11:45:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:45:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:45:49 --> Utf8 Class Initialized
INFO - 2016-11-04 11:45:49 --> URI Class Initialized
DEBUG - 2016-11-04 11:45:49 --> No URI present. Default controller set.
INFO - 2016-11-04 11:45:49 --> Router Class Initialized
INFO - 2016-11-04 11:45:49 --> Output Class Initialized
INFO - 2016-11-04 11:45:49 --> Security Class Initialized
DEBUG - 2016-11-04 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:45:49 --> Input Class Initialized
INFO - 2016-11-04 11:45:49 --> Language Class Initialized
INFO - 2016-11-04 11:45:49 --> Loader Class Initialized
INFO - 2016-11-04 11:45:49 --> Helper loaded: url_helper
INFO - 2016-11-04 11:45:49 --> Helper loaded: form_helper
INFO - 2016-11-04 11:45:49 --> Database Driver Class Initialized
INFO - 2016-11-04 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:45:49 --> Controller Class Initialized
INFO - 2016-11-04 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:45:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:45:49 --> Model Class Initialized
ERROR - 2016-11-04 11:45:50 --> Severity: Error --> Call to undefined method Leave_type_m::all_Employee() C:\xampp\htdocs\LMS\app\controllers\Auth.php 52
INFO - 2016-11-04 11:46:32 --> Config Class Initialized
INFO - 2016-11-04 11:46:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:46:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:46:32 --> Utf8 Class Initialized
INFO - 2016-11-04 11:46:32 --> URI Class Initialized
DEBUG - 2016-11-04 11:46:32 --> No URI present. Default controller set.
INFO - 2016-11-04 11:46:32 --> Router Class Initialized
INFO - 2016-11-04 11:46:32 --> Output Class Initialized
INFO - 2016-11-04 11:46:32 --> Security Class Initialized
DEBUG - 2016-11-04 11:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:46:32 --> Input Class Initialized
INFO - 2016-11-04 11:46:32 --> Language Class Initialized
ERROR - 2016-11-04 11:46:32 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Auth.php 50
INFO - 2016-11-04 11:46:33 --> Config Class Initialized
INFO - 2016-11-04 11:46:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:46:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:46:33 --> Utf8 Class Initialized
INFO - 2016-11-04 11:46:33 --> URI Class Initialized
DEBUG - 2016-11-04 11:46:33 --> No URI present. Default controller set.
INFO - 2016-11-04 11:46:33 --> Router Class Initialized
INFO - 2016-11-04 11:46:33 --> Output Class Initialized
INFO - 2016-11-04 11:46:33 --> Security Class Initialized
DEBUG - 2016-11-04 11:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:46:33 --> Input Class Initialized
INFO - 2016-11-04 11:46:33 --> Language Class Initialized
ERROR - 2016-11-04 11:46:33 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\LMS\app\controllers\Auth.php 50
INFO - 2016-11-04 11:46:50 --> Config Class Initialized
INFO - 2016-11-04 11:46:50 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:46:50 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:46:50 --> Utf8 Class Initialized
INFO - 2016-11-04 11:46:50 --> URI Class Initialized
DEBUG - 2016-11-04 11:46:50 --> No URI present. Default controller set.
INFO - 2016-11-04 11:46:50 --> Router Class Initialized
INFO - 2016-11-04 11:46:50 --> Output Class Initialized
INFO - 2016-11-04 11:46:50 --> Security Class Initialized
DEBUG - 2016-11-04 11:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:46:50 --> Input Class Initialized
INFO - 2016-11-04 11:46:50 --> Language Class Initialized
INFO - 2016-11-04 11:46:50 --> Loader Class Initialized
INFO - 2016-11-04 11:46:50 --> Helper loaded: url_helper
INFO - 2016-11-04 11:46:50 --> Helper loaded: form_helper
INFO - 2016-11-04 11:46:50 --> Database Driver Class Initialized
INFO - 2016-11-04 11:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:46:50 --> Controller Class Initialized
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:46:50 --> Model Class Initialized
INFO - 2016-11-04 11:46:50 --> Model Class Initialized
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:46:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:46:50 --> Final output sent to browser
DEBUG - 2016-11-04 11:46:50 --> Total execution time: 0.2770
INFO - 2016-11-04 11:47:21 --> Config Class Initialized
INFO - 2016-11-04 11:47:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:47:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:47:21 --> Utf8 Class Initialized
INFO - 2016-11-04 11:47:21 --> URI Class Initialized
INFO - 2016-11-04 11:47:21 --> Router Class Initialized
INFO - 2016-11-04 11:47:21 --> Output Class Initialized
INFO - 2016-11-04 11:47:21 --> Security Class Initialized
DEBUG - 2016-11-04 11:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:47:21 --> Input Class Initialized
INFO - 2016-11-04 11:47:21 --> Language Class Initialized
INFO - 2016-11-04 11:47:21 --> Loader Class Initialized
INFO - 2016-11-04 11:47:21 --> Helper loaded: url_helper
INFO - 2016-11-04 11:47:21 --> Helper loaded: form_helper
INFO - 2016-11-04 11:47:21 --> Database Driver Class Initialized
INFO - 2016-11-04 11:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:47:21 --> Controller Class Initialized
INFO - 2016-11-04 11:47:21 --> Form Validation Class Initialized
INFO - 2016-11-04 11:47:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 11:47:21 --> Final output sent to browser
DEBUG - 2016-11-04 11:47:21 --> Total execution time: 0.2607
INFO - 2016-11-04 11:47:23 --> Config Class Initialized
INFO - 2016-11-04 11:47:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:47:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:47:23 --> Utf8 Class Initialized
INFO - 2016-11-04 11:47:23 --> URI Class Initialized
DEBUG - 2016-11-04 11:47:23 --> No URI present. Default controller set.
INFO - 2016-11-04 11:47:23 --> Router Class Initialized
INFO - 2016-11-04 11:47:23 --> Output Class Initialized
INFO - 2016-11-04 11:47:23 --> Security Class Initialized
DEBUG - 2016-11-04 11:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:47:23 --> Input Class Initialized
INFO - 2016-11-04 11:47:23 --> Language Class Initialized
INFO - 2016-11-04 11:47:23 --> Loader Class Initialized
INFO - 2016-11-04 11:47:23 --> Helper loaded: url_helper
INFO - 2016-11-04 11:47:23 --> Helper loaded: form_helper
INFO - 2016-11-04 11:47:23 --> Database Driver Class Initialized
INFO - 2016-11-04 11:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:47:23 --> Controller Class Initialized
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:47:23 --> Model Class Initialized
INFO - 2016-11-04 11:47:23 --> Model Class Initialized
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:47:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:47:23 --> Final output sent to browser
DEBUG - 2016-11-04 11:47:23 --> Total execution time: 0.2821
INFO - 2016-11-04 11:51:03 --> Config Class Initialized
INFO - 2016-11-04 11:51:03 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:51:03 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:51:03 --> Utf8 Class Initialized
INFO - 2016-11-04 11:51:03 --> URI Class Initialized
DEBUG - 2016-11-04 11:51:03 --> No URI present. Default controller set.
INFO - 2016-11-04 11:51:03 --> Router Class Initialized
INFO - 2016-11-04 11:51:03 --> Output Class Initialized
INFO - 2016-11-04 11:51:03 --> Security Class Initialized
DEBUG - 2016-11-04 11:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:51:03 --> Input Class Initialized
INFO - 2016-11-04 11:51:03 --> Language Class Initialized
INFO - 2016-11-04 11:51:03 --> Loader Class Initialized
INFO - 2016-11-04 11:51:03 --> Helper loaded: url_helper
INFO - 2016-11-04 11:51:03 --> Helper loaded: form_helper
INFO - 2016-11-04 11:51:03 --> Database Driver Class Initialized
INFO - 2016-11-04 11:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:51:03 --> Controller Class Initialized
INFO - 2016-11-04 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:51:03 --> Model Class Initialized
INFO - 2016-11-04 11:51:03 --> Model Class Initialized
INFO - 2016-11-04 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:51:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:51:03 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 13
ERROR - 2016-11-04 11:51:03 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 13
INFO - 2016-11-04 11:52:25 --> Config Class Initialized
INFO - 2016-11-04 11:52:25 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:52:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:52:25 --> Utf8 Class Initialized
INFO - 2016-11-04 11:52:25 --> URI Class Initialized
DEBUG - 2016-11-04 11:52:25 --> No URI present. Default controller set.
INFO - 2016-11-04 11:52:25 --> Router Class Initialized
INFO - 2016-11-04 11:52:25 --> Output Class Initialized
INFO - 2016-11-04 11:52:25 --> Security Class Initialized
DEBUG - 2016-11-04 11:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:52:25 --> Input Class Initialized
INFO - 2016-11-04 11:52:25 --> Language Class Initialized
INFO - 2016-11-04 11:52:25 --> Loader Class Initialized
INFO - 2016-11-04 11:52:25 --> Helper loaded: url_helper
INFO - 2016-11-04 11:52:25 --> Helper loaded: form_helper
INFO - 2016-11-04 11:52:25 --> Database Driver Class Initialized
INFO - 2016-11-04 11:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:52:25 --> Controller Class Initialized
INFO - 2016-11-04 11:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:52:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:52:26 --> Model Class Initialized
INFO - 2016-11-04 11:52:26 --> Model Class Initialized
INFO - 2016-11-04 11:52:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:52:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:52:26 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 13
ERROR - 2016-11-04 11:52:26 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 13
INFO - 2016-11-04 11:52:27 --> Config Class Initialized
INFO - 2016-11-04 11:52:27 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:52:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:52:27 --> Utf8 Class Initialized
INFO - 2016-11-04 11:52:27 --> URI Class Initialized
DEBUG - 2016-11-04 11:52:27 --> No URI present. Default controller set.
INFO - 2016-11-04 11:52:27 --> Router Class Initialized
INFO - 2016-11-04 11:52:27 --> Output Class Initialized
INFO - 2016-11-04 11:52:27 --> Security Class Initialized
DEBUG - 2016-11-04 11:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:52:27 --> Input Class Initialized
INFO - 2016-11-04 11:52:27 --> Language Class Initialized
INFO - 2016-11-04 11:52:27 --> Loader Class Initialized
INFO - 2016-11-04 11:52:27 --> Helper loaded: url_helper
INFO - 2016-11-04 11:52:27 --> Helper loaded: form_helper
INFO - 2016-11-04 11:52:27 --> Database Driver Class Initialized
INFO - 2016-11-04 11:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:52:27 --> Controller Class Initialized
INFO - 2016-11-04 11:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:52:27 --> Model Class Initialized
INFO - 2016-11-04 11:52:27 --> Model Class Initialized
INFO - 2016-11-04 11:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:52:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:52:27 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 13
ERROR - 2016-11-04 11:52:27 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 13
INFO - 2016-11-04 11:52:55 --> Config Class Initialized
INFO - 2016-11-04 11:52:55 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:52:55 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:52:55 --> Utf8 Class Initialized
INFO - 2016-11-04 11:52:55 --> URI Class Initialized
DEBUG - 2016-11-04 11:52:55 --> No URI present. Default controller set.
INFO - 2016-11-04 11:52:55 --> Router Class Initialized
INFO - 2016-11-04 11:52:55 --> Output Class Initialized
INFO - 2016-11-04 11:52:55 --> Security Class Initialized
DEBUG - 2016-11-04 11:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:52:55 --> Input Class Initialized
INFO - 2016-11-04 11:52:55 --> Language Class Initialized
INFO - 2016-11-04 11:52:55 --> Loader Class Initialized
INFO - 2016-11-04 11:52:55 --> Helper loaded: url_helper
INFO - 2016-11-04 11:52:55 --> Helper loaded: form_helper
INFO - 2016-11-04 11:52:55 --> Database Driver Class Initialized
INFO - 2016-11-04 11:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:52:55 --> Controller Class Initialized
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:52:55 --> Model Class Initialized
INFO - 2016-11-04 11:52:55 --> Model Class Initialized
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:52:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:52:55 --> Final output sent to browser
DEBUG - 2016-11-04 11:52:55 --> Total execution time: 0.2706
INFO - 2016-11-04 11:53:01 --> Config Class Initialized
INFO - 2016-11-04 11:53:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:53:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:53:01 --> Utf8 Class Initialized
INFO - 2016-11-04 11:53:01 --> URI Class Initialized
DEBUG - 2016-11-04 11:53:01 --> No URI present. Default controller set.
INFO - 2016-11-04 11:53:01 --> Router Class Initialized
INFO - 2016-11-04 11:53:01 --> Output Class Initialized
INFO - 2016-11-04 11:53:01 --> Security Class Initialized
DEBUG - 2016-11-04 11:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:53:01 --> Input Class Initialized
INFO - 2016-11-04 11:53:01 --> Language Class Initialized
INFO - 2016-11-04 11:53:01 --> Loader Class Initialized
INFO - 2016-11-04 11:53:01 --> Helper loaded: url_helper
INFO - 2016-11-04 11:53:01 --> Helper loaded: form_helper
INFO - 2016-11-04 11:53:01 --> Database Driver Class Initialized
INFO - 2016-11-04 11:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:53:01 --> Controller Class Initialized
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:53:01 --> Model Class Initialized
INFO - 2016-11-04 11:53:01 --> Model Class Initialized
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:53:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:53:01 --> Final output sent to browser
DEBUG - 2016-11-04 11:53:01 --> Total execution time: 0.3304
INFO - 2016-11-04 11:53:17 --> Config Class Initialized
INFO - 2016-11-04 11:53:17 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:53:17 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:53:17 --> Utf8 Class Initialized
INFO - 2016-11-04 11:53:17 --> URI Class Initialized
INFO - 2016-11-04 11:53:17 --> Router Class Initialized
INFO - 2016-11-04 11:53:17 --> Output Class Initialized
INFO - 2016-11-04 11:53:17 --> Security Class Initialized
DEBUG - 2016-11-04 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:53:17 --> Input Class Initialized
INFO - 2016-11-04 11:53:17 --> Language Class Initialized
INFO - 2016-11-04 11:53:17 --> Loader Class Initialized
INFO - 2016-11-04 11:53:17 --> Helper loaded: url_helper
INFO - 2016-11-04 11:53:17 --> Helper loaded: form_helper
INFO - 2016-11-04 11:53:17 --> Database Driver Class Initialized
INFO - 2016-11-04 11:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:53:17 --> Controller Class Initialized
INFO - 2016-11-04 11:53:17 --> Form Validation Class Initialized
INFO - 2016-11-04 11:53:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 11:53:17 --> Final output sent to browser
DEBUG - 2016-11-04 11:53:17 --> Total execution time: 0.1834
INFO - 2016-11-04 11:53:18 --> Config Class Initialized
INFO - 2016-11-04 11:53:18 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:53:18 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:53:18 --> Utf8 Class Initialized
INFO - 2016-11-04 11:53:18 --> URI Class Initialized
DEBUG - 2016-11-04 11:53:18 --> No URI present. Default controller set.
INFO - 2016-11-04 11:53:18 --> Router Class Initialized
INFO - 2016-11-04 11:53:18 --> Output Class Initialized
INFO - 2016-11-04 11:53:18 --> Security Class Initialized
DEBUG - 2016-11-04 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:53:18 --> Input Class Initialized
INFO - 2016-11-04 11:53:18 --> Language Class Initialized
INFO - 2016-11-04 11:53:18 --> Loader Class Initialized
INFO - 2016-11-04 11:53:19 --> Helper loaded: url_helper
INFO - 2016-11-04 11:53:19 --> Helper loaded: form_helper
INFO - 2016-11-04 11:53:19 --> Database Driver Class Initialized
INFO - 2016-11-04 11:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:53:19 --> Controller Class Initialized
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:53:19 --> Model Class Initialized
INFO - 2016-11-04 11:53:19 --> Model Class Initialized
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:53:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:53:19 --> Final output sent to browser
DEBUG - 2016-11-04 11:53:19 --> Total execution time: 0.3281
INFO - 2016-11-04 11:53:46 --> Config Class Initialized
INFO - 2016-11-04 11:53:46 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:53:46 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:53:46 --> Utf8 Class Initialized
INFO - 2016-11-04 11:53:46 --> URI Class Initialized
DEBUG - 2016-11-04 11:53:46 --> No URI present. Default controller set.
INFO - 2016-11-04 11:53:46 --> Router Class Initialized
INFO - 2016-11-04 11:53:46 --> Output Class Initialized
INFO - 2016-11-04 11:53:46 --> Security Class Initialized
DEBUG - 2016-11-04 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:53:46 --> Input Class Initialized
INFO - 2016-11-04 11:53:46 --> Language Class Initialized
INFO - 2016-11-04 11:53:46 --> Loader Class Initialized
INFO - 2016-11-04 11:53:46 --> Helper loaded: url_helper
INFO - 2016-11-04 11:53:46 --> Helper loaded: form_helper
INFO - 2016-11-04 11:53:46 --> Database Driver Class Initialized
INFO - 2016-11-04 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:53:46 --> Controller Class Initialized
INFO - 2016-11-04 11:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:53:46 --> Model Class Initialized
INFO - 2016-11-04 11:53:46 --> Model Class Initialized
INFO - 2016-11-04 11:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:53:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:53:46 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 12
ERROR - 2016-11-04 11:53:46 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 12
INFO - 2016-11-04 11:55:39 --> Config Class Initialized
INFO - 2016-11-04 11:55:39 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:55:39 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:55:39 --> Utf8 Class Initialized
INFO - 2016-11-04 11:55:39 --> URI Class Initialized
DEBUG - 2016-11-04 11:55:39 --> No URI present. Default controller set.
INFO - 2016-11-04 11:55:39 --> Router Class Initialized
INFO - 2016-11-04 11:55:39 --> Output Class Initialized
INFO - 2016-11-04 11:55:39 --> Security Class Initialized
DEBUG - 2016-11-04 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:55:39 --> Input Class Initialized
INFO - 2016-11-04 11:55:39 --> Language Class Initialized
INFO - 2016-11-04 11:55:39 --> Loader Class Initialized
INFO - 2016-11-04 11:55:40 --> Helper loaded: url_helper
INFO - 2016-11-04 11:55:40 --> Helper loaded: form_helper
INFO - 2016-11-04 11:55:40 --> Database Driver Class Initialized
INFO - 2016-11-04 11:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:55:40 --> Controller Class Initialized
INFO - 2016-11-04 11:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:55:40 --> Model Class Initialized
INFO - 2016-11-04 11:55:40 --> Model Class Initialized
INFO - 2016-11-04 11:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:55:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:55:40 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 12
ERROR - 2016-11-04 11:55:40 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 12
INFO - 2016-11-04 11:55:41 --> Config Class Initialized
INFO - 2016-11-04 11:55:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:55:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:55:41 --> Utf8 Class Initialized
INFO - 2016-11-04 11:55:41 --> URI Class Initialized
DEBUG - 2016-11-04 11:55:41 --> No URI present. Default controller set.
INFO - 2016-11-04 11:55:41 --> Router Class Initialized
INFO - 2016-11-04 11:55:41 --> Output Class Initialized
INFO - 2016-11-04 11:55:41 --> Security Class Initialized
DEBUG - 2016-11-04 11:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:55:41 --> Input Class Initialized
INFO - 2016-11-04 11:55:41 --> Language Class Initialized
INFO - 2016-11-04 11:55:41 --> Loader Class Initialized
INFO - 2016-11-04 11:55:41 --> Helper loaded: url_helper
INFO - 2016-11-04 11:55:41 --> Helper loaded: form_helper
INFO - 2016-11-04 11:55:41 --> Database Driver Class Initialized
INFO - 2016-11-04 11:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:55:41 --> Controller Class Initialized
INFO - 2016-11-04 11:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:55:41 --> Model Class Initialized
INFO - 2016-11-04 11:55:41 --> Model Class Initialized
INFO - 2016-11-04 11:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:55:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:55:41 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 12
ERROR - 2016-11-04 11:55:41 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 12
INFO - 2016-11-04 11:58:17 --> Config Class Initialized
INFO - 2016-11-04 11:58:17 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:58:17 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:58:17 --> Utf8 Class Initialized
INFO - 2016-11-04 11:58:17 --> URI Class Initialized
DEBUG - 2016-11-04 11:58:17 --> No URI present. Default controller set.
INFO - 2016-11-04 11:58:17 --> Router Class Initialized
INFO - 2016-11-04 11:58:17 --> Output Class Initialized
INFO - 2016-11-04 11:58:17 --> Security Class Initialized
DEBUG - 2016-11-04 11:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:58:17 --> Input Class Initialized
INFO - 2016-11-04 11:58:17 --> Language Class Initialized
INFO - 2016-11-04 11:58:17 --> Loader Class Initialized
INFO - 2016-11-04 11:58:17 --> Helper loaded: url_helper
INFO - 2016-11-04 11:58:17 --> Helper loaded: form_helper
INFO - 2016-11-04 11:58:17 --> Database Driver Class Initialized
INFO - 2016-11-04 11:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:58:17 --> Controller Class Initialized
INFO - 2016-11-04 11:58:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:58:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:58:17 --> Model Class Initialized
INFO - 2016-11-04 11:58:17 --> Model Class Initialized
INFO - 2016-11-04 11:58:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:58:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:58:17 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 15
ERROR - 2016-11-04 11:58:17 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 11:58:17 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 15
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 15
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 11:58:18 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:58:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:58:18 --> Final output sent to browser
DEBUG - 2016-11-04 11:58:18 --> Total execution time: 0.3830
INFO - 2016-11-04 11:59:41 --> Config Class Initialized
INFO - 2016-11-04 11:59:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 11:59:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 11:59:41 --> Utf8 Class Initialized
INFO - 2016-11-04 11:59:41 --> URI Class Initialized
DEBUG - 2016-11-04 11:59:41 --> No URI present. Default controller set.
INFO - 2016-11-04 11:59:41 --> Router Class Initialized
INFO - 2016-11-04 11:59:41 --> Output Class Initialized
INFO - 2016-11-04 11:59:41 --> Security Class Initialized
DEBUG - 2016-11-04 11:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 11:59:41 --> Input Class Initialized
INFO - 2016-11-04 11:59:41 --> Language Class Initialized
INFO - 2016-11-04 11:59:41 --> Loader Class Initialized
INFO - 2016-11-04 11:59:41 --> Helper loaded: url_helper
INFO - 2016-11-04 11:59:41 --> Helper loaded: form_helper
INFO - 2016-11-04 11:59:41 --> Database Driver Class Initialized
INFO - 2016-11-04 11:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 11:59:41 --> Controller Class Initialized
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 11:59:41 --> Model Class Initialized
INFO - 2016-11-04 11:59:41 --> Model Class Initialized
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 19
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 19
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 11:59:41 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 19
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 11:59:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 11:59:41 --> Final output sent to browser
DEBUG - 2016-11-04 11:59:41 --> Total execution time: 0.3978
INFO - 2016-11-04 12:05:04 --> Config Class Initialized
INFO - 2016-11-04 12:05:04 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:05:04 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:05:04 --> Utf8 Class Initialized
INFO - 2016-11-04 12:05:04 --> URI Class Initialized
DEBUG - 2016-11-04 12:05:04 --> No URI present. Default controller set.
INFO - 2016-11-04 12:05:04 --> Router Class Initialized
INFO - 2016-11-04 12:05:04 --> Output Class Initialized
INFO - 2016-11-04 12:05:04 --> Security Class Initialized
DEBUG - 2016-11-04 12:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:05:04 --> Input Class Initialized
INFO - 2016-11-04 12:05:04 --> Language Class Initialized
INFO - 2016-11-04 12:05:04 --> Loader Class Initialized
INFO - 2016-11-04 12:05:04 --> Helper loaded: url_helper
INFO - 2016-11-04 12:05:04 --> Helper loaded: form_helper
INFO - 2016-11-04 12:05:04 --> Database Driver Class Initialized
INFO - 2016-11-04 12:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:05:04 --> Controller Class Initialized
INFO - 2016-11-04 12:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:05:04 --> Model Class Initialized
INFO - 2016-11-04 12:05:04 --> Model Class Initialized
INFO - 2016-11-04 12:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:05:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 19
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 19
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 16
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 17
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 18
ERROR - 2016-11-04 12:05:04 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 19
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:05:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:05:05 --> Final output sent to browser
DEBUG - 2016-11-04 12:05:05 --> Total execution time: 0.4565
INFO - 2016-11-04 12:18:37 --> Config Class Initialized
INFO - 2016-11-04 12:18:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:18:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:18:37 --> Utf8 Class Initialized
INFO - 2016-11-04 12:18:37 --> URI Class Initialized
DEBUG - 2016-11-04 12:18:37 --> No URI present. Default controller set.
INFO - 2016-11-04 12:18:37 --> Router Class Initialized
INFO - 2016-11-04 12:18:37 --> Output Class Initialized
INFO - 2016-11-04 12:18:37 --> Security Class Initialized
DEBUG - 2016-11-04 12:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:18:37 --> Input Class Initialized
INFO - 2016-11-04 12:18:37 --> Language Class Initialized
INFO - 2016-11-04 12:18:37 --> Loader Class Initialized
INFO - 2016-11-04 12:18:37 --> Helper loaded: url_helper
INFO - 2016-11-04 12:18:37 --> Helper loaded: form_helper
INFO - 2016-11-04 12:18:37 --> Database Driver Class Initialized
INFO - 2016-11-04 12:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:18:37 --> Controller Class Initialized
INFO - 2016-11-04 12:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:18:37 --> Model Class Initialized
INFO - 2016-11-04 12:18:37 --> Model Class Initialized
INFO - 2016-11-04 12:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:18:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:18:38 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:18:38 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:18:38 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:18:38 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:18:38 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:18:38 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:18:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:18:38 --> Final output sent to browser
DEBUG - 2016-11-04 12:18:38 --> Total execution time: 0.5319
INFO - 2016-11-04 12:21:07 --> Config Class Initialized
INFO - 2016-11-04 12:21:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:21:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:21:07 --> Utf8 Class Initialized
INFO - 2016-11-04 12:21:07 --> URI Class Initialized
DEBUG - 2016-11-04 12:21:07 --> No URI present. Default controller set.
INFO - 2016-11-04 12:21:07 --> Router Class Initialized
INFO - 2016-11-04 12:21:07 --> Output Class Initialized
INFO - 2016-11-04 12:21:07 --> Security Class Initialized
DEBUG - 2016-11-04 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:21:07 --> Input Class Initialized
INFO - 2016-11-04 12:21:08 --> Language Class Initialized
INFO - 2016-11-04 12:21:08 --> Loader Class Initialized
INFO - 2016-11-04 12:21:08 --> Helper loaded: url_helper
INFO - 2016-11-04 12:21:08 --> Helper loaded: form_helper
INFO - 2016-11-04 12:21:08 --> Database Driver Class Initialized
INFO - 2016-11-04 12:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:21:08 --> Controller Class Initialized
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:21:08 --> Model Class Initialized
INFO - 2016-11-04 12:21:08 --> Model Class Initialized
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:21:08 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:21:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:21:08 --> Final output sent to browser
DEBUG - 2016-11-04 12:21:08 --> Total execution time: 0.5571
INFO - 2016-11-04 12:22:13 --> Config Class Initialized
INFO - 2016-11-04 12:22:13 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:22:13 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:22:13 --> Utf8 Class Initialized
INFO - 2016-11-04 12:22:13 --> URI Class Initialized
INFO - 2016-11-04 12:22:13 --> Router Class Initialized
INFO - 2016-11-04 12:22:13 --> Output Class Initialized
INFO - 2016-11-04 12:22:13 --> Security Class Initialized
DEBUG - 2016-11-04 12:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:22:13 --> Input Class Initialized
INFO - 2016-11-04 12:22:13 --> Language Class Initialized
INFO - 2016-11-04 12:22:13 --> Loader Class Initialized
INFO - 2016-11-04 12:22:13 --> Helper loaded: url_helper
INFO - 2016-11-04 12:22:13 --> Helper loaded: form_helper
INFO - 2016-11-04 12:22:13 --> Database Driver Class Initialized
INFO - 2016-11-04 12:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:22:13 --> Controller Class Initialized
INFO - 2016-11-04 12:22:13 --> Form Validation Class Initialized
INFO - 2016-11-04 12:22:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 12:22:13 --> Final output sent to browser
DEBUG - 2016-11-04 12:22:13 --> Total execution time: 0.1927
INFO - 2016-11-04 12:22:15 --> Config Class Initialized
INFO - 2016-11-04 12:22:15 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:22:15 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:22:15 --> Utf8 Class Initialized
INFO - 2016-11-04 12:22:16 --> URI Class Initialized
INFO - 2016-11-04 12:22:16 --> Router Class Initialized
INFO - 2016-11-04 12:22:16 --> Output Class Initialized
INFO - 2016-11-04 12:22:16 --> Security Class Initialized
DEBUG - 2016-11-04 12:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:22:16 --> Input Class Initialized
INFO - 2016-11-04 12:22:16 --> Language Class Initialized
INFO - 2016-11-04 12:22:16 --> Loader Class Initialized
INFO - 2016-11-04 12:22:16 --> Helper loaded: url_helper
INFO - 2016-11-04 12:22:16 --> Helper loaded: form_helper
INFO - 2016-11-04 12:22:16 --> Database Driver Class Initialized
INFO - 2016-11-04 12:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:22:16 --> Controller Class Initialized
INFO - 2016-11-04 12:22:16 --> Form Validation Class Initialized
INFO - 2016-11-04 12:22:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 12:22:16 --> Final output sent to browser
DEBUG - 2016-11-04 12:22:16 --> Total execution time: 0.1990
INFO - 2016-11-04 12:22:17 --> Config Class Initialized
INFO - 2016-11-04 12:22:17 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:22:17 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:22:17 --> Utf8 Class Initialized
INFO - 2016-11-04 12:22:17 --> URI Class Initialized
DEBUG - 2016-11-04 12:22:17 --> No URI present. Default controller set.
INFO - 2016-11-04 12:22:17 --> Router Class Initialized
INFO - 2016-11-04 12:22:17 --> Output Class Initialized
INFO - 2016-11-04 12:22:17 --> Security Class Initialized
DEBUG - 2016-11-04 12:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:22:17 --> Input Class Initialized
INFO - 2016-11-04 12:22:17 --> Language Class Initialized
INFO - 2016-11-04 12:22:17 --> Loader Class Initialized
INFO - 2016-11-04 12:22:17 --> Helper loaded: url_helper
INFO - 2016-11-04 12:22:17 --> Helper loaded: form_helper
INFO - 2016-11-04 12:22:17 --> Database Driver Class Initialized
INFO - 2016-11-04 12:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:22:17 --> Controller Class Initialized
INFO - 2016-11-04 12:22:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:22:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:22:17 --> Model Class Initialized
INFO - 2016-11-04 12:22:17 --> Model Class Initialized
INFO - 2016-11-04 12:22:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:22:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:22:17 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:22:18 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:22:18 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:22:18 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:22:18 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:22:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:22:18 --> Final output sent to browser
DEBUG - 2016-11-04 12:22:18 --> Total execution time: 0.6282
INFO - 2016-11-04 12:23:01 --> Config Class Initialized
INFO - 2016-11-04 12:23:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:23:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:23:01 --> Utf8 Class Initialized
INFO - 2016-11-04 12:23:01 --> URI Class Initialized
DEBUG - 2016-11-04 12:23:01 --> No URI present. Default controller set.
INFO - 2016-11-04 12:23:01 --> Router Class Initialized
INFO - 2016-11-04 12:23:01 --> Output Class Initialized
INFO - 2016-11-04 12:23:01 --> Security Class Initialized
DEBUG - 2016-11-04 12:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:23:02 --> Input Class Initialized
INFO - 2016-11-04 12:23:02 --> Language Class Initialized
INFO - 2016-11-04 12:23:02 --> Loader Class Initialized
INFO - 2016-11-04 12:23:02 --> Helper loaded: url_helper
INFO - 2016-11-04 12:23:02 --> Helper loaded: form_helper
INFO - 2016-11-04 12:23:02 --> Database Driver Class Initialized
INFO - 2016-11-04 12:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:23:02 --> Controller Class Initialized
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:23:02 --> Model Class Initialized
INFO - 2016-11-04 12:23:02 --> Model Class Initialized
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:23:02 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:23:02 --> Final output sent to browser
DEBUG - 2016-11-04 12:23:02 --> Total execution time: 0.6032
INFO - 2016-11-04 12:23:49 --> Config Class Initialized
INFO - 2016-11-04 12:23:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:23:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:23:49 --> Utf8 Class Initialized
INFO - 2016-11-04 12:23:49 --> URI Class Initialized
DEBUG - 2016-11-04 12:23:49 --> No URI present. Default controller set.
INFO - 2016-11-04 12:23:49 --> Router Class Initialized
INFO - 2016-11-04 12:23:49 --> Output Class Initialized
INFO - 2016-11-04 12:23:50 --> Security Class Initialized
DEBUG - 2016-11-04 12:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:23:50 --> Input Class Initialized
INFO - 2016-11-04 12:23:50 --> Language Class Initialized
INFO - 2016-11-04 12:23:50 --> Loader Class Initialized
INFO - 2016-11-04 12:23:50 --> Helper loaded: url_helper
INFO - 2016-11-04 12:23:50 --> Helper loaded: form_helper
INFO - 2016-11-04 12:23:50 --> Database Driver Class Initialized
INFO - 2016-11-04 12:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:23:50 --> Controller Class Initialized
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:23:50 --> Model Class Initialized
INFO - 2016-11-04 12:23:50 --> Model Class Initialized
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:23:50 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:23:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:23:50 --> Final output sent to browser
DEBUG - 2016-11-04 12:23:50 --> Total execution time: 0.5695
INFO - 2016-11-04 12:25:07 --> Config Class Initialized
INFO - 2016-11-04 12:25:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:25:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:25:07 --> Utf8 Class Initialized
INFO - 2016-11-04 12:25:07 --> URI Class Initialized
DEBUG - 2016-11-04 12:25:07 --> No URI present. Default controller set.
INFO - 2016-11-04 12:25:07 --> Router Class Initialized
INFO - 2016-11-04 12:25:07 --> Output Class Initialized
INFO - 2016-11-04 12:25:07 --> Security Class Initialized
DEBUG - 2016-11-04 12:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:25:07 --> Input Class Initialized
INFO - 2016-11-04 12:25:07 --> Language Class Initialized
INFO - 2016-11-04 12:25:07 --> Loader Class Initialized
INFO - 2016-11-04 12:25:07 --> Helper loaded: url_helper
INFO - 2016-11-04 12:25:07 --> Helper loaded: form_helper
INFO - 2016-11-04 12:25:07 --> Database Driver Class Initialized
INFO - 2016-11-04 12:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:25:07 --> Controller Class Initialized
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:25:07 --> Model Class Initialized
INFO - 2016-11-04 12:25:07 --> Model Class Initialized
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:25:07 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:25:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:25:07 --> Final output sent to browser
DEBUG - 2016-11-04 12:25:07 --> Total execution time: 0.6176
INFO - 2016-11-04 12:33:14 --> Config Class Initialized
INFO - 2016-11-04 12:33:14 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:33:14 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:33:14 --> Utf8 Class Initialized
INFO - 2016-11-04 12:33:15 --> URI Class Initialized
DEBUG - 2016-11-04 12:33:15 --> No URI present. Default controller set.
INFO - 2016-11-04 12:33:15 --> Router Class Initialized
INFO - 2016-11-04 12:33:15 --> Output Class Initialized
INFO - 2016-11-04 12:33:15 --> Security Class Initialized
DEBUG - 2016-11-04 12:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:33:15 --> Input Class Initialized
INFO - 2016-11-04 12:33:15 --> Language Class Initialized
INFO - 2016-11-04 12:33:15 --> Loader Class Initialized
INFO - 2016-11-04 12:33:15 --> Helper loaded: url_helper
INFO - 2016-11-04 12:33:15 --> Helper loaded: form_helper
INFO - 2016-11-04 12:33:15 --> Database Driver Class Initialized
INFO - 2016-11-04 12:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:33:15 --> Controller Class Initialized
INFO - 2016-11-04 12:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:33:15 --> Model Class Initialized
INFO - 2016-11-04 12:33:15 --> Model Class Initialized
INFO - 2016-11-04 12:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:38:03 --> Config Class Initialized
INFO - 2016-11-04 12:38:03 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:38:03 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:38:03 --> Utf8 Class Initialized
INFO - 2016-11-04 12:38:03 --> URI Class Initialized
DEBUG - 2016-11-04 12:38:04 --> No URI present. Default controller set.
INFO - 2016-11-04 12:38:04 --> Router Class Initialized
INFO - 2016-11-04 12:38:04 --> Output Class Initialized
INFO - 2016-11-04 12:38:04 --> Security Class Initialized
DEBUG - 2016-11-04 12:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:38:04 --> Input Class Initialized
INFO - 2016-11-04 12:38:04 --> Language Class Initialized
INFO - 2016-11-04 12:38:04 --> Loader Class Initialized
INFO - 2016-11-04 12:38:04 --> Helper loaded: url_helper
INFO - 2016-11-04 12:38:04 --> Helper loaded: form_helper
INFO - 2016-11-04 12:38:04 --> Database Driver Class Initialized
INFO - 2016-11-04 12:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:38:04 --> Controller Class Initialized
INFO - 2016-11-04 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:38:04 --> Model Class Initialized
INFO - 2016-11-04 12:38:04 --> Model Class Initialized
INFO - 2016-11-04 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:38:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:38:05 --> Config Class Initialized
INFO - 2016-11-04 12:38:05 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:38:05 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:38:05 --> Utf8 Class Initialized
INFO - 2016-11-04 12:38:05 --> URI Class Initialized
INFO - 2016-11-04 12:38:05 --> Router Class Initialized
INFO - 2016-11-04 12:38:05 --> Output Class Initialized
INFO - 2016-11-04 12:38:05 --> Security Class Initialized
DEBUG - 2016-11-04 12:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:38:05 --> Input Class Initialized
INFO - 2016-11-04 12:38:05 --> Language Class Initialized
INFO - 2016-11-04 12:38:06 --> Loader Class Initialized
INFO - 2016-11-04 12:38:06 --> Helper loaded: url_helper
INFO - 2016-11-04 12:38:06 --> Helper loaded: form_helper
INFO - 2016-11-04 12:38:06 --> Database Driver Class Initialized
INFO - 2016-11-04 12:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:38:06 --> Controller Class Initialized
INFO - 2016-11-04 12:38:06 --> Form Validation Class Initialized
INFO - 2016-11-04 12:38:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 12:38:06 --> Final output sent to browser
DEBUG - 2016-11-04 12:38:06 --> Total execution time: 0.2269
INFO - 2016-11-04 12:38:07 --> Config Class Initialized
INFO - 2016-11-04 12:38:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:38:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:38:07 --> Utf8 Class Initialized
INFO - 2016-11-04 12:38:07 --> URI Class Initialized
DEBUG - 2016-11-04 12:38:07 --> No URI present. Default controller set.
INFO - 2016-11-04 12:38:07 --> Router Class Initialized
INFO - 2016-11-04 12:38:07 --> Output Class Initialized
INFO - 2016-11-04 12:38:07 --> Security Class Initialized
DEBUG - 2016-11-04 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:38:07 --> Input Class Initialized
INFO - 2016-11-04 12:38:07 --> Language Class Initialized
INFO - 2016-11-04 12:38:07 --> Loader Class Initialized
INFO - 2016-11-04 12:38:07 --> Helper loaded: url_helper
INFO - 2016-11-04 12:38:07 --> Helper loaded: form_helper
INFO - 2016-11-04 12:38:07 --> Database Driver Class Initialized
INFO - 2016-11-04 12:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:38:07 --> Controller Class Initialized
INFO - 2016-11-04 12:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:38:07 --> Model Class Initialized
INFO - 2016-11-04 12:38:07 --> Model Class Initialized
INFO - 2016-11-04 12:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:38:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:38:21 --> Config Class Initialized
INFO - 2016-11-04 12:38:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:38:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:38:21 --> Utf8 Class Initialized
INFO - 2016-11-04 12:38:21 --> URI Class Initialized
DEBUG - 2016-11-04 12:38:21 --> No URI present. Default controller set.
INFO - 2016-11-04 12:38:21 --> Router Class Initialized
INFO - 2016-11-04 12:38:22 --> Output Class Initialized
INFO - 2016-11-04 12:38:22 --> Security Class Initialized
DEBUG - 2016-11-04 12:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:38:22 --> Input Class Initialized
INFO - 2016-11-04 12:38:22 --> Language Class Initialized
INFO - 2016-11-04 12:38:22 --> Loader Class Initialized
INFO - 2016-11-04 12:38:22 --> Helper loaded: url_helper
INFO - 2016-11-04 12:38:22 --> Helper loaded: form_helper
INFO - 2016-11-04 12:38:22 --> Database Driver Class Initialized
INFO - 2016-11-04 12:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:38:22 --> Controller Class Initialized
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:38:22 --> Model Class Initialized
INFO - 2016-11-04 12:38:22 --> Model Class Initialized
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:38:22 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:38:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:38:22 --> Final output sent to browser
DEBUG - 2016-11-04 12:38:22 --> Total execution time: 0.6368
INFO - 2016-11-04 12:41:10 --> Config Class Initialized
INFO - 2016-11-04 12:41:10 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:41:10 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:41:10 --> Utf8 Class Initialized
INFO - 2016-11-04 12:41:10 --> URI Class Initialized
DEBUG - 2016-11-04 12:41:10 --> No URI present. Default controller set.
INFO - 2016-11-04 12:41:10 --> Router Class Initialized
INFO - 2016-11-04 12:41:10 --> Output Class Initialized
INFO - 2016-11-04 12:41:10 --> Security Class Initialized
DEBUG - 2016-11-04 12:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:41:10 --> Input Class Initialized
INFO - 2016-11-04 12:41:10 --> Language Class Initialized
INFO - 2016-11-04 12:41:10 --> Loader Class Initialized
INFO - 2016-11-04 12:41:10 --> Helper loaded: url_helper
INFO - 2016-11-04 12:41:10 --> Helper loaded: form_helper
INFO - 2016-11-04 12:41:10 --> Database Driver Class Initialized
INFO - 2016-11-04 12:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:41:10 --> Controller Class Initialized
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:41:11 --> Model Class Initialized
INFO - 2016-11-04 12:41:11 --> Model Class Initialized
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:41:11 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:41:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:41:11 --> Final output sent to browser
DEBUG - 2016-11-04 12:41:11 --> Total execution time: 0.5986
INFO - 2016-11-04 12:41:14 --> Config Class Initialized
INFO - 2016-11-04 12:41:14 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:41:14 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:41:14 --> Utf8 Class Initialized
INFO - 2016-11-04 12:41:14 --> URI Class Initialized
INFO - 2016-11-04 12:41:14 --> Router Class Initialized
INFO - 2016-11-04 12:41:14 --> Output Class Initialized
INFO - 2016-11-04 12:41:14 --> Security Class Initialized
DEBUG - 2016-11-04 12:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:41:14 --> Input Class Initialized
INFO - 2016-11-04 12:41:14 --> Language Class Initialized
INFO - 2016-11-04 12:41:14 --> Loader Class Initialized
INFO - 2016-11-04 12:41:14 --> Helper loaded: url_helper
INFO - 2016-11-04 12:41:14 --> Helper loaded: form_helper
INFO - 2016-11-04 12:41:14 --> Database Driver Class Initialized
INFO - 2016-11-04 12:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:41:14 --> Controller Class Initialized
INFO - 2016-11-04 12:41:14 --> Form Validation Class Initialized
INFO - 2016-11-04 12:41:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 12:41:14 --> Final output sent to browser
DEBUG - 2016-11-04 12:41:14 --> Total execution time: 0.2044
INFO - 2016-11-04 12:41:16 --> Config Class Initialized
INFO - 2016-11-04 12:41:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:41:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:41:16 --> Utf8 Class Initialized
INFO - 2016-11-04 12:41:16 --> URI Class Initialized
DEBUG - 2016-11-04 12:41:16 --> No URI present. Default controller set.
INFO - 2016-11-04 12:41:16 --> Router Class Initialized
INFO - 2016-11-04 12:41:16 --> Output Class Initialized
INFO - 2016-11-04 12:41:16 --> Security Class Initialized
DEBUG - 2016-11-04 12:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:41:16 --> Input Class Initialized
INFO - 2016-11-04 12:41:16 --> Language Class Initialized
INFO - 2016-11-04 12:41:16 --> Loader Class Initialized
INFO - 2016-11-04 12:41:16 --> Helper loaded: url_helper
INFO - 2016-11-04 12:41:16 --> Helper loaded: form_helper
INFO - 2016-11-04 12:41:16 --> Database Driver Class Initialized
INFO - 2016-11-04 12:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:41:16 --> Controller Class Initialized
INFO - 2016-11-04 12:41:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:41:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:41:16 --> Model Class Initialized
INFO - 2016-11-04 12:41:16 --> Model Class Initialized
INFO - 2016-11-04 12:41:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:41:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:41:17 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:41:17 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:41:17 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:41:17 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:41:17 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:41:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:41:17 --> Final output sent to browser
DEBUG - 2016-11-04 12:41:17 --> Total execution time: 0.6849
INFO - 2016-11-04 12:42:24 --> Config Class Initialized
INFO - 2016-11-04 12:42:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:42:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:42:24 --> Utf8 Class Initialized
INFO - 2016-11-04 12:42:24 --> URI Class Initialized
DEBUG - 2016-11-04 12:42:24 --> No URI present. Default controller set.
INFO - 2016-11-04 12:42:24 --> Router Class Initialized
INFO - 2016-11-04 12:42:24 --> Output Class Initialized
INFO - 2016-11-04 12:42:24 --> Security Class Initialized
DEBUG - 2016-11-04 12:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:42:24 --> Input Class Initialized
INFO - 2016-11-04 12:42:24 --> Language Class Initialized
INFO - 2016-11-04 12:42:24 --> Loader Class Initialized
INFO - 2016-11-04 12:42:24 --> Helper loaded: url_helper
INFO - 2016-11-04 12:42:24 --> Helper loaded: form_helper
INFO - 2016-11-04 12:42:24 --> Database Driver Class Initialized
INFO - 2016-11-04 12:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:42:24 --> Controller Class Initialized
INFO - 2016-11-04 12:42:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:42:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:42:24 --> Model Class Initialized
ERROR - 2016-11-04 12:42:24 --> Severity: Notice --> Undefined property: Auth::$Leave_type_m C:\xampp\htdocs\LMS\app\controllers\Auth.php 55
ERROR - 2016-11-04 12:42:24 --> Severity: Error --> Call to a member function all() on null C:\xampp\htdocs\LMS\app\controllers\Auth.php 55
INFO - 2016-11-04 12:42:42 --> Config Class Initialized
INFO - 2016-11-04 12:42:42 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:42:42 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:42:42 --> Utf8 Class Initialized
INFO - 2016-11-04 12:42:42 --> URI Class Initialized
DEBUG - 2016-11-04 12:42:42 --> No URI present. Default controller set.
INFO - 2016-11-04 12:42:42 --> Router Class Initialized
INFO - 2016-11-04 12:42:42 --> Output Class Initialized
INFO - 2016-11-04 12:42:42 --> Security Class Initialized
DEBUG - 2016-11-04 12:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:42:42 --> Input Class Initialized
INFO - 2016-11-04 12:42:42 --> Language Class Initialized
INFO - 2016-11-04 12:42:42 --> Loader Class Initialized
INFO - 2016-11-04 12:42:42 --> Helper loaded: url_helper
INFO - 2016-11-04 12:42:42 --> Helper loaded: form_helper
INFO - 2016-11-04 12:42:42 --> Database Driver Class Initialized
INFO - 2016-11-04 12:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:42:42 --> Controller Class Initialized
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:42:42 --> Model Class Initialized
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
ERROR - 2016-11-04 12:42:42 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 37
ERROR - 2016-11-04 12:42:42 --> Severity: Notice --> Undefined property: stdClass::$numberOfLeaves C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 38
ERROR - 2016-11-04 12:42:42 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 39
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:42:42 --> Final output sent to browser
DEBUG - 2016-11-04 12:42:42 --> Total execution time: 0.3666
INFO - 2016-11-04 12:43:53 --> Config Class Initialized
INFO - 2016-11-04 12:43:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:43:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:43:53 --> Utf8 Class Initialized
INFO - 2016-11-04 12:43:53 --> URI Class Initialized
DEBUG - 2016-11-04 12:43:53 --> No URI present. Default controller set.
INFO - 2016-11-04 12:43:53 --> Router Class Initialized
INFO - 2016-11-04 12:43:53 --> Output Class Initialized
INFO - 2016-11-04 12:43:53 --> Security Class Initialized
DEBUG - 2016-11-04 12:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:43:53 --> Input Class Initialized
INFO - 2016-11-04 12:43:53 --> Language Class Initialized
INFO - 2016-11-04 12:43:53 --> Loader Class Initialized
INFO - 2016-11-04 12:43:53 --> Helper loaded: url_helper
INFO - 2016-11-04 12:43:53 --> Helper loaded: form_helper
INFO - 2016-11-04 12:43:53 --> Database Driver Class Initialized
INFO - 2016-11-04 12:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:43:53 --> Controller Class Initialized
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:43:53 --> Model Class Initialized
INFO - 2016-11-04 12:43:53 --> Model Class Initialized
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:43:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:43:53 --> Final output sent to browser
DEBUG - 2016-11-04 12:43:53 --> Total execution time: 0.6215
INFO - 2016-11-04 12:46:31 --> Config Class Initialized
INFO - 2016-11-04 12:46:31 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:46:31 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:46:31 --> Utf8 Class Initialized
INFO - 2016-11-04 12:46:31 --> URI Class Initialized
DEBUG - 2016-11-04 12:46:31 --> No URI present. Default controller set.
INFO - 2016-11-04 12:46:31 --> Router Class Initialized
INFO - 2016-11-04 12:46:31 --> Output Class Initialized
INFO - 2016-11-04 12:46:31 --> Security Class Initialized
DEBUG - 2016-11-04 12:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:46:31 --> Input Class Initialized
INFO - 2016-11-04 12:46:31 --> Language Class Initialized
INFO - 2016-11-04 12:46:31 --> Loader Class Initialized
INFO - 2016-11-04 12:46:31 --> Helper loaded: url_helper
INFO - 2016-11-04 12:46:31 --> Helper loaded: form_helper
INFO - 2016-11-04 12:46:31 --> Database Driver Class Initialized
INFO - 2016-11-04 12:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:46:31 --> Controller Class Initialized
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:46:31 --> Model Class Initialized
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
ERROR - 2016-11-04 12:46:31 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 37
ERROR - 2016-11-04 12:46:31 --> Severity: Notice --> Undefined property: stdClass::$numberOfLeaves C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 38
ERROR - 2016-11-04 12:46:31 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\LMS\app\views\admin\all_leave_type.php 39
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:46:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:46:31 --> Final output sent to browser
DEBUG - 2016-11-04 12:46:31 --> Total execution time: 0.3997
INFO - 2016-11-04 12:47:15 --> Config Class Initialized
INFO - 2016-11-04 12:47:15 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:47:15 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:47:15 --> Utf8 Class Initialized
INFO - 2016-11-04 12:47:15 --> URI Class Initialized
DEBUG - 2016-11-04 12:47:15 --> No URI present. Default controller set.
INFO - 2016-11-04 12:47:15 --> Router Class Initialized
INFO - 2016-11-04 12:47:15 --> Output Class Initialized
INFO - 2016-11-04 12:47:16 --> Security Class Initialized
DEBUG - 2016-11-04 12:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:47:16 --> Input Class Initialized
INFO - 2016-11-04 12:47:16 --> Language Class Initialized
INFO - 2016-11-04 12:47:16 --> Loader Class Initialized
INFO - 2016-11-04 12:47:16 --> Helper loaded: url_helper
INFO - 2016-11-04 12:47:16 --> Helper loaded: form_helper
INFO - 2016-11-04 12:47:16 --> Database Driver Class Initialized
INFO - 2016-11-04 12:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:47:16 --> Controller Class Initialized
INFO - 2016-11-04 12:47:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:47:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:47:16 --> Model Class Initialized
ERROR - 2016-11-04 12:47:16 --> Severity: Notice --> Undefined property: Auth::$Leave_type_m C:\xampp\htdocs\LMS\app\controllers\Auth.php 55
ERROR - 2016-11-04 12:47:16 --> Severity: Error --> Call to a member function all() on null C:\xampp\htdocs\LMS\app\controllers\Auth.php 55
INFO - 2016-11-04 12:47:28 --> Config Class Initialized
INFO - 2016-11-04 12:47:28 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:47:28 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:47:28 --> Utf8 Class Initialized
INFO - 2016-11-04 12:47:28 --> URI Class Initialized
DEBUG - 2016-11-04 12:47:28 --> No URI present. Default controller set.
INFO - 2016-11-04 12:47:28 --> Router Class Initialized
INFO - 2016-11-04 12:47:28 --> Output Class Initialized
INFO - 2016-11-04 12:47:28 --> Security Class Initialized
DEBUG - 2016-11-04 12:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:47:28 --> Input Class Initialized
INFO - 2016-11-04 12:47:28 --> Language Class Initialized
INFO - 2016-11-04 12:47:28 --> Loader Class Initialized
INFO - 2016-11-04 12:47:28 --> Helper loaded: url_helper
INFO - 2016-11-04 12:47:28 --> Helper loaded: form_helper
INFO - 2016-11-04 12:47:28 --> Database Driver Class Initialized
INFO - 2016-11-04 12:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:47:29 --> Controller Class Initialized
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:47:29 --> Model Class Initialized
INFO - 2016-11-04 12:47:29 --> Model Class Initialized
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$surname C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 21
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$initial C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 22
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$persalNum C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 23
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$telephone C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 24
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idAuth C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 25
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idShiftWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 26
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idCasualWorker C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 27
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idDepartment C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 28
ERROR - 2016-11-04 12:47:29 --> Severity: Notice --> Undefined property: stdClass::$idComponent C:\xampp\htdocs\LMS\app\views\admin\add_user_sidebar.php 29
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:47:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:47:29 --> Final output sent to browser
DEBUG - 2016-11-04 12:47:29 --> Total execution time: 0.6392
INFO - 2016-11-04 12:48:35 --> Config Class Initialized
INFO - 2016-11-04 12:48:35 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:48:35 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:48:35 --> Utf8 Class Initialized
INFO - 2016-11-04 12:48:35 --> URI Class Initialized
DEBUG - 2016-11-04 12:48:35 --> No URI present. Default controller set.
INFO - 2016-11-04 12:48:35 --> Router Class Initialized
INFO - 2016-11-04 12:48:35 --> Output Class Initialized
INFO - 2016-11-04 12:48:35 --> Security Class Initialized
DEBUG - 2016-11-04 12:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:48:35 --> Input Class Initialized
INFO - 2016-11-04 12:48:35 --> Language Class Initialized
INFO - 2016-11-04 12:48:35 --> Loader Class Initialized
INFO - 2016-11-04 12:48:35 --> Helper loaded: url_helper
INFO - 2016-11-04 12:48:35 --> Helper loaded: form_helper
INFO - 2016-11-04 12:48:35 --> Database Driver Class Initialized
INFO - 2016-11-04 12:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:48:35 --> Controller Class Initialized
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:48:35 --> Model Class Initialized
INFO - 2016-11-04 12:48:35 --> Model Class Initialized
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:48:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:48:35 --> Final output sent to browser
DEBUG - 2016-11-04 12:48:35 --> Total execution time: 0.3806
INFO - 2016-11-04 12:50:08 --> Config Class Initialized
INFO - 2016-11-04 12:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:50:08 --> Utf8 Class Initialized
INFO - 2016-11-04 12:50:08 --> URI Class Initialized
DEBUG - 2016-11-04 12:50:08 --> No URI present. Default controller set.
INFO - 2016-11-04 12:50:08 --> Router Class Initialized
INFO - 2016-11-04 12:50:08 --> Output Class Initialized
INFO - 2016-11-04 12:50:08 --> Security Class Initialized
DEBUG - 2016-11-04 12:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:50:08 --> Input Class Initialized
INFO - 2016-11-04 12:50:08 --> Language Class Initialized
INFO - 2016-11-04 12:50:08 --> Loader Class Initialized
INFO - 2016-11-04 12:50:08 --> Helper loaded: url_helper
INFO - 2016-11-04 12:50:08 --> Helper loaded: form_helper
INFO - 2016-11-04 12:50:08 --> Database Driver Class Initialized
INFO - 2016-11-04 12:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:50:08 --> Controller Class Initialized
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:50:08 --> Model Class Initialized
INFO - 2016-11-04 12:50:08 --> Model Class Initialized
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:50:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:50:08 --> Final output sent to browser
DEBUG - 2016-11-04 12:50:08 --> Total execution time: 0.3363
INFO - 2016-11-04 12:50:39 --> Config Class Initialized
INFO - 2016-11-04 12:50:39 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:50:39 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:50:39 --> Utf8 Class Initialized
INFO - 2016-11-04 12:50:39 --> URI Class Initialized
DEBUG - 2016-11-04 12:50:39 --> No URI present. Default controller set.
INFO - 2016-11-04 12:50:39 --> Router Class Initialized
INFO - 2016-11-04 12:50:39 --> Output Class Initialized
INFO - 2016-11-04 12:50:39 --> Security Class Initialized
DEBUG - 2016-11-04 12:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:50:39 --> Input Class Initialized
INFO - 2016-11-04 12:50:39 --> Language Class Initialized
INFO - 2016-11-04 12:50:39 --> Loader Class Initialized
INFO - 2016-11-04 12:50:39 --> Helper loaded: url_helper
INFO - 2016-11-04 12:50:39 --> Helper loaded: form_helper
INFO - 2016-11-04 12:50:39 --> Database Driver Class Initialized
INFO - 2016-11-04 12:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:50:39 --> Controller Class Initialized
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:50:39 --> Model Class Initialized
INFO - 2016-11-04 12:50:39 --> Model Class Initialized
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:50:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:50:39 --> Final output sent to browser
DEBUG - 2016-11-04 12:50:39 --> Total execution time: 0.3762
INFO - 2016-11-04 12:53:42 --> Config Class Initialized
INFO - 2016-11-04 12:53:42 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:53:42 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:53:42 --> Utf8 Class Initialized
INFO - 2016-11-04 12:53:42 --> URI Class Initialized
INFO - 2016-11-04 12:53:42 --> Router Class Initialized
INFO - 2016-11-04 12:53:42 --> Output Class Initialized
INFO - 2016-11-04 12:53:42 --> Security Class Initialized
DEBUG - 2016-11-04 12:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:53:42 --> Input Class Initialized
INFO - 2016-11-04 12:53:42 --> Language Class Initialized
INFO - 2016-11-04 12:53:42 --> Loader Class Initialized
INFO - 2016-11-04 12:53:42 --> Helper loaded: url_helper
INFO - 2016-11-04 12:53:42 --> Helper loaded: form_helper
INFO - 2016-11-04 12:53:42 --> Database Driver Class Initialized
INFO - 2016-11-04 12:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:53:42 --> Controller Class Initialized
INFO - 2016-11-04 12:53:42 --> Form Validation Class Initialized
INFO - 2016-11-04 12:53:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 12:53:42 --> Final output sent to browser
DEBUG - 2016-11-04 12:53:42 --> Total execution time: 0.2311
INFO - 2016-11-04 12:53:44 --> Config Class Initialized
INFO - 2016-11-04 12:53:44 --> Hooks Class Initialized
DEBUG - 2016-11-04 12:53:44 --> UTF-8 Support Enabled
INFO - 2016-11-04 12:53:44 --> Utf8 Class Initialized
INFO - 2016-11-04 12:53:44 --> URI Class Initialized
DEBUG - 2016-11-04 12:53:44 --> No URI present. Default controller set.
INFO - 2016-11-04 12:53:44 --> Router Class Initialized
INFO - 2016-11-04 12:53:44 --> Output Class Initialized
INFO - 2016-11-04 12:53:44 --> Security Class Initialized
DEBUG - 2016-11-04 12:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 12:53:44 --> Input Class Initialized
INFO - 2016-11-04 12:53:44 --> Language Class Initialized
INFO - 2016-11-04 12:53:44 --> Loader Class Initialized
INFO - 2016-11-04 12:53:44 --> Helper loaded: url_helper
INFO - 2016-11-04 12:53:44 --> Helper loaded: form_helper
INFO - 2016-11-04 12:53:44 --> Database Driver Class Initialized
INFO - 2016-11-04 12:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 12:53:44 --> Controller Class Initialized
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 12:53:44 --> Model Class Initialized
INFO - 2016-11-04 12:53:44 --> Model Class Initialized
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 12:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 12:53:44 --> Final output sent to browser
DEBUG - 2016-11-04 12:53:44 --> Total execution time: 0.4362
INFO - 2016-11-04 13:20:32 --> Config Class Initialized
INFO - 2016-11-04 13:20:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:20:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:20:32 --> Utf8 Class Initialized
INFO - 2016-11-04 13:20:32 --> URI Class Initialized
INFO - 2016-11-04 13:20:32 --> Router Class Initialized
INFO - 2016-11-04 13:20:32 --> Output Class Initialized
INFO - 2016-11-04 13:20:32 --> Security Class Initialized
DEBUG - 2016-11-04 13:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:20:32 --> Input Class Initialized
INFO - 2016-11-04 13:20:32 --> Language Class Initialized
INFO - 2016-11-04 13:20:32 --> Loader Class Initialized
INFO - 2016-11-04 13:20:32 --> Helper loaded: url_helper
INFO - 2016-11-04 13:20:32 --> Helper loaded: form_helper
INFO - 2016-11-04 13:20:32 --> Database Driver Class Initialized
INFO - 2016-11-04 13:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:20:32 --> Controller Class Initialized
DEBUG - 2016-11-04 13:20:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 13:20:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 103
ERROR - 2016-11-04 13:20:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 103
INFO - 2016-11-04 13:20:32 --> Config Class Initialized
INFO - 2016-11-04 13:20:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:20:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:20:32 --> Utf8 Class Initialized
INFO - 2016-11-04 13:20:32 --> URI Class Initialized
DEBUG - 2016-11-04 13:20:32 --> No URI present. Default controller set.
INFO - 2016-11-04 13:20:32 --> Router Class Initialized
INFO - 2016-11-04 13:20:32 --> Output Class Initialized
INFO - 2016-11-04 13:20:33 --> Security Class Initialized
DEBUG - 2016-11-04 13:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:20:33 --> Input Class Initialized
INFO - 2016-11-04 13:20:33 --> Language Class Initialized
INFO - 2016-11-04 13:20:33 --> Loader Class Initialized
INFO - 2016-11-04 13:20:33 --> Helper loaded: url_helper
INFO - 2016-11-04 13:20:33 --> Helper loaded: form_helper
INFO - 2016-11-04 13:20:33 --> Database Driver Class Initialized
INFO - 2016-11-04 13:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:20:33 --> Controller Class Initialized
INFO - 2016-11-04 13:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 13:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 13:20:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 13:20:33 --> Final output sent to browser
DEBUG - 2016-11-04 13:20:33 --> Total execution time: 0.2448
INFO - 2016-11-04 13:20:41 --> Config Class Initialized
INFO - 2016-11-04 13:20:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:20:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:20:41 --> Utf8 Class Initialized
INFO - 2016-11-04 13:20:41 --> URI Class Initialized
INFO - 2016-11-04 13:20:41 --> Router Class Initialized
INFO - 2016-11-04 13:20:41 --> Output Class Initialized
INFO - 2016-11-04 13:20:41 --> Security Class Initialized
DEBUG - 2016-11-04 13:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:20:41 --> Input Class Initialized
INFO - 2016-11-04 13:20:41 --> Language Class Initialized
INFO - 2016-11-04 13:20:41 --> Loader Class Initialized
INFO - 2016-11-04 13:20:41 --> Helper loaded: url_helper
INFO - 2016-11-04 13:20:41 --> Helper loaded: form_helper
INFO - 2016-11-04 13:20:41 --> Database Driver Class Initialized
INFO - 2016-11-04 13:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:20:41 --> Controller Class Initialized
DEBUG - 2016-11-04 13:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 13:20:41 --> Model Class Initialized
INFO - 2016-11-04 13:20:41 --> Final output sent to browser
DEBUG - 2016-11-04 13:20:41 --> Total execution time: 0.2342
INFO - 2016-11-04 13:20:41 --> Config Class Initialized
INFO - 2016-11-04 13:20:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:20:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:20:41 --> Utf8 Class Initialized
INFO - 2016-11-04 13:20:41 --> URI Class Initialized
DEBUG - 2016-11-04 13:20:41 --> No URI present. Default controller set.
INFO - 2016-11-04 13:20:41 --> Router Class Initialized
INFO - 2016-11-04 13:20:41 --> Output Class Initialized
INFO - 2016-11-04 13:20:41 --> Security Class Initialized
DEBUG - 2016-11-04 13:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:20:41 --> Input Class Initialized
INFO - 2016-11-04 13:20:41 --> Language Class Initialized
INFO - 2016-11-04 13:20:41 --> Loader Class Initialized
INFO - 2016-11-04 13:20:41 --> Helper loaded: url_helper
INFO - 2016-11-04 13:20:41 --> Helper loaded: form_helper
INFO - 2016-11-04 13:20:41 --> Database Driver Class Initialized
INFO - 2016-11-04 13:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:20:41 --> Controller Class Initialized
INFO - 2016-11-04 13:20:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 13:20:42 --> Model Class Initialized
INFO - 2016-11-04 13:20:42 --> Model Class Initialized
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 13:20:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 13:20:42 --> Final output sent to browser
DEBUG - 2016-11-04 13:20:42 --> Total execution time: 0.4372
INFO - 2016-11-04 13:20:57 --> Config Class Initialized
INFO - 2016-11-04 13:20:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:20:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:20:57 --> Utf8 Class Initialized
INFO - 2016-11-04 13:20:57 --> URI Class Initialized
INFO - 2016-11-04 13:20:57 --> Router Class Initialized
INFO - 2016-11-04 13:20:57 --> Output Class Initialized
INFO - 2016-11-04 13:20:57 --> Security Class Initialized
DEBUG - 2016-11-04 13:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:20:57 --> Input Class Initialized
INFO - 2016-11-04 13:20:57 --> Language Class Initialized
INFO - 2016-11-04 13:20:57 --> Loader Class Initialized
INFO - 2016-11-04 13:20:57 --> Helper loaded: url_helper
INFO - 2016-11-04 13:20:57 --> Helper loaded: form_helper
INFO - 2016-11-04 13:20:57 --> Database Driver Class Initialized
INFO - 2016-11-04 13:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:20:57 --> Controller Class Initialized
DEBUG - 2016-11-04 13:20:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 13:20:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 103
ERROR - 2016-11-04 13:20:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 103
INFO - 2016-11-04 13:20:57 --> Config Class Initialized
INFO - 2016-11-04 13:20:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:20:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:20:57 --> Utf8 Class Initialized
INFO - 2016-11-04 13:20:57 --> URI Class Initialized
DEBUG - 2016-11-04 13:20:57 --> No URI present. Default controller set.
INFO - 2016-11-04 13:20:57 --> Router Class Initialized
INFO - 2016-11-04 13:20:57 --> Output Class Initialized
INFO - 2016-11-04 13:20:57 --> Security Class Initialized
DEBUG - 2016-11-04 13:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:20:57 --> Input Class Initialized
INFO - 2016-11-04 13:20:57 --> Language Class Initialized
INFO - 2016-11-04 13:20:57 --> Loader Class Initialized
INFO - 2016-11-04 13:20:57 --> Helper loaded: url_helper
INFO - 2016-11-04 13:20:57 --> Helper loaded: form_helper
INFO - 2016-11-04 13:20:57 --> Database Driver Class Initialized
INFO - 2016-11-04 13:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:20:57 --> Controller Class Initialized
INFO - 2016-11-04 13:20:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 13:20:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 13:20:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 13:20:57 --> Final output sent to browser
DEBUG - 2016-11-04 13:20:57 --> Total execution time: 0.2407
INFO - 2016-11-04 13:21:05 --> Config Class Initialized
INFO - 2016-11-04 13:21:05 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:21:05 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:21:05 --> Utf8 Class Initialized
INFO - 2016-11-04 13:21:05 --> URI Class Initialized
INFO - 2016-11-04 13:21:05 --> Router Class Initialized
INFO - 2016-11-04 13:21:05 --> Output Class Initialized
INFO - 2016-11-04 13:21:05 --> Security Class Initialized
DEBUG - 2016-11-04 13:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:21:06 --> Input Class Initialized
INFO - 2016-11-04 13:21:06 --> Language Class Initialized
INFO - 2016-11-04 13:21:06 --> Loader Class Initialized
INFO - 2016-11-04 13:21:06 --> Helper loaded: url_helper
INFO - 2016-11-04 13:21:06 --> Helper loaded: form_helper
INFO - 2016-11-04 13:21:06 --> Database Driver Class Initialized
INFO - 2016-11-04 13:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:21:06 --> Controller Class Initialized
DEBUG - 2016-11-04 13:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 13:21:06 --> Model Class Initialized
INFO - 2016-11-04 13:21:06 --> Final output sent to browser
DEBUG - 2016-11-04 13:21:06 --> Total execution time: 0.2366
INFO - 2016-11-04 13:21:06 --> Config Class Initialized
INFO - 2016-11-04 13:21:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 13:21:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 13:21:06 --> Utf8 Class Initialized
INFO - 2016-11-04 13:21:06 --> URI Class Initialized
DEBUG - 2016-11-04 13:21:06 --> No URI present. Default controller set.
INFO - 2016-11-04 13:21:06 --> Router Class Initialized
INFO - 2016-11-04 13:21:06 --> Output Class Initialized
INFO - 2016-11-04 13:21:06 --> Security Class Initialized
DEBUG - 2016-11-04 13:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 13:21:06 --> Input Class Initialized
INFO - 2016-11-04 13:21:06 --> Language Class Initialized
INFO - 2016-11-04 13:21:06 --> Loader Class Initialized
INFO - 2016-11-04 13:21:06 --> Helper loaded: url_helper
INFO - 2016-11-04 13:21:06 --> Helper loaded: form_helper
INFO - 2016-11-04 13:21:06 --> Database Driver Class Initialized
INFO - 2016-11-04 13:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 13:21:06 --> Controller Class Initialized
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 13:21:06 --> Model Class Initialized
INFO - 2016-11-04 13:21:06 --> Model Class Initialized
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 13:21:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 13:21:06 --> Final output sent to browser
DEBUG - 2016-11-04 13:21:06 --> Total execution time: 0.3484
INFO - 2016-11-04 14:49:57 --> Config Class Initialized
INFO - 2016-11-04 14:49:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 14:49:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 14:49:57 --> Utf8 Class Initialized
INFO - 2016-11-04 14:49:57 --> URI Class Initialized
DEBUG - 2016-11-04 14:49:57 --> No URI present. Default controller set.
INFO - 2016-11-04 14:49:57 --> Router Class Initialized
INFO - 2016-11-04 14:49:57 --> Output Class Initialized
INFO - 2016-11-04 14:49:57 --> Security Class Initialized
DEBUG - 2016-11-04 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 14:49:57 --> Input Class Initialized
INFO - 2016-11-04 14:49:57 --> Language Class Initialized
INFO - 2016-11-04 14:49:57 --> Loader Class Initialized
INFO - 2016-11-04 14:49:57 --> Helper loaded: url_helper
INFO - 2016-11-04 14:49:57 --> Helper loaded: form_helper
INFO - 2016-11-04 14:49:57 --> Database Driver Class Initialized
INFO - 2016-11-04 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 14:49:57 --> Controller Class Initialized
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 14:49:57 --> Model Class Initialized
INFO - 2016-11-04 14:49:57 --> Model Class Initialized
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-04 14:49:57 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\LMS\app\views\admin\add_user.php 70
ERROR - 2016-11-04 14:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\admin\add_user.php 70
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 14:49:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 14:49:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 14:49:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 14:49:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 14:49:58 --> Final output sent to browser
DEBUG - 2016-11-04 14:49:58 --> Total execution time: 0.4523
INFO - 2016-11-04 14:55:05 --> Config Class Initialized
INFO - 2016-11-04 14:55:05 --> Hooks Class Initialized
DEBUG - 2016-11-04 14:55:05 --> UTF-8 Support Enabled
INFO - 2016-11-04 14:55:05 --> Utf8 Class Initialized
INFO - 2016-11-04 14:55:05 --> URI Class Initialized
DEBUG - 2016-11-04 14:55:05 --> No URI present. Default controller set.
INFO - 2016-11-04 14:55:05 --> Router Class Initialized
INFO - 2016-11-04 14:55:05 --> Output Class Initialized
INFO - 2016-11-04 14:55:05 --> Security Class Initialized
DEBUG - 2016-11-04 14:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 14:55:05 --> Input Class Initialized
INFO - 2016-11-04 14:55:05 --> Language Class Initialized
INFO - 2016-11-04 14:55:05 --> Loader Class Initialized
INFO - 2016-11-04 14:55:05 --> Helper loaded: url_helper
INFO - 2016-11-04 14:55:05 --> Helper loaded: form_helper
INFO - 2016-11-04 14:55:05 --> Database Driver Class Initialized
INFO - 2016-11-04 14:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 14:55:05 --> Controller Class Initialized
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 14:55:05 --> Model Class Initialized
INFO - 2016-11-04 14:55:05 --> Model Class Initialized
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-04 14:55:05 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\LMS\app\views\admin\add_user.php 70
ERROR - 2016-11-04 14:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\admin\add_user.php 70
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 14:55:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 14:55:05 --> Final output sent to browser
DEBUG - 2016-11-04 14:55:05 --> Total execution time: 0.3780
INFO - 2016-11-04 14:56:04 --> Config Class Initialized
INFO - 2016-11-04 14:56:04 --> Hooks Class Initialized
DEBUG - 2016-11-04 14:56:04 --> UTF-8 Support Enabled
INFO - 2016-11-04 14:56:05 --> Utf8 Class Initialized
INFO - 2016-11-04 14:56:05 --> URI Class Initialized
DEBUG - 2016-11-04 14:56:05 --> No URI present. Default controller set.
INFO - 2016-11-04 14:56:05 --> Router Class Initialized
INFO - 2016-11-04 14:56:05 --> Output Class Initialized
INFO - 2016-11-04 14:56:05 --> Security Class Initialized
DEBUG - 2016-11-04 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 14:56:05 --> Input Class Initialized
INFO - 2016-11-04 14:56:05 --> Language Class Initialized
INFO - 2016-11-04 14:56:05 --> Loader Class Initialized
INFO - 2016-11-04 14:56:05 --> Helper loaded: url_helper
INFO - 2016-11-04 14:56:05 --> Helper loaded: form_helper
INFO - 2016-11-04 14:56:05 --> Database Driver Class Initialized
INFO - 2016-11-04 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 14:56:05 --> Controller Class Initialized
INFO - 2016-11-04 14:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 14:56:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 14:56:05 --> Model Class Initialized
INFO - 2016-11-04 14:56:05 --> Model Class Initialized
INFO - 2016-11-04 14:56:38 --> Config Class Initialized
INFO - 2016-11-04 14:56:38 --> Hooks Class Initialized
DEBUG - 2016-11-04 14:56:38 --> UTF-8 Support Enabled
INFO - 2016-11-04 14:56:38 --> Utf8 Class Initialized
INFO - 2016-11-04 14:56:38 --> URI Class Initialized
DEBUG - 2016-11-04 14:56:38 --> No URI present. Default controller set.
INFO - 2016-11-04 14:56:38 --> Router Class Initialized
INFO - 2016-11-04 14:56:38 --> Output Class Initialized
INFO - 2016-11-04 14:56:38 --> Security Class Initialized
DEBUG - 2016-11-04 14:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 14:56:38 --> Input Class Initialized
INFO - 2016-11-04 14:56:38 --> Language Class Initialized
INFO - 2016-11-04 14:56:38 --> Loader Class Initialized
INFO - 2016-11-04 14:56:38 --> Helper loaded: url_helper
INFO - 2016-11-04 14:56:38 --> Helper loaded: form_helper
INFO - 2016-11-04 14:56:38 --> Database Driver Class Initialized
INFO - 2016-11-04 14:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 14:56:38 --> Controller Class Initialized
INFO - 2016-11-04 14:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 14:56:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 14:56:38 --> Model Class Initialized
INFO - 2016-11-04 14:56:38 --> Model Class Initialized
INFO - 2016-11-04 14:57:15 --> Config Class Initialized
INFO - 2016-11-04 14:57:15 --> Hooks Class Initialized
DEBUG - 2016-11-04 14:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-04 14:57:15 --> Utf8 Class Initialized
INFO - 2016-11-04 14:57:15 --> URI Class Initialized
DEBUG - 2016-11-04 14:57:15 --> No URI present. Default controller set.
INFO - 2016-11-04 14:57:15 --> Router Class Initialized
INFO - 2016-11-04 14:57:15 --> Output Class Initialized
INFO - 2016-11-04 14:57:15 --> Security Class Initialized
DEBUG - 2016-11-04 14:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 14:57:15 --> Input Class Initialized
INFO - 2016-11-04 14:57:15 --> Language Class Initialized
INFO - 2016-11-04 14:57:15 --> Loader Class Initialized
INFO - 2016-11-04 14:57:15 --> Helper loaded: url_helper
INFO - 2016-11-04 14:57:15 --> Helper loaded: form_helper
INFO - 2016-11-04 14:57:15 --> Database Driver Class Initialized
INFO - 2016-11-04 14:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 14:57:15 --> Controller Class Initialized
INFO - 2016-11-04 14:57:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 14:57:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 14:57:16 --> Model Class Initialized
INFO - 2016-11-04 14:57:16 --> Model Class Initialized
INFO - 2016-11-04 15:05:20 --> Config Class Initialized
INFO - 2016-11-04 15:05:20 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:05:20 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:05:20 --> Utf8 Class Initialized
INFO - 2016-11-04 15:05:20 --> URI Class Initialized
DEBUG - 2016-11-04 15:05:20 --> No URI present. Default controller set.
INFO - 2016-11-04 15:05:20 --> Router Class Initialized
INFO - 2016-11-04 15:05:20 --> Output Class Initialized
INFO - 2016-11-04 15:05:20 --> Security Class Initialized
DEBUG - 2016-11-04 15:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:05:20 --> Input Class Initialized
INFO - 2016-11-04 15:05:20 --> Language Class Initialized
INFO - 2016-11-04 15:05:20 --> Loader Class Initialized
INFO - 2016-11-04 15:05:20 --> Helper loaded: url_helper
INFO - 2016-11-04 15:05:20 --> Helper loaded: form_helper
INFO - 2016-11-04 15:05:20 --> Database Driver Class Initialized
INFO - 2016-11-04 15:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:05:20 --> Controller Class Initialized
INFO - 2016-11-04 15:05:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:05:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:05:20 --> Model Class Initialized
INFO - 2016-11-04 15:05:20 --> Model Class Initialized
INFO - 2016-11-04 15:05:39 --> Config Class Initialized
INFO - 2016-11-04 15:05:39 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:05:39 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:05:39 --> Utf8 Class Initialized
INFO - 2016-11-04 15:05:39 --> URI Class Initialized
DEBUG - 2016-11-04 15:05:39 --> No URI present. Default controller set.
INFO - 2016-11-04 15:05:39 --> Router Class Initialized
INFO - 2016-11-04 15:05:39 --> Output Class Initialized
INFO - 2016-11-04 15:05:39 --> Security Class Initialized
DEBUG - 2016-11-04 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:05:39 --> Input Class Initialized
INFO - 2016-11-04 15:05:39 --> Language Class Initialized
INFO - 2016-11-04 15:05:39 --> Loader Class Initialized
INFO - 2016-11-04 15:05:39 --> Helper loaded: url_helper
INFO - 2016-11-04 15:05:40 --> Helper loaded: form_helper
INFO - 2016-11-04 15:05:40 --> Database Driver Class Initialized
INFO - 2016-11-04 15:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:05:40 --> Controller Class Initialized
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:05:40 --> Model Class Initialized
INFO - 2016-11-04 15:05:40 --> Model Class Initialized
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:05:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:05:40 --> Final output sent to browser
DEBUG - 2016-11-04 15:05:40 --> Total execution time: 0.3633
INFO - 2016-11-04 15:06:16 --> Config Class Initialized
INFO - 2016-11-04 15:06:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:06:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:06:16 --> Utf8 Class Initialized
INFO - 2016-11-04 15:06:16 --> URI Class Initialized
DEBUG - 2016-11-04 15:06:16 --> No URI present. Default controller set.
INFO - 2016-11-04 15:06:16 --> Router Class Initialized
INFO - 2016-11-04 15:06:17 --> Output Class Initialized
INFO - 2016-11-04 15:06:17 --> Security Class Initialized
DEBUG - 2016-11-04 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:06:17 --> Input Class Initialized
INFO - 2016-11-04 15:06:17 --> Language Class Initialized
INFO - 2016-11-04 15:06:17 --> Loader Class Initialized
INFO - 2016-11-04 15:06:17 --> Helper loaded: url_helper
INFO - 2016-11-04 15:06:17 --> Helper loaded: form_helper
INFO - 2016-11-04 15:06:17 --> Database Driver Class Initialized
INFO - 2016-11-04 15:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:06:17 --> Controller Class Initialized
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:06:17 --> Model Class Initialized
INFO - 2016-11-04 15:06:17 --> Model Class Initialized
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-04 15:06:17 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\LMS\app\views\admin\add_user.php 70
ERROR - 2016-11-04 15:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\admin\add_user.php 70
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:06:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:06:17 --> Final output sent to browser
DEBUG - 2016-11-04 15:06:17 --> Total execution time: 0.4084
INFO - 2016-11-04 15:07:40 --> Config Class Initialized
INFO - 2016-11-04 15:07:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:07:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:07:40 --> Utf8 Class Initialized
INFO - 2016-11-04 15:07:40 --> URI Class Initialized
DEBUG - 2016-11-04 15:07:40 --> No URI present. Default controller set.
INFO - 2016-11-04 15:07:40 --> Router Class Initialized
INFO - 2016-11-04 15:07:40 --> Output Class Initialized
INFO - 2016-11-04 15:07:40 --> Security Class Initialized
DEBUG - 2016-11-04 15:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:07:40 --> Input Class Initialized
INFO - 2016-11-04 15:07:40 --> Language Class Initialized
INFO - 2016-11-04 15:07:40 --> Loader Class Initialized
INFO - 2016-11-04 15:07:40 --> Helper loaded: url_helper
INFO - 2016-11-04 15:07:40 --> Helper loaded: form_helper
INFO - 2016-11-04 15:07:40 --> Database Driver Class Initialized
INFO - 2016-11-04 15:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:07:40 --> Controller Class Initialized
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:07:40 --> Model Class Initialized
INFO - 2016-11-04 15:07:40 --> Model Class Initialized
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:07:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:07:40 --> Final output sent to browser
DEBUG - 2016-11-04 15:07:40 --> Total execution time: 0.3770
INFO - 2016-11-04 15:14:34 --> Config Class Initialized
INFO - 2016-11-04 15:14:34 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:14:34 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:14:34 --> Utf8 Class Initialized
INFO - 2016-11-04 15:14:34 --> URI Class Initialized
DEBUG - 2016-11-04 15:14:34 --> No URI present. Default controller set.
INFO - 2016-11-04 15:14:34 --> Router Class Initialized
INFO - 2016-11-04 15:14:34 --> Output Class Initialized
INFO - 2016-11-04 15:14:34 --> Security Class Initialized
DEBUG - 2016-11-04 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:14:34 --> Input Class Initialized
INFO - 2016-11-04 15:14:34 --> Language Class Initialized
INFO - 2016-11-04 15:14:34 --> Loader Class Initialized
INFO - 2016-11-04 15:14:34 --> Helper loaded: url_helper
INFO - 2016-11-04 15:14:34 --> Helper loaded: form_helper
INFO - 2016-11-04 15:14:34 --> Database Driver Class Initialized
INFO - 2016-11-04 15:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:14:34 --> Controller Class Initialized
INFO - 2016-11-04 15:14:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:14:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-04 15:14:34 --> Severity: Notice --> Undefined property: Auth::$Employee_m C:\xampp\htdocs\LMS\app\controllers\Auth.php 57
ERROR - 2016-11-04 15:14:34 --> Severity: Error --> Call to a member function all_Employee() on null C:\xampp\htdocs\LMS\app\controllers\Auth.php 57
INFO - 2016-11-04 15:14:54 --> Config Class Initialized
INFO - 2016-11-04 15:14:54 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:14:54 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:14:54 --> Utf8 Class Initialized
INFO - 2016-11-04 15:14:54 --> URI Class Initialized
DEBUG - 2016-11-04 15:14:54 --> No URI present. Default controller set.
INFO - 2016-11-04 15:14:54 --> Router Class Initialized
INFO - 2016-11-04 15:14:54 --> Output Class Initialized
INFO - 2016-11-04 15:14:54 --> Security Class Initialized
DEBUG - 2016-11-04 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:14:54 --> Input Class Initialized
INFO - 2016-11-04 15:14:54 --> Language Class Initialized
INFO - 2016-11-04 15:14:55 --> Loader Class Initialized
INFO - 2016-11-04 15:14:55 --> Helper loaded: url_helper
INFO - 2016-11-04 15:14:55 --> Helper loaded: form_helper
INFO - 2016-11-04 15:14:55 --> Database Driver Class Initialized
INFO - 2016-11-04 15:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:14:55 --> Controller Class Initialized
INFO - 2016-11-04 15:14:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:14:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-04 15:14:55 --> Severity: Notice --> Undefined property: Auth::$Employee_m C:\xampp\htdocs\LMS\app\controllers\Auth.php 57
ERROR - 2016-11-04 15:14:55 --> Severity: Error --> Call to a member function all_Employee() on null C:\xampp\htdocs\LMS\app\controllers\Auth.php 57
INFO - 2016-11-04 15:14:56 --> Config Class Initialized
INFO - 2016-11-04 15:14:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:14:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:14:56 --> Utf8 Class Initialized
INFO - 2016-11-04 15:14:56 --> URI Class Initialized
DEBUG - 2016-11-04 15:14:56 --> No URI present. Default controller set.
INFO - 2016-11-04 15:14:56 --> Router Class Initialized
INFO - 2016-11-04 15:14:56 --> Output Class Initialized
INFO - 2016-11-04 15:14:56 --> Security Class Initialized
DEBUG - 2016-11-04 15:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:14:56 --> Input Class Initialized
INFO - 2016-11-04 15:14:56 --> Language Class Initialized
INFO - 2016-11-04 15:14:56 --> Loader Class Initialized
INFO - 2016-11-04 15:14:56 --> Helper loaded: url_helper
INFO - 2016-11-04 15:14:56 --> Helper loaded: form_helper
INFO - 2016-11-04 15:14:56 --> Database Driver Class Initialized
INFO - 2016-11-04 15:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:14:56 --> Controller Class Initialized
INFO - 2016-11-04 15:14:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:14:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-04 15:14:56 --> Severity: Notice --> Undefined property: Auth::$Employee_m C:\xampp\htdocs\LMS\app\controllers\Auth.php 57
ERROR - 2016-11-04 15:14:56 --> Severity: Error --> Call to a member function all_Employee() on null C:\xampp\htdocs\LMS\app\controllers\Auth.php 57
INFO - 2016-11-04 15:15:23 --> Config Class Initialized
INFO - 2016-11-04 15:15:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:15:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:15:23 --> Utf8 Class Initialized
INFO - 2016-11-04 15:15:23 --> URI Class Initialized
DEBUG - 2016-11-04 15:15:23 --> No URI present. Default controller set.
INFO - 2016-11-04 15:15:23 --> Router Class Initialized
INFO - 2016-11-04 15:15:23 --> Output Class Initialized
INFO - 2016-11-04 15:15:23 --> Security Class Initialized
DEBUG - 2016-11-04 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:15:23 --> Input Class Initialized
INFO - 2016-11-04 15:15:23 --> Language Class Initialized
ERROR - 2016-11-04 15:15:23 --> Severity: Error --> Call to undefined method CI_Controller::__contruct() C:\xampp\htdocs\LMS\app\controllers\Auth.php 24
INFO - 2016-11-04 15:16:33 --> Config Class Initialized
INFO - 2016-11-04 15:16:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:16:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:16:33 --> Utf8 Class Initialized
INFO - 2016-11-04 15:16:33 --> URI Class Initialized
DEBUG - 2016-11-04 15:16:33 --> No URI present. Default controller set.
INFO - 2016-11-04 15:16:33 --> Router Class Initialized
INFO - 2016-11-04 15:16:33 --> Output Class Initialized
INFO - 2016-11-04 15:16:33 --> Security Class Initialized
DEBUG - 2016-11-04 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:16:33 --> Input Class Initialized
INFO - 2016-11-04 15:16:33 --> Language Class Initialized
INFO - 2016-11-04 15:16:33 --> Loader Class Initialized
INFO - 2016-11-04 15:16:33 --> Helper loaded: url_helper
INFO - 2016-11-04 15:16:33 --> Helper loaded: form_helper
INFO - 2016-11-04 15:16:33 --> Database Driver Class Initialized
INFO - 2016-11-04 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:16:33 --> Controller Class Initialized
INFO - 2016-11-04 15:16:33 --> Model Class Initialized
INFO - 2016-11-04 15:16:33 --> Model Class Initialized
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:16:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:16:33 --> Final output sent to browser
DEBUG - 2016-11-04 15:16:33 --> Total execution time: 0.3530
INFO - 2016-11-04 15:16:43 --> Config Class Initialized
INFO - 2016-11-04 15:16:43 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:16:43 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:16:43 --> Utf8 Class Initialized
INFO - 2016-11-04 15:16:43 --> URI Class Initialized
DEBUG - 2016-11-04 15:16:43 --> No URI present. Default controller set.
INFO - 2016-11-04 15:16:43 --> Router Class Initialized
INFO - 2016-11-04 15:16:43 --> Output Class Initialized
INFO - 2016-11-04 15:16:43 --> Security Class Initialized
DEBUG - 2016-11-04 15:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:16:43 --> Input Class Initialized
INFO - 2016-11-04 15:16:43 --> Language Class Initialized
INFO - 2016-11-04 15:16:43 --> Loader Class Initialized
INFO - 2016-11-04 15:16:43 --> Helper loaded: url_helper
INFO - 2016-11-04 15:16:43 --> Helper loaded: form_helper
INFO - 2016-11-04 15:16:43 --> Database Driver Class Initialized
INFO - 2016-11-04 15:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:16:43 --> Controller Class Initialized
INFO - 2016-11-04 15:16:43 --> Model Class Initialized
INFO - 2016-11-04 15:16:43 --> Model Class Initialized
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:16:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:16:43 --> Final output sent to browser
DEBUG - 2016-11-04 15:16:43 --> Total execution time: 0.3742
INFO - 2016-11-04 15:18:08 --> Config Class Initialized
INFO - 2016-11-04 15:18:08 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:18:08 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:18:08 --> Utf8 Class Initialized
INFO - 2016-11-04 15:18:08 --> URI Class Initialized
DEBUG - 2016-11-04 15:18:08 --> No URI present. Default controller set.
INFO - 2016-11-04 15:18:08 --> Router Class Initialized
INFO - 2016-11-04 15:18:08 --> Output Class Initialized
INFO - 2016-11-04 15:18:08 --> Security Class Initialized
DEBUG - 2016-11-04 15:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:18:08 --> Input Class Initialized
INFO - 2016-11-04 15:18:08 --> Language Class Initialized
INFO - 2016-11-04 15:18:08 --> Loader Class Initialized
INFO - 2016-11-04 15:18:08 --> Helper loaded: url_helper
INFO - 2016-11-04 15:18:08 --> Helper loaded: form_helper
INFO - 2016-11-04 15:18:08 --> Database Driver Class Initialized
INFO - 2016-11-04 15:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:18:08 --> Controller Class Initialized
INFO - 2016-11-04 15:18:08 --> Model Class Initialized
INFO - 2016-11-04 15:18:08 --> Model Class Initialized
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:18:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:18:08 --> Final output sent to browser
DEBUG - 2016-11-04 15:18:08 --> Total execution time: 0.3578
INFO - 2016-11-04 15:19:01 --> Config Class Initialized
INFO - 2016-11-04 15:19:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:19:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:19:01 --> Utf8 Class Initialized
INFO - 2016-11-04 15:19:01 --> URI Class Initialized
DEBUG - 2016-11-04 15:19:01 --> No URI present. Default controller set.
INFO - 2016-11-04 15:19:01 --> Router Class Initialized
INFO - 2016-11-04 15:19:01 --> Output Class Initialized
INFO - 2016-11-04 15:19:01 --> Security Class Initialized
DEBUG - 2016-11-04 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:19:01 --> Input Class Initialized
INFO - 2016-11-04 15:19:01 --> Language Class Initialized
INFO - 2016-11-04 15:19:01 --> Loader Class Initialized
INFO - 2016-11-04 15:19:01 --> Helper loaded: url_helper
INFO - 2016-11-04 15:19:01 --> Helper loaded: form_helper
INFO - 2016-11-04 15:19:01 --> Database Driver Class Initialized
INFO - 2016-11-04 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:19:01 --> Controller Class Initialized
INFO - 2016-11-04 15:19:01 --> Model Class Initialized
INFO - 2016-11-04 15:19:01 --> Model Class Initialized
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:19:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:19:01 --> Final output sent to browser
DEBUG - 2016-11-04 15:19:01 --> Total execution time: 0.3764
INFO - 2016-11-04 15:19:38 --> Config Class Initialized
INFO - 2016-11-04 15:19:38 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:19:38 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:19:38 --> Utf8 Class Initialized
INFO - 2016-11-04 15:19:38 --> URI Class Initialized
DEBUG - 2016-11-04 15:19:38 --> No URI present. Default controller set.
INFO - 2016-11-04 15:19:38 --> Router Class Initialized
INFO - 2016-11-04 15:19:38 --> Output Class Initialized
INFO - 2016-11-04 15:19:38 --> Security Class Initialized
DEBUG - 2016-11-04 15:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:19:38 --> Input Class Initialized
INFO - 2016-11-04 15:19:38 --> Language Class Initialized
INFO - 2016-11-04 15:19:38 --> Loader Class Initialized
INFO - 2016-11-04 15:19:38 --> Helper loaded: url_helper
INFO - 2016-11-04 15:19:38 --> Helper loaded: form_helper
INFO - 2016-11-04 15:19:38 --> Database Driver Class Initialized
INFO - 2016-11-04 15:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:19:38 --> Controller Class Initialized
INFO - 2016-11-04 15:19:38 --> Model Class Initialized
INFO - 2016-11-04 15:19:38 --> Model Class Initialized
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:19:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:19:38 --> Final output sent to browser
DEBUG - 2016-11-04 15:19:38 --> Total execution time: 0.4099
INFO - 2016-11-04 15:21:28 --> Config Class Initialized
INFO - 2016-11-04 15:21:28 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:21:28 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:21:28 --> Utf8 Class Initialized
INFO - 2016-11-04 15:21:28 --> URI Class Initialized
DEBUG - 2016-11-04 15:21:28 --> No URI present. Default controller set.
INFO - 2016-11-04 15:21:28 --> Router Class Initialized
INFO - 2016-11-04 15:21:28 --> Output Class Initialized
INFO - 2016-11-04 15:21:28 --> Security Class Initialized
DEBUG - 2016-11-04 15:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:21:28 --> Input Class Initialized
INFO - 2016-11-04 15:21:28 --> Language Class Initialized
INFO - 2016-11-04 15:21:28 --> Loader Class Initialized
INFO - 2016-11-04 15:21:28 --> Helper loaded: url_helper
INFO - 2016-11-04 15:21:28 --> Helper loaded: form_helper
INFO - 2016-11-04 15:21:28 --> Database Driver Class Initialized
INFO - 2016-11-04 15:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:21:28 --> Controller Class Initialized
INFO - 2016-11-04 15:21:28 --> Model Class Initialized
INFO - 2016-11-04 15:21:28 --> Model Class Initialized
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:21:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:21:28 --> Final output sent to browser
DEBUG - 2016-11-04 15:21:28 --> Total execution time: 0.4158
INFO - 2016-11-04 15:32:26 --> Config Class Initialized
INFO - 2016-11-04 15:32:26 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:32:26 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:32:26 --> Utf8 Class Initialized
INFO - 2016-11-04 15:32:26 --> URI Class Initialized
INFO - 2016-11-04 15:32:26 --> Router Class Initialized
INFO - 2016-11-04 15:32:26 --> Output Class Initialized
INFO - 2016-11-04 15:32:26 --> Security Class Initialized
DEBUG - 2016-11-04 15:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:32:26 --> Input Class Initialized
INFO - 2016-11-04 15:32:26 --> Language Class Initialized
INFO - 2016-11-04 15:32:26 --> Loader Class Initialized
INFO - 2016-11-04 15:32:26 --> Helper loaded: url_helper
INFO - 2016-11-04 15:32:26 --> Helper loaded: form_helper
INFO - 2016-11-04 15:32:26 --> Database Driver Class Initialized
INFO - 2016-11-04 15:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:32:26 --> Controller Class Initialized
INFO - 2016-11-04 15:32:26 --> Form Validation Class Initialized
INFO - 2016-11-04 15:32:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 15:32:26 --> Final output sent to browser
DEBUG - 2016-11-04 15:32:26 --> Total execution time: 0.2849
INFO - 2016-11-04 15:32:30 --> Config Class Initialized
INFO - 2016-11-04 15:32:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:32:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:32:30 --> Utf8 Class Initialized
INFO - 2016-11-04 15:32:30 --> URI Class Initialized
INFO - 2016-11-04 15:32:30 --> Router Class Initialized
INFO - 2016-11-04 15:32:30 --> Output Class Initialized
INFO - 2016-11-04 15:32:30 --> Security Class Initialized
DEBUG - 2016-11-04 15:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:32:30 --> Input Class Initialized
INFO - 2016-11-04 15:32:30 --> Language Class Initialized
INFO - 2016-11-04 15:32:30 --> Loader Class Initialized
INFO - 2016-11-04 15:32:30 --> Helper loaded: url_helper
INFO - 2016-11-04 15:32:30 --> Helper loaded: form_helper
INFO - 2016-11-04 15:32:30 --> Database Driver Class Initialized
INFO - 2016-11-04 15:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:32:30 --> Controller Class Initialized
INFO - 2016-11-04 15:32:30 --> Form Validation Class Initialized
INFO - 2016-11-04 15:32:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 15:32:30 --> Final output sent to browser
DEBUG - 2016-11-04 15:32:30 --> Total execution time: 0.2509
INFO - 2016-11-04 15:32:31 --> Config Class Initialized
INFO - 2016-11-04 15:32:31 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:32:31 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:32:31 --> Utf8 Class Initialized
INFO - 2016-11-04 15:32:31 --> URI Class Initialized
DEBUG - 2016-11-04 15:32:31 --> No URI present. Default controller set.
INFO - 2016-11-04 15:32:31 --> Router Class Initialized
INFO - 2016-11-04 15:32:31 --> Output Class Initialized
INFO - 2016-11-04 15:32:31 --> Security Class Initialized
DEBUG - 2016-11-04 15:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:32:31 --> Input Class Initialized
INFO - 2016-11-04 15:32:31 --> Language Class Initialized
INFO - 2016-11-04 15:32:31 --> Loader Class Initialized
INFO - 2016-11-04 15:32:31 --> Helper loaded: url_helper
INFO - 2016-11-04 15:32:31 --> Helper loaded: form_helper
INFO - 2016-11-04 15:32:31 --> Database Driver Class Initialized
INFO - 2016-11-04 15:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:32:31 --> Controller Class Initialized
INFO - 2016-11-04 15:32:31 --> Model Class Initialized
INFO - 2016-11-04 15:32:31 --> Model Class Initialized
INFO - 2016-11-04 15:32:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:32:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:32:32 --> Final output sent to browser
DEBUG - 2016-11-04 15:32:32 --> Total execution time: 0.4366
INFO - 2016-11-04 15:53:49 --> Config Class Initialized
INFO - 2016-11-04 15:53:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:53:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:53:49 --> Utf8 Class Initialized
INFO - 2016-11-04 15:53:49 --> URI Class Initialized
INFO - 2016-11-04 15:53:49 --> Router Class Initialized
INFO - 2016-11-04 15:53:49 --> Output Class Initialized
INFO - 2016-11-04 15:53:49 --> Security Class Initialized
DEBUG - 2016-11-04 15:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:53:49 --> Input Class Initialized
INFO - 2016-11-04 15:53:49 --> Language Class Initialized
INFO - 2016-11-04 15:53:49 --> Loader Class Initialized
INFO - 2016-11-04 15:53:49 --> Helper loaded: url_helper
INFO - 2016-11-04 15:53:49 --> Helper loaded: form_helper
INFO - 2016-11-04 15:53:49 --> Database Driver Class Initialized
INFO - 2016-11-04 15:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:53:49 --> Controller Class Initialized
INFO - 2016-11-04 15:53:49 --> Form Validation Class Initialized
INFO - 2016-11-04 15:53:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 15:53:49 --> Final output sent to browser
DEBUG - 2016-11-04 15:53:49 --> Total execution time: 0.2514
INFO - 2016-11-04 15:53:53 --> Config Class Initialized
INFO - 2016-11-04 15:53:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:53:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:53:53 --> Utf8 Class Initialized
INFO - 2016-11-04 15:53:53 --> URI Class Initialized
DEBUG - 2016-11-04 15:53:53 --> No URI present. Default controller set.
INFO - 2016-11-04 15:53:53 --> Router Class Initialized
INFO - 2016-11-04 15:53:53 --> Output Class Initialized
INFO - 2016-11-04 15:53:53 --> Security Class Initialized
DEBUG - 2016-11-04 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:53:53 --> Input Class Initialized
INFO - 2016-11-04 15:53:53 --> Language Class Initialized
INFO - 2016-11-04 15:53:53 --> Loader Class Initialized
INFO - 2016-11-04 15:53:53 --> Helper loaded: url_helper
INFO - 2016-11-04 15:53:53 --> Helper loaded: form_helper
INFO - 2016-11-04 15:53:53 --> Database Driver Class Initialized
INFO - 2016-11-04 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:53:53 --> Controller Class Initialized
INFO - 2016-11-04 15:53:53 --> Model Class Initialized
INFO - 2016-11-04 15:53:53 --> Model Class Initialized
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:53:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:53:53 --> Final output sent to browser
DEBUG - 2016-11-04 15:53:53 --> Total execution time: 0.3976
INFO - 2016-11-04 15:53:59 --> Config Class Initialized
INFO - 2016-11-04 15:53:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:53:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:53:59 --> Utf8 Class Initialized
INFO - 2016-11-04 15:53:59 --> URI Class Initialized
INFO - 2016-11-04 15:53:59 --> Router Class Initialized
INFO - 2016-11-04 15:53:59 --> Output Class Initialized
INFO - 2016-11-04 15:53:59 --> Security Class Initialized
DEBUG - 2016-11-04 15:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:53:59 --> Input Class Initialized
INFO - 2016-11-04 15:53:59 --> Language Class Initialized
INFO - 2016-11-04 15:53:59 --> Loader Class Initialized
INFO - 2016-11-04 15:53:59 --> Helper loaded: url_helper
INFO - 2016-11-04 15:53:59 --> Helper loaded: form_helper
INFO - 2016-11-04 15:53:59 --> Database Driver Class Initialized
INFO - 2016-11-04 15:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:53:59 --> Controller Class Initialized
INFO - 2016-11-04 15:53:59 --> Form Validation Class Initialized
INFO - 2016-11-04 15:53:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 15:53:59 --> Final output sent to browser
DEBUG - 2016-11-04 15:53:59 --> Total execution time: 0.2493
INFO - 2016-11-04 15:54:03 --> Config Class Initialized
INFO - 2016-11-04 15:54:03 --> Hooks Class Initialized
DEBUG - 2016-11-04 15:54:03 --> UTF-8 Support Enabled
INFO - 2016-11-04 15:54:03 --> Utf8 Class Initialized
INFO - 2016-11-04 15:54:03 --> URI Class Initialized
DEBUG - 2016-11-04 15:54:03 --> No URI present. Default controller set.
INFO - 2016-11-04 15:54:03 --> Router Class Initialized
INFO - 2016-11-04 15:54:03 --> Output Class Initialized
INFO - 2016-11-04 15:54:03 --> Security Class Initialized
DEBUG - 2016-11-04 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 15:54:03 --> Input Class Initialized
INFO - 2016-11-04 15:54:03 --> Language Class Initialized
INFO - 2016-11-04 15:54:03 --> Loader Class Initialized
INFO - 2016-11-04 15:54:03 --> Helper loaded: url_helper
INFO - 2016-11-04 15:54:03 --> Helper loaded: form_helper
INFO - 2016-11-04 15:54:03 --> Database Driver Class Initialized
INFO - 2016-11-04 15:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 15:54:03 --> Controller Class Initialized
INFO - 2016-11-04 15:54:03 --> Model Class Initialized
INFO - 2016-11-04 15:54:03 --> Model Class Initialized
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 15:54:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 15:54:03 --> Final output sent to browser
DEBUG - 2016-11-04 15:54:03 --> Total execution time: 0.4036
INFO - 2016-11-04 16:15:52 --> Config Class Initialized
INFO - 2016-11-04 16:15:52 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:15:52 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:15:52 --> Utf8 Class Initialized
INFO - 2016-11-04 16:15:52 --> URI Class Initialized
DEBUG - 2016-11-04 16:15:52 --> No URI present. Default controller set.
INFO - 2016-11-04 16:15:52 --> Router Class Initialized
INFO - 2016-11-04 16:15:52 --> Output Class Initialized
INFO - 2016-11-04 16:15:52 --> Security Class Initialized
DEBUG - 2016-11-04 16:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:15:52 --> Input Class Initialized
INFO - 2016-11-04 16:15:52 --> Language Class Initialized
INFO - 2016-11-04 16:15:52 --> Loader Class Initialized
INFO - 2016-11-04 16:15:52 --> Helper loaded: url_helper
INFO - 2016-11-04 16:15:52 --> Helper loaded: form_helper
INFO - 2016-11-04 16:15:52 --> Database Driver Class Initialized
INFO - 2016-11-04 16:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:15:52 --> Controller Class Initialized
INFO - 2016-11-04 16:15:52 --> Model Class Initialized
INFO - 2016-11-04 16:15:52 --> Model Class Initialized
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:15:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:15:52 --> Final output sent to browser
DEBUG - 2016-11-04 16:15:52 --> Total execution time: 0.4231
INFO - 2016-11-04 16:15:56 --> Config Class Initialized
INFO - 2016-11-04 16:15:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:15:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:15:56 --> Utf8 Class Initialized
INFO - 2016-11-04 16:15:56 --> URI Class Initialized
INFO - 2016-11-04 16:15:56 --> Router Class Initialized
INFO - 2016-11-04 16:15:56 --> Output Class Initialized
INFO - 2016-11-04 16:15:56 --> Security Class Initialized
DEBUG - 2016-11-04 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:15:56 --> Input Class Initialized
INFO - 2016-11-04 16:15:56 --> Language Class Initialized
INFO - 2016-11-04 16:15:56 --> Loader Class Initialized
INFO - 2016-11-04 16:15:56 --> Helper loaded: url_helper
INFO - 2016-11-04 16:15:56 --> Helper loaded: form_helper
INFO - 2016-11-04 16:15:56 --> Database Driver Class Initialized
INFO - 2016-11-04 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:15:56 --> Controller Class Initialized
INFO - 2016-11-04 16:15:56 --> Model Class Initialized
INFO - 2016-11-04 16:15:56 --> Form Validation Class Initialized
INFO - 2016-11-04 16:15:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:15:56 --> Final output sent to browser
DEBUG - 2016-11-04 16:15:56 --> Total execution time: 0.2622
INFO - 2016-11-04 16:15:58 --> Config Class Initialized
INFO - 2016-11-04 16:15:58 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:15:58 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:15:58 --> Utf8 Class Initialized
INFO - 2016-11-04 16:15:58 --> URI Class Initialized
DEBUG - 2016-11-04 16:15:58 --> No URI present. Default controller set.
INFO - 2016-11-04 16:15:58 --> Router Class Initialized
INFO - 2016-11-04 16:15:58 --> Output Class Initialized
INFO - 2016-11-04 16:15:58 --> Security Class Initialized
DEBUG - 2016-11-04 16:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:15:58 --> Input Class Initialized
INFO - 2016-11-04 16:15:58 --> Language Class Initialized
INFO - 2016-11-04 16:15:58 --> Loader Class Initialized
INFO - 2016-11-04 16:15:58 --> Helper loaded: url_helper
INFO - 2016-11-04 16:15:58 --> Helper loaded: form_helper
INFO - 2016-11-04 16:15:58 --> Database Driver Class Initialized
INFO - 2016-11-04 16:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:15:58 --> Controller Class Initialized
INFO - 2016-11-04 16:15:58 --> Model Class Initialized
INFO - 2016-11-04 16:15:58 --> Model Class Initialized
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:15:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:15:58 --> Final output sent to browser
DEBUG - 2016-11-04 16:15:58 --> Total execution time: 0.5069
INFO - 2016-11-04 16:25:51 --> Config Class Initialized
INFO - 2016-11-04 16:25:51 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:25:51 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:25:51 --> Utf8 Class Initialized
INFO - 2016-11-04 16:25:51 --> URI Class Initialized
DEBUG - 2016-11-04 16:25:51 --> No URI present. Default controller set.
INFO - 2016-11-04 16:25:51 --> Router Class Initialized
INFO - 2016-11-04 16:25:51 --> Output Class Initialized
INFO - 2016-11-04 16:25:51 --> Security Class Initialized
DEBUG - 2016-11-04 16:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:25:51 --> Input Class Initialized
INFO - 2016-11-04 16:25:51 --> Language Class Initialized
INFO - 2016-11-04 16:25:51 --> Loader Class Initialized
INFO - 2016-11-04 16:25:51 --> Helper loaded: url_helper
INFO - 2016-11-04 16:25:51 --> Helper loaded: form_helper
INFO - 2016-11-04 16:25:51 --> Database Driver Class Initialized
INFO - 2016-11-04 16:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:25:51 --> Controller Class Initialized
INFO - 2016-11-04 16:25:51 --> Model Class Initialized
INFO - 2016-11-04 16:25:51 --> Model Class Initialized
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:25:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:25:51 --> Final output sent to browser
DEBUG - 2016-11-04 16:25:51 --> Total execution time: 0.3824
INFO - 2016-11-04 16:26:04 --> Config Class Initialized
INFO - 2016-11-04 16:26:04 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:26:04 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:26:04 --> Utf8 Class Initialized
INFO - 2016-11-04 16:26:04 --> URI Class Initialized
INFO - 2016-11-04 16:26:04 --> Router Class Initialized
INFO - 2016-11-04 16:26:04 --> Output Class Initialized
INFO - 2016-11-04 16:26:04 --> Security Class Initialized
DEBUG - 2016-11-04 16:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:26:04 --> Input Class Initialized
INFO - 2016-11-04 16:26:04 --> Language Class Initialized
INFO - 2016-11-04 16:26:04 --> Loader Class Initialized
INFO - 2016-11-04 16:26:04 --> Helper loaded: url_helper
INFO - 2016-11-04 16:26:04 --> Helper loaded: form_helper
INFO - 2016-11-04 16:26:04 --> Database Driver Class Initialized
INFO - 2016-11-04 16:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:26:04 --> Controller Class Initialized
INFO - 2016-11-04 16:26:04 --> Model Class Initialized
INFO - 2016-11-04 16:26:37 --> Config Class Initialized
INFO - 2016-11-04 16:26:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:26:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:26:37 --> Utf8 Class Initialized
INFO - 2016-11-04 16:26:37 --> URI Class Initialized
INFO - 2016-11-04 16:26:37 --> Router Class Initialized
INFO - 2016-11-04 16:26:37 --> Output Class Initialized
INFO - 2016-11-04 16:26:37 --> Security Class Initialized
DEBUG - 2016-11-04 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:26:37 --> Input Class Initialized
INFO - 2016-11-04 16:26:37 --> Language Class Initialized
INFO - 2016-11-04 16:26:37 --> Loader Class Initialized
INFO - 2016-11-04 16:26:37 --> Helper loaded: url_helper
INFO - 2016-11-04 16:26:37 --> Helper loaded: form_helper
INFO - 2016-11-04 16:26:37 --> Database Driver Class Initialized
INFO - 2016-11-04 16:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:26:37 --> Controller Class Initialized
INFO - 2016-11-04 16:26:37 --> Model Class Initialized
INFO - 2016-11-04 16:26:49 --> Config Class Initialized
INFO - 2016-11-04 16:26:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:26:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:26:49 --> Utf8 Class Initialized
INFO - 2016-11-04 16:26:49 --> URI Class Initialized
INFO - 2016-11-04 16:26:49 --> Router Class Initialized
INFO - 2016-11-04 16:26:49 --> Output Class Initialized
INFO - 2016-11-04 16:26:49 --> Security Class Initialized
DEBUG - 2016-11-04 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:26:49 --> Input Class Initialized
INFO - 2016-11-04 16:26:49 --> Language Class Initialized
INFO - 2016-11-04 16:26:49 --> Loader Class Initialized
INFO - 2016-11-04 16:26:49 --> Helper loaded: url_helper
INFO - 2016-11-04 16:26:49 --> Helper loaded: form_helper
INFO - 2016-11-04 16:26:49 --> Database Driver Class Initialized
INFO - 2016-11-04 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:26:49 --> Controller Class Initialized
INFO - 2016-11-04 16:26:49 --> Model Class Initialized
INFO - 2016-11-04 16:26:49 --> Form Validation Class Initialized
INFO - 2016-11-04 16:26:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:26:49 --> Final output sent to browser
DEBUG - 2016-11-04 16:26:49 --> Total execution time: 0.2594
INFO - 2016-11-04 16:26:54 --> Config Class Initialized
INFO - 2016-11-04 16:26:54 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:26:54 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:26:54 --> Utf8 Class Initialized
INFO - 2016-11-04 16:26:54 --> URI Class Initialized
DEBUG - 2016-11-04 16:26:54 --> No URI present. Default controller set.
INFO - 2016-11-04 16:26:54 --> Router Class Initialized
INFO - 2016-11-04 16:26:54 --> Output Class Initialized
INFO - 2016-11-04 16:26:54 --> Security Class Initialized
DEBUG - 2016-11-04 16:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:26:54 --> Input Class Initialized
INFO - 2016-11-04 16:26:54 --> Language Class Initialized
INFO - 2016-11-04 16:26:54 --> Loader Class Initialized
INFO - 2016-11-04 16:26:54 --> Helper loaded: url_helper
INFO - 2016-11-04 16:26:54 --> Helper loaded: form_helper
INFO - 2016-11-04 16:26:55 --> Database Driver Class Initialized
INFO - 2016-11-04 16:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:26:55 --> Controller Class Initialized
INFO - 2016-11-04 16:26:55 --> Model Class Initialized
INFO - 2016-11-04 16:26:55 --> Model Class Initialized
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:26:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:26:55 --> Final output sent to browser
DEBUG - 2016-11-04 16:26:55 --> Total execution time: 0.3981
INFO - 2016-11-04 16:27:29 --> Config Class Initialized
INFO - 2016-11-04 16:27:29 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:27:29 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:27:29 --> Utf8 Class Initialized
INFO - 2016-11-04 16:27:29 --> URI Class Initialized
DEBUG - 2016-11-04 16:27:29 --> No URI present. Default controller set.
INFO - 2016-11-04 16:27:29 --> Router Class Initialized
INFO - 2016-11-04 16:27:29 --> Output Class Initialized
INFO - 2016-11-04 16:27:29 --> Security Class Initialized
DEBUG - 2016-11-04 16:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:27:29 --> Input Class Initialized
INFO - 2016-11-04 16:27:29 --> Language Class Initialized
INFO - 2016-11-04 16:27:29 --> Loader Class Initialized
INFO - 2016-11-04 16:27:29 --> Helper loaded: url_helper
INFO - 2016-11-04 16:27:29 --> Helper loaded: form_helper
INFO - 2016-11-04 16:27:29 --> Database Driver Class Initialized
INFO - 2016-11-04 16:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:27:29 --> Controller Class Initialized
INFO - 2016-11-04 16:27:29 --> Model Class Initialized
INFO - 2016-11-04 16:27:29 --> Model Class Initialized
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:27:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:27:29 --> Final output sent to browser
DEBUG - 2016-11-04 16:27:29 --> Total execution time: 0.4117
INFO - 2016-11-04 16:28:24 --> Config Class Initialized
INFO - 2016-11-04 16:28:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:28:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:28:24 --> Utf8 Class Initialized
INFO - 2016-11-04 16:28:24 --> URI Class Initialized
INFO - 2016-11-04 16:28:24 --> Router Class Initialized
INFO - 2016-11-04 16:28:24 --> Output Class Initialized
INFO - 2016-11-04 16:28:24 --> Security Class Initialized
DEBUG - 2016-11-04 16:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:28:24 --> Input Class Initialized
INFO - 2016-11-04 16:28:24 --> Language Class Initialized
INFO - 2016-11-04 16:28:24 --> Loader Class Initialized
INFO - 2016-11-04 16:28:24 --> Helper loaded: url_helper
INFO - 2016-11-04 16:28:24 --> Helper loaded: form_helper
INFO - 2016-11-04 16:28:24 --> Database Driver Class Initialized
INFO - 2016-11-04 16:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:28:24 --> Controller Class Initialized
INFO - 2016-11-04 16:28:24 --> Model Class Initialized
INFO - 2016-11-04 16:28:24 --> Form Validation Class Initialized
INFO - 2016-11-04 16:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:28:24 --> Final output sent to browser
DEBUG - 2016-11-04 16:28:24 --> Total execution time: 0.2758
INFO - 2016-11-04 16:28:35 --> Config Class Initialized
INFO - 2016-11-04 16:28:35 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:28:35 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:28:35 --> Utf8 Class Initialized
INFO - 2016-11-04 16:28:35 --> URI Class Initialized
DEBUG - 2016-11-04 16:28:35 --> No URI present. Default controller set.
INFO - 2016-11-04 16:28:35 --> Router Class Initialized
INFO - 2016-11-04 16:28:35 --> Output Class Initialized
INFO - 2016-11-04 16:28:35 --> Security Class Initialized
DEBUG - 2016-11-04 16:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:28:35 --> Input Class Initialized
INFO - 2016-11-04 16:28:35 --> Language Class Initialized
INFO - 2016-11-04 16:28:35 --> Loader Class Initialized
INFO - 2016-11-04 16:28:35 --> Helper loaded: url_helper
INFO - 2016-11-04 16:28:35 --> Helper loaded: form_helper
INFO - 2016-11-04 16:28:35 --> Database Driver Class Initialized
INFO - 2016-11-04 16:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:28:35 --> Controller Class Initialized
INFO - 2016-11-04 16:28:35 --> Model Class Initialized
INFO - 2016-11-04 16:28:35 --> Model Class Initialized
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:28:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:28:35 --> Final output sent to browser
DEBUG - 2016-11-04 16:28:35 --> Total execution time: 0.4133
INFO - 2016-11-04 16:28:53 --> Config Class Initialized
INFO - 2016-11-04 16:28:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:28:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:28:53 --> Utf8 Class Initialized
INFO - 2016-11-04 16:28:53 --> URI Class Initialized
INFO - 2016-11-04 16:28:53 --> Router Class Initialized
INFO - 2016-11-04 16:28:53 --> Output Class Initialized
INFO - 2016-11-04 16:28:53 --> Security Class Initialized
DEBUG - 2016-11-04 16:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:28:53 --> Input Class Initialized
INFO - 2016-11-04 16:28:53 --> Language Class Initialized
INFO - 2016-11-04 16:28:53 --> Loader Class Initialized
INFO - 2016-11-04 16:28:53 --> Helper loaded: url_helper
INFO - 2016-11-04 16:28:53 --> Helper loaded: form_helper
INFO - 2016-11-04 16:28:53 --> Database Driver Class Initialized
INFO - 2016-11-04 16:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:28:53 --> Controller Class Initialized
INFO - 2016-11-04 16:28:53 --> Model Class Initialized
INFO - 2016-11-04 16:29:27 --> Config Class Initialized
INFO - 2016-11-04 16:29:27 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:29:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:29:27 --> Utf8 Class Initialized
INFO - 2016-11-04 16:29:27 --> URI Class Initialized
DEBUG - 2016-11-04 16:29:27 --> No URI present. Default controller set.
INFO - 2016-11-04 16:29:27 --> Router Class Initialized
INFO - 2016-11-04 16:29:27 --> Output Class Initialized
INFO - 2016-11-04 16:29:27 --> Security Class Initialized
DEBUG - 2016-11-04 16:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:29:27 --> Input Class Initialized
INFO - 2016-11-04 16:29:27 --> Language Class Initialized
INFO - 2016-11-04 16:29:27 --> Loader Class Initialized
INFO - 2016-11-04 16:29:27 --> Helper loaded: url_helper
INFO - 2016-11-04 16:29:27 --> Helper loaded: form_helper
INFO - 2016-11-04 16:29:27 --> Database Driver Class Initialized
INFO - 2016-11-04 16:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:29:27 --> Controller Class Initialized
INFO - 2016-11-04 16:29:27 --> Model Class Initialized
INFO - 2016-11-04 16:29:27 --> Model Class Initialized
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:29:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:29:27 --> Final output sent to browser
DEBUG - 2016-11-04 16:29:27 --> Total execution time: 0.4287
INFO - 2016-11-04 16:30:14 --> Config Class Initialized
INFO - 2016-11-04 16:30:15 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:30:15 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:30:15 --> Utf8 Class Initialized
INFO - 2016-11-04 16:30:15 --> URI Class Initialized
DEBUG - 2016-11-04 16:30:15 --> No URI present. Default controller set.
INFO - 2016-11-04 16:30:15 --> Router Class Initialized
INFO - 2016-11-04 16:30:15 --> Output Class Initialized
INFO - 2016-11-04 16:30:15 --> Security Class Initialized
DEBUG - 2016-11-04 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:30:15 --> Input Class Initialized
INFO - 2016-11-04 16:30:15 --> Language Class Initialized
INFO - 2016-11-04 16:30:15 --> Loader Class Initialized
INFO - 2016-11-04 16:30:15 --> Helper loaded: url_helper
INFO - 2016-11-04 16:30:15 --> Helper loaded: form_helper
INFO - 2016-11-04 16:30:15 --> Database Driver Class Initialized
INFO - 2016-11-04 16:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:30:15 --> Controller Class Initialized
INFO - 2016-11-04 16:30:15 --> Model Class Initialized
INFO - 2016-11-04 16:30:15 --> Model Class Initialized
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:30:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:30:15 --> Final output sent to browser
DEBUG - 2016-11-04 16:30:15 --> Total execution time: 0.4462
INFO - 2016-11-04 16:31:45 --> Config Class Initialized
INFO - 2016-11-04 16:31:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:31:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:31:45 --> Utf8 Class Initialized
INFO - 2016-11-04 16:31:45 --> URI Class Initialized
INFO - 2016-11-04 16:31:45 --> Router Class Initialized
INFO - 2016-11-04 16:31:45 --> Output Class Initialized
INFO - 2016-11-04 16:31:45 --> Security Class Initialized
DEBUG - 2016-11-04 16:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:31:45 --> Input Class Initialized
INFO - 2016-11-04 16:31:45 --> Language Class Initialized
INFO - 2016-11-04 16:31:45 --> Loader Class Initialized
INFO - 2016-11-04 16:31:45 --> Helper loaded: url_helper
INFO - 2016-11-04 16:31:45 --> Helper loaded: form_helper
INFO - 2016-11-04 16:31:45 --> Database Driver Class Initialized
INFO - 2016-11-04 16:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:31:45 --> Controller Class Initialized
INFO - 2016-11-04 16:31:45 --> Model Class Initialized
INFO - 2016-11-04 16:31:45 --> Form Validation Class Initialized
INFO - 2016-11-04 16:31:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:31:45 --> Final output sent to browser
DEBUG - 2016-11-04 16:31:45 --> Total execution time: 0.2701
INFO - 2016-11-04 16:32:28 --> Config Class Initialized
INFO - 2016-11-04 16:32:28 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:32:28 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:32:28 --> Utf8 Class Initialized
INFO - 2016-11-04 16:32:28 --> URI Class Initialized
INFO - 2016-11-04 16:32:28 --> Router Class Initialized
INFO - 2016-11-04 16:32:28 --> Output Class Initialized
INFO - 2016-11-04 16:32:28 --> Security Class Initialized
DEBUG - 2016-11-04 16:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:32:28 --> Input Class Initialized
INFO - 2016-11-04 16:32:28 --> Language Class Initialized
INFO - 2016-11-04 16:32:28 --> Loader Class Initialized
INFO - 2016-11-04 16:32:28 --> Helper loaded: url_helper
INFO - 2016-11-04 16:32:28 --> Helper loaded: form_helper
INFO - 2016-11-04 16:32:28 --> Database Driver Class Initialized
INFO - 2016-11-04 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:32:28 --> Controller Class Initialized
INFO - 2016-11-04 16:32:28 --> Model Class Initialized
INFO - 2016-11-04 16:32:28 --> Form Validation Class Initialized
INFO - 2016-11-04 16:32:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:32:28 --> Final output sent to browser
DEBUG - 2016-11-04 16:32:28 --> Total execution time: 0.3175
INFO - 2016-11-04 16:32:31 --> Config Class Initialized
INFO - 2016-11-04 16:32:31 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:32:31 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:32:31 --> Utf8 Class Initialized
INFO - 2016-11-04 16:32:31 --> URI Class Initialized
INFO - 2016-11-04 16:32:31 --> Router Class Initialized
INFO - 2016-11-04 16:32:31 --> Output Class Initialized
INFO - 2016-11-04 16:32:31 --> Security Class Initialized
DEBUG - 2016-11-04 16:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:32:31 --> Input Class Initialized
INFO - 2016-11-04 16:32:31 --> Language Class Initialized
INFO - 2016-11-04 16:32:31 --> Loader Class Initialized
INFO - 2016-11-04 16:32:31 --> Helper loaded: url_helper
INFO - 2016-11-04 16:32:31 --> Helper loaded: form_helper
INFO - 2016-11-04 16:32:31 --> Database Driver Class Initialized
INFO - 2016-11-04 16:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:32:31 --> Controller Class Initialized
INFO - 2016-11-04 16:32:31 --> Model Class Initialized
INFO - 2016-11-04 16:32:31 --> Form Validation Class Initialized
INFO - 2016-11-04 16:32:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:32:31 --> Final output sent to browser
DEBUG - 2016-11-04 16:32:31 --> Total execution time: 0.3942
INFO - 2016-11-04 16:32:32 --> Config Class Initialized
INFO - 2016-11-04 16:32:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:32:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:32:33 --> Utf8 Class Initialized
INFO - 2016-11-04 16:32:33 --> URI Class Initialized
DEBUG - 2016-11-04 16:32:33 --> No URI present. Default controller set.
INFO - 2016-11-04 16:32:33 --> Router Class Initialized
INFO - 2016-11-04 16:32:33 --> Output Class Initialized
INFO - 2016-11-04 16:32:33 --> Security Class Initialized
DEBUG - 2016-11-04 16:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:32:33 --> Input Class Initialized
INFO - 2016-11-04 16:32:33 --> Language Class Initialized
INFO - 2016-11-04 16:32:33 --> Loader Class Initialized
INFO - 2016-11-04 16:32:33 --> Helper loaded: url_helper
INFO - 2016-11-04 16:32:33 --> Helper loaded: form_helper
INFO - 2016-11-04 16:32:33 --> Database Driver Class Initialized
INFO - 2016-11-04 16:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:32:33 --> Controller Class Initialized
INFO - 2016-11-04 16:32:33 --> Model Class Initialized
INFO - 2016-11-04 16:32:33 --> Model Class Initialized
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:32:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:32:33 --> Final output sent to browser
DEBUG - 2016-11-04 16:32:33 --> Total execution time: 0.4911
INFO - 2016-11-04 16:32:37 --> Config Class Initialized
INFO - 2016-11-04 16:32:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:32:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:32:37 --> Utf8 Class Initialized
INFO - 2016-11-04 16:32:37 --> URI Class Initialized
INFO - 2016-11-04 16:32:37 --> Router Class Initialized
INFO - 2016-11-04 16:32:37 --> Output Class Initialized
INFO - 2016-11-04 16:32:37 --> Security Class Initialized
DEBUG - 2016-11-04 16:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:32:37 --> Input Class Initialized
INFO - 2016-11-04 16:32:37 --> Language Class Initialized
INFO - 2016-11-04 16:32:37 --> Loader Class Initialized
INFO - 2016-11-04 16:32:37 --> Helper loaded: url_helper
INFO - 2016-11-04 16:32:37 --> Helper loaded: form_helper
INFO - 2016-11-04 16:32:37 --> Database Driver Class Initialized
INFO - 2016-11-04 16:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:32:37 --> Controller Class Initialized
INFO - 2016-11-04 16:32:37 --> Model Class Initialized
INFO - 2016-11-04 16:32:37 --> Form Validation Class Initialized
INFO - 2016-11-04 16:32:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:32:37 --> Final output sent to browser
DEBUG - 2016-11-04 16:32:37 --> Total execution time: 0.3769
INFO - 2016-11-04 16:32:38 --> Config Class Initialized
INFO - 2016-11-04 16:32:38 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:32:38 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:32:38 --> Utf8 Class Initialized
INFO - 2016-11-04 16:32:38 --> URI Class Initialized
DEBUG - 2016-11-04 16:32:38 --> No URI present. Default controller set.
INFO - 2016-11-04 16:32:38 --> Router Class Initialized
INFO - 2016-11-04 16:32:38 --> Output Class Initialized
INFO - 2016-11-04 16:32:38 --> Security Class Initialized
DEBUG - 2016-11-04 16:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:32:38 --> Input Class Initialized
INFO - 2016-11-04 16:32:38 --> Language Class Initialized
INFO - 2016-11-04 16:32:38 --> Loader Class Initialized
INFO - 2016-11-04 16:32:38 --> Helper loaded: url_helper
INFO - 2016-11-04 16:32:38 --> Helper loaded: form_helper
INFO - 2016-11-04 16:32:38 --> Database Driver Class Initialized
INFO - 2016-11-04 16:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:32:38 --> Controller Class Initialized
INFO - 2016-11-04 16:32:38 --> Model Class Initialized
INFO - 2016-11-04 16:32:39 --> Model Class Initialized
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:32:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:32:39 --> Final output sent to browser
DEBUG - 2016-11-04 16:32:39 --> Total execution time: 0.5691
INFO - 2016-11-04 16:32:59 --> Config Class Initialized
INFO - 2016-11-04 16:32:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:32:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:32:59 --> Utf8 Class Initialized
INFO - 2016-11-04 16:32:59 --> URI Class Initialized
INFO - 2016-11-04 16:32:59 --> Router Class Initialized
INFO - 2016-11-04 16:32:59 --> Output Class Initialized
INFO - 2016-11-04 16:32:59 --> Security Class Initialized
DEBUG - 2016-11-04 16:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:32:59 --> Input Class Initialized
INFO - 2016-11-04 16:32:59 --> Language Class Initialized
INFO - 2016-11-04 16:32:59 --> Loader Class Initialized
INFO - 2016-11-04 16:32:59 --> Helper loaded: url_helper
INFO - 2016-11-04 16:32:59 --> Helper loaded: form_helper
INFO - 2016-11-04 16:32:59 --> Database Driver Class Initialized
INFO - 2016-11-04 16:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:32:59 --> Controller Class Initialized
INFO - 2016-11-04 16:32:59 --> Model Class Initialized
INFO - 2016-11-04 16:32:59 --> Form Validation Class Initialized
INFO - 2016-11-04 16:32:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:32:59 --> Final output sent to browser
DEBUG - 2016-11-04 16:32:59 --> Total execution time: 0.3896
INFO - 2016-11-04 16:33:27 --> Config Class Initialized
INFO - 2016-11-04 16:33:27 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:33:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:33:27 --> Utf8 Class Initialized
INFO - 2016-11-04 16:33:27 --> URI Class Initialized
DEBUG - 2016-11-04 16:33:27 --> No URI present. Default controller set.
INFO - 2016-11-04 16:33:27 --> Router Class Initialized
INFO - 2016-11-04 16:33:27 --> Output Class Initialized
INFO - 2016-11-04 16:33:27 --> Security Class Initialized
DEBUG - 2016-11-04 16:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:33:27 --> Input Class Initialized
INFO - 2016-11-04 16:33:27 --> Language Class Initialized
INFO - 2016-11-04 16:33:27 --> Loader Class Initialized
INFO - 2016-11-04 16:33:27 --> Helper loaded: url_helper
INFO - 2016-11-04 16:33:27 --> Helper loaded: form_helper
INFO - 2016-11-04 16:33:27 --> Database Driver Class Initialized
INFO - 2016-11-04 16:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:33:28 --> Controller Class Initialized
INFO - 2016-11-04 16:33:28 --> Model Class Initialized
INFO - 2016-11-04 16:33:28 --> Model Class Initialized
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:33:28 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:33:28 --> Final output sent to browser
DEBUG - 2016-11-04 16:33:28 --> Total execution time: 0.5069
INFO - 2016-11-04 16:33:38 --> Config Class Initialized
INFO - 2016-11-04 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:33:38 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:33:38 --> Utf8 Class Initialized
INFO - 2016-11-04 16:33:38 --> URI Class Initialized
INFO - 2016-11-04 16:33:38 --> Router Class Initialized
INFO - 2016-11-04 16:33:38 --> Output Class Initialized
INFO - 2016-11-04 16:33:38 --> Security Class Initialized
DEBUG - 2016-11-04 16:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:33:38 --> Input Class Initialized
INFO - 2016-11-04 16:33:38 --> Language Class Initialized
INFO - 2016-11-04 16:33:38 --> Loader Class Initialized
INFO - 2016-11-04 16:33:38 --> Helper loaded: url_helper
INFO - 2016-11-04 16:33:38 --> Helper loaded: form_helper
INFO - 2016-11-04 16:33:38 --> Database Driver Class Initialized
INFO - 2016-11-04 16:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:33:38 --> Controller Class Initialized
INFO - 2016-11-04 16:33:38 --> Model Class Initialized
INFO - 2016-11-04 16:33:38 --> Form Validation Class Initialized
INFO - 2016-11-04 16:33:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:34:02 --> Config Class Initialized
INFO - 2016-11-04 16:34:02 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:34:02 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:34:02 --> Utf8 Class Initialized
INFO - 2016-11-04 16:34:02 --> URI Class Initialized
INFO - 2016-11-04 16:34:02 --> Router Class Initialized
INFO - 2016-11-04 16:34:02 --> Output Class Initialized
INFO - 2016-11-04 16:34:02 --> Security Class Initialized
DEBUG - 2016-11-04 16:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:34:02 --> Input Class Initialized
INFO - 2016-11-04 16:34:02 --> Language Class Initialized
INFO - 2016-11-04 16:34:02 --> Loader Class Initialized
INFO - 2016-11-04 16:34:02 --> Helper loaded: url_helper
INFO - 2016-11-04 16:34:02 --> Helper loaded: form_helper
INFO - 2016-11-04 16:34:02 --> Database Driver Class Initialized
INFO - 2016-11-04 16:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:34:02 --> Controller Class Initialized
INFO - 2016-11-04 16:34:02 --> Model Class Initialized
INFO - 2016-11-04 16:34:02 --> Form Validation Class Initialized
INFO - 2016-11-04 16:34:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:34:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:34:03 --> Final output sent to browser
DEBUG - 2016-11-04 16:34:03 --> Total execution time: 0.4647
INFO - 2016-11-04 16:34:06 --> Config Class Initialized
INFO - 2016-11-04 16:34:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:34:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:34:06 --> Utf8 Class Initialized
INFO - 2016-11-04 16:34:06 --> URI Class Initialized
DEBUG - 2016-11-04 16:34:06 --> No URI present. Default controller set.
INFO - 2016-11-04 16:34:06 --> Router Class Initialized
INFO - 2016-11-04 16:34:06 --> Output Class Initialized
INFO - 2016-11-04 16:34:06 --> Security Class Initialized
DEBUG - 2016-11-04 16:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:34:06 --> Input Class Initialized
INFO - 2016-11-04 16:34:06 --> Language Class Initialized
INFO - 2016-11-04 16:34:06 --> Loader Class Initialized
INFO - 2016-11-04 16:34:06 --> Helper loaded: url_helper
INFO - 2016-11-04 16:34:06 --> Helper loaded: form_helper
INFO - 2016-11-04 16:34:06 --> Database Driver Class Initialized
INFO - 2016-11-04 16:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:34:06 --> Controller Class Initialized
INFO - 2016-11-04 16:34:06 --> Model Class Initialized
INFO - 2016-11-04 16:34:06 --> Model Class Initialized
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:34:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:34:06 --> Final output sent to browser
DEBUG - 2016-11-04 16:34:06 --> Total execution time: 0.4701
INFO - 2016-11-04 16:34:24 --> Config Class Initialized
INFO - 2016-11-04 16:34:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:34:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:34:24 --> Utf8 Class Initialized
INFO - 2016-11-04 16:34:24 --> URI Class Initialized
DEBUG - 2016-11-04 16:34:24 --> No URI present. Default controller set.
INFO - 2016-11-04 16:34:24 --> Router Class Initialized
INFO - 2016-11-04 16:34:24 --> Output Class Initialized
INFO - 2016-11-04 16:34:24 --> Security Class Initialized
DEBUG - 2016-11-04 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:34:24 --> Input Class Initialized
INFO - 2016-11-04 16:34:24 --> Language Class Initialized
INFO - 2016-11-04 16:34:24 --> Loader Class Initialized
INFO - 2016-11-04 16:34:24 --> Helper loaded: url_helper
INFO - 2016-11-04 16:34:24 --> Helper loaded: form_helper
INFO - 2016-11-04 16:34:24 --> Database Driver Class Initialized
INFO - 2016-11-04 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:34:24 --> Controller Class Initialized
INFO - 2016-11-04 16:34:24 --> Model Class Initialized
INFO - 2016-11-04 16:34:24 --> Model Class Initialized
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:34:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:34:24 --> Final output sent to browser
DEBUG - 2016-11-04 16:34:24 --> Total execution time: 0.4748
INFO - 2016-11-04 16:34:28 --> Config Class Initialized
INFO - 2016-11-04 16:34:28 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:34:28 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:34:28 --> Utf8 Class Initialized
INFO - 2016-11-04 16:34:28 --> URI Class Initialized
INFO - 2016-11-04 16:34:28 --> Router Class Initialized
INFO - 2016-11-04 16:34:28 --> Output Class Initialized
INFO - 2016-11-04 16:34:28 --> Security Class Initialized
DEBUG - 2016-11-04 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:34:28 --> Input Class Initialized
INFO - 2016-11-04 16:34:28 --> Language Class Initialized
INFO - 2016-11-04 16:34:28 --> Loader Class Initialized
INFO - 2016-11-04 16:34:28 --> Helper loaded: url_helper
INFO - 2016-11-04 16:34:28 --> Helper loaded: form_helper
INFO - 2016-11-04 16:34:28 --> Database Driver Class Initialized
INFO - 2016-11-04 16:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:34:28 --> Controller Class Initialized
INFO - 2016-11-04 16:34:28 --> Model Class Initialized
INFO - 2016-11-04 16:34:28 --> Form Validation Class Initialized
INFO - 2016-11-04 16:34:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:34:28 --> Final output sent to browser
DEBUG - 2016-11-04 16:34:28 --> Total execution time: 0.3327
INFO - 2016-11-04 16:35:07 --> Config Class Initialized
INFO - 2016-11-04 16:35:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:35:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:35:07 --> Utf8 Class Initialized
INFO - 2016-11-04 16:35:07 --> URI Class Initialized
INFO - 2016-11-04 16:35:07 --> Router Class Initialized
INFO - 2016-11-04 16:35:07 --> Output Class Initialized
INFO - 2016-11-04 16:35:07 --> Security Class Initialized
DEBUG - 2016-11-04 16:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:35:07 --> Input Class Initialized
INFO - 2016-11-04 16:35:07 --> Language Class Initialized
INFO - 2016-11-04 16:35:07 --> Loader Class Initialized
INFO - 2016-11-04 16:35:07 --> Helper loaded: url_helper
INFO - 2016-11-04 16:35:07 --> Helper loaded: form_helper
INFO - 2016-11-04 16:35:07 --> Database Driver Class Initialized
INFO - 2016-11-04 16:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:35:07 --> Controller Class Initialized
INFO - 2016-11-04 16:35:07 --> Model Class Initialized
INFO - 2016-11-04 16:35:07 --> Form Validation Class Initialized
INFO - 2016-11-04 16:35:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:35:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:35:08 --> Final output sent to browser
DEBUG - 2016-11-04 16:35:08 --> Total execution time: 0.8506
INFO - 2016-11-04 16:37:21 --> Config Class Initialized
INFO - 2016-11-04 16:37:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:37:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:37:21 --> Utf8 Class Initialized
INFO - 2016-11-04 16:37:21 --> URI Class Initialized
INFO - 2016-11-04 16:37:21 --> Router Class Initialized
INFO - 2016-11-04 16:37:21 --> Output Class Initialized
INFO - 2016-11-04 16:37:21 --> Security Class Initialized
DEBUG - 2016-11-04 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:37:22 --> Input Class Initialized
INFO - 2016-11-04 16:37:22 --> Language Class Initialized
INFO - 2016-11-04 16:37:22 --> Loader Class Initialized
INFO - 2016-11-04 16:37:22 --> Helper loaded: url_helper
INFO - 2016-11-04 16:37:22 --> Helper loaded: form_helper
INFO - 2016-11-04 16:37:22 --> Database Driver Class Initialized
INFO - 2016-11-04 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:37:22 --> Controller Class Initialized
INFO - 2016-11-04 16:37:22 --> Model Class Initialized
INFO - 2016-11-04 16:37:22 --> Model Class Initialized
DEBUG - 2016-11-04 16:37:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 16:37:22 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 114
ERROR - 2016-11-04 16:37:22 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 114
INFO - 2016-11-04 16:37:22 --> Config Class Initialized
INFO - 2016-11-04 16:37:22 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:37:22 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:37:22 --> Utf8 Class Initialized
INFO - 2016-11-04 16:37:22 --> URI Class Initialized
DEBUG - 2016-11-04 16:37:22 --> No URI present. Default controller set.
INFO - 2016-11-04 16:37:22 --> Router Class Initialized
INFO - 2016-11-04 16:37:22 --> Output Class Initialized
INFO - 2016-11-04 16:37:22 --> Security Class Initialized
DEBUG - 2016-11-04 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:37:22 --> Input Class Initialized
INFO - 2016-11-04 16:37:22 --> Language Class Initialized
INFO - 2016-11-04 16:37:22 --> Loader Class Initialized
INFO - 2016-11-04 16:37:22 --> Helper loaded: url_helper
INFO - 2016-11-04 16:37:22 --> Helper loaded: form_helper
INFO - 2016-11-04 16:37:22 --> Database Driver Class Initialized
INFO - 2016-11-04 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:37:22 --> Controller Class Initialized
INFO - 2016-11-04 16:37:22 --> Model Class Initialized
INFO - 2016-11-04 16:37:22 --> Model Class Initialized
INFO - 2016-11-04 16:37:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:37:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 16:37:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:37:22 --> Final output sent to browser
DEBUG - 2016-11-04 16:37:22 --> Total execution time: 0.3862
INFO - 2016-11-04 16:37:38 --> Config Class Initialized
INFO - 2016-11-04 16:37:38 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:37:38 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:37:38 --> Utf8 Class Initialized
INFO - 2016-11-04 16:37:38 --> URI Class Initialized
INFO - 2016-11-04 16:37:38 --> Router Class Initialized
INFO - 2016-11-04 16:37:38 --> Output Class Initialized
INFO - 2016-11-04 16:37:38 --> Security Class Initialized
DEBUG - 2016-11-04 16:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:37:38 --> Input Class Initialized
INFO - 2016-11-04 16:37:38 --> Language Class Initialized
INFO - 2016-11-04 16:37:38 --> Loader Class Initialized
INFO - 2016-11-04 16:37:38 --> Helper loaded: url_helper
INFO - 2016-11-04 16:37:38 --> Helper loaded: form_helper
INFO - 2016-11-04 16:37:38 --> Database Driver Class Initialized
INFO - 2016-11-04 16:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:37:38 --> Controller Class Initialized
INFO - 2016-11-04 16:37:38 --> Model Class Initialized
INFO - 2016-11-04 16:37:38 --> Model Class Initialized
DEBUG - 2016-11-04 16:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 16:37:38 --> Model Class Initialized
INFO - 2016-11-04 16:37:38 --> Final output sent to browser
DEBUG - 2016-11-04 16:37:38 --> Total execution time: 0.3360
INFO - 2016-11-04 16:37:39 --> Config Class Initialized
INFO - 2016-11-04 16:37:39 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:37:39 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:37:39 --> Utf8 Class Initialized
INFO - 2016-11-04 16:37:39 --> URI Class Initialized
DEBUG - 2016-11-04 16:37:39 --> No URI present. Default controller set.
INFO - 2016-11-04 16:37:39 --> Router Class Initialized
INFO - 2016-11-04 16:37:39 --> Output Class Initialized
INFO - 2016-11-04 16:37:39 --> Security Class Initialized
DEBUG - 2016-11-04 16:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:37:39 --> Input Class Initialized
INFO - 2016-11-04 16:37:39 --> Language Class Initialized
INFO - 2016-11-04 16:37:39 --> Loader Class Initialized
INFO - 2016-11-04 16:37:39 --> Helper loaded: url_helper
INFO - 2016-11-04 16:37:39 --> Helper loaded: form_helper
INFO - 2016-11-04 16:37:39 --> Database Driver Class Initialized
INFO - 2016-11-04 16:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:37:39 --> Controller Class Initialized
INFO - 2016-11-04 16:37:39 --> Model Class Initialized
INFO - 2016-11-04 16:37:39 --> Model Class Initialized
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:37:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:37:39 --> Final output sent to browser
DEBUG - 2016-11-04 16:37:39 --> Total execution time: 0.4603
INFO - 2016-11-04 16:37:53 --> Config Class Initialized
INFO - 2016-11-04 16:37:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:37:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:37:53 --> Utf8 Class Initialized
INFO - 2016-11-04 16:37:53 --> URI Class Initialized
INFO - 2016-11-04 16:37:53 --> Router Class Initialized
INFO - 2016-11-04 16:37:53 --> Output Class Initialized
INFO - 2016-11-04 16:37:53 --> Security Class Initialized
DEBUG - 2016-11-04 16:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:37:53 --> Input Class Initialized
INFO - 2016-11-04 16:37:53 --> Language Class Initialized
INFO - 2016-11-04 16:37:53 --> Loader Class Initialized
INFO - 2016-11-04 16:37:53 --> Helper loaded: url_helper
INFO - 2016-11-04 16:37:53 --> Helper loaded: form_helper
INFO - 2016-11-04 16:37:53 --> Database Driver Class Initialized
INFO - 2016-11-04 16:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:37:53 --> Controller Class Initialized
INFO - 2016-11-04 16:37:53 --> Model Class Initialized
INFO - 2016-11-04 16:37:53 --> Model Class Initialized
DEBUG - 2016-11-04 16:37:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 16:37:53 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 114
ERROR - 2016-11-04 16:37:53 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 114
INFO - 2016-11-04 16:37:53 --> Config Class Initialized
INFO - 2016-11-04 16:37:54 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:37:54 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:37:54 --> Utf8 Class Initialized
INFO - 2016-11-04 16:37:54 --> URI Class Initialized
DEBUG - 2016-11-04 16:37:54 --> No URI present. Default controller set.
INFO - 2016-11-04 16:37:54 --> Router Class Initialized
INFO - 2016-11-04 16:37:54 --> Output Class Initialized
INFO - 2016-11-04 16:37:54 --> Security Class Initialized
DEBUG - 2016-11-04 16:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:37:54 --> Input Class Initialized
INFO - 2016-11-04 16:37:54 --> Language Class Initialized
INFO - 2016-11-04 16:37:54 --> Loader Class Initialized
INFO - 2016-11-04 16:37:54 --> Helper loaded: url_helper
INFO - 2016-11-04 16:37:54 --> Helper loaded: form_helper
INFO - 2016-11-04 16:37:54 --> Database Driver Class Initialized
INFO - 2016-11-04 16:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:37:54 --> Controller Class Initialized
INFO - 2016-11-04 16:37:54 --> Model Class Initialized
INFO - 2016-11-04 16:37:54 --> Model Class Initialized
INFO - 2016-11-04 16:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 16:37:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:37:54 --> Final output sent to browser
DEBUG - 2016-11-04 16:37:54 --> Total execution time: 0.3508
INFO - 2016-11-04 16:40:29 --> Config Class Initialized
INFO - 2016-11-04 16:40:29 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:40:29 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:40:29 --> Utf8 Class Initialized
INFO - 2016-11-04 16:40:29 --> URI Class Initialized
DEBUG - 2016-11-04 16:40:29 --> No URI present. Default controller set.
INFO - 2016-11-04 16:40:29 --> Router Class Initialized
INFO - 2016-11-04 16:40:29 --> Output Class Initialized
INFO - 2016-11-04 16:40:29 --> Security Class Initialized
DEBUG - 2016-11-04 16:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:40:29 --> Input Class Initialized
INFO - 2016-11-04 16:40:29 --> Language Class Initialized
INFO - 2016-11-04 16:40:29 --> Loader Class Initialized
INFO - 2016-11-04 16:40:29 --> Helper loaded: url_helper
INFO - 2016-11-04 16:40:29 --> Helper loaded: form_helper
INFO - 2016-11-04 16:40:29 --> Database Driver Class Initialized
INFO - 2016-11-04 16:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:40:29 --> Controller Class Initialized
INFO - 2016-11-04 16:40:29 --> Model Class Initialized
INFO - 2016-11-04 16:40:29 --> Model Class Initialized
INFO - 2016-11-04 16:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 16:40:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:40:29 --> Final output sent to browser
DEBUG - 2016-11-04 16:40:30 --> Total execution time: 0.4866
INFO - 2016-11-04 16:40:47 --> Config Class Initialized
INFO - 2016-11-04 16:40:47 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:40:47 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:40:47 --> Utf8 Class Initialized
INFO - 2016-11-04 16:40:47 --> URI Class Initialized
INFO - 2016-11-04 16:40:47 --> Router Class Initialized
INFO - 2016-11-04 16:40:47 --> Output Class Initialized
INFO - 2016-11-04 16:40:47 --> Security Class Initialized
DEBUG - 2016-11-04 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:40:47 --> Input Class Initialized
INFO - 2016-11-04 16:40:47 --> Language Class Initialized
INFO - 2016-11-04 16:40:47 --> Loader Class Initialized
INFO - 2016-11-04 16:40:47 --> Helper loaded: url_helper
INFO - 2016-11-04 16:40:47 --> Helper loaded: form_helper
INFO - 2016-11-04 16:40:47 --> Database Driver Class Initialized
INFO - 2016-11-04 16:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:40:47 --> Controller Class Initialized
INFO - 2016-11-04 16:40:47 --> Model Class Initialized
INFO - 2016-11-04 16:40:47 --> Model Class Initialized
DEBUG - 2016-11-04 16:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 16:40:47 --> Model Class Initialized
INFO - 2016-11-04 16:40:47 --> Final output sent to browser
DEBUG - 2016-11-04 16:40:47 --> Total execution time: 0.6669
INFO - 2016-11-04 16:40:47 --> Config Class Initialized
INFO - 2016-11-04 16:40:47 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:40:47 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:40:47 --> Utf8 Class Initialized
INFO - 2016-11-04 16:40:47 --> URI Class Initialized
DEBUG - 2016-11-04 16:40:47 --> No URI present. Default controller set.
INFO - 2016-11-04 16:40:47 --> Router Class Initialized
INFO - 2016-11-04 16:40:47 --> Output Class Initialized
INFO - 2016-11-04 16:40:47 --> Security Class Initialized
DEBUG - 2016-11-04 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:40:47 --> Input Class Initialized
INFO - 2016-11-04 16:40:47 --> Language Class Initialized
INFO - 2016-11-04 16:40:47 --> Loader Class Initialized
INFO - 2016-11-04 16:40:47 --> Helper loaded: url_helper
INFO - 2016-11-04 16:40:47 --> Helper loaded: form_helper
INFO - 2016-11-04 16:40:47 --> Database Driver Class Initialized
INFO - 2016-11-04 16:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:40:47 --> Controller Class Initialized
INFO - 2016-11-04 16:40:47 --> Model Class Initialized
INFO - 2016-11-04 16:40:47 --> Model Class Initialized
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:40:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:40:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:40:48 --> Final output sent to browser
DEBUG - 2016-11-04 16:40:48 --> Total execution time: 0.4680
INFO - 2016-11-04 16:43:37 --> Config Class Initialized
INFO - 2016-11-04 16:43:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:43:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:43:37 --> Utf8 Class Initialized
INFO - 2016-11-04 16:43:37 --> URI Class Initialized
INFO - 2016-11-04 16:43:37 --> Router Class Initialized
INFO - 2016-11-04 16:43:37 --> Output Class Initialized
INFO - 2016-11-04 16:43:37 --> Security Class Initialized
DEBUG - 2016-11-04 16:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:43:37 --> Input Class Initialized
INFO - 2016-11-04 16:43:37 --> Language Class Initialized
INFO - 2016-11-04 16:43:37 --> Loader Class Initialized
INFO - 2016-11-04 16:43:37 --> Helper loaded: url_helper
INFO - 2016-11-04 16:43:37 --> Helper loaded: form_helper
INFO - 2016-11-04 16:43:37 --> Database Driver Class Initialized
INFO - 2016-11-04 16:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:43:37 --> Controller Class Initialized
INFO - 2016-11-04 16:43:37 --> Model Class Initialized
INFO - 2016-11-04 16:43:37 --> Form Validation Class Initialized
INFO - 2016-11-04 16:43:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:43:37 --> Final output sent to browser
DEBUG - 2016-11-04 16:43:37 --> Total execution time: 0.2907
INFO - 2016-11-04 16:44:38 --> Config Class Initialized
INFO - 2016-11-04 16:44:38 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:44:38 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:44:38 --> Utf8 Class Initialized
INFO - 2016-11-04 16:44:38 --> URI Class Initialized
DEBUG - 2016-11-04 16:44:38 --> No URI present. Default controller set.
INFO - 2016-11-04 16:44:38 --> Router Class Initialized
INFO - 2016-11-04 16:44:38 --> Output Class Initialized
INFO - 2016-11-04 16:44:38 --> Security Class Initialized
DEBUG - 2016-11-04 16:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:44:38 --> Input Class Initialized
INFO - 2016-11-04 16:44:38 --> Language Class Initialized
INFO - 2016-11-04 16:44:38 --> Loader Class Initialized
INFO - 2016-11-04 16:44:38 --> Helper loaded: url_helper
INFO - 2016-11-04 16:44:38 --> Helper loaded: form_helper
INFO - 2016-11-04 16:44:38 --> Database Driver Class Initialized
INFO - 2016-11-04 16:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:44:38 --> Controller Class Initialized
INFO - 2016-11-04 16:44:38 --> Model Class Initialized
INFO - 2016-11-04 16:44:38 --> Model Class Initialized
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:44:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:44:38 --> Final output sent to browser
DEBUG - 2016-11-04 16:44:38 --> Total execution time: 0.4357
INFO - 2016-11-04 16:46:18 --> Config Class Initialized
INFO - 2016-11-04 16:46:18 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:46:18 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:46:18 --> Utf8 Class Initialized
INFO - 2016-11-04 16:46:18 --> URI Class Initialized
DEBUG - 2016-11-04 16:46:18 --> No URI present. Default controller set.
INFO - 2016-11-04 16:46:18 --> Router Class Initialized
INFO - 2016-11-04 16:46:18 --> Output Class Initialized
INFO - 2016-11-04 16:46:18 --> Security Class Initialized
DEBUG - 2016-11-04 16:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:46:18 --> Input Class Initialized
INFO - 2016-11-04 16:46:18 --> Language Class Initialized
INFO - 2016-11-04 16:46:18 --> Loader Class Initialized
INFO - 2016-11-04 16:46:18 --> Helper loaded: url_helper
INFO - 2016-11-04 16:46:18 --> Helper loaded: form_helper
INFO - 2016-11-04 16:46:19 --> Database Driver Class Initialized
INFO - 2016-11-04 16:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:46:19 --> Controller Class Initialized
INFO - 2016-11-04 16:46:19 --> Model Class Initialized
INFO - 2016-11-04 16:46:19 --> Model Class Initialized
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:46:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:46:19 --> Final output sent to browser
DEBUG - 2016-11-04 16:46:19 --> Total execution time: 0.4704
INFO - 2016-11-04 16:47:16 --> Config Class Initialized
INFO - 2016-11-04 16:47:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:47:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:47:16 --> Utf8 Class Initialized
INFO - 2016-11-04 16:47:16 --> URI Class Initialized
INFO - 2016-11-04 16:47:16 --> Router Class Initialized
INFO - 2016-11-04 16:47:16 --> Output Class Initialized
INFO - 2016-11-04 16:47:16 --> Security Class Initialized
DEBUG - 2016-11-04 16:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:47:16 --> Input Class Initialized
INFO - 2016-11-04 16:47:16 --> Language Class Initialized
INFO - 2016-11-04 16:47:16 --> Loader Class Initialized
INFO - 2016-11-04 16:47:16 --> Helper loaded: url_helper
INFO - 2016-11-04 16:47:16 --> Helper loaded: form_helper
INFO - 2016-11-04 16:47:16 --> Database Driver Class Initialized
INFO - 2016-11-04 16:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:47:16 --> Controller Class Initialized
INFO - 2016-11-04 16:47:16 --> Model Class Initialized
INFO - 2016-11-04 16:47:16 --> Form Validation Class Initialized
INFO - 2016-11-04 16:47:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:47:16 --> Final output sent to browser
DEBUG - 2016-11-04 16:47:16 --> Total execution time: 0.2911
INFO - 2016-11-04 16:47:18 --> Config Class Initialized
INFO - 2016-11-04 16:47:18 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:47:18 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:47:18 --> Utf8 Class Initialized
INFO - 2016-11-04 16:47:18 --> URI Class Initialized
DEBUG - 2016-11-04 16:47:18 --> No URI present. Default controller set.
INFO - 2016-11-04 16:47:18 --> Router Class Initialized
INFO - 2016-11-04 16:47:18 --> Output Class Initialized
INFO - 2016-11-04 16:47:18 --> Security Class Initialized
DEBUG - 2016-11-04 16:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:47:19 --> Input Class Initialized
INFO - 2016-11-04 16:47:19 --> Language Class Initialized
INFO - 2016-11-04 16:47:19 --> Loader Class Initialized
INFO - 2016-11-04 16:47:19 --> Helper loaded: url_helper
INFO - 2016-11-04 16:47:19 --> Helper loaded: form_helper
INFO - 2016-11-04 16:47:19 --> Database Driver Class Initialized
INFO - 2016-11-04 16:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:47:19 --> Controller Class Initialized
INFO - 2016-11-04 16:47:19 --> Model Class Initialized
INFO - 2016-11-04 16:47:19 --> Model Class Initialized
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:47:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:47:19 --> Final output sent to browser
DEBUG - 2016-11-04 16:47:19 --> Total execution time: 0.4586
INFO - 2016-11-04 16:57:57 --> Config Class Initialized
INFO - 2016-11-04 16:57:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:57:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:57:57 --> Utf8 Class Initialized
INFO - 2016-11-04 16:57:58 --> URI Class Initialized
INFO - 2016-11-04 16:57:58 --> Router Class Initialized
INFO - 2016-11-04 16:57:58 --> Output Class Initialized
INFO - 2016-11-04 16:57:58 --> Security Class Initialized
DEBUG - 2016-11-04 16:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:57:58 --> Input Class Initialized
INFO - 2016-11-04 16:57:58 --> Language Class Initialized
INFO - 2016-11-04 16:57:58 --> Loader Class Initialized
INFO - 2016-11-04 16:57:58 --> Helper loaded: url_helper
INFO - 2016-11-04 16:57:58 --> Helper loaded: form_helper
INFO - 2016-11-04 16:57:58 --> Database Driver Class Initialized
INFO - 2016-11-04 16:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:57:58 --> Controller Class Initialized
INFO - 2016-11-04 16:57:58 --> Model Class Initialized
INFO - 2016-11-04 16:57:58 --> Form Validation Class Initialized
INFO - 2016-11-04 16:57:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 16:57:58 --> Final output sent to browser
DEBUG - 2016-11-04 16:57:58 --> Total execution time: 0.2863
INFO - 2016-11-04 16:58:00 --> Config Class Initialized
INFO - 2016-11-04 16:58:00 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:58:00 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:58:00 --> Utf8 Class Initialized
INFO - 2016-11-04 16:58:00 --> URI Class Initialized
DEBUG - 2016-11-04 16:58:00 --> No URI present. Default controller set.
INFO - 2016-11-04 16:58:00 --> Router Class Initialized
INFO - 2016-11-04 16:58:00 --> Output Class Initialized
INFO - 2016-11-04 16:58:00 --> Security Class Initialized
DEBUG - 2016-11-04 16:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:58:00 --> Input Class Initialized
INFO - 2016-11-04 16:58:00 --> Language Class Initialized
INFO - 2016-11-04 16:58:00 --> Loader Class Initialized
INFO - 2016-11-04 16:58:00 --> Helper loaded: url_helper
INFO - 2016-11-04 16:58:00 --> Helper loaded: form_helper
INFO - 2016-11-04 16:58:00 --> Database Driver Class Initialized
INFO - 2016-11-04 16:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:58:00 --> Controller Class Initialized
INFO - 2016-11-04 16:58:00 --> Model Class Initialized
INFO - 2016-11-04 16:58:00 --> Model Class Initialized
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:58:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:58:00 --> Final output sent to browser
DEBUG - 2016-11-04 16:58:00 --> Total execution time: 0.5201
INFO - 2016-11-04 16:58:45 --> Config Class Initialized
INFO - 2016-11-04 16:58:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 16:58:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 16:58:45 --> Utf8 Class Initialized
INFO - 2016-11-04 16:58:45 --> URI Class Initialized
DEBUG - 2016-11-04 16:58:45 --> No URI present. Default controller set.
INFO - 2016-11-04 16:58:45 --> Router Class Initialized
INFO - 2016-11-04 16:58:45 --> Output Class Initialized
INFO - 2016-11-04 16:58:45 --> Security Class Initialized
DEBUG - 2016-11-04 16:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 16:58:45 --> Input Class Initialized
INFO - 2016-11-04 16:58:45 --> Language Class Initialized
INFO - 2016-11-04 16:58:45 --> Loader Class Initialized
INFO - 2016-11-04 16:58:45 --> Helper loaded: url_helper
INFO - 2016-11-04 16:58:45 --> Helper loaded: form_helper
INFO - 2016-11-04 16:58:45 --> Database Driver Class Initialized
INFO - 2016-11-04 16:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 16:58:45 --> Controller Class Initialized
INFO - 2016-11-04 16:58:45 --> Model Class Initialized
INFO - 2016-11-04 16:58:45 --> Model Class Initialized
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 16:58:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 16:58:45 --> Final output sent to browser
DEBUG - 2016-11-04 16:58:45 --> Total execution time: 0.4677
INFO - 2016-11-04 17:00:03 --> Config Class Initialized
INFO - 2016-11-04 17:00:03 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:00:03 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:00:03 --> Utf8 Class Initialized
INFO - 2016-11-04 17:00:03 --> URI Class Initialized
DEBUG - 2016-11-04 17:00:03 --> No URI present. Default controller set.
INFO - 2016-11-04 17:00:03 --> Router Class Initialized
INFO - 2016-11-04 17:00:03 --> Output Class Initialized
INFO - 2016-11-04 17:00:03 --> Security Class Initialized
DEBUG - 2016-11-04 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:00:03 --> Input Class Initialized
INFO - 2016-11-04 17:00:03 --> Language Class Initialized
INFO - 2016-11-04 17:00:03 --> Loader Class Initialized
INFO - 2016-11-04 17:00:03 --> Helper loaded: url_helper
INFO - 2016-11-04 17:00:03 --> Helper loaded: form_helper
INFO - 2016-11-04 17:00:03 --> Database Driver Class Initialized
INFO - 2016-11-04 17:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:00:03 --> Controller Class Initialized
INFO - 2016-11-04 17:00:03 --> Model Class Initialized
INFO - 2016-11-04 17:00:03 --> Model Class Initialized
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:00:03 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:00:03 --> Final output sent to browser
DEBUG - 2016-11-04 17:00:03 --> Total execution time: 0.4617
INFO - 2016-11-04 17:11:32 --> Config Class Initialized
INFO - 2016-11-04 17:11:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:11:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:11:32 --> Utf8 Class Initialized
INFO - 2016-11-04 17:11:32 --> URI Class Initialized
DEBUG - 2016-11-04 17:11:32 --> No URI present. Default controller set.
INFO - 2016-11-04 17:11:32 --> Router Class Initialized
INFO - 2016-11-04 17:11:32 --> Output Class Initialized
INFO - 2016-11-04 17:11:32 --> Security Class Initialized
DEBUG - 2016-11-04 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:11:32 --> Input Class Initialized
INFO - 2016-11-04 17:11:32 --> Language Class Initialized
INFO - 2016-11-04 17:11:32 --> Loader Class Initialized
INFO - 2016-11-04 17:11:33 --> Helper loaded: url_helper
INFO - 2016-11-04 17:11:33 --> Helper loaded: form_helper
INFO - 2016-11-04 17:11:33 --> Database Driver Class Initialized
INFO - 2016-11-04 17:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:11:33 --> Controller Class Initialized
INFO - 2016-11-04 17:11:33 --> Model Class Initialized
INFO - 2016-11-04 17:11:33 --> Model Class Initialized
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:11:33 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:11:33 --> Final output sent to browser
DEBUG - 2016-11-04 17:11:33 --> Total execution time: 0.4630
INFO - 2016-11-04 17:33:40 --> Config Class Initialized
INFO - 2016-11-04 17:33:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:33:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:33:40 --> Utf8 Class Initialized
INFO - 2016-11-04 17:33:40 --> URI Class Initialized
DEBUG - 2016-11-04 17:33:40 --> No URI present. Default controller set.
INFO - 2016-11-04 17:33:40 --> Router Class Initialized
INFO - 2016-11-04 17:33:40 --> Output Class Initialized
INFO - 2016-11-04 17:33:40 --> Security Class Initialized
DEBUG - 2016-11-04 17:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:33:40 --> Input Class Initialized
INFO - 2016-11-04 17:33:40 --> Language Class Initialized
INFO - 2016-11-04 17:33:40 --> Loader Class Initialized
INFO - 2016-11-04 17:33:40 --> Helper loaded: url_helper
INFO - 2016-11-04 17:33:40 --> Helper loaded: form_helper
INFO - 2016-11-04 17:33:40 --> Database Driver Class Initialized
INFO - 2016-11-04 17:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:33:40 --> Controller Class Initialized
INFO - 2016-11-04 17:33:40 --> Model Class Initialized
INFO - 2016-11-04 17:33:40 --> Model Class Initialized
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:33:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:33:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:33:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:33:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:33:41 --> Final output sent to browser
DEBUG - 2016-11-04 17:33:41 --> Total execution time: 0.4584
INFO - 2016-11-04 17:44:11 --> Config Class Initialized
INFO - 2016-11-04 17:44:11 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:44:11 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:44:11 --> Utf8 Class Initialized
INFO - 2016-11-04 17:44:11 --> URI Class Initialized
DEBUG - 2016-11-04 17:44:11 --> No URI present. Default controller set.
INFO - 2016-11-04 17:44:11 --> Router Class Initialized
INFO - 2016-11-04 17:44:11 --> Output Class Initialized
INFO - 2016-11-04 17:44:11 --> Security Class Initialized
DEBUG - 2016-11-04 17:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:44:11 --> Input Class Initialized
INFO - 2016-11-04 17:44:11 --> Language Class Initialized
INFO - 2016-11-04 17:44:11 --> Loader Class Initialized
INFO - 2016-11-04 17:44:11 --> Helper loaded: url_helper
INFO - 2016-11-04 17:44:11 --> Helper loaded: form_helper
INFO - 2016-11-04 17:44:11 --> Database Driver Class Initialized
INFO - 2016-11-04 17:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:44:11 --> Controller Class Initialized
INFO - 2016-11-04 17:44:11 --> Model Class Initialized
INFO - 2016-11-04 17:44:11 --> Model Class Initialized
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:44:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:44:11 --> Final output sent to browser
DEBUG - 2016-11-04 17:44:12 --> Total execution time: 0.4757
INFO - 2016-11-04 17:44:49 --> Config Class Initialized
INFO - 2016-11-04 17:44:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:44:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:44:49 --> Utf8 Class Initialized
INFO - 2016-11-04 17:44:49 --> URI Class Initialized
INFO - 2016-11-04 17:44:49 --> Router Class Initialized
INFO - 2016-11-04 17:44:49 --> Output Class Initialized
INFO - 2016-11-04 17:44:49 --> Security Class Initialized
DEBUG - 2016-11-04 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:44:49 --> Input Class Initialized
INFO - 2016-11-04 17:44:49 --> Language Class Initialized
INFO - 2016-11-04 17:44:49 --> Loader Class Initialized
INFO - 2016-11-04 17:44:49 --> Helper loaded: url_helper
INFO - 2016-11-04 17:44:49 --> Helper loaded: form_helper
INFO - 2016-11-04 17:44:49 --> Database Driver Class Initialized
INFO - 2016-11-04 17:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:44:49 --> Controller Class Initialized
INFO - 2016-11-04 17:44:49 --> Model Class Initialized
INFO - 2016-11-04 17:44:49 --> Form Validation Class Initialized
INFO - 2016-11-04 17:44:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 17:44:49 --> Final output sent to browser
DEBUG - 2016-11-04 17:44:50 --> Total execution time: 0.7206
INFO - 2016-11-04 17:44:57 --> Config Class Initialized
INFO - 2016-11-04 17:44:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:44:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:44:57 --> Utf8 Class Initialized
INFO - 2016-11-04 17:44:57 --> URI Class Initialized
DEBUG - 2016-11-04 17:44:57 --> No URI present. Default controller set.
INFO - 2016-11-04 17:44:57 --> Router Class Initialized
INFO - 2016-11-04 17:44:57 --> Output Class Initialized
INFO - 2016-11-04 17:44:57 --> Security Class Initialized
DEBUG - 2016-11-04 17:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:44:57 --> Input Class Initialized
INFO - 2016-11-04 17:44:57 --> Language Class Initialized
INFO - 2016-11-04 17:44:57 --> Loader Class Initialized
INFO - 2016-11-04 17:44:57 --> Helper loaded: url_helper
INFO - 2016-11-04 17:44:57 --> Helper loaded: form_helper
INFO - 2016-11-04 17:44:57 --> Database Driver Class Initialized
INFO - 2016-11-04 17:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:44:57 --> Controller Class Initialized
INFO - 2016-11-04 17:44:57 --> Model Class Initialized
INFO - 2016-11-04 17:44:57 --> Model Class Initialized
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:44:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:44:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:44:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:44:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:44:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:44:58 --> Final output sent to browser
DEBUG - 2016-11-04 17:44:58 --> Total execution time: 0.4570
INFO - 2016-11-04 17:47:59 --> Config Class Initialized
INFO - 2016-11-04 17:47:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:47:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:47:59 --> Utf8 Class Initialized
INFO - 2016-11-04 17:47:59 --> URI Class Initialized
DEBUG - 2016-11-04 17:47:59 --> No URI present. Default controller set.
INFO - 2016-11-04 17:47:59 --> Router Class Initialized
INFO - 2016-11-04 17:47:59 --> Output Class Initialized
INFO - 2016-11-04 17:47:59 --> Security Class Initialized
DEBUG - 2016-11-04 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:47:59 --> Input Class Initialized
INFO - 2016-11-04 17:47:59 --> Language Class Initialized
INFO - 2016-11-04 17:47:59 --> Loader Class Initialized
INFO - 2016-11-04 17:47:59 --> Helper loaded: url_helper
INFO - 2016-11-04 17:47:59 --> Helper loaded: form_helper
INFO - 2016-11-04 17:47:59 --> Database Driver Class Initialized
INFO - 2016-11-04 17:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:47:59 --> Controller Class Initialized
INFO - 2016-11-04 17:47:59 --> Model Class Initialized
INFO - 2016-11-04 17:47:59 --> Model Class Initialized
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
ERROR - 2016-11-04 17:48:00 --> Severity: Notice --> Undefined index: all_Role C:\xampp\htdocs\LMS\app\controllers\Auth.php 70
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
ERROR - 2016-11-04 17:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\LMS\app\views\admin\add_user.php 59
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:48:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:48:00 --> Final output sent to browser
DEBUG - 2016-11-04 17:48:00 --> Total execution time: 0.5181
INFO - 2016-11-04 17:48:20 --> Config Class Initialized
INFO - 2016-11-04 17:48:20 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:48:20 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:48:20 --> Utf8 Class Initialized
INFO - 2016-11-04 17:48:20 --> URI Class Initialized
DEBUG - 2016-11-04 17:48:20 --> No URI present. Default controller set.
INFO - 2016-11-04 17:48:20 --> Router Class Initialized
INFO - 2016-11-04 17:48:20 --> Output Class Initialized
INFO - 2016-11-04 17:48:20 --> Security Class Initialized
DEBUG - 2016-11-04 17:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:48:20 --> Input Class Initialized
INFO - 2016-11-04 17:48:20 --> Language Class Initialized
INFO - 2016-11-04 17:48:20 --> Loader Class Initialized
INFO - 2016-11-04 17:48:20 --> Helper loaded: url_helper
INFO - 2016-11-04 17:48:20 --> Helper loaded: form_helper
INFO - 2016-11-04 17:48:20 --> Database Driver Class Initialized
INFO - 2016-11-04 17:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:48:20 --> Controller Class Initialized
INFO - 2016-11-04 17:48:20 --> Model Class Initialized
INFO - 2016-11-04 17:48:20 --> Model Class Initialized
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:48:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:48:20 --> Final output sent to browser
DEBUG - 2016-11-04 17:48:20 --> Total execution time: 0.4229
INFO - 2016-11-04 17:49:21 --> Config Class Initialized
INFO - 2016-11-04 17:49:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:49:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:49:21 --> Utf8 Class Initialized
INFO - 2016-11-04 17:49:21 --> URI Class Initialized
DEBUG - 2016-11-04 17:49:21 --> No URI present. Default controller set.
INFO - 2016-11-04 17:49:21 --> Router Class Initialized
INFO - 2016-11-04 17:49:21 --> Output Class Initialized
INFO - 2016-11-04 17:49:21 --> Security Class Initialized
DEBUG - 2016-11-04 17:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:49:21 --> Input Class Initialized
INFO - 2016-11-04 17:49:21 --> Language Class Initialized
INFO - 2016-11-04 17:49:21 --> Loader Class Initialized
INFO - 2016-11-04 17:49:21 --> Helper loaded: url_helper
INFO - 2016-11-04 17:49:22 --> Helper loaded: form_helper
INFO - 2016-11-04 17:49:22 --> Database Driver Class Initialized
INFO - 2016-11-04 17:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:49:22 --> Controller Class Initialized
INFO - 2016-11-04 17:49:22 --> Model Class Initialized
INFO - 2016-11-04 17:49:22 --> Model Class Initialized
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:49:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:49:22 --> Final output sent to browser
DEBUG - 2016-11-04 17:49:22 --> Total execution time: 0.4403
INFO - 2016-11-04 17:54:48 --> Config Class Initialized
INFO - 2016-11-04 17:54:48 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:54:48 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:54:48 --> Utf8 Class Initialized
INFO - 2016-11-04 17:54:48 --> URI Class Initialized
DEBUG - 2016-11-04 17:54:48 --> No URI present. Default controller set.
INFO - 2016-11-04 17:54:48 --> Router Class Initialized
INFO - 2016-11-04 17:54:48 --> Output Class Initialized
INFO - 2016-11-04 17:54:48 --> Security Class Initialized
DEBUG - 2016-11-04 17:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:54:48 --> Input Class Initialized
INFO - 2016-11-04 17:54:48 --> Language Class Initialized
INFO - 2016-11-04 17:54:48 --> Loader Class Initialized
INFO - 2016-11-04 17:54:48 --> Helper loaded: url_helper
INFO - 2016-11-04 17:54:48 --> Helper loaded: form_helper
INFO - 2016-11-04 17:54:48 --> Database Driver Class Initialized
INFO - 2016-11-04 17:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:54:48 --> Controller Class Initialized
INFO - 2016-11-04 17:54:48 --> Model Class Initialized
INFO - 2016-11-04 17:54:48 --> Model Class Initialized
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:54:48 --> Final output sent to browser
DEBUG - 2016-11-04 17:54:49 --> Total execution time: 0.4738
INFO - 2016-11-04 17:56:06 --> Config Class Initialized
INFO - 2016-11-04 17:56:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:56:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:56:06 --> Utf8 Class Initialized
INFO - 2016-11-04 17:56:06 --> URI Class Initialized
INFO - 2016-11-04 17:56:06 --> Router Class Initialized
INFO - 2016-11-04 17:56:06 --> Output Class Initialized
INFO - 2016-11-04 17:56:06 --> Security Class Initialized
DEBUG - 2016-11-04 17:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:56:06 --> Input Class Initialized
INFO - 2016-11-04 17:56:06 --> Language Class Initialized
INFO - 2016-11-04 17:56:06 --> Loader Class Initialized
INFO - 2016-11-04 17:56:06 --> Helper loaded: url_helper
INFO - 2016-11-04 17:56:06 --> Helper loaded: form_helper
INFO - 2016-11-04 17:56:06 --> Database Driver Class Initialized
INFO - 2016-11-04 17:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:56:06 --> Controller Class Initialized
INFO - 2016-11-04 17:56:06 --> Model Class Initialized
INFO - 2016-11-04 17:56:06 --> Form Validation Class Initialized
INFO - 2016-11-04 17:56:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 17:56:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:56:06 --> Final output sent to browser
DEBUG - 2016-11-04 17:56:06 --> Total execution time: 0.5546
INFO - 2016-11-04 17:56:13 --> Config Class Initialized
INFO - 2016-11-04 17:56:13 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:56:13 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:56:13 --> Utf8 Class Initialized
INFO - 2016-11-04 17:56:13 --> URI Class Initialized
INFO - 2016-11-04 17:56:13 --> Router Class Initialized
INFO - 2016-11-04 17:56:13 --> Output Class Initialized
INFO - 2016-11-04 17:56:13 --> Security Class Initialized
DEBUG - 2016-11-04 17:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:56:13 --> Input Class Initialized
INFO - 2016-11-04 17:56:13 --> Language Class Initialized
INFO - 2016-11-04 17:56:13 --> Loader Class Initialized
INFO - 2016-11-04 17:56:13 --> Helper loaded: url_helper
INFO - 2016-11-04 17:56:13 --> Helper loaded: form_helper
INFO - 2016-11-04 17:56:13 --> Database Driver Class Initialized
INFO - 2016-11-04 17:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:56:13 --> Controller Class Initialized
INFO - 2016-11-04 17:56:13 --> Model Class Initialized
INFO - 2016-11-04 17:56:13 --> Form Validation Class Initialized
INFO - 2016-11-04 17:56:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 17:56:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:56:13 --> Final output sent to browser
DEBUG - 2016-11-04 17:56:13 --> Total execution time: 0.4185
INFO - 2016-11-04 17:56:14 --> Config Class Initialized
INFO - 2016-11-04 17:56:14 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:56:14 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:56:14 --> Utf8 Class Initialized
INFO - 2016-11-04 17:56:15 --> URI Class Initialized
DEBUG - 2016-11-04 17:56:15 --> No URI present. Default controller set.
INFO - 2016-11-04 17:56:15 --> Router Class Initialized
INFO - 2016-11-04 17:56:15 --> Output Class Initialized
INFO - 2016-11-04 17:56:15 --> Security Class Initialized
DEBUG - 2016-11-04 17:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:56:15 --> Input Class Initialized
INFO - 2016-11-04 17:56:15 --> Language Class Initialized
INFO - 2016-11-04 17:56:15 --> Loader Class Initialized
INFO - 2016-11-04 17:56:15 --> Helper loaded: url_helper
INFO - 2016-11-04 17:56:15 --> Helper loaded: form_helper
INFO - 2016-11-04 17:56:15 --> Database Driver Class Initialized
INFO - 2016-11-04 17:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:56:15 --> Controller Class Initialized
INFO - 2016-11-04 17:56:15 --> Model Class Initialized
INFO - 2016-11-04 17:56:15 --> Model Class Initialized
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:56:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:56:15 --> Final output sent to browser
DEBUG - 2016-11-04 17:56:15 --> Total execution time: 0.5286
INFO - 2016-11-04 17:57:00 --> Config Class Initialized
INFO - 2016-11-04 17:57:00 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:57:00 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:57:00 --> Utf8 Class Initialized
INFO - 2016-11-04 17:57:00 --> URI Class Initialized
INFO - 2016-11-04 17:57:00 --> Router Class Initialized
INFO - 2016-11-04 17:57:00 --> Output Class Initialized
INFO - 2016-11-04 17:57:01 --> Security Class Initialized
DEBUG - 2016-11-04 17:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:57:01 --> Input Class Initialized
INFO - 2016-11-04 17:57:01 --> Language Class Initialized
INFO - 2016-11-04 17:57:01 --> Loader Class Initialized
INFO - 2016-11-04 17:57:01 --> Helper loaded: url_helper
INFO - 2016-11-04 17:57:01 --> Helper loaded: form_helper
INFO - 2016-11-04 17:57:01 --> Database Driver Class Initialized
INFO - 2016-11-04 17:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:57:01 --> Controller Class Initialized
INFO - 2016-11-04 17:57:01 --> Model Class Initialized
INFO - 2016-11-04 17:57:01 --> Model Class Initialized
DEBUG - 2016-11-04 17:57:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 17:57:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 17:57:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 17:57:01 --> Config Class Initialized
INFO - 2016-11-04 17:57:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:57:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:57:01 --> Utf8 Class Initialized
INFO - 2016-11-04 17:57:01 --> URI Class Initialized
DEBUG - 2016-11-04 17:57:01 --> No URI present. Default controller set.
INFO - 2016-11-04 17:57:01 --> Router Class Initialized
INFO - 2016-11-04 17:57:01 --> Output Class Initialized
INFO - 2016-11-04 17:57:02 --> Security Class Initialized
DEBUG - 2016-11-04 17:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:57:02 --> Input Class Initialized
INFO - 2016-11-04 17:57:02 --> Language Class Initialized
INFO - 2016-11-04 17:57:02 --> Loader Class Initialized
INFO - 2016-11-04 17:57:02 --> Helper loaded: url_helper
INFO - 2016-11-04 17:57:02 --> Helper loaded: form_helper
INFO - 2016-11-04 17:57:02 --> Database Driver Class Initialized
INFO - 2016-11-04 17:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:57:02 --> Controller Class Initialized
INFO - 2016-11-04 17:57:02 --> Model Class Initialized
INFO - 2016-11-04 17:57:02 --> Model Class Initialized
INFO - 2016-11-04 17:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 17:57:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:57:02 --> Final output sent to browser
DEBUG - 2016-11-04 17:57:02 --> Total execution time: 0.9269
INFO - 2016-11-04 17:57:30 --> Config Class Initialized
INFO - 2016-11-04 17:57:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:57:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:57:30 --> Utf8 Class Initialized
INFO - 2016-11-04 17:57:30 --> URI Class Initialized
DEBUG - 2016-11-04 17:57:30 --> No URI present. Default controller set.
INFO - 2016-11-04 17:57:31 --> Router Class Initialized
INFO - 2016-11-04 17:57:31 --> Output Class Initialized
INFO - 2016-11-04 17:57:31 --> Security Class Initialized
DEBUG - 2016-11-04 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:57:31 --> Input Class Initialized
INFO - 2016-11-04 17:57:31 --> Language Class Initialized
INFO - 2016-11-04 17:57:31 --> Loader Class Initialized
INFO - 2016-11-04 17:57:31 --> Helper loaded: url_helper
INFO - 2016-11-04 17:57:31 --> Helper loaded: form_helper
INFO - 2016-11-04 17:57:31 --> Database Driver Class Initialized
INFO - 2016-11-04 17:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:57:31 --> Controller Class Initialized
INFO - 2016-11-04 17:57:31 --> Model Class Initialized
INFO - 2016-11-04 17:57:31 --> Model Class Initialized
INFO - 2016-11-04 17:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 17:57:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:57:31 --> Final output sent to browser
DEBUG - 2016-11-04 17:57:31 --> Total execution time: 0.3406
INFO - 2016-11-04 17:57:45 --> Config Class Initialized
INFO - 2016-11-04 17:57:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:57:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:57:45 --> Utf8 Class Initialized
INFO - 2016-11-04 17:57:45 --> URI Class Initialized
DEBUG - 2016-11-04 17:57:45 --> No URI present. Default controller set.
INFO - 2016-11-04 17:57:45 --> Router Class Initialized
INFO - 2016-11-04 17:57:45 --> Output Class Initialized
INFO - 2016-11-04 17:57:45 --> Security Class Initialized
DEBUG - 2016-11-04 17:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:57:45 --> Input Class Initialized
INFO - 2016-11-04 17:57:45 --> Language Class Initialized
INFO - 2016-11-04 17:57:45 --> Loader Class Initialized
INFO - 2016-11-04 17:57:45 --> Helper loaded: url_helper
INFO - 2016-11-04 17:57:45 --> Helper loaded: form_helper
INFO - 2016-11-04 17:57:45 --> Database Driver Class Initialized
INFO - 2016-11-04 17:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:57:45 --> Controller Class Initialized
INFO - 2016-11-04 17:57:45 --> Model Class Initialized
INFO - 2016-11-04 17:57:45 --> Model Class Initialized
INFO - 2016-11-04 17:57:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:57:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 17:57:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:57:45 --> Final output sent to browser
DEBUG - 2016-11-04 17:57:45 --> Total execution time: 0.3383
INFO - 2016-11-04 17:58:06 --> Config Class Initialized
INFO - 2016-11-04 17:58:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:58:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:58:06 --> Utf8 Class Initialized
INFO - 2016-11-04 17:58:06 --> URI Class Initialized
DEBUG - 2016-11-04 17:58:06 --> No URI present. Default controller set.
INFO - 2016-11-04 17:58:06 --> Router Class Initialized
INFO - 2016-11-04 17:58:06 --> Output Class Initialized
INFO - 2016-11-04 17:58:06 --> Security Class Initialized
DEBUG - 2016-11-04 17:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:58:06 --> Input Class Initialized
INFO - 2016-11-04 17:58:06 --> Language Class Initialized
INFO - 2016-11-04 17:58:06 --> Loader Class Initialized
INFO - 2016-11-04 17:58:06 --> Helper loaded: url_helper
INFO - 2016-11-04 17:58:06 --> Helper loaded: form_helper
INFO - 2016-11-04 17:58:06 --> Database Driver Class Initialized
INFO - 2016-11-04 17:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:58:06 --> Controller Class Initialized
INFO - 2016-11-04 17:58:06 --> Model Class Initialized
INFO - 2016-11-04 17:58:06 --> Model Class Initialized
INFO - 2016-11-04 17:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 17:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:58:06 --> Final output sent to browser
DEBUG - 2016-11-04 17:58:06 --> Total execution time: 0.3217
INFO - 2016-11-04 17:58:15 --> Config Class Initialized
INFO - 2016-11-04 17:58:15 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:58:15 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:58:15 --> Utf8 Class Initialized
INFO - 2016-11-04 17:58:15 --> URI Class Initialized
INFO - 2016-11-04 17:58:15 --> Router Class Initialized
INFO - 2016-11-04 17:58:15 --> Output Class Initialized
INFO - 2016-11-04 17:58:15 --> Security Class Initialized
DEBUG - 2016-11-04 17:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:58:15 --> Input Class Initialized
INFO - 2016-11-04 17:58:15 --> Language Class Initialized
INFO - 2016-11-04 17:58:15 --> Loader Class Initialized
INFO - 2016-11-04 17:58:15 --> Helper loaded: url_helper
INFO - 2016-11-04 17:58:15 --> Helper loaded: form_helper
INFO - 2016-11-04 17:58:16 --> Database Driver Class Initialized
INFO - 2016-11-04 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:58:16 --> Controller Class Initialized
INFO - 2016-11-04 17:58:16 --> Model Class Initialized
INFO - 2016-11-04 17:58:16 --> Model Class Initialized
DEBUG - 2016-11-04 17:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 17:58:16 --> Model Class Initialized
ERROR - 2016-11-04 17:58:16 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
ERROR - 2016-11-04 17:58:16 --> Severity: Notice --> Undefined property: stdClass::$idrole C:\xampp\htdocs\LMS\app\controllers\Auth.php 105
INFO - 2016-11-04 17:58:16 --> Final output sent to browser
DEBUG - 2016-11-04 17:58:16 --> Total execution time: 0.3437
INFO - 2016-11-04 17:59:56 --> Config Class Initialized
INFO - 2016-11-04 17:59:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 17:59:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 17:59:56 --> Utf8 Class Initialized
INFO - 2016-11-04 17:59:56 --> URI Class Initialized
DEBUG - 2016-11-04 17:59:56 --> No URI present. Default controller set.
INFO - 2016-11-04 17:59:56 --> Router Class Initialized
INFO - 2016-11-04 17:59:56 --> Output Class Initialized
INFO - 2016-11-04 17:59:56 --> Security Class Initialized
DEBUG - 2016-11-04 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 17:59:56 --> Input Class Initialized
INFO - 2016-11-04 17:59:56 --> Language Class Initialized
INFO - 2016-11-04 17:59:56 --> Loader Class Initialized
INFO - 2016-11-04 17:59:56 --> Helper loaded: url_helper
INFO - 2016-11-04 17:59:56 --> Helper loaded: form_helper
INFO - 2016-11-04 17:59:56 --> Database Driver Class Initialized
INFO - 2016-11-04 17:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 17:59:56 --> Controller Class Initialized
INFO - 2016-11-04 17:59:56 --> Model Class Initialized
INFO - 2016-11-04 17:59:56 --> Model Class Initialized
INFO - 2016-11-04 17:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 17:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 17:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 17:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 17:59:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 17:59:56 --> Final output sent to browser
DEBUG - 2016-11-04 17:59:56 --> Total execution time: 0.3777
INFO - 2016-11-04 18:02:07 --> Config Class Initialized
INFO - 2016-11-04 18:02:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:02:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:02:07 --> Utf8 Class Initialized
INFO - 2016-11-04 18:02:07 --> URI Class Initialized
INFO - 2016-11-04 18:02:07 --> Router Class Initialized
INFO - 2016-11-04 18:02:07 --> Output Class Initialized
INFO - 2016-11-04 18:02:07 --> Security Class Initialized
DEBUG - 2016-11-04 18:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:02:07 --> Input Class Initialized
INFO - 2016-11-04 18:02:07 --> Language Class Initialized
INFO - 2016-11-04 18:02:07 --> Loader Class Initialized
INFO - 2016-11-04 18:02:07 --> Helper loaded: url_helper
INFO - 2016-11-04 18:02:07 --> Helper loaded: form_helper
INFO - 2016-11-04 18:02:07 --> Database Driver Class Initialized
INFO - 2016-11-04 18:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:02:07 --> Controller Class Initialized
INFO - 2016-11-04 18:02:07 --> Model Class Initialized
INFO - 2016-11-04 18:02:07 --> Model Class Initialized
DEBUG - 2016-11-04 18:02:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:02:07 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:02:07 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:02:07 --> Config Class Initialized
INFO - 2016-11-04 18:02:07 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:02:07 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:02:07 --> Utf8 Class Initialized
INFO - 2016-11-04 18:02:07 --> URI Class Initialized
DEBUG - 2016-11-04 18:02:07 --> No URI present. Default controller set.
INFO - 2016-11-04 18:02:07 --> Router Class Initialized
INFO - 2016-11-04 18:02:07 --> Output Class Initialized
INFO - 2016-11-04 18:02:07 --> Security Class Initialized
DEBUG - 2016-11-04 18:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:02:07 --> Input Class Initialized
INFO - 2016-11-04 18:02:07 --> Language Class Initialized
INFO - 2016-11-04 18:02:07 --> Loader Class Initialized
INFO - 2016-11-04 18:02:07 --> Helper loaded: url_helper
INFO - 2016-11-04 18:02:07 --> Helper loaded: form_helper
INFO - 2016-11-04 18:02:07 --> Database Driver Class Initialized
INFO - 2016-11-04 18:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:02:07 --> Controller Class Initialized
INFO - 2016-11-04 18:02:08 --> Model Class Initialized
INFO - 2016-11-04 18:02:08 --> Model Class Initialized
INFO - 2016-11-04 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:02:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:02:08 --> Final output sent to browser
DEBUG - 2016-11-04 18:02:08 --> Total execution time: 0.3184
INFO - 2016-11-04 18:02:20 --> Config Class Initialized
INFO - 2016-11-04 18:02:20 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:02:20 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:02:20 --> Utf8 Class Initialized
INFO - 2016-11-04 18:02:20 --> URI Class Initialized
INFO - 2016-11-04 18:02:20 --> Router Class Initialized
INFO - 2016-11-04 18:02:20 --> Output Class Initialized
INFO - 2016-11-04 18:02:20 --> Security Class Initialized
DEBUG - 2016-11-04 18:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:02:20 --> Input Class Initialized
INFO - 2016-11-04 18:02:20 --> Language Class Initialized
INFO - 2016-11-04 18:02:20 --> Loader Class Initialized
INFO - 2016-11-04 18:02:20 --> Helper loaded: url_helper
INFO - 2016-11-04 18:02:20 --> Helper loaded: form_helper
INFO - 2016-11-04 18:02:20 --> Database Driver Class Initialized
INFO - 2016-11-04 18:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:02:20 --> Controller Class Initialized
INFO - 2016-11-04 18:02:20 --> Model Class Initialized
INFO - 2016-11-04 18:02:20 --> Model Class Initialized
DEBUG - 2016-11-04 18:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:02:20 --> Model Class Initialized
ERROR - 2016-11-04 18:02:20 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
ERROR - 2016-11-04 18:02:20 --> Severity: Notice --> Undefined property: stdClass::$idrole C:\xampp\htdocs\LMS\app\controllers\Auth.php 105
INFO - 2016-11-04 18:02:20 --> Final output sent to browser
DEBUG - 2016-11-04 18:02:20 --> Total execution time: 0.3327
INFO - 2016-11-04 18:03:47 --> Config Class Initialized
INFO - 2016-11-04 18:03:47 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:03:47 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:03:47 --> Utf8 Class Initialized
INFO - 2016-11-04 18:03:47 --> URI Class Initialized
DEBUG - 2016-11-04 18:03:47 --> No URI present. Default controller set.
INFO - 2016-11-04 18:03:47 --> Router Class Initialized
INFO - 2016-11-04 18:03:47 --> Output Class Initialized
INFO - 2016-11-04 18:03:47 --> Security Class Initialized
DEBUG - 2016-11-04 18:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:03:47 --> Input Class Initialized
INFO - 2016-11-04 18:03:47 --> Language Class Initialized
INFO - 2016-11-04 18:03:47 --> Loader Class Initialized
INFO - 2016-11-04 18:03:47 --> Helper loaded: url_helper
INFO - 2016-11-04 18:03:47 --> Helper loaded: form_helper
INFO - 2016-11-04 18:03:47 --> Database Driver Class Initialized
INFO - 2016-11-04 18:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:03:47 --> Controller Class Initialized
INFO - 2016-11-04 18:03:47 --> Model Class Initialized
INFO - 2016-11-04 18:03:47 --> Model Class Initialized
INFO - 2016-11-04 18:03:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:03:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:03:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:03:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:03:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:03:47 --> Final output sent to browser
DEBUG - 2016-11-04 18:03:47 --> Total execution time: 0.3937
INFO - 2016-11-04 18:03:53 --> Config Class Initialized
INFO - 2016-11-04 18:03:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:03:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:03:53 --> Utf8 Class Initialized
INFO - 2016-11-04 18:03:53 --> URI Class Initialized
DEBUG - 2016-11-04 18:03:53 --> No URI present. Default controller set.
INFO - 2016-11-04 18:03:53 --> Router Class Initialized
INFO - 2016-11-04 18:03:53 --> Output Class Initialized
INFO - 2016-11-04 18:03:53 --> Security Class Initialized
DEBUG - 2016-11-04 18:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:03:53 --> Input Class Initialized
INFO - 2016-11-04 18:03:53 --> Language Class Initialized
INFO - 2016-11-04 18:03:53 --> Loader Class Initialized
INFO - 2016-11-04 18:03:53 --> Helper loaded: url_helper
INFO - 2016-11-04 18:03:53 --> Helper loaded: form_helper
INFO - 2016-11-04 18:03:53 --> Database Driver Class Initialized
INFO - 2016-11-04 18:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:03:53 --> Controller Class Initialized
INFO - 2016-11-04 18:03:53 --> Model Class Initialized
INFO - 2016-11-04 18:03:53 --> Model Class Initialized
INFO - 2016-11-04 18:03:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:03:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:03:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:03:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:03:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:03:53 --> Final output sent to browser
DEBUG - 2016-11-04 18:03:53 --> Total execution time: 0.3908
INFO - 2016-11-04 18:04:01 --> Config Class Initialized
INFO - 2016-11-04 18:04:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:04:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:04:01 --> Utf8 Class Initialized
INFO - 2016-11-04 18:04:01 --> URI Class Initialized
INFO - 2016-11-04 18:04:01 --> Router Class Initialized
INFO - 2016-11-04 18:04:01 --> Output Class Initialized
INFO - 2016-11-04 18:04:01 --> Security Class Initialized
DEBUG - 2016-11-04 18:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:04:01 --> Input Class Initialized
INFO - 2016-11-04 18:04:01 --> Language Class Initialized
INFO - 2016-11-04 18:04:01 --> Loader Class Initialized
INFO - 2016-11-04 18:04:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:04:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:04:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:04:01 --> Controller Class Initialized
INFO - 2016-11-04 18:04:01 --> Model Class Initialized
INFO - 2016-11-04 18:04:01 --> Model Class Initialized
DEBUG - 2016-11-04 18:04:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:04:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:04:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:04:01 --> Config Class Initialized
INFO - 2016-11-04 18:04:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:04:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:04:01 --> Utf8 Class Initialized
INFO - 2016-11-04 18:04:01 --> URI Class Initialized
DEBUG - 2016-11-04 18:04:01 --> No URI present. Default controller set.
INFO - 2016-11-04 18:04:01 --> Router Class Initialized
INFO - 2016-11-04 18:04:01 --> Output Class Initialized
INFO - 2016-11-04 18:04:01 --> Security Class Initialized
DEBUG - 2016-11-04 18:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:04:01 --> Input Class Initialized
INFO - 2016-11-04 18:04:01 --> Language Class Initialized
INFO - 2016-11-04 18:04:01 --> Loader Class Initialized
INFO - 2016-11-04 18:04:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:04:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:04:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:04:01 --> Controller Class Initialized
INFO - 2016-11-04 18:04:01 --> Model Class Initialized
INFO - 2016-11-04 18:04:01 --> Model Class Initialized
INFO - 2016-11-04 18:04:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:04:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:04:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:04:01 --> Final output sent to browser
DEBUG - 2016-11-04 18:04:01 --> Total execution time: 0.3332
INFO - 2016-11-04 18:05:30 --> Config Class Initialized
INFO - 2016-11-04 18:05:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:05:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:05:30 --> Utf8 Class Initialized
INFO - 2016-11-04 18:05:30 --> URI Class Initialized
DEBUG - 2016-11-04 18:05:30 --> No URI present. Default controller set.
INFO - 2016-11-04 18:05:30 --> Router Class Initialized
INFO - 2016-11-04 18:05:30 --> Output Class Initialized
INFO - 2016-11-04 18:05:30 --> Security Class Initialized
DEBUG - 2016-11-04 18:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:05:30 --> Input Class Initialized
INFO - 2016-11-04 18:05:30 --> Language Class Initialized
INFO - 2016-11-04 18:05:30 --> Loader Class Initialized
INFO - 2016-11-04 18:05:30 --> Helper loaded: url_helper
INFO - 2016-11-04 18:05:30 --> Helper loaded: form_helper
INFO - 2016-11-04 18:05:30 --> Database Driver Class Initialized
INFO - 2016-11-04 18:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:05:30 --> Controller Class Initialized
INFO - 2016-11-04 18:05:30 --> Model Class Initialized
INFO - 2016-11-04 18:05:30 --> Model Class Initialized
INFO - 2016-11-04 18:05:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:05:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:05:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:05:30 --> Final output sent to browser
DEBUG - 2016-11-04 18:05:30 --> Total execution time: 0.3273
INFO - 2016-11-04 18:05:41 --> Config Class Initialized
INFO - 2016-11-04 18:05:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:05:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:05:41 --> Utf8 Class Initialized
INFO - 2016-11-04 18:05:41 --> URI Class Initialized
INFO - 2016-11-04 18:05:41 --> Router Class Initialized
INFO - 2016-11-04 18:05:41 --> Output Class Initialized
INFO - 2016-11-04 18:05:41 --> Security Class Initialized
DEBUG - 2016-11-04 18:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:05:41 --> Input Class Initialized
INFO - 2016-11-04 18:05:41 --> Language Class Initialized
INFO - 2016-11-04 18:05:41 --> Loader Class Initialized
INFO - 2016-11-04 18:05:41 --> Helper loaded: url_helper
INFO - 2016-11-04 18:05:41 --> Helper loaded: form_helper
INFO - 2016-11-04 18:05:41 --> Database Driver Class Initialized
INFO - 2016-11-04 18:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:05:41 --> Controller Class Initialized
INFO - 2016-11-04 18:05:41 --> Model Class Initialized
INFO - 2016-11-04 18:05:41 --> Model Class Initialized
DEBUG - 2016-11-04 18:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:05:42 --> Model Class Initialized
ERROR - 2016-11-04 18:05:42 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
ERROR - 2016-11-04 18:05:42 --> Severity: Notice --> Undefined property: stdClass::$idrole C:\xampp\htdocs\LMS\app\controllers\Auth.php 105
INFO - 2016-11-04 18:05:42 --> Final output sent to browser
DEBUG - 2016-11-04 18:05:42 --> Total execution time: 0.4573
INFO - 2016-11-04 18:17:43 --> Config Class Initialized
INFO - 2016-11-04 18:17:43 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:17:43 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:17:43 --> Utf8 Class Initialized
INFO - 2016-11-04 18:17:43 --> URI Class Initialized
DEBUG - 2016-11-04 18:17:43 --> No URI present. Default controller set.
INFO - 2016-11-04 18:17:43 --> Router Class Initialized
INFO - 2016-11-04 18:17:43 --> Output Class Initialized
INFO - 2016-11-04 18:17:43 --> Security Class Initialized
DEBUG - 2016-11-04 18:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:17:43 --> Input Class Initialized
INFO - 2016-11-04 18:17:43 --> Language Class Initialized
INFO - 2016-11-04 18:17:43 --> Loader Class Initialized
INFO - 2016-11-04 18:17:43 --> Helper loaded: url_helper
INFO - 2016-11-04 18:17:43 --> Helper loaded: form_helper
INFO - 2016-11-04 18:17:43 --> Database Driver Class Initialized
INFO - 2016-11-04 18:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:17:43 --> Controller Class Initialized
INFO - 2016-11-04 18:17:43 --> Model Class Initialized
INFO - 2016-11-04 18:17:43 --> Model Class Initialized
INFO - 2016-11-04 18:17:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:17:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:17:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:17:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:17:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:17:44 --> Final output sent to browser
DEBUG - 2016-11-04 18:17:44 --> Total execution time: 0.3985
INFO - 2016-11-04 18:23:15 --> Config Class Initialized
INFO - 2016-11-04 18:23:15 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:23:15 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:23:15 --> Utf8 Class Initialized
INFO - 2016-11-04 18:23:15 --> URI Class Initialized
DEBUG - 2016-11-04 18:23:15 --> No URI present. Default controller set.
INFO - 2016-11-04 18:23:15 --> Router Class Initialized
INFO - 2016-11-04 18:23:15 --> Output Class Initialized
INFO - 2016-11-04 18:23:15 --> Security Class Initialized
DEBUG - 2016-11-04 18:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:23:15 --> Input Class Initialized
INFO - 2016-11-04 18:23:15 --> Language Class Initialized
INFO - 2016-11-04 18:23:15 --> Loader Class Initialized
INFO - 2016-11-04 18:23:15 --> Helper loaded: url_helper
INFO - 2016-11-04 18:23:15 --> Helper loaded: form_helper
INFO - 2016-11-04 18:23:15 --> Database Driver Class Initialized
INFO - 2016-11-04 18:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:23:15 --> Controller Class Initialized
INFO - 2016-11-04 18:23:15 --> Model Class Initialized
INFO - 2016-11-04 18:23:15 --> Model Class Initialized
INFO - 2016-11-04 18:23:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:23:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:23:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:23:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:23:16 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:23:16 --> Final output sent to browser
DEBUG - 2016-11-04 18:23:16 --> Total execution time: 0.3831
INFO - 2016-11-04 18:23:17 --> Config Class Initialized
INFO - 2016-11-04 18:23:17 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:23:17 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:23:17 --> Utf8 Class Initialized
INFO - 2016-11-04 18:23:17 --> URI Class Initialized
INFO - 2016-11-04 18:23:17 --> Router Class Initialized
INFO - 2016-11-04 18:23:17 --> Output Class Initialized
INFO - 2016-11-04 18:23:17 --> Security Class Initialized
DEBUG - 2016-11-04 18:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:23:18 --> Input Class Initialized
INFO - 2016-11-04 18:23:18 --> Language Class Initialized
INFO - 2016-11-04 18:23:18 --> Loader Class Initialized
INFO - 2016-11-04 18:23:18 --> Helper loaded: url_helper
INFO - 2016-11-04 18:23:18 --> Helper loaded: form_helper
INFO - 2016-11-04 18:23:18 --> Database Driver Class Initialized
INFO - 2016-11-04 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:23:18 --> Controller Class Initialized
INFO - 2016-11-04 18:23:18 --> Model Class Initialized
INFO - 2016-11-04 18:23:18 --> Model Class Initialized
DEBUG - 2016-11-04 18:23:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:23:18 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:23:18 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:23:18 --> Config Class Initialized
INFO - 2016-11-04 18:23:18 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:23:18 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:23:18 --> Utf8 Class Initialized
INFO - 2016-11-04 18:23:18 --> URI Class Initialized
DEBUG - 2016-11-04 18:23:18 --> No URI present. Default controller set.
INFO - 2016-11-04 18:23:18 --> Router Class Initialized
INFO - 2016-11-04 18:23:18 --> Output Class Initialized
INFO - 2016-11-04 18:23:18 --> Security Class Initialized
DEBUG - 2016-11-04 18:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:23:18 --> Input Class Initialized
INFO - 2016-11-04 18:23:18 --> Language Class Initialized
INFO - 2016-11-04 18:23:18 --> Loader Class Initialized
INFO - 2016-11-04 18:23:18 --> Helper loaded: url_helper
INFO - 2016-11-04 18:23:18 --> Helper loaded: form_helper
INFO - 2016-11-04 18:23:18 --> Database Driver Class Initialized
INFO - 2016-11-04 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:23:18 --> Controller Class Initialized
INFO - 2016-11-04 18:23:18 --> Model Class Initialized
INFO - 2016-11-04 18:23:18 --> Model Class Initialized
INFO - 2016-11-04 18:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:23:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:23:18 --> Final output sent to browser
DEBUG - 2016-11-04 18:23:18 --> Total execution time: 0.3362
INFO - 2016-11-04 18:23:27 --> Config Class Initialized
INFO - 2016-11-04 18:23:27 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:23:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:23:27 --> Utf8 Class Initialized
INFO - 2016-11-04 18:23:27 --> URI Class Initialized
INFO - 2016-11-04 18:23:27 --> Router Class Initialized
INFO - 2016-11-04 18:23:27 --> Output Class Initialized
INFO - 2016-11-04 18:23:27 --> Security Class Initialized
DEBUG - 2016-11-04 18:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:23:27 --> Input Class Initialized
INFO - 2016-11-04 18:23:27 --> Language Class Initialized
INFO - 2016-11-04 18:23:27 --> Loader Class Initialized
INFO - 2016-11-04 18:23:27 --> Helper loaded: url_helper
INFO - 2016-11-04 18:23:27 --> Helper loaded: form_helper
INFO - 2016-11-04 18:23:27 --> Database Driver Class Initialized
INFO - 2016-11-04 18:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:23:27 --> Controller Class Initialized
INFO - 2016-11-04 18:23:27 --> Model Class Initialized
INFO - 2016-11-04 18:23:27 --> Model Class Initialized
DEBUG - 2016-11-04 18:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:23:27 --> Model Class Initialized
ERROR - 2016-11-04 18:23:27 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
ERROR - 2016-11-04 18:23:27 --> Severity: Notice --> Undefined property: stdClass::$idrole C:\xampp\htdocs\LMS\app\controllers\Auth.php 105
INFO - 2016-11-04 18:23:27 --> Final output sent to browser
DEBUG - 2016-11-04 18:23:27 --> Total execution time: 0.3413
INFO - 2016-11-04 18:23:53 --> Config Class Initialized
INFO - 2016-11-04 18:23:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:23:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:23:53 --> Utf8 Class Initialized
INFO - 2016-11-04 18:23:53 --> URI Class Initialized
DEBUG - 2016-11-04 18:23:53 --> No URI present. Default controller set.
INFO - 2016-11-04 18:23:53 --> Router Class Initialized
INFO - 2016-11-04 18:23:53 --> Output Class Initialized
INFO - 2016-11-04 18:23:53 --> Security Class Initialized
DEBUG - 2016-11-04 18:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:23:53 --> Input Class Initialized
INFO - 2016-11-04 18:23:53 --> Language Class Initialized
INFO - 2016-11-04 18:23:53 --> Loader Class Initialized
INFO - 2016-11-04 18:23:53 --> Helper loaded: url_helper
INFO - 2016-11-04 18:23:53 --> Helper loaded: form_helper
INFO - 2016-11-04 18:23:53 --> Database Driver Class Initialized
INFO - 2016-11-04 18:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:23:53 --> Controller Class Initialized
INFO - 2016-11-04 18:23:53 --> Model Class Initialized
INFO - 2016-11-04 18:23:53 --> Model Class Initialized
INFO - 2016-11-04 18:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:23:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:23:54 --> Final output sent to browser
DEBUG - 2016-11-04 18:23:54 --> Total execution time: 0.3987
INFO - 2016-11-04 18:24:01 --> Config Class Initialized
INFO - 2016-11-04 18:24:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:24:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:24:01 --> Utf8 Class Initialized
INFO - 2016-11-04 18:24:01 --> URI Class Initialized
INFO - 2016-11-04 18:24:01 --> Router Class Initialized
INFO - 2016-11-04 18:24:01 --> Output Class Initialized
INFO - 2016-11-04 18:24:01 --> Security Class Initialized
DEBUG - 2016-11-04 18:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:24:01 --> Input Class Initialized
INFO - 2016-11-04 18:24:01 --> Language Class Initialized
INFO - 2016-11-04 18:24:01 --> Loader Class Initialized
INFO - 2016-11-04 18:24:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:24:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:24:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:24:01 --> Controller Class Initialized
INFO - 2016-11-04 18:24:01 --> Model Class Initialized
INFO - 2016-11-04 18:24:01 --> Model Class Initialized
DEBUG - 2016-11-04 18:24:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:24:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:24:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:24:01 --> Config Class Initialized
INFO - 2016-11-04 18:24:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:24:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:24:01 --> Utf8 Class Initialized
INFO - 2016-11-04 18:24:01 --> URI Class Initialized
DEBUG - 2016-11-04 18:24:01 --> No URI present. Default controller set.
INFO - 2016-11-04 18:24:01 --> Router Class Initialized
INFO - 2016-11-04 18:24:01 --> Output Class Initialized
INFO - 2016-11-04 18:24:01 --> Security Class Initialized
DEBUG - 2016-11-04 18:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:24:01 --> Input Class Initialized
INFO - 2016-11-04 18:24:01 --> Language Class Initialized
INFO - 2016-11-04 18:24:01 --> Loader Class Initialized
INFO - 2016-11-04 18:24:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:24:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:24:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:24:02 --> Controller Class Initialized
INFO - 2016-11-04 18:24:02 --> Model Class Initialized
INFO - 2016-11-04 18:24:02 --> Model Class Initialized
INFO - 2016-11-04 18:24:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:24:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:24:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:24:02 --> Final output sent to browser
DEBUG - 2016-11-04 18:24:02 --> Total execution time: 0.3321
INFO - 2016-11-04 18:25:32 --> Config Class Initialized
INFO - 2016-11-04 18:25:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:25:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:25:32 --> Utf8 Class Initialized
INFO - 2016-11-04 18:25:32 --> URI Class Initialized
DEBUG - 2016-11-04 18:25:32 --> No URI present. Default controller set.
INFO - 2016-11-04 18:25:32 --> Router Class Initialized
INFO - 2016-11-04 18:25:32 --> Output Class Initialized
INFO - 2016-11-04 18:25:32 --> Security Class Initialized
DEBUG - 2016-11-04 18:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:25:32 --> Input Class Initialized
INFO - 2016-11-04 18:25:32 --> Language Class Initialized
INFO - 2016-11-04 18:25:32 --> Loader Class Initialized
INFO - 2016-11-04 18:25:32 --> Helper loaded: url_helper
INFO - 2016-11-04 18:25:32 --> Helper loaded: form_helper
INFO - 2016-11-04 18:25:32 --> Database Driver Class Initialized
INFO - 2016-11-04 18:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:25:32 --> Controller Class Initialized
INFO - 2016-11-04 18:25:32 --> Model Class Initialized
INFO - 2016-11-04 18:25:32 --> Model Class Initialized
INFO - 2016-11-04 18:25:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:25:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:25:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:25:32 --> Final output sent to browser
DEBUG - 2016-11-04 18:25:32 --> Total execution time: 0.3761
INFO - 2016-11-04 18:25:33 --> Config Class Initialized
INFO - 2016-11-04 18:25:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:25:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:25:33 --> Utf8 Class Initialized
INFO - 2016-11-04 18:25:33 --> URI Class Initialized
DEBUG - 2016-11-04 18:25:33 --> No URI present. Default controller set.
INFO - 2016-11-04 18:25:33 --> Router Class Initialized
INFO - 2016-11-04 18:25:34 --> Output Class Initialized
INFO - 2016-11-04 18:25:34 --> Security Class Initialized
DEBUG - 2016-11-04 18:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:25:34 --> Input Class Initialized
INFO - 2016-11-04 18:25:34 --> Language Class Initialized
INFO - 2016-11-04 18:25:34 --> Loader Class Initialized
INFO - 2016-11-04 18:25:34 --> Helper loaded: url_helper
INFO - 2016-11-04 18:25:34 --> Helper loaded: form_helper
INFO - 2016-11-04 18:25:34 --> Database Driver Class Initialized
INFO - 2016-11-04 18:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:25:34 --> Controller Class Initialized
INFO - 2016-11-04 18:25:34 --> Model Class Initialized
INFO - 2016-11-04 18:25:34 --> Model Class Initialized
INFO - 2016-11-04 18:25:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:25:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:25:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:25:34 --> Final output sent to browser
DEBUG - 2016-11-04 18:25:34 --> Total execution time: 0.4159
INFO - 2016-11-04 18:28:08 --> Config Class Initialized
INFO - 2016-11-04 18:28:08 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:28:08 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:28:08 --> Utf8 Class Initialized
INFO - 2016-11-04 18:28:08 --> URI Class Initialized
DEBUG - 2016-11-04 18:28:08 --> No URI present. Default controller set.
INFO - 2016-11-04 18:28:09 --> Router Class Initialized
INFO - 2016-11-04 18:28:09 --> Output Class Initialized
INFO - 2016-11-04 18:28:09 --> Security Class Initialized
DEBUG - 2016-11-04 18:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:28:09 --> Input Class Initialized
INFO - 2016-11-04 18:28:09 --> Language Class Initialized
INFO - 2016-11-04 18:28:09 --> Loader Class Initialized
INFO - 2016-11-04 18:28:09 --> Helper loaded: url_helper
INFO - 2016-11-04 18:28:09 --> Helper loaded: form_helper
INFO - 2016-11-04 18:28:09 --> Database Driver Class Initialized
INFO - 2016-11-04 18:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:28:09 --> Controller Class Initialized
INFO - 2016-11-04 18:28:09 --> Model Class Initialized
INFO - 2016-11-04 18:28:09 --> Model Class Initialized
INFO - 2016-11-04 18:28:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:28:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:28:09 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:28:09 --> Final output sent to browser
DEBUG - 2016-11-04 18:28:09 --> Total execution time: 0.3346
INFO - 2016-11-04 18:28:22 --> Config Class Initialized
INFO - 2016-11-04 18:28:22 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:28:22 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:28:22 --> Utf8 Class Initialized
INFO - 2016-11-04 18:28:22 --> URI Class Initialized
INFO - 2016-11-04 18:28:22 --> Router Class Initialized
INFO - 2016-11-04 18:28:23 --> Output Class Initialized
INFO - 2016-11-04 18:28:23 --> Security Class Initialized
DEBUG - 2016-11-04 18:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:28:23 --> Input Class Initialized
INFO - 2016-11-04 18:28:23 --> Language Class Initialized
INFO - 2016-11-04 18:28:23 --> Loader Class Initialized
INFO - 2016-11-04 18:28:23 --> Helper loaded: url_helper
INFO - 2016-11-04 18:28:23 --> Helper loaded: form_helper
INFO - 2016-11-04 18:28:23 --> Database Driver Class Initialized
INFO - 2016-11-04 18:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:28:23 --> Controller Class Initialized
INFO - 2016-11-04 18:28:23 --> Model Class Initialized
INFO - 2016-11-04 18:28:23 --> Model Class Initialized
DEBUG - 2016-11-04 18:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:28:23 --> Model Class Initialized
ERROR - 2016-11-04 18:28:23 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:28:23 --> Final output sent to browser
DEBUG - 2016-11-04 18:28:23 --> Total execution time: 0.4340
INFO - 2016-11-04 18:28:39 --> Config Class Initialized
INFO - 2016-11-04 18:28:39 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:28:39 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:28:39 --> Utf8 Class Initialized
INFO - 2016-11-04 18:28:39 --> URI Class Initialized
DEBUG - 2016-11-04 18:28:39 --> No URI present. Default controller set.
INFO - 2016-11-04 18:28:39 --> Router Class Initialized
INFO - 2016-11-04 18:28:39 --> Output Class Initialized
INFO - 2016-11-04 18:28:39 --> Security Class Initialized
DEBUG - 2016-11-04 18:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:28:39 --> Input Class Initialized
INFO - 2016-11-04 18:28:39 --> Language Class Initialized
INFO - 2016-11-04 18:28:39 --> Loader Class Initialized
INFO - 2016-11-04 18:28:39 --> Helper loaded: url_helper
INFO - 2016-11-04 18:28:39 --> Helper loaded: form_helper
INFO - 2016-11-04 18:28:39 --> Database Driver Class Initialized
INFO - 2016-11-04 18:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:28:39 --> Controller Class Initialized
INFO - 2016-11-04 18:28:39 --> Model Class Initialized
INFO - 2016-11-04 18:28:39 --> Model Class Initialized
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:28:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:28:39 --> Final output sent to browser
DEBUG - 2016-11-04 18:28:39 --> Total execution time: 0.4725
INFO - 2016-11-04 18:30:24 --> Config Class Initialized
INFO - 2016-11-04 18:30:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:30:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:30:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:30:25 --> URI Class Initialized
INFO - 2016-11-04 18:30:25 --> Router Class Initialized
INFO - 2016-11-04 18:30:25 --> Output Class Initialized
INFO - 2016-11-04 18:30:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:30:25 --> Input Class Initialized
INFO - 2016-11-04 18:30:25 --> Language Class Initialized
INFO - 2016-11-04 18:30:25 --> Loader Class Initialized
INFO - 2016-11-04 18:30:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:30:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:30:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:30:25 --> Controller Class Initialized
INFO - 2016-11-04 18:30:25 --> Model Class Initialized
INFO - 2016-11-04 18:30:25 --> Form Validation Class Initialized
INFO - 2016-11-04 18:30:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:30:25 --> Final output sent to browser
DEBUG - 2016-11-04 18:30:25 --> Total execution time: 0.9419
INFO - 2016-11-04 18:30:29 --> Config Class Initialized
INFO - 2016-11-04 18:30:29 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:30:29 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:30:29 --> Utf8 Class Initialized
INFO - 2016-11-04 18:30:29 --> URI Class Initialized
DEBUG - 2016-11-04 18:30:29 --> No URI present. Default controller set.
INFO - 2016-11-04 18:30:29 --> Router Class Initialized
INFO - 2016-11-04 18:30:29 --> Output Class Initialized
INFO - 2016-11-04 18:30:29 --> Security Class Initialized
DEBUG - 2016-11-04 18:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:30:29 --> Input Class Initialized
INFO - 2016-11-04 18:30:29 --> Language Class Initialized
INFO - 2016-11-04 18:30:29 --> Loader Class Initialized
INFO - 2016-11-04 18:30:29 --> Helper loaded: url_helper
INFO - 2016-11-04 18:30:29 --> Helper loaded: form_helper
INFO - 2016-11-04 18:30:29 --> Database Driver Class Initialized
INFO - 2016-11-04 18:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:30:29 --> Controller Class Initialized
INFO - 2016-11-04 18:30:29 --> Model Class Initialized
INFO - 2016-11-04 18:30:29 --> Model Class Initialized
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:30:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:30:29 --> Final output sent to browser
DEBUG - 2016-11-04 18:30:29 --> Total execution time: 0.4882
INFO - 2016-11-04 18:30:49 --> Config Class Initialized
INFO - 2016-11-04 18:30:50 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:30:50 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:30:50 --> Utf8 Class Initialized
INFO - 2016-11-04 18:30:50 --> URI Class Initialized
INFO - 2016-11-04 18:30:50 --> Router Class Initialized
INFO - 2016-11-04 18:30:50 --> Output Class Initialized
INFO - 2016-11-04 18:30:50 --> Security Class Initialized
DEBUG - 2016-11-04 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:30:50 --> Input Class Initialized
INFO - 2016-11-04 18:30:50 --> Language Class Initialized
INFO - 2016-11-04 18:30:50 --> Loader Class Initialized
INFO - 2016-11-04 18:30:50 --> Helper loaded: url_helper
INFO - 2016-11-04 18:30:50 --> Helper loaded: form_helper
INFO - 2016-11-04 18:30:50 --> Database Driver Class Initialized
INFO - 2016-11-04 18:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:30:50 --> Controller Class Initialized
INFO - 2016-11-04 18:30:50 --> Model Class Initialized
INFO - 2016-11-04 18:30:50 --> Form Validation Class Initialized
INFO - 2016-11-04 18:30:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:30:50 --> Final output sent to browser
DEBUG - 2016-11-04 18:30:50 --> Total execution time: 0.6021
INFO - 2016-11-04 18:30:53 --> Config Class Initialized
INFO - 2016-11-04 18:30:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:30:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:30:53 --> Utf8 Class Initialized
INFO - 2016-11-04 18:30:53 --> URI Class Initialized
DEBUG - 2016-11-04 18:30:53 --> No URI present. Default controller set.
INFO - 2016-11-04 18:30:53 --> Router Class Initialized
INFO - 2016-11-04 18:30:53 --> Output Class Initialized
INFO - 2016-11-04 18:30:53 --> Security Class Initialized
DEBUG - 2016-11-04 18:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:30:53 --> Input Class Initialized
INFO - 2016-11-04 18:30:53 --> Language Class Initialized
INFO - 2016-11-04 18:30:53 --> Loader Class Initialized
INFO - 2016-11-04 18:30:53 --> Helper loaded: url_helper
INFO - 2016-11-04 18:30:53 --> Helper loaded: form_helper
INFO - 2016-11-04 18:30:53 --> Database Driver Class Initialized
INFO - 2016-11-04 18:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:30:53 --> Controller Class Initialized
INFO - 2016-11-04 18:30:53 --> Model Class Initialized
INFO - 2016-11-04 18:30:53 --> Model Class Initialized
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:30:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:30:54 --> Final output sent to browser
DEBUG - 2016-11-04 18:30:54 --> Total execution time: 0.4938
INFO - 2016-11-04 18:31:16 --> Config Class Initialized
INFO - 2016-11-04 18:31:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:31:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:31:17 --> Utf8 Class Initialized
INFO - 2016-11-04 18:31:17 --> URI Class Initialized
INFO - 2016-11-04 18:31:17 --> Router Class Initialized
INFO - 2016-11-04 18:31:17 --> Output Class Initialized
INFO - 2016-11-04 18:31:17 --> Security Class Initialized
DEBUG - 2016-11-04 18:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:31:17 --> Input Class Initialized
INFO - 2016-11-04 18:31:17 --> Language Class Initialized
INFO - 2016-11-04 18:31:17 --> Loader Class Initialized
INFO - 2016-11-04 18:31:17 --> Helper loaded: url_helper
INFO - 2016-11-04 18:31:17 --> Helper loaded: form_helper
INFO - 2016-11-04 18:31:17 --> Database Driver Class Initialized
INFO - 2016-11-04 18:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:31:17 --> Controller Class Initialized
INFO - 2016-11-04 18:31:17 --> Model Class Initialized
INFO - 2016-11-04 18:31:17 --> Form Validation Class Initialized
INFO - 2016-11-04 18:31:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:31:17 --> Final output sent to browser
DEBUG - 2016-11-04 18:31:17 --> Total execution time: 0.8928
INFO - 2016-11-04 18:31:28 --> Config Class Initialized
INFO - 2016-11-04 18:31:28 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:31:28 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:31:28 --> Utf8 Class Initialized
INFO - 2016-11-04 18:31:28 --> URI Class Initialized
INFO - 2016-11-04 18:31:28 --> Router Class Initialized
INFO - 2016-11-04 18:31:28 --> Output Class Initialized
INFO - 2016-11-04 18:31:28 --> Security Class Initialized
DEBUG - 2016-11-04 18:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:31:28 --> Input Class Initialized
INFO - 2016-11-04 18:31:28 --> Language Class Initialized
INFO - 2016-11-04 18:31:28 --> Loader Class Initialized
INFO - 2016-11-04 18:31:28 --> Helper loaded: url_helper
INFO - 2016-11-04 18:31:28 --> Helper loaded: form_helper
INFO - 2016-11-04 18:31:28 --> Database Driver Class Initialized
INFO - 2016-11-04 18:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:31:28 --> Controller Class Initialized
INFO - 2016-11-04 18:31:28 --> Model Class Initialized
INFO - 2016-11-04 18:31:28 --> Form Validation Class Initialized
INFO - 2016-11-04 18:31:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:31:28 --> Final output sent to browser
DEBUG - 2016-11-04 18:31:28 --> Total execution time: 0.3153
INFO - 2016-11-04 18:31:30 --> Config Class Initialized
INFO - 2016-11-04 18:31:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:31:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:31:30 --> Utf8 Class Initialized
INFO - 2016-11-04 18:31:30 --> URI Class Initialized
DEBUG - 2016-11-04 18:31:30 --> No URI present. Default controller set.
INFO - 2016-11-04 18:31:30 --> Router Class Initialized
INFO - 2016-11-04 18:31:30 --> Output Class Initialized
INFO - 2016-11-04 18:31:30 --> Security Class Initialized
DEBUG - 2016-11-04 18:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:31:30 --> Input Class Initialized
INFO - 2016-11-04 18:31:30 --> Language Class Initialized
INFO - 2016-11-04 18:31:30 --> Loader Class Initialized
INFO - 2016-11-04 18:31:30 --> Helper loaded: url_helper
INFO - 2016-11-04 18:31:30 --> Helper loaded: form_helper
INFO - 2016-11-04 18:31:30 --> Database Driver Class Initialized
INFO - 2016-11-04 18:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:31:30 --> Controller Class Initialized
INFO - 2016-11-04 18:31:30 --> Model Class Initialized
INFO - 2016-11-04 18:31:30 --> Model Class Initialized
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:31:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:31:30 --> Final output sent to browser
DEBUG - 2016-11-04 18:31:30 --> Total execution time: 0.5371
INFO - 2016-11-04 18:32:17 --> Config Class Initialized
INFO - 2016-11-04 18:32:17 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:32:17 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:32:17 --> Utf8 Class Initialized
INFO - 2016-11-04 18:32:17 --> URI Class Initialized
INFO - 2016-11-04 18:32:17 --> Router Class Initialized
INFO - 2016-11-04 18:32:17 --> Output Class Initialized
INFO - 2016-11-04 18:32:17 --> Security Class Initialized
DEBUG - 2016-11-04 18:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:32:17 --> Input Class Initialized
INFO - 2016-11-04 18:32:17 --> Language Class Initialized
INFO - 2016-11-04 18:32:17 --> Loader Class Initialized
INFO - 2016-11-04 18:32:17 --> Helper loaded: url_helper
INFO - 2016-11-04 18:32:17 --> Helper loaded: form_helper
INFO - 2016-11-04 18:32:17 --> Database Driver Class Initialized
INFO - 2016-11-04 18:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:32:17 --> Controller Class Initialized
INFO - 2016-11-04 18:32:18 --> Model Class Initialized
INFO - 2016-11-04 18:32:18 --> Form Validation Class Initialized
INFO - 2016-11-04 18:32:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:32:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:32:18 --> Final output sent to browser
DEBUG - 2016-11-04 18:32:18 --> Total execution time: 1.1041
INFO - 2016-11-04 18:32:22 --> Config Class Initialized
INFO - 2016-11-04 18:32:22 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:32:22 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:32:22 --> Utf8 Class Initialized
INFO - 2016-11-04 18:32:22 --> URI Class Initialized
DEBUG - 2016-11-04 18:32:22 --> No URI present. Default controller set.
INFO - 2016-11-04 18:32:22 --> Router Class Initialized
INFO - 2016-11-04 18:32:22 --> Output Class Initialized
INFO - 2016-11-04 18:32:22 --> Security Class Initialized
DEBUG - 2016-11-04 18:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:32:22 --> Input Class Initialized
INFO - 2016-11-04 18:32:22 --> Language Class Initialized
INFO - 2016-11-04 18:32:22 --> Loader Class Initialized
INFO - 2016-11-04 18:32:22 --> Helper loaded: url_helper
INFO - 2016-11-04 18:32:22 --> Helper loaded: form_helper
INFO - 2016-11-04 18:32:22 --> Database Driver Class Initialized
INFO - 2016-11-04 18:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:32:22 --> Controller Class Initialized
INFO - 2016-11-04 18:32:22 --> Model Class Initialized
INFO - 2016-11-04 18:32:22 --> Model Class Initialized
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:32:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:32:22 --> Final output sent to browser
DEBUG - 2016-11-04 18:32:22 --> Total execution time: 0.4776
INFO - 2016-11-04 18:32:56 --> Config Class Initialized
INFO - 2016-11-04 18:32:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:32:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:32:56 --> Utf8 Class Initialized
INFO - 2016-11-04 18:32:56 --> URI Class Initialized
INFO - 2016-11-04 18:32:56 --> Router Class Initialized
INFO - 2016-11-04 18:32:56 --> Output Class Initialized
INFO - 2016-11-04 18:32:56 --> Security Class Initialized
DEBUG - 2016-11-04 18:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:32:56 --> Input Class Initialized
INFO - 2016-11-04 18:32:56 --> Language Class Initialized
INFO - 2016-11-04 18:32:56 --> Loader Class Initialized
INFO - 2016-11-04 18:32:56 --> Helper loaded: url_helper
INFO - 2016-11-04 18:32:56 --> Helper loaded: form_helper
INFO - 2016-11-04 18:32:56 --> Database Driver Class Initialized
INFO - 2016-11-04 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:32:56 --> Controller Class Initialized
INFO - 2016-11-04 18:32:56 --> Model Class Initialized
INFO - 2016-11-04 18:32:56 --> Model Class Initialized
DEBUG - 2016-11-04 18:32:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:32:56 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:32:56 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:32:56 --> Config Class Initialized
INFO - 2016-11-04 18:32:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:32:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:32:56 --> Utf8 Class Initialized
INFO - 2016-11-04 18:32:56 --> URI Class Initialized
DEBUG - 2016-11-04 18:32:56 --> No URI present. Default controller set.
INFO - 2016-11-04 18:32:56 --> Router Class Initialized
INFO - 2016-11-04 18:32:56 --> Output Class Initialized
INFO - 2016-11-04 18:32:56 --> Security Class Initialized
DEBUG - 2016-11-04 18:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:32:56 --> Input Class Initialized
INFO - 2016-11-04 18:32:56 --> Language Class Initialized
INFO - 2016-11-04 18:32:56 --> Loader Class Initialized
INFO - 2016-11-04 18:32:56 --> Helper loaded: url_helper
INFO - 2016-11-04 18:32:56 --> Helper loaded: form_helper
INFO - 2016-11-04 18:32:56 --> Database Driver Class Initialized
INFO - 2016-11-04 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:32:56 --> Controller Class Initialized
INFO - 2016-11-04 18:32:56 --> Model Class Initialized
INFO - 2016-11-04 18:32:56 --> Model Class Initialized
INFO - 2016-11-04 18:32:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:32:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:32:56 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:32:56 --> Final output sent to browser
DEBUG - 2016-11-04 18:32:56 --> Total execution time: 0.3534
INFO - 2016-11-04 18:33:04 --> Config Class Initialized
INFO - 2016-11-04 18:33:04 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:33:04 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:33:04 --> Utf8 Class Initialized
INFO - 2016-11-04 18:33:04 --> URI Class Initialized
INFO - 2016-11-04 18:33:04 --> Router Class Initialized
INFO - 2016-11-04 18:33:04 --> Output Class Initialized
INFO - 2016-11-04 18:33:04 --> Security Class Initialized
DEBUG - 2016-11-04 18:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:33:04 --> Input Class Initialized
INFO - 2016-11-04 18:33:04 --> Language Class Initialized
INFO - 2016-11-04 18:33:04 --> Loader Class Initialized
INFO - 2016-11-04 18:33:04 --> Helper loaded: url_helper
INFO - 2016-11-04 18:33:04 --> Helper loaded: form_helper
INFO - 2016-11-04 18:33:04 --> Database Driver Class Initialized
INFO - 2016-11-04 18:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:33:04 --> Controller Class Initialized
INFO - 2016-11-04 18:33:04 --> Model Class Initialized
INFO - 2016-11-04 18:33:04 --> Model Class Initialized
DEBUG - 2016-11-04 18:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:33:04 --> Model Class Initialized
ERROR - 2016-11-04 18:33:04 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:33:04 --> Final output sent to browser
DEBUG - 2016-11-04 18:33:04 --> Total execution time: 0.3172
INFO - 2016-11-04 18:33:14 --> Config Class Initialized
INFO - 2016-11-04 18:33:14 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:33:14 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:33:14 --> Utf8 Class Initialized
INFO - 2016-11-04 18:33:14 --> URI Class Initialized
DEBUG - 2016-11-04 18:33:14 --> No URI present. Default controller set.
INFO - 2016-11-04 18:33:14 --> Router Class Initialized
INFO - 2016-11-04 18:33:14 --> Output Class Initialized
INFO - 2016-11-04 18:33:14 --> Security Class Initialized
DEBUG - 2016-11-04 18:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:33:14 --> Input Class Initialized
INFO - 2016-11-04 18:33:14 --> Language Class Initialized
INFO - 2016-11-04 18:33:14 --> Loader Class Initialized
INFO - 2016-11-04 18:33:14 --> Helper loaded: url_helper
INFO - 2016-11-04 18:33:14 --> Helper loaded: form_helper
INFO - 2016-11-04 18:33:15 --> Database Driver Class Initialized
INFO - 2016-11-04 18:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:33:15 --> Controller Class Initialized
INFO - 2016-11-04 18:33:15 --> Model Class Initialized
INFO - 2016-11-04 18:33:15 --> Model Class Initialized
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:33:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:33:15 --> Final output sent to browser
DEBUG - 2016-11-04 18:33:15 --> Total execution time: 0.4420
INFO - 2016-11-04 18:33:25 --> Config Class Initialized
INFO - 2016-11-04 18:33:25 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:33:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:33:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:33:25 --> URI Class Initialized
INFO - 2016-11-04 18:33:25 --> Router Class Initialized
INFO - 2016-11-04 18:33:25 --> Output Class Initialized
INFO - 2016-11-04 18:33:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:33:25 --> Input Class Initialized
INFO - 2016-11-04 18:33:25 --> Language Class Initialized
INFO - 2016-11-04 18:33:25 --> Loader Class Initialized
INFO - 2016-11-04 18:33:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:33:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:33:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:33:25 --> Controller Class Initialized
INFO - 2016-11-04 18:33:25 --> Model Class Initialized
INFO - 2016-11-04 18:33:25 --> Model Class Initialized
DEBUG - 2016-11-04 18:33:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:33:25 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:33:25 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:33:25 --> Config Class Initialized
INFO - 2016-11-04 18:33:25 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:33:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:33:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:33:25 --> URI Class Initialized
DEBUG - 2016-11-04 18:33:25 --> No URI present. Default controller set.
INFO - 2016-11-04 18:33:25 --> Router Class Initialized
INFO - 2016-11-04 18:33:25 --> Output Class Initialized
INFO - 2016-11-04 18:33:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:33:25 --> Input Class Initialized
INFO - 2016-11-04 18:33:25 --> Language Class Initialized
INFO - 2016-11-04 18:33:25 --> Loader Class Initialized
INFO - 2016-11-04 18:33:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:33:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:33:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:33:26 --> Controller Class Initialized
INFO - 2016-11-04 18:33:26 --> Model Class Initialized
INFO - 2016-11-04 18:33:26 --> Model Class Initialized
INFO - 2016-11-04 18:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:33:26 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:33:26 --> Final output sent to browser
DEBUG - 2016-11-04 18:33:26 --> Total execution time: 0.3530
INFO - 2016-11-04 18:33:36 --> Config Class Initialized
INFO - 2016-11-04 18:33:36 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:33:36 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:33:36 --> Utf8 Class Initialized
INFO - 2016-11-04 18:33:36 --> URI Class Initialized
INFO - 2016-11-04 18:33:36 --> Router Class Initialized
INFO - 2016-11-04 18:33:36 --> Output Class Initialized
INFO - 2016-11-04 18:33:36 --> Security Class Initialized
DEBUG - 2016-11-04 18:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:33:36 --> Input Class Initialized
INFO - 2016-11-04 18:33:36 --> Language Class Initialized
INFO - 2016-11-04 18:33:36 --> Loader Class Initialized
INFO - 2016-11-04 18:33:36 --> Helper loaded: url_helper
INFO - 2016-11-04 18:33:36 --> Helper loaded: form_helper
INFO - 2016-11-04 18:33:36 --> Database Driver Class Initialized
INFO - 2016-11-04 18:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:33:36 --> Controller Class Initialized
INFO - 2016-11-04 18:33:36 --> Model Class Initialized
INFO - 2016-11-04 18:33:36 --> Model Class Initialized
DEBUG - 2016-11-04 18:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:33:36 --> Model Class Initialized
ERROR - 2016-11-04 18:33:36 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:33:36 --> Final output sent to browser
DEBUG - 2016-11-04 18:33:36 --> Total execution time: 0.3557
INFO - 2016-11-04 18:33:37 --> Config Class Initialized
INFO - 2016-11-04 18:33:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:33:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:33:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:33:37 --> URI Class Initialized
DEBUG - 2016-11-04 18:33:37 --> No URI present. Default controller set.
INFO - 2016-11-04 18:33:37 --> Router Class Initialized
INFO - 2016-11-04 18:33:37 --> Output Class Initialized
INFO - 2016-11-04 18:33:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:33:37 --> Input Class Initialized
INFO - 2016-11-04 18:33:37 --> Language Class Initialized
INFO - 2016-11-04 18:33:37 --> Loader Class Initialized
INFO - 2016-11-04 18:33:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:33:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:33:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:33:37 --> Controller Class Initialized
INFO - 2016-11-04 18:33:37 --> Model Class Initialized
INFO - 2016-11-04 18:33:37 --> Model Class Initialized
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:33:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:33:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:33:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:33:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:33:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:33:38 --> Final output sent to browser
DEBUG - 2016-11-04 18:33:38 --> Total execution time: 0.5097
INFO - 2016-11-04 18:35:09 --> Config Class Initialized
INFO - 2016-11-04 18:35:09 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:35:10 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:35:10 --> Utf8 Class Initialized
INFO - 2016-11-04 18:35:10 --> URI Class Initialized
INFO - 2016-11-04 18:35:10 --> Router Class Initialized
INFO - 2016-11-04 18:35:10 --> Output Class Initialized
INFO - 2016-11-04 18:35:10 --> Security Class Initialized
DEBUG - 2016-11-04 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:35:10 --> Input Class Initialized
INFO - 2016-11-04 18:35:10 --> Language Class Initialized
INFO - 2016-11-04 18:35:10 --> Loader Class Initialized
INFO - 2016-11-04 18:35:10 --> Helper loaded: url_helper
INFO - 2016-11-04 18:35:10 --> Helper loaded: form_helper
INFO - 2016-11-04 18:35:10 --> Database Driver Class Initialized
INFO - 2016-11-04 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:35:10 --> Controller Class Initialized
INFO - 2016-11-04 18:35:10 --> Model Class Initialized
INFO - 2016-11-04 18:35:10 --> Form Validation Class Initialized
INFO - 2016-11-04 18:35:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:35:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:35:10 --> Final output sent to browser
DEBUG - 2016-11-04 18:35:10 --> Total execution time: 0.6825
INFO - 2016-11-04 18:35:12 --> Config Class Initialized
INFO - 2016-11-04 18:35:12 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:35:12 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:35:12 --> Utf8 Class Initialized
INFO - 2016-11-04 18:35:12 --> URI Class Initialized
DEBUG - 2016-11-04 18:35:12 --> No URI present. Default controller set.
INFO - 2016-11-04 18:35:12 --> Router Class Initialized
INFO - 2016-11-04 18:35:12 --> Output Class Initialized
INFO - 2016-11-04 18:35:12 --> Security Class Initialized
DEBUG - 2016-11-04 18:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:35:12 --> Input Class Initialized
INFO - 2016-11-04 18:35:12 --> Language Class Initialized
INFO - 2016-11-04 18:35:12 --> Loader Class Initialized
INFO - 2016-11-04 18:35:12 --> Helper loaded: url_helper
INFO - 2016-11-04 18:35:12 --> Helper loaded: form_helper
INFO - 2016-11-04 18:35:12 --> Database Driver Class Initialized
INFO - 2016-11-04 18:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:35:12 --> Controller Class Initialized
INFO - 2016-11-04 18:35:12 --> Model Class Initialized
INFO - 2016-11-04 18:35:12 --> Model Class Initialized
INFO - 2016-11-04 18:35:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:35:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:35:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:35:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:35:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:35:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:35:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:35:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:35:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:35:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:35:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:35:13 --> Final output sent to browser
DEBUG - 2016-11-04 18:35:13 --> Total execution time: 0.5506
INFO - 2016-11-04 18:35:41 --> Config Class Initialized
INFO - 2016-11-04 18:35:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:35:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:35:41 --> Utf8 Class Initialized
INFO - 2016-11-04 18:35:41 --> URI Class Initialized
INFO - 2016-11-04 18:35:41 --> Router Class Initialized
INFO - 2016-11-04 18:35:41 --> Output Class Initialized
INFO - 2016-11-04 18:35:41 --> Security Class Initialized
DEBUG - 2016-11-04 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:35:41 --> Input Class Initialized
INFO - 2016-11-04 18:35:41 --> Language Class Initialized
INFO - 2016-11-04 18:35:41 --> Loader Class Initialized
INFO - 2016-11-04 18:35:41 --> Helper loaded: url_helper
INFO - 2016-11-04 18:35:41 --> Helper loaded: form_helper
INFO - 2016-11-04 18:35:41 --> Database Driver Class Initialized
INFO - 2016-11-04 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:35:41 --> Controller Class Initialized
INFO - 2016-11-04 18:35:41 --> Model Class Initialized
INFO - 2016-11-04 18:35:41 --> Model Class Initialized
DEBUG - 2016-11-04 18:35:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:35:41 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:35:41 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:35:41 --> Config Class Initialized
INFO - 2016-11-04 18:35:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:35:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:35:41 --> Utf8 Class Initialized
INFO - 2016-11-04 18:35:41 --> URI Class Initialized
DEBUG - 2016-11-04 18:35:41 --> No URI present. Default controller set.
INFO - 2016-11-04 18:35:41 --> Router Class Initialized
INFO - 2016-11-04 18:35:41 --> Output Class Initialized
INFO - 2016-11-04 18:35:41 --> Security Class Initialized
DEBUG - 2016-11-04 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:35:41 --> Input Class Initialized
INFO - 2016-11-04 18:35:41 --> Language Class Initialized
INFO - 2016-11-04 18:35:41 --> Loader Class Initialized
INFO - 2016-11-04 18:35:41 --> Helper loaded: url_helper
INFO - 2016-11-04 18:35:41 --> Helper loaded: form_helper
INFO - 2016-11-04 18:35:41 --> Database Driver Class Initialized
INFO - 2016-11-04 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:35:42 --> Controller Class Initialized
INFO - 2016-11-04 18:35:42 --> Model Class Initialized
INFO - 2016-11-04 18:35:42 --> Model Class Initialized
INFO - 2016-11-04 18:35:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:35:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:35:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:35:42 --> Final output sent to browser
DEBUG - 2016-11-04 18:35:42 --> Total execution time: 0.3481
INFO - 2016-11-04 18:35:56 --> Config Class Initialized
INFO - 2016-11-04 18:35:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:35:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:35:56 --> Utf8 Class Initialized
INFO - 2016-11-04 18:35:56 --> URI Class Initialized
INFO - 2016-11-04 18:35:56 --> Router Class Initialized
INFO - 2016-11-04 18:35:56 --> Output Class Initialized
INFO - 2016-11-04 18:35:56 --> Security Class Initialized
DEBUG - 2016-11-04 18:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:35:56 --> Input Class Initialized
INFO - 2016-11-04 18:35:56 --> Language Class Initialized
INFO - 2016-11-04 18:35:57 --> Loader Class Initialized
INFO - 2016-11-04 18:35:57 --> Helper loaded: url_helper
INFO - 2016-11-04 18:35:57 --> Helper loaded: form_helper
INFO - 2016-11-04 18:35:57 --> Database Driver Class Initialized
INFO - 2016-11-04 18:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:35:57 --> Controller Class Initialized
INFO - 2016-11-04 18:35:57 --> Model Class Initialized
INFO - 2016-11-04 18:35:57 --> Model Class Initialized
DEBUG - 2016-11-04 18:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:35:57 --> Model Class Initialized
ERROR - 2016-11-04 18:35:57 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:35:57 --> Final output sent to browser
DEBUG - 2016-11-04 18:35:57 --> Total execution time: 0.3435
INFO - 2016-11-04 18:35:58 --> Config Class Initialized
INFO - 2016-11-04 18:35:58 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:35:58 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:35:58 --> Utf8 Class Initialized
INFO - 2016-11-04 18:35:58 --> URI Class Initialized
DEBUG - 2016-11-04 18:35:58 --> No URI present. Default controller set.
INFO - 2016-11-04 18:35:58 --> Router Class Initialized
INFO - 2016-11-04 18:35:58 --> Output Class Initialized
INFO - 2016-11-04 18:35:58 --> Security Class Initialized
DEBUG - 2016-11-04 18:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:35:58 --> Input Class Initialized
INFO - 2016-11-04 18:35:58 --> Language Class Initialized
INFO - 2016-11-04 18:35:58 --> Loader Class Initialized
INFO - 2016-11-04 18:35:58 --> Helper loaded: url_helper
INFO - 2016-11-04 18:35:58 --> Helper loaded: form_helper
INFO - 2016-11-04 18:35:58 --> Database Driver Class Initialized
INFO - 2016-11-04 18:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:35:58 --> Controller Class Initialized
INFO - 2016-11-04 18:35:58 --> Model Class Initialized
INFO - 2016-11-04 18:35:58 --> Model Class Initialized
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:35:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:35:58 --> Final output sent to browser
DEBUG - 2016-11-04 18:35:58 --> Total execution time: 0.6752
INFO - 2016-11-04 18:36:36 --> Config Class Initialized
INFO - 2016-11-04 18:36:36 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:36:36 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:36:36 --> Utf8 Class Initialized
INFO - 2016-11-04 18:36:36 --> URI Class Initialized
DEBUG - 2016-11-04 18:36:36 --> No URI present. Default controller set.
INFO - 2016-11-04 18:36:36 --> Router Class Initialized
INFO - 2016-11-04 18:36:36 --> Output Class Initialized
INFO - 2016-11-04 18:36:36 --> Security Class Initialized
DEBUG - 2016-11-04 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:36:36 --> Input Class Initialized
INFO - 2016-11-04 18:36:36 --> Language Class Initialized
INFO - 2016-11-04 18:36:36 --> Loader Class Initialized
INFO - 2016-11-04 18:36:36 --> Helper loaded: url_helper
INFO - 2016-11-04 18:36:36 --> Helper loaded: form_helper
INFO - 2016-11-04 18:36:36 --> Database Driver Class Initialized
INFO - 2016-11-04 18:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:36:36 --> Controller Class Initialized
INFO - 2016-11-04 18:36:36 --> Model Class Initialized
INFO - 2016-11-04 18:36:36 --> Model Class Initialized
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:36:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:36:36 --> Final output sent to browser
DEBUG - 2016-11-04 18:36:36 --> Total execution time: 0.5094
INFO - 2016-11-04 18:36:40 --> Config Class Initialized
INFO - 2016-11-04 18:36:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:36:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:36:40 --> Utf8 Class Initialized
INFO - 2016-11-04 18:36:40 --> URI Class Initialized
INFO - 2016-11-04 18:36:40 --> Router Class Initialized
INFO - 2016-11-04 18:36:40 --> Output Class Initialized
INFO - 2016-11-04 18:36:40 --> Security Class Initialized
DEBUG - 2016-11-04 18:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:36:40 --> Input Class Initialized
INFO - 2016-11-04 18:36:40 --> Language Class Initialized
INFO - 2016-11-04 18:36:40 --> Loader Class Initialized
INFO - 2016-11-04 18:36:40 --> Helper loaded: url_helper
INFO - 2016-11-04 18:36:40 --> Helper loaded: form_helper
INFO - 2016-11-04 18:36:40 --> Database Driver Class Initialized
INFO - 2016-11-04 18:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:36:40 --> Controller Class Initialized
INFO - 2016-11-04 18:36:40 --> Form Validation Class Initialized
INFO - 2016-11-04 18:36:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:36:40 --> Final output sent to browser
DEBUG - 2016-11-04 18:36:40 --> Total execution time: 0.5863
INFO - 2016-11-04 18:36:43 --> Config Class Initialized
INFO - 2016-11-04 18:36:43 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:36:43 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:36:43 --> Utf8 Class Initialized
INFO - 2016-11-04 18:36:43 --> URI Class Initialized
DEBUG - 2016-11-04 18:36:43 --> No URI present. Default controller set.
INFO - 2016-11-04 18:36:43 --> Router Class Initialized
INFO - 2016-11-04 18:36:43 --> Output Class Initialized
INFO - 2016-11-04 18:36:43 --> Security Class Initialized
DEBUG - 2016-11-04 18:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:36:43 --> Input Class Initialized
INFO - 2016-11-04 18:36:43 --> Language Class Initialized
INFO - 2016-11-04 18:36:43 --> Loader Class Initialized
INFO - 2016-11-04 18:36:43 --> Helper loaded: url_helper
INFO - 2016-11-04 18:36:43 --> Helper loaded: form_helper
INFO - 2016-11-04 18:36:43 --> Database Driver Class Initialized
INFO - 2016-11-04 18:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:36:43 --> Controller Class Initialized
INFO - 2016-11-04 18:36:43 --> Model Class Initialized
INFO - 2016-11-04 18:36:43 --> Model Class Initialized
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:36:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:36:43 --> Final output sent to browser
DEBUG - 2016-11-04 18:36:43 --> Total execution time: 0.4709
INFO - 2016-11-04 18:36:45 --> Config Class Initialized
INFO - 2016-11-04 18:36:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:36:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:36:45 --> Utf8 Class Initialized
INFO - 2016-11-04 18:36:45 --> URI Class Initialized
INFO - 2016-11-04 18:36:45 --> Router Class Initialized
INFO - 2016-11-04 18:36:45 --> Output Class Initialized
INFO - 2016-11-04 18:36:45 --> Security Class Initialized
DEBUG - 2016-11-04 18:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:36:45 --> Input Class Initialized
INFO - 2016-11-04 18:36:45 --> Language Class Initialized
INFO - 2016-11-04 18:36:45 --> Loader Class Initialized
INFO - 2016-11-04 18:36:46 --> Helper loaded: url_helper
INFO - 2016-11-04 18:36:46 --> Helper loaded: form_helper
INFO - 2016-11-04 18:36:46 --> Database Driver Class Initialized
INFO - 2016-11-04 18:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:36:46 --> Controller Class Initialized
INFO - 2016-11-04 18:36:46 --> Model Class Initialized
INFO - 2016-11-04 18:36:46 --> Model Class Initialized
DEBUG - 2016-11-04 18:36:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:36:46 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:36:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:36:46 --> Config Class Initialized
INFO - 2016-11-04 18:36:46 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:36:46 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:36:46 --> Utf8 Class Initialized
INFO - 2016-11-04 18:36:46 --> URI Class Initialized
DEBUG - 2016-11-04 18:36:46 --> No URI present. Default controller set.
INFO - 2016-11-04 18:36:46 --> Router Class Initialized
INFO - 2016-11-04 18:36:46 --> Output Class Initialized
INFO - 2016-11-04 18:36:46 --> Security Class Initialized
DEBUG - 2016-11-04 18:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:36:46 --> Input Class Initialized
INFO - 2016-11-04 18:36:46 --> Language Class Initialized
INFO - 2016-11-04 18:36:46 --> Loader Class Initialized
INFO - 2016-11-04 18:36:46 --> Helper loaded: url_helper
INFO - 2016-11-04 18:36:46 --> Helper loaded: form_helper
INFO - 2016-11-04 18:36:46 --> Database Driver Class Initialized
INFO - 2016-11-04 18:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:36:46 --> Controller Class Initialized
INFO - 2016-11-04 18:36:46 --> Model Class Initialized
INFO - 2016-11-04 18:36:46 --> Model Class Initialized
INFO - 2016-11-04 18:36:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:36:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:36:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:36:46 --> Final output sent to browser
DEBUG - 2016-11-04 18:36:46 --> Total execution time: 0.4309
INFO - 2016-11-04 18:36:56 --> Config Class Initialized
INFO - 2016-11-04 18:36:56 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:36:56 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:36:56 --> Utf8 Class Initialized
INFO - 2016-11-04 18:36:56 --> URI Class Initialized
INFO - 2016-11-04 18:36:56 --> Router Class Initialized
INFO - 2016-11-04 18:36:56 --> Output Class Initialized
INFO - 2016-11-04 18:36:56 --> Security Class Initialized
DEBUG - 2016-11-04 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:36:56 --> Input Class Initialized
INFO - 2016-11-04 18:36:56 --> Language Class Initialized
INFO - 2016-11-04 18:36:56 --> Loader Class Initialized
INFO - 2016-11-04 18:36:56 --> Helper loaded: url_helper
INFO - 2016-11-04 18:36:56 --> Helper loaded: form_helper
INFO - 2016-11-04 18:36:56 --> Database Driver Class Initialized
INFO - 2016-11-04 18:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:36:56 --> Controller Class Initialized
INFO - 2016-11-04 18:36:56 --> Model Class Initialized
INFO - 2016-11-04 18:36:56 --> Model Class Initialized
DEBUG - 2016-11-04 18:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:36:57 --> Model Class Initialized
ERROR - 2016-11-04 18:36:57 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:36:57 --> Final output sent to browser
DEBUG - 2016-11-04 18:36:57 --> Total execution time: 0.3984
INFO - 2016-11-04 18:37:41 --> Config Class Initialized
INFO - 2016-11-04 18:37:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:37:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:37:41 --> Utf8 Class Initialized
INFO - 2016-11-04 18:37:41 --> URI Class Initialized
DEBUG - 2016-11-04 18:37:41 --> No URI present. Default controller set.
INFO - 2016-11-04 18:37:41 --> Router Class Initialized
INFO - 2016-11-04 18:37:41 --> Output Class Initialized
INFO - 2016-11-04 18:37:41 --> Security Class Initialized
DEBUG - 2016-11-04 18:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:37:41 --> Input Class Initialized
INFO - 2016-11-04 18:37:41 --> Language Class Initialized
INFO - 2016-11-04 18:37:41 --> Loader Class Initialized
INFO - 2016-11-04 18:37:41 --> Helper loaded: url_helper
INFO - 2016-11-04 18:37:41 --> Helper loaded: form_helper
INFO - 2016-11-04 18:37:41 --> Database Driver Class Initialized
INFO - 2016-11-04 18:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:37:41 --> Controller Class Initialized
INFO - 2016-11-04 18:37:41 --> Model Class Initialized
INFO - 2016-11-04 18:37:41 --> Model Class Initialized
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:37:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:37:41 --> Final output sent to browser
DEBUG - 2016-11-04 18:37:41 --> Total execution time: 0.5297
INFO - 2016-11-04 18:37:44 --> Config Class Initialized
INFO - 2016-11-04 18:37:44 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:37:44 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:37:44 --> Utf8 Class Initialized
INFO - 2016-11-04 18:37:44 --> URI Class Initialized
DEBUG - 2016-11-04 18:37:44 --> No URI present. Default controller set.
INFO - 2016-11-04 18:37:44 --> Router Class Initialized
INFO - 2016-11-04 18:37:44 --> Output Class Initialized
INFO - 2016-11-04 18:37:44 --> Security Class Initialized
DEBUG - 2016-11-04 18:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:37:44 --> Input Class Initialized
INFO - 2016-11-04 18:37:44 --> Language Class Initialized
INFO - 2016-11-04 18:37:44 --> Loader Class Initialized
INFO - 2016-11-04 18:37:44 --> Helper loaded: url_helper
INFO - 2016-11-04 18:37:44 --> Helper loaded: form_helper
INFO - 2016-11-04 18:37:44 --> Database Driver Class Initialized
INFO - 2016-11-04 18:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:37:44 --> Controller Class Initialized
INFO - 2016-11-04 18:37:44 --> Model Class Initialized
INFO - 2016-11-04 18:37:44 --> Model Class Initialized
INFO - 2016-11-04 18:37:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:37:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:37:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:37:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:37:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:37:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:37:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:37:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:37:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:37:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:37:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:37:45 --> Final output sent to browser
DEBUG - 2016-11-04 18:37:45 --> Total execution time: 0.5331
INFO - 2016-11-04 18:38:24 --> Config Class Initialized
INFO - 2016-11-04 18:38:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:38:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:38:24 --> Utf8 Class Initialized
INFO - 2016-11-04 18:38:24 --> URI Class Initialized
DEBUG - 2016-11-04 18:38:24 --> No URI present. Default controller set.
INFO - 2016-11-04 18:38:24 --> Router Class Initialized
INFO - 2016-11-04 18:38:24 --> Output Class Initialized
INFO - 2016-11-04 18:38:24 --> Security Class Initialized
DEBUG - 2016-11-04 18:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:38:24 --> Input Class Initialized
INFO - 2016-11-04 18:38:24 --> Language Class Initialized
INFO - 2016-11-04 18:38:24 --> Loader Class Initialized
INFO - 2016-11-04 18:38:24 --> Helper loaded: url_helper
INFO - 2016-11-04 18:38:24 --> Helper loaded: form_helper
INFO - 2016-11-04 18:38:24 --> Database Driver Class Initialized
INFO - 2016-11-04 18:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:38:24 --> Controller Class Initialized
INFO - 2016-11-04 18:38:24 --> Model Class Initialized
INFO - 2016-11-04 18:38:24 --> Model Class Initialized
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:38:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:38:24 --> Final output sent to browser
DEBUG - 2016-11-04 18:38:24 --> Total execution time: 0.5020
INFO - 2016-11-04 18:38:26 --> Config Class Initialized
INFO - 2016-11-04 18:38:26 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:38:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:38:27 --> Utf8 Class Initialized
INFO - 2016-11-04 18:38:27 --> URI Class Initialized
INFO - 2016-11-04 18:38:27 --> Router Class Initialized
INFO - 2016-11-04 18:38:27 --> Output Class Initialized
INFO - 2016-11-04 18:38:27 --> Security Class Initialized
DEBUG - 2016-11-04 18:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:38:27 --> Input Class Initialized
INFO - 2016-11-04 18:38:27 --> Language Class Initialized
INFO - 2016-11-04 18:38:27 --> Loader Class Initialized
INFO - 2016-11-04 18:38:27 --> Helper loaded: url_helper
INFO - 2016-11-04 18:38:27 --> Helper loaded: form_helper
INFO - 2016-11-04 18:38:27 --> Database Driver Class Initialized
INFO - 2016-11-04 18:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:38:27 --> Controller Class Initialized
INFO - 2016-11-04 18:38:27 --> Model Class Initialized
INFO - 2016-11-04 18:38:27 --> Model Class Initialized
DEBUG - 2016-11-04 18:38:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:38:27 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:38:27 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:38:27 --> Config Class Initialized
INFO - 2016-11-04 18:38:27 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:38:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:38:27 --> Utf8 Class Initialized
INFO - 2016-11-04 18:38:27 --> URI Class Initialized
DEBUG - 2016-11-04 18:38:27 --> No URI present. Default controller set.
INFO - 2016-11-04 18:38:27 --> Router Class Initialized
INFO - 2016-11-04 18:38:27 --> Output Class Initialized
INFO - 2016-11-04 18:38:27 --> Security Class Initialized
DEBUG - 2016-11-04 18:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:38:27 --> Input Class Initialized
INFO - 2016-11-04 18:38:27 --> Language Class Initialized
INFO - 2016-11-04 18:38:27 --> Loader Class Initialized
INFO - 2016-11-04 18:38:27 --> Helper loaded: url_helper
INFO - 2016-11-04 18:38:27 --> Helper loaded: form_helper
INFO - 2016-11-04 18:38:27 --> Database Driver Class Initialized
INFO - 2016-11-04 18:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:38:27 --> Controller Class Initialized
INFO - 2016-11-04 18:38:27 --> Model Class Initialized
INFO - 2016-11-04 18:38:27 --> Model Class Initialized
INFO - 2016-11-04 18:38:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:38:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:38:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:38:27 --> Final output sent to browser
DEBUG - 2016-11-04 18:38:27 --> Total execution time: 0.3665
INFO - 2016-11-04 18:40:02 --> Config Class Initialized
INFO - 2016-11-04 18:40:02 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:40:02 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:40:02 --> Utf8 Class Initialized
INFO - 2016-11-04 18:40:02 --> URI Class Initialized
DEBUG - 2016-11-04 18:40:02 --> No URI present. Default controller set.
INFO - 2016-11-04 18:40:02 --> Router Class Initialized
INFO - 2016-11-04 18:40:02 --> Output Class Initialized
INFO - 2016-11-04 18:40:02 --> Security Class Initialized
DEBUG - 2016-11-04 18:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:40:02 --> Input Class Initialized
INFO - 2016-11-04 18:40:02 --> Language Class Initialized
INFO - 2016-11-04 18:40:02 --> Loader Class Initialized
INFO - 2016-11-04 18:40:02 --> Helper loaded: url_helper
INFO - 2016-11-04 18:40:02 --> Helper loaded: form_helper
INFO - 2016-11-04 18:40:02 --> Database Driver Class Initialized
INFO - 2016-11-04 18:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:40:02 --> Controller Class Initialized
INFO - 2016-11-04 18:40:02 --> Model Class Initialized
INFO - 2016-11-04 18:40:02 --> Model Class Initialized
INFO - 2016-11-04 18:40:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:40:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:40:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:40:02 --> Final output sent to browser
DEBUG - 2016-11-04 18:40:02 --> Total execution time: 0.3653
INFO - 2016-11-04 18:40:12 --> Config Class Initialized
INFO - 2016-11-04 18:40:12 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:40:12 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:40:12 --> Utf8 Class Initialized
INFO - 2016-11-04 18:40:12 --> URI Class Initialized
INFO - 2016-11-04 18:40:12 --> Router Class Initialized
INFO - 2016-11-04 18:40:12 --> Output Class Initialized
INFO - 2016-11-04 18:40:12 --> Security Class Initialized
DEBUG - 2016-11-04 18:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:40:12 --> Input Class Initialized
INFO - 2016-11-04 18:40:12 --> Language Class Initialized
INFO - 2016-11-04 18:40:12 --> Loader Class Initialized
INFO - 2016-11-04 18:40:12 --> Helper loaded: url_helper
INFO - 2016-11-04 18:40:12 --> Helper loaded: form_helper
INFO - 2016-11-04 18:40:12 --> Database Driver Class Initialized
INFO - 2016-11-04 18:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:40:12 --> Controller Class Initialized
INFO - 2016-11-04 18:40:12 --> Model Class Initialized
INFO - 2016-11-04 18:40:12 --> Model Class Initialized
DEBUG - 2016-11-04 18:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:40:12 --> Model Class Initialized
INFO - 2016-11-04 18:40:12 --> Final output sent to browser
DEBUG - 2016-11-04 18:40:12 --> Total execution time: 0.3633
INFO - 2016-11-04 18:40:20 --> Config Class Initialized
INFO - 2016-11-04 18:40:20 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:40:20 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:40:20 --> Utf8 Class Initialized
INFO - 2016-11-04 18:40:20 --> URI Class Initialized
INFO - 2016-11-04 18:40:20 --> Router Class Initialized
INFO - 2016-11-04 18:40:20 --> Output Class Initialized
INFO - 2016-11-04 18:40:20 --> Security Class Initialized
DEBUG - 2016-11-04 18:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:40:20 --> Input Class Initialized
INFO - 2016-11-04 18:40:20 --> Language Class Initialized
INFO - 2016-11-04 18:40:20 --> Loader Class Initialized
INFO - 2016-11-04 18:40:20 --> Helper loaded: url_helper
INFO - 2016-11-04 18:40:20 --> Helper loaded: form_helper
INFO - 2016-11-04 18:40:20 --> Database Driver Class Initialized
INFO - 2016-11-04 18:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:40:20 --> Controller Class Initialized
INFO - 2016-11-04 18:40:20 --> Model Class Initialized
INFO - 2016-11-04 18:40:20 --> Model Class Initialized
DEBUG - 2016-11-04 18:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:40:20 --> Model Class Initialized
INFO - 2016-11-04 18:40:20 --> Final output sent to browser
DEBUG - 2016-11-04 18:40:20 --> Total execution time: 0.3271
INFO - 2016-11-04 18:40:36 --> Config Class Initialized
INFO - 2016-11-04 18:40:36 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:40:36 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:40:36 --> Utf8 Class Initialized
INFO - 2016-11-04 18:40:36 --> URI Class Initialized
INFO - 2016-11-04 18:40:36 --> Router Class Initialized
INFO - 2016-11-04 18:40:36 --> Output Class Initialized
INFO - 2016-11-04 18:40:36 --> Security Class Initialized
DEBUG - 2016-11-04 18:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:40:36 --> Input Class Initialized
INFO - 2016-11-04 18:40:36 --> Language Class Initialized
INFO - 2016-11-04 18:40:36 --> Loader Class Initialized
INFO - 2016-11-04 18:40:36 --> Helper loaded: url_helper
INFO - 2016-11-04 18:40:36 --> Helper loaded: form_helper
INFO - 2016-11-04 18:40:36 --> Database Driver Class Initialized
INFO - 2016-11-04 18:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:40:36 --> Controller Class Initialized
INFO - 2016-11-04 18:40:36 --> Model Class Initialized
INFO - 2016-11-04 18:40:36 --> Model Class Initialized
DEBUG - 2016-11-04 18:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:40:36 --> Model Class Initialized
ERROR - 2016-11-04 18:40:37 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:40:37 --> Final output sent to browser
DEBUG - 2016-11-04 18:40:37 --> Total execution time: 0.3409
INFO - 2016-11-04 18:40:40 --> Config Class Initialized
INFO - 2016-11-04 18:40:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:40:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:40:40 --> Utf8 Class Initialized
INFO - 2016-11-04 18:40:40 --> URI Class Initialized
DEBUG - 2016-11-04 18:40:40 --> No URI present. Default controller set.
INFO - 2016-11-04 18:40:40 --> Router Class Initialized
INFO - 2016-11-04 18:40:41 --> Output Class Initialized
INFO - 2016-11-04 18:40:41 --> Security Class Initialized
DEBUG - 2016-11-04 18:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:40:41 --> Input Class Initialized
INFO - 2016-11-04 18:40:41 --> Language Class Initialized
INFO - 2016-11-04 18:40:41 --> Loader Class Initialized
INFO - 2016-11-04 18:40:41 --> Helper loaded: url_helper
INFO - 2016-11-04 18:40:41 --> Helper loaded: form_helper
INFO - 2016-11-04 18:40:41 --> Database Driver Class Initialized
INFO - 2016-11-04 18:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:40:41 --> Controller Class Initialized
INFO - 2016-11-04 18:40:41 --> Model Class Initialized
INFO - 2016-11-04 18:40:41 --> Model Class Initialized
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:40:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:40:41 --> Final output sent to browser
DEBUG - 2016-11-04 18:40:41 --> Total execution time: 0.5314
INFO - 2016-11-04 18:41:21 --> Config Class Initialized
INFO - 2016-11-04 18:41:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:21 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:21 --> URI Class Initialized
INFO - 2016-11-04 18:41:21 --> Router Class Initialized
INFO - 2016-11-04 18:41:21 --> Output Class Initialized
INFO - 2016-11-04 18:41:21 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:21 --> Input Class Initialized
INFO - 2016-11-04 18:41:21 --> Language Class Initialized
INFO - 2016-11-04 18:41:21 --> Loader Class Initialized
INFO - 2016-11-04 18:41:21 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:21 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:21 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:21 --> Controller Class Initialized
INFO - 2016-11-04 18:41:21 --> Model Class Initialized
INFO - 2016-11-04 18:41:21 --> Form Validation Class Initialized
INFO - 2016-11-04 18:41:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:41:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:41:21 --> Final output sent to browser
DEBUG - 2016-11-04 18:41:21 --> Total execution time: 0.4395
INFO - 2016-11-04 18:41:32 --> Config Class Initialized
INFO - 2016-11-04 18:41:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:32 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:32 --> URI Class Initialized
INFO - 2016-11-04 18:41:32 --> Router Class Initialized
INFO - 2016-11-04 18:41:32 --> Output Class Initialized
INFO - 2016-11-04 18:41:32 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:32 --> Input Class Initialized
INFO - 2016-11-04 18:41:32 --> Language Class Initialized
INFO - 2016-11-04 18:41:32 --> Loader Class Initialized
INFO - 2016-11-04 18:41:32 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:32 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:32 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:32 --> Controller Class Initialized
INFO - 2016-11-04 18:41:32 --> Model Class Initialized
INFO - 2016-11-04 18:41:32 --> Model Class Initialized
DEBUG - 2016-11-04 18:41:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:41:32 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:41:32 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:41:32 --> Config Class Initialized
INFO - 2016-11-04 18:41:32 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:32 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:32 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:32 --> URI Class Initialized
DEBUG - 2016-11-04 18:41:32 --> No URI present. Default controller set.
INFO - 2016-11-04 18:41:32 --> Router Class Initialized
INFO - 2016-11-04 18:41:32 --> Output Class Initialized
INFO - 2016-11-04 18:41:32 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:32 --> Input Class Initialized
INFO - 2016-11-04 18:41:32 --> Language Class Initialized
INFO - 2016-11-04 18:41:32 --> Loader Class Initialized
INFO - 2016-11-04 18:41:32 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:32 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:32 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:32 --> Controller Class Initialized
INFO - 2016-11-04 18:41:32 --> Model Class Initialized
INFO - 2016-11-04 18:41:32 --> Model Class Initialized
INFO - 2016-11-04 18:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:41:32 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:41:32 --> Final output sent to browser
DEBUG - 2016-11-04 18:41:33 --> Total execution time: 0.3874
INFO - 2016-11-04 18:41:44 --> Config Class Initialized
INFO - 2016-11-04 18:41:44 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:44 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:44 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:44 --> URI Class Initialized
INFO - 2016-11-04 18:41:44 --> Router Class Initialized
INFO - 2016-11-04 18:41:45 --> Output Class Initialized
INFO - 2016-11-04 18:41:45 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:45 --> Input Class Initialized
INFO - 2016-11-04 18:41:45 --> Language Class Initialized
INFO - 2016-11-04 18:41:45 --> Loader Class Initialized
INFO - 2016-11-04 18:41:45 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:45 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:45 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:45 --> Controller Class Initialized
INFO - 2016-11-04 18:41:45 --> Model Class Initialized
INFO - 2016-11-04 18:41:45 --> Model Class Initialized
DEBUG - 2016-11-04 18:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:41:45 --> Model Class Initialized
ERROR - 2016-11-04 18:41:45 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `Employee`
WHERE `username` = 'test'
AND `password` = '�|\Z=�V\'ښ�T��r���^'
INFO - 2016-11-04 18:41:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-04 18:41:50 --> Config Class Initialized
INFO - 2016-11-04 18:41:50 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:50 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:50 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:50 --> URI Class Initialized
DEBUG - 2016-11-04 18:41:50 --> No URI present. Default controller set.
INFO - 2016-11-04 18:41:50 --> Router Class Initialized
INFO - 2016-11-04 18:41:50 --> Output Class Initialized
INFO - 2016-11-04 18:41:50 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:50 --> Input Class Initialized
INFO - 2016-11-04 18:41:50 --> Language Class Initialized
INFO - 2016-11-04 18:41:50 --> Loader Class Initialized
INFO - 2016-11-04 18:41:50 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:50 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:50 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:51 --> Controller Class Initialized
INFO - 2016-11-04 18:41:51 --> Model Class Initialized
INFO - 2016-11-04 18:41:51 --> Model Class Initialized
INFO - 2016-11-04 18:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:41:51 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:41:51 --> Final output sent to browser
DEBUG - 2016-11-04 18:41:51 --> Total execution time: 0.3943
INFO - 2016-11-04 18:41:57 --> Config Class Initialized
INFO - 2016-11-04 18:41:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:58 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:58 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:58 --> URI Class Initialized
INFO - 2016-11-04 18:41:58 --> Router Class Initialized
INFO - 2016-11-04 18:41:58 --> Output Class Initialized
INFO - 2016-11-04 18:41:58 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:58 --> Input Class Initialized
INFO - 2016-11-04 18:41:58 --> Language Class Initialized
INFO - 2016-11-04 18:41:58 --> Loader Class Initialized
INFO - 2016-11-04 18:41:58 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:58 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:58 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:58 --> Controller Class Initialized
INFO - 2016-11-04 18:41:58 --> Model Class Initialized
INFO - 2016-11-04 18:41:58 --> Model Class Initialized
DEBUG - 2016-11-04 18:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:41:58 --> Model Class Initialized
ERROR - 2016-11-04 18:41:58 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `Employee`
WHERE `username` = 'test'
AND `password` = '�|\Z=�V\'ښ�T��r���^'
INFO - 2016-11-04 18:41:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-04 18:41:59 --> Config Class Initialized
INFO - 2016-11-04 18:41:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:41:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:41:59 --> Utf8 Class Initialized
INFO - 2016-11-04 18:41:59 --> URI Class Initialized
DEBUG - 2016-11-04 18:41:59 --> No URI present. Default controller set.
INFO - 2016-11-04 18:41:59 --> Router Class Initialized
INFO - 2016-11-04 18:41:59 --> Output Class Initialized
INFO - 2016-11-04 18:41:59 --> Security Class Initialized
DEBUG - 2016-11-04 18:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:41:59 --> Input Class Initialized
INFO - 2016-11-04 18:41:59 --> Language Class Initialized
INFO - 2016-11-04 18:41:59 --> Loader Class Initialized
INFO - 2016-11-04 18:41:59 --> Helper loaded: url_helper
INFO - 2016-11-04 18:41:59 --> Helper loaded: form_helper
INFO - 2016-11-04 18:41:59 --> Database Driver Class Initialized
INFO - 2016-11-04 18:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:41:59 --> Controller Class Initialized
INFO - 2016-11-04 18:41:59 --> Model Class Initialized
INFO - 2016-11-04 18:41:59 --> Model Class Initialized
INFO - 2016-11-04 18:41:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:41:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:41:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:41:59 --> Final output sent to browser
DEBUG - 2016-11-04 18:42:00 --> Total execution time: 0.4602
INFO - 2016-11-04 18:42:24 --> Config Class Initialized
INFO - 2016-11-04 18:42:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:24 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:24 --> URI Class Initialized
INFO - 2016-11-04 18:42:24 --> Router Class Initialized
INFO - 2016-11-04 18:42:24 --> Output Class Initialized
INFO - 2016-11-04 18:42:24 --> Security Class Initialized
DEBUG - 2016-11-04 18:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:42:24 --> Input Class Initialized
INFO - 2016-11-04 18:42:24 --> Language Class Initialized
INFO - 2016-11-04 18:42:24 --> Loader Class Initialized
INFO - 2016-11-04 18:42:24 --> Helper loaded: url_helper
INFO - 2016-11-04 18:42:24 --> Helper loaded: form_helper
INFO - 2016-11-04 18:42:24 --> Database Driver Class Initialized
INFO - 2016-11-04 18:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:42:24 --> Controller Class Initialized
INFO - 2016-11-04 18:42:24 --> Model Class Initialized
INFO - 2016-11-04 18:42:24 --> Model Class Initialized
DEBUG - 2016-11-04 18:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:42:24 --> Model Class Initialized
ERROR - 2016-11-04 18:42:24 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `Employee`
WHERE `username` = 'test'
AND `password` = '�|\Z=�V\'ښ�T��r���^'
INFO - 2016-11-04 18:42:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-04 18:42:30 --> Config Class Initialized
INFO - 2016-11-04 18:42:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:30 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:30 --> URI Class Initialized
DEBUG - 2016-11-04 18:42:30 --> No URI present. Default controller set.
INFO - 2016-11-04 18:42:30 --> Router Class Initialized
INFO - 2016-11-04 18:42:30 --> Output Class Initialized
INFO - 2016-11-04 18:42:30 --> Security Class Initialized
DEBUG - 2016-11-04 18:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:42:30 --> Input Class Initialized
INFO - 2016-11-04 18:42:30 --> Language Class Initialized
INFO - 2016-11-04 18:42:30 --> Loader Class Initialized
INFO - 2016-11-04 18:42:30 --> Helper loaded: url_helper
INFO - 2016-11-04 18:42:30 --> Helper loaded: form_helper
INFO - 2016-11-04 18:42:30 --> Database Driver Class Initialized
INFO - 2016-11-04 18:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:42:30 --> Controller Class Initialized
INFO - 2016-11-04 18:42:30 --> Model Class Initialized
INFO - 2016-11-04 18:42:30 --> Model Class Initialized
INFO - 2016-11-04 18:42:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:42:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:42:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:42:30 --> Final output sent to browser
DEBUG - 2016-11-04 18:42:30 --> Total execution time: 0.3999
INFO - 2016-11-04 18:42:41 --> Config Class Initialized
INFO - 2016-11-04 18:42:41 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:41 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:41 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:41 --> URI Class Initialized
DEBUG - 2016-11-04 18:42:41 --> No URI present. Default controller set.
INFO - 2016-11-04 18:42:42 --> Router Class Initialized
INFO - 2016-11-04 18:42:42 --> Output Class Initialized
INFO - 2016-11-04 18:42:42 --> Security Class Initialized
DEBUG - 2016-11-04 18:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:42:42 --> Input Class Initialized
INFO - 2016-11-04 18:42:42 --> Language Class Initialized
INFO - 2016-11-04 18:42:42 --> Loader Class Initialized
INFO - 2016-11-04 18:42:42 --> Helper loaded: url_helper
INFO - 2016-11-04 18:42:42 --> Helper loaded: form_helper
INFO - 2016-11-04 18:42:42 --> Database Driver Class Initialized
INFO - 2016-11-04 18:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:42:42 --> Controller Class Initialized
INFO - 2016-11-04 18:42:42 --> Model Class Initialized
INFO - 2016-11-04 18:42:42 --> Model Class Initialized
INFO - 2016-11-04 18:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:42:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:42:42 --> Final output sent to browser
DEBUG - 2016-11-04 18:42:42 --> Total execution time: 0.3922
INFO - 2016-11-04 18:42:46 --> Config Class Initialized
INFO - 2016-11-04 18:42:46 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:46 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:46 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:46 --> URI Class Initialized
INFO - 2016-11-04 18:42:46 --> Router Class Initialized
INFO - 2016-11-04 18:42:46 --> Output Class Initialized
INFO - 2016-11-04 18:42:46 --> Security Class Initialized
DEBUG - 2016-11-04 18:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:42:46 --> Input Class Initialized
INFO - 2016-11-04 18:42:46 --> Language Class Initialized
INFO - 2016-11-04 18:42:47 --> Loader Class Initialized
INFO - 2016-11-04 18:42:47 --> Helper loaded: url_helper
INFO - 2016-11-04 18:42:47 --> Helper loaded: form_helper
INFO - 2016-11-04 18:42:47 --> Database Driver Class Initialized
INFO - 2016-11-04 18:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:42:47 --> Controller Class Initialized
INFO - 2016-11-04 18:42:47 --> Model Class Initialized
INFO - 2016-11-04 18:42:47 --> Model Class Initialized
DEBUG - 2016-11-04 18:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:42:47 --> Model Class Initialized
INFO - 2016-11-04 18:42:47 --> Final output sent to browser
DEBUG - 2016-11-04 18:42:47 --> Total execution time: 0.3523
INFO - 2016-11-04 18:42:47 --> Config Class Initialized
INFO - 2016-11-04 18:42:47 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:47 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:47 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:47 --> URI Class Initialized
DEBUG - 2016-11-04 18:42:47 --> No URI present. Default controller set.
INFO - 2016-11-04 18:42:47 --> Router Class Initialized
INFO - 2016-11-04 18:42:47 --> Output Class Initialized
INFO - 2016-11-04 18:42:47 --> Security Class Initialized
DEBUG - 2016-11-04 18:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:42:47 --> Input Class Initialized
INFO - 2016-11-04 18:42:47 --> Language Class Initialized
INFO - 2016-11-04 18:42:47 --> Loader Class Initialized
INFO - 2016-11-04 18:42:47 --> Helper loaded: url_helper
INFO - 2016-11-04 18:42:47 --> Helper loaded: form_helper
INFO - 2016-11-04 18:42:47 --> Database Driver Class Initialized
INFO - 2016-11-04 18:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:42:47 --> Controller Class Initialized
INFO - 2016-11-04 18:42:47 --> Model Class Initialized
INFO - 2016-11-04 18:42:47 --> Model Class Initialized
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:42:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:42:48 --> Final output sent to browser
DEBUG - 2016-11-04 18:42:48 --> Total execution time: 0.7734
INFO - 2016-11-04 18:42:59 --> Config Class Initialized
INFO - 2016-11-04 18:42:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:59 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:59 --> URI Class Initialized
INFO - 2016-11-04 18:42:59 --> Router Class Initialized
INFO - 2016-11-04 18:42:59 --> Output Class Initialized
INFO - 2016-11-04 18:42:59 --> Security Class Initialized
DEBUG - 2016-11-04 18:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:42:59 --> Input Class Initialized
INFO - 2016-11-04 18:42:59 --> Language Class Initialized
INFO - 2016-11-04 18:42:59 --> Loader Class Initialized
INFO - 2016-11-04 18:42:59 --> Helper loaded: url_helper
INFO - 2016-11-04 18:42:59 --> Helper loaded: form_helper
INFO - 2016-11-04 18:42:59 --> Database Driver Class Initialized
INFO - 2016-11-04 18:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:42:59 --> Controller Class Initialized
INFO - 2016-11-04 18:42:59 --> Model Class Initialized
INFO - 2016-11-04 18:42:59 --> Model Class Initialized
DEBUG - 2016-11-04 18:42:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:42:59 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:42:59 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:42:59 --> Config Class Initialized
INFO - 2016-11-04 18:42:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:42:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:42:59 --> Utf8 Class Initialized
INFO - 2016-11-04 18:42:59 --> URI Class Initialized
DEBUG - 2016-11-04 18:42:59 --> No URI present. Default controller set.
INFO - 2016-11-04 18:43:00 --> Router Class Initialized
INFO - 2016-11-04 18:43:00 --> Output Class Initialized
INFO - 2016-11-04 18:43:00 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:00 --> Input Class Initialized
INFO - 2016-11-04 18:43:00 --> Language Class Initialized
INFO - 2016-11-04 18:43:00 --> Loader Class Initialized
INFO - 2016-11-04 18:43:00 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:00 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:00 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:00 --> Controller Class Initialized
INFO - 2016-11-04 18:43:00 --> Model Class Initialized
INFO - 2016-11-04 18:43:00 --> Model Class Initialized
INFO - 2016-11-04 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:43:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:43:00 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:00 --> Total execution time: 0.3787
INFO - 2016-11-04 18:43:06 --> Config Class Initialized
INFO - 2016-11-04 18:43:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:06 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:06 --> URI Class Initialized
INFO - 2016-11-04 18:43:06 --> Router Class Initialized
INFO - 2016-11-04 18:43:06 --> Output Class Initialized
INFO - 2016-11-04 18:43:06 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:06 --> Input Class Initialized
INFO - 2016-11-04 18:43:06 --> Language Class Initialized
INFO - 2016-11-04 18:43:06 --> Loader Class Initialized
INFO - 2016-11-04 18:43:06 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:06 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:06 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:06 --> Controller Class Initialized
INFO - 2016-11-04 18:43:06 --> Model Class Initialized
INFO - 2016-11-04 18:43:06 --> Model Class Initialized
DEBUG - 2016-11-04 18:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:43:06 --> Model Class Initialized
INFO - 2016-11-04 18:43:06 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:06 --> Total execution time: 0.3990
INFO - 2016-11-04 18:43:06 --> Config Class Initialized
INFO - 2016-11-04 18:43:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:06 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:06 --> URI Class Initialized
DEBUG - 2016-11-04 18:43:06 --> No URI present. Default controller set.
INFO - 2016-11-04 18:43:06 --> Router Class Initialized
INFO - 2016-11-04 18:43:06 --> Output Class Initialized
INFO - 2016-11-04 18:43:06 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:06 --> Input Class Initialized
INFO - 2016-11-04 18:43:06 --> Language Class Initialized
INFO - 2016-11-04 18:43:06 --> Loader Class Initialized
INFO - 2016-11-04 18:43:06 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:06 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:06 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:06 --> Controller Class Initialized
INFO - 2016-11-04 18:43:06 --> Model Class Initialized
INFO - 2016-11-04 18:43:06 --> Model Class Initialized
INFO - 2016-11-04 18:43:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:43:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:43:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:43:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:43:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:43:07 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:07 --> Total execution time: 0.5080
INFO - 2016-11-04 18:43:37 --> Config Class Initialized
INFO - 2016-11-04 18:43:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:37 --> URI Class Initialized
DEBUG - 2016-11-04 18:43:37 --> No URI present. Default controller set.
INFO - 2016-11-04 18:43:37 --> Router Class Initialized
INFO - 2016-11-04 18:43:37 --> Output Class Initialized
INFO - 2016-11-04 18:43:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:37 --> Input Class Initialized
INFO - 2016-11-04 18:43:37 --> Language Class Initialized
INFO - 2016-11-04 18:43:37 --> Loader Class Initialized
INFO - 2016-11-04 18:43:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:37 --> Controller Class Initialized
INFO - 2016-11-04 18:43:37 --> Model Class Initialized
INFO - 2016-11-04 18:43:37 --> Model Class Initialized
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:43:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:43:37 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:38 --> Total execution time: 0.5290
INFO - 2016-11-04 18:43:40 --> Config Class Initialized
INFO - 2016-11-04 18:43:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:40 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:40 --> URI Class Initialized
INFO - 2016-11-04 18:43:40 --> Router Class Initialized
INFO - 2016-11-04 18:43:40 --> Output Class Initialized
INFO - 2016-11-04 18:43:40 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:40 --> Input Class Initialized
INFO - 2016-11-04 18:43:40 --> Language Class Initialized
INFO - 2016-11-04 18:43:40 --> Loader Class Initialized
INFO - 2016-11-04 18:43:40 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:40 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:40 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:40 --> Controller Class Initialized
INFO - 2016-11-04 18:43:40 --> Model Class Initialized
INFO - 2016-11-04 18:43:40 --> Model Class Initialized
DEBUG - 2016-11-04 18:43:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:43:40 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:43:40 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:43:40 --> Config Class Initialized
INFO - 2016-11-04 18:43:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:40 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:40 --> URI Class Initialized
DEBUG - 2016-11-04 18:43:40 --> No URI present. Default controller set.
INFO - 2016-11-04 18:43:40 --> Router Class Initialized
INFO - 2016-11-04 18:43:40 --> Output Class Initialized
INFO - 2016-11-04 18:43:40 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:40 --> Input Class Initialized
INFO - 2016-11-04 18:43:40 --> Language Class Initialized
INFO - 2016-11-04 18:43:40 --> Loader Class Initialized
INFO - 2016-11-04 18:43:40 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:40 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:40 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:40 --> Controller Class Initialized
INFO - 2016-11-04 18:43:40 --> Model Class Initialized
INFO - 2016-11-04 18:43:40 --> Model Class Initialized
INFO - 2016-11-04 18:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:43:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:43:40 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:41 --> Total execution time: 0.3743
INFO - 2016-11-04 18:43:42 --> Config Class Initialized
INFO - 2016-11-04 18:43:42 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:42 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:43 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:43 --> URI Class Initialized
DEBUG - 2016-11-04 18:43:43 --> No URI present. Default controller set.
INFO - 2016-11-04 18:43:43 --> Router Class Initialized
INFO - 2016-11-04 18:43:43 --> Output Class Initialized
INFO - 2016-11-04 18:43:43 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:43 --> Input Class Initialized
INFO - 2016-11-04 18:43:43 --> Language Class Initialized
INFO - 2016-11-04 18:43:43 --> Loader Class Initialized
INFO - 2016-11-04 18:43:43 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:43 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:43 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:43 --> Controller Class Initialized
INFO - 2016-11-04 18:43:43 --> Model Class Initialized
INFO - 2016-11-04 18:43:43 --> Model Class Initialized
INFO - 2016-11-04 18:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:43:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:43:43 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:43 --> Total execution time: 0.4419
INFO - 2016-11-04 18:43:49 --> Config Class Initialized
INFO - 2016-11-04 18:43:49 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:49 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:49 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:49 --> URI Class Initialized
INFO - 2016-11-04 18:43:49 --> Router Class Initialized
INFO - 2016-11-04 18:43:49 --> Output Class Initialized
INFO - 2016-11-04 18:43:49 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:49 --> Input Class Initialized
INFO - 2016-11-04 18:43:49 --> Language Class Initialized
INFO - 2016-11-04 18:43:49 --> Loader Class Initialized
INFO - 2016-11-04 18:43:49 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:49 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:49 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:49 --> Controller Class Initialized
INFO - 2016-11-04 18:43:49 --> Model Class Initialized
INFO - 2016-11-04 18:43:49 --> Model Class Initialized
DEBUG - 2016-11-04 18:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:43:49 --> Model Class Initialized
ERROR - 2016-11-04 18:43:49 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:43:49 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:49 --> Total execution time: 0.3696
INFO - 2016-11-04 18:43:59 --> Config Class Initialized
INFO - 2016-11-04 18:43:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:43:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:43:59 --> Utf8 Class Initialized
INFO - 2016-11-04 18:43:59 --> URI Class Initialized
DEBUG - 2016-11-04 18:43:59 --> No URI present. Default controller set.
INFO - 2016-11-04 18:43:59 --> Router Class Initialized
INFO - 2016-11-04 18:43:59 --> Output Class Initialized
INFO - 2016-11-04 18:43:59 --> Security Class Initialized
DEBUG - 2016-11-04 18:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:43:59 --> Input Class Initialized
INFO - 2016-11-04 18:43:59 --> Language Class Initialized
INFO - 2016-11-04 18:43:59 --> Loader Class Initialized
INFO - 2016-11-04 18:43:59 --> Helper loaded: url_helper
INFO - 2016-11-04 18:43:59 --> Helper loaded: form_helper
INFO - 2016-11-04 18:43:59 --> Database Driver Class Initialized
INFO - 2016-11-04 18:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:43:59 --> Controller Class Initialized
INFO - 2016-11-04 18:43:59 --> Model Class Initialized
INFO - 2016-11-04 18:43:59 --> Model Class Initialized
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:43:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:43:59 --> Final output sent to browser
DEBUG - 2016-11-04 18:43:59 --> Total execution time: 0.5371
INFO - 2016-11-04 18:44:21 --> Config Class Initialized
INFO - 2016-11-04 18:44:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:44:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:44:21 --> Utf8 Class Initialized
INFO - 2016-11-04 18:44:21 --> URI Class Initialized
DEBUG - 2016-11-04 18:44:21 --> No URI present. Default controller set.
INFO - 2016-11-04 18:44:21 --> Router Class Initialized
INFO - 2016-11-04 18:44:21 --> Output Class Initialized
INFO - 2016-11-04 18:44:21 --> Security Class Initialized
DEBUG - 2016-11-04 18:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:44:21 --> Input Class Initialized
INFO - 2016-11-04 18:44:21 --> Language Class Initialized
INFO - 2016-11-04 18:44:22 --> Loader Class Initialized
INFO - 2016-11-04 18:44:22 --> Helper loaded: url_helper
INFO - 2016-11-04 18:44:22 --> Helper loaded: form_helper
INFO - 2016-11-04 18:44:22 --> Database Driver Class Initialized
INFO - 2016-11-04 18:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:44:22 --> Controller Class Initialized
INFO - 2016-11-04 18:44:22 --> Model Class Initialized
INFO - 2016-11-04 18:44:22 --> Model Class Initialized
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:44:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:44:22 --> Final output sent to browser
DEBUG - 2016-11-04 18:44:22 --> Total execution time: 0.5362
INFO - 2016-11-04 18:44:24 --> Config Class Initialized
INFO - 2016-11-04 18:44:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:44:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:44:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:44:25 --> URI Class Initialized
INFO - 2016-11-04 18:44:25 --> Router Class Initialized
INFO - 2016-11-04 18:44:25 --> Output Class Initialized
INFO - 2016-11-04 18:44:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:44:25 --> Input Class Initialized
INFO - 2016-11-04 18:44:25 --> Language Class Initialized
INFO - 2016-11-04 18:44:25 --> Loader Class Initialized
INFO - 2016-11-04 18:44:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:44:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:44:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:44:25 --> Controller Class Initialized
INFO - 2016-11-04 18:44:25 --> Model Class Initialized
INFO - 2016-11-04 18:44:25 --> Model Class Initialized
DEBUG - 2016-11-04 18:44:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:44:25 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:44:25 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:44:25 --> Config Class Initialized
INFO - 2016-11-04 18:44:25 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:44:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:44:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:44:25 --> URI Class Initialized
DEBUG - 2016-11-04 18:44:25 --> No URI present. Default controller set.
INFO - 2016-11-04 18:44:25 --> Router Class Initialized
INFO - 2016-11-04 18:44:25 --> Output Class Initialized
INFO - 2016-11-04 18:44:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:44:25 --> Input Class Initialized
INFO - 2016-11-04 18:44:25 --> Language Class Initialized
INFO - 2016-11-04 18:44:25 --> Loader Class Initialized
INFO - 2016-11-04 18:44:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:44:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:44:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:44:25 --> Controller Class Initialized
INFO - 2016-11-04 18:44:25 --> Model Class Initialized
INFO - 2016-11-04 18:44:25 --> Model Class Initialized
INFO - 2016-11-04 18:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:44:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:44:25 --> Final output sent to browser
DEBUG - 2016-11-04 18:44:25 --> Total execution time: 0.3844
INFO - 2016-11-04 18:44:37 --> Config Class Initialized
INFO - 2016-11-04 18:44:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:44:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:44:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:44:37 --> URI Class Initialized
INFO - 2016-11-04 18:44:38 --> Router Class Initialized
INFO - 2016-11-04 18:44:38 --> Output Class Initialized
INFO - 2016-11-04 18:44:38 --> Security Class Initialized
DEBUG - 2016-11-04 18:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:44:38 --> Input Class Initialized
INFO - 2016-11-04 18:44:38 --> Language Class Initialized
INFO - 2016-11-04 18:44:38 --> Loader Class Initialized
INFO - 2016-11-04 18:44:38 --> Helper loaded: url_helper
INFO - 2016-11-04 18:44:38 --> Helper loaded: form_helper
INFO - 2016-11-04 18:44:38 --> Database Driver Class Initialized
INFO - 2016-11-04 18:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:44:38 --> Controller Class Initialized
INFO - 2016-11-04 18:44:38 --> Model Class Initialized
INFO - 2016-11-04 18:44:38 --> Model Class Initialized
DEBUG - 2016-11-04 18:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:44:38 --> Model Class Initialized
ERROR - 2016-11-04 18:44:38 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:44:38 --> Final output sent to browser
DEBUG - 2016-11-04 18:44:38 --> Total execution time: 0.4014
INFO - 2016-11-04 18:45:29 --> Config Class Initialized
INFO - 2016-11-04 18:45:29 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:45:29 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:45:29 --> Utf8 Class Initialized
INFO - 2016-11-04 18:45:29 --> URI Class Initialized
DEBUG - 2016-11-04 18:45:29 --> No URI present. Default controller set.
INFO - 2016-11-04 18:45:29 --> Router Class Initialized
INFO - 2016-11-04 18:45:29 --> Output Class Initialized
INFO - 2016-11-04 18:45:29 --> Security Class Initialized
DEBUG - 2016-11-04 18:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:45:29 --> Input Class Initialized
INFO - 2016-11-04 18:45:29 --> Language Class Initialized
INFO - 2016-11-04 18:45:29 --> Loader Class Initialized
INFO - 2016-11-04 18:45:29 --> Helper loaded: url_helper
INFO - 2016-11-04 18:45:29 --> Helper loaded: form_helper
INFO - 2016-11-04 18:45:29 --> Database Driver Class Initialized
INFO - 2016-11-04 18:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:45:29 --> Controller Class Initialized
INFO - 2016-11-04 18:45:30 --> Model Class Initialized
INFO - 2016-11-04 18:45:30 --> Model Class Initialized
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:45:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:45:30 --> Final output sent to browser
DEBUG - 2016-11-04 18:45:30 --> Total execution time: 0.5499
INFO - 2016-11-04 18:46:00 --> Config Class Initialized
INFO - 2016-11-04 18:46:00 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:46:00 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:46:00 --> Utf8 Class Initialized
INFO - 2016-11-04 18:46:00 --> URI Class Initialized
INFO - 2016-11-04 18:46:00 --> Router Class Initialized
INFO - 2016-11-04 18:46:00 --> Output Class Initialized
INFO - 2016-11-04 18:46:00 --> Security Class Initialized
DEBUG - 2016-11-04 18:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:46:00 --> Input Class Initialized
INFO - 2016-11-04 18:46:01 --> Language Class Initialized
INFO - 2016-11-04 18:46:01 --> Loader Class Initialized
INFO - 2016-11-04 18:46:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:46:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:46:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:46:01 --> Controller Class Initialized
INFO - 2016-11-04 18:46:01 --> Model Class Initialized
INFO - 2016-11-04 18:46:01 --> Model Class Initialized
DEBUG - 2016-11-04 18:46:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:46:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:46:01 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:46:01 --> Config Class Initialized
INFO - 2016-11-04 18:46:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:46:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:46:01 --> Utf8 Class Initialized
INFO - 2016-11-04 18:46:01 --> URI Class Initialized
DEBUG - 2016-11-04 18:46:01 --> No URI present. Default controller set.
INFO - 2016-11-04 18:46:01 --> Router Class Initialized
INFO - 2016-11-04 18:46:01 --> Output Class Initialized
INFO - 2016-11-04 18:46:01 --> Security Class Initialized
DEBUG - 2016-11-04 18:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:46:01 --> Input Class Initialized
INFO - 2016-11-04 18:46:01 --> Language Class Initialized
INFO - 2016-11-04 18:46:01 --> Loader Class Initialized
INFO - 2016-11-04 18:46:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:46:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:46:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:46:01 --> Controller Class Initialized
INFO - 2016-11-04 18:46:01 --> Model Class Initialized
INFO - 2016-11-04 18:46:01 --> Model Class Initialized
INFO - 2016-11-04 18:46:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:46:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:46:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:46:01 --> Final output sent to browser
DEBUG - 2016-11-04 18:46:01 --> Total execution time: 0.3940
INFO - 2016-11-04 18:46:04 --> Config Class Initialized
INFO - 2016-11-04 18:46:04 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:46:04 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:46:04 --> Utf8 Class Initialized
INFO - 2016-11-04 18:46:04 --> URI Class Initialized
DEBUG - 2016-11-04 18:46:04 --> No URI present. Default controller set.
INFO - 2016-11-04 18:46:04 --> Router Class Initialized
INFO - 2016-11-04 18:46:04 --> Output Class Initialized
INFO - 2016-11-04 18:46:04 --> Security Class Initialized
DEBUG - 2016-11-04 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:46:04 --> Input Class Initialized
INFO - 2016-11-04 18:46:04 --> Language Class Initialized
INFO - 2016-11-04 18:46:04 --> Loader Class Initialized
INFO - 2016-11-04 18:46:04 --> Helper loaded: url_helper
INFO - 2016-11-04 18:46:04 --> Helper loaded: form_helper
INFO - 2016-11-04 18:46:04 --> Database Driver Class Initialized
INFO - 2016-11-04 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:46:04 --> Controller Class Initialized
INFO - 2016-11-04 18:46:04 --> Model Class Initialized
INFO - 2016-11-04 18:46:04 --> Model Class Initialized
INFO - 2016-11-04 18:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:46:04 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:46:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:46:05 --> Final output sent to browser
DEBUG - 2016-11-04 18:46:05 --> Total execution time: 0.4206
INFO - 2016-11-04 18:47:06 --> Config Class Initialized
INFO - 2016-11-04 18:47:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:47:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:47:06 --> Utf8 Class Initialized
INFO - 2016-11-04 18:47:06 --> URI Class Initialized
DEBUG - 2016-11-04 18:47:06 --> No URI present. Default controller set.
INFO - 2016-11-04 18:47:06 --> Router Class Initialized
INFO - 2016-11-04 18:47:06 --> Output Class Initialized
INFO - 2016-11-04 18:47:06 --> Security Class Initialized
DEBUG - 2016-11-04 18:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:47:06 --> Input Class Initialized
INFO - 2016-11-04 18:47:06 --> Language Class Initialized
INFO - 2016-11-04 18:47:06 --> Loader Class Initialized
INFO - 2016-11-04 18:47:06 --> Helper loaded: url_helper
INFO - 2016-11-04 18:47:06 --> Helper loaded: form_helper
INFO - 2016-11-04 18:47:06 --> Database Driver Class Initialized
INFO - 2016-11-04 18:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:47:06 --> Controller Class Initialized
INFO - 2016-11-04 18:47:06 --> Model Class Initialized
INFO - 2016-11-04 18:47:06 --> Model Class Initialized
INFO - 2016-11-04 18:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:47:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:47:06 --> Final output sent to browser
DEBUG - 2016-11-04 18:47:06 --> Total execution time: 0.4204
INFO - 2016-11-04 18:47:16 --> Config Class Initialized
INFO - 2016-11-04 18:47:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:47:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:47:16 --> Utf8 Class Initialized
INFO - 2016-11-04 18:47:16 --> URI Class Initialized
INFO - 2016-11-04 18:47:16 --> Router Class Initialized
INFO - 2016-11-04 18:47:16 --> Output Class Initialized
INFO - 2016-11-04 18:47:16 --> Security Class Initialized
DEBUG - 2016-11-04 18:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:47:16 --> Input Class Initialized
INFO - 2016-11-04 18:47:16 --> Language Class Initialized
INFO - 2016-11-04 18:47:16 --> Loader Class Initialized
INFO - 2016-11-04 18:47:16 --> Helper loaded: url_helper
INFO - 2016-11-04 18:47:16 --> Helper loaded: form_helper
INFO - 2016-11-04 18:47:16 --> Database Driver Class Initialized
INFO - 2016-11-04 18:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:47:16 --> Controller Class Initialized
INFO - 2016-11-04 18:47:16 --> Model Class Initialized
INFO - 2016-11-04 18:47:16 --> Model Class Initialized
DEBUG - 2016-11-04 18:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:47:16 --> Model Class Initialized
ERROR - 2016-11-04 18:47:16 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:47:16 --> Final output sent to browser
DEBUG - 2016-11-04 18:47:16 --> Total execution time: 0.3782
INFO - 2016-11-04 18:47:24 --> Config Class Initialized
INFO - 2016-11-04 18:47:25 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:47:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:47:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:47:25 --> URI Class Initialized
DEBUG - 2016-11-04 18:47:25 --> No URI present. Default controller set.
INFO - 2016-11-04 18:47:25 --> Router Class Initialized
INFO - 2016-11-04 18:47:25 --> Output Class Initialized
INFO - 2016-11-04 18:47:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:47:25 --> Input Class Initialized
INFO - 2016-11-04 18:47:25 --> Language Class Initialized
INFO - 2016-11-04 18:47:25 --> Loader Class Initialized
INFO - 2016-11-04 18:47:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:47:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:47:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:47:25 --> Controller Class Initialized
INFO - 2016-11-04 18:47:25 --> Model Class Initialized
INFO - 2016-11-04 18:47:25 --> Model Class Initialized
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:47:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:47:25 --> Final output sent to browser
DEBUG - 2016-11-04 18:47:25 --> Total execution time: 0.5498
INFO - 2016-11-04 18:47:48 --> Config Class Initialized
INFO - 2016-11-04 18:47:48 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:47:48 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:47:48 --> Utf8 Class Initialized
INFO - 2016-11-04 18:47:48 --> URI Class Initialized
INFO - 2016-11-04 18:47:48 --> Router Class Initialized
INFO - 2016-11-04 18:47:48 --> Output Class Initialized
INFO - 2016-11-04 18:47:49 --> Security Class Initialized
DEBUG - 2016-11-04 18:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:47:49 --> Input Class Initialized
INFO - 2016-11-04 18:47:49 --> Language Class Initialized
INFO - 2016-11-04 18:47:49 --> Loader Class Initialized
INFO - 2016-11-04 18:47:49 --> Helper loaded: url_helper
INFO - 2016-11-04 18:47:49 --> Helper loaded: form_helper
INFO - 2016-11-04 18:47:49 --> Database Driver Class Initialized
INFO - 2016-11-04 18:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:47:49 --> Controller Class Initialized
INFO - 2016-11-04 18:47:49 --> Model Class Initialized
INFO - 2016-11-04 18:47:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:47:49 --> Final output sent to browser
DEBUG - 2016-11-04 18:47:49 --> Total execution time: 0.4501
INFO - 2016-11-04 18:47:57 --> Config Class Initialized
INFO - 2016-11-04 18:47:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:47:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:47:57 --> Utf8 Class Initialized
INFO - 2016-11-04 18:47:57 --> URI Class Initialized
INFO - 2016-11-04 18:47:57 --> Router Class Initialized
INFO - 2016-11-04 18:47:57 --> Output Class Initialized
INFO - 2016-11-04 18:47:57 --> Security Class Initialized
DEBUG - 2016-11-04 18:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:47:57 --> Input Class Initialized
INFO - 2016-11-04 18:47:57 --> Language Class Initialized
INFO - 2016-11-04 18:47:57 --> Loader Class Initialized
INFO - 2016-11-04 18:47:57 --> Helper loaded: url_helper
INFO - 2016-11-04 18:47:57 --> Helper loaded: form_helper
INFO - 2016-11-04 18:47:57 --> Database Driver Class Initialized
INFO - 2016-11-04 18:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:47:57 --> Controller Class Initialized
INFO - 2016-11-04 18:47:57 --> Form Validation Class Initialized
INFO - 2016-11-04 18:47:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:47:57 --> Final output sent to browser
DEBUG - 2016-11-04 18:47:57 --> Total execution time: 0.4617
INFO - 2016-11-04 18:48:13 --> Config Class Initialized
INFO - 2016-11-04 18:48:13 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:48:13 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:48:13 --> Utf8 Class Initialized
INFO - 2016-11-04 18:48:13 --> URI Class Initialized
INFO - 2016-11-04 18:48:13 --> Router Class Initialized
INFO - 2016-11-04 18:48:13 --> Output Class Initialized
INFO - 2016-11-04 18:48:13 --> Security Class Initialized
DEBUG - 2016-11-04 18:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:48:13 --> Input Class Initialized
INFO - 2016-11-04 18:48:13 --> Language Class Initialized
INFO - 2016-11-04 18:48:13 --> Loader Class Initialized
INFO - 2016-11-04 18:48:13 --> Helper loaded: url_helper
INFO - 2016-11-04 18:48:13 --> Helper loaded: form_helper
INFO - 2016-11-04 18:48:13 --> Database Driver Class Initialized
INFO - 2016-11-04 18:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:48:13 --> Controller Class Initialized
INFO - 2016-11-04 18:48:13 --> Model Class Initialized
INFO - 2016-11-04 18:48:13 --> Form Validation Class Initialized
INFO - 2016-11-04 18:48:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:48:13 --> Final output sent to browser
DEBUG - 2016-11-04 18:48:13 --> Total execution time: 0.3348
INFO - 2016-11-04 18:49:52 --> Config Class Initialized
INFO - 2016-11-04 18:49:52 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:49:52 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:49:52 --> Utf8 Class Initialized
INFO - 2016-11-04 18:49:52 --> URI Class Initialized
DEBUG - 2016-11-04 18:49:52 --> No URI present. Default controller set.
INFO - 2016-11-04 18:49:52 --> Router Class Initialized
INFO - 2016-11-04 18:49:52 --> Output Class Initialized
INFO - 2016-11-04 18:49:52 --> Security Class Initialized
DEBUG - 2016-11-04 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:49:52 --> Input Class Initialized
INFO - 2016-11-04 18:49:52 --> Language Class Initialized
INFO - 2016-11-04 18:49:52 --> Loader Class Initialized
INFO - 2016-11-04 18:49:52 --> Helper loaded: url_helper
INFO - 2016-11-04 18:49:52 --> Helper loaded: form_helper
INFO - 2016-11-04 18:49:52 --> Database Driver Class Initialized
INFO - 2016-11-04 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:49:52 --> Controller Class Initialized
INFO - 2016-11-04 18:49:52 --> Model Class Initialized
INFO - 2016-11-04 18:49:52 --> Model Class Initialized
INFO - 2016-11-04 18:49:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:49:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:49:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:49:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:49:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:49:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:49:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:49:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:49:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:49:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:49:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:49:53 --> Final output sent to browser
DEBUG - 2016-11-04 18:49:53 --> Total execution time: 0.5677
INFO - 2016-11-04 18:51:05 --> Config Class Initialized
INFO - 2016-11-04 18:51:05 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:51:05 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:51:05 --> Utf8 Class Initialized
INFO - 2016-11-04 18:51:05 --> URI Class Initialized
INFO - 2016-11-04 18:51:05 --> Router Class Initialized
INFO - 2016-11-04 18:51:05 --> Output Class Initialized
INFO - 2016-11-04 18:51:05 --> Security Class Initialized
DEBUG - 2016-11-04 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:51:05 --> Input Class Initialized
INFO - 2016-11-04 18:51:05 --> Language Class Initialized
INFO - 2016-11-04 18:51:05 --> Loader Class Initialized
INFO - 2016-11-04 18:51:05 --> Helper loaded: url_helper
INFO - 2016-11-04 18:51:05 --> Helper loaded: form_helper
INFO - 2016-11-04 18:51:05 --> Database Driver Class Initialized
INFO - 2016-11-04 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:51:06 --> Controller Class Initialized
INFO - 2016-11-04 18:51:06 --> Model Class Initialized
INFO - 2016-11-04 18:51:06 --> Model Class Initialized
DEBUG - 2016-11-04 18:51:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:51:06 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:51:06 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:51:06 --> Config Class Initialized
INFO - 2016-11-04 18:51:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:51:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:51:06 --> Utf8 Class Initialized
INFO - 2016-11-04 18:51:06 --> URI Class Initialized
DEBUG - 2016-11-04 18:51:06 --> No URI present. Default controller set.
INFO - 2016-11-04 18:51:06 --> Router Class Initialized
INFO - 2016-11-04 18:51:06 --> Output Class Initialized
INFO - 2016-11-04 18:51:06 --> Security Class Initialized
DEBUG - 2016-11-04 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:51:06 --> Input Class Initialized
INFO - 2016-11-04 18:51:06 --> Language Class Initialized
INFO - 2016-11-04 18:51:06 --> Loader Class Initialized
INFO - 2016-11-04 18:51:06 --> Helper loaded: url_helper
INFO - 2016-11-04 18:51:06 --> Helper loaded: form_helper
INFO - 2016-11-04 18:51:06 --> Database Driver Class Initialized
INFO - 2016-11-04 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:51:06 --> Controller Class Initialized
INFO - 2016-11-04 18:51:06 --> Model Class Initialized
INFO - 2016-11-04 18:51:06 --> Model Class Initialized
INFO - 2016-11-04 18:51:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:51:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:51:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:51:06 --> Final output sent to browser
DEBUG - 2016-11-04 18:51:06 --> Total execution time: 0.4376
INFO - 2016-11-04 18:51:17 --> Config Class Initialized
INFO - 2016-11-04 18:51:17 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:51:17 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:51:17 --> Utf8 Class Initialized
INFO - 2016-11-04 18:51:17 --> URI Class Initialized
INFO - 2016-11-04 18:51:17 --> Router Class Initialized
INFO - 2016-11-04 18:51:17 --> Output Class Initialized
INFO - 2016-11-04 18:51:17 --> Security Class Initialized
DEBUG - 2016-11-04 18:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:51:17 --> Input Class Initialized
INFO - 2016-11-04 18:51:17 --> Language Class Initialized
INFO - 2016-11-04 18:51:17 --> Loader Class Initialized
INFO - 2016-11-04 18:51:17 --> Helper loaded: url_helper
INFO - 2016-11-04 18:51:17 --> Helper loaded: form_helper
INFO - 2016-11-04 18:51:17 --> Database Driver Class Initialized
INFO - 2016-11-04 18:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:51:17 --> Controller Class Initialized
INFO - 2016-11-04 18:51:17 --> Model Class Initialized
INFO - 2016-11-04 18:51:17 --> Model Class Initialized
DEBUG - 2016-11-04 18:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:51:17 --> Model Class Initialized
ERROR - 2016-11-04 18:51:17 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:51:17 --> Final output sent to browser
DEBUG - 2016-11-04 18:51:17 --> Total execution time: 0.5379
INFO - 2016-11-04 18:51:23 --> Config Class Initialized
INFO - 2016-11-04 18:51:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:51:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:51:23 --> Utf8 Class Initialized
INFO - 2016-11-04 18:51:23 --> URI Class Initialized
DEBUG - 2016-11-04 18:51:23 --> No URI present. Default controller set.
INFO - 2016-11-04 18:51:23 --> Router Class Initialized
INFO - 2016-11-04 18:51:23 --> Output Class Initialized
INFO - 2016-11-04 18:51:23 --> Security Class Initialized
DEBUG - 2016-11-04 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:51:23 --> Input Class Initialized
INFO - 2016-11-04 18:51:23 --> Language Class Initialized
INFO - 2016-11-04 18:51:23 --> Loader Class Initialized
INFO - 2016-11-04 18:51:23 --> Helper loaded: url_helper
INFO - 2016-11-04 18:51:23 --> Helper loaded: form_helper
INFO - 2016-11-04 18:51:23 --> Database Driver Class Initialized
INFO - 2016-11-04 18:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:51:23 --> Controller Class Initialized
INFO - 2016-11-04 18:51:23 --> Model Class Initialized
INFO - 2016-11-04 18:51:23 --> Model Class Initialized
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:51:23 --> Final output sent to browser
DEBUG - 2016-11-04 18:51:23 --> Total execution time: 0.5577
INFO - 2016-11-04 18:51:30 --> Config Class Initialized
INFO - 2016-11-04 18:51:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:51:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:51:30 --> Utf8 Class Initialized
INFO - 2016-11-04 18:51:30 --> URI Class Initialized
INFO - 2016-11-04 18:51:30 --> Router Class Initialized
INFO - 2016-11-04 18:51:30 --> Output Class Initialized
INFO - 2016-11-04 18:51:30 --> Security Class Initialized
DEBUG - 2016-11-04 18:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:51:30 --> Input Class Initialized
INFO - 2016-11-04 18:51:30 --> Language Class Initialized
INFO - 2016-11-04 18:51:30 --> Loader Class Initialized
INFO - 2016-11-04 18:51:30 --> Helper loaded: url_helper
INFO - 2016-11-04 18:51:30 --> Helper loaded: form_helper
INFO - 2016-11-04 18:51:30 --> Database Driver Class Initialized
INFO - 2016-11-04 18:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:51:30 --> Controller Class Initialized
INFO - 2016-11-04 18:51:30 --> Model Class Initialized
INFO - 2016-11-04 18:51:30 --> Model Class Initialized
DEBUG - 2016-11-04 18:51:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:51:30 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:51:30 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:51:30 --> Config Class Initialized
INFO - 2016-11-04 18:51:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:51:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:51:30 --> Utf8 Class Initialized
INFO - 2016-11-04 18:51:30 --> URI Class Initialized
DEBUG - 2016-11-04 18:51:30 --> No URI present. Default controller set.
INFO - 2016-11-04 18:51:30 --> Router Class Initialized
INFO - 2016-11-04 18:51:30 --> Output Class Initialized
INFO - 2016-11-04 18:51:30 --> Security Class Initialized
DEBUG - 2016-11-04 18:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:51:30 --> Input Class Initialized
INFO - 2016-11-04 18:51:30 --> Language Class Initialized
INFO - 2016-11-04 18:51:30 --> Loader Class Initialized
INFO - 2016-11-04 18:51:30 --> Helper loaded: url_helper
INFO - 2016-11-04 18:51:30 --> Helper loaded: form_helper
INFO - 2016-11-04 18:51:30 --> Database Driver Class Initialized
INFO - 2016-11-04 18:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:51:30 --> Controller Class Initialized
INFO - 2016-11-04 18:51:30 --> Model Class Initialized
INFO - 2016-11-04 18:51:30 --> Model Class Initialized
INFO - 2016-11-04 18:51:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:51:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:51:31 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:51:31 --> Final output sent to browser
DEBUG - 2016-11-04 18:51:31 --> Total execution time: 0.3852
INFO - 2016-11-04 18:52:34 --> Config Class Initialized
INFO - 2016-11-04 18:52:34 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:52:34 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:52:34 --> Utf8 Class Initialized
INFO - 2016-11-04 18:52:34 --> URI Class Initialized
INFO - 2016-11-04 18:52:34 --> Router Class Initialized
INFO - 2016-11-04 18:52:34 --> Output Class Initialized
INFO - 2016-11-04 18:52:34 --> Security Class Initialized
DEBUG - 2016-11-04 18:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:52:34 --> Input Class Initialized
INFO - 2016-11-04 18:52:34 --> Language Class Initialized
INFO - 2016-11-04 18:52:34 --> Loader Class Initialized
INFO - 2016-11-04 18:52:34 --> Helper loaded: url_helper
INFO - 2016-11-04 18:52:34 --> Helper loaded: form_helper
INFO - 2016-11-04 18:52:34 --> Database Driver Class Initialized
INFO - 2016-11-04 18:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:52:34 --> Controller Class Initialized
INFO - 2016-11-04 18:52:34 --> Model Class Initialized
INFO - 2016-11-04 18:52:34 --> Model Class Initialized
DEBUG - 2016-11-04 18:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:52:34 --> Model Class Initialized
ERROR - 2016-11-04 18:52:34 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:52:34 --> Final output sent to browser
DEBUG - 2016-11-04 18:52:34 --> Total execution time: 0.4034
INFO - 2016-11-04 18:52:37 --> Config Class Initialized
INFO - 2016-11-04 18:52:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:52:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:52:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:52:37 --> URI Class Initialized
DEBUG - 2016-11-04 18:52:37 --> No URI present. Default controller set.
INFO - 2016-11-04 18:52:37 --> Router Class Initialized
INFO - 2016-11-04 18:52:37 --> Output Class Initialized
INFO - 2016-11-04 18:52:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:52:37 --> Input Class Initialized
INFO - 2016-11-04 18:52:37 --> Language Class Initialized
INFO - 2016-11-04 18:52:37 --> Loader Class Initialized
INFO - 2016-11-04 18:52:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:52:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:52:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:52:37 --> Controller Class Initialized
INFO - 2016-11-04 18:52:37 --> Model Class Initialized
INFO - 2016-11-04 18:52:37 --> Model Class Initialized
INFO - 2016-11-04 18:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:52:37 --> Final output sent to browser
DEBUG - 2016-11-04 18:52:37 --> Total execution time: 0.4296
INFO - 2016-11-04 18:52:43 --> Config Class Initialized
INFO - 2016-11-04 18:52:43 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:52:43 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:52:43 --> Utf8 Class Initialized
INFO - 2016-11-04 18:52:43 --> URI Class Initialized
DEBUG - 2016-11-04 18:52:43 --> No URI present. Default controller set.
INFO - 2016-11-04 18:52:43 --> Router Class Initialized
INFO - 2016-11-04 18:52:43 --> Output Class Initialized
INFO - 2016-11-04 18:52:43 --> Security Class Initialized
DEBUG - 2016-11-04 18:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:52:43 --> Input Class Initialized
INFO - 2016-11-04 18:52:43 --> Language Class Initialized
INFO - 2016-11-04 18:52:43 --> Loader Class Initialized
INFO - 2016-11-04 18:52:43 --> Helper loaded: url_helper
INFO - 2016-11-04 18:52:43 --> Helper loaded: form_helper
INFO - 2016-11-04 18:52:43 --> Database Driver Class Initialized
INFO - 2016-11-04 18:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:52:43 --> Controller Class Initialized
INFO - 2016-11-04 18:52:43 --> Model Class Initialized
INFO - 2016-11-04 18:52:43 --> Model Class Initialized
INFO - 2016-11-04 18:52:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:52:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:52:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:52:43 --> Final output sent to browser
DEBUG - 2016-11-04 18:52:43 --> Total execution time: 0.4089
INFO - 2016-11-04 18:52:53 --> Config Class Initialized
INFO - 2016-11-04 18:52:53 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:52:53 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:52:53 --> Utf8 Class Initialized
INFO - 2016-11-04 18:52:53 --> URI Class Initialized
INFO - 2016-11-04 18:52:53 --> Router Class Initialized
INFO - 2016-11-04 18:52:54 --> Output Class Initialized
INFO - 2016-11-04 18:52:54 --> Security Class Initialized
DEBUG - 2016-11-04 18:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:52:54 --> Input Class Initialized
INFO - 2016-11-04 18:52:54 --> Language Class Initialized
INFO - 2016-11-04 18:52:54 --> Loader Class Initialized
INFO - 2016-11-04 18:52:54 --> Helper loaded: url_helper
INFO - 2016-11-04 18:52:54 --> Helper loaded: form_helper
INFO - 2016-11-04 18:52:54 --> Database Driver Class Initialized
INFO - 2016-11-04 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:52:54 --> Controller Class Initialized
INFO - 2016-11-04 18:52:54 --> Model Class Initialized
INFO - 2016-11-04 18:52:54 --> Model Class Initialized
DEBUG - 2016-11-04 18:52:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:52:54 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:52:54 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:52:54 --> Config Class Initialized
INFO - 2016-11-04 18:52:54 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:52:54 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:52:54 --> Utf8 Class Initialized
INFO - 2016-11-04 18:52:54 --> URI Class Initialized
DEBUG - 2016-11-04 18:52:54 --> No URI present. Default controller set.
INFO - 2016-11-04 18:52:54 --> Router Class Initialized
INFO - 2016-11-04 18:52:54 --> Output Class Initialized
INFO - 2016-11-04 18:52:54 --> Security Class Initialized
DEBUG - 2016-11-04 18:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:52:54 --> Input Class Initialized
INFO - 2016-11-04 18:52:54 --> Language Class Initialized
INFO - 2016-11-04 18:52:54 --> Loader Class Initialized
INFO - 2016-11-04 18:52:54 --> Helper loaded: url_helper
INFO - 2016-11-04 18:52:54 --> Helper loaded: form_helper
INFO - 2016-11-04 18:52:54 --> Database Driver Class Initialized
INFO - 2016-11-04 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:52:54 --> Controller Class Initialized
INFO - 2016-11-04 18:52:54 --> Model Class Initialized
INFO - 2016-11-04 18:52:54 --> Model Class Initialized
INFO - 2016-11-04 18:52:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:52:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:52:54 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:52:54 --> Final output sent to browser
DEBUG - 2016-11-04 18:52:54 --> Total execution time: 0.3890
INFO - 2016-11-04 18:52:59 --> Config Class Initialized
INFO - 2016-11-04 18:52:59 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:52:59 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:52:59 --> Utf8 Class Initialized
INFO - 2016-11-04 18:52:59 --> URI Class Initialized
INFO - 2016-11-04 18:52:59 --> Router Class Initialized
INFO - 2016-11-04 18:52:59 --> Output Class Initialized
INFO - 2016-11-04 18:52:59 --> Security Class Initialized
DEBUG - 2016-11-04 18:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:52:59 --> Input Class Initialized
INFO - 2016-11-04 18:52:59 --> Language Class Initialized
INFO - 2016-11-04 18:52:59 --> Loader Class Initialized
INFO - 2016-11-04 18:52:59 --> Helper loaded: url_helper
INFO - 2016-11-04 18:52:59 --> Helper loaded: form_helper
INFO - 2016-11-04 18:52:59 --> Database Driver Class Initialized
INFO - 2016-11-04 18:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:52:59 --> Controller Class Initialized
INFO - 2016-11-04 18:52:59 --> Model Class Initialized
INFO - 2016-11-04 18:52:59 --> Model Class Initialized
DEBUG - 2016-11-04 18:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:52:59 --> Model Class Initialized
ERROR - 2016-11-04 18:52:59 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:52:59 --> Final output sent to browser
DEBUG - 2016-11-04 18:52:59 --> Total execution time: 0.5868
INFO - 2016-11-04 18:53:06 --> Config Class Initialized
INFO - 2016-11-04 18:53:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:06 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:06 --> URI Class Initialized
DEBUG - 2016-11-04 18:53:06 --> No URI present. Default controller set.
INFO - 2016-11-04 18:53:06 --> Router Class Initialized
INFO - 2016-11-04 18:53:06 --> Output Class Initialized
INFO - 2016-11-04 18:53:06 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:06 --> Input Class Initialized
INFO - 2016-11-04 18:53:06 --> Language Class Initialized
INFO - 2016-11-04 18:53:06 --> Loader Class Initialized
INFO - 2016-11-04 18:53:06 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:06 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:06 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:06 --> Controller Class Initialized
INFO - 2016-11-04 18:53:06 --> Model Class Initialized
INFO - 2016-11-04 18:53:06 --> Model Class Initialized
INFO - 2016-11-04 18:53:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:53:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:53:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:53:06 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:06 --> Total execution time: 0.4162
INFO - 2016-11-04 18:53:16 --> Config Class Initialized
INFO - 2016-11-04 18:53:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:16 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:16 --> URI Class Initialized
DEBUG - 2016-11-04 18:53:16 --> No URI present. Default controller set.
INFO - 2016-11-04 18:53:17 --> Router Class Initialized
INFO - 2016-11-04 18:53:17 --> Output Class Initialized
INFO - 2016-11-04 18:53:17 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:17 --> Input Class Initialized
INFO - 2016-11-04 18:53:17 --> Language Class Initialized
INFO - 2016-11-04 18:53:17 --> Loader Class Initialized
INFO - 2016-11-04 18:53:17 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:17 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:17 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:17 --> Controller Class Initialized
INFO - 2016-11-04 18:53:17 --> Model Class Initialized
INFO - 2016-11-04 18:53:17 --> Model Class Initialized
INFO - 2016-11-04 18:53:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:53:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:53:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:53:17 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:17 --> Total execution time: 0.4257
INFO - 2016-11-04 18:53:29 --> Config Class Initialized
INFO - 2016-11-04 18:53:29 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:29 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:29 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:29 --> URI Class Initialized
DEBUG - 2016-11-04 18:53:29 --> No URI present. Default controller set.
INFO - 2016-11-04 18:53:29 --> Router Class Initialized
INFO - 2016-11-04 18:53:29 --> Output Class Initialized
INFO - 2016-11-04 18:53:29 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:29 --> Input Class Initialized
INFO - 2016-11-04 18:53:29 --> Language Class Initialized
INFO - 2016-11-04 18:53:29 --> Loader Class Initialized
INFO - 2016-11-04 18:53:29 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:29 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:29 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:29 --> Controller Class Initialized
INFO - 2016-11-04 18:53:29 --> Model Class Initialized
INFO - 2016-11-04 18:53:29 --> Model Class Initialized
INFO - 2016-11-04 18:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:53:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:53:29 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:29 --> Total execution time: 0.4374
INFO - 2016-11-04 18:53:37 --> Config Class Initialized
INFO - 2016-11-04 18:53:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:37 --> URI Class Initialized
INFO - 2016-11-04 18:53:37 --> Router Class Initialized
INFO - 2016-11-04 18:53:37 --> Output Class Initialized
INFO - 2016-11-04 18:53:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:37 --> Input Class Initialized
INFO - 2016-11-04 18:53:37 --> Language Class Initialized
INFO - 2016-11-04 18:53:37 --> Loader Class Initialized
INFO - 2016-11-04 18:53:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:37 --> Controller Class Initialized
INFO - 2016-11-04 18:53:37 --> Model Class Initialized
INFO - 2016-11-04 18:53:37 --> Model Class Initialized
DEBUG - 2016-11-04 18:53:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:53:37 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:53:37 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:53:37 --> Config Class Initialized
INFO - 2016-11-04 18:53:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:37 --> URI Class Initialized
DEBUG - 2016-11-04 18:53:37 --> No URI present. Default controller set.
INFO - 2016-11-04 18:53:37 --> Router Class Initialized
INFO - 2016-11-04 18:53:37 --> Output Class Initialized
INFO - 2016-11-04 18:53:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:37 --> Input Class Initialized
INFO - 2016-11-04 18:53:37 --> Language Class Initialized
INFO - 2016-11-04 18:53:37 --> Loader Class Initialized
INFO - 2016-11-04 18:53:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:37 --> Controller Class Initialized
INFO - 2016-11-04 18:53:37 --> Model Class Initialized
INFO - 2016-11-04 18:53:37 --> Model Class Initialized
INFO - 2016-11-04 18:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:53:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:53:37 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:37 --> Total execution time: 0.4042
INFO - 2016-11-04 18:53:45 --> Config Class Initialized
INFO - 2016-11-04 18:53:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:46 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:46 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:46 --> URI Class Initialized
INFO - 2016-11-04 18:53:46 --> Router Class Initialized
INFO - 2016-11-04 18:53:46 --> Output Class Initialized
INFO - 2016-11-04 18:53:46 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:46 --> Input Class Initialized
INFO - 2016-11-04 18:53:46 --> Language Class Initialized
INFO - 2016-11-04 18:53:46 --> Loader Class Initialized
INFO - 2016-11-04 18:53:46 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:46 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:46 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:46 --> Controller Class Initialized
INFO - 2016-11-04 18:53:46 --> Model Class Initialized
INFO - 2016-11-04 18:53:46 --> Model Class Initialized
DEBUG - 2016-11-04 18:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:53:46 --> Model Class Initialized
ERROR - 2016-11-04 18:53:46 --> Severity: Warning --> hash(): Unknown hashing algorithm: 256 C:\xampp\htdocs\LMS\app\models\Auth_model.php 11
INFO - 2016-11-04 18:53:46 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:46 --> Total execution time: 0.5641
INFO - 2016-11-04 18:53:48 --> Config Class Initialized
INFO - 2016-11-04 18:53:48 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:48 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:48 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:48 --> URI Class Initialized
DEBUG - 2016-11-04 18:53:48 --> No URI present. Default controller set.
INFO - 2016-11-04 18:53:48 --> Router Class Initialized
INFO - 2016-11-04 18:53:48 --> Output Class Initialized
INFO - 2016-11-04 18:53:48 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:48 --> Input Class Initialized
INFO - 2016-11-04 18:53:48 --> Language Class Initialized
INFO - 2016-11-04 18:53:48 --> Loader Class Initialized
INFO - 2016-11-04 18:53:48 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:48 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:48 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:48 --> Controller Class Initialized
INFO - 2016-11-04 18:53:48 --> Model Class Initialized
INFO - 2016-11-04 18:53:48 --> Model Class Initialized
INFO - 2016-11-04 18:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:53:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:53:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:53:49 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:49 --> Total execution time: 0.5794
INFO - 2016-11-04 18:53:57 --> Config Class Initialized
INFO - 2016-11-04 18:53:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:57 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:57 --> URI Class Initialized
INFO - 2016-11-04 18:53:57 --> Router Class Initialized
INFO - 2016-11-04 18:53:57 --> Output Class Initialized
INFO - 2016-11-04 18:53:57 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:57 --> Input Class Initialized
INFO - 2016-11-04 18:53:57 --> Language Class Initialized
INFO - 2016-11-04 18:53:57 --> Loader Class Initialized
INFO - 2016-11-04 18:53:57 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:57 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:57 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:57 --> Controller Class Initialized
INFO - 2016-11-04 18:53:57 --> Model Class Initialized
INFO - 2016-11-04 18:53:57 --> Model Class Initialized
DEBUG - 2016-11-04 18:53:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:53:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:53:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:53:57 --> Config Class Initialized
INFO - 2016-11-04 18:53:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:53:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:53:57 --> Utf8 Class Initialized
INFO - 2016-11-04 18:53:57 --> URI Class Initialized
DEBUG - 2016-11-04 18:53:57 --> No URI present. Default controller set.
INFO - 2016-11-04 18:53:57 --> Router Class Initialized
INFO - 2016-11-04 18:53:57 --> Output Class Initialized
INFO - 2016-11-04 18:53:57 --> Security Class Initialized
DEBUG - 2016-11-04 18:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:53:57 --> Input Class Initialized
INFO - 2016-11-04 18:53:57 --> Language Class Initialized
INFO - 2016-11-04 18:53:57 --> Loader Class Initialized
INFO - 2016-11-04 18:53:57 --> Helper loaded: url_helper
INFO - 2016-11-04 18:53:58 --> Helper loaded: form_helper
INFO - 2016-11-04 18:53:58 --> Database Driver Class Initialized
INFO - 2016-11-04 18:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:53:58 --> Controller Class Initialized
INFO - 2016-11-04 18:53:58 --> Model Class Initialized
INFO - 2016-11-04 18:53:58 --> Model Class Initialized
INFO - 2016-11-04 18:53:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:53:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:53:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:53:58 --> Final output sent to browser
DEBUG - 2016-11-04 18:53:58 --> Total execution time: 0.3996
INFO - 2016-11-04 18:55:21 --> Config Class Initialized
INFO - 2016-11-04 18:55:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:55:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:55:21 --> Utf8 Class Initialized
INFO - 2016-11-04 18:55:21 --> URI Class Initialized
DEBUG - 2016-11-04 18:55:21 --> No URI present. Default controller set.
INFO - 2016-11-04 18:55:21 --> Router Class Initialized
INFO - 2016-11-04 18:55:21 --> Output Class Initialized
INFO - 2016-11-04 18:55:21 --> Security Class Initialized
DEBUG - 2016-11-04 18:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:55:21 --> Input Class Initialized
INFO - 2016-11-04 18:55:21 --> Language Class Initialized
INFO - 2016-11-04 18:55:21 --> Loader Class Initialized
INFO - 2016-11-04 18:55:21 --> Helper loaded: url_helper
INFO - 2016-11-04 18:55:21 --> Helper loaded: form_helper
INFO - 2016-11-04 18:55:21 --> Database Driver Class Initialized
INFO - 2016-11-04 18:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:55:21 --> Controller Class Initialized
INFO - 2016-11-04 18:55:21 --> Model Class Initialized
INFO - 2016-11-04 18:55:21 --> Model Class Initialized
INFO - 2016-11-04 18:55:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:55:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:55:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:55:21 --> Final output sent to browser
DEBUG - 2016-11-04 18:55:21 --> Total execution time: 0.4028
INFO - 2016-11-04 18:55:30 --> Config Class Initialized
INFO - 2016-11-04 18:55:30 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:55:30 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:55:30 --> Utf8 Class Initialized
INFO - 2016-11-04 18:55:30 --> URI Class Initialized
DEBUG - 2016-11-04 18:55:30 --> No URI present. Default controller set.
INFO - 2016-11-04 18:55:30 --> Router Class Initialized
INFO - 2016-11-04 18:55:30 --> Output Class Initialized
INFO - 2016-11-04 18:55:30 --> Security Class Initialized
DEBUG - 2016-11-04 18:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:55:30 --> Input Class Initialized
INFO - 2016-11-04 18:55:30 --> Language Class Initialized
INFO - 2016-11-04 18:55:30 --> Loader Class Initialized
INFO - 2016-11-04 18:55:30 --> Helper loaded: url_helper
INFO - 2016-11-04 18:55:30 --> Helper loaded: form_helper
INFO - 2016-11-04 18:55:30 --> Database Driver Class Initialized
INFO - 2016-11-04 18:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:55:30 --> Controller Class Initialized
INFO - 2016-11-04 18:55:30 --> Model Class Initialized
INFO - 2016-11-04 18:55:30 --> Model Class Initialized
INFO - 2016-11-04 18:55:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:55:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:55:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:55:30 --> Final output sent to browser
DEBUG - 2016-11-04 18:55:30 --> Total execution time: 0.4189
INFO - 2016-11-04 18:55:36 --> Config Class Initialized
INFO - 2016-11-04 18:55:36 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:55:36 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:55:36 --> Utf8 Class Initialized
INFO - 2016-11-04 18:55:37 --> URI Class Initialized
INFO - 2016-11-04 18:55:37 --> Router Class Initialized
INFO - 2016-11-04 18:55:37 --> Output Class Initialized
INFO - 2016-11-04 18:55:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:55:37 --> Input Class Initialized
INFO - 2016-11-04 18:55:37 --> Language Class Initialized
INFO - 2016-11-04 18:55:37 --> Loader Class Initialized
INFO - 2016-11-04 18:55:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:55:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:55:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:55:37 --> Controller Class Initialized
INFO - 2016-11-04 18:55:37 --> Model Class Initialized
INFO - 2016-11-04 18:55:37 --> Model Class Initialized
DEBUG - 2016-11-04 18:55:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:55:37 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:55:37 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:55:37 --> Config Class Initialized
INFO - 2016-11-04 18:55:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:55:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:55:37 --> Utf8 Class Initialized
INFO - 2016-11-04 18:55:37 --> URI Class Initialized
DEBUG - 2016-11-04 18:55:37 --> No URI present. Default controller set.
INFO - 2016-11-04 18:55:37 --> Router Class Initialized
INFO - 2016-11-04 18:55:37 --> Output Class Initialized
INFO - 2016-11-04 18:55:37 --> Security Class Initialized
DEBUG - 2016-11-04 18:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:55:37 --> Input Class Initialized
INFO - 2016-11-04 18:55:37 --> Language Class Initialized
INFO - 2016-11-04 18:55:37 --> Loader Class Initialized
INFO - 2016-11-04 18:55:37 --> Helper loaded: url_helper
INFO - 2016-11-04 18:55:37 --> Helper loaded: form_helper
INFO - 2016-11-04 18:55:37 --> Database Driver Class Initialized
INFO - 2016-11-04 18:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:55:37 --> Controller Class Initialized
INFO - 2016-11-04 18:55:37 --> Model Class Initialized
INFO - 2016-11-04 18:55:37 --> Model Class Initialized
INFO - 2016-11-04 18:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:55:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:55:37 --> Final output sent to browser
DEBUG - 2016-11-04 18:55:37 --> Total execution time: 0.4501
INFO - 2016-11-04 18:55:45 --> Config Class Initialized
INFO - 2016-11-04 18:55:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:55:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:55:45 --> Utf8 Class Initialized
INFO - 2016-11-04 18:55:45 --> URI Class Initialized
INFO - 2016-11-04 18:55:45 --> Router Class Initialized
INFO - 2016-11-04 18:55:45 --> Output Class Initialized
INFO - 2016-11-04 18:55:45 --> Security Class Initialized
DEBUG - 2016-11-04 18:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:55:45 --> Input Class Initialized
INFO - 2016-11-04 18:55:45 --> Language Class Initialized
INFO - 2016-11-04 18:55:45 --> Loader Class Initialized
INFO - 2016-11-04 18:55:45 --> Helper loaded: url_helper
INFO - 2016-11-04 18:55:45 --> Helper loaded: form_helper
INFO - 2016-11-04 18:55:45 --> Database Driver Class Initialized
INFO - 2016-11-04 18:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:55:45 --> Controller Class Initialized
INFO - 2016-11-04 18:55:45 --> Model Class Initialized
INFO - 2016-11-04 18:55:45 --> Model Class Initialized
DEBUG - 2016-11-04 18:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:55:45 --> Model Class Initialized
INFO - 2016-11-04 18:55:45 --> Final output sent to browser
DEBUG - 2016-11-04 18:55:45 --> Total execution time: 0.3762
INFO - 2016-11-04 18:55:55 --> Config Class Initialized
INFO - 2016-11-04 18:55:55 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:55:55 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:55:55 --> Utf8 Class Initialized
INFO - 2016-11-04 18:55:55 --> URI Class Initialized
INFO - 2016-11-04 18:55:55 --> Router Class Initialized
INFO - 2016-11-04 18:55:55 --> Output Class Initialized
INFO - 2016-11-04 18:55:55 --> Security Class Initialized
DEBUG - 2016-11-04 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:55:55 --> Input Class Initialized
INFO - 2016-11-04 18:55:55 --> Language Class Initialized
INFO - 2016-11-04 18:55:55 --> Loader Class Initialized
INFO - 2016-11-04 18:55:55 --> Helper loaded: url_helper
INFO - 2016-11-04 18:55:55 --> Helper loaded: form_helper
INFO - 2016-11-04 18:55:55 --> Database Driver Class Initialized
INFO - 2016-11-04 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:55:55 --> Controller Class Initialized
INFO - 2016-11-04 18:55:55 --> Model Class Initialized
INFO - 2016-11-04 18:55:55 --> Model Class Initialized
DEBUG - 2016-11-04 18:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:55:55 --> Model Class Initialized
INFO - 2016-11-04 18:55:55 --> Final output sent to browser
DEBUG - 2016-11-04 18:55:55 --> Total execution time: 0.4896
INFO - 2016-11-04 18:56:25 --> Config Class Initialized
INFO - 2016-11-04 18:56:25 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:56:25 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:56:25 --> Utf8 Class Initialized
INFO - 2016-11-04 18:56:25 --> URI Class Initialized
INFO - 2016-11-04 18:56:25 --> Router Class Initialized
INFO - 2016-11-04 18:56:25 --> Output Class Initialized
INFO - 2016-11-04 18:56:25 --> Security Class Initialized
DEBUG - 2016-11-04 18:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:56:25 --> Input Class Initialized
INFO - 2016-11-04 18:56:25 --> Language Class Initialized
INFO - 2016-11-04 18:56:25 --> Loader Class Initialized
INFO - 2016-11-04 18:56:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:56:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:56:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:56:25 --> Controller Class Initialized
INFO - 2016-11-04 18:56:25 --> Model Class Initialized
INFO - 2016-11-04 18:56:25 --> Model Class Initialized
DEBUG - 2016-11-04 18:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:56:25 --> Model Class Initialized
INFO - 2016-11-04 18:56:25 --> Final output sent to browser
DEBUG - 2016-11-04 18:56:25 --> Total execution time: 0.3744
INFO - 2016-11-04 18:56:45 --> Config Class Initialized
INFO - 2016-11-04 18:56:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:56:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:56:45 --> Utf8 Class Initialized
INFO - 2016-11-04 18:56:45 --> URI Class Initialized
INFO - 2016-11-04 18:56:45 --> Router Class Initialized
INFO - 2016-11-04 18:56:45 --> Output Class Initialized
INFO - 2016-11-04 18:56:45 --> Security Class Initialized
DEBUG - 2016-11-04 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:56:45 --> Input Class Initialized
INFO - 2016-11-04 18:56:45 --> Language Class Initialized
INFO - 2016-11-04 18:56:45 --> Loader Class Initialized
INFO - 2016-11-04 18:56:45 --> Helper loaded: url_helper
INFO - 2016-11-04 18:56:45 --> Helper loaded: form_helper
INFO - 2016-11-04 18:56:45 --> Database Driver Class Initialized
INFO - 2016-11-04 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:56:45 --> Controller Class Initialized
INFO - 2016-11-04 18:56:45 --> Model Class Initialized
INFO - 2016-11-04 18:56:45 --> Model Class Initialized
DEBUG - 2016-11-04 18:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:56:45 --> Model Class Initialized
INFO - 2016-11-04 18:56:45 --> Final output sent to browser
DEBUG - 2016-11-04 18:56:45 --> Total execution time: 0.3786
INFO - 2016-11-04 18:56:58 --> Config Class Initialized
INFO - 2016-11-04 18:56:58 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:56:58 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:56:58 --> Utf8 Class Initialized
INFO - 2016-11-04 18:56:58 --> URI Class Initialized
INFO - 2016-11-04 18:56:58 --> Router Class Initialized
INFO - 2016-11-04 18:56:58 --> Output Class Initialized
INFO - 2016-11-04 18:56:58 --> Security Class Initialized
DEBUG - 2016-11-04 18:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:56:58 --> Input Class Initialized
INFO - 2016-11-04 18:56:58 --> Language Class Initialized
INFO - 2016-11-04 18:56:58 --> Loader Class Initialized
INFO - 2016-11-04 18:56:58 --> Helper loaded: url_helper
INFO - 2016-11-04 18:56:58 --> Helper loaded: form_helper
INFO - 2016-11-04 18:56:58 --> Database Driver Class Initialized
INFO - 2016-11-04 18:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:56:58 --> Controller Class Initialized
INFO - 2016-11-04 18:56:58 --> Model Class Initialized
INFO - 2016-11-04 18:56:58 --> Model Class Initialized
DEBUG - 2016-11-04 18:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:56:58 --> Model Class Initialized
INFO - 2016-11-04 18:56:58 --> Final output sent to browser
DEBUG - 2016-11-04 18:56:58 --> Total execution time: 0.3666
INFO - 2016-11-04 18:56:58 --> Config Class Initialized
INFO - 2016-11-04 18:56:58 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:56:58 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:56:58 --> Utf8 Class Initialized
INFO - 2016-11-04 18:56:58 --> URI Class Initialized
DEBUG - 2016-11-04 18:56:58 --> No URI present. Default controller set.
INFO - 2016-11-04 18:56:58 --> Router Class Initialized
INFO - 2016-11-04 18:56:58 --> Output Class Initialized
INFO - 2016-11-04 18:56:58 --> Security Class Initialized
DEBUG - 2016-11-04 18:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:56:58 --> Input Class Initialized
INFO - 2016-11-04 18:56:59 --> Language Class Initialized
INFO - 2016-11-04 18:56:59 --> Loader Class Initialized
INFO - 2016-11-04 18:56:59 --> Helper loaded: url_helper
INFO - 2016-11-04 18:56:59 --> Helper loaded: form_helper
INFO - 2016-11-04 18:56:59 --> Database Driver Class Initialized
INFO - 2016-11-04 18:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:56:59 --> Controller Class Initialized
INFO - 2016-11-04 18:56:59 --> Model Class Initialized
INFO - 2016-11-04 18:56:59 --> Model Class Initialized
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:56:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:56:59 --> Final output sent to browser
DEBUG - 2016-11-04 18:56:59 --> Total execution time: 0.5444
INFO - 2016-11-04 18:57:01 --> Config Class Initialized
INFO - 2016-11-04 18:57:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:57:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:57:01 --> Utf8 Class Initialized
INFO - 2016-11-04 18:57:01 --> URI Class Initialized
DEBUG - 2016-11-04 18:57:01 --> No URI present. Default controller set.
INFO - 2016-11-04 18:57:01 --> Router Class Initialized
INFO - 2016-11-04 18:57:01 --> Output Class Initialized
INFO - 2016-11-04 18:57:01 --> Security Class Initialized
DEBUG - 2016-11-04 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:57:01 --> Input Class Initialized
INFO - 2016-11-04 18:57:01 --> Language Class Initialized
INFO - 2016-11-04 18:57:01 --> Loader Class Initialized
INFO - 2016-11-04 18:57:01 --> Helper loaded: url_helper
INFO - 2016-11-04 18:57:01 --> Helper loaded: form_helper
INFO - 2016-11-04 18:57:01 --> Database Driver Class Initialized
INFO - 2016-11-04 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:57:01 --> Controller Class Initialized
INFO - 2016-11-04 18:57:01 --> Model Class Initialized
INFO - 2016-11-04 18:57:01 --> Model Class Initialized
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:57:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:57:01 --> Final output sent to browser
DEBUG - 2016-11-04 18:57:01 --> Total execution time: 0.6563
INFO - 2016-11-04 18:57:40 --> Config Class Initialized
INFO - 2016-11-04 18:57:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:57:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:57:40 --> Utf8 Class Initialized
INFO - 2016-11-04 18:57:40 --> URI Class Initialized
DEBUG - 2016-11-04 18:57:40 --> No URI present. Default controller set.
INFO - 2016-11-04 18:57:40 --> Router Class Initialized
INFO - 2016-11-04 18:57:40 --> Output Class Initialized
INFO - 2016-11-04 18:57:40 --> Security Class Initialized
DEBUG - 2016-11-04 18:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:57:40 --> Input Class Initialized
INFO - 2016-11-04 18:57:40 --> Language Class Initialized
INFO - 2016-11-04 18:57:40 --> Loader Class Initialized
INFO - 2016-11-04 18:57:40 --> Helper loaded: url_helper
INFO - 2016-11-04 18:57:40 --> Helper loaded: form_helper
INFO - 2016-11-04 18:57:40 --> Database Driver Class Initialized
INFO - 2016-11-04 18:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:57:40 --> Controller Class Initialized
INFO - 2016-11-04 18:57:40 --> Model Class Initialized
INFO - 2016-11-04 18:57:40 --> Model Class Initialized
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:57:40 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:57:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:57:41 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:57:41 --> Final output sent to browser
DEBUG - 2016-11-04 18:57:41 --> Total execution time: 0.5697
INFO - 2016-11-04 18:59:24 --> Config Class Initialized
INFO - 2016-11-04 18:59:24 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:24 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:24 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:24 --> URI Class Initialized
INFO - 2016-11-04 18:59:24 --> Router Class Initialized
INFO - 2016-11-04 18:59:24 --> Output Class Initialized
INFO - 2016-11-04 18:59:24 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:24 --> Input Class Initialized
INFO - 2016-11-04 18:59:24 --> Language Class Initialized
INFO - 2016-11-04 18:59:25 --> Loader Class Initialized
INFO - 2016-11-04 18:59:25 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:25 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:25 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:25 --> Controller Class Initialized
INFO - 2016-11-04 18:59:25 --> Model Class Initialized
INFO - 2016-11-04 18:59:25 --> Form Validation Class Initialized
INFO - 2016-11-04 18:59:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 18:59:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:59:25 --> Final output sent to browser
DEBUG - 2016-11-04 18:59:25 --> Total execution time: 0.4890
INFO - 2016-11-04 18:59:27 --> Config Class Initialized
INFO - 2016-11-04 18:59:27 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:27 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:27 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:27 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:27 --> No URI present. Default controller set.
INFO - 2016-11-04 18:59:27 --> Router Class Initialized
INFO - 2016-11-04 18:59:27 --> Output Class Initialized
INFO - 2016-11-04 18:59:27 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:27 --> Input Class Initialized
INFO - 2016-11-04 18:59:27 --> Language Class Initialized
INFO - 2016-11-04 18:59:27 --> Loader Class Initialized
INFO - 2016-11-04 18:59:27 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:27 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:27 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:27 --> Controller Class Initialized
INFO - 2016-11-04 18:59:27 --> Model Class Initialized
INFO - 2016-11-04 18:59:27 --> Model Class Initialized
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:59:27 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:59:27 --> Final output sent to browser
DEBUG - 2016-11-04 18:59:28 --> Total execution time: 0.5613
INFO - 2016-11-04 18:59:33 --> Config Class Initialized
INFO - 2016-11-04 18:59:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:33 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:33 --> URI Class Initialized
INFO - 2016-11-04 18:59:33 --> Router Class Initialized
INFO - 2016-11-04 18:59:33 --> Output Class Initialized
INFO - 2016-11-04 18:59:33 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:33 --> Input Class Initialized
INFO - 2016-11-04 18:59:33 --> Language Class Initialized
INFO - 2016-11-04 18:59:33 --> Loader Class Initialized
INFO - 2016-11-04 18:59:33 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:33 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:33 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:33 --> Controller Class Initialized
INFO - 2016-11-04 18:59:33 --> Model Class Initialized
INFO - 2016-11-04 18:59:33 --> Model Class Initialized
DEBUG - 2016-11-04 18:59:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:59:33 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:59:33 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:59:33 --> Config Class Initialized
INFO - 2016-11-04 18:59:33 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:33 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:33 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:33 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:33 --> No URI present. Default controller set.
INFO - 2016-11-04 18:59:33 --> Router Class Initialized
INFO - 2016-11-04 18:59:33 --> Output Class Initialized
INFO - 2016-11-04 18:59:33 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:33 --> Input Class Initialized
INFO - 2016-11-04 18:59:33 --> Language Class Initialized
INFO - 2016-11-04 18:59:33 --> Loader Class Initialized
INFO - 2016-11-04 18:59:33 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:33 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:33 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:34 --> Controller Class Initialized
INFO - 2016-11-04 18:59:34 --> Model Class Initialized
INFO - 2016-11-04 18:59:34 --> Model Class Initialized
INFO - 2016-11-04 18:59:34 --> Config Class Initialized
INFO - 2016-11-04 18:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:59:34 --> Hooks Class Initialized
INFO - 2016-11-04 18:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
DEBUG - 2016-11-04 18:59:34 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:59:34 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:34 --> Final output sent to browser
INFO - 2016-11-04 18:59:34 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:34 --> Total execution time: 0.4508
INFO - 2016-11-04 18:59:34 --> Router Class Initialized
INFO - 2016-11-04 18:59:34 --> Output Class Initialized
INFO - 2016-11-04 18:59:34 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:34 --> Input Class Initialized
INFO - 2016-11-04 18:59:34 --> Language Class Initialized
INFO - 2016-11-04 18:59:34 --> Loader Class Initialized
INFO - 2016-11-04 18:59:34 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:34 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:34 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:34 --> Controller Class Initialized
INFO - 2016-11-04 18:59:34 --> Model Class Initialized
INFO - 2016-11-04 18:59:34 --> Model Class Initialized
DEBUG - 2016-11-04 18:59:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:59:34 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:59:34 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:59:34 --> Config Class Initialized
INFO - 2016-11-04 18:59:34 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:34 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:34 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:35 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:35 --> No URI present. Default controller set.
INFO - 2016-11-04 18:59:35 --> Router Class Initialized
INFO - 2016-11-04 18:59:35 --> Output Class Initialized
INFO - 2016-11-04 18:59:35 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:35 --> Input Class Initialized
INFO - 2016-11-04 18:59:35 --> Language Class Initialized
INFO - 2016-11-04 18:59:35 --> Loader Class Initialized
INFO - 2016-11-04 18:59:35 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:35 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:35 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:35 --> Controller Class Initialized
INFO - 2016-11-04 18:59:35 --> Model Class Initialized
INFO - 2016-11-04 18:59:35 --> Model Class Initialized
INFO - 2016-11-04 18:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:59:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:59:35 --> Final output sent to browser
DEBUG - 2016-11-04 18:59:35 --> Total execution time: 0.5366
INFO - 2016-11-04 18:59:44 --> Config Class Initialized
INFO - 2016-11-04 18:59:44 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:44 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:44 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:44 --> URI Class Initialized
INFO - 2016-11-04 18:59:44 --> Router Class Initialized
INFO - 2016-11-04 18:59:44 --> Output Class Initialized
INFO - 2016-11-04 18:59:44 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:44 --> Input Class Initialized
INFO - 2016-11-04 18:59:44 --> Language Class Initialized
INFO - 2016-11-04 18:59:44 --> Loader Class Initialized
INFO - 2016-11-04 18:59:44 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:44 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:44 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:44 --> Controller Class Initialized
INFO - 2016-11-04 18:59:44 --> Model Class Initialized
INFO - 2016-11-04 18:59:44 --> Model Class Initialized
DEBUG - 2016-11-04 18:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 18:59:44 --> Model Class Initialized
INFO - 2016-11-04 18:59:45 --> Final output sent to browser
DEBUG - 2016-11-04 18:59:45 --> Total execution time: 0.3960
INFO - 2016-11-04 18:59:45 --> Config Class Initialized
INFO - 2016-11-04 18:59:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:45 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:45 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:45 --> No URI present. Default controller set.
INFO - 2016-11-04 18:59:45 --> Router Class Initialized
INFO - 2016-11-04 18:59:45 --> Output Class Initialized
INFO - 2016-11-04 18:59:45 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:45 --> Input Class Initialized
INFO - 2016-11-04 18:59:45 --> Language Class Initialized
INFO - 2016-11-04 18:59:45 --> Loader Class Initialized
INFO - 2016-11-04 18:59:45 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:45 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:45 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:45 --> Controller Class Initialized
INFO - 2016-11-04 18:59:45 --> Model Class Initialized
INFO - 2016-11-04 18:59:45 --> Model Class Initialized
INFO - 2016-11-04 18:59:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 18:59:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:59:46 --> Final output sent to browser
DEBUG - 2016-11-04 18:59:46 --> Total execution time: 1.2397
INFO - 2016-11-04 18:59:57 --> Config Class Initialized
INFO - 2016-11-04 18:59:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:57 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:57 --> URI Class Initialized
INFO - 2016-11-04 18:59:57 --> Router Class Initialized
INFO - 2016-11-04 18:59:57 --> Output Class Initialized
INFO - 2016-11-04 18:59:57 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:57 --> Input Class Initialized
INFO - 2016-11-04 18:59:57 --> Language Class Initialized
INFO - 2016-11-04 18:59:57 --> Loader Class Initialized
INFO - 2016-11-04 18:59:57 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:57 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:57 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:57 --> Controller Class Initialized
INFO - 2016-11-04 18:59:57 --> Model Class Initialized
INFO - 2016-11-04 18:59:57 --> Model Class Initialized
DEBUG - 2016-11-04 18:59:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:59:57 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:59:57 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:59:57 --> Config Class Initialized
INFO - 2016-11-04 18:59:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:57 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:57 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:57 --> No URI present. Default controller set.
INFO - 2016-11-04 18:59:57 --> Router Class Initialized
INFO - 2016-11-04 18:59:57 --> Output Class Initialized
INFO - 2016-11-04 18:59:57 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:57 --> Input Class Initialized
INFO - 2016-11-04 18:59:57 --> Language Class Initialized
INFO - 2016-11-04 18:59:57 --> Loader Class Initialized
INFO - 2016-11-04 18:59:57 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:57 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:57 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:57 --> Controller Class Initialized
INFO - 2016-11-04 18:59:57 --> Model Class Initialized
INFO - 2016-11-04 18:59:57 --> Model Class Initialized
INFO - 2016-11-04 18:59:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:59:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:59:57 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:59:57 --> Final output sent to browser
INFO - 2016-11-04 18:59:57 --> Config Class Initialized
DEBUG - 2016-11-04 18:59:57 --> Total execution time: 0.4182
INFO - 2016-11-04 18:59:57 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:57 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:57 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:57 --> URI Class Initialized
INFO - 2016-11-04 18:59:57 --> Router Class Initialized
INFO - 2016-11-04 18:59:57 --> Output Class Initialized
INFO - 2016-11-04 18:59:57 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:58 --> Input Class Initialized
INFO - 2016-11-04 18:59:58 --> Language Class Initialized
INFO - 2016-11-04 18:59:58 --> Loader Class Initialized
INFO - 2016-11-04 18:59:58 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:58 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:58 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:58 --> Controller Class Initialized
INFO - 2016-11-04 18:59:58 --> Model Class Initialized
INFO - 2016-11-04 18:59:58 --> Model Class Initialized
DEBUG - 2016-11-04 18:59:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 18:59:58 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 18:59:58 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 18:59:58 --> Config Class Initialized
INFO - 2016-11-04 18:59:58 --> Hooks Class Initialized
DEBUG - 2016-11-04 18:59:58 --> UTF-8 Support Enabled
INFO - 2016-11-04 18:59:58 --> Utf8 Class Initialized
INFO - 2016-11-04 18:59:58 --> URI Class Initialized
DEBUG - 2016-11-04 18:59:58 --> No URI present. Default controller set.
INFO - 2016-11-04 18:59:58 --> Router Class Initialized
INFO - 2016-11-04 18:59:58 --> Output Class Initialized
INFO - 2016-11-04 18:59:58 --> Security Class Initialized
DEBUG - 2016-11-04 18:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 18:59:58 --> Input Class Initialized
INFO - 2016-11-04 18:59:58 --> Language Class Initialized
INFO - 2016-11-04 18:59:58 --> Loader Class Initialized
INFO - 2016-11-04 18:59:58 --> Helper loaded: url_helper
INFO - 2016-11-04 18:59:58 --> Helper loaded: form_helper
INFO - 2016-11-04 18:59:58 --> Database Driver Class Initialized
INFO - 2016-11-04 18:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 18:59:58 --> Controller Class Initialized
INFO - 2016-11-04 18:59:58 --> Model Class Initialized
INFO - 2016-11-04 18:59:58 --> Model Class Initialized
INFO - 2016-11-04 18:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 18:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 18:59:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 18:59:58 --> Final output sent to browser
DEBUG - 2016-11-04 18:59:58 --> Total execution time: 0.4216
INFO - 2016-11-04 19:00:06 --> Config Class Initialized
INFO - 2016-11-04 19:00:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 19:00:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 19:00:06 --> Utf8 Class Initialized
INFO - 2016-11-04 19:00:06 --> URI Class Initialized
INFO - 2016-11-04 19:00:06 --> Router Class Initialized
INFO - 2016-11-04 19:00:06 --> Output Class Initialized
INFO - 2016-11-04 19:00:06 --> Security Class Initialized
DEBUG - 2016-11-04 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 19:00:06 --> Input Class Initialized
INFO - 2016-11-04 19:00:06 --> Language Class Initialized
INFO - 2016-11-04 19:00:06 --> Loader Class Initialized
INFO - 2016-11-04 19:00:06 --> Helper loaded: url_helper
INFO - 2016-11-04 19:00:06 --> Helper loaded: form_helper
INFO - 2016-11-04 19:00:06 --> Database Driver Class Initialized
INFO - 2016-11-04 19:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 19:00:06 --> Controller Class Initialized
INFO - 2016-11-04 19:00:07 --> Model Class Initialized
INFO - 2016-11-04 19:00:07 --> Model Class Initialized
DEBUG - 2016-11-04 19:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 19:00:07 --> Model Class Initialized
INFO - 2016-11-04 19:00:07 --> Final output sent to browser
DEBUG - 2016-11-04 19:00:07 --> Total execution time: 0.3853
INFO - 2016-11-04 21:51:21 --> Config Class Initialized
INFO - 2016-11-04 21:51:21 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:51:21 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:51:21 --> Utf8 Class Initialized
INFO - 2016-11-04 21:51:21 --> URI Class Initialized
INFO - 2016-11-04 21:51:21 --> Router Class Initialized
INFO - 2016-11-04 21:51:21 --> Output Class Initialized
INFO - 2016-11-04 21:51:21 --> Security Class Initialized
DEBUG - 2016-11-04 21:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:51:22 --> Input Class Initialized
INFO - 2016-11-04 21:51:22 --> Language Class Initialized
INFO - 2016-11-04 21:51:22 --> Loader Class Initialized
INFO - 2016-11-04 21:51:22 --> Helper loaded: url_helper
INFO - 2016-11-04 21:51:22 --> Helper loaded: form_helper
INFO - 2016-11-04 21:51:22 --> Database Driver Class Initialized
INFO - 2016-11-04 21:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:51:22 --> Controller Class Initialized
INFO - 2016-11-04 21:51:22 --> Model Class Initialized
INFO - 2016-11-04 21:51:22 --> Model Class Initialized
DEBUG - 2016-11-04 21:51:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 21:51:23 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 21:51:23 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 21:51:23 --> Config Class Initialized
INFO - 2016-11-04 21:51:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:51:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:51:23 --> Utf8 Class Initialized
INFO - 2016-11-04 21:51:23 --> URI Class Initialized
DEBUG - 2016-11-04 21:51:23 --> No URI present. Default controller set.
INFO - 2016-11-04 21:51:23 --> Router Class Initialized
INFO - 2016-11-04 21:51:23 --> Output Class Initialized
INFO - 2016-11-04 21:51:23 --> Security Class Initialized
DEBUG - 2016-11-04 21:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:51:23 --> Input Class Initialized
INFO - 2016-11-04 21:51:23 --> Language Class Initialized
INFO - 2016-11-04 21:51:23 --> Loader Class Initialized
INFO - 2016-11-04 21:51:23 --> Helper loaded: url_helper
INFO - 2016-11-04 21:51:23 --> Helper loaded: form_helper
INFO - 2016-11-04 21:51:23 --> Database Driver Class Initialized
INFO - 2016-11-04 21:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:51:23 --> Controller Class Initialized
INFO - 2016-11-04 21:51:23 --> Model Class Initialized
INFO - 2016-11-04 21:51:23 --> Model Class Initialized
INFO - 2016-11-04 21:51:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 21:51:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:51:24 --> Final output sent to browser
DEBUG - 2016-11-04 21:51:24 --> Total execution time: 0.9665
INFO - 2016-11-04 21:51:45 --> Config Class Initialized
INFO - 2016-11-04 21:51:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:51:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:51:45 --> Utf8 Class Initialized
INFO - 2016-11-04 21:51:45 --> URI Class Initialized
INFO - 2016-11-04 21:51:45 --> Router Class Initialized
INFO - 2016-11-04 21:51:45 --> Output Class Initialized
INFO - 2016-11-04 21:51:45 --> Security Class Initialized
DEBUG - 2016-11-04 21:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:51:45 --> Input Class Initialized
INFO - 2016-11-04 21:51:45 --> Language Class Initialized
INFO - 2016-11-04 21:51:45 --> Loader Class Initialized
INFO - 2016-11-04 21:51:45 --> Helper loaded: url_helper
INFO - 2016-11-04 21:51:45 --> Helper loaded: form_helper
INFO - 2016-11-04 21:51:45 --> Database Driver Class Initialized
INFO - 2016-11-04 21:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:51:45 --> Controller Class Initialized
INFO - 2016-11-04 21:51:45 --> Model Class Initialized
INFO - 2016-11-04 21:51:45 --> Model Class Initialized
DEBUG - 2016-11-04 21:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 21:51:45 --> Model Class Initialized
INFO - 2016-11-04 21:51:46 --> Final output sent to browser
DEBUG - 2016-11-04 21:51:46 --> Total execution time: 0.8188
INFO - 2016-11-04 21:51:46 --> Config Class Initialized
INFO - 2016-11-04 21:51:46 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:51:46 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:51:46 --> Utf8 Class Initialized
INFO - 2016-11-04 21:51:46 --> URI Class Initialized
DEBUG - 2016-11-04 21:51:46 --> No URI present. Default controller set.
INFO - 2016-11-04 21:51:46 --> Router Class Initialized
INFO - 2016-11-04 21:51:46 --> Output Class Initialized
INFO - 2016-11-04 21:51:46 --> Security Class Initialized
DEBUG - 2016-11-04 21:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:51:46 --> Input Class Initialized
INFO - 2016-11-04 21:51:46 --> Language Class Initialized
INFO - 2016-11-04 21:51:46 --> Loader Class Initialized
INFO - 2016-11-04 21:51:46 --> Helper loaded: url_helper
INFO - 2016-11-04 21:51:46 --> Helper loaded: form_helper
INFO - 2016-11-04 21:51:46 --> Database Driver Class Initialized
INFO - 2016-11-04 21:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:51:46 --> Controller Class Initialized
INFO - 2016-11-04 21:51:46 --> Model Class Initialized
INFO - 2016-11-04 21:51:46 --> Model Class Initialized
INFO - 2016-11-04 21:51:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:51:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 21:51:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 21:51:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 21:51:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 21:51:46 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 21:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 21:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 21:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 21:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 21:51:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:51:47 --> Final output sent to browser
DEBUG - 2016-11-04 21:51:47 --> Total execution time: 0.9833
INFO - 2016-11-04 21:52:06 --> Config Class Initialized
INFO - 2016-11-04 21:52:06 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:52:06 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:52:06 --> Utf8 Class Initialized
INFO - 2016-11-04 21:52:07 --> URI Class Initialized
DEBUG - 2016-11-04 21:52:07 --> No URI present. Default controller set.
INFO - 2016-11-04 21:52:07 --> Router Class Initialized
INFO - 2016-11-04 21:52:07 --> Output Class Initialized
INFO - 2016-11-04 21:52:07 --> Security Class Initialized
DEBUG - 2016-11-04 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:52:07 --> Input Class Initialized
INFO - 2016-11-04 21:52:07 --> Language Class Initialized
INFO - 2016-11-04 21:52:07 --> Loader Class Initialized
INFO - 2016-11-04 21:52:07 --> Helper loaded: url_helper
INFO - 2016-11-04 21:52:07 --> Helper loaded: form_helper
INFO - 2016-11-04 21:52:07 --> Database Driver Class Initialized
INFO - 2016-11-04 21:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:52:07 --> Controller Class Initialized
INFO - 2016-11-04 21:52:07 --> Model Class Initialized
INFO - 2016-11-04 21:52:07 --> Model Class Initialized
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 21:52:07 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:52:07 --> Final output sent to browser
DEBUG - 2016-11-04 21:52:07 --> Total execution time: 0.6789
INFO - 2016-11-04 21:52:37 --> Config Class Initialized
INFO - 2016-11-04 21:52:37 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:52:37 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:52:37 --> Utf8 Class Initialized
INFO - 2016-11-04 21:52:37 --> URI Class Initialized
DEBUG - 2016-11-04 21:52:37 --> No URI present. Default controller set.
INFO - 2016-11-04 21:52:37 --> Router Class Initialized
INFO - 2016-11-04 21:52:37 --> Output Class Initialized
INFO - 2016-11-04 21:52:37 --> Security Class Initialized
DEBUG - 2016-11-04 21:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:52:37 --> Input Class Initialized
INFO - 2016-11-04 21:52:37 --> Language Class Initialized
INFO - 2016-11-04 21:52:37 --> Loader Class Initialized
INFO - 2016-11-04 21:52:37 --> Helper loaded: url_helper
INFO - 2016-11-04 21:52:37 --> Helper loaded: form_helper
INFO - 2016-11-04 21:52:37 --> Database Driver Class Initialized
INFO - 2016-11-04 21:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:52:37 --> Controller Class Initialized
INFO - 2016-11-04 21:52:37 --> Model Class Initialized
INFO - 2016-11-04 21:52:37 --> Model Class Initialized
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 21:52:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:52:37 --> Final output sent to browser
DEBUG - 2016-11-04 21:52:38 --> Total execution time: 0.6781
INFO - 2016-11-04 21:54:40 --> Config Class Initialized
INFO - 2016-11-04 21:54:40 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:54:40 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:54:40 --> Utf8 Class Initialized
INFO - 2016-11-04 21:54:41 --> URI Class Initialized
INFO - 2016-11-04 21:54:41 --> Router Class Initialized
INFO - 2016-11-04 21:54:41 --> Output Class Initialized
INFO - 2016-11-04 21:54:41 --> Security Class Initialized
DEBUG - 2016-11-04 21:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:54:41 --> Input Class Initialized
INFO - 2016-11-04 21:54:41 --> Language Class Initialized
INFO - 2016-11-04 21:54:41 --> Loader Class Initialized
INFO - 2016-11-04 21:54:41 --> Helper loaded: url_helper
INFO - 2016-11-04 21:54:41 --> Helper loaded: form_helper
INFO - 2016-11-04 21:54:41 --> Database Driver Class Initialized
INFO - 2016-11-04 21:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:54:41 --> Controller Class Initialized
INFO - 2016-11-04 21:54:41 --> Model Class Initialized
INFO - 2016-11-04 21:54:41 --> Form Validation Class Initialized
INFO - 2016-11-04 21:54:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 21:54:41 --> Final output sent to browser
DEBUG - 2016-11-04 21:54:41 --> Total execution time: 0.4675
INFO - 2016-11-04 21:54:47 --> Config Class Initialized
INFO - 2016-11-04 21:54:47 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:54:47 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:54:47 --> Utf8 Class Initialized
INFO - 2016-11-04 21:54:47 --> URI Class Initialized
INFO - 2016-11-04 21:54:47 --> Router Class Initialized
INFO - 2016-11-04 21:54:47 --> Output Class Initialized
INFO - 2016-11-04 21:54:47 --> Security Class Initialized
DEBUG - 2016-11-04 21:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:54:47 --> Input Class Initialized
INFO - 2016-11-04 21:54:47 --> Language Class Initialized
INFO - 2016-11-04 21:54:47 --> Loader Class Initialized
INFO - 2016-11-04 21:54:47 --> Helper loaded: url_helper
INFO - 2016-11-04 21:54:47 --> Helper loaded: form_helper
INFO - 2016-11-04 21:54:47 --> Database Driver Class Initialized
INFO - 2016-11-04 21:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:54:47 --> Controller Class Initialized
INFO - 2016-11-04 21:54:48 --> Model Class Initialized
INFO - 2016-11-04 21:54:48 --> Model Class Initialized
DEBUG - 2016-11-04 21:54:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 21:54:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 21:54:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 21:54:48 --> Config Class Initialized
INFO - 2016-11-04 21:54:48 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:54:48 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:54:48 --> Utf8 Class Initialized
INFO - 2016-11-04 21:54:48 --> URI Class Initialized
DEBUG - 2016-11-04 21:54:48 --> No URI present. Default controller set.
INFO - 2016-11-04 21:54:48 --> Router Class Initialized
INFO - 2016-11-04 21:54:48 --> Output Class Initialized
INFO - 2016-11-04 21:54:48 --> Security Class Initialized
DEBUG - 2016-11-04 21:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:54:48 --> Input Class Initialized
INFO - 2016-11-04 21:54:48 --> Language Class Initialized
INFO - 2016-11-04 21:54:48 --> Loader Class Initialized
INFO - 2016-11-04 21:54:48 --> Helper loaded: url_helper
INFO - 2016-11-04 21:54:48 --> Helper loaded: form_helper
INFO - 2016-11-04 21:54:48 --> Database Driver Class Initialized
INFO - 2016-11-04 21:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:54:48 --> Controller Class Initialized
INFO - 2016-11-04 21:54:48 --> Model Class Initialized
INFO - 2016-11-04 21:54:48 --> Model Class Initialized
INFO - 2016-11-04 21:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 21:54:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:54:48 --> Final output sent to browser
DEBUG - 2016-11-04 21:54:48 --> Total execution time: 0.4672
INFO - 2016-11-04 21:55:01 --> Config Class Initialized
INFO - 2016-11-04 21:55:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:55:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:55:01 --> Utf8 Class Initialized
INFO - 2016-11-04 21:55:01 --> URI Class Initialized
INFO - 2016-11-04 21:55:01 --> Router Class Initialized
INFO - 2016-11-04 21:55:01 --> Output Class Initialized
INFO - 2016-11-04 21:55:01 --> Security Class Initialized
DEBUG - 2016-11-04 21:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:55:01 --> Input Class Initialized
INFO - 2016-11-04 21:55:01 --> Language Class Initialized
INFO - 2016-11-04 21:55:01 --> Loader Class Initialized
INFO - 2016-11-04 21:55:01 --> Helper loaded: url_helper
INFO - 2016-11-04 21:55:01 --> Helper loaded: form_helper
INFO - 2016-11-04 21:55:01 --> Database Driver Class Initialized
INFO - 2016-11-04 21:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:55:01 --> Controller Class Initialized
INFO - 2016-11-04 21:55:01 --> Model Class Initialized
INFO - 2016-11-04 21:55:01 --> Model Class Initialized
DEBUG - 2016-11-04 21:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 21:55:02 --> Model Class Initialized
INFO - 2016-11-04 21:55:02 --> Final output sent to browser
DEBUG - 2016-11-04 21:55:02 --> Total execution time: 0.4034
INFO - 2016-11-04 21:55:02 --> Config Class Initialized
INFO - 2016-11-04 21:55:02 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:55:02 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:55:02 --> Utf8 Class Initialized
INFO - 2016-11-04 21:55:02 --> URI Class Initialized
DEBUG - 2016-11-04 21:55:02 --> No URI present. Default controller set.
INFO - 2016-11-04 21:55:02 --> Router Class Initialized
INFO - 2016-11-04 21:55:02 --> Output Class Initialized
INFO - 2016-11-04 21:55:02 --> Security Class Initialized
DEBUG - 2016-11-04 21:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:55:02 --> Input Class Initialized
INFO - 2016-11-04 21:55:02 --> Language Class Initialized
INFO - 2016-11-04 21:55:02 --> Loader Class Initialized
INFO - 2016-11-04 21:55:02 --> Helper loaded: url_helper
INFO - 2016-11-04 21:55:02 --> Helper loaded: form_helper
INFO - 2016-11-04 21:55:02 --> Database Driver Class Initialized
INFO - 2016-11-04 21:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:55:02 --> Controller Class Initialized
INFO - 2016-11-04 21:55:02 --> Model Class Initialized
INFO - 2016-11-04 21:55:02 --> Model Class Initialized
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 21:55:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:55:02 --> Final output sent to browser
DEBUG - 2016-11-04 21:55:02 --> Total execution time: 0.5983
INFO - 2016-11-04 21:57:01 --> Config Class Initialized
INFO - 2016-11-04 21:57:01 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:57:01 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:57:01 --> Utf8 Class Initialized
INFO - 2016-11-04 21:57:01 --> URI Class Initialized
INFO - 2016-11-04 21:57:01 --> Router Class Initialized
INFO - 2016-11-04 21:57:01 --> Output Class Initialized
INFO - 2016-11-04 21:57:01 --> Security Class Initialized
DEBUG - 2016-11-04 21:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:57:01 --> Input Class Initialized
INFO - 2016-11-04 21:57:01 --> Language Class Initialized
INFO - 2016-11-04 21:57:01 --> Loader Class Initialized
INFO - 2016-11-04 21:57:01 --> Helper loaded: url_helper
INFO - 2016-11-04 21:57:01 --> Helper loaded: form_helper
INFO - 2016-11-04 21:57:01 --> Database Driver Class Initialized
INFO - 2016-11-04 21:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:57:01 --> Controller Class Initialized
INFO - 2016-11-04 21:57:02 --> Form Validation Class Initialized
INFO - 2016-11-04 21:57:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 21:57:02 --> Final output sent to browser
DEBUG - 2016-11-04 21:57:02 --> Total execution time: 0.3770
INFO - 2016-11-04 21:57:16 --> Config Class Initialized
INFO - 2016-11-04 21:57:16 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:57:16 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:57:16 --> Utf8 Class Initialized
INFO - 2016-11-04 21:57:16 --> URI Class Initialized
INFO - 2016-11-04 21:57:16 --> Router Class Initialized
INFO - 2016-11-04 21:57:16 --> Output Class Initialized
INFO - 2016-11-04 21:57:16 --> Security Class Initialized
DEBUG - 2016-11-04 21:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:57:16 --> Input Class Initialized
INFO - 2016-11-04 21:57:16 --> Language Class Initialized
INFO - 2016-11-04 21:57:17 --> Loader Class Initialized
INFO - 2016-11-04 21:57:17 --> Helper loaded: url_helper
INFO - 2016-11-04 21:57:17 --> Helper loaded: form_helper
INFO - 2016-11-04 21:57:17 --> Database Driver Class Initialized
INFO - 2016-11-04 21:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:57:17 --> Controller Class Initialized
INFO - 2016-11-04 21:57:17 --> Model Class Initialized
INFO - 2016-11-04 21:57:17 --> Form Validation Class Initialized
INFO - 2016-11-04 21:57:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 21:57:17 --> Final output sent to browser
DEBUG - 2016-11-04 21:57:17 --> Total execution time: 0.3893
INFO - 2016-11-04 21:57:23 --> Config Class Initialized
INFO - 2016-11-04 21:57:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:57:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:57:23 --> Utf8 Class Initialized
INFO - 2016-11-04 21:57:23 --> URI Class Initialized
INFO - 2016-11-04 21:57:23 --> Router Class Initialized
INFO - 2016-11-04 21:57:23 --> Output Class Initialized
INFO - 2016-11-04 21:57:23 --> Security Class Initialized
DEBUG - 2016-11-04 21:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:57:23 --> Input Class Initialized
INFO - 2016-11-04 21:57:23 --> Language Class Initialized
INFO - 2016-11-04 21:57:23 --> Loader Class Initialized
INFO - 2016-11-04 21:57:23 --> Helper loaded: url_helper
INFO - 2016-11-04 21:57:23 --> Helper loaded: form_helper
INFO - 2016-11-04 21:57:23 --> Database Driver Class Initialized
INFO - 2016-11-04 21:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:57:23 --> Controller Class Initialized
INFO - 2016-11-04 21:57:23 --> Model Class Initialized
INFO - 2016-11-04 21:57:23 --> Model Class Initialized
DEBUG - 2016-11-04 21:57:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 21:57:23 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 21:57:23 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 21:57:23 --> Config Class Initialized
INFO - 2016-11-04 21:57:23 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:57:23 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:57:23 --> Utf8 Class Initialized
INFO - 2016-11-04 21:57:23 --> URI Class Initialized
DEBUG - 2016-11-04 21:57:23 --> No URI present. Default controller set.
INFO - 2016-11-04 21:57:23 --> Router Class Initialized
INFO - 2016-11-04 21:57:23 --> Output Class Initialized
INFO - 2016-11-04 21:57:23 --> Security Class Initialized
DEBUG - 2016-11-04 21:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:57:23 --> Input Class Initialized
INFO - 2016-11-04 21:57:23 --> Language Class Initialized
INFO - 2016-11-04 21:57:23 --> Loader Class Initialized
INFO - 2016-11-04 21:57:23 --> Helper loaded: url_helper
INFO - 2016-11-04 21:57:23 --> Helper loaded: form_helper
INFO - 2016-11-04 21:57:24 --> Database Driver Class Initialized
INFO - 2016-11-04 21:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:57:24 --> Controller Class Initialized
INFO - 2016-11-04 21:57:24 --> Model Class Initialized
INFO - 2016-11-04 21:57:24 --> Model Class Initialized
INFO - 2016-11-04 21:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 21:57:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:57:24 --> Final output sent to browser
DEBUG - 2016-11-04 21:57:24 --> Total execution time: 0.4488
INFO - 2016-11-04 21:57:36 --> Config Class Initialized
INFO - 2016-11-04 21:57:36 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:57:36 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:57:36 --> Utf8 Class Initialized
INFO - 2016-11-04 21:57:36 --> URI Class Initialized
INFO - 2016-11-04 21:57:36 --> Router Class Initialized
INFO - 2016-11-04 21:57:36 --> Output Class Initialized
INFO - 2016-11-04 21:57:36 --> Security Class Initialized
DEBUG - 2016-11-04 21:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:57:36 --> Input Class Initialized
INFO - 2016-11-04 21:57:36 --> Language Class Initialized
INFO - 2016-11-04 21:57:36 --> Loader Class Initialized
INFO - 2016-11-04 21:57:36 --> Helper loaded: url_helper
INFO - 2016-11-04 21:57:36 --> Helper loaded: form_helper
INFO - 2016-11-04 21:57:36 --> Database Driver Class Initialized
INFO - 2016-11-04 21:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:57:36 --> Controller Class Initialized
INFO - 2016-11-04 21:57:36 --> Model Class Initialized
INFO - 2016-11-04 21:57:36 --> Model Class Initialized
DEBUG - 2016-11-04 21:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-04 21:57:36 --> Model Class Initialized
INFO - 2016-11-04 21:57:36 --> Final output sent to browser
DEBUG - 2016-11-04 21:57:36 --> Total execution time: 0.4328
INFO - 2016-11-04 21:57:36 --> Config Class Initialized
INFO - 2016-11-04 21:57:36 --> Hooks Class Initialized
DEBUG - 2016-11-04 21:57:36 --> UTF-8 Support Enabled
INFO - 2016-11-04 21:57:36 --> Utf8 Class Initialized
INFO - 2016-11-04 21:57:36 --> URI Class Initialized
DEBUG - 2016-11-04 21:57:36 --> No URI present. Default controller set.
INFO - 2016-11-04 21:57:36 --> Router Class Initialized
INFO - 2016-11-04 21:57:36 --> Output Class Initialized
INFO - 2016-11-04 21:57:36 --> Security Class Initialized
DEBUG - 2016-11-04 21:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 21:57:36 --> Input Class Initialized
INFO - 2016-11-04 21:57:36 --> Language Class Initialized
INFO - 2016-11-04 21:57:36 --> Loader Class Initialized
INFO - 2016-11-04 21:57:36 --> Helper loaded: url_helper
INFO - 2016-11-04 21:57:36 --> Helper loaded: form_helper
INFO - 2016-11-04 21:57:36 --> Database Driver Class Initialized
INFO - 2016-11-04 21:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 21:57:36 --> Controller Class Initialized
INFO - 2016-11-04 21:57:36 --> Model Class Initialized
INFO - 2016-11-04 21:57:36 --> Model Class Initialized
INFO - 2016-11-04 21:57:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 21:57:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-04 21:57:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-04 21:57:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 21:57:37 --> Final output sent to browser
DEBUG - 2016-11-04 21:57:37 --> Total execution time: 0.6463
INFO - 2016-11-04 22:23:11 --> Config Class Initialized
INFO - 2016-11-04 22:23:11 --> Hooks Class Initialized
DEBUG - 2016-11-04 22:23:11 --> UTF-8 Support Enabled
INFO - 2016-11-04 22:23:11 --> Utf8 Class Initialized
INFO - 2016-11-04 22:23:11 --> URI Class Initialized
INFO - 2016-11-04 22:23:11 --> Router Class Initialized
INFO - 2016-11-04 22:23:11 --> Output Class Initialized
INFO - 2016-11-04 22:23:11 --> Security Class Initialized
DEBUG - 2016-11-04 22:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 22:23:11 --> Input Class Initialized
INFO - 2016-11-04 22:23:11 --> Language Class Initialized
INFO - 2016-11-04 22:23:11 --> Loader Class Initialized
INFO - 2016-11-04 22:23:11 --> Helper loaded: url_helper
INFO - 2016-11-04 22:23:11 --> Helper loaded: form_helper
INFO - 2016-11-04 22:23:11 --> Database Driver Class Initialized
INFO - 2016-11-04 22:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 22:23:11 --> Controller Class Initialized
INFO - 2016-11-04 22:23:11 --> Model Class Initialized
INFO - 2016-11-04 22:23:11 --> Form Validation Class Initialized
INFO - 2016-11-04 22:23:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-04 22:23:11 --> Final output sent to browser
DEBUG - 2016-11-04 22:23:11 --> Total execution time: 0.4000
INFO - 2016-11-04 22:23:44 --> Config Class Initialized
INFO - 2016-11-04 22:23:44 --> Hooks Class Initialized
DEBUG - 2016-11-04 22:23:44 --> UTF-8 Support Enabled
INFO - 2016-11-04 22:23:44 --> Utf8 Class Initialized
INFO - 2016-11-04 22:23:44 --> URI Class Initialized
INFO - 2016-11-04 22:23:44 --> Router Class Initialized
INFO - 2016-11-04 22:23:44 --> Output Class Initialized
INFO - 2016-11-04 22:23:44 --> Security Class Initialized
DEBUG - 2016-11-04 22:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 22:23:44 --> Input Class Initialized
INFO - 2016-11-04 22:23:44 --> Language Class Initialized
INFO - 2016-11-04 22:23:44 --> Loader Class Initialized
INFO - 2016-11-04 22:23:44 --> Helper loaded: url_helper
INFO - 2016-11-04 22:23:44 --> Helper loaded: form_helper
INFO - 2016-11-04 22:23:44 --> Database Driver Class Initialized
INFO - 2016-11-04 22:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 22:23:44 --> Controller Class Initialized
INFO - 2016-11-04 22:23:44 --> Model Class Initialized
INFO - 2016-11-04 22:23:44 --> Model Class Initialized
DEBUG - 2016-11-04 22:23:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-04 22:23:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
ERROR - 2016-11-04 22:23:44 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 117
INFO - 2016-11-04 22:23:44 --> Config Class Initialized
INFO - 2016-11-04 22:23:45 --> Hooks Class Initialized
DEBUG - 2016-11-04 22:23:45 --> UTF-8 Support Enabled
INFO - 2016-11-04 22:23:45 --> Utf8 Class Initialized
INFO - 2016-11-04 22:23:45 --> URI Class Initialized
DEBUG - 2016-11-04 22:23:45 --> No URI present. Default controller set.
INFO - 2016-11-04 22:23:45 --> Router Class Initialized
INFO - 2016-11-04 22:23:45 --> Output Class Initialized
INFO - 2016-11-04 22:23:45 --> Security Class Initialized
DEBUG - 2016-11-04 22:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-04 22:23:45 --> Input Class Initialized
INFO - 2016-11-04 22:23:45 --> Language Class Initialized
INFO - 2016-11-04 22:23:45 --> Loader Class Initialized
INFO - 2016-11-04 22:23:45 --> Helper loaded: url_helper
INFO - 2016-11-04 22:23:45 --> Helper loaded: form_helper
INFO - 2016-11-04 22:23:45 --> Database Driver Class Initialized
INFO - 2016-11-04 22:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-04 22:23:45 --> Controller Class Initialized
INFO - 2016-11-04 22:23:45 --> Model Class Initialized
INFO - 2016-11-04 22:23:45 --> Model Class Initialized
INFO - 2016-11-04 22:23:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-04 22:23:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-04 22:23:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-04 22:23:45 --> Final output sent to browser
DEBUG - 2016-11-04 22:23:45 --> Total execution time: 0.4311
