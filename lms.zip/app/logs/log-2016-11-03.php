<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-03 09:38:22 --> Config Class Initialized
INFO - 2016-11-03 09:38:22 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:38:22 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:38:22 --> Utf8 Class Initialized
INFO - 2016-11-03 09:38:22 --> URI Class Initialized
DEBUG - 2016-11-03 09:38:22 --> No URI present. Default controller set.
INFO - 2016-11-03 09:38:22 --> Router Class Initialized
INFO - 2016-11-03 09:38:22 --> Output Class Initialized
INFO - 2016-11-03 09:38:22 --> Security Class Initialized
DEBUG - 2016-11-03 09:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:38:22 --> Input Class Initialized
INFO - 2016-11-03 09:38:22 --> Language Class Initialized
INFO - 2016-11-03 09:38:22 --> Loader Class Initialized
INFO - 2016-11-03 09:38:22 --> Helper loaded: url_helper
INFO - 2016-11-03 09:38:22 --> Helper loaded: form_helper
INFO - 2016-11-03 09:38:22 --> Database Driver Class Initialized
INFO - 2016-11-03 09:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:38:22 --> Controller Class Initialized
INFO - 2016-11-03 09:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 09:38:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:38:22 --> Final output sent to browser
DEBUG - 2016-11-03 09:38:22 --> Total execution time: 0.0944
INFO - 2016-11-03 09:38:30 --> Config Class Initialized
INFO - 2016-11-03 09:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:38:30 --> Utf8 Class Initialized
INFO - 2016-11-03 09:38:30 --> URI Class Initialized
INFO - 2016-11-03 09:38:30 --> Router Class Initialized
INFO - 2016-11-03 09:38:30 --> Output Class Initialized
INFO - 2016-11-03 09:38:30 --> Security Class Initialized
DEBUG - 2016-11-03 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:38:30 --> Input Class Initialized
INFO - 2016-11-03 09:38:30 --> Language Class Initialized
INFO - 2016-11-03 09:38:30 --> Loader Class Initialized
INFO - 2016-11-03 09:38:30 --> Helper loaded: url_helper
INFO - 2016-11-03 09:38:30 --> Helper loaded: form_helper
INFO - 2016-11-03 09:38:30 --> Database Driver Class Initialized
INFO - 2016-11-03 09:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:38:30 --> Controller Class Initialized
DEBUG - 2016-11-03 09:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 09:38:30 --> Model Class Initialized
INFO - 2016-11-03 09:38:30 --> Final output sent to browser
DEBUG - 2016-11-03 09:38:30 --> Total execution time: 0.0185
INFO - 2016-11-03 09:38:30 --> Config Class Initialized
INFO - 2016-11-03 09:38:30 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:38:30 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:38:30 --> Utf8 Class Initialized
INFO - 2016-11-03 09:38:30 --> URI Class Initialized
DEBUG - 2016-11-03 09:38:30 --> No URI present. Default controller set.
INFO - 2016-11-03 09:38:30 --> Router Class Initialized
INFO - 2016-11-03 09:38:30 --> Output Class Initialized
INFO - 2016-11-03 09:38:30 --> Security Class Initialized
DEBUG - 2016-11-03 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:38:30 --> Input Class Initialized
INFO - 2016-11-03 09:38:30 --> Language Class Initialized
INFO - 2016-11-03 09:38:30 --> Loader Class Initialized
INFO - 2016-11-03 09:38:30 --> Helper loaded: url_helper
INFO - 2016-11-03 09:38:30 --> Helper loaded: form_helper
INFO - 2016-11-03 09:38:30 --> Database Driver Class Initialized
INFO - 2016-11-03 09:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:38:30 --> Controller Class Initialized
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:38:30 --> Model Class Initialized
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:38:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:38:30 --> Final output sent to browser
DEBUG - 2016-11-03 09:38:30 --> Total execution time: 0.0602
INFO - 2016-11-03 09:38:43 --> Config Class Initialized
INFO - 2016-11-03 09:38:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:38:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:38:43 --> Utf8 Class Initialized
INFO - 2016-11-03 09:38:43 --> URI Class Initialized
INFO - 2016-11-03 09:38:43 --> Router Class Initialized
INFO - 2016-11-03 09:38:43 --> Output Class Initialized
INFO - 2016-11-03 09:38:43 --> Security Class Initialized
DEBUG - 2016-11-03 09:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:38:43 --> Input Class Initialized
INFO - 2016-11-03 09:38:43 --> Language Class Initialized
INFO - 2016-11-03 09:38:43 --> Loader Class Initialized
INFO - 2016-11-03 09:38:43 --> Helper loaded: url_helper
INFO - 2016-11-03 09:38:43 --> Helper loaded: form_helper
INFO - 2016-11-03 09:38:43 --> Database Driver Class Initialized
INFO - 2016-11-03 09:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:38:43 --> Controller Class Initialized
INFO - 2016-11-03 09:38:43 --> Model Class Initialized
INFO - 2016-11-03 09:38:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:38:43 --> Final output sent to browser
DEBUG - 2016-11-03 09:38:43 --> Total execution time: 0.0392
INFO - 2016-11-03 09:38:47 --> Config Class Initialized
INFO - 2016-11-03 09:38:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:38:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:38:47 --> Utf8 Class Initialized
INFO - 2016-11-03 09:38:47 --> URI Class Initialized
INFO - 2016-11-03 09:38:47 --> Router Class Initialized
INFO - 2016-11-03 09:38:47 --> Output Class Initialized
INFO - 2016-11-03 09:38:47 --> Security Class Initialized
DEBUG - 2016-11-03 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:38:47 --> Input Class Initialized
INFO - 2016-11-03 09:38:47 --> Language Class Initialized
INFO - 2016-11-03 09:38:47 --> Loader Class Initialized
INFO - 2016-11-03 09:38:47 --> Helper loaded: url_helper
INFO - 2016-11-03 09:38:47 --> Helper loaded: form_helper
INFO - 2016-11-03 09:38:47 --> Database Driver Class Initialized
INFO - 2016-11-03 09:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:38:47 --> Controller Class Initialized
INFO - 2016-11-03 09:38:47 --> Form Validation Class Initialized
INFO - 2016-11-03 09:38:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 09:38:47 --> Final output sent to browser
DEBUG - 2016-11-03 09:38:47 --> Total execution time: 0.0305
INFO - 2016-11-03 09:39:14 --> Config Class Initialized
INFO - 2016-11-03 09:39:14 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:39:14 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:39:14 --> Utf8 Class Initialized
INFO - 2016-11-03 09:39:14 --> URI Class Initialized
INFO - 2016-11-03 09:39:14 --> Router Class Initialized
INFO - 2016-11-03 09:39:14 --> Output Class Initialized
INFO - 2016-11-03 09:39:14 --> Security Class Initialized
DEBUG - 2016-11-03 09:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:39:14 --> Input Class Initialized
INFO - 2016-11-03 09:39:14 --> Language Class Initialized
INFO - 2016-11-03 09:39:14 --> Loader Class Initialized
INFO - 2016-11-03 09:39:14 --> Helper loaded: url_helper
INFO - 2016-11-03 09:39:14 --> Helper loaded: form_helper
INFO - 2016-11-03 09:39:14 --> Database Driver Class Initialized
INFO - 2016-11-03 09:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:39:14 --> Controller Class Initialized
INFO - 2016-11-03 09:39:14 --> Form Validation Class Initialized
INFO - 2016-11-03 09:39:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 09:39:14 --> Final output sent to browser
DEBUG - 2016-11-03 09:39:14 --> Total execution time: 0.0180
INFO - 2016-11-03 09:39:31 --> Config Class Initialized
INFO - 2016-11-03 09:39:31 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:39:31 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:39:31 --> Utf8 Class Initialized
INFO - 2016-11-03 09:39:31 --> URI Class Initialized
INFO - 2016-11-03 09:39:31 --> Router Class Initialized
INFO - 2016-11-03 09:39:31 --> Output Class Initialized
INFO - 2016-11-03 09:39:31 --> Security Class Initialized
DEBUG - 2016-11-03 09:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:39:31 --> Input Class Initialized
INFO - 2016-11-03 09:39:31 --> Language Class Initialized
INFO - 2016-11-03 09:39:31 --> Loader Class Initialized
INFO - 2016-11-03 09:39:31 --> Helper loaded: url_helper
INFO - 2016-11-03 09:39:31 --> Helper loaded: form_helper
INFO - 2016-11-03 09:39:31 --> Database Driver Class Initialized
INFO - 2016-11-03 09:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:39:31 --> Controller Class Initialized
INFO - 2016-11-03 09:39:31 --> Form Validation Class Initialized
INFO - 2016-11-03 09:39:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 09:39:31 --> Final output sent to browser
DEBUG - 2016-11-03 09:39:31 --> Total execution time: 0.0214
INFO - 2016-11-03 09:40:07 --> Config Class Initialized
INFO - 2016-11-03 09:40:07 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:40:07 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:40:07 --> Utf8 Class Initialized
INFO - 2016-11-03 09:40:07 --> URI Class Initialized
DEBUG - 2016-11-03 09:40:07 --> No URI present. Default controller set.
INFO - 2016-11-03 09:40:07 --> Router Class Initialized
INFO - 2016-11-03 09:40:07 --> Output Class Initialized
INFO - 2016-11-03 09:40:07 --> Security Class Initialized
DEBUG - 2016-11-03 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:40:07 --> Input Class Initialized
INFO - 2016-11-03 09:40:07 --> Language Class Initialized
INFO - 2016-11-03 09:40:07 --> Loader Class Initialized
INFO - 2016-11-03 09:40:07 --> Helper loaded: url_helper
INFO - 2016-11-03 09:40:07 --> Helper loaded: form_helper
INFO - 2016-11-03 09:40:07 --> Database Driver Class Initialized
INFO - 2016-11-03 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:40:07 --> Controller Class Initialized
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:40:07 --> Model Class Initialized
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:40:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:40:07 --> Final output sent to browser
DEBUG - 2016-11-03 09:40:07 --> Total execution time: 0.0206
INFO - 2016-11-03 09:41:28 --> Config Class Initialized
INFO - 2016-11-03 09:41:28 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:41:28 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:41:28 --> Utf8 Class Initialized
INFO - 2016-11-03 09:41:28 --> URI Class Initialized
DEBUG - 2016-11-03 09:41:28 --> No URI present. Default controller set.
INFO - 2016-11-03 09:41:28 --> Router Class Initialized
INFO - 2016-11-03 09:41:28 --> Output Class Initialized
INFO - 2016-11-03 09:41:28 --> Security Class Initialized
DEBUG - 2016-11-03 09:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:41:28 --> Input Class Initialized
INFO - 2016-11-03 09:41:28 --> Language Class Initialized
INFO - 2016-11-03 09:41:28 --> Loader Class Initialized
INFO - 2016-11-03 09:41:28 --> Helper loaded: url_helper
INFO - 2016-11-03 09:41:28 --> Helper loaded: form_helper
INFO - 2016-11-03 09:41:28 --> Database Driver Class Initialized
INFO - 2016-11-03 09:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:41:28 --> Controller Class Initialized
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:41:28 --> Model Class Initialized
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:41:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:41:28 --> Final output sent to browser
DEBUG - 2016-11-03 09:41:28 --> Total execution time: 0.0199
INFO - 2016-11-03 09:41:58 --> Config Class Initialized
INFO - 2016-11-03 09:41:58 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:41:58 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:41:58 --> Utf8 Class Initialized
INFO - 2016-11-03 09:41:58 --> URI Class Initialized
INFO - 2016-11-03 09:41:58 --> Router Class Initialized
INFO - 2016-11-03 09:41:58 --> Output Class Initialized
INFO - 2016-11-03 09:41:58 --> Security Class Initialized
DEBUG - 2016-11-03 09:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:41:58 --> Input Class Initialized
INFO - 2016-11-03 09:41:58 --> Language Class Initialized
INFO - 2016-11-03 09:41:58 --> Loader Class Initialized
INFO - 2016-11-03 09:41:58 --> Helper loaded: url_helper
INFO - 2016-11-03 09:41:58 --> Helper loaded: form_helper
INFO - 2016-11-03 09:41:58 --> Database Driver Class Initialized
INFO - 2016-11-03 09:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:41:58 --> Controller Class Initialized
INFO - 2016-11-03 09:41:58 --> Model Class Initialized
INFO - 2016-11-03 09:41:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:41:58 --> Final output sent to browser
DEBUG - 2016-11-03 09:41:58 --> Total execution time: 0.0174
INFO - 2016-11-03 09:42:01 --> Config Class Initialized
INFO - 2016-11-03 09:42:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:42:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:42:01 --> Utf8 Class Initialized
INFO - 2016-11-03 09:42:01 --> URI Class Initialized
INFO - 2016-11-03 09:42:01 --> Router Class Initialized
INFO - 2016-11-03 09:42:01 --> Output Class Initialized
INFO - 2016-11-03 09:42:01 --> Security Class Initialized
DEBUG - 2016-11-03 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:42:01 --> Input Class Initialized
INFO - 2016-11-03 09:42:01 --> Language Class Initialized
INFO - 2016-11-03 09:42:01 --> Loader Class Initialized
INFO - 2016-11-03 09:42:01 --> Helper loaded: url_helper
INFO - 2016-11-03 09:42:01 --> Helper loaded: form_helper
INFO - 2016-11-03 09:42:01 --> Database Driver Class Initialized
INFO - 2016-11-03 09:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:42:01 --> Controller Class Initialized
INFO - 2016-11-03 09:42:01 --> Model Class Initialized
INFO - 2016-11-03 09:42:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:42:01 --> Final output sent to browser
DEBUG - 2016-11-03 09:42:01 --> Total execution time: 0.0177
INFO - 2016-11-03 09:42:04 --> Config Class Initialized
INFO - 2016-11-03 09:42:04 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:42:04 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:42:04 --> Utf8 Class Initialized
INFO - 2016-11-03 09:42:04 --> URI Class Initialized
INFO - 2016-11-03 09:42:04 --> Router Class Initialized
INFO - 2016-11-03 09:42:04 --> Output Class Initialized
INFO - 2016-11-03 09:42:04 --> Security Class Initialized
DEBUG - 2016-11-03 09:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:42:04 --> Input Class Initialized
INFO - 2016-11-03 09:42:04 --> Language Class Initialized
INFO - 2016-11-03 09:42:04 --> Loader Class Initialized
INFO - 2016-11-03 09:42:04 --> Helper loaded: url_helper
INFO - 2016-11-03 09:42:04 --> Helper loaded: form_helper
INFO - 2016-11-03 09:42:04 --> Database Driver Class Initialized
INFO - 2016-11-03 09:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:42:04 --> Controller Class Initialized
INFO - 2016-11-03 09:42:04 --> Model Class Initialized
INFO - 2016-11-03 09:42:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:42:04 --> Final output sent to browser
DEBUG - 2016-11-03 09:42:04 --> Total execution time: 0.0184
INFO - 2016-11-03 09:42:09 --> Config Class Initialized
INFO - 2016-11-03 09:42:09 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:42:09 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:42:09 --> Utf8 Class Initialized
INFO - 2016-11-03 09:42:09 --> URI Class Initialized
INFO - 2016-11-03 09:42:09 --> Router Class Initialized
INFO - 2016-11-03 09:42:09 --> Output Class Initialized
INFO - 2016-11-03 09:42:09 --> Security Class Initialized
DEBUG - 2016-11-03 09:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:42:09 --> Input Class Initialized
INFO - 2016-11-03 09:42:09 --> Language Class Initialized
INFO - 2016-11-03 09:42:09 --> Loader Class Initialized
INFO - 2016-11-03 09:42:09 --> Helper loaded: url_helper
INFO - 2016-11-03 09:42:09 --> Helper loaded: form_helper
INFO - 2016-11-03 09:42:09 --> Database Driver Class Initialized
INFO - 2016-11-03 09:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:42:09 --> Controller Class Initialized
INFO - 2016-11-03 09:42:09 --> Model Class Initialized
INFO - 2016-11-03 09:42:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:42:09 --> Final output sent to browser
DEBUG - 2016-11-03 09:42:09 --> Total execution time: 0.0181
INFO - 2016-11-03 09:46:27 --> Config Class Initialized
INFO - 2016-11-03 09:46:27 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:46:27 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:46:27 --> Utf8 Class Initialized
INFO - 2016-11-03 09:46:27 --> URI Class Initialized
DEBUG - 2016-11-03 09:46:27 --> No URI present. Default controller set.
INFO - 2016-11-03 09:46:27 --> Router Class Initialized
INFO - 2016-11-03 09:46:27 --> Output Class Initialized
INFO - 2016-11-03 09:46:27 --> Security Class Initialized
DEBUG - 2016-11-03 09:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:46:27 --> Input Class Initialized
INFO - 2016-11-03 09:46:27 --> Language Class Initialized
INFO - 2016-11-03 09:46:27 --> Loader Class Initialized
INFO - 2016-11-03 09:46:27 --> Helper loaded: url_helper
INFO - 2016-11-03 09:46:27 --> Helper loaded: form_helper
INFO - 2016-11-03 09:46:27 --> Database Driver Class Initialized
INFO - 2016-11-03 09:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:46:27 --> Controller Class Initialized
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:46:27 --> Model Class Initialized
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:46:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:46:27 --> Final output sent to browser
DEBUG - 2016-11-03 09:46:27 --> Total execution time: 0.0206
INFO - 2016-11-03 09:47:17 --> Config Class Initialized
INFO - 2016-11-03 09:47:17 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:47:17 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:47:17 --> Utf8 Class Initialized
INFO - 2016-11-03 09:47:17 --> URI Class Initialized
DEBUG - 2016-11-03 09:47:17 --> No URI present. Default controller set.
INFO - 2016-11-03 09:47:17 --> Router Class Initialized
INFO - 2016-11-03 09:47:17 --> Output Class Initialized
INFO - 2016-11-03 09:47:17 --> Security Class Initialized
DEBUG - 2016-11-03 09:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:47:17 --> Input Class Initialized
INFO - 2016-11-03 09:47:17 --> Language Class Initialized
INFO - 2016-11-03 09:47:17 --> Loader Class Initialized
INFO - 2016-11-03 09:47:17 --> Helper loaded: url_helper
INFO - 2016-11-03 09:47:17 --> Helper loaded: form_helper
INFO - 2016-11-03 09:47:17 --> Database Driver Class Initialized
INFO - 2016-11-03 09:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:47:17 --> Controller Class Initialized
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:47:17 --> Model Class Initialized
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:47:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:47:17 --> Final output sent to browser
DEBUG - 2016-11-03 09:47:17 --> Total execution time: 0.0250
INFO - 2016-11-03 09:47:25 --> Config Class Initialized
INFO - 2016-11-03 09:47:25 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:47:25 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:47:25 --> Utf8 Class Initialized
INFO - 2016-11-03 09:47:25 --> URI Class Initialized
INFO - 2016-11-03 09:47:25 --> Router Class Initialized
INFO - 2016-11-03 09:47:25 --> Output Class Initialized
INFO - 2016-11-03 09:47:25 --> Security Class Initialized
DEBUG - 2016-11-03 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:47:25 --> Input Class Initialized
INFO - 2016-11-03 09:47:25 --> Language Class Initialized
INFO - 2016-11-03 09:47:25 --> Loader Class Initialized
INFO - 2016-11-03 09:47:25 --> Helper loaded: url_helper
INFO - 2016-11-03 09:47:25 --> Helper loaded: form_helper
INFO - 2016-11-03 09:47:25 --> Database Driver Class Initialized
INFO - 2016-11-03 09:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:47:25 --> Controller Class Initialized
INFO - 2016-11-03 09:47:25 --> Model Class Initialized
INFO - 2016-11-03 09:47:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:47:25 --> Final output sent to browser
DEBUG - 2016-11-03 09:47:25 --> Total execution time: 0.0185
INFO - 2016-11-03 09:50:08 --> Config Class Initialized
INFO - 2016-11-03 09:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:50:08 --> Utf8 Class Initialized
INFO - 2016-11-03 09:50:08 --> URI Class Initialized
DEBUG - 2016-11-03 09:50:08 --> No URI present. Default controller set.
INFO - 2016-11-03 09:50:08 --> Router Class Initialized
INFO - 2016-11-03 09:50:08 --> Output Class Initialized
INFO - 2016-11-03 09:50:08 --> Security Class Initialized
DEBUG - 2016-11-03 09:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:50:08 --> Input Class Initialized
INFO - 2016-11-03 09:50:08 --> Language Class Initialized
INFO - 2016-11-03 09:50:08 --> Loader Class Initialized
INFO - 2016-11-03 09:50:08 --> Helper loaded: url_helper
INFO - 2016-11-03 09:50:08 --> Helper loaded: form_helper
INFO - 2016-11-03 09:50:08 --> Database Driver Class Initialized
INFO - 2016-11-03 09:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:50:08 --> Controller Class Initialized
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:50:08 --> Model Class Initialized
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:50:08 --> Final output sent to browser
DEBUG - 2016-11-03 09:50:08 --> Total execution time: 0.0237
INFO - 2016-11-03 09:50:15 --> Config Class Initialized
INFO - 2016-11-03 09:50:15 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:50:15 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:50:15 --> Utf8 Class Initialized
INFO - 2016-11-03 09:50:15 --> URI Class Initialized
INFO - 2016-11-03 09:50:15 --> Router Class Initialized
INFO - 2016-11-03 09:50:15 --> Output Class Initialized
INFO - 2016-11-03 09:50:15 --> Security Class Initialized
DEBUG - 2016-11-03 09:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:50:15 --> Input Class Initialized
INFO - 2016-11-03 09:50:15 --> Language Class Initialized
INFO - 2016-11-03 09:50:15 --> Loader Class Initialized
INFO - 2016-11-03 09:50:15 --> Helper loaded: url_helper
INFO - 2016-11-03 09:50:15 --> Helper loaded: form_helper
INFO - 2016-11-03 09:50:15 --> Database Driver Class Initialized
INFO - 2016-11-03 09:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:50:15 --> Controller Class Initialized
INFO - 2016-11-03 09:50:15 --> Model Class Initialized
INFO - 2016-11-03 09:50:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:50:15 --> Final output sent to browser
DEBUG - 2016-11-03 09:50:15 --> Total execution time: 0.0178
INFO - 2016-11-03 09:50:19 --> Config Class Initialized
INFO - 2016-11-03 09:50:19 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:50:19 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:50:19 --> Utf8 Class Initialized
INFO - 2016-11-03 09:50:19 --> URI Class Initialized
INFO - 2016-11-03 09:50:19 --> Router Class Initialized
INFO - 2016-11-03 09:50:19 --> Output Class Initialized
INFO - 2016-11-03 09:50:19 --> Security Class Initialized
DEBUG - 2016-11-03 09:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:50:19 --> Input Class Initialized
INFO - 2016-11-03 09:50:19 --> Language Class Initialized
INFO - 2016-11-03 09:50:19 --> Loader Class Initialized
INFO - 2016-11-03 09:50:19 --> Helper loaded: url_helper
INFO - 2016-11-03 09:50:19 --> Helper loaded: form_helper
INFO - 2016-11-03 09:50:19 --> Database Driver Class Initialized
INFO - 2016-11-03 09:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:50:19 --> Controller Class Initialized
INFO - 2016-11-03 09:50:19 --> Model Class Initialized
INFO - 2016-11-03 09:50:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:50:19 --> Final output sent to browser
DEBUG - 2016-11-03 09:50:19 --> Total execution time: 0.0170
INFO - 2016-11-03 09:53:40 --> Config Class Initialized
INFO - 2016-11-03 09:53:40 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:53:40 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:53:40 --> Utf8 Class Initialized
INFO - 2016-11-03 09:53:40 --> URI Class Initialized
DEBUG - 2016-11-03 09:53:40 --> No URI present. Default controller set.
INFO - 2016-11-03 09:53:40 --> Router Class Initialized
INFO - 2016-11-03 09:53:40 --> Output Class Initialized
INFO - 2016-11-03 09:53:40 --> Security Class Initialized
DEBUG - 2016-11-03 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:53:40 --> Input Class Initialized
INFO - 2016-11-03 09:53:40 --> Language Class Initialized
INFO - 2016-11-03 09:53:40 --> Loader Class Initialized
INFO - 2016-11-03 09:53:40 --> Helper loaded: url_helper
INFO - 2016-11-03 09:53:40 --> Helper loaded: form_helper
INFO - 2016-11-03 09:53:40 --> Database Driver Class Initialized
INFO - 2016-11-03 09:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:53:40 --> Controller Class Initialized
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:53:40 --> Model Class Initialized
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:53:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:53:40 --> Final output sent to browser
DEBUG - 2016-11-03 09:53:40 --> Total execution time: 0.0225
INFO - 2016-11-03 09:54:02 --> Config Class Initialized
INFO - 2016-11-03 09:54:02 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:54:02 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:54:02 --> Utf8 Class Initialized
INFO - 2016-11-03 09:54:02 --> URI Class Initialized
DEBUG - 2016-11-03 09:54:02 --> No URI present. Default controller set.
INFO - 2016-11-03 09:54:02 --> Router Class Initialized
INFO - 2016-11-03 09:54:02 --> Output Class Initialized
INFO - 2016-11-03 09:54:02 --> Security Class Initialized
DEBUG - 2016-11-03 09:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:54:02 --> Input Class Initialized
INFO - 2016-11-03 09:54:02 --> Language Class Initialized
INFO - 2016-11-03 09:54:02 --> Loader Class Initialized
INFO - 2016-11-03 09:54:02 --> Helper loaded: url_helper
INFO - 2016-11-03 09:54:02 --> Helper loaded: form_helper
INFO - 2016-11-03 09:54:02 --> Database Driver Class Initialized
INFO - 2016-11-03 09:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:54:02 --> Controller Class Initialized
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 09:54:02 --> Model Class Initialized
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 09:54:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 09:54:02 --> Final output sent to browser
DEBUG - 2016-11-03 09:54:02 --> Total execution time: 0.0192
INFO - 2016-11-03 09:54:12 --> Config Class Initialized
INFO - 2016-11-03 09:54:12 --> Hooks Class Initialized
DEBUG - 2016-11-03 09:54:12 --> UTF-8 Support Enabled
INFO - 2016-11-03 09:54:12 --> Utf8 Class Initialized
INFO - 2016-11-03 09:54:12 --> URI Class Initialized
INFO - 2016-11-03 09:54:12 --> Router Class Initialized
INFO - 2016-11-03 09:54:12 --> Output Class Initialized
INFO - 2016-11-03 09:54:12 --> Security Class Initialized
DEBUG - 2016-11-03 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 09:54:12 --> Input Class Initialized
INFO - 2016-11-03 09:54:12 --> Language Class Initialized
INFO - 2016-11-03 09:54:12 --> Loader Class Initialized
INFO - 2016-11-03 09:54:12 --> Helper loaded: url_helper
INFO - 2016-11-03 09:54:12 --> Helper loaded: form_helper
INFO - 2016-11-03 09:54:12 --> Database Driver Class Initialized
INFO - 2016-11-03 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 09:54:12 --> Controller Class Initialized
INFO - 2016-11-03 09:54:12 --> Form Validation Class Initialized
INFO - 2016-11-03 09:54:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 09:54:12 --> Final output sent to browser
DEBUG - 2016-11-03 09:54:12 --> Total execution time: 0.0307
INFO - 2016-11-03 10:53:47 --> Config Class Initialized
INFO - 2016-11-03 10:53:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 10:53:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 10:53:47 --> Utf8 Class Initialized
INFO - 2016-11-03 10:53:47 --> URI Class Initialized
DEBUG - 2016-11-03 10:53:47 --> No URI present. Default controller set.
INFO - 2016-11-03 10:53:47 --> Router Class Initialized
INFO - 2016-11-03 10:53:47 --> Output Class Initialized
INFO - 2016-11-03 10:53:47 --> Security Class Initialized
DEBUG - 2016-11-03 10:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 10:53:47 --> Input Class Initialized
INFO - 2016-11-03 10:53:47 --> Language Class Initialized
INFO - 2016-11-03 10:53:47 --> Loader Class Initialized
INFO - 2016-11-03 10:53:47 --> Helper loaded: url_helper
INFO - 2016-11-03 10:53:47 --> Helper loaded: form_helper
INFO - 2016-11-03 10:53:47 --> Database Driver Class Initialized
INFO - 2016-11-03 10:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 10:53:47 --> Controller Class Initialized
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 10:53:47 --> Model Class Initialized
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 10:53:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 10:53:47 --> Final output sent to browser
DEBUG - 2016-11-03 10:53:47 --> Total execution time: 0.0574
INFO - 2016-11-03 10:54:08 --> Config Class Initialized
INFO - 2016-11-03 10:54:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 10:54:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 10:54:08 --> Utf8 Class Initialized
INFO - 2016-11-03 10:54:08 --> URI Class Initialized
INFO - 2016-11-03 10:54:08 --> Router Class Initialized
INFO - 2016-11-03 10:54:08 --> Output Class Initialized
INFO - 2016-11-03 10:54:08 --> Security Class Initialized
DEBUG - 2016-11-03 10:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 10:54:08 --> Input Class Initialized
INFO - 2016-11-03 10:54:08 --> Language Class Initialized
INFO - 2016-11-03 10:54:08 --> Loader Class Initialized
INFO - 2016-11-03 10:54:08 --> Helper loaded: url_helper
INFO - 2016-11-03 10:54:08 --> Helper loaded: form_helper
INFO - 2016-11-03 10:54:08 --> Database Driver Class Initialized
INFO - 2016-11-03 10:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 10:54:08 --> Controller Class Initialized
INFO - 2016-11-03 10:54:08 --> Form Validation Class Initialized
INFO - 2016-11-03 10:54:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 10:54:08 --> Final output sent to browser
DEBUG - 2016-11-03 10:54:08 --> Total execution time: 0.0337
INFO - 2016-11-03 10:54:10 --> Config Class Initialized
INFO - 2016-11-03 10:54:10 --> Hooks Class Initialized
DEBUG - 2016-11-03 10:54:10 --> UTF-8 Support Enabled
INFO - 2016-11-03 10:54:10 --> Utf8 Class Initialized
INFO - 2016-11-03 10:54:10 --> URI Class Initialized
DEBUG - 2016-11-03 10:54:10 --> No URI present. Default controller set.
INFO - 2016-11-03 10:54:10 --> Router Class Initialized
INFO - 2016-11-03 10:54:10 --> Output Class Initialized
INFO - 2016-11-03 10:54:10 --> Security Class Initialized
DEBUG - 2016-11-03 10:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 10:54:10 --> Input Class Initialized
INFO - 2016-11-03 10:54:10 --> Language Class Initialized
INFO - 2016-11-03 10:54:10 --> Loader Class Initialized
INFO - 2016-11-03 10:54:10 --> Helper loaded: url_helper
INFO - 2016-11-03 10:54:10 --> Helper loaded: form_helper
INFO - 2016-11-03 10:54:10 --> Database Driver Class Initialized
INFO - 2016-11-03 10:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 10:54:10 --> Controller Class Initialized
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 10:54:10 --> Model Class Initialized
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 10:54:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 10:54:10 --> Final output sent to browser
DEBUG - 2016-11-03 10:54:10 --> Total execution time: 0.0186
INFO - 2016-11-03 10:56:33 --> Config Class Initialized
INFO - 2016-11-03 10:56:33 --> Hooks Class Initialized
DEBUG - 2016-11-03 10:56:33 --> UTF-8 Support Enabled
INFO - 2016-11-03 10:56:33 --> Utf8 Class Initialized
INFO - 2016-11-03 10:56:33 --> URI Class Initialized
INFO - 2016-11-03 10:56:33 --> Router Class Initialized
INFO - 2016-11-03 10:56:33 --> Output Class Initialized
INFO - 2016-11-03 10:56:33 --> Security Class Initialized
DEBUG - 2016-11-03 10:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 10:56:33 --> Input Class Initialized
INFO - 2016-11-03 10:56:33 --> Language Class Initialized
INFO - 2016-11-03 10:56:33 --> Loader Class Initialized
INFO - 2016-11-03 10:56:33 --> Helper loaded: url_helper
INFO - 2016-11-03 10:56:33 --> Helper loaded: form_helper
INFO - 2016-11-03 10:56:33 --> Database Driver Class Initialized
INFO - 2016-11-03 10:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 10:56:33 --> Controller Class Initialized
INFO - 2016-11-03 10:56:33 --> Model Class Initialized
INFO - 2016-11-03 10:56:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 10:56:33 --> Final output sent to browser
DEBUG - 2016-11-03 10:56:33 --> Total execution time: 0.0202
INFO - 2016-11-03 11:22:36 --> Config Class Initialized
INFO - 2016-11-03 11:22:36 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:22:36 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:22:36 --> Utf8 Class Initialized
INFO - 2016-11-03 11:22:36 --> URI Class Initialized
DEBUG - 2016-11-03 11:22:36 --> No URI present. Default controller set.
INFO - 2016-11-03 11:22:36 --> Router Class Initialized
INFO - 2016-11-03 11:22:36 --> Output Class Initialized
INFO - 2016-11-03 11:22:36 --> Security Class Initialized
DEBUG - 2016-11-03 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:22:36 --> Input Class Initialized
INFO - 2016-11-03 11:22:36 --> Language Class Initialized
INFO - 2016-11-03 11:22:36 --> Loader Class Initialized
INFO - 2016-11-03 11:22:36 --> Helper loaded: url_helper
INFO - 2016-11-03 11:22:36 --> Helper loaded: form_helper
INFO - 2016-11-03 11:22:36 --> Database Driver Class Initialized
INFO - 2016-11-03 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:22:36 --> Controller Class Initialized
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 11:22:36 --> Model Class Initialized
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 11:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 11:22:36 --> Final output sent to browser
DEBUG - 2016-11-03 11:22:36 --> Total execution time: 0.0215
INFO - 2016-11-03 11:22:37 --> Config Class Initialized
INFO - 2016-11-03 11:22:37 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:22:37 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:22:37 --> Utf8 Class Initialized
INFO - 2016-11-03 11:22:37 --> URI Class Initialized
DEBUG - 2016-11-03 11:22:37 --> No URI present. Default controller set.
INFO - 2016-11-03 11:22:37 --> Router Class Initialized
INFO - 2016-11-03 11:22:37 --> Output Class Initialized
INFO - 2016-11-03 11:22:37 --> Security Class Initialized
DEBUG - 2016-11-03 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:22:37 --> Input Class Initialized
INFO - 2016-11-03 11:22:37 --> Language Class Initialized
INFO - 2016-11-03 11:22:37 --> Loader Class Initialized
INFO - 2016-11-03 11:22:37 --> Helper loaded: url_helper
INFO - 2016-11-03 11:22:37 --> Helper loaded: form_helper
INFO - 2016-11-03 11:22:37 --> Database Driver Class Initialized
INFO - 2016-11-03 11:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:22:37 --> Controller Class Initialized
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 11:22:37 --> Model Class Initialized
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 11:22:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 11:22:37 --> Final output sent to browser
DEBUG - 2016-11-03 11:22:37 --> Total execution time: 0.0208
INFO - 2016-11-03 11:48:04 --> Config Class Initialized
INFO - 2016-11-03 11:48:04 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:48:04 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:48:04 --> Utf8 Class Initialized
INFO - 2016-11-03 11:48:04 --> URI Class Initialized
DEBUG - 2016-11-03 11:48:04 --> No URI present. Default controller set.
INFO - 2016-11-03 11:48:04 --> Router Class Initialized
INFO - 2016-11-03 11:48:04 --> Output Class Initialized
INFO - 2016-11-03 11:48:04 --> Security Class Initialized
DEBUG - 2016-11-03 11:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:48:04 --> Input Class Initialized
INFO - 2016-11-03 11:48:04 --> Language Class Initialized
INFO - 2016-11-03 11:48:04 --> Loader Class Initialized
INFO - 2016-11-03 11:48:04 --> Helper loaded: url_helper
INFO - 2016-11-03 11:48:04 --> Helper loaded: form_helper
INFO - 2016-11-03 11:48:04 --> Database Driver Class Initialized
INFO - 2016-11-03 11:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:48:04 --> Controller Class Initialized
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 11:48:04 --> Model Class Initialized
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 11:48:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 11:48:04 --> Final output sent to browser
DEBUG - 2016-11-03 11:48:04 --> Total execution time: 0.0199
INFO - 2016-11-03 11:49:44 --> Config Class Initialized
INFO - 2016-11-03 11:49:44 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:49:44 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:49:44 --> Utf8 Class Initialized
INFO - 2016-11-03 11:49:44 --> URI Class Initialized
DEBUG - 2016-11-03 11:49:44 --> No URI present. Default controller set.
INFO - 2016-11-03 11:49:44 --> Router Class Initialized
INFO - 2016-11-03 11:49:44 --> Output Class Initialized
INFO - 2016-11-03 11:49:44 --> Security Class Initialized
DEBUG - 2016-11-03 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:49:44 --> Input Class Initialized
INFO - 2016-11-03 11:49:44 --> Language Class Initialized
INFO - 2016-11-03 11:49:44 --> Loader Class Initialized
INFO - 2016-11-03 11:49:44 --> Helper loaded: url_helper
INFO - 2016-11-03 11:49:44 --> Helper loaded: form_helper
INFO - 2016-11-03 11:49:44 --> Database Driver Class Initialized
INFO - 2016-11-03 11:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:49:44 --> Controller Class Initialized
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 11:49:44 --> Model Class Initialized
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 11:49:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 11:49:44 --> Final output sent to browser
DEBUG - 2016-11-03 11:49:44 --> Total execution time: 0.0237
INFO - 2016-11-03 11:49:57 --> Config Class Initialized
INFO - 2016-11-03 11:49:57 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:49:57 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:49:57 --> Utf8 Class Initialized
INFO - 2016-11-03 11:49:57 --> URI Class Initialized
INFO - 2016-11-03 11:49:57 --> Router Class Initialized
INFO - 2016-11-03 11:49:57 --> Output Class Initialized
INFO - 2016-11-03 11:49:57 --> Security Class Initialized
DEBUG - 2016-11-03 11:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:49:57 --> Input Class Initialized
INFO - 2016-11-03 11:49:57 --> Language Class Initialized
INFO - 2016-11-03 11:49:57 --> Loader Class Initialized
INFO - 2016-11-03 11:49:57 --> Helper loaded: url_helper
INFO - 2016-11-03 11:49:57 --> Helper loaded: form_helper
INFO - 2016-11-03 11:49:57 --> Database Driver Class Initialized
INFO - 2016-11-03 11:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:49:57 --> Controller Class Initialized
INFO - 2016-11-03 11:49:57 --> Model Class Initialized
INFO - 2016-11-03 11:49:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:49:57 --> Final output sent to browser
DEBUG - 2016-11-03 11:49:57 --> Total execution time: 0.0225
INFO - 2016-11-03 11:50:07 --> Config Class Initialized
INFO - 2016-11-03 11:50:07 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:50:07 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:50:07 --> Utf8 Class Initialized
INFO - 2016-11-03 11:50:07 --> URI Class Initialized
INFO - 2016-11-03 11:50:07 --> Router Class Initialized
INFO - 2016-11-03 11:50:07 --> Output Class Initialized
INFO - 2016-11-03 11:50:07 --> Security Class Initialized
DEBUG - 2016-11-03 11:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:50:07 --> Input Class Initialized
INFO - 2016-11-03 11:50:07 --> Language Class Initialized
INFO - 2016-11-03 11:50:07 --> Loader Class Initialized
INFO - 2016-11-03 11:50:07 --> Helper loaded: url_helper
INFO - 2016-11-03 11:50:07 --> Helper loaded: form_helper
INFO - 2016-11-03 11:50:07 --> Database Driver Class Initialized
INFO - 2016-11-03 11:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:50:07 --> Controller Class Initialized
INFO - 2016-11-03 11:50:07 --> Model Class Initialized
INFO - 2016-11-03 11:50:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:50:07 --> Final output sent to browser
DEBUG - 2016-11-03 11:50:07 --> Total execution time: 0.0177
INFO - 2016-11-03 11:50:11 --> Config Class Initialized
INFO - 2016-11-03 11:50:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:50:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:50:11 --> Utf8 Class Initialized
INFO - 2016-11-03 11:50:11 --> URI Class Initialized
INFO - 2016-11-03 11:50:11 --> Router Class Initialized
INFO - 2016-11-03 11:50:11 --> Output Class Initialized
INFO - 2016-11-03 11:50:11 --> Security Class Initialized
DEBUG - 2016-11-03 11:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:50:11 --> Input Class Initialized
INFO - 2016-11-03 11:50:11 --> Language Class Initialized
INFO - 2016-11-03 11:50:11 --> Loader Class Initialized
INFO - 2016-11-03 11:50:11 --> Helper loaded: url_helper
INFO - 2016-11-03 11:50:11 --> Helper loaded: form_helper
INFO - 2016-11-03 11:50:11 --> Database Driver Class Initialized
INFO - 2016-11-03 11:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:50:11 --> Controller Class Initialized
INFO - 2016-11-03 11:50:11 --> Model Class Initialized
INFO - 2016-11-03 11:50:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:50:11 --> Final output sent to browser
DEBUG - 2016-11-03 11:50:11 --> Total execution time: 0.0173
INFO - 2016-11-03 11:50:22 --> Config Class Initialized
INFO - 2016-11-03 11:50:22 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:50:22 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:50:22 --> Utf8 Class Initialized
INFO - 2016-11-03 11:50:22 --> URI Class Initialized
DEBUG - 2016-11-03 11:50:22 --> No URI present. Default controller set.
INFO - 2016-11-03 11:50:22 --> Router Class Initialized
INFO - 2016-11-03 11:50:22 --> Output Class Initialized
INFO - 2016-11-03 11:50:22 --> Security Class Initialized
DEBUG - 2016-11-03 11:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:50:22 --> Input Class Initialized
INFO - 2016-11-03 11:50:22 --> Language Class Initialized
INFO - 2016-11-03 11:50:22 --> Loader Class Initialized
INFO - 2016-11-03 11:50:22 --> Helper loaded: url_helper
INFO - 2016-11-03 11:50:22 --> Helper loaded: form_helper
INFO - 2016-11-03 11:50:22 --> Database Driver Class Initialized
INFO - 2016-11-03 11:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:50:22 --> Controller Class Initialized
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 11:50:22 --> Model Class Initialized
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 11:50:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 11:50:22 --> Final output sent to browser
DEBUG - 2016-11-03 11:50:22 --> Total execution time: 0.0232
INFO - 2016-11-03 11:50:25 --> Config Class Initialized
INFO - 2016-11-03 11:50:25 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:50:25 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:50:25 --> Utf8 Class Initialized
INFO - 2016-11-03 11:50:25 --> URI Class Initialized
INFO - 2016-11-03 11:50:25 --> Router Class Initialized
INFO - 2016-11-03 11:50:25 --> Output Class Initialized
INFO - 2016-11-03 11:50:25 --> Security Class Initialized
DEBUG - 2016-11-03 11:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:50:25 --> Input Class Initialized
INFO - 2016-11-03 11:50:25 --> Language Class Initialized
INFO - 2016-11-03 11:50:25 --> Loader Class Initialized
INFO - 2016-11-03 11:50:25 --> Helper loaded: url_helper
INFO - 2016-11-03 11:50:25 --> Helper loaded: form_helper
INFO - 2016-11-03 11:50:25 --> Database Driver Class Initialized
INFO - 2016-11-03 11:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:50:25 --> Controller Class Initialized
DEBUG - 2016-11-03 11:50:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-03 11:50:25 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-11-03 11:50:25 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-11-03 11:50:25 --> Config Class Initialized
INFO - 2016-11-03 11:50:25 --> Hooks Class Initialized
DEBUG - 2016-11-03 11:50:25 --> UTF-8 Support Enabled
INFO - 2016-11-03 11:50:25 --> Utf8 Class Initialized
INFO - 2016-11-03 11:50:25 --> URI Class Initialized
DEBUG - 2016-11-03 11:50:25 --> No URI present. Default controller set.
INFO - 2016-11-03 11:50:25 --> Router Class Initialized
INFO - 2016-11-03 11:50:25 --> Output Class Initialized
INFO - 2016-11-03 11:50:25 --> Security Class Initialized
DEBUG - 2016-11-03 11:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 11:50:25 --> Input Class Initialized
INFO - 2016-11-03 11:50:25 --> Language Class Initialized
INFO - 2016-11-03 11:50:25 --> Loader Class Initialized
INFO - 2016-11-03 11:50:25 --> Helper loaded: url_helper
INFO - 2016-11-03 11:50:25 --> Helper loaded: form_helper
INFO - 2016-11-03 11:50:25 --> Database Driver Class Initialized
INFO - 2016-11-03 11:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 11:50:25 --> Controller Class Initialized
INFO - 2016-11-03 11:50:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 11:50:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 11:50:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 11:50:25 --> Final output sent to browser
DEBUG - 2016-11-03 11:50:25 --> Total execution time: 0.0263
INFO - 2016-11-03 12:23:35 --> Config Class Initialized
INFO - 2016-11-03 12:23:35 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:23:35 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:23:35 --> Utf8 Class Initialized
INFO - 2016-11-03 12:23:35 --> URI Class Initialized
DEBUG - 2016-11-03 12:23:35 --> No URI present. Default controller set.
INFO - 2016-11-03 12:23:35 --> Router Class Initialized
INFO - 2016-11-03 12:23:35 --> Output Class Initialized
INFO - 2016-11-03 12:23:35 --> Security Class Initialized
DEBUG - 2016-11-03 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:23:35 --> Input Class Initialized
INFO - 2016-11-03 12:23:35 --> Language Class Initialized
INFO - 2016-11-03 12:23:35 --> Loader Class Initialized
INFO - 2016-11-03 12:23:35 --> Helper loaded: url_helper
INFO - 2016-11-03 12:23:35 --> Helper loaded: form_helper
INFO - 2016-11-03 12:23:35 --> Database Driver Class Initialized
INFO - 2016-11-03 12:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:23:35 --> Controller Class Initialized
INFO - 2016-11-03 12:23:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:23:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:23:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:23:35 --> Final output sent to browser
DEBUG - 2016-11-03 12:23:35 --> Total execution time: 0.0204
INFO - 2016-11-03 12:23:36 --> Config Class Initialized
INFO - 2016-11-03 12:23:36 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:23:36 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:23:36 --> Utf8 Class Initialized
INFO - 2016-11-03 12:23:36 --> URI Class Initialized
DEBUG - 2016-11-03 12:23:36 --> No URI present. Default controller set.
INFO - 2016-11-03 12:23:36 --> Router Class Initialized
INFO - 2016-11-03 12:23:36 --> Output Class Initialized
INFO - 2016-11-03 12:23:36 --> Security Class Initialized
DEBUG - 2016-11-03 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:23:36 --> Input Class Initialized
INFO - 2016-11-03 12:23:36 --> Language Class Initialized
INFO - 2016-11-03 12:23:36 --> Loader Class Initialized
INFO - 2016-11-03 12:23:36 --> Helper loaded: url_helper
INFO - 2016-11-03 12:23:36 --> Helper loaded: form_helper
INFO - 2016-11-03 12:23:36 --> Database Driver Class Initialized
INFO - 2016-11-03 12:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:23:36 --> Controller Class Initialized
INFO - 2016-11-03 12:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:23:36 --> Final output sent to browser
DEBUG - 2016-11-03 12:23:36 --> Total execution time: 0.0161
INFO - 2016-11-03 12:23:38 --> Config Class Initialized
INFO - 2016-11-03 12:23:38 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:23:38 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:23:38 --> Utf8 Class Initialized
INFO - 2016-11-03 12:23:38 --> URI Class Initialized
DEBUG - 2016-11-03 12:23:38 --> No URI present. Default controller set.
INFO - 2016-11-03 12:23:38 --> Router Class Initialized
INFO - 2016-11-03 12:23:38 --> Output Class Initialized
INFO - 2016-11-03 12:23:38 --> Security Class Initialized
DEBUG - 2016-11-03 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:23:38 --> Input Class Initialized
INFO - 2016-11-03 12:23:38 --> Language Class Initialized
INFO - 2016-11-03 12:23:38 --> Loader Class Initialized
INFO - 2016-11-03 12:23:38 --> Helper loaded: url_helper
INFO - 2016-11-03 12:23:38 --> Helper loaded: form_helper
INFO - 2016-11-03 12:23:38 --> Database Driver Class Initialized
INFO - 2016-11-03 12:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:23:38 --> Controller Class Initialized
INFO - 2016-11-03 12:23:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:23:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:23:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:23:38 --> Final output sent to browser
DEBUG - 2016-11-03 12:23:38 --> Total execution time: 0.0155
INFO - 2016-11-03 12:23:56 --> Config Class Initialized
INFO - 2016-11-03 12:23:56 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:23:56 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:23:56 --> Utf8 Class Initialized
INFO - 2016-11-03 12:23:56 --> URI Class Initialized
INFO - 2016-11-03 12:23:56 --> Router Class Initialized
INFO - 2016-11-03 12:23:56 --> Output Class Initialized
INFO - 2016-11-03 12:23:56 --> Security Class Initialized
DEBUG - 2016-11-03 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:23:56 --> Input Class Initialized
INFO - 2016-11-03 12:23:56 --> Language Class Initialized
INFO - 2016-11-03 12:23:56 --> Loader Class Initialized
INFO - 2016-11-03 12:23:56 --> Helper loaded: url_helper
INFO - 2016-11-03 12:23:56 --> Helper loaded: form_helper
INFO - 2016-11-03 12:23:56 --> Database Driver Class Initialized
INFO - 2016-11-03 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:23:56 --> Controller Class Initialized
DEBUG - 2016-11-03 12:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 12:23:56 --> Model Class Initialized
INFO - 2016-11-03 12:23:56 --> Final output sent to browser
DEBUG - 2016-11-03 12:23:56 --> Total execution time: 0.0275
INFO - 2016-11-03 12:23:56 --> Config Class Initialized
INFO - 2016-11-03 12:23:56 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:23:56 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:23:56 --> Utf8 Class Initialized
INFO - 2016-11-03 12:23:56 --> URI Class Initialized
DEBUG - 2016-11-03 12:23:56 --> No URI present. Default controller set.
INFO - 2016-11-03 12:23:56 --> Router Class Initialized
INFO - 2016-11-03 12:23:56 --> Output Class Initialized
INFO - 2016-11-03 12:23:56 --> Security Class Initialized
DEBUG - 2016-11-03 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:23:56 --> Input Class Initialized
INFO - 2016-11-03 12:23:56 --> Language Class Initialized
INFO - 2016-11-03 12:23:56 --> Loader Class Initialized
INFO - 2016-11-03 12:23:56 --> Helper loaded: url_helper
INFO - 2016-11-03 12:23:56 --> Helper loaded: form_helper
INFO - 2016-11-03 12:23:56 --> Database Driver Class Initialized
INFO - 2016-11-03 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:23:56 --> Controller Class Initialized
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 12:23:56 --> Model Class Initialized
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 12:23:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:23:56 --> Final output sent to browser
DEBUG - 2016-11-03 12:23:56 --> Total execution time: 0.0178
INFO - 2016-11-03 12:23:58 --> Config Class Initialized
INFO - 2016-11-03 12:23:58 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:23:58 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:23:58 --> Utf8 Class Initialized
INFO - 2016-11-03 12:23:58 --> URI Class Initialized
DEBUG - 2016-11-03 12:23:58 --> No URI present. Default controller set.
INFO - 2016-11-03 12:23:58 --> Router Class Initialized
INFO - 2016-11-03 12:23:58 --> Output Class Initialized
INFO - 2016-11-03 12:23:58 --> Security Class Initialized
DEBUG - 2016-11-03 12:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:23:58 --> Input Class Initialized
INFO - 2016-11-03 12:23:58 --> Language Class Initialized
INFO - 2016-11-03 12:23:58 --> Loader Class Initialized
INFO - 2016-11-03 12:23:58 --> Helper loaded: url_helper
INFO - 2016-11-03 12:23:58 --> Helper loaded: form_helper
INFO - 2016-11-03 12:23:58 --> Database Driver Class Initialized
INFO - 2016-11-03 12:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:23:58 --> Controller Class Initialized
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 12:23:58 --> Model Class Initialized
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 12:23:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:23:58 --> Final output sent to browser
DEBUG - 2016-11-03 12:23:58 --> Total execution time: 0.0215
INFO - 2016-11-03 12:24:16 --> Config Class Initialized
INFO - 2016-11-03 12:24:16 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:24:16 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:24:16 --> Utf8 Class Initialized
INFO - 2016-11-03 12:24:16 --> URI Class Initialized
INFO - 2016-11-03 12:24:16 --> Router Class Initialized
INFO - 2016-11-03 12:24:16 --> Output Class Initialized
INFO - 2016-11-03 12:24:16 --> Security Class Initialized
DEBUG - 2016-11-03 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:24:16 --> Input Class Initialized
INFO - 2016-11-03 12:24:16 --> Language Class Initialized
INFO - 2016-11-03 12:24:16 --> Loader Class Initialized
INFO - 2016-11-03 12:24:16 --> Helper loaded: url_helper
INFO - 2016-11-03 12:24:16 --> Helper loaded: form_helper
INFO - 2016-11-03 12:24:16 --> Database Driver Class Initialized
INFO - 2016-11-03 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:24:16 --> Controller Class Initialized
DEBUG - 2016-11-03 12:24:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-03 12:24:16 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-11-03 12:24:16 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-11-03 12:24:16 --> Config Class Initialized
INFO - 2016-11-03 12:24:16 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:24:16 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:24:16 --> Utf8 Class Initialized
INFO - 2016-11-03 12:24:16 --> URI Class Initialized
DEBUG - 2016-11-03 12:24:16 --> No URI present. Default controller set.
INFO - 2016-11-03 12:24:16 --> Router Class Initialized
INFO - 2016-11-03 12:24:16 --> Output Class Initialized
INFO - 2016-11-03 12:24:16 --> Security Class Initialized
DEBUG - 2016-11-03 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:24:16 --> Input Class Initialized
INFO - 2016-11-03 12:24:16 --> Language Class Initialized
INFO - 2016-11-03 12:24:16 --> Loader Class Initialized
INFO - 2016-11-03 12:24:16 --> Helper loaded: url_helper
INFO - 2016-11-03 12:24:16 --> Helper loaded: form_helper
INFO - 2016-11-03 12:24:16 --> Database Driver Class Initialized
INFO - 2016-11-03 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:24:16 --> Controller Class Initialized
INFO - 2016-11-03 12:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:24:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:24:16 --> Final output sent to browser
DEBUG - 2016-11-03 12:24:16 --> Total execution time: 0.0147
INFO - 2016-11-03 12:24:18 --> Config Class Initialized
INFO - 2016-11-03 12:24:18 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:24:18 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:24:18 --> Utf8 Class Initialized
INFO - 2016-11-03 12:24:18 --> URI Class Initialized
DEBUG - 2016-11-03 12:24:18 --> No URI present. Default controller set.
INFO - 2016-11-03 12:24:18 --> Router Class Initialized
INFO - 2016-11-03 12:24:18 --> Output Class Initialized
INFO - 2016-11-03 12:24:18 --> Security Class Initialized
DEBUG - 2016-11-03 12:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:24:18 --> Input Class Initialized
INFO - 2016-11-03 12:24:18 --> Language Class Initialized
INFO - 2016-11-03 12:24:18 --> Loader Class Initialized
INFO - 2016-11-03 12:24:18 --> Helper loaded: url_helper
INFO - 2016-11-03 12:24:18 --> Helper loaded: form_helper
INFO - 2016-11-03 12:24:18 --> Database Driver Class Initialized
INFO - 2016-11-03 12:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:24:18 --> Controller Class Initialized
INFO - 2016-11-03 12:24:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:24:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:24:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:24:18 --> Final output sent to browser
DEBUG - 2016-11-03 12:24:18 --> Total execution time: 0.0156
INFO - 2016-11-03 12:26:11 --> Config Class Initialized
INFO - 2016-11-03 12:26:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:26:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:26:11 --> Utf8 Class Initialized
INFO - 2016-11-03 12:26:11 --> URI Class Initialized
DEBUG - 2016-11-03 12:26:11 --> No URI present. Default controller set.
INFO - 2016-11-03 12:26:11 --> Router Class Initialized
INFO - 2016-11-03 12:26:11 --> Output Class Initialized
INFO - 2016-11-03 12:26:11 --> Security Class Initialized
DEBUG - 2016-11-03 12:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:26:11 --> Input Class Initialized
INFO - 2016-11-03 12:26:11 --> Language Class Initialized
INFO - 2016-11-03 12:26:11 --> Loader Class Initialized
INFO - 2016-11-03 12:26:11 --> Helper loaded: url_helper
INFO - 2016-11-03 12:26:11 --> Helper loaded: form_helper
INFO - 2016-11-03 12:26:11 --> Database Driver Class Initialized
INFO - 2016-11-03 12:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:26:11 --> Controller Class Initialized
INFO - 2016-11-03 12:26:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:26:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:26:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:26:11 --> Final output sent to browser
DEBUG - 2016-11-03 12:26:11 --> Total execution time: 0.0198
INFO - 2016-11-03 12:26:29 --> Config Class Initialized
INFO - 2016-11-03 12:26:29 --> Hooks Class Initialized
DEBUG - 2016-11-03 12:26:29 --> UTF-8 Support Enabled
INFO - 2016-11-03 12:26:29 --> Utf8 Class Initialized
INFO - 2016-11-03 12:26:29 --> URI Class Initialized
DEBUG - 2016-11-03 12:26:29 --> No URI present. Default controller set.
INFO - 2016-11-03 12:26:29 --> Router Class Initialized
INFO - 2016-11-03 12:26:29 --> Output Class Initialized
INFO - 2016-11-03 12:26:29 --> Security Class Initialized
DEBUG - 2016-11-03 12:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 12:26:29 --> Input Class Initialized
INFO - 2016-11-03 12:26:29 --> Language Class Initialized
INFO - 2016-11-03 12:26:29 --> Loader Class Initialized
INFO - 2016-11-03 12:26:29 --> Helper loaded: url_helper
INFO - 2016-11-03 12:26:29 --> Helper loaded: form_helper
INFO - 2016-11-03 12:26:29 --> Database Driver Class Initialized
INFO - 2016-11-03 12:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 12:26:29 --> Controller Class Initialized
INFO - 2016-11-03 12:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 12:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 12:26:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 12:26:29 --> Final output sent to browser
DEBUG - 2016-11-03 12:26:29 --> Total execution time: 0.0166
INFO - 2016-11-03 13:14:35 --> Config Class Initialized
INFO - 2016-11-03 13:14:35 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:14:35 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:14:35 --> Utf8 Class Initialized
INFO - 2016-11-03 13:14:35 --> URI Class Initialized
DEBUG - 2016-11-03 13:14:35 --> No URI present. Default controller set.
INFO - 2016-11-03 13:14:35 --> Router Class Initialized
INFO - 2016-11-03 13:14:35 --> Output Class Initialized
INFO - 2016-11-03 13:14:35 --> Security Class Initialized
DEBUG - 2016-11-03 13:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:14:35 --> Input Class Initialized
INFO - 2016-11-03 13:14:35 --> Language Class Initialized
INFO - 2016-11-03 13:14:35 --> Loader Class Initialized
INFO - 2016-11-03 13:14:35 --> Helper loaded: url_helper
INFO - 2016-11-03 13:14:35 --> Helper loaded: form_helper
INFO - 2016-11-03 13:14:35 --> Database Driver Class Initialized
INFO - 2016-11-03 13:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:14:35 --> Controller Class Initialized
INFO - 2016-11-03 13:14:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 13:14:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 13:14:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 13:14:35 --> Final output sent to browser
DEBUG - 2016-11-03 13:14:35 --> Total execution time: 0.0202
INFO - 2016-11-03 13:14:45 --> Config Class Initialized
INFO - 2016-11-03 13:14:45 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:14:45 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:14:45 --> Utf8 Class Initialized
INFO - 2016-11-03 13:14:45 --> URI Class Initialized
INFO - 2016-11-03 13:14:45 --> Router Class Initialized
INFO - 2016-11-03 13:14:45 --> Output Class Initialized
INFO - 2016-11-03 13:14:45 --> Security Class Initialized
DEBUG - 2016-11-03 13:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:14:45 --> Input Class Initialized
INFO - 2016-11-03 13:14:45 --> Language Class Initialized
INFO - 2016-11-03 13:14:45 --> Loader Class Initialized
INFO - 2016-11-03 13:14:45 --> Helper loaded: url_helper
INFO - 2016-11-03 13:14:45 --> Helper loaded: form_helper
INFO - 2016-11-03 13:14:45 --> Database Driver Class Initialized
INFO - 2016-11-03 13:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:14:45 --> Controller Class Initialized
DEBUG - 2016-11-03 13:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 13:14:45 --> Model Class Initialized
INFO - 2016-11-03 13:14:45 --> Final output sent to browser
DEBUG - 2016-11-03 13:14:45 --> Total execution time: 0.0200
INFO - 2016-11-03 13:14:51 --> Config Class Initialized
INFO - 2016-11-03 13:14:51 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:14:51 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:14:51 --> Utf8 Class Initialized
INFO - 2016-11-03 13:14:51 --> URI Class Initialized
INFO - 2016-11-03 13:14:51 --> Router Class Initialized
INFO - 2016-11-03 13:14:51 --> Output Class Initialized
INFO - 2016-11-03 13:14:51 --> Security Class Initialized
DEBUG - 2016-11-03 13:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:14:51 --> Input Class Initialized
INFO - 2016-11-03 13:14:51 --> Language Class Initialized
INFO - 2016-11-03 13:14:51 --> Loader Class Initialized
INFO - 2016-11-03 13:14:51 --> Helper loaded: url_helper
INFO - 2016-11-03 13:14:51 --> Helper loaded: form_helper
INFO - 2016-11-03 13:14:51 --> Database Driver Class Initialized
INFO - 2016-11-03 13:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:14:51 --> Controller Class Initialized
DEBUG - 2016-11-03 13:14:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 13:14:51 --> Model Class Initialized
INFO - 2016-11-03 13:14:51 --> Final output sent to browser
DEBUG - 2016-11-03 13:14:51 --> Total execution time: 0.0185
INFO - 2016-11-03 13:14:56 --> Config Class Initialized
INFO - 2016-11-03 13:14:56 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:14:56 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:14:56 --> Utf8 Class Initialized
INFO - 2016-11-03 13:14:56 --> URI Class Initialized
INFO - 2016-11-03 13:14:56 --> Router Class Initialized
INFO - 2016-11-03 13:14:56 --> Output Class Initialized
INFO - 2016-11-03 13:14:56 --> Security Class Initialized
DEBUG - 2016-11-03 13:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:14:56 --> Input Class Initialized
INFO - 2016-11-03 13:14:56 --> Language Class Initialized
INFO - 2016-11-03 13:14:56 --> Loader Class Initialized
INFO - 2016-11-03 13:14:56 --> Helper loaded: url_helper
INFO - 2016-11-03 13:14:56 --> Helper loaded: form_helper
INFO - 2016-11-03 13:14:56 --> Database Driver Class Initialized
INFO - 2016-11-03 13:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:14:56 --> Controller Class Initialized
DEBUG - 2016-11-03 13:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 13:14:56 --> Model Class Initialized
INFO - 2016-11-03 13:14:56 --> Final output sent to browser
DEBUG - 2016-11-03 13:14:56 --> Total execution time: 0.0178
INFO - 2016-11-03 13:15:02 --> Config Class Initialized
INFO - 2016-11-03 13:15:02 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:02 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:02 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:02 --> URI Class Initialized
INFO - 2016-11-03 13:15:02 --> Router Class Initialized
INFO - 2016-11-03 13:15:02 --> Output Class Initialized
INFO - 2016-11-03 13:15:02 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:02 --> Input Class Initialized
INFO - 2016-11-03 13:15:02 --> Language Class Initialized
INFO - 2016-11-03 13:15:02 --> Loader Class Initialized
INFO - 2016-11-03 13:15:02 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:02 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:02 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:02 --> Controller Class Initialized
DEBUG - 2016-11-03 13:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 13:15:02 --> Model Class Initialized
INFO - 2016-11-03 13:15:02 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:02 --> Total execution time: 0.0183
INFO - 2016-11-03 13:15:06 --> Config Class Initialized
INFO - 2016-11-03 13:15:06 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:06 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:06 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:06 --> URI Class Initialized
INFO - 2016-11-03 13:15:06 --> Router Class Initialized
INFO - 2016-11-03 13:15:06 --> Output Class Initialized
INFO - 2016-11-03 13:15:06 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:06 --> Input Class Initialized
INFO - 2016-11-03 13:15:06 --> Language Class Initialized
INFO - 2016-11-03 13:15:06 --> Loader Class Initialized
INFO - 2016-11-03 13:15:06 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:06 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:06 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:06 --> Controller Class Initialized
DEBUG - 2016-11-03 13:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 13:15:06 --> Model Class Initialized
INFO - 2016-11-03 13:15:06 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:06 --> Total execution time: 0.0169
INFO - 2016-11-03 13:15:11 --> Config Class Initialized
INFO - 2016-11-03 13:15:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:11 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:11 --> URI Class Initialized
INFO - 2016-11-03 13:15:11 --> Router Class Initialized
INFO - 2016-11-03 13:15:11 --> Output Class Initialized
INFO - 2016-11-03 13:15:11 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:11 --> Input Class Initialized
INFO - 2016-11-03 13:15:11 --> Language Class Initialized
INFO - 2016-11-03 13:15:11 --> Loader Class Initialized
INFO - 2016-11-03 13:15:11 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:11 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:11 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:11 --> Controller Class Initialized
DEBUG - 2016-11-03 13:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 13:15:11 --> Model Class Initialized
INFO - 2016-11-03 13:15:11 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:11 --> Total execution time: 0.0671
INFO - 2016-11-03 13:15:11 --> Config Class Initialized
INFO - 2016-11-03 13:15:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:11 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:11 --> URI Class Initialized
DEBUG - 2016-11-03 13:15:11 --> No URI present. Default controller set.
INFO - 2016-11-03 13:15:11 --> Router Class Initialized
INFO - 2016-11-03 13:15:11 --> Output Class Initialized
INFO - 2016-11-03 13:15:11 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:11 --> Input Class Initialized
INFO - 2016-11-03 13:15:11 --> Language Class Initialized
INFO - 2016-11-03 13:15:11 --> Loader Class Initialized
INFO - 2016-11-03 13:15:11 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:11 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:11 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:11 --> Controller Class Initialized
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 13:15:11 --> Model Class Initialized
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 13:15:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 13:15:11 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:11 --> Total execution time: 0.0178
INFO - 2016-11-03 13:15:13 --> Config Class Initialized
INFO - 2016-11-03 13:15:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:13 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:13 --> URI Class Initialized
INFO - 2016-11-03 13:15:13 --> Router Class Initialized
INFO - 2016-11-03 13:15:13 --> Output Class Initialized
INFO - 2016-11-03 13:15:13 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:13 --> Input Class Initialized
INFO - 2016-11-03 13:15:13 --> Language Class Initialized
INFO - 2016-11-03 13:15:13 --> Loader Class Initialized
INFO - 2016-11-03 13:15:13 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:13 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:13 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:13 --> Controller Class Initialized
DEBUG - 2016-11-03 13:15:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-03 13:15:13 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-11-03 13:15:13 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-11-03 13:15:13 --> Config Class Initialized
INFO - 2016-11-03 13:15:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:13 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:13 --> URI Class Initialized
DEBUG - 2016-11-03 13:15:13 --> No URI present. Default controller set.
INFO - 2016-11-03 13:15:13 --> Router Class Initialized
INFO - 2016-11-03 13:15:13 --> Output Class Initialized
INFO - 2016-11-03 13:15:13 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:13 --> Input Class Initialized
INFO - 2016-11-03 13:15:13 --> Language Class Initialized
INFO - 2016-11-03 13:15:13 --> Loader Class Initialized
INFO - 2016-11-03 13:15:13 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:13 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:13 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:13 --> Controller Class Initialized
INFO - 2016-11-03 13:15:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 13:15:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 13:15:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 13:15:13 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:13 --> Total execution time: 0.0148
INFO - 2016-11-03 13:15:15 --> Config Class Initialized
INFO - 2016-11-03 13:15:15 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:15 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:15 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:15 --> URI Class Initialized
DEBUG - 2016-11-03 13:15:15 --> No URI present. Default controller set.
INFO - 2016-11-03 13:15:15 --> Router Class Initialized
INFO - 2016-11-03 13:15:15 --> Output Class Initialized
INFO - 2016-11-03 13:15:15 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:15 --> Input Class Initialized
INFO - 2016-11-03 13:15:15 --> Language Class Initialized
INFO - 2016-11-03 13:15:15 --> Loader Class Initialized
INFO - 2016-11-03 13:15:15 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:15 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:15 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:15 --> Controller Class Initialized
INFO - 2016-11-03 13:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 13:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 13:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 13:15:15 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:15 --> Total execution time: 0.0160
INFO - 2016-11-03 13:15:37 --> Config Class Initialized
INFO - 2016-11-03 13:15:37 --> Hooks Class Initialized
DEBUG - 2016-11-03 13:15:37 --> UTF-8 Support Enabled
INFO - 2016-11-03 13:15:37 --> Utf8 Class Initialized
INFO - 2016-11-03 13:15:37 --> URI Class Initialized
DEBUG - 2016-11-03 13:15:37 --> No URI present. Default controller set.
INFO - 2016-11-03 13:15:37 --> Router Class Initialized
INFO - 2016-11-03 13:15:37 --> Output Class Initialized
INFO - 2016-11-03 13:15:37 --> Security Class Initialized
DEBUG - 2016-11-03 13:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 13:15:37 --> Input Class Initialized
INFO - 2016-11-03 13:15:37 --> Language Class Initialized
INFO - 2016-11-03 13:15:37 --> Loader Class Initialized
INFO - 2016-11-03 13:15:37 --> Helper loaded: url_helper
INFO - 2016-11-03 13:15:37 --> Helper loaded: form_helper
INFO - 2016-11-03 13:15:37 --> Database Driver Class Initialized
INFO - 2016-11-03 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 13:15:37 --> Controller Class Initialized
INFO - 2016-11-03 13:15:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 13:15:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 13:15:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 13:15:37 --> Final output sent to browser
DEBUG - 2016-11-03 13:15:37 --> Total execution time: 0.0167
INFO - 2016-11-03 14:25:01 --> Config Class Initialized
INFO - 2016-11-03 14:25:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:25:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:25:01 --> Utf8 Class Initialized
INFO - 2016-11-03 14:25:01 --> URI Class Initialized
DEBUG - 2016-11-03 14:25:01 --> No URI present. Default controller set.
INFO - 2016-11-03 14:25:01 --> Router Class Initialized
INFO - 2016-11-03 14:25:01 --> Output Class Initialized
INFO - 2016-11-03 14:25:01 --> Security Class Initialized
DEBUG - 2016-11-03 14:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:25:01 --> Input Class Initialized
INFO - 2016-11-03 14:25:01 --> Language Class Initialized
INFO - 2016-11-03 14:25:01 --> Loader Class Initialized
INFO - 2016-11-03 14:25:01 --> Helper loaded: url_helper
INFO - 2016-11-03 14:25:01 --> Helper loaded: form_helper
INFO - 2016-11-03 14:25:01 --> Database Driver Class Initialized
INFO - 2016-11-03 14:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:25:01 --> Controller Class Initialized
INFO - 2016-11-03 14:25:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:25:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 14:25:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:25:01 --> Final output sent to browser
DEBUG - 2016-11-03 14:25:01 --> Total execution time: 0.0200
INFO - 2016-11-03 14:26:05 --> Config Class Initialized
INFO - 2016-11-03 14:26:05 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:26:05 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:26:05 --> Utf8 Class Initialized
INFO - 2016-11-03 14:26:05 --> URI Class Initialized
DEBUG - 2016-11-03 14:26:05 --> No URI present. Default controller set.
INFO - 2016-11-03 14:26:05 --> Router Class Initialized
INFO - 2016-11-03 14:26:05 --> Output Class Initialized
INFO - 2016-11-03 14:26:05 --> Security Class Initialized
DEBUG - 2016-11-03 14:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:26:05 --> Input Class Initialized
INFO - 2016-11-03 14:26:05 --> Language Class Initialized
INFO - 2016-11-03 14:26:05 --> Loader Class Initialized
INFO - 2016-11-03 14:26:05 --> Helper loaded: url_helper
INFO - 2016-11-03 14:26:05 --> Helper loaded: form_helper
INFO - 2016-11-03 14:26:05 --> Database Driver Class Initialized
INFO - 2016-11-03 14:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:26:05 --> Controller Class Initialized
INFO - 2016-11-03 14:26:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:26:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 14:26:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:26:05 --> Final output sent to browser
DEBUG - 2016-11-03 14:26:05 --> Total execution time: 0.0168
INFO - 2016-11-03 14:36:26 --> Config Class Initialized
INFO - 2016-11-03 14:36:26 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:36:26 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:36:26 --> Utf8 Class Initialized
INFO - 2016-11-03 14:36:26 --> URI Class Initialized
DEBUG - 2016-11-03 14:36:26 --> No URI present. Default controller set.
INFO - 2016-11-03 14:36:26 --> Router Class Initialized
INFO - 2016-11-03 14:36:26 --> Output Class Initialized
INFO - 2016-11-03 14:36:26 --> Security Class Initialized
DEBUG - 2016-11-03 14:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:36:26 --> Input Class Initialized
INFO - 2016-11-03 14:36:26 --> Language Class Initialized
INFO - 2016-11-03 14:36:26 --> Loader Class Initialized
INFO - 2016-11-03 14:36:26 --> Helper loaded: url_helper
INFO - 2016-11-03 14:36:26 --> Helper loaded: form_helper
INFO - 2016-11-03 14:36:26 --> Database Driver Class Initialized
INFO - 2016-11-03 14:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:36:26 --> Controller Class Initialized
INFO - 2016-11-03 14:36:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:36:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 14:36:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:36:26 --> Final output sent to browser
DEBUG - 2016-11-03 14:36:26 --> Total execution time: 0.0162
INFO - 2016-11-03 14:36:29 --> Config Class Initialized
INFO - 2016-11-03 14:36:29 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:36:29 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:36:29 --> Utf8 Class Initialized
INFO - 2016-11-03 14:36:29 --> URI Class Initialized
DEBUG - 2016-11-03 14:36:29 --> No URI present. Default controller set.
INFO - 2016-11-03 14:36:29 --> Router Class Initialized
INFO - 2016-11-03 14:36:29 --> Output Class Initialized
INFO - 2016-11-03 14:36:29 --> Security Class Initialized
DEBUG - 2016-11-03 14:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:36:29 --> Input Class Initialized
INFO - 2016-11-03 14:36:29 --> Language Class Initialized
INFO - 2016-11-03 14:36:29 --> Loader Class Initialized
INFO - 2016-11-03 14:36:29 --> Helper loaded: url_helper
INFO - 2016-11-03 14:36:29 --> Helper loaded: form_helper
INFO - 2016-11-03 14:36:29 --> Database Driver Class Initialized
INFO - 2016-11-03 14:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:36:29 --> Controller Class Initialized
INFO - 2016-11-03 14:36:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:36:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 14:36:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:36:29 --> Final output sent to browser
DEBUG - 2016-11-03 14:36:29 --> Total execution time: 0.0157
INFO - 2016-11-03 14:58:01 --> Config Class Initialized
INFO - 2016-11-03 14:58:01 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:58:01 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:58:01 --> Utf8 Class Initialized
INFO - 2016-11-03 14:58:01 --> URI Class Initialized
DEBUG - 2016-11-03 14:58:01 --> No URI present. Default controller set.
INFO - 2016-11-03 14:58:01 --> Router Class Initialized
INFO - 2016-11-03 14:58:01 --> Output Class Initialized
INFO - 2016-11-03 14:58:01 --> Security Class Initialized
DEBUG - 2016-11-03 14:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:58:01 --> Input Class Initialized
INFO - 2016-11-03 14:58:01 --> Language Class Initialized
INFO - 2016-11-03 14:58:01 --> Loader Class Initialized
INFO - 2016-11-03 14:58:01 --> Helper loaded: url_helper
INFO - 2016-11-03 14:58:01 --> Helper loaded: form_helper
INFO - 2016-11-03 14:58:01 --> Database Driver Class Initialized
INFO - 2016-11-03 14:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:58:01 --> Controller Class Initialized
INFO - 2016-11-03 14:58:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:58:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 14:58:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:58:01 --> Final output sent to browser
DEBUG - 2016-11-03 14:58:01 --> Total execution time: 0.0174
INFO - 2016-11-03 14:58:02 --> Config Class Initialized
INFO - 2016-11-03 14:58:02 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:58:02 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:58:02 --> Utf8 Class Initialized
INFO - 2016-11-03 14:58:02 --> URI Class Initialized
DEBUG - 2016-11-03 14:58:02 --> No URI present. Default controller set.
INFO - 2016-11-03 14:58:02 --> Router Class Initialized
INFO - 2016-11-03 14:58:02 --> Output Class Initialized
INFO - 2016-11-03 14:58:02 --> Security Class Initialized
DEBUG - 2016-11-03 14:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:58:02 --> Input Class Initialized
INFO - 2016-11-03 14:58:02 --> Language Class Initialized
INFO - 2016-11-03 14:58:02 --> Loader Class Initialized
INFO - 2016-11-03 14:58:02 --> Helper loaded: url_helper
INFO - 2016-11-03 14:58:02 --> Helper loaded: form_helper
INFO - 2016-11-03 14:58:02 --> Database Driver Class Initialized
INFO - 2016-11-03 14:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:58:02 --> Controller Class Initialized
INFO - 2016-11-03 14:58:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:58:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 14:58:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:58:02 --> Final output sent to browser
DEBUG - 2016-11-03 14:58:02 --> Total execution time: 0.0158
INFO - 2016-11-03 14:58:08 --> Config Class Initialized
INFO - 2016-11-03 14:58:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:58:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:58:08 --> Utf8 Class Initialized
INFO - 2016-11-03 14:58:08 --> URI Class Initialized
INFO - 2016-11-03 14:58:08 --> Router Class Initialized
INFO - 2016-11-03 14:58:08 --> Output Class Initialized
INFO - 2016-11-03 14:58:08 --> Security Class Initialized
DEBUG - 2016-11-03 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:58:08 --> Input Class Initialized
INFO - 2016-11-03 14:58:08 --> Language Class Initialized
INFO - 2016-11-03 14:58:08 --> Loader Class Initialized
INFO - 2016-11-03 14:58:08 --> Helper loaded: url_helper
INFO - 2016-11-03 14:58:08 --> Helper loaded: form_helper
INFO - 2016-11-03 14:58:08 --> Database Driver Class Initialized
INFO - 2016-11-03 14:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:58:08 --> Controller Class Initialized
DEBUG - 2016-11-03 14:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-03 14:58:08 --> Model Class Initialized
INFO - 2016-11-03 14:58:08 --> Final output sent to browser
DEBUG - 2016-11-03 14:58:08 --> Total execution time: 0.0178
INFO - 2016-11-03 14:58:08 --> Config Class Initialized
INFO - 2016-11-03 14:58:08 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:58:08 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:58:08 --> Utf8 Class Initialized
INFO - 2016-11-03 14:58:08 --> URI Class Initialized
DEBUG - 2016-11-03 14:58:08 --> No URI present. Default controller set.
INFO - 2016-11-03 14:58:08 --> Router Class Initialized
INFO - 2016-11-03 14:58:08 --> Output Class Initialized
INFO - 2016-11-03 14:58:08 --> Security Class Initialized
DEBUG - 2016-11-03 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:58:08 --> Input Class Initialized
INFO - 2016-11-03 14:58:08 --> Language Class Initialized
INFO - 2016-11-03 14:58:08 --> Loader Class Initialized
INFO - 2016-11-03 14:58:08 --> Helper loaded: url_helper
INFO - 2016-11-03 14:58:08 --> Helper loaded: form_helper
INFO - 2016-11-03 14:58:08 --> Database Driver Class Initialized
INFO - 2016-11-03 14:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:58:08 --> Controller Class Initialized
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 14:58:08 --> Model Class Initialized
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 14:58:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:58:08 --> Final output sent to browser
DEBUG - 2016-11-03 14:58:08 --> Total execution time: 0.0356
INFO - 2016-11-03 14:58:14 --> Config Class Initialized
INFO - 2016-11-03 14:58:14 --> Hooks Class Initialized
DEBUG - 2016-11-03 14:58:14 --> UTF-8 Support Enabled
INFO - 2016-11-03 14:58:14 --> Utf8 Class Initialized
INFO - 2016-11-03 14:58:14 --> URI Class Initialized
DEBUG - 2016-11-03 14:58:14 --> No URI present. Default controller set.
INFO - 2016-11-03 14:58:14 --> Router Class Initialized
INFO - 2016-11-03 14:58:14 --> Output Class Initialized
INFO - 2016-11-03 14:58:14 --> Security Class Initialized
DEBUG - 2016-11-03 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 14:58:14 --> Input Class Initialized
INFO - 2016-11-03 14:58:14 --> Language Class Initialized
INFO - 2016-11-03 14:58:14 --> Loader Class Initialized
INFO - 2016-11-03 14:58:14 --> Helper loaded: url_helper
INFO - 2016-11-03 14:58:14 --> Helper loaded: form_helper
INFO - 2016-11-03 14:58:14 --> Database Driver Class Initialized
INFO - 2016-11-03 14:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 14:58:14 --> Controller Class Initialized
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 14:58:14 --> Model Class Initialized
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 14:58:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 14:58:14 --> Final output sent to browser
DEBUG - 2016-11-03 14:58:14 --> Total execution time: 0.0198
INFO - 2016-11-03 15:13:35 --> Config Class Initialized
INFO - 2016-11-03 15:13:35 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:13:35 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:13:35 --> Utf8 Class Initialized
INFO - 2016-11-03 15:13:35 --> URI Class Initialized
DEBUG - 2016-11-03 15:13:35 --> No URI present. Default controller set.
INFO - 2016-11-03 15:13:35 --> Router Class Initialized
INFO - 2016-11-03 15:13:35 --> Output Class Initialized
INFO - 2016-11-03 15:13:35 --> Security Class Initialized
DEBUG - 2016-11-03 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:13:35 --> Input Class Initialized
INFO - 2016-11-03 15:13:35 --> Language Class Initialized
INFO - 2016-11-03 15:13:35 --> Loader Class Initialized
INFO - 2016-11-03 15:13:35 --> Helper loaded: url_helper
INFO - 2016-11-03 15:13:35 --> Helper loaded: form_helper
INFO - 2016-11-03 15:13:35 --> Database Driver Class Initialized
INFO - 2016-11-03 15:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:13:35 --> Controller Class Initialized
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-11-03 15:13:35 --> Model Class Initialized
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-11-03 15:13:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:13:35 --> Final output sent to browser
DEBUG - 2016-11-03 15:13:35 --> Total execution time: 0.0213
INFO - 2016-11-03 15:13:37 --> Config Class Initialized
INFO - 2016-11-03 15:13:37 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:13:37 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:13:37 --> Utf8 Class Initialized
INFO - 2016-11-03 15:13:37 --> URI Class Initialized
INFO - 2016-11-03 15:13:37 --> Router Class Initialized
INFO - 2016-11-03 15:13:37 --> Output Class Initialized
INFO - 2016-11-03 15:13:37 --> Security Class Initialized
DEBUG - 2016-11-03 15:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:13:37 --> Input Class Initialized
INFO - 2016-11-03 15:13:37 --> Language Class Initialized
INFO - 2016-11-03 15:13:37 --> Loader Class Initialized
INFO - 2016-11-03 15:13:37 --> Helper loaded: url_helper
INFO - 2016-11-03 15:13:37 --> Helper loaded: form_helper
INFO - 2016-11-03 15:13:37 --> Database Driver Class Initialized
INFO - 2016-11-03 15:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:13:37 --> Controller Class Initialized
DEBUG - 2016-11-03 15:13:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-03 15:13:37 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-11-03 15:13:37 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-11-03 15:13:37 --> Config Class Initialized
INFO - 2016-11-03 15:13:37 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:13:37 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:13:37 --> Utf8 Class Initialized
INFO - 2016-11-03 15:13:37 --> URI Class Initialized
DEBUG - 2016-11-03 15:13:37 --> No URI present. Default controller set.
INFO - 2016-11-03 15:13:37 --> Router Class Initialized
INFO - 2016-11-03 15:13:37 --> Output Class Initialized
INFO - 2016-11-03 15:13:37 --> Security Class Initialized
DEBUG - 2016-11-03 15:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:13:37 --> Input Class Initialized
INFO - 2016-11-03 15:13:37 --> Language Class Initialized
INFO - 2016-11-03 15:13:37 --> Loader Class Initialized
INFO - 2016-11-03 15:13:37 --> Helper loaded: url_helper
INFO - 2016-11-03 15:13:37 --> Helper loaded: form_helper
INFO - 2016-11-03 15:13:37 --> Database Driver Class Initialized
INFO - 2016-11-03 15:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:13:37 --> Controller Class Initialized
INFO - 2016-11-03 15:13:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:13:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:13:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:13:37 --> Final output sent to browser
DEBUG - 2016-11-03 15:13:37 --> Total execution time: 0.0153
INFO - 2016-11-03 15:21:23 --> Config Class Initialized
INFO - 2016-11-03 15:21:23 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:21:23 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:21:23 --> Utf8 Class Initialized
INFO - 2016-11-03 15:21:23 --> URI Class Initialized
DEBUG - 2016-11-03 15:21:23 --> No URI present. Default controller set.
INFO - 2016-11-03 15:21:23 --> Router Class Initialized
INFO - 2016-11-03 15:21:23 --> Output Class Initialized
INFO - 2016-11-03 15:21:23 --> Security Class Initialized
DEBUG - 2016-11-03 15:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:21:23 --> Input Class Initialized
INFO - 2016-11-03 15:21:23 --> Language Class Initialized
INFO - 2016-11-03 15:21:23 --> Loader Class Initialized
INFO - 2016-11-03 15:21:23 --> Helper loaded: url_helper
INFO - 2016-11-03 15:21:23 --> Helper loaded: form_helper
INFO - 2016-11-03 15:21:23 --> Database Driver Class Initialized
INFO - 2016-11-03 15:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:21:23 --> Controller Class Initialized
INFO - 2016-11-03 15:21:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:21:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:21:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:21:23 --> Final output sent to browser
DEBUG - 2016-11-03 15:21:23 --> Total execution time: 0.0167
INFO - 2016-11-03 15:28:14 --> Config Class Initialized
INFO - 2016-11-03 15:28:14 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:28:14 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:28:14 --> Utf8 Class Initialized
INFO - 2016-11-03 15:28:14 --> URI Class Initialized
DEBUG - 2016-11-03 15:28:14 --> No URI present. Default controller set.
INFO - 2016-11-03 15:28:14 --> Router Class Initialized
INFO - 2016-11-03 15:28:14 --> Output Class Initialized
INFO - 2016-11-03 15:28:15 --> Security Class Initialized
DEBUG - 2016-11-03 15:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:28:15 --> Input Class Initialized
INFO - 2016-11-03 15:28:15 --> Language Class Initialized
INFO - 2016-11-03 15:28:15 --> Loader Class Initialized
INFO - 2016-11-03 15:28:15 --> Helper loaded: url_helper
INFO - 2016-11-03 15:28:15 --> Helper loaded: form_helper
INFO - 2016-11-03 15:28:15 --> Database Driver Class Initialized
INFO - 2016-11-03 15:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:28:15 --> Controller Class Initialized
INFO - 2016-11-03 15:28:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:28:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:28:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:28:15 --> Final output sent to browser
DEBUG - 2016-11-03 15:28:15 --> Total execution time: 0.0164
INFO - 2016-11-03 15:28:18 --> Config Class Initialized
INFO - 2016-11-03 15:28:18 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:28:18 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:28:18 --> Utf8 Class Initialized
INFO - 2016-11-03 15:28:18 --> URI Class Initialized
DEBUG - 2016-11-03 15:28:18 --> No URI present. Default controller set.
INFO - 2016-11-03 15:28:18 --> Router Class Initialized
INFO - 2016-11-03 15:28:18 --> Output Class Initialized
INFO - 2016-11-03 15:28:18 --> Security Class Initialized
DEBUG - 2016-11-03 15:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:28:18 --> Input Class Initialized
INFO - 2016-11-03 15:28:18 --> Language Class Initialized
INFO - 2016-11-03 15:28:18 --> Loader Class Initialized
INFO - 2016-11-03 15:28:18 --> Helper loaded: url_helper
INFO - 2016-11-03 15:28:18 --> Helper loaded: form_helper
INFO - 2016-11-03 15:28:18 --> Database Driver Class Initialized
INFO - 2016-11-03 15:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:28:18 --> Controller Class Initialized
INFO - 2016-11-03 15:28:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:28:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:28:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:28:18 --> Final output sent to browser
DEBUG - 2016-11-03 15:28:18 --> Total execution time: 0.0161
INFO - 2016-11-03 15:42:11 --> Config Class Initialized
INFO - 2016-11-03 15:42:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:42:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:42:11 --> Utf8 Class Initialized
INFO - 2016-11-03 15:42:11 --> URI Class Initialized
DEBUG - 2016-11-03 15:42:11 --> No URI present. Default controller set.
INFO - 2016-11-03 15:42:11 --> Router Class Initialized
INFO - 2016-11-03 15:42:11 --> Output Class Initialized
INFO - 2016-11-03 15:42:11 --> Security Class Initialized
DEBUG - 2016-11-03 15:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:42:11 --> Input Class Initialized
INFO - 2016-11-03 15:42:11 --> Language Class Initialized
INFO - 2016-11-03 15:42:11 --> Loader Class Initialized
INFO - 2016-11-03 15:42:11 --> Helper loaded: url_helper
INFO - 2016-11-03 15:42:11 --> Helper loaded: form_helper
INFO - 2016-11-03 15:42:11 --> Database Driver Class Initialized
INFO - 2016-11-03 15:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:42:11 --> Controller Class Initialized
INFO - 2016-11-03 15:42:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:42:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:42:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:42:11 --> Final output sent to browser
DEBUG - 2016-11-03 15:42:11 --> Total execution time: 0.0163
INFO - 2016-11-03 15:50:50 --> Config Class Initialized
INFO - 2016-11-03 15:50:50 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:50:50 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:50:50 --> Utf8 Class Initialized
INFO - 2016-11-03 15:50:50 --> URI Class Initialized
DEBUG - 2016-11-03 15:50:50 --> No URI present. Default controller set.
INFO - 2016-11-03 15:50:50 --> Router Class Initialized
INFO - 2016-11-03 15:50:50 --> Output Class Initialized
INFO - 2016-11-03 15:50:50 --> Security Class Initialized
DEBUG - 2016-11-03 15:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:50:50 --> Input Class Initialized
INFO - 2016-11-03 15:50:50 --> Language Class Initialized
INFO - 2016-11-03 15:50:50 --> Loader Class Initialized
INFO - 2016-11-03 15:50:50 --> Helper loaded: url_helper
INFO - 2016-11-03 15:50:50 --> Helper loaded: form_helper
INFO - 2016-11-03 15:50:50 --> Database Driver Class Initialized
INFO - 2016-11-03 15:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:50:50 --> Controller Class Initialized
INFO - 2016-11-03 15:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:50:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:50:50 --> Final output sent to browser
DEBUG - 2016-11-03 15:50:50 --> Total execution time: 0.0172
INFO - 2016-11-03 15:50:57 --> Config Class Initialized
INFO - 2016-11-03 15:50:57 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:50:57 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:50:57 --> Utf8 Class Initialized
INFO - 2016-11-03 15:50:57 --> URI Class Initialized
DEBUG - 2016-11-03 15:50:57 --> No URI present. Default controller set.
INFO - 2016-11-03 15:50:57 --> Router Class Initialized
INFO - 2016-11-03 15:50:57 --> Output Class Initialized
INFO - 2016-11-03 15:50:57 --> Security Class Initialized
DEBUG - 2016-11-03 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:50:57 --> Input Class Initialized
INFO - 2016-11-03 15:50:57 --> Language Class Initialized
INFO - 2016-11-03 15:50:57 --> Loader Class Initialized
INFO - 2016-11-03 15:50:57 --> Helper loaded: url_helper
INFO - 2016-11-03 15:50:57 --> Helper loaded: form_helper
INFO - 2016-11-03 15:50:57 --> Database Driver Class Initialized
INFO - 2016-11-03 15:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:50:57 --> Controller Class Initialized
INFO - 2016-11-03 15:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:50:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:50:57 --> Final output sent to browser
DEBUG - 2016-11-03 15:50:57 --> Total execution time: 0.0167
INFO - 2016-11-03 15:51:09 --> Config Class Initialized
INFO - 2016-11-03 15:51:09 --> Hooks Class Initialized
DEBUG - 2016-11-03 15:51:09 --> UTF-8 Support Enabled
INFO - 2016-11-03 15:51:09 --> Utf8 Class Initialized
INFO - 2016-11-03 15:51:09 --> URI Class Initialized
DEBUG - 2016-11-03 15:51:09 --> No URI present. Default controller set.
INFO - 2016-11-03 15:51:09 --> Router Class Initialized
INFO - 2016-11-03 15:51:09 --> Output Class Initialized
INFO - 2016-11-03 15:51:09 --> Security Class Initialized
DEBUG - 2016-11-03 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 15:51:09 --> Input Class Initialized
INFO - 2016-11-03 15:51:09 --> Language Class Initialized
INFO - 2016-11-03 15:51:09 --> Loader Class Initialized
INFO - 2016-11-03 15:51:09 --> Helper loaded: url_helper
INFO - 2016-11-03 15:51:09 --> Helper loaded: form_helper
INFO - 2016-11-03 15:51:09 --> Database Driver Class Initialized
INFO - 2016-11-03 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 15:51:09 --> Controller Class Initialized
INFO - 2016-11-03 15:51:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-11-03 15:51:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-11-03 15:51:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-11-03 15:51:09 --> Final output sent to browser
DEBUG - 2016-11-03 15:51:09 --> Total execution time: 0.0193
INFO - 2016-11-03 17:15:22 --> Config Class Initialized
INFO - 2016-11-03 17:15:22 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:15:22 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:15:22 --> Utf8 Class Initialized
INFO - 2016-11-03 17:15:22 --> URI Class Initialized
DEBUG - 2016-11-03 17:15:22 --> No URI present. Default controller set.
INFO - 2016-11-03 17:15:22 --> Router Class Initialized
INFO - 2016-11-03 17:15:22 --> Output Class Initialized
INFO - 2016-11-03 17:15:22 --> Security Class Initialized
DEBUG - 2016-11-03 17:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:15:22 --> Input Class Initialized
INFO - 2016-11-03 17:15:22 --> Language Class Initialized
INFO - 2016-11-03 17:15:22 --> Loader Class Initialized
INFO - 2016-11-03 17:15:22 --> Helper loaded: url_helper
INFO - 2016-11-03 17:15:22 --> Helper loaded: form_helper
INFO - 2016-11-03 17:15:22 --> Database Driver Class Initialized
INFO - 2016-11-03 17:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:15:23 --> Controller Class Initialized
INFO - 2016-11-03 17:15:23 --> File loaded: C:\xampp\htdocs\LMS\LMS\app\views\header.php
INFO - 2016-11-03 17:15:23 --> File loaded: C:\xampp\htdocs\LMS\LMS\app\views\navbar.php
INFO - 2016-11-03 17:15:23 --> Model Class Initialized
ERROR - 2016-11-03 17:15:23 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\LMS\LMS\app\views\dashboard.php 217
INFO - 2016-11-03 17:16:43 --> Config Class Initialized
INFO - 2016-11-03 17:16:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:16:44 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:16:44 --> Utf8 Class Initialized
INFO - 2016-11-03 17:16:44 --> URI Class Initialized
DEBUG - 2016-11-03 17:16:44 --> No URI present. Default controller set.
INFO - 2016-11-03 17:16:44 --> Router Class Initialized
INFO - 2016-11-03 17:16:44 --> Output Class Initialized
INFO - 2016-11-03 17:16:44 --> Security Class Initialized
DEBUG - 2016-11-03 17:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:16:44 --> Input Class Initialized
INFO - 2016-11-03 17:16:44 --> Language Class Initialized
INFO - 2016-11-03 17:16:44 --> Loader Class Initialized
INFO - 2016-11-03 17:16:44 --> Helper loaded: url_helper
INFO - 2016-11-03 17:16:44 --> Helper loaded: form_helper
INFO - 2016-11-03 17:16:44 --> Database Driver Class Initialized
INFO - 2016-11-03 17:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:16:44 --> Controller Class Initialized
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:16:44 --> Model Class Initialized
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:16:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:16:44 --> Final output sent to browser
DEBUG - 2016-11-03 17:16:44 --> Total execution time: 0.3002
INFO - 2016-11-03 17:16:49 --> Config Class Initialized
INFO - 2016-11-03 17:16:49 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:16:49 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:16:49 --> Utf8 Class Initialized
INFO - 2016-11-03 17:16:49 --> URI Class Initialized
INFO - 2016-11-03 17:16:49 --> Router Class Initialized
INFO - 2016-11-03 17:16:49 --> Output Class Initialized
INFO - 2016-11-03 17:16:49 --> Security Class Initialized
DEBUG - 2016-11-03 17:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:16:49 --> Input Class Initialized
INFO - 2016-11-03 17:16:49 --> Language Class Initialized
INFO - 2016-11-03 17:16:49 --> Loader Class Initialized
INFO - 2016-11-03 17:16:49 --> Helper loaded: url_helper
INFO - 2016-11-03 17:16:50 --> Helper loaded: form_helper
INFO - 2016-11-03 17:16:50 --> Database Driver Class Initialized
INFO - 2016-11-03 17:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:16:50 --> Controller Class Initialized
INFO - 2016-11-03 17:16:50 --> Form Validation Class Initialized
INFO - 2016-11-03 17:16:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:16:50 --> Final output sent to browser
DEBUG - 2016-11-03 17:16:50 --> Total execution time: 0.1962
INFO - 2016-11-03 17:17:41 --> Config Class Initialized
INFO - 2016-11-03 17:17:41 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:17:41 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:17:41 --> Utf8 Class Initialized
INFO - 2016-11-03 17:17:42 --> URI Class Initialized
DEBUG - 2016-11-03 17:17:42 --> No URI present. Default controller set.
INFO - 2016-11-03 17:17:42 --> Router Class Initialized
INFO - 2016-11-03 17:17:42 --> Output Class Initialized
INFO - 2016-11-03 17:17:42 --> Security Class Initialized
DEBUG - 2016-11-03 17:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:17:42 --> Input Class Initialized
INFO - 2016-11-03 17:17:42 --> Language Class Initialized
INFO - 2016-11-03 17:17:42 --> Loader Class Initialized
INFO - 2016-11-03 17:17:42 --> Helper loaded: url_helper
INFO - 2016-11-03 17:17:42 --> Helper loaded: form_helper
INFO - 2016-11-03 17:17:42 --> Database Driver Class Initialized
INFO - 2016-11-03 17:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:17:42 --> Controller Class Initialized
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:17:42 --> Model Class Initialized
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:17:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:17:42 --> Final output sent to browser
DEBUG - 2016-11-03 17:17:42 --> Total execution time: 0.4756
INFO - 2016-11-03 17:17:46 --> Config Class Initialized
INFO - 2016-11-03 17:17:47 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:17:47 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:17:47 --> Utf8 Class Initialized
INFO - 2016-11-03 17:17:47 --> URI Class Initialized
INFO - 2016-11-03 17:17:47 --> Router Class Initialized
INFO - 2016-11-03 17:17:47 --> Output Class Initialized
INFO - 2016-11-03 17:17:47 --> Security Class Initialized
DEBUG - 2016-11-03 17:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:17:47 --> Input Class Initialized
INFO - 2016-11-03 17:17:47 --> Language Class Initialized
INFO - 2016-11-03 17:17:47 --> Loader Class Initialized
INFO - 2016-11-03 17:17:47 --> Helper loaded: url_helper
INFO - 2016-11-03 17:17:47 --> Helper loaded: form_helper
INFO - 2016-11-03 17:17:47 --> Database Driver Class Initialized
INFO - 2016-11-03 17:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:17:47 --> Controller Class Initialized
INFO - 2016-11-03 17:17:47 --> Form Validation Class Initialized
INFO - 2016-11-03 17:17:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:17:47 --> Final output sent to browser
DEBUG - 2016-11-03 17:17:47 --> Total execution time: 0.2218
INFO - 2016-11-03 17:17:48 --> Config Class Initialized
INFO - 2016-11-03 17:17:48 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:17:48 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:17:48 --> Utf8 Class Initialized
INFO - 2016-11-03 17:17:48 --> URI Class Initialized
DEBUG - 2016-11-03 17:17:48 --> No URI present. Default controller set.
INFO - 2016-11-03 17:17:48 --> Router Class Initialized
INFO - 2016-11-03 17:17:48 --> Output Class Initialized
INFO - 2016-11-03 17:17:48 --> Security Class Initialized
DEBUG - 2016-11-03 17:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:17:48 --> Input Class Initialized
INFO - 2016-11-03 17:17:48 --> Language Class Initialized
INFO - 2016-11-03 17:17:48 --> Loader Class Initialized
INFO - 2016-11-03 17:17:48 --> Helper loaded: url_helper
INFO - 2016-11-03 17:17:48 --> Helper loaded: form_helper
INFO - 2016-11-03 17:17:48 --> Database Driver Class Initialized
INFO - 2016-11-03 17:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:17:48 --> Controller Class Initialized
INFO - 2016-11-03 17:17:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:17:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:17:48 --> Model Class Initialized
INFO - 2016-11-03 17:17:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:17:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:17:49 --> Final output sent to browser
DEBUG - 2016-11-03 17:17:49 --> Total execution time: 0.4078
INFO - 2016-11-03 17:18:57 --> Config Class Initialized
INFO - 2016-11-03 17:18:58 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:18:58 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:18:58 --> Utf8 Class Initialized
INFO - 2016-11-03 17:18:58 --> URI Class Initialized
DEBUG - 2016-11-03 17:18:58 --> No URI present. Default controller set.
INFO - 2016-11-03 17:18:58 --> Router Class Initialized
INFO - 2016-11-03 17:18:58 --> Output Class Initialized
INFO - 2016-11-03 17:18:58 --> Security Class Initialized
DEBUG - 2016-11-03 17:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:18:58 --> Input Class Initialized
INFO - 2016-11-03 17:18:58 --> Language Class Initialized
INFO - 2016-11-03 17:18:58 --> Loader Class Initialized
INFO - 2016-11-03 17:18:58 --> Helper loaded: url_helper
INFO - 2016-11-03 17:18:58 --> Helper loaded: form_helper
INFO - 2016-11-03 17:18:58 --> Database Driver Class Initialized
INFO - 2016-11-03 17:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:18:58 --> Controller Class Initialized
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:18:58 --> Model Class Initialized
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:18:58 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:18:58 --> Final output sent to browser
DEBUG - 2016-11-03 17:18:58 --> Total execution time: 1.0892
INFO - 2016-11-03 17:21:09 --> Config Class Initialized
INFO - 2016-11-03 17:21:09 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:21:09 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:21:09 --> Utf8 Class Initialized
INFO - 2016-11-03 17:21:09 --> URI Class Initialized
INFO - 2016-11-03 17:21:09 --> Router Class Initialized
INFO - 2016-11-03 17:21:09 --> Output Class Initialized
INFO - 2016-11-03 17:21:09 --> Security Class Initialized
DEBUG - 2016-11-03 17:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:21:09 --> Input Class Initialized
INFO - 2016-11-03 17:21:09 --> Language Class Initialized
INFO - 2016-11-03 17:21:09 --> Loader Class Initialized
INFO - 2016-11-03 17:21:09 --> Helper loaded: url_helper
INFO - 2016-11-03 17:21:09 --> Helper loaded: form_helper
INFO - 2016-11-03 17:21:09 --> Database Driver Class Initialized
INFO - 2016-11-03 17:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:21:09 --> Controller Class Initialized
INFO - 2016-11-03 17:21:09 --> Form Validation Class Initialized
INFO - 2016-11-03 17:21:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:21:09 --> Final output sent to browser
DEBUG - 2016-11-03 17:21:09 --> Total execution time: 0.3769
INFO - 2016-11-03 17:21:19 --> Config Class Initialized
INFO - 2016-11-03 17:21:19 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:21:19 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:21:19 --> Utf8 Class Initialized
INFO - 2016-11-03 17:21:19 --> URI Class Initialized
INFO - 2016-11-03 17:21:19 --> Router Class Initialized
INFO - 2016-11-03 17:21:19 --> Output Class Initialized
INFO - 2016-11-03 17:21:19 --> Security Class Initialized
DEBUG - 2016-11-03 17:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:21:19 --> Input Class Initialized
INFO - 2016-11-03 17:21:19 --> Language Class Initialized
INFO - 2016-11-03 17:21:19 --> Loader Class Initialized
INFO - 2016-11-03 17:21:19 --> Helper loaded: url_helper
INFO - 2016-11-03 17:21:19 --> Helper loaded: form_helper
INFO - 2016-11-03 17:21:19 --> Database Driver Class Initialized
INFO - 2016-11-03 17:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:21:19 --> Controller Class Initialized
INFO - 2016-11-03 17:21:19 --> Form Validation Class Initialized
INFO - 2016-11-03 17:21:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:21:19 --> Final output sent to browser
DEBUG - 2016-11-03 17:21:19 --> Total execution time: 0.2283
INFO - 2016-11-03 17:21:21 --> Config Class Initialized
INFO - 2016-11-03 17:21:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:21:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:21:21 --> Utf8 Class Initialized
INFO - 2016-11-03 17:21:21 --> URI Class Initialized
INFO - 2016-11-03 17:21:21 --> Router Class Initialized
INFO - 2016-11-03 17:21:21 --> Output Class Initialized
INFO - 2016-11-03 17:21:21 --> Security Class Initialized
DEBUG - 2016-11-03 17:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:21:21 --> Input Class Initialized
INFO - 2016-11-03 17:21:21 --> Language Class Initialized
INFO - 2016-11-03 17:21:21 --> Loader Class Initialized
INFO - 2016-11-03 17:21:21 --> Helper loaded: url_helper
INFO - 2016-11-03 17:21:21 --> Helper loaded: form_helper
INFO - 2016-11-03 17:21:21 --> Database Driver Class Initialized
INFO - 2016-11-03 17:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:21:21 --> Controller Class Initialized
INFO - 2016-11-03 17:21:21 --> Form Validation Class Initialized
INFO - 2016-11-03 17:21:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:21:21 --> Final output sent to browser
DEBUG - 2016-11-03 17:21:21 --> Total execution time: 0.2668
INFO - 2016-11-03 17:21:25 --> Config Class Initialized
INFO - 2016-11-03 17:21:25 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:21:25 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:21:25 --> Utf8 Class Initialized
INFO - 2016-11-03 17:21:25 --> URI Class Initialized
INFO - 2016-11-03 17:21:25 --> Router Class Initialized
INFO - 2016-11-03 17:21:25 --> Output Class Initialized
INFO - 2016-11-03 17:21:25 --> Security Class Initialized
DEBUG - 2016-11-03 17:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:21:25 --> Input Class Initialized
INFO - 2016-11-03 17:21:25 --> Language Class Initialized
INFO - 2016-11-03 17:21:25 --> Loader Class Initialized
INFO - 2016-11-03 17:21:25 --> Helper loaded: url_helper
INFO - 2016-11-03 17:21:25 --> Helper loaded: form_helper
INFO - 2016-11-03 17:21:25 --> Database Driver Class Initialized
INFO - 2016-11-03 17:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:21:25 --> Controller Class Initialized
INFO - 2016-11-03 17:21:25 --> Form Validation Class Initialized
INFO - 2016-11-03 17:21:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:21:25 --> Final output sent to browser
DEBUG - 2016-11-03 17:21:25 --> Total execution time: 0.2376
INFO - 2016-11-03 17:21:54 --> Config Class Initialized
INFO - 2016-11-03 17:21:54 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:21:54 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:21:54 --> Utf8 Class Initialized
INFO - 2016-11-03 17:21:54 --> URI Class Initialized
DEBUG - 2016-11-03 17:21:54 --> No URI present. Default controller set.
INFO - 2016-11-03 17:21:54 --> Router Class Initialized
INFO - 2016-11-03 17:21:54 --> Output Class Initialized
INFO - 2016-11-03 17:21:54 --> Security Class Initialized
DEBUG - 2016-11-03 17:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:21:54 --> Input Class Initialized
INFO - 2016-11-03 17:21:54 --> Language Class Initialized
INFO - 2016-11-03 17:21:54 --> Loader Class Initialized
INFO - 2016-11-03 17:21:55 --> Helper loaded: url_helper
INFO - 2016-11-03 17:21:55 --> Helper loaded: form_helper
INFO - 2016-11-03 17:21:55 --> Database Driver Class Initialized
INFO - 2016-11-03 17:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:21:55 --> Controller Class Initialized
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:21:55 --> Model Class Initialized
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:21:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:21:55 --> Final output sent to browser
DEBUG - 2016-11-03 17:21:55 --> Total execution time: 0.3557
INFO - 2016-11-03 17:22:37 --> Config Class Initialized
INFO - 2016-11-03 17:22:37 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:22:37 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:22:37 --> Utf8 Class Initialized
INFO - 2016-11-03 17:22:37 --> URI Class Initialized
INFO - 2016-11-03 17:22:37 --> Router Class Initialized
INFO - 2016-11-03 17:22:37 --> Output Class Initialized
INFO - 2016-11-03 17:22:37 --> Security Class Initialized
DEBUG - 2016-11-03 17:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:22:37 --> Input Class Initialized
INFO - 2016-11-03 17:22:37 --> Language Class Initialized
INFO - 2016-11-03 17:22:37 --> Loader Class Initialized
INFO - 2016-11-03 17:22:37 --> Helper loaded: url_helper
INFO - 2016-11-03 17:22:37 --> Helper loaded: form_helper
INFO - 2016-11-03 17:22:37 --> Database Driver Class Initialized
INFO - 2016-11-03 17:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:22:37 --> Controller Class Initialized
INFO - 2016-11-03 17:22:37 --> Form Validation Class Initialized
INFO - 2016-11-03 17:22:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:22:37 --> Final output sent to browser
DEBUG - 2016-11-03 17:22:37 --> Total execution time: 0.2074
INFO - 2016-11-03 17:22:38 --> Config Class Initialized
INFO - 2016-11-03 17:22:38 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:22:38 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:22:38 --> Utf8 Class Initialized
INFO - 2016-11-03 17:22:38 --> URI Class Initialized
DEBUG - 2016-11-03 17:22:38 --> No URI present. Default controller set.
INFO - 2016-11-03 17:22:38 --> Router Class Initialized
INFO - 2016-11-03 17:22:38 --> Output Class Initialized
INFO - 2016-11-03 17:22:38 --> Security Class Initialized
DEBUG - 2016-11-03 17:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:22:38 --> Input Class Initialized
INFO - 2016-11-03 17:22:38 --> Language Class Initialized
INFO - 2016-11-03 17:22:38 --> Loader Class Initialized
INFO - 2016-11-03 17:22:38 --> Helper loaded: url_helper
INFO - 2016-11-03 17:22:38 --> Helper loaded: form_helper
INFO - 2016-11-03 17:22:38 --> Database Driver Class Initialized
INFO - 2016-11-03 17:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:22:38 --> Controller Class Initialized
INFO - 2016-11-03 17:22:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:22:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:22:38 --> Model Class Initialized
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:22:39 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:22:39 --> Final output sent to browser
DEBUG - 2016-11-03 17:22:39 --> Total execution time: 0.3794
INFO - 2016-11-03 17:22:42 --> Config Class Initialized
INFO - 2016-11-03 17:22:42 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:22:42 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:22:42 --> Utf8 Class Initialized
INFO - 2016-11-03 17:22:42 --> URI Class Initialized
INFO - 2016-11-03 17:22:42 --> Router Class Initialized
INFO - 2016-11-03 17:22:42 --> Output Class Initialized
INFO - 2016-11-03 17:22:42 --> Security Class Initialized
DEBUG - 2016-11-03 17:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:22:42 --> Input Class Initialized
INFO - 2016-11-03 17:22:42 --> Language Class Initialized
INFO - 2016-11-03 17:22:42 --> Loader Class Initialized
INFO - 2016-11-03 17:22:42 --> Helper loaded: url_helper
INFO - 2016-11-03 17:22:42 --> Helper loaded: form_helper
INFO - 2016-11-03 17:22:42 --> Database Driver Class Initialized
INFO - 2016-11-03 17:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:22:42 --> Controller Class Initialized
INFO - 2016-11-03 17:22:42 --> Form Validation Class Initialized
INFO - 2016-11-03 17:22:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-03 17:22:42 --> Final output sent to browser
DEBUG - 2016-11-03 17:22:42 --> Total execution time: 0.2374
INFO - 2016-11-03 17:22:43 --> Config Class Initialized
INFO - 2016-11-03 17:22:43 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:22:43 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:22:43 --> Utf8 Class Initialized
INFO - 2016-11-03 17:22:43 --> URI Class Initialized
DEBUG - 2016-11-03 17:22:43 --> No URI present. Default controller set.
INFO - 2016-11-03 17:22:43 --> Router Class Initialized
INFO - 2016-11-03 17:22:43 --> Output Class Initialized
INFO - 2016-11-03 17:22:43 --> Security Class Initialized
DEBUG - 2016-11-03 17:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:22:43 --> Input Class Initialized
INFO - 2016-11-03 17:22:43 --> Language Class Initialized
INFO - 2016-11-03 17:22:43 --> Loader Class Initialized
INFO - 2016-11-03 17:22:43 --> Helper loaded: url_helper
INFO - 2016-11-03 17:22:43 --> Helper loaded: form_helper
INFO - 2016-11-03 17:22:43 --> Database Driver Class Initialized
INFO - 2016-11-03 17:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:22:44 --> Controller Class Initialized
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-03 17:22:44 --> Model Class Initialized
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-03 17:22:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:22:44 --> Final output sent to browser
DEBUG - 2016-11-03 17:22:44 --> Total execution time: 0.4008
INFO - 2016-11-03 17:23:02 --> Config Class Initialized
INFO - 2016-11-03 17:23:02 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:23:02 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:23:02 --> Utf8 Class Initialized
INFO - 2016-11-03 17:23:02 --> URI Class Initialized
INFO - 2016-11-03 17:23:02 --> Router Class Initialized
INFO - 2016-11-03 17:23:02 --> Output Class Initialized
INFO - 2016-11-03 17:23:02 --> Security Class Initialized
DEBUG - 2016-11-03 17:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:23:02 --> Input Class Initialized
INFO - 2016-11-03 17:23:02 --> Language Class Initialized
INFO - 2016-11-03 17:23:02 --> Loader Class Initialized
INFO - 2016-11-03 17:23:02 --> Helper loaded: url_helper
INFO - 2016-11-03 17:23:02 --> Helper loaded: form_helper
INFO - 2016-11-03 17:23:02 --> Database Driver Class Initialized
INFO - 2016-11-03 17:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:23:02 --> Controller Class Initialized
DEBUG - 2016-11-03 17:23:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-03 17:23:02 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 98
ERROR - 2016-11-03 17:23:02 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 98
INFO - 2016-11-03 17:23:02 --> Config Class Initialized
INFO - 2016-11-03 17:23:02 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:23:02 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:23:02 --> Utf8 Class Initialized
INFO - 2016-11-03 17:23:02 --> URI Class Initialized
DEBUG - 2016-11-03 17:23:02 --> No URI present. Default controller set.
INFO - 2016-11-03 17:23:02 --> Router Class Initialized
INFO - 2016-11-03 17:23:02 --> Output Class Initialized
INFO - 2016-11-03 17:23:02 --> Security Class Initialized
DEBUG - 2016-11-03 17:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:23:02 --> Input Class Initialized
INFO - 2016-11-03 17:23:02 --> Language Class Initialized
INFO - 2016-11-03 17:23:02 --> Loader Class Initialized
INFO - 2016-11-03 17:23:02 --> Helper loaded: url_helper
INFO - 2016-11-03 17:23:02 --> Helper loaded: form_helper
INFO - 2016-11-03 17:23:02 --> Database Driver Class Initialized
INFO - 2016-11-03 17:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:23:02 --> Controller Class Initialized
INFO - 2016-11-03 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:23:02 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:23:02 --> Final output sent to browser
DEBUG - 2016-11-03 17:23:02 --> Total execution time: 0.2521
INFO - 2016-11-03 17:23:05 --> Config Class Initialized
INFO - 2016-11-03 17:23:05 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:23:05 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:23:05 --> Utf8 Class Initialized
INFO - 2016-11-03 17:23:05 --> URI Class Initialized
DEBUG - 2016-11-03 17:23:05 --> No URI present. Default controller set.
INFO - 2016-11-03 17:23:05 --> Router Class Initialized
INFO - 2016-11-03 17:23:05 --> Output Class Initialized
INFO - 2016-11-03 17:23:05 --> Security Class Initialized
DEBUG - 2016-11-03 17:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:23:05 --> Input Class Initialized
INFO - 2016-11-03 17:23:05 --> Language Class Initialized
INFO - 2016-11-03 17:23:05 --> Loader Class Initialized
INFO - 2016-11-03 17:23:05 --> Helper loaded: url_helper
INFO - 2016-11-03 17:23:05 --> Helper loaded: form_helper
INFO - 2016-11-03 17:23:05 --> Database Driver Class Initialized
INFO - 2016-11-03 17:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:23:05 --> Controller Class Initialized
INFO - 2016-11-03 17:23:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:23:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:23:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:23:05 --> Final output sent to browser
DEBUG - 2016-11-03 17:23:05 --> Total execution time: 0.2393
INFO - 2016-11-03 17:25:11 --> Config Class Initialized
INFO - 2016-11-03 17:25:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:25:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:25:11 --> Utf8 Class Initialized
INFO - 2016-11-03 17:25:11 --> URI Class Initialized
DEBUG - 2016-11-03 17:25:11 --> No URI present. Default controller set.
INFO - 2016-11-03 17:25:11 --> Router Class Initialized
INFO - 2016-11-03 17:25:11 --> Output Class Initialized
INFO - 2016-11-03 17:25:11 --> Security Class Initialized
DEBUG - 2016-11-03 17:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:25:11 --> Input Class Initialized
INFO - 2016-11-03 17:25:11 --> Language Class Initialized
INFO - 2016-11-03 17:25:11 --> Loader Class Initialized
INFO - 2016-11-03 17:25:12 --> Helper loaded: url_helper
INFO - 2016-11-03 17:25:12 --> Helper loaded: form_helper
INFO - 2016-11-03 17:25:12 --> Database Driver Class Initialized
INFO - 2016-11-03 17:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:25:12 --> Controller Class Initialized
INFO - 2016-11-03 17:25:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:25:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:25:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:25:12 --> Final output sent to browser
DEBUG - 2016-11-03 17:25:12 --> Total execution time: 0.2450
INFO - 2016-11-03 17:25:20 --> Config Class Initialized
INFO - 2016-11-03 17:25:20 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:25:21 --> Utf8 Class Initialized
INFO - 2016-11-03 17:25:21 --> URI Class Initialized
DEBUG - 2016-11-03 17:25:21 --> No URI present. Default controller set.
INFO - 2016-11-03 17:25:21 --> Router Class Initialized
INFO - 2016-11-03 17:25:21 --> Output Class Initialized
INFO - 2016-11-03 17:25:21 --> Security Class Initialized
DEBUG - 2016-11-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:25:21 --> Input Class Initialized
INFO - 2016-11-03 17:25:21 --> Language Class Initialized
INFO - 2016-11-03 17:25:21 --> Loader Class Initialized
INFO - 2016-11-03 17:25:21 --> Helper loaded: url_helper
INFO - 2016-11-03 17:25:21 --> Helper loaded: form_helper
INFO - 2016-11-03 17:25:21 --> Database Driver Class Initialized
INFO - 2016-11-03 17:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:25:21 --> Controller Class Initialized
INFO - 2016-11-03 17:25:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:25:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:25:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:25:21 --> Final output sent to browser
DEBUG - 2016-11-03 17:25:21 --> Total execution time: 0.2486
INFO - 2016-11-03 17:26:10 --> Config Class Initialized
INFO - 2016-11-03 17:26:10 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:26:10 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:26:10 --> Utf8 Class Initialized
INFO - 2016-11-03 17:26:10 --> URI Class Initialized
DEBUG - 2016-11-03 17:26:10 --> No URI present. Default controller set.
INFO - 2016-11-03 17:26:10 --> Router Class Initialized
INFO - 2016-11-03 17:26:10 --> Output Class Initialized
INFO - 2016-11-03 17:26:10 --> Security Class Initialized
DEBUG - 2016-11-03 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:26:10 --> Input Class Initialized
INFO - 2016-11-03 17:26:10 --> Language Class Initialized
INFO - 2016-11-03 17:26:10 --> Loader Class Initialized
INFO - 2016-11-03 17:26:10 --> Helper loaded: url_helper
INFO - 2016-11-03 17:26:10 --> Helper loaded: form_helper
INFO - 2016-11-03 17:26:10 --> Database Driver Class Initialized
INFO - 2016-11-03 17:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:26:10 --> Controller Class Initialized
INFO - 2016-11-03 17:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:26:10 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:26:10 --> Final output sent to browser
DEBUG - 2016-11-03 17:26:10 --> Total execution time: 0.2316
INFO - 2016-11-03 17:26:13 --> Config Class Initialized
INFO - 2016-11-03 17:26:13 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:26:13 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:26:13 --> Utf8 Class Initialized
INFO - 2016-11-03 17:26:13 --> URI Class Initialized
DEBUG - 2016-11-03 17:26:13 --> No URI present. Default controller set.
INFO - 2016-11-03 17:26:13 --> Router Class Initialized
INFO - 2016-11-03 17:26:13 --> Output Class Initialized
INFO - 2016-11-03 17:26:13 --> Security Class Initialized
DEBUG - 2016-11-03 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:26:13 --> Input Class Initialized
INFO - 2016-11-03 17:26:13 --> Language Class Initialized
INFO - 2016-11-03 17:26:13 --> Loader Class Initialized
INFO - 2016-11-03 17:26:13 --> Helper loaded: url_helper
INFO - 2016-11-03 17:26:13 --> Helper loaded: form_helper
INFO - 2016-11-03 17:26:13 --> Database Driver Class Initialized
INFO - 2016-11-03 17:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:26:13 --> Controller Class Initialized
INFO - 2016-11-03 17:26:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:26:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:26:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:26:13 --> Final output sent to browser
DEBUG - 2016-11-03 17:26:13 --> Total execution time: 0.2532
INFO - 2016-11-03 17:26:21 --> Config Class Initialized
INFO - 2016-11-03 17:26:21 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:26:21 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:26:21 --> Utf8 Class Initialized
INFO - 2016-11-03 17:26:21 --> URI Class Initialized
DEBUG - 2016-11-03 17:26:21 --> No URI present. Default controller set.
INFO - 2016-11-03 17:26:21 --> Router Class Initialized
INFO - 2016-11-03 17:26:21 --> Output Class Initialized
INFO - 2016-11-03 17:26:21 --> Security Class Initialized
DEBUG - 2016-11-03 17:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:26:21 --> Input Class Initialized
INFO - 2016-11-03 17:26:22 --> Language Class Initialized
INFO - 2016-11-03 17:26:22 --> Loader Class Initialized
INFO - 2016-11-03 17:26:22 --> Helper loaded: url_helper
INFO - 2016-11-03 17:26:22 --> Helper loaded: form_helper
INFO - 2016-11-03 17:26:22 --> Database Driver Class Initialized
INFO - 2016-11-03 17:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:26:22 --> Controller Class Initialized
INFO - 2016-11-03 17:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:26:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:26:22 --> Final output sent to browser
DEBUG - 2016-11-03 17:26:22 --> Total execution time: 0.2533
INFO - 2016-11-03 17:26:49 --> Config Class Initialized
INFO - 2016-11-03 17:26:49 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:26:49 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:26:49 --> Utf8 Class Initialized
INFO - 2016-11-03 17:26:49 --> URI Class Initialized
DEBUG - 2016-11-03 17:26:49 --> No URI present. Default controller set.
INFO - 2016-11-03 17:26:49 --> Router Class Initialized
INFO - 2016-11-03 17:26:49 --> Output Class Initialized
INFO - 2016-11-03 17:26:49 --> Security Class Initialized
DEBUG - 2016-11-03 17:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:26:49 --> Input Class Initialized
INFO - 2016-11-03 17:26:49 --> Language Class Initialized
INFO - 2016-11-03 17:26:49 --> Loader Class Initialized
INFO - 2016-11-03 17:26:49 --> Helper loaded: url_helper
INFO - 2016-11-03 17:26:49 --> Helper loaded: form_helper
INFO - 2016-11-03 17:26:49 --> Database Driver Class Initialized
INFO - 2016-11-03 17:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:26:49 --> Controller Class Initialized
INFO - 2016-11-03 17:26:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:26:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:26:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:26:49 --> Final output sent to browser
DEBUG - 2016-11-03 17:26:49 --> Total execution time: 0.2695
INFO - 2016-11-03 17:27:22 --> Config Class Initialized
INFO - 2016-11-03 17:27:22 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:27:22 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:27:22 --> Utf8 Class Initialized
INFO - 2016-11-03 17:27:22 --> URI Class Initialized
DEBUG - 2016-11-03 17:27:22 --> No URI present. Default controller set.
INFO - 2016-11-03 17:27:22 --> Router Class Initialized
INFO - 2016-11-03 17:27:22 --> Output Class Initialized
INFO - 2016-11-03 17:27:22 --> Security Class Initialized
DEBUG - 2016-11-03 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:27:22 --> Input Class Initialized
INFO - 2016-11-03 17:27:22 --> Language Class Initialized
INFO - 2016-11-03 17:27:22 --> Loader Class Initialized
INFO - 2016-11-03 17:27:22 --> Helper loaded: url_helper
INFO - 2016-11-03 17:27:22 --> Helper loaded: form_helper
INFO - 2016-11-03 17:27:22 --> Database Driver Class Initialized
INFO - 2016-11-03 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:27:22 --> Controller Class Initialized
INFO - 2016-11-03 17:27:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:27:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:27:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:27:22 --> Final output sent to browser
DEBUG - 2016-11-03 17:27:22 --> Total execution time: 0.2447
INFO - 2016-11-03 17:28:11 --> Config Class Initialized
INFO - 2016-11-03 17:28:11 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:28:11 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:28:11 --> Utf8 Class Initialized
INFO - 2016-11-03 17:28:11 --> URI Class Initialized
DEBUG - 2016-11-03 17:28:11 --> No URI present. Default controller set.
INFO - 2016-11-03 17:28:11 --> Router Class Initialized
INFO - 2016-11-03 17:28:11 --> Output Class Initialized
INFO - 2016-11-03 17:28:11 --> Security Class Initialized
DEBUG - 2016-11-03 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:28:11 --> Input Class Initialized
INFO - 2016-11-03 17:28:11 --> Language Class Initialized
INFO - 2016-11-03 17:28:11 --> Loader Class Initialized
INFO - 2016-11-03 17:28:11 --> Helper loaded: url_helper
INFO - 2016-11-03 17:28:11 --> Helper loaded: form_helper
INFO - 2016-11-03 17:28:11 --> Database Driver Class Initialized
INFO - 2016-11-03 17:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:28:11 --> Controller Class Initialized
INFO - 2016-11-03 17:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:28:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:28:11 --> Final output sent to browser
DEBUG - 2016-11-03 17:28:11 --> Total execution time: 0.2563
INFO - 2016-11-03 17:28:12 --> Config Class Initialized
INFO - 2016-11-03 17:28:12 --> Hooks Class Initialized
DEBUG - 2016-11-03 17:28:12 --> UTF-8 Support Enabled
INFO - 2016-11-03 17:28:12 --> Utf8 Class Initialized
INFO - 2016-11-03 17:28:12 --> URI Class Initialized
DEBUG - 2016-11-03 17:28:12 --> No URI present. Default controller set.
INFO - 2016-11-03 17:28:12 --> Router Class Initialized
INFO - 2016-11-03 17:28:12 --> Output Class Initialized
INFO - 2016-11-03 17:28:12 --> Security Class Initialized
DEBUG - 2016-11-03 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-03 17:28:12 --> Input Class Initialized
INFO - 2016-11-03 17:28:12 --> Language Class Initialized
INFO - 2016-11-03 17:28:12 --> Loader Class Initialized
INFO - 2016-11-03 17:28:12 --> Helper loaded: url_helper
INFO - 2016-11-03 17:28:12 --> Helper loaded: form_helper
INFO - 2016-11-03 17:28:12 --> Database Driver Class Initialized
INFO - 2016-11-03 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-03 17:28:12 --> Controller Class Initialized
INFO - 2016-11-03 17:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-03 17:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-03 17:28:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-03 17:28:12 --> Final output sent to browser
DEBUG - 2016-11-03 17:28:12 --> Total execution time: 0.2511
