<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-21 09:50:53 --> Config Class Initialized
INFO - 2016-10-21 09:50:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:50:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:50:53 --> Utf8 Class Initialized
INFO - 2016-10-21 09:50:53 --> URI Class Initialized
DEBUG - 2016-10-21 09:50:53 --> No URI present. Default controller set.
INFO - 2016-10-21 09:50:53 --> Router Class Initialized
INFO - 2016-10-21 09:50:53 --> Output Class Initialized
INFO - 2016-10-21 09:50:53 --> Security Class Initialized
DEBUG - 2016-10-21 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:50:53 --> Input Class Initialized
INFO - 2016-10-21 09:50:53 --> Language Class Initialized
INFO - 2016-10-21 09:50:53 --> Loader Class Initialized
INFO - 2016-10-21 09:50:53 --> Helper loaded: url_helper
INFO - 2016-10-21 09:50:53 --> Helper loaded: form_helper
INFO - 2016-10-21 09:50:53 --> Database Driver Class Initialized
INFO - 2016-10-21 09:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:50:53 --> Controller Class Initialized
INFO - 2016-10-21 09:50:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:50:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 09:50:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:50:53 --> Final output sent to browser
DEBUG - 2016-10-21 09:50:53 --> Total execution time: 0.0092
INFO - 2016-10-21 09:51:20 --> Config Class Initialized
INFO - 2016-10-21 09:51:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:51:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:51:20 --> Utf8 Class Initialized
INFO - 2016-10-21 09:51:20 --> URI Class Initialized
INFO - 2016-10-21 09:51:20 --> Router Class Initialized
INFO - 2016-10-21 09:51:20 --> Output Class Initialized
INFO - 2016-10-21 09:51:20 --> Security Class Initialized
DEBUG - 2016-10-21 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:51:20 --> Input Class Initialized
INFO - 2016-10-21 09:51:20 --> Language Class Initialized
INFO - 2016-10-21 09:51:20 --> Loader Class Initialized
INFO - 2016-10-21 09:51:20 --> Helper loaded: url_helper
INFO - 2016-10-21 09:51:20 --> Helper loaded: form_helper
INFO - 2016-10-21 09:51:20 --> Database Driver Class Initialized
INFO - 2016-10-21 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:51:20 --> Controller Class Initialized
DEBUG - 2016-10-21 09:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 09:51:20 --> Model Class Initialized
INFO - 2016-10-21 09:51:20 --> Final output sent to browser
DEBUG - 2016-10-21 09:51:20 --> Total execution time: 0.0078
INFO - 2016-10-21 09:51:20 --> Config Class Initialized
INFO - 2016-10-21 09:51:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:51:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:51:20 --> Utf8 Class Initialized
INFO - 2016-10-21 09:51:20 --> URI Class Initialized
DEBUG - 2016-10-21 09:51:20 --> No URI present. Default controller set.
INFO - 2016-10-21 09:51:20 --> Router Class Initialized
INFO - 2016-10-21 09:51:20 --> Output Class Initialized
INFO - 2016-10-21 09:51:20 --> Security Class Initialized
DEBUG - 2016-10-21 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:51:20 --> Input Class Initialized
INFO - 2016-10-21 09:51:20 --> Language Class Initialized
INFO - 2016-10-21 09:51:20 --> Loader Class Initialized
INFO - 2016-10-21 09:51:20 --> Helper loaded: url_helper
INFO - 2016-10-21 09:51:20 --> Helper loaded: form_helper
INFO - 2016-10-21 09:51:20 --> Database Driver Class Initialized
INFO - 2016-10-21 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:51:20 --> Controller Class Initialized
INFO - 2016-10-21 09:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:51:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:51:20 --> Final output sent to browser
DEBUG - 2016-10-21 09:51:20 --> Total execution time: 0.0334
INFO - 2016-10-21 09:56:07 --> Config Class Initialized
INFO - 2016-10-21 09:56:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:56:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:56:07 --> Utf8 Class Initialized
INFO - 2016-10-21 09:56:07 --> URI Class Initialized
DEBUG - 2016-10-21 09:56:07 --> No URI present. Default controller set.
INFO - 2016-10-21 09:56:07 --> Router Class Initialized
INFO - 2016-10-21 09:56:07 --> Output Class Initialized
INFO - 2016-10-21 09:56:07 --> Security Class Initialized
DEBUG - 2016-10-21 09:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:56:07 --> Input Class Initialized
INFO - 2016-10-21 09:56:07 --> Language Class Initialized
ERROR - 2016-10-21 09:56:07 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 30
INFO - 2016-10-21 09:56:25 --> Config Class Initialized
INFO - 2016-10-21 09:56:25 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:56:25 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:56:25 --> Utf8 Class Initialized
INFO - 2016-10-21 09:56:25 --> URI Class Initialized
DEBUG - 2016-10-21 09:56:25 --> No URI present. Default controller set.
INFO - 2016-10-21 09:56:25 --> Router Class Initialized
INFO - 2016-10-21 09:56:25 --> Output Class Initialized
INFO - 2016-10-21 09:56:25 --> Security Class Initialized
DEBUG - 2016-10-21 09:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:56:25 --> Input Class Initialized
INFO - 2016-10-21 09:56:25 --> Language Class Initialized
INFO - 2016-10-21 09:56:25 --> Loader Class Initialized
INFO - 2016-10-21 09:56:25 --> Helper loaded: url_helper
INFO - 2016-10-21 09:56:25 --> Helper loaded: form_helper
INFO - 2016-10-21 09:56:25 --> Database Driver Class Initialized
INFO - 2016-10-21 09:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:56:25 --> Controller Class Initialized
INFO - 2016-10-21 09:56:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-21 09:56:25 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php 20
INFO - 2016-10-21 09:56:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-21 09:56:25 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
INFO - 2016-10-21 09:56:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:56:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:56:25 --> Final output sent to browser
DEBUG - 2016-10-21 09:56:25 --> Total execution time: 0.0065
INFO - 2016-10-21 09:56:50 --> Config Class Initialized
INFO - 2016-10-21 09:56:50 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:56:50 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:56:50 --> Utf8 Class Initialized
INFO - 2016-10-21 09:56:50 --> URI Class Initialized
DEBUG - 2016-10-21 09:56:50 --> No URI present. Default controller set.
INFO - 2016-10-21 09:56:50 --> Router Class Initialized
INFO - 2016-10-21 09:56:50 --> Output Class Initialized
INFO - 2016-10-21 09:56:50 --> Security Class Initialized
DEBUG - 2016-10-21 09:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:56:50 --> Input Class Initialized
INFO - 2016-10-21 09:56:50 --> Language Class Initialized
INFO - 2016-10-21 09:56:50 --> Loader Class Initialized
INFO - 2016-10-21 09:56:50 --> Helper loaded: url_helper
INFO - 2016-10-21 09:56:50 --> Helper loaded: form_helper
INFO - 2016-10-21 09:56:50 --> Database Driver Class Initialized
INFO - 2016-10-21 09:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:56:50 --> Controller Class Initialized
INFO - 2016-10-21 09:56:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:56:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-21 09:56:50 --> Severity: Notice --> Array to string conversion /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 3
INFO - 2016-10-21 09:56:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:56:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:56:50 --> Final output sent to browser
DEBUG - 2016-10-21 09:56:50 --> Total execution time: 0.0067
INFO - 2016-10-21 09:57:11 --> Config Class Initialized
INFO - 2016-10-21 09:57:11 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:57:11 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:57:11 --> Utf8 Class Initialized
INFO - 2016-10-21 09:57:11 --> URI Class Initialized
DEBUG - 2016-10-21 09:57:11 --> No URI present. Default controller set.
INFO - 2016-10-21 09:57:11 --> Router Class Initialized
INFO - 2016-10-21 09:57:11 --> Output Class Initialized
INFO - 2016-10-21 09:57:11 --> Security Class Initialized
DEBUG - 2016-10-21 09:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:57:11 --> Input Class Initialized
INFO - 2016-10-21 09:57:11 --> Language Class Initialized
INFO - 2016-10-21 09:57:11 --> Loader Class Initialized
INFO - 2016-10-21 09:57:11 --> Helper loaded: url_helper
INFO - 2016-10-21 09:57:11 --> Helper loaded: form_helper
INFO - 2016-10-21 09:57:11 --> Database Driver Class Initialized
INFO - 2016-10-21 09:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:57:11 --> Controller Class Initialized
INFO - 2016-10-21 09:57:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:57:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:57:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:57:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:57:11 --> Final output sent to browser
DEBUG - 2016-10-21 09:57:11 --> Total execution time: 0.0085
INFO - 2016-10-21 09:59:13 --> Config Class Initialized
INFO - 2016-10-21 09:59:13 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:13 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:13 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:13 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:13 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:13 --> Router Class Initialized
INFO - 2016-10-21 09:59:13 --> Output Class Initialized
INFO - 2016-10-21 09:59:13 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:13 --> Input Class Initialized
INFO - 2016-10-21 09:59:13 --> Language Class Initialized
INFO - 2016-10-21 09:59:13 --> Loader Class Initialized
INFO - 2016-10-21 09:59:13 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:13 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:13 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:13 --> Controller Class Initialized
INFO - 2016-10-21 09:59:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:59:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:59:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:13 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:13 --> Total execution time: 0.0070
INFO - 2016-10-21 09:59:14 --> Config Class Initialized
INFO - 2016-10-21 09:59:14 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:14 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:14 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:14 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:14 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:14 --> Router Class Initialized
INFO - 2016-10-21 09:59:14 --> Output Class Initialized
INFO - 2016-10-21 09:59:14 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:14 --> Input Class Initialized
INFO - 2016-10-21 09:59:14 --> Language Class Initialized
INFO - 2016-10-21 09:59:14 --> Loader Class Initialized
INFO - 2016-10-21 09:59:14 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:14 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:14 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:14 --> Controller Class Initialized
INFO - 2016-10-21 09:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:59:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:14 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:14 --> Total execution time: 0.0064
INFO - 2016-10-21 09:59:18 --> Config Class Initialized
INFO - 2016-10-21 09:59:18 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:18 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:18 --> URI Class Initialized
INFO - 2016-10-21 09:59:18 --> Router Class Initialized
INFO - 2016-10-21 09:59:18 --> Output Class Initialized
INFO - 2016-10-21 09:59:18 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:18 --> Input Class Initialized
INFO - 2016-10-21 09:59:18 --> Language Class Initialized
INFO - 2016-10-21 09:59:18 --> Loader Class Initialized
INFO - 2016-10-21 09:59:18 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:18 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:18 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:18 --> Controller Class Initialized
DEBUG - 2016-10-21 09:59:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 09:59:18 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 09:59:18 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 09:59:18 --> Config Class Initialized
INFO - 2016-10-21 09:59:18 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:18 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:18 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:18 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:18 --> Router Class Initialized
INFO - 2016-10-21 09:59:18 --> Output Class Initialized
INFO - 2016-10-21 09:59:18 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:18 --> Input Class Initialized
INFO - 2016-10-21 09:59:18 --> Language Class Initialized
INFO - 2016-10-21 09:59:18 --> Loader Class Initialized
INFO - 2016-10-21 09:59:18 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:18 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:18 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:18 --> Controller Class Initialized
INFO - 2016-10-21 09:59:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 09:59:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:18 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:18 --> Total execution time: 0.0046
INFO - 2016-10-21 09:59:30 --> Config Class Initialized
INFO - 2016-10-21 09:59:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:30 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:30 --> URI Class Initialized
INFO - 2016-10-21 09:59:30 --> Router Class Initialized
INFO - 2016-10-21 09:59:30 --> Output Class Initialized
INFO - 2016-10-21 09:59:30 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:30 --> Input Class Initialized
INFO - 2016-10-21 09:59:30 --> Language Class Initialized
INFO - 2016-10-21 09:59:30 --> Loader Class Initialized
INFO - 2016-10-21 09:59:30 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:30 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:30 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:30 --> Controller Class Initialized
DEBUG - 2016-10-21 09:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 09:59:30 --> Model Class Initialized
ERROR - 2016-10-21 09:59:30 --> Severity: Notice --> Trying to get property of non-object /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 61
INFO - 2016-10-21 09:59:30 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:30 --> Total execution time: 0.0078
INFO - 2016-10-21 09:59:36 --> Config Class Initialized
INFO - 2016-10-21 09:59:36 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:36 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:36 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:36 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:36 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:36 --> Router Class Initialized
INFO - 2016-10-21 09:59:36 --> Output Class Initialized
INFO - 2016-10-21 09:59:36 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:36 --> Input Class Initialized
INFO - 2016-10-21 09:59:36 --> Language Class Initialized
INFO - 2016-10-21 09:59:36 --> Loader Class Initialized
INFO - 2016-10-21 09:59:36 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:36 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:36 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:36 --> Controller Class Initialized
INFO - 2016-10-21 09:59:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:59:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:59:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:36 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:36 --> Total execution time: 0.0059
INFO - 2016-10-21 09:59:40 --> Config Class Initialized
INFO - 2016-10-21 09:59:40 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:40 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:40 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:40 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:40 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:40 --> Router Class Initialized
INFO - 2016-10-21 09:59:40 --> Output Class Initialized
INFO - 2016-10-21 09:59:40 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:40 --> Input Class Initialized
INFO - 2016-10-21 09:59:40 --> Language Class Initialized
INFO - 2016-10-21 09:59:40 --> Loader Class Initialized
INFO - 2016-10-21 09:59:40 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:40 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:40 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:40 --> Controller Class Initialized
INFO - 2016-10-21 09:59:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:59:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:59:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:40 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:40 --> Total execution time: 0.0092
INFO - 2016-10-21 09:59:41 --> Config Class Initialized
INFO - 2016-10-21 09:59:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:41 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:41 --> URI Class Initialized
INFO - 2016-10-21 09:59:41 --> Router Class Initialized
INFO - 2016-10-21 09:59:41 --> Output Class Initialized
INFO - 2016-10-21 09:59:41 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:41 --> Input Class Initialized
INFO - 2016-10-21 09:59:41 --> Language Class Initialized
INFO - 2016-10-21 09:59:41 --> Loader Class Initialized
INFO - 2016-10-21 09:59:41 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:41 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:41 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:41 --> Controller Class Initialized
DEBUG - 2016-10-21 09:59:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 09:59:41 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 09:59:41 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 09:59:41 --> Config Class Initialized
INFO - 2016-10-21 09:59:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:41 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:41 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:41 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:41 --> Router Class Initialized
INFO - 2016-10-21 09:59:41 --> Output Class Initialized
INFO - 2016-10-21 09:59:41 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:41 --> Input Class Initialized
INFO - 2016-10-21 09:59:41 --> Language Class Initialized
INFO - 2016-10-21 09:59:41 --> Loader Class Initialized
INFO - 2016-10-21 09:59:41 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:41 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:41 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:41 --> Controller Class Initialized
INFO - 2016-10-21 09:59:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 09:59:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:41 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:41 --> Total execution time: 0.0048
INFO - 2016-10-21 09:59:48 --> Config Class Initialized
INFO - 2016-10-21 09:59:48 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:48 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:48 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:48 --> URI Class Initialized
INFO - 2016-10-21 09:59:48 --> Router Class Initialized
INFO - 2016-10-21 09:59:48 --> Output Class Initialized
INFO - 2016-10-21 09:59:48 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:48 --> Input Class Initialized
INFO - 2016-10-21 09:59:48 --> Language Class Initialized
INFO - 2016-10-21 09:59:48 --> Loader Class Initialized
INFO - 2016-10-21 09:59:48 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:48 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:48 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:48 --> Controller Class Initialized
DEBUG - 2016-10-21 09:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 09:59:48 --> Model Class Initialized
ERROR - 2016-10-21 09:59:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 61
INFO - 2016-10-21 09:59:48 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:48 --> Total execution time: 0.0072
INFO - 2016-10-21 09:59:59 --> Config Class Initialized
INFO - 2016-10-21 09:59:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:59 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:59 --> URI Class Initialized
INFO - 2016-10-21 09:59:59 --> Router Class Initialized
INFO - 2016-10-21 09:59:59 --> Output Class Initialized
INFO - 2016-10-21 09:59:59 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:59 --> Input Class Initialized
INFO - 2016-10-21 09:59:59 --> Language Class Initialized
INFO - 2016-10-21 09:59:59 --> Loader Class Initialized
INFO - 2016-10-21 09:59:59 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:59 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:59 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:59 --> Controller Class Initialized
DEBUG - 2016-10-21 09:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 09:59:59 --> Model Class Initialized
INFO - 2016-10-21 09:59:59 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:59 --> Total execution time: 0.0094
INFO - 2016-10-21 09:59:59 --> Config Class Initialized
INFO - 2016-10-21 09:59:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 09:59:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 09:59:59 --> Utf8 Class Initialized
INFO - 2016-10-21 09:59:59 --> URI Class Initialized
DEBUG - 2016-10-21 09:59:59 --> No URI present. Default controller set.
INFO - 2016-10-21 09:59:59 --> Router Class Initialized
INFO - 2016-10-21 09:59:59 --> Output Class Initialized
INFO - 2016-10-21 09:59:59 --> Security Class Initialized
DEBUG - 2016-10-21 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 09:59:59 --> Input Class Initialized
INFO - 2016-10-21 09:59:59 --> Language Class Initialized
INFO - 2016-10-21 09:59:59 --> Loader Class Initialized
INFO - 2016-10-21 09:59:59 --> Helper loaded: url_helper
INFO - 2016-10-21 09:59:59 --> Helper loaded: form_helper
INFO - 2016-10-21 09:59:59 --> Database Driver Class Initialized
INFO - 2016-10-21 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 09:59:59 --> Controller Class Initialized
INFO - 2016-10-21 09:59:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 09:59:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 09:59:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 09:59:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 09:59:59 --> Final output sent to browser
DEBUG - 2016-10-21 09:59:59 --> Total execution time: 0.0049
INFO - 2016-10-21 10:01:41 --> Config Class Initialized
INFO - 2016-10-21 10:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:01:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:01:41 --> Utf8 Class Initialized
INFO - 2016-10-21 10:01:41 --> URI Class Initialized
INFO - 2016-10-21 10:01:41 --> Router Class Initialized
INFO - 2016-10-21 10:01:41 --> Output Class Initialized
INFO - 2016-10-21 10:01:41 --> Security Class Initialized
DEBUG - 2016-10-21 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:01:41 --> Input Class Initialized
INFO - 2016-10-21 10:01:41 --> Language Class Initialized
INFO - 2016-10-21 10:01:41 --> Loader Class Initialized
INFO - 2016-10-21 10:01:41 --> Helper loaded: url_helper
INFO - 2016-10-21 10:01:41 --> Helper loaded: form_helper
INFO - 2016-10-21 10:01:41 --> Database Driver Class Initialized
INFO - 2016-10-21 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:01:41 --> Controller Class Initialized
DEBUG - 2016-10-21 10:01:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 10:01:41 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 10:01:41 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 10:01:41 --> Config Class Initialized
INFO - 2016-10-21 10:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:01:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:01:41 --> Utf8 Class Initialized
INFO - 2016-10-21 10:01:41 --> URI Class Initialized
DEBUG - 2016-10-21 10:01:41 --> No URI present. Default controller set.
INFO - 2016-10-21 10:01:41 --> Router Class Initialized
INFO - 2016-10-21 10:01:41 --> Output Class Initialized
INFO - 2016-10-21 10:01:41 --> Security Class Initialized
DEBUG - 2016-10-21 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:01:41 --> Input Class Initialized
INFO - 2016-10-21 10:01:41 --> Language Class Initialized
INFO - 2016-10-21 10:01:41 --> Loader Class Initialized
INFO - 2016-10-21 10:01:41 --> Helper loaded: url_helper
INFO - 2016-10-21 10:01:41 --> Helper loaded: form_helper
INFO - 2016-10-21 10:01:41 --> Database Driver Class Initialized
INFO - 2016-10-21 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:01:41 --> Controller Class Initialized
INFO - 2016-10-21 10:01:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:01:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 10:01:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:01:41 --> Final output sent to browser
DEBUG - 2016-10-21 10:01:41 --> Total execution time: 0.0045
INFO - 2016-10-21 10:01:47 --> Config Class Initialized
INFO - 2016-10-21 10:01:47 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:01:47 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:01:47 --> Utf8 Class Initialized
INFO - 2016-10-21 10:01:47 --> URI Class Initialized
INFO - 2016-10-21 10:01:47 --> Router Class Initialized
INFO - 2016-10-21 10:01:47 --> Output Class Initialized
INFO - 2016-10-21 10:01:47 --> Security Class Initialized
DEBUG - 2016-10-21 10:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:01:47 --> Input Class Initialized
INFO - 2016-10-21 10:01:47 --> Language Class Initialized
INFO - 2016-10-21 10:01:47 --> Loader Class Initialized
INFO - 2016-10-21 10:01:47 --> Helper loaded: url_helper
INFO - 2016-10-21 10:01:47 --> Helper loaded: form_helper
INFO - 2016-10-21 10:01:47 --> Database Driver Class Initialized
INFO - 2016-10-21 10:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:01:47 --> Controller Class Initialized
DEBUG - 2016-10-21 10:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 10:01:47 --> Model Class Initialized
INFO - 2016-10-21 10:01:47 --> Final output sent to browser
DEBUG - 2016-10-21 10:01:47 --> Total execution time: 0.0098
INFO - 2016-10-21 10:01:47 --> Config Class Initialized
INFO - 2016-10-21 10:01:47 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:01:47 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:01:47 --> Utf8 Class Initialized
INFO - 2016-10-21 10:01:47 --> URI Class Initialized
DEBUG - 2016-10-21 10:01:47 --> No URI present. Default controller set.
INFO - 2016-10-21 10:01:47 --> Router Class Initialized
INFO - 2016-10-21 10:01:47 --> Output Class Initialized
INFO - 2016-10-21 10:01:47 --> Security Class Initialized
DEBUG - 2016-10-21 10:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:01:47 --> Input Class Initialized
INFO - 2016-10-21 10:01:47 --> Language Class Initialized
INFO - 2016-10-21 10:01:47 --> Loader Class Initialized
INFO - 2016-10-21 10:01:47 --> Helper loaded: url_helper
INFO - 2016-10-21 10:01:47 --> Helper loaded: form_helper
INFO - 2016-10-21 10:01:47 --> Database Driver Class Initialized
INFO - 2016-10-21 10:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:01:47 --> Controller Class Initialized
INFO - 2016-10-21 10:01:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:01:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:01:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:01:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:01:47 --> Final output sent to browser
DEBUG - 2016-10-21 10:01:47 --> Total execution time: 0.0049
INFO - 2016-10-21 10:03:15 --> Config Class Initialized
INFO - 2016-10-21 10:03:15 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:03:15 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:03:15 --> Utf8 Class Initialized
INFO - 2016-10-21 10:03:15 --> URI Class Initialized
DEBUG - 2016-10-21 10:03:15 --> No URI present. Default controller set.
INFO - 2016-10-21 10:03:15 --> Router Class Initialized
INFO - 2016-10-21 10:03:15 --> Output Class Initialized
INFO - 2016-10-21 10:03:15 --> Security Class Initialized
DEBUG - 2016-10-21 10:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:03:15 --> Input Class Initialized
INFO - 2016-10-21 10:03:15 --> Language Class Initialized
INFO - 2016-10-21 10:03:15 --> Loader Class Initialized
INFO - 2016-10-21 10:03:15 --> Helper loaded: url_helper
INFO - 2016-10-21 10:03:15 --> Helper loaded: form_helper
INFO - 2016-10-21 10:03:15 --> Database Driver Class Initialized
INFO - 2016-10-21 10:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:03:15 --> Controller Class Initialized
INFO - 2016-10-21 10:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:03:15 --> Final output sent to browser
DEBUG - 2016-10-21 10:03:15 --> Total execution time: 0.0063
INFO - 2016-10-21 10:03:31 --> Config Class Initialized
INFO - 2016-10-21 10:03:31 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:03:31 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:03:31 --> Utf8 Class Initialized
INFO - 2016-10-21 10:03:31 --> URI Class Initialized
DEBUG - 2016-10-21 10:03:31 --> No URI present. Default controller set.
INFO - 2016-10-21 10:03:31 --> Router Class Initialized
INFO - 2016-10-21 10:03:31 --> Output Class Initialized
INFO - 2016-10-21 10:03:31 --> Security Class Initialized
DEBUG - 2016-10-21 10:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:03:31 --> Input Class Initialized
INFO - 2016-10-21 10:03:31 --> Language Class Initialized
INFO - 2016-10-21 10:03:31 --> Loader Class Initialized
INFO - 2016-10-21 10:03:31 --> Helper loaded: url_helper
INFO - 2016-10-21 10:03:31 --> Helper loaded: form_helper
INFO - 2016-10-21 10:03:31 --> Database Driver Class Initialized
INFO - 2016-10-21 10:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:03:31 --> Controller Class Initialized
INFO - 2016-10-21 10:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:03:31 --> Final output sent to browser
DEBUG - 2016-10-21 10:03:31 --> Total execution time: 0.0062
INFO - 2016-10-21 10:11:45 --> Config Class Initialized
INFO - 2016-10-21 10:11:45 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:11:45 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:11:45 --> Utf8 Class Initialized
INFO - 2016-10-21 10:11:45 --> URI Class Initialized
DEBUG - 2016-10-21 10:11:45 --> No URI present. Default controller set.
INFO - 2016-10-21 10:11:45 --> Router Class Initialized
INFO - 2016-10-21 10:11:45 --> Output Class Initialized
INFO - 2016-10-21 10:11:45 --> Security Class Initialized
DEBUG - 2016-10-21 10:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:11:45 --> Input Class Initialized
INFO - 2016-10-21 10:11:45 --> Language Class Initialized
INFO - 2016-10-21 10:11:45 --> Loader Class Initialized
INFO - 2016-10-21 10:11:45 --> Helper loaded: url_helper
INFO - 2016-10-21 10:11:45 --> Helper loaded: form_helper
INFO - 2016-10-21 10:11:45 --> Database Driver Class Initialized
INFO - 2016-10-21 10:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:11:45 --> Controller Class Initialized
INFO - 2016-10-21 10:11:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:11:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:11:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:11:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:11:45 --> Final output sent to browser
DEBUG - 2016-10-21 10:11:45 --> Total execution time: 0.0070
INFO - 2016-10-21 10:12:07 --> Config Class Initialized
INFO - 2016-10-21 10:12:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:12:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:12:07 --> Utf8 Class Initialized
INFO - 2016-10-21 10:12:07 --> URI Class Initialized
DEBUG - 2016-10-21 10:12:07 --> No URI present. Default controller set.
INFO - 2016-10-21 10:12:07 --> Router Class Initialized
INFO - 2016-10-21 10:12:07 --> Output Class Initialized
INFO - 2016-10-21 10:12:07 --> Security Class Initialized
DEBUG - 2016-10-21 10:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:12:07 --> Input Class Initialized
INFO - 2016-10-21 10:12:07 --> Language Class Initialized
INFO - 2016-10-21 10:12:07 --> Loader Class Initialized
INFO - 2016-10-21 10:12:07 --> Helper loaded: url_helper
INFO - 2016-10-21 10:12:07 --> Helper loaded: form_helper
INFO - 2016-10-21 10:12:07 --> Database Driver Class Initialized
INFO - 2016-10-21 10:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:12:07 --> Controller Class Initialized
INFO - 2016-10-21 10:12:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:12:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:12:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:12:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:12:07 --> Final output sent to browser
DEBUG - 2016-10-21 10:12:07 --> Total execution time: 0.0085
INFO - 2016-10-21 10:13:03 --> Config Class Initialized
INFO - 2016-10-21 10:13:03 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:03 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:03 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:03 --> URI Class Initialized
INFO - 2016-10-21 10:13:03 --> Router Class Initialized
INFO - 2016-10-21 10:13:03 --> Output Class Initialized
INFO - 2016-10-21 10:13:03 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:03 --> Input Class Initialized
INFO - 2016-10-21 10:13:03 --> Language Class Initialized
INFO - 2016-10-21 10:13:03 --> Loader Class Initialized
INFO - 2016-10-21 10:13:03 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:03 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:03 --> Controller Class Initialized
DEBUG - 2016-10-21 10:13:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 10:13:03 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 10:13:03 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 10:13:03 --> Config Class Initialized
INFO - 2016-10-21 10:13:03 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:03 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:03 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:03 --> URI Class Initialized
DEBUG - 2016-10-21 10:13:03 --> No URI present. Default controller set.
INFO - 2016-10-21 10:13:03 --> Router Class Initialized
INFO - 2016-10-21 10:13:03 --> Output Class Initialized
INFO - 2016-10-21 10:13:03 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:03 --> Input Class Initialized
INFO - 2016-10-21 10:13:03 --> Language Class Initialized
INFO - 2016-10-21 10:13:03 --> Loader Class Initialized
INFO - 2016-10-21 10:13:03 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:03 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:03 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:03 --> Controller Class Initialized
INFO - 2016-10-21 10:13:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:13:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 10:13:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:13:03 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:03 --> Total execution time: 0.0046
INFO - 2016-10-21 10:13:30 --> Config Class Initialized
INFO - 2016-10-21 10:13:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:30 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:30 --> URI Class Initialized
INFO - 2016-10-21 10:13:30 --> Router Class Initialized
INFO - 2016-10-21 10:13:30 --> Output Class Initialized
INFO - 2016-10-21 10:13:30 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:30 --> Input Class Initialized
INFO - 2016-10-21 10:13:30 --> Language Class Initialized
INFO - 2016-10-21 10:13:30 --> Loader Class Initialized
INFO - 2016-10-21 10:13:30 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:30 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:30 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:30 --> Controller Class Initialized
DEBUG - 2016-10-21 10:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 10:13:30 --> Model Class Initialized
INFO - 2016-10-21 10:13:30 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:30 --> Total execution time: 0.0072
INFO - 2016-10-21 10:13:30 --> Config Class Initialized
INFO - 2016-10-21 10:13:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:30 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:30 --> URI Class Initialized
DEBUG - 2016-10-21 10:13:30 --> No URI present. Default controller set.
INFO - 2016-10-21 10:13:30 --> Router Class Initialized
INFO - 2016-10-21 10:13:30 --> Output Class Initialized
INFO - 2016-10-21 10:13:30 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:30 --> Input Class Initialized
INFO - 2016-10-21 10:13:30 --> Language Class Initialized
INFO - 2016-10-21 10:13:30 --> Loader Class Initialized
INFO - 2016-10-21 10:13:30 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:30 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:30 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:30 --> Controller Class Initialized
INFO - 2016-10-21 10:13:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:13:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:13:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:13:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:13:30 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:30 --> Total execution time: 0.0048
INFO - 2016-10-21 10:13:47 --> Config Class Initialized
INFO - 2016-10-21 10:13:47 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:47 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:47 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:47 --> URI Class Initialized
DEBUG - 2016-10-21 10:13:47 --> No URI present. Default controller set.
INFO - 2016-10-21 10:13:47 --> Router Class Initialized
INFO - 2016-10-21 10:13:47 --> Output Class Initialized
INFO - 2016-10-21 10:13:47 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:47 --> Input Class Initialized
INFO - 2016-10-21 10:13:47 --> Language Class Initialized
INFO - 2016-10-21 10:13:47 --> Loader Class Initialized
INFO - 2016-10-21 10:13:47 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:47 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:47 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:47 --> Controller Class Initialized
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:13:47 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:47 --> Total execution time: 0.0054
INFO - 2016-10-21 10:13:47 --> Config Class Initialized
INFO - 2016-10-21 10:13:47 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:47 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:47 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:47 --> URI Class Initialized
DEBUG - 2016-10-21 10:13:47 --> No URI present. Default controller set.
INFO - 2016-10-21 10:13:47 --> Router Class Initialized
INFO - 2016-10-21 10:13:47 --> Output Class Initialized
INFO - 2016-10-21 10:13:47 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:47 --> Input Class Initialized
INFO - 2016-10-21 10:13:47 --> Language Class Initialized
INFO - 2016-10-21 10:13:47 --> Loader Class Initialized
INFO - 2016-10-21 10:13:47 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:47 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:47 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:47 --> Controller Class Initialized
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:13:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:13:47 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:47 --> Total execution time: 0.0091
INFO - 2016-10-21 10:13:49 --> Config Class Initialized
INFO - 2016-10-21 10:13:49 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:49 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:49 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:49 --> URI Class Initialized
INFO - 2016-10-21 10:13:49 --> Router Class Initialized
INFO - 2016-10-21 10:13:49 --> Output Class Initialized
INFO - 2016-10-21 10:13:49 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:49 --> Input Class Initialized
INFO - 2016-10-21 10:13:49 --> Language Class Initialized
INFO - 2016-10-21 10:13:49 --> Loader Class Initialized
INFO - 2016-10-21 10:13:49 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:49 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:49 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:49 --> Controller Class Initialized
DEBUG - 2016-10-21 10:13:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 10:13:49 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 10:13:49 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 10:13:49 --> Config Class Initialized
INFO - 2016-10-21 10:13:49 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:49 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:49 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:49 --> URI Class Initialized
DEBUG - 2016-10-21 10:13:49 --> No URI present. Default controller set.
INFO - 2016-10-21 10:13:49 --> Router Class Initialized
INFO - 2016-10-21 10:13:49 --> Output Class Initialized
INFO - 2016-10-21 10:13:49 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:49 --> Input Class Initialized
INFO - 2016-10-21 10:13:49 --> Language Class Initialized
INFO - 2016-10-21 10:13:49 --> Loader Class Initialized
INFO - 2016-10-21 10:13:49 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:49 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:49 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:49 --> Controller Class Initialized
INFO - 2016-10-21 10:13:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:13:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 10:13:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:13:49 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:49 --> Total execution time: 0.0045
INFO - 2016-10-21 10:13:57 --> Config Class Initialized
INFO - 2016-10-21 10:13:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:57 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:57 --> URI Class Initialized
INFO - 2016-10-21 10:13:57 --> Router Class Initialized
INFO - 2016-10-21 10:13:57 --> Output Class Initialized
INFO - 2016-10-21 10:13:57 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:57 --> Input Class Initialized
INFO - 2016-10-21 10:13:57 --> Language Class Initialized
INFO - 2016-10-21 10:13:57 --> Loader Class Initialized
INFO - 2016-10-21 10:13:57 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:57 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:57 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:57 --> Controller Class Initialized
DEBUG - 2016-10-21 10:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 10:13:57 --> Model Class Initialized
INFO - 2016-10-21 10:13:57 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:57 --> Total execution time: 0.0062
INFO - 2016-10-21 10:13:57 --> Config Class Initialized
INFO - 2016-10-21 10:13:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:13:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:13:57 --> Utf8 Class Initialized
INFO - 2016-10-21 10:13:57 --> URI Class Initialized
DEBUG - 2016-10-21 10:13:57 --> No URI present. Default controller set.
INFO - 2016-10-21 10:13:57 --> Router Class Initialized
INFO - 2016-10-21 10:13:57 --> Output Class Initialized
INFO - 2016-10-21 10:13:57 --> Security Class Initialized
DEBUG - 2016-10-21 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:13:57 --> Input Class Initialized
INFO - 2016-10-21 10:13:57 --> Language Class Initialized
INFO - 2016-10-21 10:13:57 --> Loader Class Initialized
INFO - 2016-10-21 10:13:57 --> Helper loaded: url_helper
INFO - 2016-10-21 10:13:57 --> Helper loaded: form_helper
INFO - 2016-10-21 10:13:57 --> Database Driver Class Initialized
INFO - 2016-10-21 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:13:57 --> Controller Class Initialized
INFO - 2016-10-21 10:13:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:13:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:13:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:13:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:13:57 --> Final output sent to browser
DEBUG - 2016-10-21 10:13:57 --> Total execution time: 0.0047
INFO - 2016-10-21 10:14:28 --> Config Class Initialized
INFO - 2016-10-21 10:14:28 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:14:28 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:14:28 --> Utf8 Class Initialized
INFO - 2016-10-21 10:14:28 --> URI Class Initialized
INFO - 2016-10-21 10:14:28 --> Router Class Initialized
INFO - 2016-10-21 10:14:28 --> Output Class Initialized
INFO - 2016-10-21 10:14:28 --> Security Class Initialized
DEBUG - 2016-10-21 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:14:28 --> Input Class Initialized
INFO - 2016-10-21 10:14:28 --> Language Class Initialized
INFO - 2016-10-21 10:14:28 --> Loader Class Initialized
INFO - 2016-10-21 10:14:28 --> Helper loaded: url_helper
INFO - 2016-10-21 10:14:28 --> Helper loaded: form_helper
INFO - 2016-10-21 10:14:28 --> Database Driver Class Initialized
INFO - 2016-10-21 10:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:14:28 --> Controller Class Initialized
DEBUG - 2016-10-21 10:14:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 10:14:28 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 10:14:28 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 10:14:28 --> Config Class Initialized
INFO - 2016-10-21 10:14:28 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:14:28 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:14:28 --> Utf8 Class Initialized
INFO - 2016-10-21 10:14:28 --> URI Class Initialized
DEBUG - 2016-10-21 10:14:28 --> No URI present. Default controller set.
INFO - 2016-10-21 10:14:28 --> Router Class Initialized
INFO - 2016-10-21 10:14:28 --> Output Class Initialized
INFO - 2016-10-21 10:14:28 --> Security Class Initialized
DEBUG - 2016-10-21 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:14:28 --> Input Class Initialized
INFO - 2016-10-21 10:14:28 --> Language Class Initialized
INFO - 2016-10-21 10:14:28 --> Loader Class Initialized
INFO - 2016-10-21 10:14:28 --> Helper loaded: url_helper
INFO - 2016-10-21 10:14:28 --> Helper loaded: form_helper
INFO - 2016-10-21 10:14:28 --> Database Driver Class Initialized
INFO - 2016-10-21 10:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:14:28 --> Controller Class Initialized
INFO - 2016-10-21 10:14:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:14:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 10:14:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:14:28 --> Final output sent to browser
DEBUG - 2016-10-21 10:14:28 --> Total execution time: 0.0045
INFO - 2016-10-21 10:14:34 --> Config Class Initialized
INFO - 2016-10-21 10:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:14:34 --> Utf8 Class Initialized
INFO - 2016-10-21 10:14:34 --> URI Class Initialized
INFO - 2016-10-21 10:14:34 --> Router Class Initialized
INFO - 2016-10-21 10:14:34 --> Output Class Initialized
INFO - 2016-10-21 10:14:34 --> Security Class Initialized
DEBUG - 2016-10-21 10:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:14:34 --> Input Class Initialized
INFO - 2016-10-21 10:14:34 --> Language Class Initialized
INFO - 2016-10-21 10:14:34 --> Loader Class Initialized
INFO - 2016-10-21 10:14:34 --> Helper loaded: url_helper
INFO - 2016-10-21 10:14:34 --> Helper loaded: form_helper
INFO - 2016-10-21 10:14:34 --> Database Driver Class Initialized
INFO - 2016-10-21 10:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:14:34 --> Controller Class Initialized
DEBUG - 2016-10-21 10:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 10:14:34 --> Model Class Initialized
INFO - 2016-10-21 10:14:34 --> Final output sent to browser
DEBUG - 2016-10-21 10:14:34 --> Total execution time: 0.0064
INFO - 2016-10-21 10:14:34 --> Config Class Initialized
INFO - 2016-10-21 10:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:14:34 --> Utf8 Class Initialized
INFO - 2016-10-21 10:14:34 --> URI Class Initialized
DEBUG - 2016-10-21 10:14:34 --> No URI present. Default controller set.
INFO - 2016-10-21 10:14:34 --> Router Class Initialized
INFO - 2016-10-21 10:14:34 --> Output Class Initialized
INFO - 2016-10-21 10:14:34 --> Security Class Initialized
DEBUG - 2016-10-21 10:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:14:34 --> Input Class Initialized
INFO - 2016-10-21 10:14:34 --> Language Class Initialized
INFO - 2016-10-21 10:14:34 --> Loader Class Initialized
INFO - 2016-10-21 10:14:34 --> Helper loaded: url_helper
INFO - 2016-10-21 10:14:34 --> Helper loaded: form_helper
INFO - 2016-10-21 10:14:34 --> Database Driver Class Initialized
INFO - 2016-10-21 10:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:14:34 --> Controller Class Initialized
INFO - 2016-10-21 10:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:14:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:14:34 --> Final output sent to browser
DEBUG - 2016-10-21 10:14:34 --> Total execution time: 0.0047
INFO - 2016-10-21 10:15:24 --> Config Class Initialized
INFO - 2016-10-21 10:15:24 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:15:24 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:15:24 --> Utf8 Class Initialized
INFO - 2016-10-21 10:15:24 --> URI Class Initialized
INFO - 2016-10-21 10:15:24 --> Router Class Initialized
INFO - 2016-10-21 10:15:24 --> Output Class Initialized
INFO - 2016-10-21 10:15:24 --> Security Class Initialized
DEBUG - 2016-10-21 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:15:24 --> Input Class Initialized
INFO - 2016-10-21 10:15:24 --> Language Class Initialized
INFO - 2016-10-21 10:15:24 --> Loader Class Initialized
INFO - 2016-10-21 10:15:24 --> Helper loaded: url_helper
INFO - 2016-10-21 10:15:24 --> Helper loaded: form_helper
INFO - 2016-10-21 10:15:24 --> Database Driver Class Initialized
INFO - 2016-10-21 10:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:15:24 --> Controller Class Initialized
DEBUG - 2016-10-21 10:15:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 10:15:24 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 10:15:24 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 10:15:24 --> Config Class Initialized
INFO - 2016-10-21 10:15:24 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:15:24 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:15:24 --> Utf8 Class Initialized
INFO - 2016-10-21 10:15:24 --> URI Class Initialized
DEBUG - 2016-10-21 10:15:24 --> No URI present. Default controller set.
INFO - 2016-10-21 10:15:24 --> Router Class Initialized
INFO - 2016-10-21 10:15:24 --> Output Class Initialized
INFO - 2016-10-21 10:15:24 --> Security Class Initialized
DEBUG - 2016-10-21 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:15:24 --> Input Class Initialized
INFO - 2016-10-21 10:15:24 --> Language Class Initialized
INFO - 2016-10-21 10:15:24 --> Loader Class Initialized
INFO - 2016-10-21 10:15:24 --> Helper loaded: url_helper
INFO - 2016-10-21 10:15:24 --> Helper loaded: form_helper
INFO - 2016-10-21 10:15:24 --> Database Driver Class Initialized
INFO - 2016-10-21 10:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:15:24 --> Controller Class Initialized
INFO - 2016-10-21 10:15:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:15:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 10:15:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:15:24 --> Final output sent to browser
DEBUG - 2016-10-21 10:15:24 --> Total execution time: 0.0171
INFO - 2016-10-21 10:21:43 --> Config Class Initialized
INFO - 2016-10-21 10:21:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:21:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:21:43 --> Utf8 Class Initialized
INFO - 2016-10-21 10:21:43 --> URI Class Initialized
INFO - 2016-10-21 10:21:43 --> Router Class Initialized
INFO - 2016-10-21 10:21:43 --> Output Class Initialized
INFO - 2016-10-21 10:21:43 --> Security Class Initialized
DEBUG - 2016-10-21 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:21:43 --> Input Class Initialized
INFO - 2016-10-21 10:21:43 --> Language Class Initialized
INFO - 2016-10-21 10:21:43 --> Loader Class Initialized
INFO - 2016-10-21 10:21:43 --> Helper loaded: url_helper
INFO - 2016-10-21 10:21:43 --> Helper loaded: form_helper
INFO - 2016-10-21 10:21:43 --> Database Driver Class Initialized
INFO - 2016-10-21 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:21:43 --> Controller Class Initialized
DEBUG - 2016-10-21 10:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 10:21:43 --> Model Class Initialized
INFO - 2016-10-21 10:21:43 --> Final output sent to browser
DEBUG - 2016-10-21 10:21:43 --> Total execution time: 0.0083
INFO - 2016-10-21 10:21:43 --> Config Class Initialized
INFO - 2016-10-21 10:21:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:21:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:21:43 --> Utf8 Class Initialized
INFO - 2016-10-21 10:21:43 --> URI Class Initialized
DEBUG - 2016-10-21 10:21:43 --> No URI present. Default controller set.
INFO - 2016-10-21 10:21:43 --> Router Class Initialized
INFO - 2016-10-21 10:21:43 --> Output Class Initialized
INFO - 2016-10-21 10:21:43 --> Security Class Initialized
DEBUG - 2016-10-21 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:21:43 --> Input Class Initialized
INFO - 2016-10-21 10:21:43 --> Language Class Initialized
INFO - 2016-10-21 10:21:43 --> Loader Class Initialized
INFO - 2016-10-21 10:21:43 --> Helper loaded: url_helper
INFO - 2016-10-21 10:21:43 --> Helper loaded: form_helper
INFO - 2016-10-21 10:21:43 --> Database Driver Class Initialized
INFO - 2016-10-21 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:21:43 --> Controller Class Initialized
INFO - 2016-10-21 10:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 10:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 10:21:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:21:43 --> Final output sent to browser
DEBUG - 2016-10-21 10:21:43 --> Total execution time: 0.0049
INFO - 2016-10-21 10:21:48 --> Config Class Initialized
INFO - 2016-10-21 10:21:48 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:21:48 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:21:48 --> Utf8 Class Initialized
INFO - 2016-10-21 10:21:48 --> URI Class Initialized
INFO - 2016-10-21 10:21:48 --> Router Class Initialized
INFO - 2016-10-21 10:21:48 --> Output Class Initialized
INFO - 2016-10-21 10:21:48 --> Security Class Initialized
DEBUG - 2016-10-21 10:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:21:48 --> Input Class Initialized
INFO - 2016-10-21 10:21:48 --> Language Class Initialized
INFO - 2016-10-21 10:21:48 --> Loader Class Initialized
INFO - 2016-10-21 10:21:48 --> Helper loaded: url_helper
INFO - 2016-10-21 10:21:48 --> Helper loaded: form_helper
INFO - 2016-10-21 10:21:48 --> Database Driver Class Initialized
INFO - 2016-10-21 10:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:21:48 --> Controller Class Initialized
DEBUG - 2016-10-21 10:21:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 10:21:48 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 10:21:48 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 10:21:48 --> Config Class Initialized
INFO - 2016-10-21 10:21:48 --> Hooks Class Initialized
DEBUG - 2016-10-21 10:21:48 --> UTF-8 Support Enabled
INFO - 2016-10-21 10:21:48 --> Utf8 Class Initialized
INFO - 2016-10-21 10:21:48 --> URI Class Initialized
DEBUG - 2016-10-21 10:21:48 --> No URI present. Default controller set.
INFO - 2016-10-21 10:21:48 --> Router Class Initialized
INFO - 2016-10-21 10:21:48 --> Output Class Initialized
INFO - 2016-10-21 10:21:48 --> Security Class Initialized
DEBUG - 2016-10-21 10:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 10:21:48 --> Input Class Initialized
INFO - 2016-10-21 10:21:48 --> Language Class Initialized
INFO - 2016-10-21 10:21:48 --> Loader Class Initialized
INFO - 2016-10-21 10:21:48 --> Helper loaded: url_helper
INFO - 2016-10-21 10:21:48 --> Helper loaded: form_helper
INFO - 2016-10-21 10:21:48 --> Database Driver Class Initialized
INFO - 2016-10-21 10:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 10:21:48 --> Controller Class Initialized
INFO - 2016-10-21 10:21:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 10:21:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 10:21:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 10:21:48 --> Final output sent to browser
DEBUG - 2016-10-21 10:21:48 --> Total execution time: 0.0047
INFO - 2016-10-21 12:44:53 --> Config Class Initialized
INFO - 2016-10-21 12:44:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 12:44:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 12:44:53 --> Utf8 Class Initialized
INFO - 2016-10-21 12:44:53 --> URI Class Initialized
INFO - 2016-10-21 12:44:53 --> Router Class Initialized
INFO - 2016-10-21 12:44:53 --> Output Class Initialized
INFO - 2016-10-21 12:44:53 --> Security Class Initialized
DEBUG - 2016-10-21 12:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 12:44:53 --> Input Class Initialized
INFO - 2016-10-21 12:44:53 --> Language Class Initialized
INFO - 2016-10-21 12:44:53 --> Loader Class Initialized
INFO - 2016-10-21 12:44:53 --> Helper loaded: url_helper
INFO - 2016-10-21 12:44:53 --> Helper loaded: form_helper
INFO - 2016-10-21 12:44:53 --> Database Driver Class Initialized
INFO - 2016-10-21 12:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 12:44:53 --> Controller Class Initialized
DEBUG - 2016-10-21 12:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 12:44:53 --> Model Class Initialized
INFO - 2016-10-21 12:44:53 --> Final output sent to browser
DEBUG - 2016-10-21 12:44:53 --> Total execution time: 0.0756
INFO - 2016-10-21 12:44:59 --> Config Class Initialized
INFO - 2016-10-21 12:44:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 12:44:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 12:44:59 --> Utf8 Class Initialized
INFO - 2016-10-21 12:44:59 --> URI Class Initialized
INFO - 2016-10-21 12:44:59 --> Router Class Initialized
INFO - 2016-10-21 12:44:59 --> Output Class Initialized
INFO - 2016-10-21 12:44:59 --> Security Class Initialized
DEBUG - 2016-10-21 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 12:44:59 --> Input Class Initialized
INFO - 2016-10-21 12:44:59 --> Language Class Initialized
INFO - 2016-10-21 12:44:59 --> Loader Class Initialized
INFO - 2016-10-21 12:44:59 --> Helper loaded: url_helper
INFO - 2016-10-21 12:44:59 --> Helper loaded: form_helper
INFO - 2016-10-21 12:44:59 --> Database Driver Class Initialized
INFO - 2016-10-21 12:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 12:44:59 --> Controller Class Initialized
DEBUG - 2016-10-21 12:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 12:44:59 --> Model Class Initialized
INFO - 2016-10-21 12:44:59 --> Final output sent to browser
DEBUG - 2016-10-21 12:44:59 --> Total execution time: 0.0066
INFO - 2016-10-21 12:44:59 --> Config Class Initialized
INFO - 2016-10-21 12:44:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 12:44:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 12:44:59 --> Utf8 Class Initialized
INFO - 2016-10-21 12:44:59 --> URI Class Initialized
DEBUG - 2016-10-21 12:44:59 --> No URI present. Default controller set.
INFO - 2016-10-21 12:44:59 --> Router Class Initialized
INFO - 2016-10-21 12:44:59 --> Output Class Initialized
INFO - 2016-10-21 12:44:59 --> Security Class Initialized
DEBUG - 2016-10-21 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 12:44:59 --> Input Class Initialized
INFO - 2016-10-21 12:44:59 --> Language Class Initialized
INFO - 2016-10-21 12:44:59 --> Loader Class Initialized
INFO - 2016-10-21 12:44:59 --> Helper loaded: url_helper
INFO - 2016-10-21 12:44:59 --> Helper loaded: form_helper
INFO - 2016-10-21 12:44:59 --> Database Driver Class Initialized
INFO - 2016-10-21 12:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 12:44:59 --> Controller Class Initialized
INFO - 2016-10-21 12:44:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 12:44:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 12:44:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 12:44:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 12:44:59 --> Final output sent to browser
DEBUG - 2016-10-21 12:44:59 --> Total execution time: 0.0141
INFO - 2016-10-21 13:23:36 --> Config Class Initialized
INFO - 2016-10-21 13:23:36 --> Hooks Class Initialized
DEBUG - 2016-10-21 13:23:36 --> UTF-8 Support Enabled
INFO - 2016-10-21 13:23:36 --> Utf8 Class Initialized
INFO - 2016-10-21 13:23:36 --> URI Class Initialized
DEBUG - 2016-10-21 13:23:36 --> No URI present. Default controller set.
INFO - 2016-10-21 13:23:36 --> Router Class Initialized
INFO - 2016-10-21 13:23:36 --> Output Class Initialized
INFO - 2016-10-21 13:23:36 --> Security Class Initialized
DEBUG - 2016-10-21 13:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 13:23:36 --> Input Class Initialized
INFO - 2016-10-21 13:23:36 --> Language Class Initialized
INFO - 2016-10-21 13:23:36 --> Loader Class Initialized
INFO - 2016-10-21 13:23:36 --> Helper loaded: url_helper
INFO - 2016-10-21 13:23:36 --> Helper loaded: form_helper
INFO - 2016-10-21 13:23:36 --> Database Driver Class Initialized
INFO - 2016-10-21 13:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 13:23:36 --> Controller Class Initialized
INFO - 2016-10-21 13:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 13:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 13:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 13:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 13:23:36 --> Final output sent to browser
DEBUG - 2016-10-21 13:23:36 --> Total execution time: 0.0072
INFO - 2016-10-21 13:25:24 --> Config Class Initialized
INFO - 2016-10-21 13:25:24 --> Hooks Class Initialized
DEBUG - 2016-10-21 13:25:24 --> UTF-8 Support Enabled
INFO - 2016-10-21 13:25:24 --> Utf8 Class Initialized
INFO - 2016-10-21 13:25:24 --> URI Class Initialized
INFO - 2016-10-21 13:25:24 --> Router Class Initialized
INFO - 2016-10-21 13:25:24 --> Output Class Initialized
INFO - 2016-10-21 13:25:24 --> Security Class Initialized
DEBUG - 2016-10-21 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 13:25:24 --> Input Class Initialized
INFO - 2016-10-21 13:25:24 --> Language Class Initialized
INFO - 2016-10-21 13:25:24 --> Loader Class Initialized
INFO - 2016-10-21 13:25:24 --> Helper loaded: url_helper
INFO - 2016-10-21 13:25:24 --> Helper loaded: form_helper
INFO - 2016-10-21 13:25:24 --> Database Driver Class Initialized
INFO - 2016-10-21 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 13:25:24 --> Controller Class Initialized
DEBUG - 2016-10-21 13:25:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 13:25:24 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 13:25:24 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 13:25:24 --> Config Class Initialized
INFO - 2016-10-21 13:25:24 --> Hooks Class Initialized
DEBUG - 2016-10-21 13:25:24 --> UTF-8 Support Enabled
INFO - 2016-10-21 13:25:24 --> Utf8 Class Initialized
INFO - 2016-10-21 13:25:24 --> URI Class Initialized
DEBUG - 2016-10-21 13:25:24 --> No URI present. Default controller set.
INFO - 2016-10-21 13:25:24 --> Router Class Initialized
INFO - 2016-10-21 13:25:24 --> Output Class Initialized
INFO - 2016-10-21 13:25:24 --> Security Class Initialized
DEBUG - 2016-10-21 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 13:25:24 --> Input Class Initialized
INFO - 2016-10-21 13:25:24 --> Language Class Initialized
INFO - 2016-10-21 13:25:24 --> Loader Class Initialized
INFO - 2016-10-21 13:25:24 --> Helper loaded: url_helper
INFO - 2016-10-21 13:25:24 --> Helper loaded: form_helper
INFO - 2016-10-21 13:25:24 --> Database Driver Class Initialized
INFO - 2016-10-21 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 13:25:24 --> Controller Class Initialized
INFO - 2016-10-21 13:25:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 13:25:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 13:25:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 13:25:24 --> Final output sent to browser
DEBUG - 2016-10-21 13:25:24 --> Total execution time: 0.0231
INFO - 2016-10-21 13:25:38 --> Config Class Initialized
INFO - 2016-10-21 13:25:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 13:25:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 13:25:38 --> Utf8 Class Initialized
INFO - 2016-10-21 13:25:38 --> URI Class Initialized
INFO - 2016-10-21 13:25:38 --> Router Class Initialized
INFO - 2016-10-21 13:25:38 --> Output Class Initialized
INFO - 2016-10-21 13:25:38 --> Security Class Initialized
DEBUG - 2016-10-21 13:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 13:25:38 --> Input Class Initialized
INFO - 2016-10-21 13:25:38 --> Language Class Initialized
INFO - 2016-10-21 13:25:38 --> Loader Class Initialized
INFO - 2016-10-21 13:25:38 --> Helper loaded: url_helper
INFO - 2016-10-21 13:25:38 --> Helper loaded: form_helper
INFO - 2016-10-21 13:25:38 --> Database Driver Class Initialized
INFO - 2016-10-21 13:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 13:25:38 --> Controller Class Initialized
DEBUG - 2016-10-21 13:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 13:25:38 --> Model Class Initialized
INFO - 2016-10-21 13:25:38 --> Final output sent to browser
DEBUG - 2016-10-21 13:25:38 --> Total execution time: 0.0068
INFO - 2016-10-21 13:25:38 --> Config Class Initialized
INFO - 2016-10-21 13:25:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 13:25:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 13:25:38 --> Utf8 Class Initialized
INFO - 2016-10-21 13:25:38 --> URI Class Initialized
DEBUG - 2016-10-21 13:25:38 --> No URI present. Default controller set.
INFO - 2016-10-21 13:25:38 --> Router Class Initialized
INFO - 2016-10-21 13:25:38 --> Output Class Initialized
INFO - 2016-10-21 13:25:38 --> Security Class Initialized
DEBUG - 2016-10-21 13:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 13:25:38 --> Input Class Initialized
INFO - 2016-10-21 13:25:38 --> Language Class Initialized
INFO - 2016-10-21 13:25:38 --> Loader Class Initialized
INFO - 2016-10-21 13:25:38 --> Helper loaded: url_helper
INFO - 2016-10-21 13:25:38 --> Helper loaded: form_helper
INFO - 2016-10-21 13:25:38 --> Database Driver Class Initialized
INFO - 2016-10-21 13:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 13:25:38 --> Controller Class Initialized
INFO - 2016-10-21 13:25:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 13:25:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 13:25:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 13:25:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 13:25:38 --> Final output sent to browser
DEBUG - 2016-10-21 13:25:38 --> Total execution time: 0.0045
INFO - 2016-10-21 14:20:22 --> Config Class Initialized
INFO - 2016-10-21 14:20:22 --> Hooks Class Initialized
DEBUG - 2016-10-21 14:20:22 --> UTF-8 Support Enabled
INFO - 2016-10-21 14:20:22 --> Utf8 Class Initialized
INFO - 2016-10-21 14:20:22 --> URI Class Initialized
INFO - 2016-10-21 14:20:22 --> Router Class Initialized
INFO - 2016-10-21 14:20:22 --> Output Class Initialized
INFO - 2016-10-21 14:20:22 --> Security Class Initialized
DEBUG - 2016-10-21 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 14:20:22 --> Input Class Initialized
INFO - 2016-10-21 14:20:22 --> Language Class Initialized
INFO - 2016-10-21 14:20:22 --> Loader Class Initialized
INFO - 2016-10-21 14:20:22 --> Helper loaded: url_helper
INFO - 2016-10-21 14:20:22 --> Helper loaded: form_helper
INFO - 2016-10-21 14:20:22 --> Database Driver Class Initialized
INFO - 2016-10-21 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 14:20:22 --> Controller Class Initialized
INFO - 2016-10-21 14:20:22 --> Form Validation Class Initialized
INFO - 2016-10-21 14:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 14:20:22 --> Final output sent to browser
DEBUG - 2016-10-21 14:20:22 --> Total execution time: 0.0420
INFO - 2016-10-21 14:20:24 --> Config Class Initialized
INFO - 2016-10-21 14:20:24 --> Hooks Class Initialized
DEBUG - 2016-10-21 14:20:24 --> UTF-8 Support Enabled
INFO - 2016-10-21 14:20:24 --> Utf8 Class Initialized
INFO - 2016-10-21 14:20:24 --> URI Class Initialized
DEBUG - 2016-10-21 14:20:24 --> No URI present. Default controller set.
INFO - 2016-10-21 14:20:24 --> Router Class Initialized
INFO - 2016-10-21 14:20:24 --> Output Class Initialized
INFO - 2016-10-21 14:20:24 --> Security Class Initialized
DEBUG - 2016-10-21 14:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 14:20:24 --> Input Class Initialized
INFO - 2016-10-21 14:20:24 --> Language Class Initialized
INFO - 2016-10-21 14:20:24 --> Loader Class Initialized
INFO - 2016-10-21 14:20:24 --> Helper loaded: url_helper
INFO - 2016-10-21 14:20:24 --> Helper loaded: form_helper
INFO - 2016-10-21 14:20:24 --> Database Driver Class Initialized
INFO - 2016-10-21 14:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 14:20:24 --> Controller Class Initialized
INFO - 2016-10-21 14:20:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 14:20:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 14:20:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 14:20:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 14:20:24 --> Final output sent to browser
DEBUG - 2016-10-21 14:20:24 --> Total execution time: 0.0055
INFO - 2016-10-21 15:23:42 --> Config Class Initialized
INFO - 2016-10-21 15:23:42 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:23:42 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:23:42 --> Utf8 Class Initialized
INFO - 2016-10-21 15:23:42 --> URI Class Initialized
DEBUG - 2016-10-21 15:23:42 --> No URI present. Default controller set.
INFO - 2016-10-21 15:23:42 --> Router Class Initialized
INFO - 2016-10-21 15:23:42 --> Output Class Initialized
INFO - 2016-10-21 15:23:42 --> Security Class Initialized
DEBUG - 2016-10-21 15:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:23:42 --> Input Class Initialized
INFO - 2016-10-21 15:23:42 --> Language Class Initialized
INFO - 2016-10-21 15:23:42 --> Loader Class Initialized
INFO - 2016-10-21 15:23:42 --> Helper loaded: url_helper
INFO - 2016-10-21 15:23:42 --> Helper loaded: form_helper
INFO - 2016-10-21 15:23:42 --> Database Driver Class Initialized
INFO - 2016-10-21 15:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:23:42 --> Controller Class Initialized
INFO - 2016-10-21 15:23:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 15:23:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 15:23:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 15:23:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 15:23:42 --> Final output sent to browser
DEBUG - 2016-10-21 15:23:42 --> Total execution time: 0.0074
INFO - 2016-10-21 15:31:30 --> Config Class Initialized
INFO - 2016-10-21 15:31:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:30 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:30 --> URI Class Initialized
INFO - 2016-10-21 15:31:30 --> Router Class Initialized
INFO - 2016-10-21 15:31:30 --> Output Class Initialized
INFO - 2016-10-21 15:31:30 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:30 --> Input Class Initialized
INFO - 2016-10-21 15:31:30 --> Language Class Initialized
INFO - 2016-10-21 15:31:30 --> Loader Class Initialized
INFO - 2016-10-21 15:31:30 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:30 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:30 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:30 --> Controller Class Initialized
INFO - 2016-10-21 15:31:30 --> Form Validation Class Initialized
INFO - 2016-10-21 15:31:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 15:31:30 --> Final output sent to browser
DEBUG - 2016-10-21 15:31:30 --> Total execution time: 0.0078
INFO - 2016-10-21 15:31:36 --> Config Class Initialized
INFO - 2016-10-21 15:31:36 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:36 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:36 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:36 --> URI Class Initialized
INFO - 2016-10-21 15:31:36 --> Router Class Initialized
INFO - 2016-10-21 15:31:36 --> Output Class Initialized
INFO - 2016-10-21 15:31:36 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:36 --> Input Class Initialized
INFO - 2016-10-21 15:31:36 --> Language Class Initialized
INFO - 2016-10-21 15:31:36 --> Loader Class Initialized
INFO - 2016-10-21 15:31:36 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:36 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:36 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:36 --> Controller Class Initialized
INFO - 2016-10-21 15:31:36 --> Form Validation Class Initialized
INFO - 2016-10-21 15:31:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 15:31:36 --> Final output sent to browser
DEBUG - 2016-10-21 15:31:36 --> Total execution time: 0.0073
INFO - 2016-10-21 15:31:45 --> Config Class Initialized
INFO - 2016-10-21 15:31:45 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:45 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:45 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:45 --> URI Class Initialized
INFO - 2016-10-21 15:31:45 --> Router Class Initialized
INFO - 2016-10-21 15:31:45 --> Output Class Initialized
INFO - 2016-10-21 15:31:45 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:45 --> Input Class Initialized
INFO - 2016-10-21 15:31:45 --> Language Class Initialized
INFO - 2016-10-21 15:31:45 --> Loader Class Initialized
INFO - 2016-10-21 15:31:45 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:45 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:45 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:45 --> Controller Class Initialized
DEBUG - 2016-10-21 15:31:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 15:31:45 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 15:31:45 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 15:31:45 --> Config Class Initialized
INFO - 2016-10-21 15:31:45 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:45 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:45 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:45 --> URI Class Initialized
DEBUG - 2016-10-21 15:31:45 --> No URI present. Default controller set.
INFO - 2016-10-21 15:31:45 --> Router Class Initialized
INFO - 2016-10-21 15:31:45 --> Output Class Initialized
INFO - 2016-10-21 15:31:45 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:45 --> Input Class Initialized
INFO - 2016-10-21 15:31:45 --> Language Class Initialized
INFO - 2016-10-21 15:31:45 --> Loader Class Initialized
INFO - 2016-10-21 15:31:45 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:45 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:45 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:45 --> Controller Class Initialized
INFO - 2016-10-21 15:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 15:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 15:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 15:31:45 --> Final output sent to browser
DEBUG - 2016-10-21 15:31:45 --> Total execution time: 0.0046
INFO - 2016-10-21 15:31:51 --> Config Class Initialized
INFO - 2016-10-21 15:31:51 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:51 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:51 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:51 --> URI Class Initialized
INFO - 2016-10-21 15:31:51 --> Router Class Initialized
INFO - 2016-10-21 15:31:51 --> Output Class Initialized
INFO - 2016-10-21 15:31:51 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:51 --> Input Class Initialized
INFO - 2016-10-21 15:31:51 --> Language Class Initialized
INFO - 2016-10-21 15:31:51 --> Loader Class Initialized
INFO - 2016-10-21 15:31:51 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:51 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:51 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:51 --> Controller Class Initialized
DEBUG - 2016-10-21 15:31:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 15:31:51 --> Model Class Initialized
INFO - 2016-10-21 15:31:51 --> Final output sent to browser
DEBUG - 2016-10-21 15:31:51 --> Total execution time: 0.0067
INFO - 2016-10-21 15:31:51 --> Config Class Initialized
INFO - 2016-10-21 15:31:51 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:51 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:51 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:51 --> URI Class Initialized
DEBUG - 2016-10-21 15:31:51 --> No URI present. Default controller set.
INFO - 2016-10-21 15:31:51 --> Router Class Initialized
INFO - 2016-10-21 15:31:51 --> Output Class Initialized
INFO - 2016-10-21 15:31:51 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:51 --> Input Class Initialized
INFO - 2016-10-21 15:31:51 --> Language Class Initialized
INFO - 2016-10-21 15:31:51 --> Loader Class Initialized
INFO - 2016-10-21 15:31:51 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:51 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:51 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:51 --> Controller Class Initialized
INFO - 2016-10-21 15:31:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 15:31:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 15:31:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 15:31:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 15:31:51 --> Final output sent to browser
DEBUG - 2016-10-21 15:31:51 --> Total execution time: 0.0049
INFO - 2016-10-21 15:31:55 --> Config Class Initialized
INFO - 2016-10-21 15:31:55 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:55 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:55 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:55 --> URI Class Initialized
INFO - 2016-10-21 15:31:55 --> Router Class Initialized
INFO - 2016-10-21 15:31:55 --> Output Class Initialized
INFO - 2016-10-21 15:31:55 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:55 --> Input Class Initialized
INFO - 2016-10-21 15:31:55 --> Language Class Initialized
INFO - 2016-10-21 15:31:55 --> Loader Class Initialized
INFO - 2016-10-21 15:31:55 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:55 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:55 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:55 --> Controller Class Initialized
DEBUG - 2016-10-21 15:31:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 15:31:55 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 15:31:55 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 15:31:55 --> Config Class Initialized
INFO - 2016-10-21 15:31:55 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:31:55 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:31:55 --> Utf8 Class Initialized
INFO - 2016-10-21 15:31:55 --> URI Class Initialized
DEBUG - 2016-10-21 15:31:55 --> No URI present. Default controller set.
INFO - 2016-10-21 15:31:55 --> Router Class Initialized
INFO - 2016-10-21 15:31:55 --> Output Class Initialized
INFO - 2016-10-21 15:31:55 --> Security Class Initialized
DEBUG - 2016-10-21 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:31:55 --> Input Class Initialized
INFO - 2016-10-21 15:31:55 --> Language Class Initialized
INFO - 2016-10-21 15:31:55 --> Loader Class Initialized
INFO - 2016-10-21 15:31:55 --> Helper loaded: url_helper
INFO - 2016-10-21 15:31:55 --> Helper loaded: form_helper
INFO - 2016-10-21 15:31:55 --> Database Driver Class Initialized
INFO - 2016-10-21 15:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:31:55 --> Controller Class Initialized
INFO - 2016-10-21 15:31:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 15:31:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 15:31:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 15:31:55 --> Final output sent to browser
DEBUG - 2016-10-21 15:31:55 --> Total execution time: 0.0046
INFO - 2016-10-21 15:32:09 --> Config Class Initialized
INFO - 2016-10-21 15:32:09 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:32:09 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:32:09 --> Utf8 Class Initialized
INFO - 2016-10-21 15:32:09 --> URI Class Initialized
INFO - 2016-10-21 15:32:09 --> Router Class Initialized
INFO - 2016-10-21 15:32:09 --> Output Class Initialized
INFO - 2016-10-21 15:32:09 --> Security Class Initialized
DEBUG - 2016-10-21 15:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:32:09 --> Input Class Initialized
INFO - 2016-10-21 15:32:09 --> Language Class Initialized
INFO - 2016-10-21 15:32:09 --> Loader Class Initialized
INFO - 2016-10-21 15:32:09 --> Helper loaded: url_helper
INFO - 2016-10-21 15:32:09 --> Helper loaded: form_helper
INFO - 2016-10-21 15:32:09 --> Database Driver Class Initialized
INFO - 2016-10-21 15:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:32:09 --> Controller Class Initialized
DEBUG - 2016-10-21 15:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 15:32:09 --> Model Class Initialized
INFO - 2016-10-21 15:32:09 --> Final output sent to browser
DEBUG - 2016-10-21 15:32:09 --> Total execution time: 0.0076
INFO - 2016-10-21 15:32:09 --> Config Class Initialized
INFO - 2016-10-21 15:32:09 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:32:09 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:32:09 --> Utf8 Class Initialized
INFO - 2016-10-21 15:32:09 --> URI Class Initialized
DEBUG - 2016-10-21 15:32:09 --> No URI present. Default controller set.
INFO - 2016-10-21 15:32:09 --> Router Class Initialized
INFO - 2016-10-21 15:32:09 --> Output Class Initialized
INFO - 2016-10-21 15:32:09 --> Security Class Initialized
DEBUG - 2016-10-21 15:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:32:09 --> Input Class Initialized
INFO - 2016-10-21 15:32:09 --> Language Class Initialized
INFO - 2016-10-21 15:32:09 --> Loader Class Initialized
INFO - 2016-10-21 15:32:09 --> Helper loaded: url_helper
INFO - 2016-10-21 15:32:09 --> Helper loaded: form_helper
INFO - 2016-10-21 15:32:09 --> Database Driver Class Initialized
INFO - 2016-10-21 15:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:32:09 --> Controller Class Initialized
INFO - 2016-10-21 15:32:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 15:32:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 15:32:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 15:32:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 15:32:09 --> Final output sent to browser
DEBUG - 2016-10-21 15:32:09 --> Total execution time: 0.0047
INFO - 2016-10-21 15:40:38 --> Config Class Initialized
INFO - 2016-10-21 15:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 15:40:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 15:40:38 --> Utf8 Class Initialized
INFO - 2016-10-21 15:40:38 --> URI Class Initialized
DEBUG - 2016-10-21 15:40:38 --> No URI present. Default controller set.
INFO - 2016-10-21 15:40:38 --> Router Class Initialized
INFO - 2016-10-21 15:40:38 --> Output Class Initialized
INFO - 2016-10-21 15:40:38 --> Security Class Initialized
DEBUG - 2016-10-21 15:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 15:40:38 --> Input Class Initialized
INFO - 2016-10-21 15:40:38 --> Language Class Initialized
INFO - 2016-10-21 15:40:38 --> Loader Class Initialized
INFO - 2016-10-21 15:40:38 --> Helper loaded: url_helper
INFO - 2016-10-21 15:40:38 --> Helper loaded: form_helper
INFO - 2016-10-21 15:40:38 --> Database Driver Class Initialized
INFO - 2016-10-21 15:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 15:40:38 --> Controller Class Initialized
INFO - 2016-10-21 15:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 15:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 15:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 15:40:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 15:40:38 --> Final output sent to browser
DEBUG - 2016-10-21 15:40:38 --> Total execution time: 0.0060
INFO - 2016-10-21 16:03:15 --> Config Class Initialized
INFO - 2016-10-21 16:03:15 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:15 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:15 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:15 --> URI Class Initialized
DEBUG - 2016-10-21 16:03:15 --> No URI present. Default controller set.
INFO - 2016-10-21 16:03:15 --> Router Class Initialized
INFO - 2016-10-21 16:03:15 --> Output Class Initialized
INFO - 2016-10-21 16:03:15 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:15 --> Input Class Initialized
INFO - 2016-10-21 16:03:15 --> Language Class Initialized
INFO - 2016-10-21 16:03:15 --> Loader Class Initialized
INFO - 2016-10-21 16:03:15 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:15 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:15 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:15 --> Controller Class Initialized
INFO - 2016-10-21 16:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:03:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:03:15 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:15 --> Total execution time: 0.0066
INFO - 2016-10-21 16:03:21 --> Config Class Initialized
INFO - 2016-10-21 16:03:21 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:21 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:21 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:21 --> URI Class Initialized
INFO - 2016-10-21 16:03:21 --> Router Class Initialized
INFO - 2016-10-21 16:03:21 --> Output Class Initialized
INFO - 2016-10-21 16:03:21 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:21 --> Input Class Initialized
INFO - 2016-10-21 16:03:21 --> Language Class Initialized
INFO - 2016-10-21 16:03:21 --> Loader Class Initialized
INFO - 2016-10-21 16:03:21 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:21 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:21 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:21 --> Controller Class Initialized
DEBUG - 2016-10-21 16:03:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:03:21 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:03:21 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:03:21 --> Config Class Initialized
INFO - 2016-10-21 16:03:21 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:21 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:21 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:21 --> URI Class Initialized
DEBUG - 2016-10-21 16:03:21 --> No URI present. Default controller set.
INFO - 2016-10-21 16:03:21 --> Router Class Initialized
INFO - 2016-10-21 16:03:21 --> Output Class Initialized
INFO - 2016-10-21 16:03:21 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:21 --> Input Class Initialized
INFO - 2016-10-21 16:03:21 --> Language Class Initialized
INFO - 2016-10-21 16:03:21 --> Loader Class Initialized
INFO - 2016-10-21 16:03:21 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:21 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:21 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:21 --> Controller Class Initialized
INFO - 2016-10-21 16:03:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:03:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:03:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:03:21 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:21 --> Total execution time: 0.0046
INFO - 2016-10-21 16:03:41 --> Config Class Initialized
INFO - 2016-10-21 16:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:41 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:41 --> URI Class Initialized
INFO - 2016-10-21 16:03:41 --> Router Class Initialized
INFO - 2016-10-21 16:03:41 --> Output Class Initialized
INFO - 2016-10-21 16:03:41 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:41 --> Input Class Initialized
INFO - 2016-10-21 16:03:41 --> Language Class Initialized
INFO - 2016-10-21 16:03:41 --> Loader Class Initialized
INFO - 2016-10-21 16:03:41 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:41 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:41 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:41 --> Controller Class Initialized
DEBUG - 2016-10-21 16:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:03:41 --> Model Class Initialized
INFO - 2016-10-21 16:03:41 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:41 --> Total execution time: 0.0070
INFO - 2016-10-21 16:03:41 --> Config Class Initialized
INFO - 2016-10-21 16:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:41 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:41 --> URI Class Initialized
DEBUG - 2016-10-21 16:03:41 --> No URI present. Default controller set.
INFO - 2016-10-21 16:03:41 --> Router Class Initialized
INFO - 2016-10-21 16:03:41 --> Output Class Initialized
INFO - 2016-10-21 16:03:41 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:41 --> Input Class Initialized
INFO - 2016-10-21 16:03:41 --> Language Class Initialized
INFO - 2016-10-21 16:03:41 --> Loader Class Initialized
INFO - 2016-10-21 16:03:41 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:41 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:41 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:41 --> Controller Class Initialized
INFO - 2016-10-21 16:03:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:03:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:03:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:03:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:03:41 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:41 --> Total execution time: 0.0044
INFO - 2016-10-21 16:03:45 --> Config Class Initialized
INFO - 2016-10-21 16:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:45 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:45 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:45 --> URI Class Initialized
DEBUG - 2016-10-21 16:03:45 --> No URI present. Default controller set.
INFO - 2016-10-21 16:03:45 --> Router Class Initialized
INFO - 2016-10-21 16:03:45 --> Output Class Initialized
INFO - 2016-10-21 16:03:45 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:45 --> Input Class Initialized
INFO - 2016-10-21 16:03:45 --> Language Class Initialized
INFO - 2016-10-21 16:03:45 --> Loader Class Initialized
INFO - 2016-10-21 16:03:45 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:45 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:45 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:45 --> Controller Class Initialized
INFO - 2016-10-21 16:03:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:03:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:03:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:03:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:03:45 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:45 --> Total execution time: 0.0060
INFO - 2016-10-21 16:03:48 --> Config Class Initialized
INFO - 2016-10-21 16:03:48 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:48 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:48 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:48 --> URI Class Initialized
INFO - 2016-10-21 16:03:48 --> Router Class Initialized
INFO - 2016-10-21 16:03:48 --> Output Class Initialized
INFO - 2016-10-21 16:03:48 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:48 --> Input Class Initialized
INFO - 2016-10-21 16:03:48 --> Language Class Initialized
INFO - 2016-10-21 16:03:48 --> Loader Class Initialized
INFO - 2016-10-21 16:03:48 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:48 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:48 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:48 --> Controller Class Initialized
DEBUG - 2016-10-21 16:03:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:03:48 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:03:48 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:03:48 --> Config Class Initialized
INFO - 2016-10-21 16:03:48 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:48 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:48 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:48 --> URI Class Initialized
DEBUG - 2016-10-21 16:03:48 --> No URI present. Default controller set.
INFO - 2016-10-21 16:03:48 --> Router Class Initialized
INFO - 2016-10-21 16:03:48 --> Output Class Initialized
INFO - 2016-10-21 16:03:48 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:48 --> Input Class Initialized
INFO - 2016-10-21 16:03:48 --> Language Class Initialized
INFO - 2016-10-21 16:03:48 --> Loader Class Initialized
INFO - 2016-10-21 16:03:48 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:48 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:48 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:48 --> Controller Class Initialized
INFO - 2016-10-21 16:03:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:03:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:03:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:03:48 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:48 --> Total execution time: 0.0044
INFO - 2016-10-21 16:03:55 --> Config Class Initialized
INFO - 2016-10-21 16:03:55 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:55 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:55 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:55 --> URI Class Initialized
INFO - 2016-10-21 16:03:55 --> Router Class Initialized
INFO - 2016-10-21 16:03:55 --> Output Class Initialized
INFO - 2016-10-21 16:03:55 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:55 --> Input Class Initialized
INFO - 2016-10-21 16:03:55 --> Language Class Initialized
INFO - 2016-10-21 16:03:55 --> Loader Class Initialized
INFO - 2016-10-21 16:03:55 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:55 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:55 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:55 --> Controller Class Initialized
DEBUG - 2016-10-21 16:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:03:55 --> Model Class Initialized
INFO - 2016-10-21 16:03:55 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:55 --> Total execution time: 0.0070
INFO - 2016-10-21 16:03:59 --> Config Class Initialized
INFO - 2016-10-21 16:03:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:59 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:59 --> URI Class Initialized
INFO - 2016-10-21 16:03:59 --> Router Class Initialized
INFO - 2016-10-21 16:03:59 --> Output Class Initialized
INFO - 2016-10-21 16:03:59 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:59 --> Input Class Initialized
INFO - 2016-10-21 16:03:59 --> Language Class Initialized
INFO - 2016-10-21 16:03:59 --> Loader Class Initialized
INFO - 2016-10-21 16:03:59 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:59 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:59 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:59 --> Controller Class Initialized
DEBUG - 2016-10-21 16:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:03:59 --> Model Class Initialized
INFO - 2016-10-21 16:03:59 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:59 --> Total execution time: 0.0062
INFO - 2016-10-21 16:03:59 --> Config Class Initialized
INFO - 2016-10-21 16:03:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:03:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:03:59 --> Utf8 Class Initialized
INFO - 2016-10-21 16:03:59 --> URI Class Initialized
DEBUG - 2016-10-21 16:03:59 --> No URI present. Default controller set.
INFO - 2016-10-21 16:03:59 --> Router Class Initialized
INFO - 2016-10-21 16:03:59 --> Output Class Initialized
INFO - 2016-10-21 16:03:59 --> Security Class Initialized
DEBUG - 2016-10-21 16:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:03:59 --> Input Class Initialized
INFO - 2016-10-21 16:03:59 --> Language Class Initialized
INFO - 2016-10-21 16:03:59 --> Loader Class Initialized
INFO - 2016-10-21 16:03:59 --> Helper loaded: url_helper
INFO - 2016-10-21 16:03:59 --> Helper loaded: form_helper
INFO - 2016-10-21 16:03:59 --> Database Driver Class Initialized
INFO - 2016-10-21 16:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:03:59 --> Controller Class Initialized
INFO - 2016-10-21 16:03:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:03:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:03:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:03:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:03:59 --> Final output sent to browser
DEBUG - 2016-10-21 16:03:59 --> Total execution time: 0.0047
INFO - 2016-10-21 16:04:46 --> Config Class Initialized
INFO - 2016-10-21 16:04:46 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:04:46 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:04:46 --> Utf8 Class Initialized
INFO - 2016-10-21 16:04:46 --> URI Class Initialized
DEBUG - 2016-10-21 16:04:46 --> No URI present. Default controller set.
INFO - 2016-10-21 16:04:46 --> Router Class Initialized
INFO - 2016-10-21 16:04:46 --> Output Class Initialized
INFO - 2016-10-21 16:04:46 --> Security Class Initialized
DEBUG - 2016-10-21 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:04:46 --> Input Class Initialized
INFO - 2016-10-21 16:04:46 --> Language Class Initialized
INFO - 2016-10-21 16:04:46 --> Loader Class Initialized
INFO - 2016-10-21 16:04:46 --> Helper loaded: url_helper
INFO - 2016-10-21 16:04:46 --> Helper loaded: form_helper
INFO - 2016-10-21 16:04:46 --> Database Driver Class Initialized
INFO - 2016-10-21 16:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:04:46 --> Controller Class Initialized
INFO - 2016-10-21 16:04:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:04:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:04:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:04:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:04:46 --> Final output sent to browser
DEBUG - 2016-10-21 16:04:46 --> Total execution time: 0.0061
INFO - 2016-10-21 16:04:51 --> Config Class Initialized
INFO - 2016-10-21 16:04:51 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:04:51 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:04:51 --> Utf8 Class Initialized
INFO - 2016-10-21 16:04:51 --> URI Class Initialized
INFO - 2016-10-21 16:04:51 --> Router Class Initialized
INFO - 2016-10-21 16:04:51 --> Output Class Initialized
INFO - 2016-10-21 16:04:51 --> Security Class Initialized
DEBUG - 2016-10-21 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:04:51 --> Input Class Initialized
INFO - 2016-10-21 16:04:51 --> Language Class Initialized
INFO - 2016-10-21 16:04:51 --> Loader Class Initialized
INFO - 2016-10-21 16:04:51 --> Helper loaded: url_helper
INFO - 2016-10-21 16:04:51 --> Helper loaded: form_helper
INFO - 2016-10-21 16:04:51 --> Database Driver Class Initialized
INFO - 2016-10-21 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:04:51 --> Controller Class Initialized
DEBUG - 2016-10-21 16:04:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:04:51 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:04:51 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:04:51 --> Config Class Initialized
INFO - 2016-10-21 16:04:51 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:04:51 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:04:51 --> Utf8 Class Initialized
INFO - 2016-10-21 16:04:51 --> URI Class Initialized
DEBUG - 2016-10-21 16:04:51 --> No URI present. Default controller set.
INFO - 2016-10-21 16:04:51 --> Router Class Initialized
INFO - 2016-10-21 16:04:51 --> Output Class Initialized
INFO - 2016-10-21 16:04:51 --> Security Class Initialized
DEBUG - 2016-10-21 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:04:51 --> Input Class Initialized
INFO - 2016-10-21 16:04:51 --> Language Class Initialized
INFO - 2016-10-21 16:04:51 --> Loader Class Initialized
INFO - 2016-10-21 16:04:51 --> Helper loaded: url_helper
INFO - 2016-10-21 16:04:51 --> Helper loaded: form_helper
INFO - 2016-10-21 16:04:51 --> Database Driver Class Initialized
INFO - 2016-10-21 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:04:51 --> Controller Class Initialized
INFO - 2016-10-21 16:04:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:04:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:04:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:04:51 --> Final output sent to browser
DEBUG - 2016-10-21 16:04:51 --> Total execution time: 0.0046
INFO - 2016-10-21 16:04:57 --> Config Class Initialized
INFO - 2016-10-21 16:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:04:57 --> Utf8 Class Initialized
INFO - 2016-10-21 16:04:57 --> URI Class Initialized
INFO - 2016-10-21 16:04:57 --> Router Class Initialized
INFO - 2016-10-21 16:04:57 --> Output Class Initialized
INFO - 2016-10-21 16:04:57 --> Security Class Initialized
DEBUG - 2016-10-21 16:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:04:57 --> Input Class Initialized
INFO - 2016-10-21 16:04:57 --> Language Class Initialized
INFO - 2016-10-21 16:04:57 --> Loader Class Initialized
INFO - 2016-10-21 16:04:57 --> Helper loaded: url_helper
INFO - 2016-10-21 16:04:57 --> Helper loaded: form_helper
INFO - 2016-10-21 16:04:57 --> Database Driver Class Initialized
INFO - 2016-10-21 16:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:04:57 --> Controller Class Initialized
DEBUG - 2016-10-21 16:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:04:57 --> Model Class Initialized
INFO - 2016-10-21 16:04:57 --> Final output sent to browser
DEBUG - 2016-10-21 16:04:57 --> Total execution time: 0.0065
INFO - 2016-10-21 16:04:57 --> Config Class Initialized
INFO - 2016-10-21 16:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:04:57 --> Utf8 Class Initialized
INFO - 2016-10-21 16:04:57 --> URI Class Initialized
DEBUG - 2016-10-21 16:04:57 --> No URI present. Default controller set.
INFO - 2016-10-21 16:04:57 --> Router Class Initialized
INFO - 2016-10-21 16:04:57 --> Output Class Initialized
INFO - 2016-10-21 16:04:57 --> Security Class Initialized
DEBUG - 2016-10-21 16:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:04:57 --> Input Class Initialized
INFO - 2016-10-21 16:04:57 --> Language Class Initialized
INFO - 2016-10-21 16:04:57 --> Loader Class Initialized
INFO - 2016-10-21 16:04:57 --> Helper loaded: url_helper
INFO - 2016-10-21 16:04:57 --> Helper loaded: form_helper
INFO - 2016-10-21 16:04:57 --> Database Driver Class Initialized
INFO - 2016-10-21 16:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:04:57 --> Controller Class Initialized
INFO - 2016-10-21 16:04:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:04:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:04:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:04:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:04:57 --> Final output sent to browser
DEBUG - 2016-10-21 16:04:57 --> Total execution time: 0.0046
INFO - 2016-10-21 16:07:02 --> Config Class Initialized
INFO - 2016-10-21 16:07:02 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:02 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:02 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:02 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:02 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:02 --> Router Class Initialized
INFO - 2016-10-21 16:07:02 --> Output Class Initialized
INFO - 2016-10-21 16:07:02 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:02 --> Input Class Initialized
INFO - 2016-10-21 16:07:02 --> Language Class Initialized
INFO - 2016-10-21 16:07:02 --> Loader Class Initialized
INFO - 2016-10-21 16:07:02 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:02 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:02 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:02 --> Controller Class Initialized
INFO - 2016-10-21 16:07:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:07:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:07:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:02 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:02 --> Total execution time: 0.0061
INFO - 2016-10-21 16:07:03 --> Config Class Initialized
INFO - 2016-10-21 16:07:03 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:03 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:03 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:03 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:03 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:03 --> Router Class Initialized
INFO - 2016-10-21 16:07:03 --> Output Class Initialized
INFO - 2016-10-21 16:07:03 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:03 --> Input Class Initialized
INFO - 2016-10-21 16:07:03 --> Language Class Initialized
INFO - 2016-10-21 16:07:03 --> Loader Class Initialized
INFO - 2016-10-21 16:07:03 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:03 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:03 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:03 --> Controller Class Initialized
INFO - 2016-10-21 16:07:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:07:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:07:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:03 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:03 --> Total execution time: 0.0083
INFO - 2016-10-21 16:07:04 --> Config Class Initialized
INFO - 2016-10-21 16:07:04 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:04 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:04 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:04 --> URI Class Initialized
INFO - 2016-10-21 16:07:04 --> Router Class Initialized
INFO - 2016-10-21 16:07:04 --> Output Class Initialized
INFO - 2016-10-21 16:07:04 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:04 --> Input Class Initialized
INFO - 2016-10-21 16:07:04 --> Language Class Initialized
INFO - 2016-10-21 16:07:04 --> Loader Class Initialized
INFO - 2016-10-21 16:07:04 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:04 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:04 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:04 --> Controller Class Initialized
DEBUG - 2016-10-21 16:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:07:04 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:07:04 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:07:04 --> Config Class Initialized
INFO - 2016-10-21 16:07:04 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:04 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:04 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:04 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:04 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:04 --> Router Class Initialized
INFO - 2016-10-21 16:07:04 --> Output Class Initialized
INFO - 2016-10-21 16:07:04 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:04 --> Input Class Initialized
INFO - 2016-10-21 16:07:04 --> Language Class Initialized
INFO - 2016-10-21 16:07:04 --> Loader Class Initialized
INFO - 2016-10-21 16:07:04 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:04 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:04 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:04 --> Controller Class Initialized
INFO - 2016-10-21 16:07:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:07:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:04 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:04 --> Total execution time: 0.0047
INFO - 2016-10-21 16:07:13 --> Config Class Initialized
INFO - 2016-10-21 16:07:13 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:13 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:13 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:13 --> URI Class Initialized
INFO - 2016-10-21 16:07:13 --> Router Class Initialized
INFO - 2016-10-21 16:07:13 --> Output Class Initialized
INFO - 2016-10-21 16:07:13 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:13 --> Input Class Initialized
INFO - 2016-10-21 16:07:13 --> Language Class Initialized
INFO - 2016-10-21 16:07:13 --> Loader Class Initialized
INFO - 2016-10-21 16:07:13 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:13 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:13 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:13 --> Controller Class Initialized
DEBUG - 2016-10-21 16:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:07:13 --> Model Class Initialized
INFO - 2016-10-21 16:07:13 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:13 --> Total execution time: 0.0075
INFO - 2016-10-21 16:07:13 --> Config Class Initialized
INFO - 2016-10-21 16:07:13 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:13 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:13 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:13 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:13 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:13 --> Router Class Initialized
INFO - 2016-10-21 16:07:13 --> Output Class Initialized
INFO - 2016-10-21 16:07:13 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:13 --> Input Class Initialized
INFO - 2016-10-21 16:07:13 --> Language Class Initialized
INFO - 2016-10-21 16:07:13 --> Loader Class Initialized
INFO - 2016-10-21 16:07:13 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:13 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:13 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:13 --> Controller Class Initialized
INFO - 2016-10-21 16:07:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:07:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:07:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:13 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:13 --> Total execution time: 0.0056
INFO - 2016-10-21 16:07:20 --> Config Class Initialized
INFO - 2016-10-21 16:07:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:20 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:20 --> URI Class Initialized
INFO - 2016-10-21 16:07:20 --> Router Class Initialized
INFO - 2016-10-21 16:07:20 --> Output Class Initialized
INFO - 2016-10-21 16:07:20 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:20 --> Input Class Initialized
INFO - 2016-10-21 16:07:20 --> Language Class Initialized
INFO - 2016-10-21 16:07:20 --> Loader Class Initialized
INFO - 2016-10-21 16:07:20 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:20 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:20 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:20 --> Controller Class Initialized
DEBUG - 2016-10-21 16:07:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:07:20 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:07:20 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:07:20 --> Config Class Initialized
INFO - 2016-10-21 16:07:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:20 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:20 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:20 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:20 --> Router Class Initialized
INFO - 2016-10-21 16:07:20 --> Output Class Initialized
INFO - 2016-10-21 16:07:20 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:20 --> Input Class Initialized
INFO - 2016-10-21 16:07:20 --> Language Class Initialized
INFO - 2016-10-21 16:07:20 --> Loader Class Initialized
INFO - 2016-10-21 16:07:20 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:20 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:20 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:20 --> Controller Class Initialized
INFO - 2016-10-21 16:07:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:07:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:20 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:20 --> Total execution time: 0.0056
INFO - 2016-10-21 16:07:31 --> Config Class Initialized
INFO - 2016-10-21 16:07:31 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:31 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:31 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:31 --> URI Class Initialized
INFO - 2016-10-21 16:07:31 --> Router Class Initialized
INFO - 2016-10-21 16:07:31 --> Output Class Initialized
INFO - 2016-10-21 16:07:31 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:31 --> Input Class Initialized
INFO - 2016-10-21 16:07:31 --> Language Class Initialized
INFO - 2016-10-21 16:07:31 --> Loader Class Initialized
INFO - 2016-10-21 16:07:31 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:31 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:31 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:31 --> Controller Class Initialized
DEBUG - 2016-10-21 16:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:07:31 --> Model Class Initialized
INFO - 2016-10-21 16:07:31 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:31 --> Total execution time: 0.0066
INFO - 2016-10-21 16:07:32 --> Config Class Initialized
INFO - 2016-10-21 16:07:32 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:32 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:32 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:32 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:32 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:32 --> Router Class Initialized
INFO - 2016-10-21 16:07:32 --> Output Class Initialized
INFO - 2016-10-21 16:07:32 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:32 --> Input Class Initialized
INFO - 2016-10-21 16:07:32 --> Language Class Initialized
INFO - 2016-10-21 16:07:32 --> Loader Class Initialized
INFO - 2016-10-21 16:07:32 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:32 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:32 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:32 --> Controller Class Initialized
INFO - 2016-10-21 16:07:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:07:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:07:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:32 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:32 --> Total execution time: 0.0050
INFO - 2016-10-21 16:07:34 --> Config Class Initialized
INFO - 2016-10-21 16:07:34 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:34 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:34 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:34 --> URI Class Initialized
INFO - 2016-10-21 16:07:34 --> Router Class Initialized
INFO - 2016-10-21 16:07:34 --> Output Class Initialized
INFO - 2016-10-21 16:07:34 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:34 --> Input Class Initialized
INFO - 2016-10-21 16:07:34 --> Language Class Initialized
INFO - 2016-10-21 16:07:34 --> Loader Class Initialized
INFO - 2016-10-21 16:07:34 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:34 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:34 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:34 --> Controller Class Initialized
DEBUG - 2016-10-21 16:07:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:07:34 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:07:34 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:07:34 --> Config Class Initialized
INFO - 2016-10-21 16:07:34 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:34 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:34 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:34 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:34 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:34 --> Router Class Initialized
INFO - 2016-10-21 16:07:34 --> Output Class Initialized
INFO - 2016-10-21 16:07:34 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:34 --> Input Class Initialized
INFO - 2016-10-21 16:07:34 --> Language Class Initialized
INFO - 2016-10-21 16:07:34 --> Loader Class Initialized
INFO - 2016-10-21 16:07:34 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:34 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:34 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:34 --> Controller Class Initialized
INFO - 2016-10-21 16:07:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:07:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:34 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:34 --> Total execution time: 0.0051
INFO - 2016-10-21 16:07:40 --> Config Class Initialized
INFO - 2016-10-21 16:07:40 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:40 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:40 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:40 --> URI Class Initialized
INFO - 2016-10-21 16:07:40 --> Router Class Initialized
INFO - 2016-10-21 16:07:40 --> Output Class Initialized
INFO - 2016-10-21 16:07:40 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:40 --> Input Class Initialized
INFO - 2016-10-21 16:07:40 --> Language Class Initialized
INFO - 2016-10-21 16:07:40 --> Loader Class Initialized
INFO - 2016-10-21 16:07:40 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:40 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:40 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:40 --> Controller Class Initialized
DEBUG - 2016-10-21 16:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:07:40 --> Model Class Initialized
INFO - 2016-10-21 16:07:40 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:40 --> Total execution time: 0.0108
INFO - 2016-10-21 16:07:40 --> Config Class Initialized
INFO - 2016-10-21 16:07:40 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:07:40 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:07:40 --> Utf8 Class Initialized
INFO - 2016-10-21 16:07:40 --> URI Class Initialized
DEBUG - 2016-10-21 16:07:40 --> No URI present. Default controller set.
INFO - 2016-10-21 16:07:40 --> Router Class Initialized
INFO - 2016-10-21 16:07:40 --> Output Class Initialized
INFO - 2016-10-21 16:07:40 --> Security Class Initialized
DEBUG - 2016-10-21 16:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:07:40 --> Input Class Initialized
INFO - 2016-10-21 16:07:40 --> Language Class Initialized
INFO - 2016-10-21 16:07:40 --> Loader Class Initialized
INFO - 2016-10-21 16:07:40 --> Helper loaded: url_helper
INFO - 2016-10-21 16:07:40 --> Helper loaded: form_helper
INFO - 2016-10-21 16:07:40 --> Database Driver Class Initialized
INFO - 2016-10-21 16:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:07:40 --> Controller Class Initialized
INFO - 2016-10-21 16:07:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:07:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:07:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:07:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:07:40 --> Final output sent to browser
DEBUG - 2016-10-21 16:07:40 --> Total execution time: 0.0064
INFO - 2016-10-21 16:11:37 --> Config Class Initialized
INFO - 2016-10-21 16:11:37 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:11:37 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:11:37 --> Utf8 Class Initialized
INFO - 2016-10-21 16:11:37 --> URI Class Initialized
DEBUG - 2016-10-21 16:11:37 --> No URI present. Default controller set.
INFO - 2016-10-21 16:11:37 --> Router Class Initialized
INFO - 2016-10-21 16:11:37 --> Output Class Initialized
INFO - 2016-10-21 16:11:37 --> Security Class Initialized
DEBUG - 2016-10-21 16:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:11:37 --> Input Class Initialized
INFO - 2016-10-21 16:11:37 --> Language Class Initialized
INFO - 2016-10-21 16:11:37 --> Loader Class Initialized
INFO - 2016-10-21 16:11:37 --> Helper loaded: url_helper
INFO - 2016-10-21 16:11:37 --> Helper loaded: form_helper
INFO - 2016-10-21 16:11:37 --> Database Driver Class Initialized
INFO - 2016-10-21 16:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:11:37 --> Controller Class Initialized
INFO - 2016-10-21 16:11:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:11:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:11:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:11:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:11:37 --> Final output sent to browser
DEBUG - 2016-10-21 16:11:37 --> Total execution time: 0.0144
INFO - 2016-10-21 16:11:38 --> Config Class Initialized
INFO - 2016-10-21 16:11:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:11:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:11:38 --> Utf8 Class Initialized
INFO - 2016-10-21 16:11:38 --> URI Class Initialized
DEBUG - 2016-10-21 16:11:38 --> No URI present. Default controller set.
INFO - 2016-10-21 16:11:38 --> Router Class Initialized
INFO - 2016-10-21 16:11:38 --> Output Class Initialized
INFO - 2016-10-21 16:11:38 --> Security Class Initialized
DEBUG - 2016-10-21 16:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:11:38 --> Input Class Initialized
INFO - 2016-10-21 16:11:38 --> Language Class Initialized
INFO - 2016-10-21 16:11:38 --> Loader Class Initialized
INFO - 2016-10-21 16:11:38 --> Helper loaded: url_helper
INFO - 2016-10-21 16:11:38 --> Helper loaded: form_helper
INFO - 2016-10-21 16:11:38 --> Database Driver Class Initialized
INFO - 2016-10-21 16:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:11:38 --> Controller Class Initialized
INFO - 2016-10-21 16:11:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:11:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:11:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:11:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:11:38 --> Final output sent to browser
DEBUG - 2016-10-21 16:11:38 --> Total execution time: 0.0082
INFO - 2016-10-21 16:11:40 --> Config Class Initialized
INFO - 2016-10-21 16:11:40 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:11:40 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:11:40 --> Utf8 Class Initialized
INFO - 2016-10-21 16:11:40 --> URI Class Initialized
DEBUG - 2016-10-21 16:11:40 --> No URI present. Default controller set.
INFO - 2016-10-21 16:11:40 --> Router Class Initialized
INFO - 2016-10-21 16:11:40 --> Output Class Initialized
INFO - 2016-10-21 16:11:40 --> Security Class Initialized
DEBUG - 2016-10-21 16:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:11:40 --> Input Class Initialized
INFO - 2016-10-21 16:11:40 --> Language Class Initialized
INFO - 2016-10-21 16:11:40 --> Loader Class Initialized
INFO - 2016-10-21 16:11:40 --> Helper loaded: url_helper
INFO - 2016-10-21 16:11:40 --> Helper loaded: form_helper
INFO - 2016-10-21 16:11:40 --> Database Driver Class Initialized
INFO - 2016-10-21 16:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:11:40 --> Controller Class Initialized
INFO - 2016-10-21 16:11:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:11:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:11:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:11:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:11:40 --> Final output sent to browser
DEBUG - 2016-10-21 16:11:40 --> Total execution time: 0.0086
INFO - 2016-10-21 16:13:32 --> Config Class Initialized
INFO - 2016-10-21 16:13:32 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:13:32 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:13:32 --> Utf8 Class Initialized
INFO - 2016-10-21 16:13:32 --> URI Class Initialized
DEBUG - 2016-10-21 16:13:32 --> No URI present. Default controller set.
INFO - 2016-10-21 16:13:32 --> Router Class Initialized
INFO - 2016-10-21 16:13:32 --> Output Class Initialized
INFO - 2016-10-21 16:13:32 --> Security Class Initialized
DEBUG - 2016-10-21 16:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:13:32 --> Input Class Initialized
INFO - 2016-10-21 16:13:32 --> Language Class Initialized
INFO - 2016-10-21 16:13:32 --> Loader Class Initialized
INFO - 2016-10-21 16:13:32 --> Helper loaded: url_helper
INFO - 2016-10-21 16:13:32 --> Helper loaded: form_helper
INFO - 2016-10-21 16:13:32 --> Database Driver Class Initialized
INFO - 2016-10-21 16:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:13:32 --> Controller Class Initialized
INFO - 2016-10-21 16:13:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:13:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:13:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:13:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:13:32 --> Final output sent to browser
DEBUG - 2016-10-21 16:13:32 --> Total execution time: 0.0093
INFO - 2016-10-21 16:14:22 --> Config Class Initialized
INFO - 2016-10-21 16:14:22 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:14:22 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:14:22 --> Utf8 Class Initialized
INFO - 2016-10-21 16:14:22 --> URI Class Initialized
DEBUG - 2016-10-21 16:14:22 --> No URI present. Default controller set.
INFO - 2016-10-21 16:14:22 --> Router Class Initialized
INFO - 2016-10-21 16:14:22 --> Output Class Initialized
INFO - 2016-10-21 16:14:22 --> Security Class Initialized
DEBUG - 2016-10-21 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:14:22 --> Input Class Initialized
INFO - 2016-10-21 16:14:22 --> Language Class Initialized
INFO - 2016-10-21 16:14:22 --> Loader Class Initialized
INFO - 2016-10-21 16:14:22 --> Helper loaded: url_helper
INFO - 2016-10-21 16:14:22 --> Helper loaded: form_helper
INFO - 2016-10-21 16:14:22 --> Database Driver Class Initialized
INFO - 2016-10-21 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:14:22 --> Controller Class Initialized
INFO - 2016-10-21 16:14:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:14:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
ERROR - 2016-10-21 16:14:22 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 16
INFO - 2016-10-21 16:14:41 --> Config Class Initialized
INFO - 2016-10-21 16:14:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:14:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:14:41 --> Utf8 Class Initialized
INFO - 2016-10-21 16:14:41 --> URI Class Initialized
DEBUG - 2016-10-21 16:14:41 --> No URI present. Default controller set.
INFO - 2016-10-21 16:14:41 --> Router Class Initialized
INFO - 2016-10-21 16:14:41 --> Output Class Initialized
INFO - 2016-10-21 16:14:41 --> Security Class Initialized
DEBUG - 2016-10-21 16:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:14:41 --> Input Class Initialized
INFO - 2016-10-21 16:14:41 --> Language Class Initialized
INFO - 2016-10-21 16:14:41 --> Loader Class Initialized
INFO - 2016-10-21 16:14:41 --> Helper loaded: url_helper
INFO - 2016-10-21 16:14:41 --> Helper loaded: form_helper
INFO - 2016-10-21 16:14:41 --> Database Driver Class Initialized
INFO - 2016-10-21 16:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:14:41 --> Controller Class Initialized
INFO - 2016-10-21 16:14:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:14:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:14:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:14:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:14:41 --> Final output sent to browser
DEBUG - 2016-10-21 16:14:41 --> Total execution time: 0.0090
INFO - 2016-10-21 16:14:44 --> Config Class Initialized
INFO - 2016-10-21 16:14:44 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:14:44 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:14:44 --> Utf8 Class Initialized
INFO - 2016-10-21 16:14:44 --> URI Class Initialized
DEBUG - 2016-10-21 16:14:44 --> No URI present. Default controller set.
INFO - 2016-10-21 16:14:44 --> Router Class Initialized
INFO - 2016-10-21 16:14:44 --> Output Class Initialized
INFO - 2016-10-21 16:14:44 --> Security Class Initialized
DEBUG - 2016-10-21 16:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:14:44 --> Input Class Initialized
INFO - 2016-10-21 16:14:44 --> Language Class Initialized
INFO - 2016-10-21 16:14:44 --> Loader Class Initialized
INFO - 2016-10-21 16:14:44 --> Helper loaded: url_helper
INFO - 2016-10-21 16:14:44 --> Helper loaded: form_helper
INFO - 2016-10-21 16:14:44 --> Database Driver Class Initialized
INFO - 2016-10-21 16:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:14:44 --> Controller Class Initialized
INFO - 2016-10-21 16:14:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:14:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:14:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:14:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:14:44 --> Final output sent to browser
DEBUG - 2016-10-21 16:14:44 --> Total execution time: 0.0058
INFO - 2016-10-21 16:15:05 --> Config Class Initialized
INFO - 2016-10-21 16:15:05 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:05 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:05 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:05 --> URI Class Initialized
DEBUG - 2016-10-21 16:15:05 --> No URI present. Default controller set.
INFO - 2016-10-21 16:15:05 --> Router Class Initialized
INFO - 2016-10-21 16:15:05 --> Output Class Initialized
INFO - 2016-10-21 16:15:05 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:05 --> Input Class Initialized
INFO - 2016-10-21 16:15:05 --> Language Class Initialized
INFO - 2016-10-21 16:15:05 --> Loader Class Initialized
INFO - 2016-10-21 16:15:05 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:05 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:05 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:05 --> Controller Class Initialized
INFO - 2016-10-21 16:15:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:15:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:15:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:15:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:15:05 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:05 --> Total execution time: 0.0061
INFO - 2016-10-21 16:15:07 --> Config Class Initialized
INFO - 2016-10-21 16:15:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:07 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:07 --> URI Class Initialized
DEBUG - 2016-10-21 16:15:07 --> No URI present. Default controller set.
INFO - 2016-10-21 16:15:07 --> Router Class Initialized
INFO - 2016-10-21 16:15:07 --> Output Class Initialized
INFO - 2016-10-21 16:15:07 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:07 --> Input Class Initialized
INFO - 2016-10-21 16:15:07 --> Language Class Initialized
INFO - 2016-10-21 16:15:07 --> Loader Class Initialized
INFO - 2016-10-21 16:15:07 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:07 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:07 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:07 --> Controller Class Initialized
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:15:07 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:07 --> Total execution time: 0.0057
INFO - 2016-10-21 16:15:07 --> Config Class Initialized
INFO - 2016-10-21 16:15:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:07 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:07 --> URI Class Initialized
DEBUG - 2016-10-21 16:15:07 --> No URI present. Default controller set.
INFO - 2016-10-21 16:15:07 --> Router Class Initialized
INFO - 2016-10-21 16:15:07 --> Output Class Initialized
INFO - 2016-10-21 16:15:07 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:07 --> Input Class Initialized
INFO - 2016-10-21 16:15:07 --> Language Class Initialized
INFO - 2016-10-21 16:15:07 --> Loader Class Initialized
INFO - 2016-10-21 16:15:07 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:07 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:07 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:07 --> Controller Class Initialized
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:15:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:15:07 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:07 --> Total execution time: 0.0053
INFO - 2016-10-21 16:15:38 --> Config Class Initialized
INFO - 2016-10-21 16:15:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:38 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:38 --> URI Class Initialized
DEBUG - 2016-10-21 16:15:38 --> No URI present. Default controller set.
INFO - 2016-10-21 16:15:38 --> Router Class Initialized
INFO - 2016-10-21 16:15:38 --> Output Class Initialized
INFO - 2016-10-21 16:15:38 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:38 --> Input Class Initialized
INFO - 2016-10-21 16:15:38 --> Language Class Initialized
INFO - 2016-10-21 16:15:38 --> Loader Class Initialized
INFO - 2016-10-21 16:15:38 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:38 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:38 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:38 --> Controller Class Initialized
INFO - 2016-10-21 16:15:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:15:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:15:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:15:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:15:38 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:38 --> Total execution time: 0.0057
INFO - 2016-10-21 16:15:39 --> Config Class Initialized
INFO - 2016-10-21 16:15:39 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:39 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:39 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:39 --> URI Class Initialized
DEBUG - 2016-10-21 16:15:39 --> No URI present. Default controller set.
INFO - 2016-10-21 16:15:39 --> Router Class Initialized
INFO - 2016-10-21 16:15:39 --> Output Class Initialized
INFO - 2016-10-21 16:15:39 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:39 --> Input Class Initialized
INFO - 2016-10-21 16:15:39 --> Language Class Initialized
INFO - 2016-10-21 16:15:39 --> Loader Class Initialized
INFO - 2016-10-21 16:15:39 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:39 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:39 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:39 --> Controller Class Initialized
INFO - 2016-10-21 16:15:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:15:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:15:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:15:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:15:39 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:39 --> Total execution time: 0.0083
INFO - 2016-10-21 16:15:43 --> Config Class Initialized
INFO - 2016-10-21 16:15:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:43 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:43 --> URI Class Initialized
INFO - 2016-10-21 16:15:43 --> Router Class Initialized
INFO - 2016-10-21 16:15:43 --> Output Class Initialized
INFO - 2016-10-21 16:15:43 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:43 --> Input Class Initialized
INFO - 2016-10-21 16:15:43 --> Language Class Initialized
INFO - 2016-10-21 16:15:43 --> Loader Class Initialized
INFO - 2016-10-21 16:15:43 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:43 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:43 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:43 --> Controller Class Initialized
DEBUG - 2016-10-21 16:15:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:15:43 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:15:43 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:15:43 --> Config Class Initialized
INFO - 2016-10-21 16:15:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:43 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:43 --> URI Class Initialized
DEBUG - 2016-10-21 16:15:43 --> No URI present. Default controller set.
INFO - 2016-10-21 16:15:43 --> Router Class Initialized
INFO - 2016-10-21 16:15:43 --> Output Class Initialized
INFO - 2016-10-21 16:15:43 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:43 --> Input Class Initialized
INFO - 2016-10-21 16:15:43 --> Language Class Initialized
INFO - 2016-10-21 16:15:43 --> Loader Class Initialized
INFO - 2016-10-21 16:15:43 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:43 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:43 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:43 --> Controller Class Initialized
INFO - 2016-10-21 16:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:15:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:15:43 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:43 --> Total execution time: 0.0047
INFO - 2016-10-21 16:15:52 --> Config Class Initialized
INFO - 2016-10-21 16:15:52 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:15:52 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:15:52 --> Utf8 Class Initialized
INFO - 2016-10-21 16:15:52 --> URI Class Initialized
INFO - 2016-10-21 16:15:52 --> Router Class Initialized
INFO - 2016-10-21 16:15:52 --> Output Class Initialized
INFO - 2016-10-21 16:15:52 --> Security Class Initialized
DEBUG - 2016-10-21 16:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:15:52 --> Input Class Initialized
INFO - 2016-10-21 16:15:52 --> Language Class Initialized
INFO - 2016-10-21 16:15:52 --> Loader Class Initialized
INFO - 2016-10-21 16:15:52 --> Helper loaded: url_helper
INFO - 2016-10-21 16:15:52 --> Helper loaded: form_helper
INFO - 2016-10-21 16:15:52 --> Database Driver Class Initialized
INFO - 2016-10-21 16:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:15:52 --> Controller Class Initialized
DEBUG - 2016-10-21 16:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:15:52 --> Model Class Initialized
INFO - 2016-10-21 16:15:52 --> Final output sent to browser
DEBUG - 2016-10-21 16:15:52 --> Total execution time: 0.0070
INFO - 2016-10-21 16:16:05 --> Config Class Initialized
INFO - 2016-10-21 16:16:05 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:16:05 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:16:05 --> Utf8 Class Initialized
INFO - 2016-10-21 16:16:05 --> URI Class Initialized
INFO - 2016-10-21 16:16:05 --> Router Class Initialized
INFO - 2016-10-21 16:16:05 --> Output Class Initialized
INFO - 2016-10-21 16:16:05 --> Security Class Initialized
DEBUG - 2016-10-21 16:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:16:05 --> Input Class Initialized
INFO - 2016-10-21 16:16:05 --> Language Class Initialized
INFO - 2016-10-21 16:16:05 --> Loader Class Initialized
INFO - 2016-10-21 16:16:05 --> Helper loaded: url_helper
INFO - 2016-10-21 16:16:05 --> Helper loaded: form_helper
INFO - 2016-10-21 16:16:05 --> Database Driver Class Initialized
INFO - 2016-10-21 16:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:16:05 --> Controller Class Initialized
DEBUG - 2016-10-21 16:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:16:05 --> Model Class Initialized
INFO - 2016-10-21 16:16:05 --> Final output sent to browser
DEBUG - 2016-10-21 16:16:05 --> Total execution time: 0.0071
INFO - 2016-10-21 16:16:05 --> Config Class Initialized
INFO - 2016-10-21 16:16:05 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:16:05 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:16:05 --> Utf8 Class Initialized
INFO - 2016-10-21 16:16:05 --> URI Class Initialized
DEBUG - 2016-10-21 16:16:05 --> No URI present. Default controller set.
INFO - 2016-10-21 16:16:05 --> Router Class Initialized
INFO - 2016-10-21 16:16:05 --> Output Class Initialized
INFO - 2016-10-21 16:16:05 --> Security Class Initialized
DEBUG - 2016-10-21 16:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:16:05 --> Input Class Initialized
INFO - 2016-10-21 16:16:05 --> Language Class Initialized
INFO - 2016-10-21 16:16:05 --> Loader Class Initialized
INFO - 2016-10-21 16:16:05 --> Helper loaded: url_helper
INFO - 2016-10-21 16:16:05 --> Helper loaded: form_helper
INFO - 2016-10-21 16:16:05 --> Database Driver Class Initialized
INFO - 2016-10-21 16:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:16:05 --> Controller Class Initialized
INFO - 2016-10-21 16:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:16:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:16:05 --> Final output sent to browser
DEBUG - 2016-10-21 16:16:05 --> Total execution time: 0.0048
INFO - 2016-10-21 16:16:11 --> Config Class Initialized
INFO - 2016-10-21 16:16:11 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:16:11 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:16:11 --> Utf8 Class Initialized
INFO - 2016-10-21 16:16:11 --> URI Class Initialized
INFO - 2016-10-21 16:16:11 --> Router Class Initialized
INFO - 2016-10-21 16:16:11 --> Output Class Initialized
INFO - 2016-10-21 16:16:11 --> Security Class Initialized
DEBUG - 2016-10-21 16:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:16:11 --> Input Class Initialized
INFO - 2016-10-21 16:16:11 --> Language Class Initialized
INFO - 2016-10-21 16:16:11 --> Loader Class Initialized
INFO - 2016-10-21 16:16:11 --> Helper loaded: url_helper
INFO - 2016-10-21 16:16:11 --> Helper loaded: form_helper
INFO - 2016-10-21 16:16:11 --> Database Driver Class Initialized
INFO - 2016-10-21 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:16:11 --> Controller Class Initialized
DEBUG - 2016-10-21 16:16:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:16:11 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:16:11 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:16:11 --> Config Class Initialized
INFO - 2016-10-21 16:16:11 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:16:11 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:16:11 --> Utf8 Class Initialized
INFO - 2016-10-21 16:16:11 --> URI Class Initialized
DEBUG - 2016-10-21 16:16:11 --> No URI present. Default controller set.
INFO - 2016-10-21 16:16:11 --> Router Class Initialized
INFO - 2016-10-21 16:16:11 --> Output Class Initialized
INFO - 2016-10-21 16:16:11 --> Security Class Initialized
DEBUG - 2016-10-21 16:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:16:11 --> Input Class Initialized
INFO - 2016-10-21 16:16:11 --> Language Class Initialized
INFO - 2016-10-21 16:16:11 --> Loader Class Initialized
INFO - 2016-10-21 16:16:11 --> Helper loaded: url_helper
INFO - 2016-10-21 16:16:11 --> Helper loaded: form_helper
INFO - 2016-10-21 16:16:11 --> Database Driver Class Initialized
INFO - 2016-10-21 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:16:11 --> Controller Class Initialized
INFO - 2016-10-21 16:16:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:16:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:16:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:16:11 --> Final output sent to browser
DEBUG - 2016-10-21 16:16:11 --> Total execution time: 0.0061
INFO - 2016-10-21 16:16:17 --> Config Class Initialized
INFO - 2016-10-21 16:16:17 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:16:17 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:16:17 --> Utf8 Class Initialized
INFO - 2016-10-21 16:16:17 --> URI Class Initialized
INFO - 2016-10-21 16:16:17 --> Router Class Initialized
INFO - 2016-10-21 16:16:17 --> Output Class Initialized
INFO - 2016-10-21 16:16:17 --> Security Class Initialized
DEBUG - 2016-10-21 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:16:17 --> Input Class Initialized
INFO - 2016-10-21 16:16:17 --> Language Class Initialized
INFO - 2016-10-21 16:16:17 --> Loader Class Initialized
INFO - 2016-10-21 16:16:17 --> Helper loaded: url_helper
INFO - 2016-10-21 16:16:17 --> Helper loaded: form_helper
INFO - 2016-10-21 16:16:17 --> Database Driver Class Initialized
INFO - 2016-10-21 16:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:16:17 --> Controller Class Initialized
DEBUG - 2016-10-21 16:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:16:17 --> Model Class Initialized
INFO - 2016-10-21 16:16:17 --> Final output sent to browser
DEBUG - 2016-10-21 16:16:17 --> Total execution time: 0.0072
INFO - 2016-10-21 16:16:17 --> Config Class Initialized
INFO - 2016-10-21 16:16:17 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:16:17 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:16:17 --> Utf8 Class Initialized
INFO - 2016-10-21 16:16:17 --> URI Class Initialized
DEBUG - 2016-10-21 16:16:17 --> No URI present. Default controller set.
INFO - 2016-10-21 16:16:17 --> Router Class Initialized
INFO - 2016-10-21 16:16:17 --> Output Class Initialized
INFO - 2016-10-21 16:16:17 --> Security Class Initialized
DEBUG - 2016-10-21 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:16:17 --> Input Class Initialized
INFO - 2016-10-21 16:16:17 --> Language Class Initialized
INFO - 2016-10-21 16:16:17 --> Loader Class Initialized
INFO - 2016-10-21 16:16:17 --> Helper loaded: url_helper
INFO - 2016-10-21 16:16:17 --> Helper loaded: form_helper
INFO - 2016-10-21 16:16:17 --> Database Driver Class Initialized
INFO - 2016-10-21 16:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:16:17 --> Controller Class Initialized
INFO - 2016-10-21 16:16:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:16:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:16:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:16:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:16:17 --> Final output sent to browser
DEBUG - 2016-10-21 16:16:17 --> Total execution time: 0.0049
INFO - 2016-10-21 16:17:27 --> Config Class Initialized
INFO - 2016-10-21 16:17:27 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:17:27 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:17:27 --> Utf8 Class Initialized
INFO - 2016-10-21 16:17:27 --> URI Class Initialized
DEBUG - 2016-10-21 16:17:27 --> No URI present. Default controller set.
INFO - 2016-10-21 16:17:27 --> Router Class Initialized
INFO - 2016-10-21 16:17:27 --> Output Class Initialized
INFO - 2016-10-21 16:17:27 --> Security Class Initialized
DEBUG - 2016-10-21 16:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:17:27 --> Input Class Initialized
INFO - 2016-10-21 16:17:27 --> Language Class Initialized
INFO - 2016-10-21 16:17:27 --> Loader Class Initialized
INFO - 2016-10-21 16:17:27 --> Helper loaded: url_helper
INFO - 2016-10-21 16:17:27 --> Helper loaded: form_helper
INFO - 2016-10-21 16:17:27 --> Database Driver Class Initialized
INFO - 2016-10-21 16:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:17:27 --> Controller Class Initialized
INFO - 2016-10-21 16:17:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:17:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:17:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:17:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:17:27 --> Final output sent to browser
DEBUG - 2016-10-21 16:17:27 --> Total execution time: 0.0059
INFO - 2016-10-21 16:17:44 --> Config Class Initialized
INFO - 2016-10-21 16:17:44 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:17:44 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:17:44 --> Utf8 Class Initialized
INFO - 2016-10-21 16:17:44 --> URI Class Initialized
DEBUG - 2016-10-21 16:17:44 --> No URI present. Default controller set.
INFO - 2016-10-21 16:17:44 --> Router Class Initialized
INFO - 2016-10-21 16:17:44 --> Output Class Initialized
INFO - 2016-10-21 16:17:44 --> Security Class Initialized
DEBUG - 2016-10-21 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:17:44 --> Input Class Initialized
INFO - 2016-10-21 16:17:44 --> Language Class Initialized
INFO - 2016-10-21 16:17:44 --> Loader Class Initialized
INFO - 2016-10-21 16:17:44 --> Helper loaded: url_helper
INFO - 2016-10-21 16:17:44 --> Helper loaded: form_helper
INFO - 2016-10-21 16:17:44 --> Database Driver Class Initialized
INFO - 2016-10-21 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:17:44 --> Controller Class Initialized
INFO - 2016-10-21 16:17:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:17:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:17:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:17:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:17:44 --> Final output sent to browser
DEBUG - 2016-10-21 16:17:44 --> Total execution time: 0.0063
INFO - 2016-10-21 16:18:23 --> Config Class Initialized
INFO - 2016-10-21 16:18:23 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:18:23 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:18:23 --> Utf8 Class Initialized
INFO - 2016-10-21 16:18:23 --> URI Class Initialized
DEBUG - 2016-10-21 16:18:23 --> No URI present. Default controller set.
INFO - 2016-10-21 16:18:23 --> Router Class Initialized
INFO - 2016-10-21 16:18:23 --> Output Class Initialized
INFO - 2016-10-21 16:18:23 --> Security Class Initialized
DEBUG - 2016-10-21 16:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:18:23 --> Input Class Initialized
INFO - 2016-10-21 16:18:23 --> Language Class Initialized
INFO - 2016-10-21 16:18:23 --> Loader Class Initialized
INFO - 2016-10-21 16:18:23 --> Helper loaded: url_helper
INFO - 2016-10-21 16:18:23 --> Helper loaded: form_helper
INFO - 2016-10-21 16:18:23 --> Database Driver Class Initialized
INFO - 2016-10-21 16:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:18:23 --> Controller Class Initialized
INFO - 2016-10-21 16:18:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:18:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:18:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:18:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:18:23 --> Final output sent to browser
DEBUG - 2016-10-21 16:18:23 --> Total execution time: 0.0059
INFO - 2016-10-21 16:18:47 --> Config Class Initialized
INFO - 2016-10-21 16:18:47 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:18:47 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:18:47 --> Utf8 Class Initialized
INFO - 2016-10-21 16:18:47 --> URI Class Initialized
DEBUG - 2016-10-21 16:18:47 --> No URI present. Default controller set.
INFO - 2016-10-21 16:18:47 --> Router Class Initialized
INFO - 2016-10-21 16:18:47 --> Output Class Initialized
INFO - 2016-10-21 16:18:47 --> Security Class Initialized
DEBUG - 2016-10-21 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:18:47 --> Input Class Initialized
INFO - 2016-10-21 16:18:47 --> Language Class Initialized
INFO - 2016-10-21 16:18:47 --> Loader Class Initialized
INFO - 2016-10-21 16:18:47 --> Helper loaded: url_helper
INFO - 2016-10-21 16:18:47 --> Helper loaded: form_helper
INFO - 2016-10-21 16:18:47 --> Database Driver Class Initialized
INFO - 2016-10-21 16:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:18:47 --> Controller Class Initialized
INFO - 2016-10-21 16:18:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:18:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:18:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:18:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:18:47 --> Final output sent to browser
DEBUG - 2016-10-21 16:18:47 --> Total execution time: 0.0062
INFO - 2016-10-21 16:21:45 --> Config Class Initialized
INFO - 2016-10-21 16:21:45 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:21:45 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:21:45 --> Utf8 Class Initialized
INFO - 2016-10-21 16:21:45 --> URI Class Initialized
DEBUG - 2016-10-21 16:21:45 --> No URI present. Default controller set.
INFO - 2016-10-21 16:21:45 --> Router Class Initialized
INFO - 2016-10-21 16:21:45 --> Output Class Initialized
INFO - 2016-10-21 16:21:45 --> Security Class Initialized
DEBUG - 2016-10-21 16:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:21:45 --> Input Class Initialized
INFO - 2016-10-21 16:21:45 --> Language Class Initialized
INFO - 2016-10-21 16:21:45 --> Loader Class Initialized
INFO - 2016-10-21 16:21:45 --> Helper loaded: url_helper
INFO - 2016-10-21 16:21:45 --> Helper loaded: form_helper
INFO - 2016-10-21 16:21:45 --> Database Driver Class Initialized
INFO - 2016-10-21 16:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:21:45 --> Controller Class Initialized
INFO - 2016-10-21 16:21:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:21:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:21:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:21:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:21:45 --> Final output sent to browser
DEBUG - 2016-10-21 16:21:45 --> Total execution time: 0.0088
INFO - 2016-10-21 16:24:28 --> Config Class Initialized
INFO - 2016-10-21 16:24:28 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:24:28 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:24:28 --> Utf8 Class Initialized
INFO - 2016-10-21 16:24:28 --> URI Class Initialized
DEBUG - 2016-10-21 16:24:28 --> No URI present. Default controller set.
INFO - 2016-10-21 16:24:28 --> Router Class Initialized
INFO - 2016-10-21 16:24:28 --> Output Class Initialized
INFO - 2016-10-21 16:24:28 --> Security Class Initialized
DEBUG - 2016-10-21 16:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:24:28 --> Input Class Initialized
INFO - 2016-10-21 16:24:28 --> Language Class Initialized
INFO - 2016-10-21 16:24:28 --> Loader Class Initialized
INFO - 2016-10-21 16:24:28 --> Helper loaded: url_helper
INFO - 2016-10-21 16:24:28 --> Helper loaded: form_helper
INFO - 2016-10-21 16:24:28 --> Database Driver Class Initialized
INFO - 2016-10-21 16:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:24:28 --> Controller Class Initialized
INFO - 2016-10-21 16:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:24:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:24:28 --> Final output sent to browser
DEBUG - 2016-10-21 16:24:28 --> Total execution time: 0.0064
INFO - 2016-10-21 16:26:17 --> Config Class Initialized
INFO - 2016-10-21 16:26:17 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:26:17 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:26:17 --> Utf8 Class Initialized
INFO - 2016-10-21 16:26:17 --> URI Class Initialized
DEBUG - 2016-10-21 16:26:17 --> No URI present. Default controller set.
INFO - 2016-10-21 16:26:17 --> Router Class Initialized
INFO - 2016-10-21 16:26:17 --> Output Class Initialized
INFO - 2016-10-21 16:26:17 --> Security Class Initialized
DEBUG - 2016-10-21 16:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:26:17 --> Input Class Initialized
INFO - 2016-10-21 16:26:17 --> Language Class Initialized
INFO - 2016-10-21 16:26:17 --> Loader Class Initialized
INFO - 2016-10-21 16:26:17 --> Helper loaded: url_helper
INFO - 2016-10-21 16:26:17 --> Helper loaded: form_helper
INFO - 2016-10-21 16:26:17 --> Database Driver Class Initialized
INFO - 2016-10-21 16:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:26:17 --> Controller Class Initialized
INFO - 2016-10-21 16:26:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:26:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:26:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:26:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:26:17 --> Final output sent to browser
DEBUG - 2016-10-21 16:26:17 --> Total execution time: 0.0055
INFO - 2016-10-21 16:27:26 --> Config Class Initialized
INFO - 2016-10-21 16:27:26 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:27:26 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:27:26 --> Utf8 Class Initialized
INFO - 2016-10-21 16:27:26 --> URI Class Initialized
DEBUG - 2016-10-21 16:27:26 --> No URI present. Default controller set.
INFO - 2016-10-21 16:27:26 --> Router Class Initialized
INFO - 2016-10-21 16:27:26 --> Output Class Initialized
INFO - 2016-10-21 16:27:26 --> Security Class Initialized
DEBUG - 2016-10-21 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:27:26 --> Input Class Initialized
INFO - 2016-10-21 16:27:26 --> Language Class Initialized
INFO - 2016-10-21 16:27:26 --> Loader Class Initialized
INFO - 2016-10-21 16:27:26 --> Helper loaded: url_helper
INFO - 2016-10-21 16:27:26 --> Helper loaded: form_helper
INFO - 2016-10-21 16:27:26 --> Database Driver Class Initialized
INFO - 2016-10-21 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:27:26 --> Controller Class Initialized
INFO - 2016-10-21 16:27:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:27:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:27:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:27:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:27:26 --> Final output sent to browser
DEBUG - 2016-10-21 16:27:26 --> Total execution time: 0.0090
INFO - 2016-10-21 16:28:50 --> Config Class Initialized
INFO - 2016-10-21 16:28:50 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:28:50 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:28:50 --> Utf8 Class Initialized
INFO - 2016-10-21 16:28:50 --> URI Class Initialized
DEBUG - 2016-10-21 16:28:50 --> No URI present. Default controller set.
INFO - 2016-10-21 16:28:50 --> Router Class Initialized
INFO - 2016-10-21 16:28:50 --> Output Class Initialized
INFO - 2016-10-21 16:28:50 --> Security Class Initialized
DEBUG - 2016-10-21 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:28:50 --> Input Class Initialized
INFO - 2016-10-21 16:28:50 --> Language Class Initialized
INFO - 2016-10-21 16:28:50 --> Loader Class Initialized
INFO - 2016-10-21 16:28:50 --> Helper loaded: url_helper
INFO - 2016-10-21 16:28:50 --> Helper loaded: form_helper
INFO - 2016-10-21 16:28:50 --> Database Driver Class Initialized
INFO - 2016-10-21 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:28:50 --> Controller Class Initialized
INFO - 2016-10-21 16:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:28:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:28:50 --> Final output sent to browser
DEBUG - 2016-10-21 16:28:50 --> Total execution time: 0.0056
INFO - 2016-10-21 16:29:11 --> Config Class Initialized
INFO - 2016-10-21 16:29:11 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:29:11 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:29:11 --> Utf8 Class Initialized
INFO - 2016-10-21 16:29:11 --> URI Class Initialized
DEBUG - 2016-10-21 16:29:11 --> No URI present. Default controller set.
INFO - 2016-10-21 16:29:11 --> Router Class Initialized
INFO - 2016-10-21 16:29:11 --> Output Class Initialized
INFO - 2016-10-21 16:29:11 --> Security Class Initialized
DEBUG - 2016-10-21 16:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:29:11 --> Input Class Initialized
INFO - 2016-10-21 16:29:11 --> Language Class Initialized
INFO - 2016-10-21 16:29:11 --> Loader Class Initialized
INFO - 2016-10-21 16:29:11 --> Helper loaded: url_helper
INFO - 2016-10-21 16:29:11 --> Helper loaded: form_helper
INFO - 2016-10-21 16:29:11 --> Database Driver Class Initialized
INFO - 2016-10-21 16:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:29:11 --> Controller Class Initialized
INFO - 2016-10-21 16:29:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:29:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:29:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:29:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:29:11 --> Final output sent to browser
DEBUG - 2016-10-21 16:29:11 --> Total execution time: 0.0085
INFO - 2016-10-21 16:30:08 --> Config Class Initialized
INFO - 2016-10-21 16:30:08 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:30:08 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:30:08 --> Utf8 Class Initialized
INFO - 2016-10-21 16:30:08 --> URI Class Initialized
DEBUG - 2016-10-21 16:30:08 --> No URI present. Default controller set.
INFO - 2016-10-21 16:30:08 --> Router Class Initialized
INFO - 2016-10-21 16:30:08 --> Output Class Initialized
INFO - 2016-10-21 16:30:08 --> Security Class Initialized
DEBUG - 2016-10-21 16:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:30:08 --> Input Class Initialized
INFO - 2016-10-21 16:30:08 --> Language Class Initialized
INFO - 2016-10-21 16:30:08 --> Loader Class Initialized
INFO - 2016-10-21 16:30:08 --> Helper loaded: url_helper
INFO - 2016-10-21 16:30:08 --> Helper loaded: form_helper
INFO - 2016-10-21 16:30:08 --> Database Driver Class Initialized
INFO - 2016-10-21 16:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:30:08 --> Controller Class Initialized
INFO - 2016-10-21 16:30:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:30:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:30:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:30:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:30:08 --> Final output sent to browser
DEBUG - 2016-10-21 16:30:08 --> Total execution time: 0.0060
INFO - 2016-10-21 16:31:26 --> Config Class Initialized
INFO - 2016-10-21 16:31:26 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:31:26 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:31:26 --> Utf8 Class Initialized
INFO - 2016-10-21 16:31:26 --> URI Class Initialized
DEBUG - 2016-10-21 16:31:26 --> No URI present. Default controller set.
INFO - 2016-10-21 16:31:26 --> Router Class Initialized
INFO - 2016-10-21 16:31:26 --> Output Class Initialized
INFO - 2016-10-21 16:31:26 --> Security Class Initialized
DEBUG - 2016-10-21 16:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:31:26 --> Input Class Initialized
INFO - 2016-10-21 16:31:26 --> Language Class Initialized
INFO - 2016-10-21 16:31:26 --> Loader Class Initialized
INFO - 2016-10-21 16:31:26 --> Helper loaded: url_helper
INFO - 2016-10-21 16:31:26 --> Helper loaded: form_helper
INFO - 2016-10-21 16:31:26 --> Database Driver Class Initialized
INFO - 2016-10-21 16:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:31:26 --> Controller Class Initialized
INFO - 2016-10-21 16:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:31:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:31:26 --> Final output sent to browser
DEBUG - 2016-10-21 16:31:26 --> Total execution time: 0.0065
INFO - 2016-10-21 16:32:44 --> Config Class Initialized
INFO - 2016-10-21 16:32:44 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:32:44 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:32:44 --> Utf8 Class Initialized
INFO - 2016-10-21 16:32:44 --> URI Class Initialized
DEBUG - 2016-10-21 16:32:44 --> No URI present. Default controller set.
INFO - 2016-10-21 16:32:44 --> Router Class Initialized
INFO - 2016-10-21 16:32:44 --> Output Class Initialized
INFO - 2016-10-21 16:32:44 --> Security Class Initialized
DEBUG - 2016-10-21 16:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:32:44 --> Input Class Initialized
INFO - 2016-10-21 16:32:44 --> Language Class Initialized
INFO - 2016-10-21 16:32:44 --> Loader Class Initialized
INFO - 2016-10-21 16:32:44 --> Helper loaded: url_helper
INFO - 2016-10-21 16:32:44 --> Helper loaded: form_helper
INFO - 2016-10-21 16:32:44 --> Database Driver Class Initialized
INFO - 2016-10-21 16:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:32:44 --> Controller Class Initialized
INFO - 2016-10-21 16:32:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:32:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:32:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:32:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:32:44 --> Final output sent to browser
DEBUG - 2016-10-21 16:32:44 --> Total execution time: 0.0061
INFO - 2016-10-21 16:33:07 --> Config Class Initialized
INFO - 2016-10-21 16:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:33:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:33:07 --> Utf8 Class Initialized
INFO - 2016-10-21 16:33:07 --> URI Class Initialized
DEBUG - 2016-10-21 16:33:07 --> No URI present. Default controller set.
INFO - 2016-10-21 16:33:07 --> Router Class Initialized
INFO - 2016-10-21 16:33:07 --> Output Class Initialized
INFO - 2016-10-21 16:33:07 --> Security Class Initialized
DEBUG - 2016-10-21 16:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:33:07 --> Input Class Initialized
INFO - 2016-10-21 16:33:07 --> Language Class Initialized
INFO - 2016-10-21 16:33:07 --> Loader Class Initialized
INFO - 2016-10-21 16:33:07 --> Helper loaded: url_helper
INFO - 2016-10-21 16:33:07 --> Helper loaded: form_helper
INFO - 2016-10-21 16:33:07 --> Database Driver Class Initialized
INFO - 2016-10-21 16:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:33:07 --> Controller Class Initialized
INFO - 2016-10-21 16:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:33:07 --> Final output sent to browser
DEBUG - 2016-10-21 16:33:07 --> Total execution time: 0.0054
INFO - 2016-10-21 16:46:00 --> Config Class Initialized
INFO - 2016-10-21 16:46:00 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:46:00 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:46:00 --> Utf8 Class Initialized
INFO - 2016-10-21 16:46:00 --> URI Class Initialized
DEBUG - 2016-10-21 16:46:00 --> No URI present. Default controller set.
INFO - 2016-10-21 16:46:00 --> Router Class Initialized
INFO - 2016-10-21 16:46:00 --> Output Class Initialized
INFO - 2016-10-21 16:46:00 --> Security Class Initialized
DEBUG - 2016-10-21 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:46:00 --> Input Class Initialized
INFO - 2016-10-21 16:46:00 --> Language Class Initialized
INFO - 2016-10-21 16:46:00 --> Loader Class Initialized
INFO - 2016-10-21 16:46:00 --> Helper loaded: url_helper
INFO - 2016-10-21 16:46:00 --> Helper loaded: form_helper
INFO - 2016-10-21 16:46:00 --> Database Driver Class Initialized
INFO - 2016-10-21 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:46:00 --> Controller Class Initialized
INFO - 2016-10-21 16:46:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:46:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:46:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:46:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:46:00 --> Final output sent to browser
DEBUG - 2016-10-21 16:46:00 --> Total execution time: 0.0066
INFO - 2016-10-21 16:46:22 --> Config Class Initialized
INFO - 2016-10-21 16:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:46:22 --> Utf8 Class Initialized
INFO - 2016-10-21 16:46:22 --> URI Class Initialized
DEBUG - 2016-10-21 16:46:22 --> No URI present. Default controller set.
INFO - 2016-10-21 16:46:22 --> Router Class Initialized
INFO - 2016-10-21 16:46:22 --> Output Class Initialized
INFO - 2016-10-21 16:46:22 --> Security Class Initialized
DEBUG - 2016-10-21 16:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:46:22 --> Input Class Initialized
INFO - 2016-10-21 16:46:22 --> Language Class Initialized
INFO - 2016-10-21 16:46:22 --> Loader Class Initialized
INFO - 2016-10-21 16:46:22 --> Helper loaded: url_helper
INFO - 2016-10-21 16:46:22 --> Helper loaded: form_helper
INFO - 2016-10-21 16:46:22 --> Database Driver Class Initialized
INFO - 2016-10-21 16:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:46:22 --> Controller Class Initialized
INFO - 2016-10-21 16:46:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:46:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:46:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:46:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:46:22 --> Final output sent to browser
DEBUG - 2016-10-21 16:46:22 --> Total execution time: 0.0062
INFO - 2016-10-21 16:46:53 --> Config Class Initialized
INFO - 2016-10-21 16:46:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:46:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:46:53 --> Utf8 Class Initialized
INFO - 2016-10-21 16:46:53 --> URI Class Initialized
DEBUG - 2016-10-21 16:46:53 --> No URI present. Default controller set.
INFO - 2016-10-21 16:46:53 --> Router Class Initialized
INFO - 2016-10-21 16:46:53 --> Output Class Initialized
INFO - 2016-10-21 16:46:53 --> Security Class Initialized
DEBUG - 2016-10-21 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:46:53 --> Input Class Initialized
INFO - 2016-10-21 16:46:53 --> Language Class Initialized
INFO - 2016-10-21 16:46:53 --> Loader Class Initialized
INFO - 2016-10-21 16:46:53 --> Helper loaded: url_helper
INFO - 2016-10-21 16:46:53 --> Helper loaded: form_helper
INFO - 2016-10-21 16:46:53 --> Database Driver Class Initialized
INFO - 2016-10-21 16:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:46:53 --> Controller Class Initialized
INFO - 2016-10-21 16:46:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:46:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:46:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:46:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:46:53 --> Final output sent to browser
DEBUG - 2016-10-21 16:46:53 --> Total execution time: 0.0060
INFO - 2016-10-21 16:47:29 --> Config Class Initialized
INFO - 2016-10-21 16:47:29 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:47:29 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:47:29 --> Utf8 Class Initialized
INFO - 2016-10-21 16:47:29 --> URI Class Initialized
DEBUG - 2016-10-21 16:47:29 --> No URI present. Default controller set.
INFO - 2016-10-21 16:47:29 --> Router Class Initialized
INFO - 2016-10-21 16:47:29 --> Output Class Initialized
INFO - 2016-10-21 16:47:29 --> Security Class Initialized
DEBUG - 2016-10-21 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:47:29 --> Input Class Initialized
INFO - 2016-10-21 16:47:29 --> Language Class Initialized
INFO - 2016-10-21 16:47:29 --> Loader Class Initialized
INFO - 2016-10-21 16:47:29 --> Helper loaded: url_helper
INFO - 2016-10-21 16:47:29 --> Helper loaded: form_helper
INFO - 2016-10-21 16:47:29 --> Database Driver Class Initialized
INFO - 2016-10-21 16:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:47:29 --> Controller Class Initialized
INFO - 2016-10-21 16:47:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:47:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:47:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:47:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:47:29 --> Final output sent to browser
DEBUG - 2016-10-21 16:47:29 --> Total execution time: 0.0067
INFO - 2016-10-21 16:52:16 --> Config Class Initialized
INFO - 2016-10-21 16:52:16 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:52:16 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:52:16 --> Utf8 Class Initialized
INFO - 2016-10-21 16:52:16 --> URI Class Initialized
DEBUG - 2016-10-21 16:52:17 --> No URI present. Default controller set.
INFO - 2016-10-21 16:52:17 --> Router Class Initialized
INFO - 2016-10-21 16:52:17 --> Output Class Initialized
INFO - 2016-10-21 16:52:17 --> Security Class Initialized
DEBUG - 2016-10-21 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:52:17 --> Input Class Initialized
INFO - 2016-10-21 16:52:17 --> Language Class Initialized
INFO - 2016-10-21 16:52:17 --> Loader Class Initialized
INFO - 2016-10-21 16:52:17 --> Helper loaded: url_helper
INFO - 2016-10-21 16:52:17 --> Helper loaded: form_helper
INFO - 2016-10-21 16:52:17 --> Database Driver Class Initialized
INFO - 2016-10-21 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:52:17 --> Controller Class Initialized
INFO - 2016-10-21 16:52:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:52:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:52:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:52:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:52:17 --> Final output sent to browser
DEBUG - 2016-10-21 16:52:17 --> Total execution time: 0.0086
INFO - 2016-10-21 16:52:23 --> Config Class Initialized
INFO - 2016-10-21 16:52:23 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:52:23 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:52:23 --> Utf8 Class Initialized
INFO - 2016-10-21 16:52:23 --> URI Class Initialized
INFO - 2016-10-21 16:52:23 --> Router Class Initialized
INFO - 2016-10-21 16:52:23 --> Output Class Initialized
INFO - 2016-10-21 16:52:23 --> Security Class Initialized
DEBUG - 2016-10-21 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:52:23 --> Input Class Initialized
INFO - 2016-10-21 16:52:23 --> Language Class Initialized
INFO - 2016-10-21 16:52:23 --> Loader Class Initialized
INFO - 2016-10-21 16:52:23 --> Helper loaded: url_helper
INFO - 2016-10-21 16:52:23 --> Helper loaded: form_helper
INFO - 2016-10-21 16:52:23 --> Database Driver Class Initialized
INFO - 2016-10-21 16:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:52:23 --> Controller Class Initialized
DEBUG - 2016-10-21 16:52:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 16:52:23 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 16:52:23 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 16:52:23 --> Config Class Initialized
INFO - 2016-10-21 16:52:23 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:52:23 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:52:23 --> Utf8 Class Initialized
INFO - 2016-10-21 16:52:23 --> URI Class Initialized
DEBUG - 2016-10-21 16:52:23 --> No URI present. Default controller set.
INFO - 2016-10-21 16:52:23 --> Router Class Initialized
INFO - 2016-10-21 16:52:23 --> Output Class Initialized
INFO - 2016-10-21 16:52:23 --> Security Class Initialized
DEBUG - 2016-10-21 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:52:23 --> Input Class Initialized
INFO - 2016-10-21 16:52:23 --> Language Class Initialized
INFO - 2016-10-21 16:52:23 --> Loader Class Initialized
INFO - 2016-10-21 16:52:23 --> Helper loaded: url_helper
INFO - 2016-10-21 16:52:23 --> Helper loaded: form_helper
INFO - 2016-10-21 16:52:23 --> Database Driver Class Initialized
INFO - 2016-10-21 16:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:52:23 --> Controller Class Initialized
INFO - 2016-10-21 16:52:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:52:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 16:52:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:52:23 --> Final output sent to browser
DEBUG - 2016-10-21 16:52:23 --> Total execution time: 0.0044
INFO - 2016-10-21 16:52:32 --> Config Class Initialized
INFO - 2016-10-21 16:52:32 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:52:32 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:52:32 --> Utf8 Class Initialized
INFO - 2016-10-21 16:52:32 --> URI Class Initialized
INFO - 2016-10-21 16:52:32 --> Router Class Initialized
INFO - 2016-10-21 16:52:32 --> Output Class Initialized
INFO - 2016-10-21 16:52:32 --> Security Class Initialized
DEBUG - 2016-10-21 16:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:52:32 --> Input Class Initialized
INFO - 2016-10-21 16:52:32 --> Language Class Initialized
INFO - 2016-10-21 16:52:32 --> Loader Class Initialized
INFO - 2016-10-21 16:52:32 --> Helper loaded: url_helper
INFO - 2016-10-21 16:52:32 --> Helper loaded: form_helper
INFO - 2016-10-21 16:52:32 --> Database Driver Class Initialized
INFO - 2016-10-21 16:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:52:32 --> Controller Class Initialized
DEBUG - 2016-10-21 16:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 16:52:32 --> Model Class Initialized
INFO - 2016-10-21 16:52:32 --> Final output sent to browser
DEBUG - 2016-10-21 16:52:32 --> Total execution time: 0.0072
INFO - 2016-10-21 16:52:32 --> Config Class Initialized
INFO - 2016-10-21 16:52:32 --> Hooks Class Initialized
DEBUG - 2016-10-21 16:52:32 --> UTF-8 Support Enabled
INFO - 2016-10-21 16:52:32 --> Utf8 Class Initialized
INFO - 2016-10-21 16:52:32 --> URI Class Initialized
DEBUG - 2016-10-21 16:52:32 --> No URI present. Default controller set.
INFO - 2016-10-21 16:52:32 --> Router Class Initialized
INFO - 2016-10-21 16:52:32 --> Output Class Initialized
INFO - 2016-10-21 16:52:32 --> Security Class Initialized
DEBUG - 2016-10-21 16:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 16:52:32 --> Input Class Initialized
INFO - 2016-10-21 16:52:32 --> Language Class Initialized
INFO - 2016-10-21 16:52:32 --> Loader Class Initialized
INFO - 2016-10-21 16:52:32 --> Helper loaded: url_helper
INFO - 2016-10-21 16:52:32 --> Helper loaded: form_helper
INFO - 2016-10-21 16:52:32 --> Database Driver Class Initialized
INFO - 2016-10-21 16:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 16:52:32 --> Controller Class Initialized
INFO - 2016-10-21 16:52:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 16:52:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 16:52:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 16:52:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 16:52:32 --> Final output sent to browser
DEBUG - 2016-10-21 16:52:32 --> Total execution time: 0.0049
INFO - 2016-10-21 17:14:46 --> Config Class Initialized
INFO - 2016-10-21 17:14:46 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:14:46 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:14:46 --> Utf8 Class Initialized
INFO - 2016-10-21 17:14:46 --> URI Class Initialized
INFO - 2016-10-21 17:14:46 --> Router Class Initialized
INFO - 2016-10-21 17:14:46 --> Output Class Initialized
INFO - 2016-10-21 17:14:46 --> Security Class Initialized
DEBUG - 2016-10-21 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:14:46 --> Input Class Initialized
INFO - 2016-10-21 17:14:46 --> Language Class Initialized
INFO - 2016-10-21 17:14:46 --> Loader Class Initialized
INFO - 2016-10-21 17:14:46 --> Helper loaded: url_helper
INFO - 2016-10-21 17:14:46 --> Helper loaded: form_helper
INFO - 2016-10-21 17:14:46 --> Database Driver Class Initialized
INFO - 2016-10-21 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:14:46 --> Controller Class Initialized
DEBUG - 2016-10-21 17:14:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:14:46 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:14:46 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:14:46 --> Config Class Initialized
INFO - 2016-10-21 17:14:46 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:14:46 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:14:46 --> Utf8 Class Initialized
INFO - 2016-10-21 17:14:46 --> URI Class Initialized
DEBUG - 2016-10-21 17:14:46 --> No URI present. Default controller set.
INFO - 2016-10-21 17:14:46 --> Router Class Initialized
INFO - 2016-10-21 17:14:46 --> Output Class Initialized
INFO - 2016-10-21 17:14:46 --> Security Class Initialized
DEBUG - 2016-10-21 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:14:46 --> Input Class Initialized
INFO - 2016-10-21 17:14:46 --> Language Class Initialized
INFO - 2016-10-21 17:14:46 --> Loader Class Initialized
INFO - 2016-10-21 17:14:46 --> Helper loaded: url_helper
INFO - 2016-10-21 17:14:46 --> Helper loaded: form_helper
INFO - 2016-10-21 17:14:46 --> Database Driver Class Initialized
INFO - 2016-10-21 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:14:46 --> Controller Class Initialized
INFO - 2016-10-21 17:14:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:14:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:14:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:14:46 --> Final output sent to browser
DEBUG - 2016-10-21 17:14:46 --> Total execution time: 0.0045
INFO - 2016-10-21 17:14:52 --> Config Class Initialized
INFO - 2016-10-21 17:14:52 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:14:52 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:14:52 --> Utf8 Class Initialized
INFO - 2016-10-21 17:14:52 --> URI Class Initialized
INFO - 2016-10-21 17:14:52 --> Router Class Initialized
INFO - 2016-10-21 17:14:52 --> Output Class Initialized
INFO - 2016-10-21 17:14:52 --> Security Class Initialized
DEBUG - 2016-10-21 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:14:52 --> Input Class Initialized
INFO - 2016-10-21 17:14:52 --> Language Class Initialized
INFO - 2016-10-21 17:14:52 --> Loader Class Initialized
INFO - 2016-10-21 17:14:52 --> Helper loaded: url_helper
INFO - 2016-10-21 17:14:52 --> Helper loaded: form_helper
INFO - 2016-10-21 17:14:52 --> Database Driver Class Initialized
INFO - 2016-10-21 17:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:14:52 --> Controller Class Initialized
DEBUG - 2016-10-21 17:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:14:52 --> Model Class Initialized
INFO - 2016-10-21 17:14:52 --> Final output sent to browser
DEBUG - 2016-10-21 17:14:52 --> Total execution time: 0.0069
INFO - 2016-10-21 17:14:53 --> Config Class Initialized
INFO - 2016-10-21 17:14:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:14:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:14:53 --> Utf8 Class Initialized
INFO - 2016-10-21 17:14:53 --> URI Class Initialized
DEBUG - 2016-10-21 17:14:53 --> No URI present. Default controller set.
INFO - 2016-10-21 17:14:53 --> Router Class Initialized
INFO - 2016-10-21 17:14:53 --> Output Class Initialized
INFO - 2016-10-21 17:14:53 --> Security Class Initialized
DEBUG - 2016-10-21 17:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:14:53 --> Input Class Initialized
INFO - 2016-10-21 17:14:53 --> Language Class Initialized
INFO - 2016-10-21 17:14:53 --> Loader Class Initialized
INFO - 2016-10-21 17:14:53 --> Helper loaded: url_helper
INFO - 2016-10-21 17:14:53 --> Helper loaded: form_helper
INFO - 2016-10-21 17:14:53 --> Database Driver Class Initialized
INFO - 2016-10-21 17:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:14:53 --> Controller Class Initialized
INFO - 2016-10-21 17:14:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:14:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:14:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:14:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:14:53 --> Final output sent to browser
DEBUG - 2016-10-21 17:14:53 --> Total execution time: 0.0048
INFO - 2016-10-21 17:17:38 --> Config Class Initialized
INFO - 2016-10-21 17:17:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:17:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:17:38 --> Utf8 Class Initialized
INFO - 2016-10-21 17:17:38 --> URI Class Initialized
INFO - 2016-10-21 17:17:38 --> Router Class Initialized
INFO - 2016-10-21 17:17:38 --> Output Class Initialized
INFO - 2016-10-21 17:17:38 --> Security Class Initialized
DEBUG - 2016-10-21 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:17:38 --> Input Class Initialized
INFO - 2016-10-21 17:17:38 --> Language Class Initialized
INFO - 2016-10-21 17:17:38 --> Loader Class Initialized
INFO - 2016-10-21 17:17:38 --> Helper loaded: url_helper
INFO - 2016-10-21 17:17:38 --> Helper loaded: form_helper
INFO - 2016-10-21 17:17:38 --> Database Driver Class Initialized
INFO - 2016-10-21 17:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:17:38 --> Controller Class Initialized
DEBUG - 2016-10-21 17:17:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:17:38 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:17:38 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:17:38 --> Config Class Initialized
INFO - 2016-10-21 17:17:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:17:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:17:38 --> Utf8 Class Initialized
INFO - 2016-10-21 17:17:38 --> URI Class Initialized
DEBUG - 2016-10-21 17:17:38 --> No URI present. Default controller set.
INFO - 2016-10-21 17:17:38 --> Router Class Initialized
INFO - 2016-10-21 17:17:38 --> Output Class Initialized
INFO - 2016-10-21 17:17:38 --> Security Class Initialized
DEBUG - 2016-10-21 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:17:38 --> Input Class Initialized
INFO - 2016-10-21 17:17:38 --> Language Class Initialized
INFO - 2016-10-21 17:17:38 --> Loader Class Initialized
INFO - 2016-10-21 17:17:38 --> Helper loaded: url_helper
INFO - 2016-10-21 17:17:38 --> Helper loaded: form_helper
INFO - 2016-10-21 17:17:38 --> Database Driver Class Initialized
INFO - 2016-10-21 17:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:17:38 --> Controller Class Initialized
INFO - 2016-10-21 17:17:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:17:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:17:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:17:38 --> Final output sent to browser
DEBUG - 2016-10-21 17:17:38 --> Total execution time: 0.0051
INFO - 2016-10-21 17:17:53 --> Config Class Initialized
INFO - 2016-10-21 17:17:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:17:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:17:53 --> Utf8 Class Initialized
INFO - 2016-10-21 17:17:53 --> URI Class Initialized
INFO - 2016-10-21 17:17:53 --> Router Class Initialized
INFO - 2016-10-21 17:17:53 --> Output Class Initialized
INFO - 2016-10-21 17:17:53 --> Security Class Initialized
DEBUG - 2016-10-21 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:17:53 --> Input Class Initialized
INFO - 2016-10-21 17:17:53 --> Language Class Initialized
INFO - 2016-10-21 17:17:53 --> Loader Class Initialized
INFO - 2016-10-21 17:17:53 --> Helper loaded: url_helper
INFO - 2016-10-21 17:17:53 --> Helper loaded: form_helper
INFO - 2016-10-21 17:17:53 --> Database Driver Class Initialized
INFO - 2016-10-21 17:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:17:53 --> Controller Class Initialized
DEBUG - 2016-10-21 17:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:17:53 --> Model Class Initialized
INFO - 2016-10-21 17:17:53 --> Final output sent to browser
DEBUG - 2016-10-21 17:17:53 --> Total execution time: 0.0083
INFO - 2016-10-21 17:17:58 --> Config Class Initialized
INFO - 2016-10-21 17:17:58 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:17:58 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:17:58 --> Utf8 Class Initialized
INFO - 2016-10-21 17:17:58 --> URI Class Initialized
INFO - 2016-10-21 17:17:58 --> Router Class Initialized
INFO - 2016-10-21 17:17:58 --> Output Class Initialized
INFO - 2016-10-21 17:17:58 --> Security Class Initialized
DEBUG - 2016-10-21 17:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:17:58 --> Input Class Initialized
INFO - 2016-10-21 17:17:58 --> Language Class Initialized
INFO - 2016-10-21 17:17:58 --> Loader Class Initialized
INFO - 2016-10-21 17:17:58 --> Helper loaded: url_helper
INFO - 2016-10-21 17:17:58 --> Helper loaded: form_helper
INFO - 2016-10-21 17:17:58 --> Database Driver Class Initialized
INFO - 2016-10-21 17:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:17:58 --> Controller Class Initialized
DEBUG - 2016-10-21 17:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:17:58 --> Model Class Initialized
INFO - 2016-10-21 17:17:58 --> Final output sent to browser
DEBUG - 2016-10-21 17:17:58 --> Total execution time: 0.0075
INFO - 2016-10-21 17:18:07 --> Config Class Initialized
INFO - 2016-10-21 17:18:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:18:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:18:07 --> Utf8 Class Initialized
INFO - 2016-10-21 17:18:07 --> URI Class Initialized
INFO - 2016-10-21 17:18:07 --> Router Class Initialized
INFO - 2016-10-21 17:18:07 --> Output Class Initialized
INFO - 2016-10-21 17:18:07 --> Security Class Initialized
DEBUG - 2016-10-21 17:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:18:07 --> Input Class Initialized
INFO - 2016-10-21 17:18:07 --> Language Class Initialized
INFO - 2016-10-21 17:18:07 --> Loader Class Initialized
INFO - 2016-10-21 17:18:07 --> Helper loaded: url_helper
INFO - 2016-10-21 17:18:07 --> Helper loaded: form_helper
INFO - 2016-10-21 17:18:07 --> Database Driver Class Initialized
INFO - 2016-10-21 17:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:18:07 --> Controller Class Initialized
DEBUG - 2016-10-21 17:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:18:07 --> Model Class Initialized
INFO - 2016-10-21 17:18:07 --> Final output sent to browser
DEBUG - 2016-10-21 17:18:07 --> Total execution time: 0.0070
INFO - 2016-10-21 17:18:08 --> Config Class Initialized
INFO - 2016-10-21 17:18:08 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:18:08 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:18:08 --> Utf8 Class Initialized
INFO - 2016-10-21 17:18:08 --> URI Class Initialized
DEBUG - 2016-10-21 17:18:08 --> No URI present. Default controller set.
INFO - 2016-10-21 17:18:08 --> Router Class Initialized
INFO - 2016-10-21 17:18:08 --> Output Class Initialized
INFO - 2016-10-21 17:18:08 --> Security Class Initialized
DEBUG - 2016-10-21 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:18:08 --> Input Class Initialized
INFO - 2016-10-21 17:18:08 --> Language Class Initialized
INFO - 2016-10-21 17:18:08 --> Loader Class Initialized
INFO - 2016-10-21 17:18:08 --> Helper loaded: url_helper
INFO - 2016-10-21 17:18:08 --> Helper loaded: form_helper
INFO - 2016-10-21 17:18:08 --> Database Driver Class Initialized
INFO - 2016-10-21 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:18:08 --> Controller Class Initialized
INFO - 2016-10-21 17:18:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:18:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:18:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:18:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:18:08 --> Final output sent to browser
DEBUG - 2016-10-21 17:18:08 --> Total execution time: 0.0048
INFO - 2016-10-21 17:21:58 --> Config Class Initialized
INFO - 2016-10-21 17:21:58 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:21:58 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:21:58 --> Utf8 Class Initialized
INFO - 2016-10-21 17:21:58 --> URI Class Initialized
DEBUG - 2016-10-21 17:21:58 --> No URI present. Default controller set.
INFO - 2016-10-21 17:21:58 --> Router Class Initialized
INFO - 2016-10-21 17:21:58 --> Output Class Initialized
INFO - 2016-10-21 17:21:58 --> Security Class Initialized
DEBUG - 2016-10-21 17:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:21:58 --> Input Class Initialized
INFO - 2016-10-21 17:21:58 --> Language Class Initialized
INFO - 2016-10-21 17:21:58 --> Loader Class Initialized
INFO - 2016-10-21 17:21:58 --> Helper loaded: url_helper
INFO - 2016-10-21 17:21:58 --> Helper loaded: form_helper
INFO - 2016-10-21 17:21:58 --> Database Driver Class Initialized
INFO - 2016-10-21 17:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:21:58 --> Controller Class Initialized
INFO - 2016-10-21 17:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:21:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:21:58 --> Final output sent to browser
DEBUG - 2016-10-21 17:21:58 --> Total execution time: 0.0072
INFO - 2016-10-21 17:21:59 --> Config Class Initialized
INFO - 2016-10-21 17:21:59 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:21:59 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:21:59 --> Utf8 Class Initialized
INFO - 2016-10-21 17:21:59 --> URI Class Initialized
DEBUG - 2016-10-21 17:21:59 --> No URI present. Default controller set.
INFO - 2016-10-21 17:21:59 --> Router Class Initialized
INFO - 2016-10-21 17:21:59 --> Output Class Initialized
INFO - 2016-10-21 17:21:59 --> Security Class Initialized
DEBUG - 2016-10-21 17:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:21:59 --> Input Class Initialized
INFO - 2016-10-21 17:21:59 --> Language Class Initialized
INFO - 2016-10-21 17:21:59 --> Loader Class Initialized
INFO - 2016-10-21 17:21:59 --> Helper loaded: url_helper
INFO - 2016-10-21 17:21:59 --> Helper loaded: form_helper
INFO - 2016-10-21 17:21:59 --> Database Driver Class Initialized
INFO - 2016-10-21 17:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:21:59 --> Controller Class Initialized
INFO - 2016-10-21 17:21:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:21:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:21:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:21:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:21:59 --> Final output sent to browser
DEBUG - 2016-10-21 17:21:59 --> Total execution time: 0.0060
INFO - 2016-10-21 17:22:00 --> Config Class Initialized
INFO - 2016-10-21 17:22:00 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:22:00 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:22:00 --> Utf8 Class Initialized
INFO - 2016-10-21 17:22:00 --> URI Class Initialized
INFO - 2016-10-21 17:22:00 --> Router Class Initialized
INFO - 2016-10-21 17:22:00 --> Output Class Initialized
INFO - 2016-10-21 17:22:00 --> Security Class Initialized
DEBUG - 2016-10-21 17:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:22:00 --> Input Class Initialized
INFO - 2016-10-21 17:22:00 --> Language Class Initialized
INFO - 2016-10-21 17:22:00 --> Loader Class Initialized
INFO - 2016-10-21 17:22:00 --> Helper loaded: url_helper
INFO - 2016-10-21 17:22:00 --> Helper loaded: form_helper
INFO - 2016-10-21 17:22:00 --> Database Driver Class Initialized
INFO - 2016-10-21 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:22:00 --> Controller Class Initialized
DEBUG - 2016-10-21 17:22:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:22:00 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:22:00 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:22:00 --> Config Class Initialized
INFO - 2016-10-21 17:22:00 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:22:00 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:22:00 --> Utf8 Class Initialized
INFO - 2016-10-21 17:22:00 --> URI Class Initialized
DEBUG - 2016-10-21 17:22:00 --> No URI present. Default controller set.
INFO - 2016-10-21 17:22:00 --> Router Class Initialized
INFO - 2016-10-21 17:22:00 --> Output Class Initialized
INFO - 2016-10-21 17:22:00 --> Security Class Initialized
DEBUG - 2016-10-21 17:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:22:00 --> Input Class Initialized
INFO - 2016-10-21 17:22:00 --> Language Class Initialized
INFO - 2016-10-21 17:22:00 --> Loader Class Initialized
INFO - 2016-10-21 17:22:00 --> Helper loaded: url_helper
INFO - 2016-10-21 17:22:00 --> Helper loaded: form_helper
INFO - 2016-10-21 17:22:00 --> Database Driver Class Initialized
INFO - 2016-10-21 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:22:00 --> Controller Class Initialized
INFO - 2016-10-21 17:22:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:22:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:22:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:22:00 --> Final output sent to browser
DEBUG - 2016-10-21 17:22:00 --> Total execution time: 0.0054
INFO - 2016-10-21 17:22:12 --> Config Class Initialized
INFO - 2016-10-21 17:22:12 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:22:12 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:22:12 --> Utf8 Class Initialized
INFO - 2016-10-21 17:22:12 --> URI Class Initialized
INFO - 2016-10-21 17:22:12 --> Router Class Initialized
INFO - 2016-10-21 17:22:12 --> Output Class Initialized
INFO - 2016-10-21 17:22:12 --> Security Class Initialized
DEBUG - 2016-10-21 17:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:22:12 --> Input Class Initialized
INFO - 2016-10-21 17:22:12 --> Language Class Initialized
INFO - 2016-10-21 17:22:12 --> Loader Class Initialized
INFO - 2016-10-21 17:22:12 --> Helper loaded: url_helper
INFO - 2016-10-21 17:22:12 --> Helper loaded: form_helper
INFO - 2016-10-21 17:22:12 --> Database Driver Class Initialized
INFO - 2016-10-21 17:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:22:12 --> Controller Class Initialized
DEBUG - 2016-10-21 17:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:22:12 --> Model Class Initialized
INFO - 2016-10-21 17:22:12 --> Final output sent to browser
DEBUG - 2016-10-21 17:22:12 --> Total execution time: 0.0072
INFO - 2016-10-21 17:22:20 --> Config Class Initialized
INFO - 2016-10-21 17:22:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:22:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:22:20 --> Utf8 Class Initialized
INFO - 2016-10-21 17:22:20 --> URI Class Initialized
INFO - 2016-10-21 17:22:20 --> Router Class Initialized
INFO - 2016-10-21 17:22:20 --> Output Class Initialized
INFO - 2016-10-21 17:22:20 --> Security Class Initialized
DEBUG - 2016-10-21 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:22:20 --> Input Class Initialized
INFO - 2016-10-21 17:22:20 --> Language Class Initialized
INFO - 2016-10-21 17:22:20 --> Loader Class Initialized
INFO - 2016-10-21 17:22:20 --> Helper loaded: url_helper
INFO - 2016-10-21 17:22:20 --> Helper loaded: form_helper
INFO - 2016-10-21 17:22:20 --> Database Driver Class Initialized
INFO - 2016-10-21 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:22:20 --> Controller Class Initialized
DEBUG - 2016-10-21 17:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:22:20 --> Model Class Initialized
INFO - 2016-10-21 17:22:20 --> Final output sent to browser
DEBUG - 2016-10-21 17:22:20 --> Total execution time: 0.0071
INFO - 2016-10-21 17:22:20 --> Config Class Initialized
INFO - 2016-10-21 17:22:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:22:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:22:20 --> Utf8 Class Initialized
INFO - 2016-10-21 17:22:20 --> URI Class Initialized
DEBUG - 2016-10-21 17:22:20 --> No URI present. Default controller set.
INFO - 2016-10-21 17:22:20 --> Router Class Initialized
INFO - 2016-10-21 17:22:20 --> Output Class Initialized
INFO - 2016-10-21 17:22:20 --> Security Class Initialized
DEBUG - 2016-10-21 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:22:20 --> Input Class Initialized
INFO - 2016-10-21 17:22:20 --> Language Class Initialized
INFO - 2016-10-21 17:22:20 --> Loader Class Initialized
INFO - 2016-10-21 17:22:20 --> Helper loaded: url_helper
INFO - 2016-10-21 17:22:20 --> Helper loaded: form_helper
INFO - 2016-10-21 17:22:20 --> Database Driver Class Initialized
INFO - 2016-10-21 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:22:20 --> Controller Class Initialized
INFO - 2016-10-21 17:22:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:22:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:22:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:22:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:22:20 --> Final output sent to browser
DEBUG - 2016-10-21 17:22:20 --> Total execution time: 0.0048
INFO - 2016-10-21 17:27:20 --> Config Class Initialized
INFO - 2016-10-21 17:27:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:27:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:27:20 --> Utf8 Class Initialized
INFO - 2016-10-21 17:27:20 --> URI Class Initialized
DEBUG - 2016-10-21 17:27:20 --> No URI present. Default controller set.
INFO - 2016-10-21 17:27:20 --> Router Class Initialized
INFO - 2016-10-21 17:27:20 --> Output Class Initialized
INFO - 2016-10-21 17:27:20 --> Security Class Initialized
DEBUG - 2016-10-21 17:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:27:20 --> Input Class Initialized
INFO - 2016-10-21 17:27:20 --> Language Class Initialized
INFO - 2016-10-21 17:27:20 --> Loader Class Initialized
INFO - 2016-10-21 17:27:20 --> Helper loaded: url_helper
INFO - 2016-10-21 17:27:20 --> Helper loaded: form_helper
INFO - 2016-10-21 17:27:20 --> Database Driver Class Initialized
INFO - 2016-10-21 17:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:27:20 --> Controller Class Initialized
INFO - 2016-10-21 17:27:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:27:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:27:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:27:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:27:20 --> Final output sent to browser
DEBUG - 2016-10-21 17:27:20 --> Total execution time: 0.0072
INFO - 2016-10-21 17:27:37 --> Config Class Initialized
INFO - 2016-10-21 17:27:37 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:27:37 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:27:37 --> Utf8 Class Initialized
INFO - 2016-10-21 17:27:37 --> URI Class Initialized
INFO - 2016-10-21 17:27:37 --> Router Class Initialized
INFO - 2016-10-21 17:27:37 --> Output Class Initialized
INFO - 2016-10-21 17:27:37 --> Security Class Initialized
DEBUG - 2016-10-21 17:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:27:37 --> Input Class Initialized
INFO - 2016-10-21 17:27:37 --> Language Class Initialized
INFO - 2016-10-21 17:27:37 --> Loader Class Initialized
INFO - 2016-10-21 17:27:37 --> Helper loaded: url_helper
INFO - 2016-10-21 17:27:37 --> Helper loaded: form_helper
INFO - 2016-10-21 17:27:37 --> Database Driver Class Initialized
INFO - 2016-10-21 17:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:27:37 --> Controller Class Initialized
DEBUG - 2016-10-21 17:27:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:27:37 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:27:37 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:27:37 --> Config Class Initialized
INFO - 2016-10-21 17:27:37 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:27:37 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:27:37 --> Utf8 Class Initialized
INFO - 2016-10-21 17:27:37 --> URI Class Initialized
DEBUG - 2016-10-21 17:27:37 --> No URI present. Default controller set.
INFO - 2016-10-21 17:27:37 --> Router Class Initialized
INFO - 2016-10-21 17:27:37 --> Output Class Initialized
INFO - 2016-10-21 17:27:37 --> Security Class Initialized
DEBUG - 2016-10-21 17:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:27:37 --> Input Class Initialized
INFO - 2016-10-21 17:27:37 --> Language Class Initialized
INFO - 2016-10-21 17:27:37 --> Loader Class Initialized
INFO - 2016-10-21 17:27:37 --> Helper loaded: url_helper
INFO - 2016-10-21 17:27:37 --> Helper loaded: form_helper
INFO - 2016-10-21 17:27:37 --> Database Driver Class Initialized
INFO - 2016-10-21 17:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:27:37 --> Controller Class Initialized
INFO - 2016-10-21 17:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:27:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:27:37 --> Final output sent to browser
DEBUG - 2016-10-21 17:27:37 --> Total execution time: 0.0045
INFO - 2016-10-21 17:27:46 --> Config Class Initialized
INFO - 2016-10-21 17:27:46 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:27:46 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:27:46 --> Utf8 Class Initialized
INFO - 2016-10-21 17:27:46 --> URI Class Initialized
INFO - 2016-10-21 17:27:46 --> Router Class Initialized
INFO - 2016-10-21 17:27:46 --> Output Class Initialized
INFO - 2016-10-21 17:27:46 --> Security Class Initialized
DEBUG - 2016-10-21 17:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:27:46 --> Input Class Initialized
INFO - 2016-10-21 17:27:46 --> Language Class Initialized
INFO - 2016-10-21 17:27:46 --> Loader Class Initialized
INFO - 2016-10-21 17:27:46 --> Helper loaded: url_helper
INFO - 2016-10-21 17:27:46 --> Helper loaded: form_helper
INFO - 2016-10-21 17:27:46 --> Database Driver Class Initialized
INFO - 2016-10-21 17:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:27:46 --> Controller Class Initialized
DEBUG - 2016-10-21 17:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:27:46 --> Model Class Initialized
INFO - 2016-10-21 17:27:46 --> Final output sent to browser
DEBUG - 2016-10-21 17:27:46 --> Total execution time: 0.0093
INFO - 2016-10-21 17:27:52 --> Config Class Initialized
INFO - 2016-10-21 17:27:52 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:27:52 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:27:52 --> Utf8 Class Initialized
INFO - 2016-10-21 17:27:52 --> URI Class Initialized
INFO - 2016-10-21 17:27:52 --> Router Class Initialized
INFO - 2016-10-21 17:27:52 --> Output Class Initialized
INFO - 2016-10-21 17:27:52 --> Security Class Initialized
DEBUG - 2016-10-21 17:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:27:52 --> Input Class Initialized
INFO - 2016-10-21 17:27:52 --> Language Class Initialized
INFO - 2016-10-21 17:27:52 --> Loader Class Initialized
INFO - 2016-10-21 17:27:52 --> Helper loaded: url_helper
INFO - 2016-10-21 17:27:52 --> Helper loaded: form_helper
INFO - 2016-10-21 17:27:52 --> Database Driver Class Initialized
INFO - 2016-10-21 17:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:27:52 --> Controller Class Initialized
DEBUG - 2016-10-21 17:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:27:52 --> Model Class Initialized
INFO - 2016-10-21 17:27:52 --> Final output sent to browser
DEBUG - 2016-10-21 17:27:52 --> Total execution time: 0.0073
INFO - 2016-10-21 17:28:09 --> Config Class Initialized
INFO - 2016-10-21 17:28:09 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:09 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:09 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:09 --> URI Class Initialized
INFO - 2016-10-21 17:28:09 --> Router Class Initialized
INFO - 2016-10-21 17:28:09 --> Output Class Initialized
INFO - 2016-10-21 17:28:09 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:09 --> Input Class Initialized
INFO - 2016-10-21 17:28:09 --> Language Class Initialized
INFO - 2016-10-21 17:28:09 --> Loader Class Initialized
INFO - 2016-10-21 17:28:09 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:09 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:09 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:09 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:28:09 --> Model Class Initialized
INFO - 2016-10-21 17:28:09 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:09 --> Total execution time: 0.0112
INFO - 2016-10-21 17:28:09 --> Config Class Initialized
INFO - 2016-10-21 17:28:09 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:09 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:09 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:09 --> URI Class Initialized
DEBUG - 2016-10-21 17:28:09 --> No URI present. Default controller set.
INFO - 2016-10-21 17:28:09 --> Router Class Initialized
INFO - 2016-10-21 17:28:09 --> Output Class Initialized
INFO - 2016-10-21 17:28:09 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:09 --> Input Class Initialized
INFO - 2016-10-21 17:28:09 --> Language Class Initialized
INFO - 2016-10-21 17:28:09 --> Loader Class Initialized
INFO - 2016-10-21 17:28:09 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:09 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:09 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:09 --> Controller Class Initialized
INFO - 2016-10-21 17:28:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:28:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:28:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:28:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:28:09 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:09 --> Total execution time: 0.0049
INFO - 2016-10-21 17:28:14 --> Config Class Initialized
INFO - 2016-10-21 17:28:14 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:14 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:14 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:14 --> URI Class Initialized
INFO - 2016-10-21 17:28:14 --> Router Class Initialized
INFO - 2016-10-21 17:28:14 --> Output Class Initialized
INFO - 2016-10-21 17:28:14 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:14 --> Input Class Initialized
INFO - 2016-10-21 17:28:14 --> Language Class Initialized
INFO - 2016-10-21 17:28:14 --> Loader Class Initialized
INFO - 2016-10-21 17:28:14 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:14 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:14 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:14 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:28:14 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:28:14 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:28:14 --> Config Class Initialized
INFO - 2016-10-21 17:28:14 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:14 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:14 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:14 --> URI Class Initialized
DEBUG - 2016-10-21 17:28:14 --> No URI present. Default controller set.
INFO - 2016-10-21 17:28:14 --> Router Class Initialized
INFO - 2016-10-21 17:28:14 --> Output Class Initialized
INFO - 2016-10-21 17:28:14 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:14 --> Input Class Initialized
INFO - 2016-10-21 17:28:14 --> Language Class Initialized
INFO - 2016-10-21 17:28:14 --> Loader Class Initialized
INFO - 2016-10-21 17:28:14 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:14 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:14 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:14 --> Controller Class Initialized
INFO - 2016-10-21 17:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:28:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:28:14 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:14 --> Total execution time: 0.0046
INFO - 2016-10-21 17:28:25 --> Config Class Initialized
INFO - 2016-10-21 17:28:25 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:25 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:25 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:25 --> URI Class Initialized
INFO - 2016-10-21 17:28:25 --> Router Class Initialized
INFO - 2016-10-21 17:28:25 --> Output Class Initialized
INFO - 2016-10-21 17:28:25 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:25 --> Input Class Initialized
INFO - 2016-10-21 17:28:25 --> Language Class Initialized
INFO - 2016-10-21 17:28:25 --> Loader Class Initialized
INFO - 2016-10-21 17:28:25 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:25 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:25 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:25 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:28:25 --> Model Class Initialized
INFO - 2016-10-21 17:28:25 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:25 --> Total execution time: 0.0068
INFO - 2016-10-21 17:28:31 --> Config Class Initialized
INFO - 2016-10-21 17:28:31 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:31 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:31 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:31 --> URI Class Initialized
INFO - 2016-10-21 17:28:31 --> Router Class Initialized
INFO - 2016-10-21 17:28:31 --> Output Class Initialized
INFO - 2016-10-21 17:28:31 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:31 --> Input Class Initialized
INFO - 2016-10-21 17:28:31 --> Language Class Initialized
INFO - 2016-10-21 17:28:31 --> Loader Class Initialized
INFO - 2016-10-21 17:28:31 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:31 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:31 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:31 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:28:31 --> Model Class Initialized
INFO - 2016-10-21 17:28:31 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:31 --> Total execution time: 0.0220
INFO - 2016-10-21 17:28:35 --> Config Class Initialized
INFO - 2016-10-21 17:28:35 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:35 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:35 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:35 --> URI Class Initialized
INFO - 2016-10-21 17:28:35 --> Router Class Initialized
INFO - 2016-10-21 17:28:35 --> Output Class Initialized
INFO - 2016-10-21 17:28:35 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:35 --> Input Class Initialized
INFO - 2016-10-21 17:28:35 --> Language Class Initialized
INFO - 2016-10-21 17:28:35 --> Loader Class Initialized
INFO - 2016-10-21 17:28:35 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:35 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:35 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:35 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:28:35 --> Model Class Initialized
INFO - 2016-10-21 17:28:35 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:35 --> Total execution time: 0.0064
INFO - 2016-10-21 17:28:40 --> Config Class Initialized
INFO - 2016-10-21 17:28:40 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:40 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:40 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:40 --> URI Class Initialized
INFO - 2016-10-21 17:28:40 --> Router Class Initialized
INFO - 2016-10-21 17:28:40 --> Output Class Initialized
INFO - 2016-10-21 17:28:40 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:40 --> Input Class Initialized
INFO - 2016-10-21 17:28:40 --> Language Class Initialized
INFO - 2016-10-21 17:28:40 --> Loader Class Initialized
INFO - 2016-10-21 17:28:40 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:40 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:40 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:40 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:28:40 --> Model Class Initialized
INFO - 2016-10-21 17:28:41 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:41 --> Total execution time: 0.0067
INFO - 2016-10-21 17:28:57 --> Config Class Initialized
INFO - 2016-10-21 17:28:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:57 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:57 --> URI Class Initialized
INFO - 2016-10-21 17:28:57 --> Router Class Initialized
INFO - 2016-10-21 17:28:57 --> Output Class Initialized
INFO - 2016-10-21 17:28:57 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:57 --> Input Class Initialized
INFO - 2016-10-21 17:28:57 --> Language Class Initialized
INFO - 2016-10-21 17:28:57 --> Loader Class Initialized
INFO - 2016-10-21 17:28:57 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:57 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:57 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:57 --> Controller Class Initialized
DEBUG - 2016-10-21 17:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:28:57 --> Model Class Initialized
INFO - 2016-10-21 17:28:57 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:57 --> Total execution time: 0.0098
INFO - 2016-10-21 17:28:57 --> Config Class Initialized
INFO - 2016-10-21 17:28:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:28:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:28:57 --> Utf8 Class Initialized
INFO - 2016-10-21 17:28:57 --> URI Class Initialized
DEBUG - 2016-10-21 17:28:57 --> No URI present. Default controller set.
INFO - 2016-10-21 17:28:57 --> Router Class Initialized
INFO - 2016-10-21 17:28:57 --> Output Class Initialized
INFO - 2016-10-21 17:28:57 --> Security Class Initialized
DEBUG - 2016-10-21 17:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:28:57 --> Input Class Initialized
INFO - 2016-10-21 17:28:57 --> Language Class Initialized
INFO - 2016-10-21 17:28:57 --> Loader Class Initialized
INFO - 2016-10-21 17:28:57 --> Helper loaded: url_helper
INFO - 2016-10-21 17:28:57 --> Helper loaded: form_helper
INFO - 2016-10-21 17:28:57 --> Database Driver Class Initialized
INFO - 2016-10-21 17:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:28:57 --> Controller Class Initialized
INFO - 2016-10-21 17:28:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:28:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:28:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:28:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:28:57 --> Final output sent to browser
DEBUG - 2016-10-21 17:28:57 --> Total execution time: 0.0051
INFO - 2016-10-21 17:30:44 --> Config Class Initialized
INFO - 2016-10-21 17:30:44 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:30:44 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:30:44 --> Utf8 Class Initialized
INFO - 2016-10-21 17:30:44 --> URI Class Initialized
DEBUG - 2016-10-21 17:30:44 --> No URI present. Default controller set.
INFO - 2016-10-21 17:30:44 --> Router Class Initialized
INFO - 2016-10-21 17:30:44 --> Output Class Initialized
INFO - 2016-10-21 17:30:44 --> Security Class Initialized
DEBUG - 2016-10-21 17:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:30:44 --> Input Class Initialized
INFO - 2016-10-21 17:30:44 --> Language Class Initialized
INFO - 2016-10-21 17:30:44 --> Loader Class Initialized
INFO - 2016-10-21 17:30:44 --> Helper loaded: url_helper
INFO - 2016-10-21 17:30:44 --> Helper loaded: form_helper
INFO - 2016-10-21 17:30:44 --> Database Driver Class Initialized
INFO - 2016-10-21 17:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:30:44 --> Controller Class Initialized
INFO - 2016-10-21 17:30:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:30:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:30:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:30:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:30:44 --> Final output sent to browser
DEBUG - 2016-10-21 17:30:44 --> Total execution time: 0.0156
INFO - 2016-10-21 17:32:28 --> Config Class Initialized
INFO - 2016-10-21 17:32:28 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:28 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:28 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:28 --> URI Class Initialized
DEBUG - 2016-10-21 17:32:28 --> No URI present. Default controller set.
INFO - 2016-10-21 17:32:28 --> Router Class Initialized
INFO - 2016-10-21 17:32:28 --> Output Class Initialized
INFO - 2016-10-21 17:32:28 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:28 --> Input Class Initialized
INFO - 2016-10-21 17:32:28 --> Language Class Initialized
INFO - 2016-10-21 17:32:28 --> Loader Class Initialized
INFO - 2016-10-21 17:32:28 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:28 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:28 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:28 --> Controller Class Initialized
INFO - 2016-10-21 17:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:32:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:32:28 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:28 --> Total execution time: 0.0065
INFO - 2016-10-21 17:32:30 --> Config Class Initialized
INFO - 2016-10-21 17:32:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:30 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:30 --> URI Class Initialized
INFO - 2016-10-21 17:32:30 --> Router Class Initialized
INFO - 2016-10-21 17:32:30 --> Output Class Initialized
INFO - 2016-10-21 17:32:30 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:30 --> Input Class Initialized
INFO - 2016-10-21 17:32:30 --> Language Class Initialized
INFO - 2016-10-21 17:32:30 --> Loader Class Initialized
INFO - 2016-10-21 17:32:30 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:30 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:30 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:30 --> Controller Class Initialized
DEBUG - 2016-10-21 17:32:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:32:30 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:32:30 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:32:30 --> Config Class Initialized
INFO - 2016-10-21 17:32:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:30 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:30 --> URI Class Initialized
DEBUG - 2016-10-21 17:32:30 --> No URI present. Default controller set.
INFO - 2016-10-21 17:32:30 --> Router Class Initialized
INFO - 2016-10-21 17:32:30 --> Output Class Initialized
INFO - 2016-10-21 17:32:30 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:30 --> Input Class Initialized
INFO - 2016-10-21 17:32:30 --> Language Class Initialized
INFO - 2016-10-21 17:32:30 --> Loader Class Initialized
INFO - 2016-10-21 17:32:30 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:30 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:30 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:30 --> Controller Class Initialized
INFO - 2016-10-21 17:32:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:32:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:32:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:32:30 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:30 --> Total execution time: 0.0046
INFO - 2016-10-21 17:32:35 --> Config Class Initialized
INFO - 2016-10-21 17:32:35 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:35 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:35 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:35 --> URI Class Initialized
INFO - 2016-10-21 17:32:35 --> Router Class Initialized
INFO - 2016-10-21 17:32:35 --> Output Class Initialized
INFO - 2016-10-21 17:32:35 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:35 --> Input Class Initialized
INFO - 2016-10-21 17:32:35 --> Language Class Initialized
INFO - 2016-10-21 17:32:35 --> Loader Class Initialized
INFO - 2016-10-21 17:32:35 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:35 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:35 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:35 --> Controller Class Initialized
DEBUG - 2016-10-21 17:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:32:35 --> Model Class Initialized
INFO - 2016-10-21 17:32:35 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:35 --> Total execution time: 0.0068
INFO - 2016-10-21 17:32:35 --> Config Class Initialized
INFO - 2016-10-21 17:32:35 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:35 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:35 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:35 --> URI Class Initialized
DEBUG - 2016-10-21 17:32:35 --> No URI present. Default controller set.
INFO - 2016-10-21 17:32:35 --> Router Class Initialized
INFO - 2016-10-21 17:32:35 --> Output Class Initialized
INFO - 2016-10-21 17:32:35 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:35 --> Input Class Initialized
INFO - 2016-10-21 17:32:35 --> Language Class Initialized
INFO - 2016-10-21 17:32:35 --> Loader Class Initialized
INFO - 2016-10-21 17:32:35 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:35 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:35 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:35 --> Controller Class Initialized
INFO - 2016-10-21 17:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:32:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:32:35 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:35 --> Total execution time: 0.0048
INFO - 2016-10-21 17:32:39 --> Config Class Initialized
INFO - 2016-10-21 17:32:39 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:39 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:39 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:39 --> URI Class Initialized
INFO - 2016-10-21 17:32:39 --> Router Class Initialized
INFO - 2016-10-21 17:32:39 --> Output Class Initialized
INFO - 2016-10-21 17:32:39 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:39 --> Input Class Initialized
INFO - 2016-10-21 17:32:39 --> Language Class Initialized
INFO - 2016-10-21 17:32:39 --> Loader Class Initialized
INFO - 2016-10-21 17:32:39 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:39 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:39 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:39 --> Controller Class Initialized
DEBUG - 2016-10-21 17:32:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:32:39 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:32:39 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:32:39 --> Config Class Initialized
INFO - 2016-10-21 17:32:39 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:39 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:39 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:39 --> URI Class Initialized
DEBUG - 2016-10-21 17:32:39 --> No URI present. Default controller set.
INFO - 2016-10-21 17:32:39 --> Router Class Initialized
INFO - 2016-10-21 17:32:39 --> Output Class Initialized
INFO - 2016-10-21 17:32:39 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:39 --> Input Class Initialized
INFO - 2016-10-21 17:32:39 --> Language Class Initialized
INFO - 2016-10-21 17:32:39 --> Loader Class Initialized
INFO - 2016-10-21 17:32:39 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:39 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:39 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:39 --> Controller Class Initialized
INFO - 2016-10-21 17:32:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:32:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:32:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:32:39 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:39 --> Total execution time: 0.0043
INFO - 2016-10-21 17:32:47 --> Config Class Initialized
INFO - 2016-10-21 17:32:47 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:47 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:47 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:47 --> URI Class Initialized
INFO - 2016-10-21 17:32:47 --> Router Class Initialized
INFO - 2016-10-21 17:32:47 --> Output Class Initialized
INFO - 2016-10-21 17:32:47 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:47 --> Input Class Initialized
INFO - 2016-10-21 17:32:47 --> Language Class Initialized
INFO - 2016-10-21 17:32:47 --> Loader Class Initialized
INFO - 2016-10-21 17:32:47 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:47 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:47 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:47 --> Controller Class Initialized
DEBUG - 2016-10-21 17:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:32:47 --> Model Class Initialized
INFO - 2016-10-21 17:32:47 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:47 --> Total execution time: 0.0077
INFO - 2016-10-21 17:32:53 --> Config Class Initialized
INFO - 2016-10-21 17:32:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:53 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:53 --> URI Class Initialized
INFO - 2016-10-21 17:32:53 --> Router Class Initialized
INFO - 2016-10-21 17:32:53 --> Output Class Initialized
INFO - 2016-10-21 17:32:53 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:53 --> Input Class Initialized
INFO - 2016-10-21 17:32:53 --> Language Class Initialized
INFO - 2016-10-21 17:32:53 --> Loader Class Initialized
INFO - 2016-10-21 17:32:53 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:53 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:53 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:53 --> Controller Class Initialized
DEBUG - 2016-10-21 17:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:32:53 --> Model Class Initialized
INFO - 2016-10-21 17:32:53 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:53 --> Total execution time: 0.0068
INFO - 2016-10-21 17:32:53 --> Config Class Initialized
INFO - 2016-10-21 17:32:53 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:53 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:53 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:53 --> URI Class Initialized
DEBUG - 2016-10-21 17:32:53 --> No URI present. Default controller set.
INFO - 2016-10-21 17:32:53 --> Router Class Initialized
INFO - 2016-10-21 17:32:53 --> Output Class Initialized
INFO - 2016-10-21 17:32:53 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:53 --> Input Class Initialized
INFO - 2016-10-21 17:32:53 --> Language Class Initialized
INFO - 2016-10-21 17:32:53 --> Loader Class Initialized
INFO - 2016-10-21 17:32:53 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:53 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:53 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:53 --> Controller Class Initialized
INFO - 2016-10-21 17:32:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:32:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:32:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:32:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:32:53 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:53 --> Total execution time: 0.0045
INFO - 2016-10-21 17:32:57 --> Config Class Initialized
INFO - 2016-10-21 17:32:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:57 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:57 --> URI Class Initialized
INFO - 2016-10-21 17:32:57 --> Router Class Initialized
INFO - 2016-10-21 17:32:57 --> Output Class Initialized
INFO - 2016-10-21 17:32:57 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:57 --> Input Class Initialized
INFO - 2016-10-21 17:32:57 --> Language Class Initialized
INFO - 2016-10-21 17:32:57 --> Loader Class Initialized
INFO - 2016-10-21 17:32:57 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:57 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:57 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:57 --> Controller Class Initialized
DEBUG - 2016-10-21 17:32:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:32:57 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:32:57 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:32:57 --> Config Class Initialized
INFO - 2016-10-21 17:32:57 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:32:57 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:32:57 --> Utf8 Class Initialized
INFO - 2016-10-21 17:32:57 --> URI Class Initialized
DEBUG - 2016-10-21 17:32:57 --> No URI present. Default controller set.
INFO - 2016-10-21 17:32:57 --> Router Class Initialized
INFO - 2016-10-21 17:32:57 --> Output Class Initialized
INFO - 2016-10-21 17:32:57 --> Security Class Initialized
DEBUG - 2016-10-21 17:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:32:57 --> Input Class Initialized
INFO - 2016-10-21 17:32:57 --> Language Class Initialized
INFO - 2016-10-21 17:32:57 --> Loader Class Initialized
INFO - 2016-10-21 17:32:57 --> Helper loaded: url_helper
INFO - 2016-10-21 17:32:57 --> Helper loaded: form_helper
INFO - 2016-10-21 17:32:57 --> Database Driver Class Initialized
INFO - 2016-10-21 17:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:32:57 --> Controller Class Initialized
INFO - 2016-10-21 17:32:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:32:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:32:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:32:57 --> Final output sent to browser
DEBUG - 2016-10-21 17:32:57 --> Total execution time: 0.0048
INFO - 2016-10-21 17:33:07 --> Config Class Initialized
INFO - 2016-10-21 17:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:33:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:33:07 --> Utf8 Class Initialized
INFO - 2016-10-21 17:33:07 --> URI Class Initialized
INFO - 2016-10-21 17:33:07 --> Router Class Initialized
INFO - 2016-10-21 17:33:07 --> Output Class Initialized
INFO - 2016-10-21 17:33:07 --> Security Class Initialized
DEBUG - 2016-10-21 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:33:07 --> Input Class Initialized
INFO - 2016-10-21 17:33:07 --> Language Class Initialized
INFO - 2016-10-21 17:33:07 --> Loader Class Initialized
INFO - 2016-10-21 17:33:07 --> Helper loaded: url_helper
INFO - 2016-10-21 17:33:07 --> Helper loaded: form_helper
INFO - 2016-10-21 17:33:07 --> Database Driver Class Initialized
INFO - 2016-10-21 17:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:33:07 --> Controller Class Initialized
DEBUG - 2016-10-21 17:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:33:07 --> Model Class Initialized
INFO - 2016-10-21 17:33:07 --> Final output sent to browser
DEBUG - 2016-10-21 17:33:07 --> Total execution time: 0.0068
INFO - 2016-10-21 17:33:07 --> Config Class Initialized
INFO - 2016-10-21 17:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:33:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:33:07 --> Utf8 Class Initialized
INFO - 2016-10-21 17:33:07 --> URI Class Initialized
DEBUG - 2016-10-21 17:33:07 --> No URI present. Default controller set.
INFO - 2016-10-21 17:33:07 --> Router Class Initialized
INFO - 2016-10-21 17:33:07 --> Output Class Initialized
INFO - 2016-10-21 17:33:07 --> Security Class Initialized
DEBUG - 2016-10-21 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:33:07 --> Input Class Initialized
INFO - 2016-10-21 17:33:07 --> Language Class Initialized
INFO - 2016-10-21 17:33:07 --> Loader Class Initialized
INFO - 2016-10-21 17:33:07 --> Helper loaded: url_helper
INFO - 2016-10-21 17:33:07 --> Helper loaded: form_helper
INFO - 2016-10-21 17:33:07 --> Database Driver Class Initialized
INFO - 2016-10-21 17:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:33:07 --> Controller Class Initialized
INFO - 2016-10-21 17:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:33:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:33:07 --> Final output sent to browser
DEBUG - 2016-10-21 17:33:07 --> Total execution time: 0.0044
INFO - 2016-10-21 17:36:07 --> Config Class Initialized
INFO - 2016-10-21 17:36:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:36:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:36:07 --> Utf8 Class Initialized
INFO - 2016-10-21 17:36:07 --> URI Class Initialized
DEBUG - 2016-10-21 17:36:07 --> No URI present. Default controller set.
INFO - 2016-10-21 17:36:07 --> Router Class Initialized
INFO - 2016-10-21 17:36:07 --> Output Class Initialized
INFO - 2016-10-21 17:36:07 --> Security Class Initialized
DEBUG - 2016-10-21 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:36:07 --> Input Class Initialized
INFO - 2016-10-21 17:36:07 --> Language Class Initialized
INFO - 2016-10-21 17:36:07 --> Loader Class Initialized
INFO - 2016-10-21 17:36:07 --> Helper loaded: url_helper
INFO - 2016-10-21 17:36:07 --> Helper loaded: form_helper
INFO - 2016-10-21 17:36:07 --> Database Driver Class Initialized
INFO - 2016-10-21 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:36:07 --> Controller Class Initialized
INFO - 2016-10-21 17:36:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:36:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:36:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:36:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:36:07 --> Final output sent to browser
DEBUG - 2016-10-21 17:36:07 --> Total execution time: 0.0064
INFO - 2016-10-21 17:36:19 --> Config Class Initialized
INFO - 2016-10-21 17:36:19 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:36:19 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:36:19 --> Utf8 Class Initialized
INFO - 2016-10-21 17:36:19 --> URI Class Initialized
INFO - 2016-10-21 17:36:19 --> Router Class Initialized
INFO - 2016-10-21 17:36:19 --> Output Class Initialized
INFO - 2016-10-21 17:36:19 --> Security Class Initialized
DEBUG - 2016-10-21 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:36:19 --> Input Class Initialized
INFO - 2016-10-21 17:36:19 --> Language Class Initialized
INFO - 2016-10-21 17:36:19 --> Loader Class Initialized
INFO - 2016-10-21 17:36:19 --> Helper loaded: url_helper
INFO - 2016-10-21 17:36:19 --> Helper loaded: form_helper
INFO - 2016-10-21 17:36:19 --> Database Driver Class Initialized
INFO - 2016-10-21 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:36:19 --> Controller Class Initialized
DEBUG - 2016-10-21 17:36:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 17:36:19 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 17:36:19 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 17:36:19 --> Config Class Initialized
INFO - 2016-10-21 17:36:19 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:36:19 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:36:19 --> Utf8 Class Initialized
INFO - 2016-10-21 17:36:19 --> URI Class Initialized
DEBUG - 2016-10-21 17:36:19 --> No URI present. Default controller set.
INFO - 2016-10-21 17:36:19 --> Router Class Initialized
INFO - 2016-10-21 17:36:19 --> Output Class Initialized
INFO - 2016-10-21 17:36:19 --> Security Class Initialized
DEBUG - 2016-10-21 17:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:36:19 --> Input Class Initialized
INFO - 2016-10-21 17:36:19 --> Language Class Initialized
INFO - 2016-10-21 17:36:19 --> Loader Class Initialized
INFO - 2016-10-21 17:36:19 --> Helper loaded: url_helper
INFO - 2016-10-21 17:36:19 --> Helper loaded: form_helper
INFO - 2016-10-21 17:36:19 --> Database Driver Class Initialized
INFO - 2016-10-21 17:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:36:19 --> Controller Class Initialized
INFO - 2016-10-21 17:36:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:36:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 17:36:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:36:19 --> Final output sent to browser
DEBUG - 2016-10-21 17:36:19 --> Total execution time: 0.0044
INFO - 2016-10-21 17:36:31 --> Config Class Initialized
INFO - 2016-10-21 17:36:31 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:36:31 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:36:31 --> Utf8 Class Initialized
INFO - 2016-10-21 17:36:31 --> URI Class Initialized
INFO - 2016-10-21 17:36:31 --> Router Class Initialized
INFO - 2016-10-21 17:36:31 --> Output Class Initialized
INFO - 2016-10-21 17:36:31 --> Security Class Initialized
DEBUG - 2016-10-21 17:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:36:31 --> Input Class Initialized
INFO - 2016-10-21 17:36:31 --> Language Class Initialized
INFO - 2016-10-21 17:36:31 --> Loader Class Initialized
INFO - 2016-10-21 17:36:31 --> Helper loaded: url_helper
INFO - 2016-10-21 17:36:31 --> Helper loaded: form_helper
INFO - 2016-10-21 17:36:31 --> Database Driver Class Initialized
INFO - 2016-10-21 17:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:36:31 --> Controller Class Initialized
DEBUG - 2016-10-21 17:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 17:36:31 --> Model Class Initialized
INFO - 2016-10-21 17:36:31 --> Final output sent to browser
DEBUG - 2016-10-21 17:36:31 --> Total execution time: 0.0071
INFO - 2016-10-21 17:36:31 --> Config Class Initialized
INFO - 2016-10-21 17:36:31 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:36:31 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:36:31 --> Utf8 Class Initialized
INFO - 2016-10-21 17:36:31 --> URI Class Initialized
DEBUG - 2016-10-21 17:36:31 --> No URI present. Default controller set.
INFO - 2016-10-21 17:36:31 --> Router Class Initialized
INFO - 2016-10-21 17:36:31 --> Output Class Initialized
INFO - 2016-10-21 17:36:31 --> Security Class Initialized
DEBUG - 2016-10-21 17:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:36:31 --> Input Class Initialized
INFO - 2016-10-21 17:36:31 --> Language Class Initialized
INFO - 2016-10-21 17:36:31 --> Loader Class Initialized
INFO - 2016-10-21 17:36:31 --> Helper loaded: url_helper
INFO - 2016-10-21 17:36:31 --> Helper loaded: form_helper
INFO - 2016-10-21 17:36:31 --> Database Driver Class Initialized
INFO - 2016-10-21 17:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:36:31 --> Controller Class Initialized
INFO - 2016-10-21 17:36:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:36:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:36:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:36:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:36:31 --> Final output sent to browser
DEBUG - 2016-10-21 17:36:31 --> Total execution time: 0.0044
INFO - 2016-10-21 17:41:52 --> Config Class Initialized
INFO - 2016-10-21 17:41:52 --> Hooks Class Initialized
DEBUG - 2016-10-21 17:41:52 --> UTF-8 Support Enabled
INFO - 2016-10-21 17:41:52 --> Utf8 Class Initialized
INFO - 2016-10-21 17:41:52 --> URI Class Initialized
DEBUG - 2016-10-21 17:41:52 --> No URI present. Default controller set.
INFO - 2016-10-21 17:41:52 --> Router Class Initialized
INFO - 2016-10-21 17:41:52 --> Output Class Initialized
INFO - 2016-10-21 17:41:52 --> Security Class Initialized
DEBUG - 2016-10-21 17:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 17:41:52 --> Input Class Initialized
INFO - 2016-10-21 17:41:52 --> Language Class Initialized
INFO - 2016-10-21 17:41:52 --> Loader Class Initialized
INFO - 2016-10-21 17:41:52 --> Helper loaded: url_helper
INFO - 2016-10-21 17:41:52 --> Helper loaded: form_helper
INFO - 2016-10-21 17:41:52 --> Database Driver Class Initialized
INFO - 2016-10-21 17:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 17:41:52 --> Controller Class Initialized
INFO - 2016-10-21 17:41:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 17:41:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 17:41:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 17:41:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 17:41:52 --> Final output sent to browser
DEBUG - 2016-10-21 17:41:52 --> Total execution time: 0.0058
INFO - 2016-10-21 18:03:54 --> Config Class Initialized
INFO - 2016-10-21 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:03:54 --> Utf8 Class Initialized
INFO - 2016-10-21 18:03:54 --> URI Class Initialized
INFO - 2016-10-21 18:03:54 --> Router Class Initialized
INFO - 2016-10-21 18:03:54 --> Output Class Initialized
INFO - 2016-10-21 18:03:54 --> Security Class Initialized
DEBUG - 2016-10-21 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:03:54 --> Input Class Initialized
INFO - 2016-10-21 18:03:54 --> Language Class Initialized
INFO - 2016-10-21 18:03:54 --> Loader Class Initialized
INFO - 2016-10-21 18:03:54 --> Helper loaded: url_helper
INFO - 2016-10-21 18:03:54 --> Helper loaded: form_helper
INFO - 2016-10-21 18:03:54 --> Database Driver Class Initialized
INFO - 2016-10-21 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:03:54 --> Controller Class Initialized
DEBUG - 2016-10-21 18:03:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:03:54 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:03:54 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:03:54 --> Config Class Initialized
INFO - 2016-10-21 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:03:54 --> Utf8 Class Initialized
INFO - 2016-10-21 18:03:54 --> URI Class Initialized
DEBUG - 2016-10-21 18:03:54 --> No URI present. Default controller set.
INFO - 2016-10-21 18:03:54 --> Router Class Initialized
INFO - 2016-10-21 18:03:54 --> Output Class Initialized
INFO - 2016-10-21 18:03:54 --> Security Class Initialized
DEBUG - 2016-10-21 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:03:54 --> Input Class Initialized
INFO - 2016-10-21 18:03:54 --> Language Class Initialized
INFO - 2016-10-21 18:03:54 --> Loader Class Initialized
INFO - 2016-10-21 18:03:54 --> Helper loaded: url_helper
INFO - 2016-10-21 18:03:54 --> Helper loaded: form_helper
INFO - 2016-10-21 18:03:54 --> Database Driver Class Initialized
INFO - 2016-10-21 18:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:03:54 --> Controller Class Initialized
INFO - 2016-10-21 18:03:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:03:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:03:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:03:54 --> Final output sent to browser
DEBUG - 2016-10-21 18:03:54 --> Total execution time: 0.0160
INFO - 2016-10-21 18:04:05 --> Config Class Initialized
INFO - 2016-10-21 18:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:04:05 --> Utf8 Class Initialized
INFO - 2016-10-21 18:04:05 --> URI Class Initialized
INFO - 2016-10-21 18:04:05 --> Router Class Initialized
INFO - 2016-10-21 18:04:05 --> Output Class Initialized
INFO - 2016-10-21 18:04:05 --> Security Class Initialized
DEBUG - 2016-10-21 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:04:05 --> Input Class Initialized
INFO - 2016-10-21 18:04:05 --> Language Class Initialized
INFO - 2016-10-21 18:04:05 --> Loader Class Initialized
INFO - 2016-10-21 18:04:05 --> Helper loaded: url_helper
INFO - 2016-10-21 18:04:05 --> Helper loaded: form_helper
INFO - 2016-10-21 18:04:05 --> Database Driver Class Initialized
INFO - 2016-10-21 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:04:05 --> Controller Class Initialized
DEBUG - 2016-10-21 18:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:04:05 --> Model Class Initialized
INFO - 2016-10-21 18:04:05 --> Final output sent to browser
DEBUG - 2016-10-21 18:04:05 --> Total execution time: 0.0094
INFO - 2016-10-21 18:04:05 --> Config Class Initialized
INFO - 2016-10-21 18:04:05 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:04:05 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:04:05 --> Utf8 Class Initialized
INFO - 2016-10-21 18:04:05 --> URI Class Initialized
DEBUG - 2016-10-21 18:04:05 --> No URI present. Default controller set.
INFO - 2016-10-21 18:04:05 --> Router Class Initialized
INFO - 2016-10-21 18:04:05 --> Output Class Initialized
INFO - 2016-10-21 18:04:05 --> Security Class Initialized
DEBUG - 2016-10-21 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:04:05 --> Input Class Initialized
INFO - 2016-10-21 18:04:05 --> Language Class Initialized
INFO - 2016-10-21 18:04:05 --> Loader Class Initialized
INFO - 2016-10-21 18:04:05 --> Helper loaded: url_helper
INFO - 2016-10-21 18:04:05 --> Helper loaded: form_helper
INFO - 2016-10-21 18:04:05 --> Database Driver Class Initialized
INFO - 2016-10-21 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:04:05 --> Controller Class Initialized
INFO - 2016-10-21 18:04:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:04:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 18:04:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 18:04:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:04:05 --> Final output sent to browser
DEBUG - 2016-10-21 18:04:05 --> Total execution time: 0.0047
INFO - 2016-10-21 18:10:43 --> Config Class Initialized
INFO - 2016-10-21 18:10:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:10:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:10:43 --> Utf8 Class Initialized
INFO - 2016-10-21 18:10:43 --> URI Class Initialized
INFO - 2016-10-21 18:10:43 --> Router Class Initialized
INFO - 2016-10-21 18:10:43 --> Output Class Initialized
INFO - 2016-10-21 18:10:43 --> Security Class Initialized
DEBUG - 2016-10-21 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:10:43 --> Input Class Initialized
INFO - 2016-10-21 18:10:43 --> Language Class Initialized
INFO - 2016-10-21 18:10:43 --> Loader Class Initialized
INFO - 2016-10-21 18:10:43 --> Helper loaded: url_helper
INFO - 2016-10-21 18:10:43 --> Helper loaded: form_helper
INFO - 2016-10-21 18:10:43 --> Database Driver Class Initialized
INFO - 2016-10-21 18:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:10:43 --> Controller Class Initialized
DEBUG - 2016-10-21 18:10:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:10:43 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:10:43 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:10:43 --> Config Class Initialized
INFO - 2016-10-21 18:10:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:10:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:10:43 --> Utf8 Class Initialized
INFO - 2016-10-21 18:10:43 --> URI Class Initialized
DEBUG - 2016-10-21 18:10:43 --> No URI present. Default controller set.
INFO - 2016-10-21 18:10:43 --> Router Class Initialized
INFO - 2016-10-21 18:10:43 --> Output Class Initialized
INFO - 2016-10-21 18:10:43 --> Security Class Initialized
DEBUG - 2016-10-21 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:10:43 --> Input Class Initialized
INFO - 2016-10-21 18:10:43 --> Language Class Initialized
INFO - 2016-10-21 18:10:43 --> Loader Class Initialized
INFO - 2016-10-21 18:10:43 --> Helper loaded: url_helper
INFO - 2016-10-21 18:10:43 --> Helper loaded: form_helper
INFO - 2016-10-21 18:10:43 --> Database Driver Class Initialized
INFO - 2016-10-21 18:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:10:43 --> Controller Class Initialized
INFO - 2016-10-21 18:10:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:10:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:10:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:10:43 --> Final output sent to browser
DEBUG - 2016-10-21 18:10:43 --> Total execution time: 0.0047
INFO - 2016-10-21 18:10:56 --> Config Class Initialized
INFO - 2016-10-21 18:10:56 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:10:56 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:10:56 --> Utf8 Class Initialized
INFO - 2016-10-21 18:10:56 --> URI Class Initialized
INFO - 2016-10-21 18:10:56 --> Router Class Initialized
INFO - 2016-10-21 18:10:56 --> Output Class Initialized
INFO - 2016-10-21 18:10:56 --> Security Class Initialized
DEBUG - 2016-10-21 18:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:10:56 --> Input Class Initialized
INFO - 2016-10-21 18:10:56 --> Language Class Initialized
INFO - 2016-10-21 18:10:56 --> Loader Class Initialized
INFO - 2016-10-21 18:10:56 --> Helper loaded: url_helper
INFO - 2016-10-21 18:10:56 --> Helper loaded: form_helper
INFO - 2016-10-21 18:10:56 --> Database Driver Class Initialized
INFO - 2016-10-21 18:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:10:56 --> Controller Class Initialized
DEBUG - 2016-10-21 18:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:10:56 --> Model Class Initialized
INFO - 2016-10-21 18:10:56 --> Final output sent to browser
DEBUG - 2016-10-21 18:10:56 --> Total execution time: 0.0101
INFO - 2016-10-21 18:11:02 --> Config Class Initialized
INFO - 2016-10-21 18:11:02 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:11:02 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:11:02 --> Utf8 Class Initialized
INFO - 2016-10-21 18:11:02 --> URI Class Initialized
INFO - 2016-10-21 18:11:02 --> Router Class Initialized
INFO - 2016-10-21 18:11:02 --> Output Class Initialized
INFO - 2016-10-21 18:11:02 --> Security Class Initialized
DEBUG - 2016-10-21 18:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:11:02 --> Input Class Initialized
INFO - 2016-10-21 18:11:02 --> Language Class Initialized
INFO - 2016-10-21 18:11:02 --> Loader Class Initialized
INFO - 2016-10-21 18:11:02 --> Helper loaded: url_helper
INFO - 2016-10-21 18:11:02 --> Helper loaded: form_helper
INFO - 2016-10-21 18:11:02 --> Database Driver Class Initialized
INFO - 2016-10-21 18:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:11:02 --> Controller Class Initialized
DEBUG - 2016-10-21 18:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:11:02 --> Model Class Initialized
INFO - 2016-10-21 18:11:02 --> Final output sent to browser
DEBUG - 2016-10-21 18:11:02 --> Total execution time: 0.0064
INFO - 2016-10-21 18:11:02 --> Config Class Initialized
INFO - 2016-10-21 18:11:02 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:11:02 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:11:02 --> Utf8 Class Initialized
INFO - 2016-10-21 18:11:02 --> URI Class Initialized
DEBUG - 2016-10-21 18:11:02 --> No URI present. Default controller set.
INFO - 2016-10-21 18:11:02 --> Router Class Initialized
INFO - 2016-10-21 18:11:02 --> Output Class Initialized
INFO - 2016-10-21 18:11:02 --> Security Class Initialized
DEBUG - 2016-10-21 18:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:11:02 --> Input Class Initialized
INFO - 2016-10-21 18:11:02 --> Language Class Initialized
INFO - 2016-10-21 18:11:02 --> Loader Class Initialized
INFO - 2016-10-21 18:11:02 --> Helper loaded: url_helper
INFO - 2016-10-21 18:11:02 --> Helper loaded: form_helper
INFO - 2016-10-21 18:11:02 --> Database Driver Class Initialized
INFO - 2016-10-21 18:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:11:02 --> Controller Class Initialized
INFO - 2016-10-21 18:11:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:11:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 18:11:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 18:11:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:11:02 --> Final output sent to browser
DEBUG - 2016-10-21 18:11:02 --> Total execution time: 0.0044
INFO - 2016-10-21 18:13:20 --> Config Class Initialized
INFO - 2016-10-21 18:13:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:13:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:13:20 --> Utf8 Class Initialized
INFO - 2016-10-21 18:13:20 --> URI Class Initialized
INFO - 2016-10-21 18:13:20 --> Router Class Initialized
INFO - 2016-10-21 18:13:20 --> Output Class Initialized
INFO - 2016-10-21 18:13:20 --> Security Class Initialized
DEBUG - 2016-10-21 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:13:20 --> Input Class Initialized
INFO - 2016-10-21 18:13:20 --> Language Class Initialized
INFO - 2016-10-21 18:13:20 --> Loader Class Initialized
INFO - 2016-10-21 18:13:20 --> Helper loaded: url_helper
INFO - 2016-10-21 18:13:20 --> Helper loaded: form_helper
INFO - 2016-10-21 18:13:20 --> Database Driver Class Initialized
INFO - 2016-10-21 18:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:13:20 --> Controller Class Initialized
DEBUG - 2016-10-21 18:13:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:13:20 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:13:20 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:13:20 --> Config Class Initialized
INFO - 2016-10-21 18:13:20 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:13:20 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:13:20 --> Utf8 Class Initialized
INFO - 2016-10-21 18:13:20 --> URI Class Initialized
DEBUG - 2016-10-21 18:13:20 --> No URI present. Default controller set.
INFO - 2016-10-21 18:13:20 --> Router Class Initialized
INFO - 2016-10-21 18:13:20 --> Output Class Initialized
INFO - 2016-10-21 18:13:20 --> Security Class Initialized
DEBUG - 2016-10-21 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:13:20 --> Input Class Initialized
INFO - 2016-10-21 18:13:20 --> Language Class Initialized
INFO - 2016-10-21 18:13:20 --> Loader Class Initialized
INFO - 2016-10-21 18:13:20 --> Helper loaded: url_helper
INFO - 2016-10-21 18:13:20 --> Helper loaded: form_helper
INFO - 2016-10-21 18:13:20 --> Database Driver Class Initialized
INFO - 2016-10-21 18:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:13:20 --> Controller Class Initialized
INFO - 2016-10-21 18:13:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:13:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:13:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:13:20 --> Final output sent to browser
DEBUG - 2016-10-21 18:13:20 --> Total execution time: 0.0046
INFO - 2016-10-21 18:13:29 --> Config Class Initialized
INFO - 2016-10-21 18:13:29 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:13:29 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:13:29 --> Utf8 Class Initialized
INFO - 2016-10-21 18:13:29 --> URI Class Initialized
INFO - 2016-10-21 18:13:29 --> Router Class Initialized
INFO - 2016-10-21 18:13:29 --> Output Class Initialized
INFO - 2016-10-21 18:13:29 --> Security Class Initialized
DEBUG - 2016-10-21 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:13:29 --> Input Class Initialized
INFO - 2016-10-21 18:13:29 --> Language Class Initialized
INFO - 2016-10-21 18:13:29 --> Loader Class Initialized
INFO - 2016-10-21 18:13:29 --> Helper loaded: url_helper
INFO - 2016-10-21 18:13:29 --> Helper loaded: form_helper
INFO - 2016-10-21 18:13:29 --> Database Driver Class Initialized
INFO - 2016-10-21 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:13:29 --> Controller Class Initialized
DEBUG - 2016-10-21 18:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:13:29 --> Model Class Initialized
INFO - 2016-10-21 18:13:29 --> Final output sent to browser
DEBUG - 2016-10-21 18:13:29 --> Total execution time: 0.0067
INFO - 2016-10-21 18:13:29 --> Config Class Initialized
INFO - 2016-10-21 18:13:29 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:13:29 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:13:29 --> Utf8 Class Initialized
INFO - 2016-10-21 18:13:29 --> URI Class Initialized
DEBUG - 2016-10-21 18:13:29 --> No URI present. Default controller set.
INFO - 2016-10-21 18:13:29 --> Router Class Initialized
INFO - 2016-10-21 18:13:29 --> Output Class Initialized
INFO - 2016-10-21 18:13:29 --> Security Class Initialized
DEBUG - 2016-10-21 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:13:29 --> Input Class Initialized
INFO - 2016-10-21 18:13:29 --> Language Class Initialized
INFO - 2016-10-21 18:13:29 --> Loader Class Initialized
INFO - 2016-10-21 18:13:29 --> Helper loaded: url_helper
INFO - 2016-10-21 18:13:29 --> Helper loaded: form_helper
INFO - 2016-10-21 18:13:29 --> Database Driver Class Initialized
INFO - 2016-10-21 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:13:29 --> Controller Class Initialized
INFO - 2016-10-21 18:13:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:13:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 18:13:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 18:13:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:13:29 --> Final output sent to browser
DEBUG - 2016-10-21 18:13:29 --> Total execution time: 0.0047
INFO - 2016-10-21 18:31:00 --> Config Class Initialized
INFO - 2016-10-21 18:31:00 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:31:00 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:31:00 --> Utf8 Class Initialized
INFO - 2016-10-21 18:31:00 --> URI Class Initialized
INFO - 2016-10-21 18:31:00 --> Router Class Initialized
INFO - 2016-10-21 18:31:00 --> Output Class Initialized
INFO - 2016-10-21 18:31:00 --> Security Class Initialized
DEBUG - 2016-10-21 18:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:31:00 --> Input Class Initialized
INFO - 2016-10-21 18:31:00 --> Language Class Initialized
INFO - 2016-10-21 18:31:00 --> Loader Class Initialized
INFO - 2016-10-21 18:31:00 --> Helper loaded: url_helper
INFO - 2016-10-21 18:31:00 --> Helper loaded: form_helper
INFO - 2016-10-21 18:31:00 --> Database Driver Class Initialized
INFO - 2016-10-21 18:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:31:00 --> Controller Class Initialized
DEBUG - 2016-10-21 18:31:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:31:00 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:31:00 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:31:00 --> Config Class Initialized
INFO - 2016-10-21 18:31:00 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:31:00 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:31:00 --> Utf8 Class Initialized
INFO - 2016-10-21 18:31:00 --> URI Class Initialized
DEBUG - 2016-10-21 18:31:00 --> No URI present. Default controller set.
INFO - 2016-10-21 18:31:00 --> Router Class Initialized
INFO - 2016-10-21 18:31:00 --> Output Class Initialized
INFO - 2016-10-21 18:31:00 --> Security Class Initialized
DEBUG - 2016-10-21 18:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:31:00 --> Input Class Initialized
INFO - 2016-10-21 18:31:00 --> Language Class Initialized
INFO - 2016-10-21 18:31:00 --> Loader Class Initialized
INFO - 2016-10-21 18:31:00 --> Helper loaded: url_helper
INFO - 2016-10-21 18:31:00 --> Helper loaded: form_helper
INFO - 2016-10-21 18:31:00 --> Database Driver Class Initialized
INFO - 2016-10-21 18:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:31:00 --> Controller Class Initialized
INFO - 2016-10-21 18:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:31:00 --> Final output sent to browser
DEBUG - 2016-10-21 18:31:00 --> Total execution time: 0.0049
INFO - 2016-10-21 18:51:10 --> Config Class Initialized
INFO - 2016-10-21 18:51:10 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:51:10 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:51:10 --> Utf8 Class Initialized
INFO - 2016-10-21 18:51:10 --> URI Class Initialized
DEBUG - 2016-10-21 18:51:10 --> No URI present. Default controller set.
INFO - 2016-10-21 18:51:10 --> Router Class Initialized
INFO - 2016-10-21 18:51:10 --> Output Class Initialized
INFO - 2016-10-21 18:51:10 --> Security Class Initialized
DEBUG - 2016-10-21 18:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:51:10 --> Input Class Initialized
INFO - 2016-10-21 18:51:10 --> Language Class Initialized
INFO - 2016-10-21 18:51:10 --> Loader Class Initialized
INFO - 2016-10-21 18:51:10 --> Helper loaded: url_helper
INFO - 2016-10-21 18:51:10 --> Helper loaded: form_helper
INFO - 2016-10-21 18:51:10 --> Database Driver Class Initialized
INFO - 2016-10-21 18:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:51:10 --> Controller Class Initialized
INFO - 2016-10-21 18:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:51:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:51:10 --> Final output sent to browser
DEBUG - 2016-10-21 18:51:10 --> Total execution time: 0.0060
INFO - 2016-10-21 18:51:25 --> Config Class Initialized
INFO - 2016-10-21 18:51:25 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:51:25 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:51:25 --> Utf8 Class Initialized
INFO - 2016-10-21 18:51:25 --> URI Class Initialized
INFO - 2016-10-21 18:51:25 --> Router Class Initialized
INFO - 2016-10-21 18:51:25 --> Output Class Initialized
INFO - 2016-10-21 18:51:25 --> Security Class Initialized
DEBUG - 2016-10-21 18:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:51:25 --> Input Class Initialized
INFO - 2016-10-21 18:51:25 --> Language Class Initialized
INFO - 2016-10-21 18:51:25 --> Loader Class Initialized
INFO - 2016-10-21 18:51:25 --> Helper loaded: url_helper
INFO - 2016-10-21 18:51:25 --> Helper loaded: form_helper
INFO - 2016-10-21 18:51:25 --> Database Driver Class Initialized
INFO - 2016-10-21 18:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:51:25 --> Controller Class Initialized
DEBUG - 2016-10-21 18:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:51:25 --> Model Class Initialized
INFO - 2016-10-21 18:51:25 --> Final output sent to browser
DEBUG - 2016-10-21 18:51:25 --> Total execution time: 0.0066
INFO - 2016-10-21 18:51:25 --> Config Class Initialized
INFO - 2016-10-21 18:51:25 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:51:25 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:51:25 --> Utf8 Class Initialized
INFO - 2016-10-21 18:51:25 --> URI Class Initialized
DEBUG - 2016-10-21 18:51:25 --> No URI present. Default controller set.
INFO - 2016-10-21 18:51:25 --> Router Class Initialized
INFO - 2016-10-21 18:51:25 --> Output Class Initialized
INFO - 2016-10-21 18:51:25 --> Security Class Initialized
DEBUG - 2016-10-21 18:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:51:25 --> Input Class Initialized
INFO - 2016-10-21 18:51:25 --> Language Class Initialized
INFO - 2016-10-21 18:51:25 --> Loader Class Initialized
INFO - 2016-10-21 18:51:25 --> Helper loaded: url_helper
INFO - 2016-10-21 18:51:25 --> Helper loaded: form_helper
INFO - 2016-10-21 18:51:25 --> Database Driver Class Initialized
INFO - 2016-10-21 18:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:51:25 --> Controller Class Initialized
INFO - 2016-10-21 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 18:51:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:51:25 --> Final output sent to browser
DEBUG - 2016-10-21 18:51:25 --> Total execution time: 0.0045
INFO - 2016-10-21 18:51:39 --> Config Class Initialized
INFO - 2016-10-21 18:51:39 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:51:39 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:51:39 --> Utf8 Class Initialized
INFO - 2016-10-21 18:51:39 --> URI Class Initialized
INFO - 2016-10-21 18:51:39 --> Router Class Initialized
INFO - 2016-10-21 18:51:39 --> Output Class Initialized
INFO - 2016-10-21 18:51:39 --> Security Class Initialized
DEBUG - 2016-10-21 18:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:51:39 --> Input Class Initialized
INFO - 2016-10-21 18:51:39 --> Language Class Initialized
INFO - 2016-10-21 18:51:39 --> Loader Class Initialized
INFO - 2016-10-21 18:51:39 --> Helper loaded: url_helper
INFO - 2016-10-21 18:51:39 --> Helper loaded: form_helper
INFO - 2016-10-21 18:51:39 --> Database Driver Class Initialized
INFO - 2016-10-21 18:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:51:39 --> Controller Class Initialized
DEBUG - 2016-10-21 18:51:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:51:39 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:51:39 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:51:39 --> Config Class Initialized
INFO - 2016-10-21 18:51:39 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:51:39 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:51:39 --> Utf8 Class Initialized
INFO - 2016-10-21 18:51:39 --> URI Class Initialized
DEBUG - 2016-10-21 18:51:39 --> No URI present. Default controller set.
INFO - 2016-10-21 18:51:39 --> Router Class Initialized
INFO - 2016-10-21 18:51:39 --> Output Class Initialized
INFO - 2016-10-21 18:51:39 --> Security Class Initialized
DEBUG - 2016-10-21 18:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:51:39 --> Input Class Initialized
INFO - 2016-10-21 18:51:39 --> Language Class Initialized
INFO - 2016-10-21 18:51:39 --> Loader Class Initialized
INFO - 2016-10-21 18:51:39 --> Helper loaded: url_helper
INFO - 2016-10-21 18:51:39 --> Helper loaded: form_helper
INFO - 2016-10-21 18:51:39 --> Database Driver Class Initialized
INFO - 2016-10-21 18:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:51:39 --> Controller Class Initialized
INFO - 2016-10-21 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:51:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:51:39 --> Final output sent to browser
DEBUG - 2016-10-21 18:51:39 --> Total execution time: 0.0045
INFO - 2016-10-21 18:51:58 --> Config Class Initialized
INFO - 2016-10-21 18:51:58 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:51:58 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:51:58 --> Utf8 Class Initialized
INFO - 2016-10-21 18:51:58 --> URI Class Initialized
INFO - 2016-10-21 18:51:58 --> Router Class Initialized
INFO - 2016-10-21 18:51:58 --> Output Class Initialized
INFO - 2016-10-21 18:51:58 --> Security Class Initialized
DEBUG - 2016-10-21 18:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:51:58 --> Input Class Initialized
INFO - 2016-10-21 18:51:58 --> Language Class Initialized
INFO - 2016-10-21 18:51:58 --> Loader Class Initialized
INFO - 2016-10-21 18:51:58 --> Helper loaded: url_helper
INFO - 2016-10-21 18:51:58 --> Helper loaded: form_helper
INFO - 2016-10-21 18:51:58 --> Database Driver Class Initialized
INFO - 2016-10-21 18:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:51:58 --> Controller Class Initialized
DEBUG - 2016-10-21 18:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:51:58 --> Model Class Initialized
INFO - 2016-10-21 18:51:58 --> Final output sent to browser
DEBUG - 2016-10-21 18:51:58 --> Total execution time: 0.0072
INFO - 2016-10-21 18:52:08 --> Config Class Initialized
INFO - 2016-10-21 18:52:08 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:08 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:08 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:08 --> URI Class Initialized
INFO - 2016-10-21 18:52:08 --> Router Class Initialized
INFO - 2016-10-21 18:52:08 --> Output Class Initialized
INFO - 2016-10-21 18:52:08 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:08 --> Input Class Initialized
INFO - 2016-10-21 18:52:08 --> Language Class Initialized
INFO - 2016-10-21 18:52:08 --> Loader Class Initialized
INFO - 2016-10-21 18:52:08 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:08 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:08 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:08 --> Controller Class Initialized
DEBUG - 2016-10-21 18:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:52:08 --> Model Class Initialized
INFO - 2016-10-21 18:52:08 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:08 --> Total execution time: 0.0066
INFO - 2016-10-21 18:52:08 --> Config Class Initialized
INFO - 2016-10-21 18:52:08 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:08 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:08 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:08 --> URI Class Initialized
DEBUG - 2016-10-21 18:52:08 --> No URI present. Default controller set.
INFO - 2016-10-21 18:52:08 --> Router Class Initialized
INFO - 2016-10-21 18:52:08 --> Output Class Initialized
INFO - 2016-10-21 18:52:08 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:08 --> Input Class Initialized
INFO - 2016-10-21 18:52:08 --> Language Class Initialized
INFO - 2016-10-21 18:52:08 --> Loader Class Initialized
INFO - 2016-10-21 18:52:08 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:08 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:08 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:08 --> Controller Class Initialized
INFO - 2016-10-21 18:52:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:52:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 18:52:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 18:52:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:52:08 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:08 --> Total execution time: 0.0046
INFO - 2016-10-21 18:52:15 --> Config Class Initialized
INFO - 2016-10-21 18:52:15 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:15 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:15 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:15 --> URI Class Initialized
INFO - 2016-10-21 18:52:15 --> Router Class Initialized
INFO - 2016-10-21 18:52:15 --> Output Class Initialized
INFO - 2016-10-21 18:52:15 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:15 --> Input Class Initialized
INFO - 2016-10-21 18:52:15 --> Language Class Initialized
INFO - 2016-10-21 18:52:15 --> Loader Class Initialized
INFO - 2016-10-21 18:52:15 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:15 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:15 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:15 --> Controller Class Initialized
INFO - 2016-10-21 18:52:15 --> Form Validation Class Initialized
INFO - 2016-10-21 18:52:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:52:15 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:15 --> Total execution time: 0.0094
INFO - 2016-10-21 18:52:35 --> Config Class Initialized
INFO - 2016-10-21 18:52:35 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:35 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:35 --> URI Class Initialized
INFO - 2016-10-21 18:52:35 --> Router Class Initialized
INFO - 2016-10-21 18:52:35 --> Output Class Initialized
INFO - 2016-10-21 18:52:35 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:35 --> Input Class Initialized
INFO - 2016-10-21 18:52:35 --> Language Class Initialized
INFO - 2016-10-21 18:52:35 --> Loader Class Initialized
INFO - 2016-10-21 18:52:35 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:35 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:35 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:35 --> Controller Class Initialized
INFO - 2016-10-21 18:52:35 --> Form Validation Class Initialized
INFO - 2016-10-21 18:52:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:52:35 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:35 --> Total execution time: 0.0069
INFO - 2016-10-21 18:52:38 --> Config Class Initialized
INFO - 2016-10-21 18:52:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:38 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:38 --> URI Class Initialized
INFO - 2016-10-21 18:52:38 --> Router Class Initialized
INFO - 2016-10-21 18:52:38 --> Output Class Initialized
INFO - 2016-10-21 18:52:38 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:38 --> Input Class Initialized
INFO - 2016-10-21 18:52:38 --> Language Class Initialized
INFO - 2016-10-21 18:52:38 --> Loader Class Initialized
INFO - 2016-10-21 18:52:38 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:38 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:38 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:38 --> Controller Class Initialized
INFO - 2016-10-21 18:52:38 --> Form Validation Class Initialized
INFO - 2016-10-21 18:52:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:52:38 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:38 --> Total execution time: 0.0066
INFO - 2016-10-21 18:52:40 --> Config Class Initialized
INFO - 2016-10-21 18:52:40 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:40 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:40 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:40 --> URI Class Initialized
INFO - 2016-10-21 18:52:40 --> Router Class Initialized
INFO - 2016-10-21 18:52:40 --> Output Class Initialized
INFO - 2016-10-21 18:52:40 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:40 --> Input Class Initialized
INFO - 2016-10-21 18:52:40 --> Language Class Initialized
INFO - 2016-10-21 18:52:40 --> Loader Class Initialized
INFO - 2016-10-21 18:52:40 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:40 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:40 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:40 --> Controller Class Initialized
INFO - 2016-10-21 18:52:40 --> Form Validation Class Initialized
INFO - 2016-10-21 18:52:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:52:40 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:40 --> Total execution time: 0.0068
INFO - 2016-10-21 18:52:49 --> Config Class Initialized
INFO - 2016-10-21 18:52:49 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:49 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:49 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:49 --> URI Class Initialized
INFO - 2016-10-21 18:52:49 --> Router Class Initialized
INFO - 2016-10-21 18:52:49 --> Output Class Initialized
INFO - 2016-10-21 18:52:49 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:49 --> Input Class Initialized
INFO - 2016-10-21 18:52:49 --> Language Class Initialized
INFO - 2016-10-21 18:52:49 --> Loader Class Initialized
INFO - 2016-10-21 18:52:49 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:49 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:49 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:49 --> Controller Class Initialized
INFO - 2016-10-21 18:52:49 --> Form Validation Class Initialized
INFO - 2016-10-21 18:52:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:52:49 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:49 --> Total execution time: 0.0104
INFO - 2016-10-21 18:52:52 --> Config Class Initialized
INFO - 2016-10-21 18:52:52 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:52:52 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:52:52 --> Utf8 Class Initialized
INFO - 2016-10-21 18:52:52 --> URI Class Initialized
INFO - 2016-10-21 18:52:52 --> Router Class Initialized
INFO - 2016-10-21 18:52:52 --> Output Class Initialized
INFO - 2016-10-21 18:52:52 --> Security Class Initialized
DEBUG - 2016-10-21 18:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:52:52 --> Input Class Initialized
INFO - 2016-10-21 18:52:52 --> Language Class Initialized
INFO - 2016-10-21 18:52:52 --> Loader Class Initialized
INFO - 2016-10-21 18:52:52 --> Helper loaded: url_helper
INFO - 2016-10-21 18:52:52 --> Helper loaded: form_helper
INFO - 2016-10-21 18:52:52 --> Database Driver Class Initialized
INFO - 2016-10-21 18:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:52:52 --> Controller Class Initialized
INFO - 2016-10-21 18:52:52 --> Form Validation Class Initialized
INFO - 2016-10-21 18:52:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:52:52 --> Final output sent to browser
DEBUG - 2016-10-21 18:52:52 --> Total execution time: 0.0069
INFO - 2016-10-21 18:53:07 --> Config Class Initialized
INFO - 2016-10-21 18:53:07 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:07 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:07 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:07 --> URI Class Initialized
INFO - 2016-10-21 18:53:07 --> Router Class Initialized
INFO - 2016-10-21 18:53:07 --> Output Class Initialized
INFO - 2016-10-21 18:53:07 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:07 --> Input Class Initialized
INFO - 2016-10-21 18:53:07 --> Language Class Initialized
INFO - 2016-10-21 18:53:07 --> Loader Class Initialized
INFO - 2016-10-21 18:53:07 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:07 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:07 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:07 --> Controller Class Initialized
INFO - 2016-10-21 18:53:07 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:07 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:07 --> Total execution time: 0.0064
INFO - 2016-10-21 18:53:17 --> Config Class Initialized
INFO - 2016-10-21 18:53:17 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:17 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:17 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:17 --> URI Class Initialized
INFO - 2016-10-21 18:53:17 --> Router Class Initialized
INFO - 2016-10-21 18:53:17 --> Output Class Initialized
INFO - 2016-10-21 18:53:17 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:17 --> Input Class Initialized
INFO - 2016-10-21 18:53:17 --> Language Class Initialized
INFO - 2016-10-21 18:53:17 --> Loader Class Initialized
INFO - 2016-10-21 18:53:17 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:17 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:17 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:17 --> Controller Class Initialized
INFO - 2016-10-21 18:53:17 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:17 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:17 --> Total execution time: 0.0066
INFO - 2016-10-21 18:53:19 --> Config Class Initialized
INFO - 2016-10-21 18:53:19 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:19 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:19 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:19 --> URI Class Initialized
INFO - 2016-10-21 18:53:19 --> Router Class Initialized
INFO - 2016-10-21 18:53:19 --> Output Class Initialized
INFO - 2016-10-21 18:53:19 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:19 --> Input Class Initialized
INFO - 2016-10-21 18:53:19 --> Language Class Initialized
INFO - 2016-10-21 18:53:19 --> Loader Class Initialized
INFO - 2016-10-21 18:53:19 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:19 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:19 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:19 --> Controller Class Initialized
INFO - 2016-10-21 18:53:19 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:19 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:19 --> Total execution time: 0.0063
INFO - 2016-10-21 18:53:25 --> Config Class Initialized
INFO - 2016-10-21 18:53:25 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:25 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:25 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:25 --> URI Class Initialized
INFO - 2016-10-21 18:53:25 --> Router Class Initialized
INFO - 2016-10-21 18:53:25 --> Output Class Initialized
INFO - 2016-10-21 18:53:25 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:25 --> Input Class Initialized
INFO - 2016-10-21 18:53:25 --> Language Class Initialized
INFO - 2016-10-21 18:53:25 --> Loader Class Initialized
INFO - 2016-10-21 18:53:25 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:25 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:25 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:25 --> Controller Class Initialized
INFO - 2016-10-21 18:53:25 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:25 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:25 --> Total execution time: 0.0067
INFO - 2016-10-21 18:53:31 --> Config Class Initialized
INFO - 2016-10-21 18:53:31 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:31 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:31 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:31 --> URI Class Initialized
INFO - 2016-10-21 18:53:31 --> Router Class Initialized
INFO - 2016-10-21 18:53:31 --> Output Class Initialized
INFO - 2016-10-21 18:53:31 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:31 --> Input Class Initialized
INFO - 2016-10-21 18:53:31 --> Language Class Initialized
INFO - 2016-10-21 18:53:31 --> Loader Class Initialized
INFO - 2016-10-21 18:53:31 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:31 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:31 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:31 --> Controller Class Initialized
INFO - 2016-10-21 18:53:31 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:31 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:31 --> Total execution time: 0.0068
INFO - 2016-10-21 18:53:32 --> Config Class Initialized
INFO - 2016-10-21 18:53:32 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:32 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:32 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:32 --> URI Class Initialized
INFO - 2016-10-21 18:53:32 --> Router Class Initialized
INFO - 2016-10-21 18:53:32 --> Output Class Initialized
INFO - 2016-10-21 18:53:32 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:32 --> Input Class Initialized
INFO - 2016-10-21 18:53:32 --> Language Class Initialized
INFO - 2016-10-21 18:53:32 --> Loader Class Initialized
INFO - 2016-10-21 18:53:32 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:32 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:32 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:32 --> Controller Class Initialized
INFO - 2016-10-21 18:53:32 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:32 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:32 --> Total execution time: 0.0063
INFO - 2016-10-21 18:53:41 --> Config Class Initialized
INFO - 2016-10-21 18:53:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:41 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:41 --> URI Class Initialized
INFO - 2016-10-21 18:53:41 --> Router Class Initialized
INFO - 2016-10-21 18:53:41 --> Output Class Initialized
INFO - 2016-10-21 18:53:41 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:41 --> Input Class Initialized
INFO - 2016-10-21 18:53:41 --> Language Class Initialized
INFO - 2016-10-21 18:53:41 --> Loader Class Initialized
INFO - 2016-10-21 18:53:41 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:41 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:41 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:41 --> Controller Class Initialized
INFO - 2016-10-21 18:53:41 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:41 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:41 --> Total execution time: 0.0065
INFO - 2016-10-21 18:53:50 --> Config Class Initialized
INFO - 2016-10-21 18:53:50 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:53:50 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:53:50 --> Utf8 Class Initialized
INFO - 2016-10-21 18:53:50 --> URI Class Initialized
INFO - 2016-10-21 18:53:50 --> Router Class Initialized
INFO - 2016-10-21 18:53:50 --> Output Class Initialized
INFO - 2016-10-21 18:53:50 --> Security Class Initialized
DEBUG - 2016-10-21 18:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:53:50 --> Input Class Initialized
INFO - 2016-10-21 18:53:50 --> Language Class Initialized
INFO - 2016-10-21 18:53:50 --> Loader Class Initialized
INFO - 2016-10-21 18:53:50 --> Helper loaded: url_helper
INFO - 2016-10-21 18:53:50 --> Helper loaded: form_helper
INFO - 2016-10-21 18:53:50 --> Database Driver Class Initialized
INFO - 2016-10-21 18:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:53:50 --> Controller Class Initialized
INFO - 2016-10-21 18:53:50 --> Form Validation Class Initialized
INFO - 2016-10-21 18:53:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-21 18:53:50 --> Final output sent to browser
DEBUG - 2016-10-21 18:53:50 --> Total execution time: 0.0069
INFO - 2016-10-21 18:54:04 --> Config Class Initialized
INFO - 2016-10-21 18:54:04 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:54:04 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:54:04 --> Utf8 Class Initialized
INFO - 2016-10-21 18:54:04 --> URI Class Initialized
INFO - 2016-10-21 18:54:04 --> Router Class Initialized
INFO - 2016-10-21 18:54:04 --> Output Class Initialized
INFO - 2016-10-21 18:54:04 --> Security Class Initialized
DEBUG - 2016-10-21 18:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:54:04 --> Input Class Initialized
INFO - 2016-10-21 18:54:04 --> Language Class Initialized
INFO - 2016-10-21 18:54:04 --> Loader Class Initialized
INFO - 2016-10-21 18:54:04 --> Helper loaded: url_helper
INFO - 2016-10-21 18:54:04 --> Helper loaded: form_helper
INFO - 2016-10-21 18:54:04 --> Database Driver Class Initialized
INFO - 2016-10-21 18:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:54:04 --> Controller Class Initialized
DEBUG - 2016-10-21 18:54:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:54:04 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:54:04 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:54:04 --> Config Class Initialized
INFO - 2016-10-21 18:54:04 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:54:04 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:54:04 --> Utf8 Class Initialized
INFO - 2016-10-21 18:54:04 --> URI Class Initialized
DEBUG - 2016-10-21 18:54:04 --> No URI present. Default controller set.
INFO - 2016-10-21 18:54:04 --> Router Class Initialized
INFO - 2016-10-21 18:54:04 --> Output Class Initialized
INFO - 2016-10-21 18:54:04 --> Security Class Initialized
DEBUG - 2016-10-21 18:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:54:04 --> Input Class Initialized
INFO - 2016-10-21 18:54:04 --> Language Class Initialized
INFO - 2016-10-21 18:54:04 --> Loader Class Initialized
INFO - 2016-10-21 18:54:04 --> Helper loaded: url_helper
INFO - 2016-10-21 18:54:04 --> Helper loaded: form_helper
INFO - 2016-10-21 18:54:04 --> Database Driver Class Initialized
INFO - 2016-10-21 18:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:54:04 --> Controller Class Initialized
INFO - 2016-10-21 18:54:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:54:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:54:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:54:04 --> Final output sent to browser
DEBUG - 2016-10-21 18:54:04 --> Total execution time: 0.0049
INFO - 2016-10-21 18:55:30 --> Config Class Initialized
INFO - 2016-10-21 18:55:30 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:30 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:30 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:30 --> URI Class Initialized
INFO - 2016-10-21 18:55:30 --> Router Class Initialized
INFO - 2016-10-21 18:55:30 --> Output Class Initialized
INFO - 2016-10-21 18:55:30 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:30 --> Input Class Initialized
INFO - 2016-10-21 18:55:30 --> Language Class Initialized
INFO - 2016-10-21 18:55:30 --> Loader Class Initialized
INFO - 2016-10-21 18:55:30 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:30 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:30 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:30 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:30 --> Model Class Initialized
INFO - 2016-10-21 18:55:30 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:30 --> Total execution time: 0.0064
INFO - 2016-10-21 18:55:36 --> Config Class Initialized
INFO - 2016-10-21 18:55:36 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:36 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:36 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:36 --> URI Class Initialized
INFO - 2016-10-21 18:55:36 --> Router Class Initialized
INFO - 2016-10-21 18:55:36 --> Output Class Initialized
INFO - 2016-10-21 18:55:36 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:36 --> Input Class Initialized
INFO - 2016-10-21 18:55:36 --> Language Class Initialized
INFO - 2016-10-21 18:55:36 --> Loader Class Initialized
INFO - 2016-10-21 18:55:36 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:36 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:36 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:36 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:36 --> Model Class Initialized
INFO - 2016-10-21 18:55:36 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:36 --> Total execution time: 0.0061
INFO - 2016-10-21 18:55:38 --> Config Class Initialized
INFO - 2016-10-21 18:55:38 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:38 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:38 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:38 --> URI Class Initialized
INFO - 2016-10-21 18:55:38 --> Router Class Initialized
INFO - 2016-10-21 18:55:38 --> Output Class Initialized
INFO - 2016-10-21 18:55:38 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:38 --> Input Class Initialized
INFO - 2016-10-21 18:55:38 --> Language Class Initialized
INFO - 2016-10-21 18:55:38 --> Loader Class Initialized
INFO - 2016-10-21 18:55:38 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:38 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:38 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:38 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:38 --> Model Class Initialized
INFO - 2016-10-21 18:55:38 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:38 --> Total execution time: 0.0058
INFO - 2016-10-21 18:55:39 --> Config Class Initialized
INFO - 2016-10-21 18:55:39 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:39 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:39 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:39 --> URI Class Initialized
INFO - 2016-10-21 18:55:39 --> Router Class Initialized
INFO - 2016-10-21 18:55:39 --> Output Class Initialized
INFO - 2016-10-21 18:55:39 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:39 --> Input Class Initialized
INFO - 2016-10-21 18:55:39 --> Language Class Initialized
INFO - 2016-10-21 18:55:39 --> Loader Class Initialized
INFO - 2016-10-21 18:55:39 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:39 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:39 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:39 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:39 --> Model Class Initialized
INFO - 2016-10-21 18:55:39 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:39 --> Total execution time: 0.0058
INFO - 2016-10-21 18:55:41 --> Config Class Initialized
INFO - 2016-10-21 18:55:41 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:41 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:41 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:41 --> URI Class Initialized
INFO - 2016-10-21 18:55:41 --> Router Class Initialized
INFO - 2016-10-21 18:55:41 --> Output Class Initialized
INFO - 2016-10-21 18:55:41 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:41 --> Input Class Initialized
INFO - 2016-10-21 18:55:41 --> Language Class Initialized
INFO - 2016-10-21 18:55:41 --> Loader Class Initialized
INFO - 2016-10-21 18:55:41 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:41 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:41 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:41 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:41 --> Model Class Initialized
INFO - 2016-10-21 18:55:41 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:41 --> Total execution time: 0.0065
INFO - 2016-10-21 18:55:42 --> Config Class Initialized
INFO - 2016-10-21 18:55:42 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:42 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:42 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:42 --> URI Class Initialized
INFO - 2016-10-21 18:55:42 --> Router Class Initialized
INFO - 2016-10-21 18:55:42 --> Output Class Initialized
INFO - 2016-10-21 18:55:42 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:42 --> Input Class Initialized
INFO - 2016-10-21 18:55:42 --> Language Class Initialized
INFO - 2016-10-21 18:55:42 --> Loader Class Initialized
INFO - 2016-10-21 18:55:42 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:42 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:42 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:42 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:42 --> Model Class Initialized
INFO - 2016-10-21 18:55:42 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:42 --> Total execution time: 0.0066
INFO - 2016-10-21 18:55:43 --> Config Class Initialized
INFO - 2016-10-21 18:55:43 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:43 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:43 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:43 --> URI Class Initialized
INFO - 2016-10-21 18:55:43 --> Router Class Initialized
INFO - 2016-10-21 18:55:43 --> Output Class Initialized
INFO - 2016-10-21 18:55:43 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:43 --> Input Class Initialized
INFO - 2016-10-21 18:55:43 --> Language Class Initialized
INFO - 2016-10-21 18:55:43 --> Loader Class Initialized
INFO - 2016-10-21 18:55:43 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:43 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:43 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:43 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:43 --> Model Class Initialized
INFO - 2016-10-21 18:55:43 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:43 --> Total execution time: 0.0057
INFO - 2016-10-21 18:55:45 --> Config Class Initialized
INFO - 2016-10-21 18:55:45 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:45 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:45 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:45 --> URI Class Initialized
INFO - 2016-10-21 18:55:45 --> Router Class Initialized
INFO - 2016-10-21 18:55:45 --> Output Class Initialized
INFO - 2016-10-21 18:55:45 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:45 --> Input Class Initialized
INFO - 2016-10-21 18:55:45 --> Language Class Initialized
INFO - 2016-10-21 18:55:45 --> Loader Class Initialized
INFO - 2016-10-21 18:55:45 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:45 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:45 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:45 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:45 --> Model Class Initialized
INFO - 2016-10-21 18:55:45 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:45 --> Total execution time: 0.0059
INFO - 2016-10-21 18:55:49 --> Config Class Initialized
INFO - 2016-10-21 18:55:49 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:49 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:49 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:49 --> URI Class Initialized
INFO - 2016-10-21 18:55:49 --> Router Class Initialized
INFO - 2016-10-21 18:55:49 --> Output Class Initialized
INFO - 2016-10-21 18:55:49 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:49 --> Input Class Initialized
INFO - 2016-10-21 18:55:49 --> Language Class Initialized
INFO - 2016-10-21 18:55:49 --> Loader Class Initialized
INFO - 2016-10-21 18:55:49 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:49 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:49 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:49 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:49 --> Model Class Initialized
INFO - 2016-10-21 18:55:49 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:49 --> Total execution time: 0.0064
INFO - 2016-10-21 18:55:55 --> Config Class Initialized
INFO - 2016-10-21 18:55:55 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:55 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:55 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:55 --> URI Class Initialized
INFO - 2016-10-21 18:55:55 --> Router Class Initialized
INFO - 2016-10-21 18:55:55 --> Output Class Initialized
INFO - 2016-10-21 18:55:55 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:55 --> Input Class Initialized
INFO - 2016-10-21 18:55:55 --> Language Class Initialized
INFO - 2016-10-21 18:55:55 --> Loader Class Initialized
INFO - 2016-10-21 18:55:55 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:55 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:55 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:55 --> Controller Class Initialized
DEBUG - 2016-10-21 18:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-21 18:55:55 --> Model Class Initialized
INFO - 2016-10-21 18:55:55 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:55 --> Total execution time: 0.0067
INFO - 2016-10-21 18:55:55 --> Config Class Initialized
INFO - 2016-10-21 18:55:55 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:55:55 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:55:55 --> Utf8 Class Initialized
INFO - 2016-10-21 18:55:55 --> URI Class Initialized
DEBUG - 2016-10-21 18:55:55 --> No URI present. Default controller set.
INFO - 2016-10-21 18:55:55 --> Router Class Initialized
INFO - 2016-10-21 18:55:55 --> Output Class Initialized
INFO - 2016-10-21 18:55:55 --> Security Class Initialized
DEBUG - 2016-10-21 18:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:55:55 --> Input Class Initialized
INFO - 2016-10-21 18:55:55 --> Language Class Initialized
INFO - 2016-10-21 18:55:55 --> Loader Class Initialized
INFO - 2016-10-21 18:55:55 --> Helper loaded: url_helper
INFO - 2016-10-21 18:55:55 --> Helper loaded: form_helper
INFO - 2016-10-21 18:55:55 --> Database Driver Class Initialized
INFO - 2016-10-21 18:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:55:55 --> Controller Class Initialized
INFO - 2016-10-21 18:55:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:55:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-21 18:55:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-21 18:55:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:55:55 --> Final output sent to browser
DEBUG - 2016-10-21 18:55:55 --> Total execution time: 0.0046
INFO - 2016-10-21 18:58:58 --> Config Class Initialized
INFO - 2016-10-21 18:58:58 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:58:58 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:58:58 --> Utf8 Class Initialized
INFO - 2016-10-21 18:58:58 --> URI Class Initialized
INFO - 2016-10-21 18:58:58 --> Router Class Initialized
INFO - 2016-10-21 18:58:58 --> Output Class Initialized
INFO - 2016-10-21 18:58:58 --> Security Class Initialized
DEBUG - 2016-10-21 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:58:58 --> Input Class Initialized
INFO - 2016-10-21 18:58:58 --> Language Class Initialized
INFO - 2016-10-21 18:58:58 --> Loader Class Initialized
INFO - 2016-10-21 18:58:58 --> Helper loaded: url_helper
INFO - 2016-10-21 18:58:58 --> Helper loaded: form_helper
INFO - 2016-10-21 18:58:58 --> Database Driver Class Initialized
INFO - 2016-10-21 18:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:58:58 --> Controller Class Initialized
DEBUG - 2016-10-21 18:58:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-21 18:58:58 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
ERROR - 2016-10-21 18:58:58 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 140
INFO - 2016-10-21 18:58:58 --> Config Class Initialized
INFO - 2016-10-21 18:58:58 --> Hooks Class Initialized
DEBUG - 2016-10-21 18:58:58 --> UTF-8 Support Enabled
INFO - 2016-10-21 18:58:58 --> Utf8 Class Initialized
INFO - 2016-10-21 18:58:58 --> URI Class Initialized
DEBUG - 2016-10-21 18:58:58 --> No URI present. Default controller set.
INFO - 2016-10-21 18:58:58 --> Router Class Initialized
INFO - 2016-10-21 18:58:58 --> Output Class Initialized
INFO - 2016-10-21 18:58:58 --> Security Class Initialized
DEBUG - 2016-10-21 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-21 18:58:58 --> Input Class Initialized
INFO - 2016-10-21 18:58:58 --> Language Class Initialized
INFO - 2016-10-21 18:58:58 --> Loader Class Initialized
INFO - 2016-10-21 18:58:58 --> Helper loaded: url_helper
INFO - 2016-10-21 18:58:58 --> Helper loaded: form_helper
INFO - 2016-10-21 18:58:58 --> Database Driver Class Initialized
INFO - 2016-10-21 18:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-21 18:58:58 --> Controller Class Initialized
INFO - 2016-10-21 18:58:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-21 18:58:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-21 18:58:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-21 18:58:58 --> Final output sent to browser
DEBUG - 2016-10-21 18:58:58 --> Total execution time: 0.0104
