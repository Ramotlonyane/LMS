<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-15 21:47:10 --> Config Class Initialized
INFO - 2016-11-15 21:47:10 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:47:11 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:47:11 --> Utf8 Class Initialized
INFO - 2016-11-15 21:47:11 --> URI Class Initialized
DEBUG - 2016-11-15 21:47:11 --> No URI present. Default controller set.
INFO - 2016-11-15 21:47:11 --> Router Class Initialized
INFO - 2016-11-15 21:47:11 --> Output Class Initialized
INFO - 2016-11-15 21:47:11 --> Security Class Initialized
DEBUG - 2016-11-15 21:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:47:11 --> Input Class Initialized
INFO - 2016-11-15 21:47:12 --> Language Class Initialized
INFO - 2016-11-15 21:47:12 --> Loader Class Initialized
INFO - 2016-11-15 21:47:12 --> Helper loaded: url_helper
INFO - 2016-11-15 21:47:12 --> Helper loaded: form_helper
INFO - 2016-11-15 21:47:13 --> Database Driver Class Initialized
INFO - 2016-11-15 21:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:47:14 --> Controller Class Initialized
INFO - 2016-11-15 21:47:14 --> Model Class Initialized
INFO - 2016-11-15 21:47:14 --> Model Class Initialized
INFO - 2016-11-15 21:47:14 --> Model Class Initialized
INFO - 2016-11-15 21:47:15 --> Model Class Initialized
INFO - 2016-11-15 21:47:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:47:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-15 21:47:15 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:47:15 --> Final output sent to browser
DEBUG - 2016-11-15 21:47:15 --> Total execution time: 4.6372
INFO - 2016-11-15 21:47:33 --> Config Class Initialized
INFO - 2016-11-15 21:47:33 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:47:33 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:47:33 --> Utf8 Class Initialized
INFO - 2016-11-15 21:47:33 --> URI Class Initialized
INFO - 2016-11-15 21:47:33 --> Router Class Initialized
INFO - 2016-11-15 21:47:33 --> Output Class Initialized
INFO - 2016-11-15 21:47:33 --> Security Class Initialized
DEBUG - 2016-11-15 21:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:47:34 --> Input Class Initialized
INFO - 2016-11-15 21:47:34 --> Language Class Initialized
INFO - 2016-11-15 21:47:34 --> Loader Class Initialized
INFO - 2016-11-15 21:47:34 --> Helper loaded: url_helper
INFO - 2016-11-15 21:47:34 --> Helper loaded: form_helper
INFO - 2016-11-15 21:47:34 --> Database Driver Class Initialized
INFO - 2016-11-15 21:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:47:34 --> Controller Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
DEBUG - 2016-11-15 21:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Final output sent to browser
DEBUG - 2016-11-15 21:47:34 --> Total execution time: 0.5838
INFO - 2016-11-15 21:47:34 --> Config Class Initialized
INFO - 2016-11-15 21:47:34 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:47:34 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:47:34 --> Utf8 Class Initialized
INFO - 2016-11-15 21:47:34 --> URI Class Initialized
DEBUG - 2016-11-15 21:47:34 --> No URI present. Default controller set.
INFO - 2016-11-15 21:47:34 --> Router Class Initialized
INFO - 2016-11-15 21:47:34 --> Output Class Initialized
INFO - 2016-11-15 21:47:34 --> Security Class Initialized
DEBUG - 2016-11-15 21:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:47:34 --> Input Class Initialized
INFO - 2016-11-15 21:47:34 --> Language Class Initialized
INFO - 2016-11-15 21:47:34 --> Loader Class Initialized
INFO - 2016-11-15 21:47:34 --> Helper loaded: url_helper
INFO - 2016-11-15 21:47:34 --> Helper loaded: form_helper
INFO - 2016-11-15 21:47:34 --> Database Driver Class Initialized
INFO - 2016-11-15 21:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:47:34 --> Controller Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> Model Class Initialized
INFO - 2016-11-15 21:47:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:47:34 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:47:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:47:35 --> Final output sent to browser
DEBUG - 2016-11-15 21:47:35 --> Total execution time: 1.1182
INFO - 2016-11-15 21:48:40 --> Config Class Initialized
INFO - 2016-11-15 21:48:40 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:48:40 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:48:40 --> Utf8 Class Initialized
INFO - 2016-11-15 21:48:40 --> URI Class Initialized
INFO - 2016-11-15 21:48:40 --> Router Class Initialized
INFO - 2016-11-15 21:48:40 --> Output Class Initialized
INFO - 2016-11-15 21:48:40 --> Security Class Initialized
DEBUG - 2016-11-15 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:48:40 --> Input Class Initialized
INFO - 2016-11-15 21:48:40 --> Language Class Initialized
INFO - 2016-11-15 21:48:40 --> Loader Class Initialized
INFO - 2016-11-15 21:48:40 --> Helper loaded: url_helper
INFO - 2016-11-15 21:48:40 --> Helper loaded: form_helper
INFO - 2016-11-15 21:48:40 --> Database Driver Class Initialized
INFO - 2016-11-15 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:48:40 --> Controller Class Initialized
INFO - 2016-11-15 21:48:40 --> Model Class Initialized
INFO - 2016-11-15 21:48:40 --> Form Validation Class Initialized
INFO - 2016-11-15 21:48:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:48:40 --> Final output sent to browser
DEBUG - 2016-11-15 21:48:40 --> Total execution time: 0.2726
INFO - 2016-11-15 21:51:55 --> Config Class Initialized
INFO - 2016-11-15 21:51:55 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:51:55 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:51:55 --> Utf8 Class Initialized
INFO - 2016-11-15 21:51:55 --> URI Class Initialized
DEBUG - 2016-11-15 21:51:55 --> No URI present. Default controller set.
INFO - 2016-11-15 21:51:55 --> Router Class Initialized
INFO - 2016-11-15 21:51:55 --> Output Class Initialized
INFO - 2016-11-15 21:51:55 --> Security Class Initialized
DEBUG - 2016-11-15 21:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:51:55 --> Input Class Initialized
INFO - 2016-11-15 21:51:55 --> Language Class Initialized
INFO - 2016-11-15 21:51:55 --> Loader Class Initialized
INFO - 2016-11-15 21:51:55 --> Helper loaded: url_helper
INFO - 2016-11-15 21:51:55 --> Helper loaded: form_helper
INFO - 2016-11-15 21:51:55 --> Database Driver Class Initialized
INFO - 2016-11-15 21:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:51:55 --> Controller Class Initialized
INFO - 2016-11-15 21:51:55 --> Model Class Initialized
INFO - 2016-11-15 21:51:55 --> Model Class Initialized
INFO - 2016-11-15 21:51:55 --> Model Class Initialized
INFO - 2016-11-15 21:51:55 --> Model Class Initialized
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:51:55 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:51:55 --> Final output sent to browser
DEBUG - 2016-11-15 21:51:55 --> Total execution time: 0.3442
INFO - 2016-11-15 21:52:01 --> Config Class Initialized
INFO - 2016-11-15 21:52:01 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:52:01 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:52:01 --> Utf8 Class Initialized
INFO - 2016-11-15 21:52:01 --> URI Class Initialized
INFO - 2016-11-15 21:52:01 --> Router Class Initialized
INFO - 2016-11-15 21:52:01 --> Output Class Initialized
INFO - 2016-11-15 21:52:01 --> Security Class Initialized
DEBUG - 2016-11-15 21:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:52:01 --> Input Class Initialized
INFO - 2016-11-15 21:52:01 --> Language Class Initialized
INFO - 2016-11-15 21:52:01 --> Loader Class Initialized
INFO - 2016-11-15 21:52:01 --> Helper loaded: url_helper
INFO - 2016-11-15 21:52:01 --> Helper loaded: form_helper
INFO - 2016-11-15 21:52:01 --> Database Driver Class Initialized
INFO - 2016-11-15 21:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:52:01 --> Controller Class Initialized
INFO - 2016-11-15 21:52:01 --> Model Class Initialized
INFO - 2016-11-15 21:52:01 --> Form Validation Class Initialized
INFO - 2016-11-15 21:52:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:52:01 --> Final output sent to browser
DEBUG - 2016-11-15 21:52:01 --> Total execution time: 0.1741
INFO - 2016-11-15 21:52:11 --> Config Class Initialized
INFO - 2016-11-15 21:52:11 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:52:11 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:52:11 --> Utf8 Class Initialized
INFO - 2016-11-15 21:52:11 --> URI Class Initialized
INFO - 2016-11-15 21:52:11 --> Router Class Initialized
INFO - 2016-11-15 21:52:11 --> Output Class Initialized
INFO - 2016-11-15 21:52:11 --> Security Class Initialized
DEBUG - 2016-11-15 21:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:52:11 --> Input Class Initialized
INFO - 2016-11-15 21:52:11 --> Language Class Initialized
INFO - 2016-11-15 21:52:11 --> Loader Class Initialized
INFO - 2016-11-15 21:52:11 --> Helper loaded: url_helper
INFO - 2016-11-15 21:52:11 --> Helper loaded: form_helper
INFO - 2016-11-15 21:52:11 --> Database Driver Class Initialized
INFO - 2016-11-15 21:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:52:11 --> Controller Class Initialized
INFO - 2016-11-15 21:52:11 --> Model Class Initialized
INFO - 2016-11-15 21:52:11 --> Form Validation Class Initialized
INFO - 2016-11-15 21:52:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:52:11 --> Final output sent to browser
DEBUG - 2016-11-15 21:52:11 --> Total execution time: 0.2361
INFO - 2016-11-15 21:53:43 --> Config Class Initialized
INFO - 2016-11-15 21:53:43 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:53:43 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:53:43 --> Utf8 Class Initialized
INFO - 2016-11-15 21:53:43 --> URI Class Initialized
DEBUG - 2016-11-15 21:53:43 --> No URI present. Default controller set.
INFO - 2016-11-15 21:53:43 --> Router Class Initialized
INFO - 2016-11-15 21:53:43 --> Output Class Initialized
INFO - 2016-11-15 21:53:43 --> Security Class Initialized
DEBUG - 2016-11-15 21:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:53:43 --> Input Class Initialized
INFO - 2016-11-15 21:53:43 --> Language Class Initialized
INFO - 2016-11-15 21:53:43 --> Loader Class Initialized
INFO - 2016-11-15 21:53:43 --> Helper loaded: url_helper
INFO - 2016-11-15 21:53:43 --> Helper loaded: form_helper
INFO - 2016-11-15 21:53:44 --> Database Driver Class Initialized
INFO - 2016-11-15 21:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:53:44 --> Controller Class Initialized
INFO - 2016-11-15 21:53:44 --> Model Class Initialized
INFO - 2016-11-15 21:53:44 --> Model Class Initialized
INFO - 2016-11-15 21:53:44 --> Model Class Initialized
INFO - 2016-11-15 21:53:44 --> Model Class Initialized
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:53:44 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:53:44 --> Final output sent to browser
DEBUG - 2016-11-15 21:53:44 --> Total execution time: 0.3311
INFO - 2016-11-15 21:55:50 --> Config Class Initialized
INFO - 2016-11-15 21:55:50 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:55:50 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:55:50 --> Utf8 Class Initialized
INFO - 2016-11-15 21:55:50 --> URI Class Initialized
DEBUG - 2016-11-15 21:55:50 --> No URI present. Default controller set.
INFO - 2016-11-15 21:55:50 --> Router Class Initialized
INFO - 2016-11-15 21:55:50 --> Output Class Initialized
INFO - 2016-11-15 21:55:50 --> Security Class Initialized
DEBUG - 2016-11-15 21:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:55:50 --> Input Class Initialized
INFO - 2016-11-15 21:55:50 --> Language Class Initialized
INFO - 2016-11-15 21:55:50 --> Loader Class Initialized
INFO - 2016-11-15 21:55:50 --> Helper loaded: url_helper
INFO - 2016-11-15 21:55:50 --> Helper loaded: form_helper
INFO - 2016-11-15 21:55:50 --> Database Driver Class Initialized
INFO - 2016-11-15 21:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:55:50 --> Controller Class Initialized
INFO - 2016-11-15 21:55:50 --> Model Class Initialized
INFO - 2016-11-15 21:55:50 --> Model Class Initialized
INFO - 2016-11-15 21:55:50 --> Model Class Initialized
INFO - 2016-11-15 21:55:50 --> Model Class Initialized
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:55:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:55:50 --> Final output sent to browser
DEBUG - 2016-11-15 21:55:50 --> Total execution time: 0.3303
INFO - 2016-11-15 21:56:14 --> Config Class Initialized
INFO - 2016-11-15 21:56:14 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:56:14 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:56:14 --> Utf8 Class Initialized
INFO - 2016-11-15 21:56:14 --> URI Class Initialized
DEBUG - 2016-11-15 21:56:14 --> No URI present. Default controller set.
INFO - 2016-11-15 21:56:14 --> Router Class Initialized
INFO - 2016-11-15 21:56:14 --> Output Class Initialized
INFO - 2016-11-15 21:56:14 --> Security Class Initialized
DEBUG - 2016-11-15 21:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:56:14 --> Input Class Initialized
INFO - 2016-11-15 21:56:14 --> Language Class Initialized
INFO - 2016-11-15 21:56:14 --> Loader Class Initialized
INFO - 2016-11-15 21:56:14 --> Helper loaded: url_helper
INFO - 2016-11-15 21:56:14 --> Helper loaded: form_helper
INFO - 2016-11-15 21:56:14 --> Database Driver Class Initialized
INFO - 2016-11-15 21:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:56:14 --> Controller Class Initialized
INFO - 2016-11-15 21:56:14 --> Model Class Initialized
INFO - 2016-11-15 21:56:14 --> Model Class Initialized
INFO - 2016-11-15 21:56:14 --> Model Class Initialized
INFO - 2016-11-15 21:56:14 --> Model Class Initialized
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:56:14 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:56:14 --> Final output sent to browser
DEBUG - 2016-11-15 21:56:15 --> Total execution time: 0.3391
INFO - 2016-11-15 21:56:26 --> Config Class Initialized
INFO - 2016-11-15 21:56:26 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:56:26 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:56:26 --> Utf8 Class Initialized
INFO - 2016-11-15 21:56:26 --> URI Class Initialized
INFO - 2016-11-15 21:56:26 --> Router Class Initialized
INFO - 2016-11-15 21:56:26 --> Output Class Initialized
INFO - 2016-11-15 21:56:26 --> Security Class Initialized
DEBUG - 2016-11-15 21:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:56:26 --> Input Class Initialized
INFO - 2016-11-15 21:56:26 --> Language Class Initialized
INFO - 2016-11-15 21:56:26 --> Loader Class Initialized
INFO - 2016-11-15 21:56:26 --> Helper loaded: url_helper
INFO - 2016-11-15 21:56:26 --> Helper loaded: form_helper
INFO - 2016-11-15 21:56:26 --> Database Driver Class Initialized
INFO - 2016-11-15 21:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:56:26 --> Controller Class Initialized
INFO - 2016-11-15 21:56:26 --> Model Class Initialized
INFO - 2016-11-15 21:56:26 --> Form Validation Class Initialized
INFO - 2016-11-15 21:56:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:56:26 --> Final output sent to browser
DEBUG - 2016-11-15 21:56:26 --> Total execution time: 0.1770
INFO - 2016-11-15 21:56:29 --> Config Class Initialized
INFO - 2016-11-15 21:56:30 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:56:30 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:56:30 --> Utf8 Class Initialized
INFO - 2016-11-15 21:56:30 --> URI Class Initialized
INFO - 2016-11-15 21:56:30 --> Router Class Initialized
INFO - 2016-11-15 21:56:30 --> Output Class Initialized
INFO - 2016-11-15 21:56:30 --> Security Class Initialized
DEBUG - 2016-11-15 21:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:56:30 --> Input Class Initialized
INFO - 2016-11-15 21:56:30 --> Language Class Initialized
INFO - 2016-11-15 21:56:30 --> Loader Class Initialized
INFO - 2016-11-15 21:56:30 --> Helper loaded: url_helper
INFO - 2016-11-15 21:56:30 --> Helper loaded: form_helper
INFO - 2016-11-15 21:56:30 --> Database Driver Class Initialized
INFO - 2016-11-15 21:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:56:30 --> Controller Class Initialized
INFO - 2016-11-15 21:56:30 --> Model Class Initialized
INFO - 2016-11-15 21:56:30 --> Form Validation Class Initialized
INFO - 2016-11-15 21:56:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:56:30 --> Final output sent to browser
DEBUG - 2016-11-15 21:56:30 --> Total execution time: 0.2348
INFO - 2016-11-15 21:57:07 --> Config Class Initialized
INFO - 2016-11-15 21:57:07 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:07 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:07 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:07 --> URI Class Initialized
DEBUG - 2016-11-15 21:57:07 --> No URI present. Default controller set.
INFO - 2016-11-15 21:57:07 --> Router Class Initialized
INFO - 2016-11-15 21:57:07 --> Output Class Initialized
INFO - 2016-11-15 21:57:07 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:07 --> Input Class Initialized
INFO - 2016-11-15 21:57:07 --> Language Class Initialized
INFO - 2016-11-15 21:57:07 --> Loader Class Initialized
INFO - 2016-11-15 21:57:07 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:08 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:08 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:08 --> Controller Class Initialized
INFO - 2016-11-15 21:57:08 --> Model Class Initialized
INFO - 2016-11-15 21:57:08 --> Model Class Initialized
INFO - 2016-11-15 21:57:08 --> Model Class Initialized
INFO - 2016-11-15 21:57:08 --> Model Class Initialized
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:57:08 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:57:08 --> Final output sent to browser
DEBUG - 2016-11-15 21:57:08 --> Total execution time: 0.3293
INFO - 2016-11-15 21:57:13 --> Config Class Initialized
INFO - 2016-11-15 21:57:13 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:13 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:13 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:13 --> URI Class Initialized
INFO - 2016-11-15 21:57:13 --> Router Class Initialized
INFO - 2016-11-15 21:57:13 --> Output Class Initialized
INFO - 2016-11-15 21:57:13 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:13 --> Input Class Initialized
INFO - 2016-11-15 21:57:13 --> Language Class Initialized
INFO - 2016-11-15 21:57:13 --> Loader Class Initialized
INFO - 2016-11-15 21:57:13 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:13 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:13 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:13 --> Controller Class Initialized
INFO - 2016-11-15 21:57:13 --> Model Class Initialized
INFO - 2016-11-15 21:57:13 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:13 --> Final output sent to browser
DEBUG - 2016-11-15 21:57:13 --> Total execution time: 0.2120
INFO - 2016-11-15 21:57:14 --> Config Class Initialized
INFO - 2016-11-15 21:57:14 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:14 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:14 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:14 --> URI Class Initialized
INFO - 2016-11-15 21:57:14 --> Router Class Initialized
INFO - 2016-11-15 21:57:14 --> Output Class Initialized
INFO - 2016-11-15 21:57:14 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:14 --> Input Class Initialized
INFO - 2016-11-15 21:57:14 --> Language Class Initialized
INFO - 2016-11-15 21:57:14 --> Loader Class Initialized
INFO - 2016-11-15 21:57:14 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:14 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:14 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:14 --> Controller Class Initialized
INFO - 2016-11-15 21:57:14 --> Model Class Initialized
INFO - 2016-11-15 21:57:14 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:14 --> Final output sent to browser
DEBUG - 2016-11-15 21:57:14 --> Total execution time: 0.2162
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:15 --> URI Class Initialized
INFO - 2016-11-15 21:57:15 --> Router Class Initialized
INFO - 2016-11-15 21:57:15 --> Output Class Initialized
INFO - 2016-11-15 21:57:15 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:15 --> Input Class Initialized
INFO - 2016-11-15 21:57:15 --> Language Class Initialized
INFO - 2016-11-15 21:57:15 --> Loader Class Initialized
INFO - 2016-11-15 21:57:15 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:15 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:15 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:15 --> Controller Class Initialized
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:15 --> Model Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:15 --> URI Class Initialized
INFO - 2016-11-15 21:57:15 --> Final output sent to browser
INFO - 2016-11-15 21:57:15 --> Router Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Total execution time: 0.2370
INFO - 2016-11-15 21:57:15 --> Output Class Initialized
INFO - 2016-11-15 21:57:15 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:15 --> Input Class Initialized
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Language Class Initialized
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Loader Class Initialized
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:15 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:15 --> URI Class Initialized
INFO - 2016-11-15 21:57:15 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:15 --> Router Class Initialized
INFO - 2016-11-15 21:57:15 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:15 --> Output Class Initialized
INFO - 2016-11-15 21:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:15 --> Security Class Initialized
INFO - 2016-11-15 21:57:15 --> Controller Class Initialized
INFO - 2016-11-15 21:57:15 --> Model Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:15 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:15 --> Input Class Initialized
INFO - 2016-11-15 21:57:15 --> Language Class Initialized
INFO - 2016-11-15 21:57:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:15 --> Final output sent to browser
INFO - 2016-11-15 21:57:15 --> Loader Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Total execution time: 0.2987
INFO - 2016-11-15 21:57:15 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:15 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:15 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:15 --> Controller Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Model Class Initialized
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:15 --> URI Class Initialized
INFO - 2016-11-15 21:57:15 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:15 --> Router Class Initialized
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:15 --> Output Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Final output sent to browser
INFO - 2016-11-15 21:57:15 --> Security Class Initialized
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Total execution time: 0.3245
INFO - 2016-11-15 21:57:15 --> URI Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:15 --> Input Class Initialized
INFO - 2016-11-15 21:57:15 --> Router Class Initialized
INFO - 2016-11-15 21:57:15 --> Language Class Initialized
INFO - 2016-11-15 21:57:15 --> Output Class Initialized
INFO - 2016-11-15 21:57:15 --> Loader Class Initialized
INFO - 2016-11-15 21:57:15 --> Security Class Initialized
INFO - 2016-11-15 21:57:15 --> Helper loaded: url_helper
DEBUG - 2016-11-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:15 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:15 --> Input Class Initialized
INFO - 2016-11-15 21:57:15 --> Language Class Initialized
INFO - 2016-11-15 21:57:15 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:15 --> Loader Class Initialized
INFO - 2016-11-15 21:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:15 --> Controller Class Initialized
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:15 --> Model Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:15 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:15 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:15 --> URI Class Initialized
INFO - 2016-11-15 21:57:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:15 --> Final output sent to browser
INFO - 2016-11-15 21:57:15 --> Router Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Total execution time: 0.3062
INFO - 2016-11-15 21:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:15 --> Output Class Initialized
INFO - 2016-11-15 21:57:15 --> Controller Class Initialized
INFO - 2016-11-15 21:57:15 --> Model Class Initialized
INFO - 2016-11-15 21:57:15 --> Security Class Initialized
INFO - 2016-11-15 21:57:15 --> Form Validation Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:15 --> Input Class Initialized
INFO - 2016-11-15 21:57:15 --> Final output sent to browser
INFO - 2016-11-15 21:57:15 --> Config Class Initialized
INFO - 2016-11-15 21:57:15 --> Language Class Initialized
DEBUG - 2016-11-15 21:57:15 --> Total execution time: 0.3013
INFO - 2016-11-15 21:57:15 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:15 --> Loader Class Initialized
DEBUG - 2016-11-15 21:57:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:15 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:15 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:16 --> URI Class Initialized
INFO - 2016-11-15 21:57:16 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:16 --> Router Class Initialized
INFO - 2016-11-15 21:57:16 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:16 --> Output Class Initialized
INFO - 2016-11-15 21:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:16 --> Security Class Initialized
INFO - 2016-11-15 21:57:16 --> Controller Class Initialized
INFO - 2016-11-15 21:57:16 --> Model Class Initialized
DEBUG - 2016-11-15 21:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:16 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:16 --> Input Class Initialized
INFO - 2016-11-15 21:57:16 --> Language Class Initialized
INFO - 2016-11-15 21:57:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:16 --> Final output sent to browser
INFO - 2016-11-15 21:57:16 --> Loader Class Initialized
DEBUG - 2016-11-15 21:57:16 --> Total execution time: 0.2774
INFO - 2016-11-15 21:57:16 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:16 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:16 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:16 --> Config Class Initialized
INFO - 2016-11-15 21:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:16 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:16 --> Controller Class Initialized
DEBUG - 2016-11-15 21:57:16 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:16 --> Model Class Initialized
INFO - 2016-11-15 21:57:16 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:16 --> URI Class Initialized
INFO - 2016-11-15 21:57:16 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:16 --> Router Class Initialized
INFO - 2016-11-15 21:57:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:16 --> Output Class Initialized
INFO - 2016-11-15 21:57:16 --> Final output sent to browser
INFO - 2016-11-15 21:57:16 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:16 --> Total execution time: 0.2536
DEBUG - 2016-11-15 21:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:16 --> Input Class Initialized
INFO - 2016-11-15 21:57:16 --> Language Class Initialized
INFO - 2016-11-15 21:57:16 --> Loader Class Initialized
INFO - 2016-11-15 21:57:16 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:16 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:16 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:16 --> Controller Class Initialized
INFO - 2016-11-15 21:57:16 --> Config Class Initialized
INFO - 2016-11-15 21:57:16 --> Hooks Class Initialized
INFO - 2016-11-15 21:57:16 --> Model Class Initialized
DEBUG - 2016-11-15 21:57:16 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:16 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:16 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:16 --> URI Class Initialized
INFO - 2016-11-15 21:57:16 --> Final output sent to browser
INFO - 2016-11-15 21:57:16 --> Router Class Initialized
DEBUG - 2016-11-15 21:57:16 --> Total execution time: 0.2255
INFO - 2016-11-15 21:57:16 --> Output Class Initialized
INFO - 2016-11-15 21:57:16 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:16 --> Input Class Initialized
INFO - 2016-11-15 21:57:16 --> Language Class Initialized
INFO - 2016-11-15 21:57:16 --> Loader Class Initialized
INFO - 2016-11-15 21:57:16 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:16 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:16 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:16 --> Controller Class Initialized
INFO - 2016-11-15 21:57:16 --> Model Class Initialized
INFO - 2016-11-15 21:57:16 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:16 --> Final output sent to browser
DEBUG - 2016-11-15 21:57:16 --> Total execution time: 0.2185
INFO - 2016-11-15 21:57:49 --> Config Class Initialized
INFO - 2016-11-15 21:57:49 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:49 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:49 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:49 --> URI Class Initialized
DEBUG - 2016-11-15 21:57:49 --> No URI present. Default controller set.
INFO - 2016-11-15 21:57:49 --> Router Class Initialized
INFO - 2016-11-15 21:57:49 --> Output Class Initialized
INFO - 2016-11-15 21:57:49 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:49 --> Input Class Initialized
INFO - 2016-11-15 21:57:49 --> Language Class Initialized
INFO - 2016-11-15 21:57:49 --> Loader Class Initialized
INFO - 2016-11-15 21:57:49 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:49 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:49 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:49 --> Controller Class Initialized
INFO - 2016-11-15 21:57:49 --> Model Class Initialized
INFO - 2016-11-15 21:57:49 --> Model Class Initialized
INFO - 2016-11-15 21:57:49 --> Model Class Initialized
INFO - 2016-11-15 21:57:49 --> Model Class Initialized
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:57:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:57:49 --> Final output sent to browser
DEBUG - 2016-11-15 21:57:49 --> Total execution time: 0.3985
INFO - 2016-11-15 21:57:58 --> Config Class Initialized
INFO - 2016-11-15 21:57:58 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:57:58 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:57:58 --> Utf8 Class Initialized
INFO - 2016-11-15 21:57:58 --> URI Class Initialized
INFO - 2016-11-15 21:57:59 --> Router Class Initialized
INFO - 2016-11-15 21:57:59 --> Output Class Initialized
INFO - 2016-11-15 21:57:59 --> Security Class Initialized
DEBUG - 2016-11-15 21:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:57:59 --> Input Class Initialized
INFO - 2016-11-15 21:57:59 --> Language Class Initialized
INFO - 2016-11-15 21:57:59 --> Loader Class Initialized
INFO - 2016-11-15 21:57:59 --> Helper loaded: url_helper
INFO - 2016-11-15 21:57:59 --> Helper loaded: form_helper
INFO - 2016-11-15 21:57:59 --> Database Driver Class Initialized
INFO - 2016-11-15 21:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:57:59 --> Controller Class Initialized
INFO - 2016-11-15 21:57:59 --> Model Class Initialized
INFO - 2016-11-15 21:57:59 --> Form Validation Class Initialized
INFO - 2016-11-15 21:57:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:57:59 --> Final output sent to browser
DEBUG - 2016-11-15 21:57:59 --> Total execution time: 0.2194
INFO - 2016-11-15 21:58:05 --> Config Class Initialized
INFO - 2016-11-15 21:58:05 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:58:05 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:58:05 --> Utf8 Class Initialized
INFO - 2016-11-15 21:58:05 --> URI Class Initialized
INFO - 2016-11-15 21:58:05 --> Router Class Initialized
INFO - 2016-11-15 21:58:05 --> Output Class Initialized
INFO - 2016-11-15 21:58:05 --> Security Class Initialized
DEBUG - 2016-11-15 21:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:58:05 --> Input Class Initialized
INFO - 2016-11-15 21:58:05 --> Language Class Initialized
INFO - 2016-11-15 21:58:05 --> Loader Class Initialized
INFO - 2016-11-15 21:58:05 --> Helper loaded: url_helper
INFO - 2016-11-15 21:58:05 --> Helper loaded: form_helper
INFO - 2016-11-15 21:58:05 --> Database Driver Class Initialized
INFO - 2016-11-15 21:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:58:05 --> Controller Class Initialized
INFO - 2016-11-15 21:58:05 --> Model Class Initialized
INFO - 2016-11-15 21:58:05 --> Form Validation Class Initialized
INFO - 2016-11-15 21:58:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:58:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:58:06 --> Final output sent to browser
DEBUG - 2016-11-15 21:58:06 --> Total execution time: 0.9762
INFO - 2016-11-15 21:59:22 --> Config Class Initialized
INFO - 2016-11-15 21:59:22 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:59:22 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:22 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:22 --> URI Class Initialized
DEBUG - 2016-11-15 21:59:22 --> No URI present. Default controller set.
INFO - 2016-11-15 21:59:22 --> Router Class Initialized
INFO - 2016-11-15 21:59:22 --> Output Class Initialized
INFO - 2016-11-15 21:59:22 --> Security Class Initialized
DEBUG - 2016-11-15 21:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:22 --> Input Class Initialized
INFO - 2016-11-15 21:59:22 --> Language Class Initialized
INFO - 2016-11-15 21:59:22 --> Loader Class Initialized
INFO - 2016-11-15 21:59:22 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:22 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:22 --> Database Driver Class Initialized
INFO - 2016-11-15 21:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:22 --> Controller Class Initialized
INFO - 2016-11-15 21:59:22 --> Model Class Initialized
INFO - 2016-11-15 21:59:22 --> Model Class Initialized
INFO - 2016-11-15 21:59:22 --> Model Class Initialized
INFO - 2016-11-15 21:59:22 --> Model Class Initialized
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 21:59:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 21:59:23 --> Final output sent to browser
DEBUG - 2016-11-15 21:59:23 --> Total execution time: 0.3742
INFO - 2016-11-15 21:59:27 --> Config Class Initialized
INFO - 2016-11-15 21:59:27 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:59:27 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:27 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:27 --> URI Class Initialized
INFO - 2016-11-15 21:59:27 --> Router Class Initialized
INFO - 2016-11-15 21:59:27 --> Output Class Initialized
INFO - 2016-11-15 21:59:27 --> Security Class Initialized
DEBUG - 2016-11-15 21:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:27 --> Input Class Initialized
INFO - 2016-11-15 21:59:27 --> Language Class Initialized
INFO - 2016-11-15 21:59:27 --> Loader Class Initialized
INFO - 2016-11-15 21:59:27 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:27 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:27 --> Database Driver Class Initialized
INFO - 2016-11-15 21:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:27 --> Controller Class Initialized
INFO - 2016-11-15 21:59:27 --> Model Class Initialized
ERROR - 2016-11-15 21:59:27 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 21:59:27 --> Form Validation Class Initialized
INFO - 2016-11-15 21:59:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:59:27 --> Final output sent to browser
DEBUG - 2016-11-15 21:59:27 --> Total execution time: 0.4193
INFO - 2016-11-15 21:59:32 --> Config Class Initialized
INFO - 2016-11-15 21:59:32 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:32 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:32 --> URI Class Initialized
INFO - 2016-11-15 21:59:32 --> Router Class Initialized
INFO - 2016-11-15 21:59:32 --> Output Class Initialized
INFO - 2016-11-15 21:59:32 --> Security Class Initialized
DEBUG - 2016-11-15 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:32 --> Input Class Initialized
INFO - 2016-11-15 21:59:32 --> Language Class Initialized
INFO - 2016-11-15 21:59:32 --> Loader Class Initialized
INFO - 2016-11-15 21:59:32 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:32 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:32 --> Config Class Initialized
INFO - 2016-11-15 21:59:32 --> Hooks Class Initialized
INFO - 2016-11-15 21:59:32 --> Database Driver Class Initialized
DEBUG - 2016-11-15 21:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:32 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:32 --> Controller Class Initialized
INFO - 2016-11-15 21:59:32 --> URI Class Initialized
INFO - 2016-11-15 21:59:32 --> Model Class Initialized
INFO - 2016-11-15 21:59:32 --> Router Class Initialized
ERROR - 2016-11-15 21:59:32 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 21:59:32 --> Output Class Initialized
INFO - 2016-11-15 21:59:32 --> Form Validation Class Initialized
INFO - 2016-11-15 21:59:32 --> Security Class Initialized
INFO - 2016-11-15 21:59:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-15 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:32 --> Final output sent to browser
INFO - 2016-11-15 21:59:32 --> Input Class Initialized
INFO - 2016-11-15 21:59:32 --> Config Class Initialized
DEBUG - 2016-11-15 21:59:32 --> Total execution time: 0.2916
INFO - 2016-11-15 21:59:32 --> Language Class Initialized
INFO - 2016-11-15 21:59:32 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:32 --> Loader Class Initialized
INFO - 2016-11-15 21:59:32 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:32 --> URI Class Initialized
INFO - 2016-11-15 21:59:32 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:32 --> Router Class Initialized
INFO - 2016-11-15 21:59:32 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:32 --> Output Class Initialized
INFO - 2016-11-15 21:59:32 --> Database Driver Class Initialized
INFO - 2016-11-15 21:59:32 --> Security Class Initialized
INFO - 2016-11-15 21:59:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-15 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:32 --> Controller Class Initialized
INFO - 2016-11-15 21:59:32 --> Input Class Initialized
INFO - 2016-11-15 21:59:32 --> Model Class Initialized
INFO - 2016-11-15 21:59:32 --> Language Class Initialized
INFO - 2016-11-15 21:59:32 --> Config Class Initialized
ERROR - 2016-11-15 21:59:32 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 21:59:32 --> Loader Class Initialized
INFO - 2016-11-15 21:59:32 --> Hooks Class Initialized
INFO - 2016-11-15 21:59:32 --> Form Validation Class Initialized
DEBUG - 2016-11-15 21:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:32 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:32 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:59:32 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:32 --> Final output sent to browser
INFO - 2016-11-15 21:59:32 --> URI Class Initialized
INFO - 2016-11-15 21:59:32 --> Database Driver Class Initialized
DEBUG - 2016-11-15 21:59:32 --> Total execution time: 0.3836
INFO - 2016-11-15 21:59:32 --> Router Class Initialized
INFO - 2016-11-15 21:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:32 --> Output Class Initialized
INFO - 2016-11-15 21:59:32 --> Controller Class Initialized
INFO - 2016-11-15 21:59:32 --> Model Class Initialized
INFO - 2016-11-15 21:59:32 --> Security Class Initialized
ERROR - 2016-11-15 21:59:32 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
DEBUG - 2016-11-15 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:32 --> Form Validation Class Initialized
INFO - 2016-11-15 21:59:32 --> Input Class Initialized
INFO - 2016-11-15 21:59:32 --> Language Class Initialized
INFO - 2016-11-15 21:59:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:59:32 --> Config Class Initialized
INFO - 2016-11-15 21:59:32 --> Final output sent to browser
INFO - 2016-11-15 21:59:32 --> Loader Class Initialized
INFO - 2016-11-15 21:59:32 --> Hooks Class Initialized
DEBUG - 2016-11-15 21:59:32 --> Total execution time: 0.3406
DEBUG - 2016-11-15 21:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:32 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:32 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:32 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:32 --> URI Class Initialized
INFO - 2016-11-15 21:59:32 --> Database Driver Class Initialized
INFO - 2016-11-15 21:59:32 --> Router Class Initialized
INFO - 2016-11-15 21:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:32 --> Output Class Initialized
INFO - 2016-11-15 21:59:32 --> Controller Class Initialized
INFO - 2016-11-15 21:59:32 --> Model Class Initialized
INFO - 2016-11-15 21:59:32 --> Security Class Initialized
ERROR - 2016-11-15 21:59:32 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
DEBUG - 2016-11-15 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:32 --> Form Validation Class Initialized
INFO - 2016-11-15 21:59:32 --> Input Class Initialized
INFO - 2016-11-15 21:59:32 --> Language Class Initialized
INFO - 2016-11-15 21:59:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:59:32 --> Final output sent to browser
INFO - 2016-11-15 21:59:32 --> Loader Class Initialized
DEBUG - 2016-11-15 21:59:32 --> Total execution time: 0.3144
INFO - 2016-11-15 21:59:32 --> Config Class Initialized
INFO - 2016-11-15 21:59:32 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:32 --> Hooks Class Initialized
INFO - 2016-11-15 21:59:32 --> Helper loaded: form_helper
DEBUG - 2016-11-15 21:59:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 21:59:32 --> Database Driver Class Initialized
INFO - 2016-11-15 21:59:32 --> Utf8 Class Initialized
INFO - 2016-11-15 21:59:32 --> URI Class Initialized
INFO - 2016-11-15 21:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:32 --> Router Class Initialized
INFO - 2016-11-15 21:59:32 --> Controller Class Initialized
INFO - 2016-11-15 21:59:32 --> Model Class Initialized
INFO - 2016-11-15 21:59:32 --> Output Class Initialized
ERROR - 2016-11-15 21:59:32 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 21:59:32 --> Security Class Initialized
INFO - 2016-11-15 21:59:33 --> Form Validation Class Initialized
DEBUG - 2016-11-15 21:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 21:59:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:59:33 --> Input Class Initialized
INFO - 2016-11-15 21:59:33 --> Final output sent to browser
INFO - 2016-11-15 21:59:33 --> Language Class Initialized
DEBUG - 2016-11-15 21:59:33 --> Total execution time: 0.3196
INFO - 2016-11-15 21:59:33 --> Loader Class Initialized
INFO - 2016-11-15 21:59:33 --> Helper loaded: url_helper
INFO - 2016-11-15 21:59:33 --> Helper loaded: form_helper
INFO - 2016-11-15 21:59:33 --> Database Driver Class Initialized
INFO - 2016-11-15 21:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 21:59:33 --> Controller Class Initialized
INFO - 2016-11-15 21:59:33 --> Model Class Initialized
ERROR - 2016-11-15 21:59:33 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 21:59:33 --> Form Validation Class Initialized
INFO - 2016-11-15 21:59:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 21:59:33 --> Final output sent to browser
DEBUG - 2016-11-15 21:59:33 --> Total execution time: 0.2776
INFO - 2016-11-15 22:00:59 --> Config Class Initialized
INFO - 2016-11-15 22:00:59 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:00:59 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:00:59 --> Utf8 Class Initialized
INFO - 2016-11-15 22:00:59 --> URI Class Initialized
DEBUG - 2016-11-15 22:00:59 --> No URI present. Default controller set.
INFO - 2016-11-15 22:00:59 --> Router Class Initialized
INFO - 2016-11-15 22:00:59 --> Output Class Initialized
INFO - 2016-11-15 22:00:59 --> Security Class Initialized
DEBUG - 2016-11-15 22:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:00:59 --> Input Class Initialized
INFO - 2016-11-15 22:00:59 --> Language Class Initialized
INFO - 2016-11-15 22:00:59 --> Loader Class Initialized
INFO - 2016-11-15 22:00:59 --> Helper loaded: url_helper
INFO - 2016-11-15 22:00:59 --> Helper loaded: form_helper
INFO - 2016-11-15 22:00:59 --> Database Driver Class Initialized
INFO - 2016-11-15 22:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:00:59 --> Controller Class Initialized
INFO - 2016-11-15 22:00:59 --> Model Class Initialized
INFO - 2016-11-15 22:00:59 --> Model Class Initialized
INFO - 2016-11-15 22:00:59 --> Model Class Initialized
INFO - 2016-11-15 22:00:59 --> Model Class Initialized
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:00:59 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:00:59 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:00 --> Total execution time: 0.3887
INFO - 2016-11-15 22:01:16 --> Config Class Initialized
INFO - 2016-11-15 22:01:16 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:01:16 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:16 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:16 --> URI Class Initialized
INFO - 2016-11-15 22:01:16 --> Router Class Initialized
INFO - 2016-11-15 22:01:16 --> Output Class Initialized
INFO - 2016-11-15 22:01:16 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:16 --> Input Class Initialized
INFO - 2016-11-15 22:01:16 --> Language Class Initialized
INFO - 2016-11-15 22:01:16 --> Loader Class Initialized
INFO - 2016-11-15 22:01:16 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:16 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:16 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:16 --> Controller Class Initialized
INFO - 2016-11-15 22:01:16 --> Model Class Initialized
ERROR - 2016-11-15 22:01:16 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:16 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:01:16 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:17 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:17 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:17 --> Total execution time: 0.4871
INFO - 2016-11-15 22:01:21 --> Config Class Initialized
INFO - 2016-11-15 22:01:21 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:01:21 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:21 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:21 --> URI Class Initialized
INFO - 2016-11-15 22:01:21 --> Router Class Initialized
INFO - 2016-11-15 22:01:21 --> Output Class Initialized
INFO - 2016-11-15 22:01:21 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:21 --> Input Class Initialized
INFO - 2016-11-15 22:01:21 --> Language Class Initialized
INFO - 2016-11-15 22:01:21 --> Loader Class Initialized
INFO - 2016-11-15 22:01:21 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:21 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:21 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:21 --> Controller Class Initialized
INFO - 2016-11-15 22:01:21 --> Model Class Initialized
ERROR - 2016-11-15 22:01:21 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:21 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:01:21 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:21 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:21 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:21 --> Total execution time: 0.4457
INFO - 2016-11-15 22:01:22 --> Config Class Initialized
INFO - 2016-11-15 22:01:22 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:01:22 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:22 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> Router Class Initialized
INFO - 2016-11-15 22:01:23 --> Output Class Initialized
INFO - 2016-11-15 22:01:23 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:23 --> Input Class Initialized
INFO - 2016-11-15 22:01:23 --> Language Class Initialized
INFO - 2016-11-15 22:01:23 --> Loader Class Initialized
INFO - 2016-11-15 22:01:23 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:23 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:23 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:23 --> Controller Class Initialized
INFO - 2016-11-15 22:01:23 --> Model Class Initialized
ERROR - 2016-11-15 22:01:23 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:23 --> Config Class Initialized
INFO - 2016-11-15 22:01:23 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:23 --> Hooks Class Initialized
INFO - 2016-11-15 22:01:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-15 22:01:23 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:23 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> Router Class Initialized
INFO - 2016-11-15 22:01:23 --> Output Class Initialized
INFO - 2016-11-15 22:01:23 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:23 --> Input Class Initialized
INFO - 2016-11-15 22:01:23 --> Language Class Initialized
INFO - 2016-11-15 22:01:23 --> Config Class Initialized
INFO - 2016-11-15 22:01:23 --> Loader Class Initialized
INFO - 2016-11-15 22:01:23 --> Hooks Class Initialized
INFO - 2016-11-15 22:01:23 --> Helper loaded: url_helper
DEBUG - 2016-11-15 22:01:23 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:23 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:23 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:23 --> Router Class Initialized
INFO - 2016-11-15 22:01:23 --> Output Class Initialized
INFO - 2016-11-15 22:01:23 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:23 --> Input Class Initialized
ERROR - 2016-11-15 22:01:23 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:23 --> Language Class Initialized
INFO - 2016-11-15 22:01:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:23 --> Loader Class Initialized
INFO - 2016-11-15 22:01:23 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:23 --> Total execution time: 0.4708
INFO - 2016-11-15 22:01:23 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:23 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:23 --> Config Class Initialized
INFO - 2016-11-15 22:01:23 --> Controller Class Initialized
INFO - 2016-11-15 22:01:23 --> Hooks Class Initialized
INFO - 2016-11-15 22:01:23 --> Model Class Initialized
INFO - 2016-11-15 22:01:23 --> Database Driver Class Initialized
DEBUG - 2016-11-15 22:01:23 --> UTF-8 Support Enabled
ERROR - 2016-11-15 22:01:23 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:23 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:23 --> Router Class Initialized
INFO - 2016-11-15 22:01:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:01:23 --> Output Class Initialized
INFO - 2016-11-15 22:01:23 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:23 --> Input Class Initialized
INFO - 2016-11-15 22:01:23 --> Language Class Initialized
INFO - 2016-11-15 22:01:23 --> Loader Class Initialized
INFO - 2016-11-15 22:01:23 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:23 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:23 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:01:23 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:23 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:23 --> Total execution time: 0.5793
INFO - 2016-11-15 22:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:23 --> Controller Class Initialized
INFO - 2016-11-15 22:01:23 --> Model Class Initialized
ERROR - 2016-11-15 22:01:23 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:23 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:01:23 --> Config Class Initialized
INFO - 2016-11-15 22:01:23 --> Hooks Class Initialized
INFO - 2016-11-15 22:01:23 --> Config Class Initialized
INFO - 2016-11-15 22:01:23 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:01:23 --> UTF-8 Support Enabled
DEBUG - 2016-11-15 22:01:23 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:23 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> Router Class Initialized
INFO - 2016-11-15 22:01:23 --> Router Class Initialized
INFO - 2016-11-15 22:01:23 --> Output Class Initialized
INFO - 2016-11-15 22:01:23 --> Config Class Initialized
ERROR - 2016-11-15 22:01:23 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:23 --> Output Class Initialized
INFO - 2016-11-15 22:01:23 --> Security Class Initialized
INFO - 2016-11-15 22:01:23 --> Hooks Class Initialized
INFO - 2016-11-15 22:01:23 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:23 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:23 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:23 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-15 22:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-15 22:01:23 --> Total execution time: 0.6582
INFO - 2016-11-15 22:01:23 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:23 --> Input Class Initialized
INFO - 2016-11-15 22:01:23 --> Input Class Initialized
INFO - 2016-11-15 22:01:23 --> URI Class Initialized
INFO - 2016-11-15 22:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:23 --> Language Class Initialized
INFO - 2016-11-15 22:01:23 --> Controller Class Initialized
INFO - 2016-11-15 22:01:23 --> Language Class Initialized
INFO - 2016-11-15 22:01:24 --> Loader Class Initialized
INFO - 2016-11-15 22:01:24 --> Router Class Initialized
INFO - 2016-11-15 22:01:24 --> Model Class Initialized
INFO - 2016-11-15 22:01:24 --> Loader Class Initialized
INFO - 2016-11-15 22:01:24 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:24 --> Output Class Initialized
INFO - 2016-11-15 22:01:24 --> Helper loaded: url_helper
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:24 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:24 --> Security Class Initialized
INFO - 2016-11-15 22:01:24 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:24 --> Form Validation Class Initialized
DEBUG - 2016-11-15 22:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:24 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:24 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:24 --> Input Class Initialized
INFO - 2016-11-15 22:01:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:01:24 --> Language Class Initialized
INFO - 2016-11-15 22:01:24 --> Loader Class Initialized
INFO - 2016-11-15 22:01:24 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:24 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:24 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:24 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:24 --> Total execution time: 0.7168
INFO - 2016-11-15 22:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:24 --> Controller Class Initialized
INFO - 2016-11-15 22:01:24 --> Model Class Initialized
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:24 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:24 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:24 --> Total execution time: 0.6023
INFO - 2016-11-15 22:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:24 --> Controller Class Initialized
INFO - 2016-11-15 22:01:24 --> Model Class Initialized
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:24 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:24 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:24 --> Total execution time: 0.8518
INFO - 2016-11-15 22:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:24 --> Controller Class Initialized
INFO - 2016-11-15 22:01:24 --> Model Class Initialized
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: userRole C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 40
INFO - 2016-11-15 22:01:24 --> Form Validation Class Initialized
INFO - 2016-11-15 22:01:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:01:24 --> Severity: Notice --> Undefined variable: subordinate C:\xampp\htdocs\LMS\app\controllers\Leave_records_c.php 63
INFO - 2016-11-15 22:01:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:24 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:24 --> Total execution time: 1.0012
INFO - 2016-11-15 22:01:30 --> Config Class Initialized
INFO - 2016-11-15 22:01:30 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:01:30 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:01:30 --> Utf8 Class Initialized
INFO - 2016-11-15 22:01:30 --> URI Class Initialized
DEBUG - 2016-11-15 22:01:30 --> No URI present. Default controller set.
INFO - 2016-11-15 22:01:30 --> Router Class Initialized
INFO - 2016-11-15 22:01:30 --> Output Class Initialized
INFO - 2016-11-15 22:01:30 --> Security Class Initialized
DEBUG - 2016-11-15 22:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:01:30 --> Input Class Initialized
INFO - 2016-11-15 22:01:30 --> Language Class Initialized
INFO - 2016-11-15 22:01:30 --> Loader Class Initialized
INFO - 2016-11-15 22:01:30 --> Helper loaded: url_helper
INFO - 2016-11-15 22:01:30 --> Helper loaded: form_helper
INFO - 2016-11-15 22:01:30 --> Database Driver Class Initialized
INFO - 2016-11-15 22:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:01:30 --> Controller Class Initialized
INFO - 2016-11-15 22:01:30 --> Model Class Initialized
INFO - 2016-11-15 22:01:30 --> Model Class Initialized
INFO - 2016-11-15 22:01:30 --> Model Class Initialized
INFO - 2016-11-15 22:01:30 --> Model Class Initialized
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:01:30 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:01:30 --> Final output sent to browser
DEBUG - 2016-11-15 22:01:30 --> Total execution time: 0.3988
INFO - 2016-11-15 22:02:45 --> Config Class Initialized
INFO - 2016-11-15 22:02:46 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:02:46 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:02:46 --> Utf8 Class Initialized
INFO - 2016-11-15 22:02:46 --> URI Class Initialized
INFO - 2016-11-15 22:02:46 --> Router Class Initialized
INFO - 2016-11-15 22:02:46 --> Output Class Initialized
INFO - 2016-11-15 22:02:46 --> Security Class Initialized
DEBUG - 2016-11-15 22:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:02:46 --> Input Class Initialized
INFO - 2016-11-15 22:02:46 --> Language Class Initialized
INFO - 2016-11-15 22:02:46 --> Loader Class Initialized
INFO - 2016-11-15 22:02:46 --> Helper loaded: url_helper
INFO - 2016-11-15 22:02:46 --> Helper loaded: form_helper
INFO - 2016-11-15 22:02:46 --> Database Driver Class Initialized
INFO - 2016-11-15 22:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:02:46 --> Controller Class Initialized
INFO - 2016-11-15 22:02:46 --> Model Class Initialized
INFO - 2016-11-15 22:02:46 --> Form Validation Class Initialized
INFO - 2016-11-15 22:02:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:02:46 --> Final output sent to browser
DEBUG - 2016-11-15 22:02:46 --> Total execution time: 0.5902
INFO - 2016-11-15 22:03:45 --> Config Class Initialized
INFO - 2016-11-15 22:03:45 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:03:45 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:03:45 --> Utf8 Class Initialized
INFO - 2016-11-15 22:03:45 --> URI Class Initialized
DEBUG - 2016-11-15 22:03:45 --> No URI present. Default controller set.
INFO - 2016-11-15 22:03:45 --> Router Class Initialized
INFO - 2016-11-15 22:03:45 --> Output Class Initialized
INFO - 2016-11-15 22:03:45 --> Security Class Initialized
DEBUG - 2016-11-15 22:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:03:45 --> Input Class Initialized
INFO - 2016-11-15 22:03:45 --> Language Class Initialized
INFO - 2016-11-15 22:03:45 --> Loader Class Initialized
INFO - 2016-11-15 22:03:45 --> Helper loaded: url_helper
INFO - 2016-11-15 22:03:45 --> Helper loaded: form_helper
INFO - 2016-11-15 22:03:45 --> Database Driver Class Initialized
INFO - 2016-11-15 22:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:03:45 --> Controller Class Initialized
INFO - 2016-11-15 22:03:45 --> Model Class Initialized
INFO - 2016-11-15 22:03:45 --> Model Class Initialized
INFO - 2016-11-15 22:03:45 --> Model Class Initialized
INFO - 2016-11-15 22:03:45 --> Model Class Initialized
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:03:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:03:45 --> Final output sent to browser
DEBUG - 2016-11-15 22:03:45 --> Total execution time: 0.5264
INFO - 2016-11-15 22:03:52 --> Config Class Initialized
INFO - 2016-11-15 22:03:52 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:03:52 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:03:52 --> Utf8 Class Initialized
INFO - 2016-11-15 22:03:52 --> URI Class Initialized
INFO - 2016-11-15 22:03:52 --> Router Class Initialized
INFO - 2016-11-15 22:03:52 --> Output Class Initialized
INFO - 2016-11-15 22:03:52 --> Security Class Initialized
DEBUG - 2016-11-15 22:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:03:52 --> Input Class Initialized
INFO - 2016-11-15 22:03:52 --> Language Class Initialized
INFO - 2016-11-15 22:03:52 --> Loader Class Initialized
INFO - 2016-11-15 22:03:52 --> Helper loaded: url_helper
INFO - 2016-11-15 22:03:52 --> Helper loaded: form_helper
INFO - 2016-11-15 22:03:52 --> Database Driver Class Initialized
INFO - 2016-11-15 22:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:03:52 --> Controller Class Initialized
INFO - 2016-11-15 22:03:52 --> Model Class Initialized
INFO - 2016-11-15 22:03:52 --> Form Validation Class Initialized
INFO - 2016-11-15 22:03:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:03:52 --> Final output sent to browser
DEBUG - 2016-11-15 22:03:52 --> Total execution time: 0.2757
INFO - 2016-11-15 22:04:19 --> Config Class Initialized
INFO - 2016-11-15 22:04:19 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:19 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:19 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:19 --> URI Class Initialized
INFO - 2016-11-15 22:04:19 --> Router Class Initialized
INFO - 2016-11-15 22:04:19 --> Output Class Initialized
INFO - 2016-11-15 22:04:19 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:19 --> Input Class Initialized
INFO - 2016-11-15 22:04:19 --> Language Class Initialized
INFO - 2016-11-15 22:04:20 --> Loader Class Initialized
INFO - 2016-11-15 22:04:20 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:20 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:20 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:20 --> Controller Class Initialized
INFO - 2016-11-15 22:04:20 --> Model Class Initialized
INFO - 2016-11-15 22:04:20 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:20 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:20', '1', 'Test')
INFO - 2016-11-15 22:04:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:24 --> Config Class Initialized
INFO - 2016-11-15 22:04:24 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:24 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:24 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:24 --> URI Class Initialized
INFO - 2016-11-15 22:04:24 --> Router Class Initialized
INFO - 2016-11-15 22:04:24 --> Output Class Initialized
INFO - 2016-11-15 22:04:24 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:24 --> Input Class Initialized
INFO - 2016-11-15 22:04:24 --> Language Class Initialized
INFO - 2016-11-15 22:04:24 --> Loader Class Initialized
INFO - 2016-11-15 22:04:24 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:24 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:24 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:24 --> Controller Class Initialized
INFO - 2016-11-15 22:04:24 --> Model Class Initialized
INFO - 2016-11-15 22:04:25 --> Config Class Initialized
INFO - 2016-11-15 22:04:25 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:25 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-11-15 22:04:25 --> UTF-8 Support Enabled
ERROR - 2016-11-15 22:04:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:25 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:25 --> URI Class Initialized
INFO - 2016-11-15 22:04:25 --> Router Class Initialized
INFO - 2016-11-15 22:04:25 --> Output Class Initialized
INFO - 2016-11-15 22:04:25 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:25 --> Input Class Initialized
INFO - 2016-11-15 22:04:25 --> Language Class Initialized
INFO - 2016-11-15 22:04:25 --> Loader Class Initialized
INFO - 2016-11-15 22:04:25 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:25 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:25 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:25 --> Config Class Initialized
INFO - 2016-11-15 22:04:25 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:25 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:25 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:25 --> URI Class Initialized
ERROR - 2016-11-15 22:04:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:25', '1', 'Test')
INFO - 2016-11-15 22:04:25 --> Router Class Initialized
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:25 --> Output Class Initialized
INFO - 2016-11-15 22:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:25 --> Security Class Initialized
INFO - 2016-11-15 22:04:25 --> Controller Class Initialized
INFO - 2016-11-15 22:04:25 --> Model Class Initialized
DEBUG - 2016-11-15 22:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:25 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:25 --> Input Class Initialized
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:25 --> Language Class Initialized
ERROR - 2016-11-15 22:04:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:25 --> Loader Class Initialized
INFO - 2016-11-15 22:04:25 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:25 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:25 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:25 --> Config Class Initialized
INFO - 2016-11-15 22:04:25 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:25 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:25 --> Utf8 Class Initialized
ERROR - 2016-11-15 22:04:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:25', '1', 'Test')
INFO - 2016-11-15 22:04:25 --> URI Class Initialized
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:25 --> Router Class Initialized
INFO - 2016-11-15 22:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:25 --> Output Class Initialized
INFO - 2016-11-15 22:04:25 --> Controller Class Initialized
INFO - 2016-11-15 22:04:25 --> Model Class Initialized
INFO - 2016-11-15 22:04:25 --> Security Class Initialized
INFO - 2016-11-15 22:04:25 --> Form Validation Class Initialized
DEBUG - 2016-11-15 22:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:25 --> Input Class Initialized
INFO - 2016-11-15 22:04:25 --> Language Class Initialized
ERROR - 2016-11-15 22:04:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:25 --> Loader Class Initialized
INFO - 2016-11-15 22:04:25 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:25 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:25 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:25 --> Config Class Initialized
INFO - 2016-11-15 22:04:25 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:25 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:25 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:25 --> URI Class Initialized
INFO - 2016-11-15 22:04:25 --> Router Class Initialized
INFO - 2016-11-15 22:04:25 --> Output Class Initialized
ERROR - 2016-11-15 22:04:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:25', '1', 'Test')
INFO - 2016-11-15 22:04:25 --> Security Class Initialized
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-15 22:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:25 --> Input Class Initialized
INFO - 2016-11-15 22:04:25 --> Controller Class Initialized
INFO - 2016-11-15 22:04:25 --> Language Class Initialized
INFO - 2016-11-15 22:04:25 --> Model Class Initialized
INFO - 2016-11-15 22:04:25 --> Loader Class Initialized
INFO - 2016-11-15 22:04:25 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:25 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:25 --> Helper loaded: form_helper
ERROR - 2016-11-15 22:04:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:25 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:25 --> Config Class Initialized
INFO - 2016-11-15 22:04:25 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:25 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:25 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:25 --> URI Class Initialized
INFO - 2016-11-15 22:04:25 --> Router Class Initialized
INFO - 2016-11-15 22:04:25 --> Output Class Initialized
INFO - 2016-11-15 22:04:25 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:25 --> Input Class Initialized
INFO - 2016-11-15 22:04:25 --> Language Class Initialized
INFO - 2016-11-15 22:04:25 --> Loader Class Initialized
INFO - 2016-11-15 22:04:25 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:25 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:25 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:04:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:25', '1', 'Test')
INFO - 2016-11-15 22:04:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:25 --> Controller Class Initialized
INFO - 2016-11-15 22:04:25 --> Config Class Initialized
INFO - 2016-11-15 22:04:26 --> Model Class Initialized
INFO - 2016-11-15 22:04:26 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:26 --> Form Validation Class Initialized
DEBUG - 2016-11-15 22:04:26 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:26 --> Utf8 Class Initialized
ERROR - 2016-11-15 22:04:26 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:26 --> URI Class Initialized
INFO - 2016-11-15 22:04:26 --> Router Class Initialized
INFO - 2016-11-15 22:04:26 --> Output Class Initialized
INFO - 2016-11-15 22:04:26 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:26 --> Input Class Initialized
INFO - 2016-11-15 22:04:26 --> Language Class Initialized
INFO - 2016-11-15 22:04:26 --> Loader Class Initialized
INFO - 2016-11-15 22:04:26 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:26 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:26 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:04:26 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:26', '1', 'Test')
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:26 --> Controller Class Initialized
INFO - 2016-11-15 22:04:26 --> Config Class Initialized
INFO - 2016-11-15 22:04:26 --> Model Class Initialized
INFO - 2016-11-15 22:04:26 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:26 --> Form Validation Class Initialized
DEBUG - 2016-11-15 22:04:26 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:26 --> Utf8 Class Initialized
ERROR - 2016-11-15 22:04:26 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:26 --> URI Class Initialized
INFO - 2016-11-15 22:04:26 --> Router Class Initialized
INFO - 2016-11-15 22:04:26 --> Output Class Initialized
INFO - 2016-11-15 22:04:26 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:26 --> Input Class Initialized
INFO - 2016-11-15 22:04:26 --> Language Class Initialized
INFO - 2016-11-15 22:04:26 --> Loader Class Initialized
INFO - 2016-11-15 22:04:26 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:26 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:26 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:04:26 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:26', '1', 'Test')
INFO - 2016-11-15 22:04:26 --> Config Class Initialized
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:26 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-15 22:04:26 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:26 --> Controller Class Initialized
INFO - 2016-11-15 22:04:26 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:26 --> Model Class Initialized
INFO - 2016-11-15 22:04:26 --> URI Class Initialized
INFO - 2016-11-15 22:04:26 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:26 --> Router Class Initialized
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:26 --> Output Class Initialized
ERROR - 2016-11-15 22:04:26 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:26 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:26 --> Input Class Initialized
INFO - 2016-11-15 22:04:26 --> Language Class Initialized
INFO - 2016-11-15 22:04:26 --> Loader Class Initialized
INFO - 2016-11-15 22:04:26 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:26 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:26 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:26 --> Config Class Initialized
INFO - 2016-11-15 22:04:26 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:26 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:26 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:26 --> URI Class Initialized
INFO - 2016-11-15 22:04:26 --> Router Class Initialized
INFO - 2016-11-15 22:04:26 --> Output Class Initialized
INFO - 2016-11-15 22:04:26 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:26 --> Input Class Initialized
INFO - 2016-11-15 22:04:26 --> Language Class Initialized
INFO - 2016-11-15 22:04:26 --> Loader Class Initialized
ERROR - 2016-11-15 22:04:26 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:26', '1', 'Test')
INFO - 2016-11-15 22:04:26 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:26 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:26 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:26 --> Controller Class Initialized
INFO - 2016-11-15 22:04:26 --> Model Class Initialized
INFO - 2016-11-15 22:04:26 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:26 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:26 --> Config Class Initialized
INFO - 2016-11-15 22:04:26 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:26 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:26 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:26 --> URI Class Initialized
ERROR - 2016-11-15 22:04:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:26', '1', 'Test')
INFO - 2016-11-15 22:04:27 --> Router Class Initialized
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:27 --> Output Class Initialized
INFO - 2016-11-15 22:04:27 --> Config Class Initialized
INFO - 2016-11-15 22:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:27 --> Security Class Initialized
INFO - 2016-11-15 22:04:27 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:27 --> Controller Class Initialized
DEBUG - 2016-11-15 22:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-15 22:04:27 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:27 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:27 --> Input Class Initialized
INFO - 2016-11-15 22:04:27 --> Model Class Initialized
INFO - 2016-11-15 22:04:27 --> Language Class Initialized
INFO - 2016-11-15 22:04:27 --> URI Class Initialized
INFO - 2016-11-15 22:04:27 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:27 --> Loader Class Initialized
INFO - 2016-11-15 22:04:27 --> Router Class Initialized
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:27 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:27 --> Output Class Initialized
ERROR - 2016-11-15 22:04:27 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:27 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:27 --> Security Class Initialized
INFO - 2016-11-15 22:04:27 --> Database Driver Class Initialized
DEBUG - 2016-11-15 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:27 --> Input Class Initialized
INFO - 2016-11-15 22:04:27 --> Language Class Initialized
INFO - 2016-11-15 22:04:27 --> Loader Class Initialized
INFO - 2016-11-15 22:04:27 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:27 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:27 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:04:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:27', '1', 'Test')
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:27 --> Controller Class Initialized
INFO - 2016-11-15 22:04:27 --> Model Class Initialized
INFO - 2016-11-15 22:04:27 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:27 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:27', '1', 'Test')
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:27 --> Controller Class Initialized
INFO - 2016-11-15 22:04:27 --> Model Class Initialized
INFO - 2016-11-15 22:04:27 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:27 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:27', '1', 'Test')
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:27 --> Controller Class Initialized
INFO - 2016-11-15 22:04:27 --> Model Class Initialized
INFO - 2016-11-15 22:04:27 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:27 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:27', '1', 'Test')
INFO - 2016-11-15 22:04:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:32 --> Config Class Initialized
INFO - 2016-11-15 22:04:32 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:32 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:32 --> URI Class Initialized
INFO - 2016-11-15 22:04:32 --> Router Class Initialized
INFO - 2016-11-15 22:04:32 --> Output Class Initialized
INFO - 2016-11-15 22:04:32 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:32 --> Input Class Initialized
INFO - 2016-11-15 22:04:32 --> Language Class Initialized
INFO - 2016-11-15 22:04:32 --> Config Class Initialized
INFO - 2016-11-15 22:04:32 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:32 --> Loader Class Initialized
DEBUG - 2016-11-15 22:04:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:32 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:32 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:32 --> URI Class Initialized
INFO - 2016-11-15 22:04:32 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:32 --> Router Class Initialized
INFO - 2016-11-15 22:04:32 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:32 --> Output Class Initialized
INFO - 2016-11-15 22:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:32 --> Security Class Initialized
INFO - 2016-11-15 22:04:32 --> Controller Class Initialized
INFO - 2016-11-15 22:04:32 --> Model Class Initialized
DEBUG - 2016-11-15 22:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:32 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:32 --> Input Class Initialized
INFO - 2016-11-15 22:04:32 --> Language Class Initialized
INFO - 2016-11-15 22:04:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:32 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:32 --> Loader Class Initialized
INFO - 2016-11-15 22:04:32 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:32 --> Config Class Initialized
INFO - 2016-11-15 22:04:32 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:32 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:32 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:32 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:32 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:32 --> URI Class Initialized
INFO - 2016-11-15 22:04:32 --> Router Class Initialized
INFO - 2016-11-15 22:04:32 --> Output Class Initialized
INFO - 2016-11-15 22:04:32 --> Security Class Initialized
ERROR - 2016-11-15 22:04:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:32', '1', 'Test')
DEBUG - 2016-11-15 22:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:32 --> Input Class Initialized
INFO - 2016-11-15 22:04:32 --> Language Class Initialized
INFO - 2016-11-15 22:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:32 --> Loader Class Initialized
INFO - 2016-11-15 22:04:32 --> Controller Class Initialized
INFO - 2016-11-15 22:04:32 --> Model Class Initialized
INFO - 2016-11-15 22:04:32 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:32 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:32 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:32 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:04:32 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:32', '1', 'Test')
INFO - 2016-11-15 22:04:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:32 --> Controller Class Initialized
INFO - 2016-11-15 22:04:32 --> Config Class Initialized
INFO - 2016-11-15 22:04:32 --> Model Class Initialized
INFO - 2016-11-15 22:04:32 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:33 --> Form Validation Class Initialized
DEBUG - 2016-11-15 22:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:33 --> Utf8 Class Initialized
ERROR - 2016-11-15 22:04:33 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:04:33 --> URI Class Initialized
INFO - 2016-11-15 22:04:33 --> Router Class Initialized
INFO - 2016-11-15 22:04:33 --> Output Class Initialized
INFO - 2016-11-15 22:04:33 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:33 --> Input Class Initialized
INFO - 2016-11-15 22:04:33 --> Language Class Initialized
INFO - 2016-11-15 22:04:33 --> Loader Class Initialized
INFO - 2016-11-15 22:04:33 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:33 --> Helper loaded: form_helper
ERROR - 2016-11-15 22:04:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:33', '1', 'Test')
INFO - 2016-11-15 22:04:33 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:33 --> Controller Class Initialized
INFO - 2016-11-15 22:04:33 --> Model Class Initialized
INFO - 2016-11-15 22:04:33 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:33 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:33', '1', 'Test')
INFO - 2016-11-15 22:04:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:33 --> Config Class Initialized
INFO - 2016-11-15 22:04:33 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:33 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:33 --> URI Class Initialized
INFO - 2016-11-15 22:04:33 --> Router Class Initialized
INFO - 2016-11-15 22:04:33 --> Output Class Initialized
INFO - 2016-11-15 22:04:33 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:33 --> Input Class Initialized
INFO - 2016-11-15 22:04:33 --> Language Class Initialized
INFO - 2016-11-15 22:04:33 --> Config Class Initialized
INFO - 2016-11-15 22:04:33 --> Loader Class Initialized
INFO - 2016-11-15 22:04:33 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:33 --> Helper loaded: url_helper
DEBUG - 2016-11-15 22:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:33 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:33 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:33 --> URI Class Initialized
INFO - 2016-11-15 22:04:33 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:33 --> Router Class Initialized
INFO - 2016-11-15 22:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:33 --> Output Class Initialized
INFO - 2016-11-15 22:04:33 --> Controller Class Initialized
INFO - 2016-11-15 22:04:33 --> Model Class Initialized
INFO - 2016-11-15 22:04:33 --> Security Class Initialized
INFO - 2016-11-15 22:04:33 --> Form Validation Class Initialized
DEBUG - 2016-11-15 22:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:33 --> Config Class Initialized
INFO - 2016-11-15 22:04:33 --> Input Class Initialized
INFO - 2016-11-15 22:04:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:33 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:33 --> Language Class Initialized
ERROR - 2016-11-15 22:04:33 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-15 22:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:33 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:33 --> Loader Class Initialized
INFO - 2016-11-15 22:04:33 --> URI Class Initialized
INFO - 2016-11-15 22:04:33 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:33 --> Router Class Initialized
INFO - 2016-11-15 22:04:33 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:33 --> Output Class Initialized
INFO - 2016-11-15 22:04:33 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:33 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:33 --> Config Class Initialized
ERROR - 2016-11-15 22:04:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:33', '1', 'Test')
INFO - 2016-11-15 22:04:33 --> Input Class Initialized
INFO - 2016-11-15 22:04:33 --> Hooks Class Initialized
INFO - 2016-11-15 22:04:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-11-15 22:04:33 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:33 --> Language Class Initialized
INFO - 2016-11-15 22:04:33 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:33 --> Loader Class Initialized
INFO - 2016-11-15 22:04:33 --> Controller Class Initialized
INFO - 2016-11-15 22:04:34 --> URI Class Initialized
INFO - 2016-11-15 22:04:34 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:34 --> Model Class Initialized
INFO - 2016-11-15 22:04:34 --> Router Class Initialized
INFO - 2016-11-15 22:04:34 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:34 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:34 --> Output Class Initialized
INFO - 2016-11-15 22:04:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:04:34 --> Security Class Initialized
INFO - 2016-11-15 22:04:34 --> Database Driver Class Initialized
ERROR - 2016-11-15 22:04:34 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
DEBUG - 2016-11-15 22:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:34 --> Input Class Initialized
INFO - 2016-11-15 22:04:34 --> Language Class Initialized
INFO - 2016-11-15 22:04:34 --> Loader Class Initialized
ERROR - 2016-11-15 22:04:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:34', '1', 'Test')
INFO - 2016-11-15 22:04:34 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:34 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:34 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:34 --> Controller Class Initialized
INFO - 2016-11-15 22:04:34 --> Model Class Initialized
INFO - 2016-11-15 22:04:34 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:34 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:34', '1', 'Test')
INFO - 2016-11-15 22:04:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:34 --> Controller Class Initialized
INFO - 2016-11-15 22:04:34 --> Model Class Initialized
INFO - 2016-11-15 22:04:34 --> Form Validation Class Initialized
INFO - 2016-11-15 22:04:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:04:34 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:04:34 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-01', '2016-11-02', '3', '3', '2016-11-15 22:04:34', '1', 'Test')
INFO - 2016-11-15 22:04:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:04:42 --> Config Class Initialized
INFO - 2016-11-15 22:04:42 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:04:42 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:04:42 --> Utf8 Class Initialized
INFO - 2016-11-15 22:04:42 --> URI Class Initialized
DEBUG - 2016-11-15 22:04:42 --> No URI present. Default controller set.
INFO - 2016-11-15 22:04:42 --> Router Class Initialized
INFO - 2016-11-15 22:04:42 --> Output Class Initialized
INFO - 2016-11-15 22:04:42 --> Security Class Initialized
DEBUG - 2016-11-15 22:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:04:42 --> Input Class Initialized
INFO - 2016-11-15 22:04:42 --> Language Class Initialized
INFO - 2016-11-15 22:04:42 --> Loader Class Initialized
INFO - 2016-11-15 22:04:42 --> Helper loaded: url_helper
INFO - 2016-11-15 22:04:42 --> Helper loaded: form_helper
INFO - 2016-11-15 22:04:42 --> Database Driver Class Initialized
INFO - 2016-11-15 22:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:04:42 --> Controller Class Initialized
INFO - 2016-11-15 22:04:42 --> Model Class Initialized
INFO - 2016-11-15 22:04:42 --> Model Class Initialized
INFO - 2016-11-15 22:04:42 --> Model Class Initialized
INFO - 2016-11-15 22:04:42 --> Model Class Initialized
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:04:42 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:04:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:04:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:04:43 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:04:43 --> Final output sent to browser
DEBUG - 2016-11-15 22:04:43 --> Total execution time: 0.4255
INFO - 2016-11-15 22:05:48 --> Config Class Initialized
INFO - 2016-11-15 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:05:48 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:05:48 --> Utf8 Class Initialized
INFO - 2016-11-15 22:05:48 --> URI Class Initialized
DEBUG - 2016-11-15 22:05:48 --> No URI present. Default controller set.
INFO - 2016-11-15 22:05:48 --> Router Class Initialized
INFO - 2016-11-15 22:05:48 --> Output Class Initialized
INFO - 2016-11-15 22:05:48 --> Security Class Initialized
DEBUG - 2016-11-15 22:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:05:48 --> Input Class Initialized
INFO - 2016-11-15 22:05:48 --> Language Class Initialized
INFO - 2016-11-15 22:05:48 --> Loader Class Initialized
INFO - 2016-11-15 22:05:48 --> Helper loaded: url_helper
INFO - 2016-11-15 22:05:48 --> Helper loaded: form_helper
INFO - 2016-11-15 22:05:48 --> Database Driver Class Initialized
INFO - 2016-11-15 22:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:05:48 --> Controller Class Initialized
INFO - 2016-11-15 22:05:48 --> Model Class Initialized
INFO - 2016-11-15 22:05:48 --> Model Class Initialized
INFO - 2016-11-15 22:05:48 --> Model Class Initialized
INFO - 2016-11-15 22:05:48 --> Model Class Initialized
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:05:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:05:48 --> Final output sent to browser
DEBUG - 2016-11-15 22:05:48 --> Total execution time: 0.4424
INFO - 2016-11-15 22:06:06 --> Config Class Initialized
INFO - 2016-11-15 22:06:06 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:06:06 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:06:06 --> Utf8 Class Initialized
INFO - 2016-11-15 22:06:06 --> URI Class Initialized
INFO - 2016-11-15 22:06:06 --> Router Class Initialized
INFO - 2016-11-15 22:06:06 --> Output Class Initialized
INFO - 2016-11-15 22:06:06 --> Security Class Initialized
DEBUG - 2016-11-15 22:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:06:06 --> Input Class Initialized
INFO - 2016-11-15 22:06:06 --> Language Class Initialized
INFO - 2016-11-15 22:06:06 --> Loader Class Initialized
INFO - 2016-11-15 22:06:06 --> Helper loaded: url_helper
INFO - 2016-11-15 22:06:06 --> Helper loaded: form_helper
INFO - 2016-11-15 22:06:06 --> Database Driver Class Initialized
INFO - 2016-11-15 22:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:06:06 --> Controller Class Initialized
INFO - 2016-11-15 22:06:06 --> Model Class Initialized
INFO - 2016-11-15 22:06:06 --> Form Validation Class Initialized
INFO - 2016-11-15 22:06:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:06:06 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:06:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-24', '2016-11-26', '3', '2', '2016-11-15 22:06:06', '1', '')
INFO - 2016-11-15 22:06:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:06:22 --> Config Class Initialized
INFO - 2016-11-15 22:06:22 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:06:22 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:06:22 --> Utf8 Class Initialized
INFO - 2016-11-15 22:06:22 --> URI Class Initialized
DEBUG - 2016-11-15 22:06:22 --> No URI present. Default controller set.
INFO - 2016-11-15 22:06:22 --> Router Class Initialized
INFO - 2016-11-15 22:06:22 --> Output Class Initialized
INFO - 2016-11-15 22:06:22 --> Security Class Initialized
DEBUG - 2016-11-15 22:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:06:22 --> Input Class Initialized
INFO - 2016-11-15 22:06:22 --> Language Class Initialized
INFO - 2016-11-15 22:06:22 --> Loader Class Initialized
INFO - 2016-11-15 22:06:22 --> Helper loaded: url_helper
INFO - 2016-11-15 22:06:22 --> Helper loaded: form_helper
INFO - 2016-11-15 22:06:22 --> Database Driver Class Initialized
INFO - 2016-11-15 22:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:06:22 --> Controller Class Initialized
INFO - 2016-11-15 22:06:22 --> Model Class Initialized
INFO - 2016-11-15 22:06:22 --> Model Class Initialized
INFO - 2016-11-15 22:06:22 --> Model Class Initialized
INFO - 2016-11-15 22:06:22 --> Model Class Initialized
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:06:22 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:06:22 --> Final output sent to browser
DEBUG - 2016-11-15 22:06:22 --> Total execution time: 0.4428
INFO - 2016-11-15 22:07:19 --> Config Class Initialized
INFO - 2016-11-15 22:07:19 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:07:19 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:07:19 --> Utf8 Class Initialized
INFO - 2016-11-15 22:07:19 --> URI Class Initialized
DEBUG - 2016-11-15 22:07:19 --> No URI present. Default controller set.
INFO - 2016-11-15 22:07:19 --> Router Class Initialized
INFO - 2016-11-15 22:07:19 --> Output Class Initialized
INFO - 2016-11-15 22:07:19 --> Security Class Initialized
DEBUG - 2016-11-15 22:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:07:19 --> Input Class Initialized
INFO - 2016-11-15 22:07:19 --> Language Class Initialized
INFO - 2016-11-15 22:07:19 --> Loader Class Initialized
INFO - 2016-11-15 22:07:19 --> Helper loaded: url_helper
INFO - 2016-11-15 22:07:19 --> Helper loaded: form_helper
INFO - 2016-11-15 22:07:19 --> Database Driver Class Initialized
INFO - 2016-11-15 22:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:07:19 --> Controller Class Initialized
INFO - 2016-11-15 22:07:19 --> Model Class Initialized
INFO - 2016-11-15 22:07:19 --> Model Class Initialized
INFO - 2016-11-15 22:07:19 --> Model Class Initialized
INFO - 2016-11-15 22:07:19 --> Model Class Initialized
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:07:19 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:07:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:07:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:07:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:07:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:07:20 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:07:20 --> Final output sent to browser
DEBUG - 2016-11-15 22:07:20 --> Total execution time: 0.4459
INFO - 2016-11-15 22:09:35 --> Config Class Initialized
INFO - 2016-11-15 22:09:35 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:09:35 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:09:35 --> Utf8 Class Initialized
INFO - 2016-11-15 22:09:35 --> URI Class Initialized
DEBUG - 2016-11-15 22:09:35 --> No URI present. Default controller set.
INFO - 2016-11-15 22:09:35 --> Router Class Initialized
INFO - 2016-11-15 22:09:35 --> Output Class Initialized
INFO - 2016-11-15 22:09:35 --> Security Class Initialized
DEBUG - 2016-11-15 22:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:09:35 --> Input Class Initialized
INFO - 2016-11-15 22:09:35 --> Language Class Initialized
INFO - 2016-11-15 22:09:35 --> Loader Class Initialized
INFO - 2016-11-15 22:09:35 --> Helper loaded: url_helper
INFO - 2016-11-15 22:09:35 --> Helper loaded: form_helper
INFO - 2016-11-15 22:09:35 --> Database Driver Class Initialized
INFO - 2016-11-15 22:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:09:35 --> Controller Class Initialized
INFO - 2016-11-15 22:09:35 --> Model Class Initialized
INFO - 2016-11-15 22:09:35 --> Model Class Initialized
INFO - 2016-11-15 22:09:35 --> Model Class Initialized
INFO - 2016-11-15 22:09:35 --> Model Class Initialized
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:09:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:09:35 --> Final output sent to browser
DEBUG - 2016-11-15 22:09:35 --> Total execution time: 1.2692
INFO - 2016-11-15 22:10:47 --> Config Class Initialized
INFO - 2016-11-15 22:10:47 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:10:47 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:10:47 --> Utf8 Class Initialized
INFO - 2016-11-15 22:10:47 --> URI Class Initialized
DEBUG - 2016-11-15 22:10:47 --> No URI present. Default controller set.
INFO - 2016-11-15 22:10:47 --> Router Class Initialized
INFO - 2016-11-15 22:10:48 --> Output Class Initialized
INFO - 2016-11-15 22:10:48 --> Security Class Initialized
DEBUG - 2016-11-15 22:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:10:48 --> Input Class Initialized
INFO - 2016-11-15 22:10:48 --> Language Class Initialized
INFO - 2016-11-15 22:10:48 --> Loader Class Initialized
INFO - 2016-11-15 22:10:48 --> Helper loaded: url_helper
INFO - 2016-11-15 22:10:48 --> Helper loaded: form_helper
INFO - 2016-11-15 22:10:48 --> Database Driver Class Initialized
INFO - 2016-11-15 22:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:10:48 --> Controller Class Initialized
INFO - 2016-11-15 22:10:48 --> Model Class Initialized
INFO - 2016-11-15 22:10:48 --> Model Class Initialized
INFO - 2016-11-15 22:10:48 --> Model Class Initialized
INFO - 2016-11-15 22:10:48 --> Model Class Initialized
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:10:48 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:10:48 --> Final output sent to browser
DEBUG - 2016-11-15 22:10:48 --> Total execution time: 0.4643
INFO - 2016-11-15 22:10:59 --> Config Class Initialized
INFO - 2016-11-15 22:10:59 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:11:00 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:11:00 --> Utf8 Class Initialized
INFO - 2016-11-15 22:11:00 --> URI Class Initialized
DEBUG - 2016-11-15 22:11:00 --> No URI present. Default controller set.
INFO - 2016-11-15 22:11:00 --> Router Class Initialized
INFO - 2016-11-15 22:11:00 --> Output Class Initialized
INFO - 2016-11-15 22:11:00 --> Security Class Initialized
DEBUG - 2016-11-15 22:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:11:00 --> Input Class Initialized
INFO - 2016-11-15 22:11:00 --> Language Class Initialized
INFO - 2016-11-15 22:11:00 --> Loader Class Initialized
INFO - 2016-11-15 22:11:00 --> Helper loaded: url_helper
INFO - 2016-11-15 22:11:00 --> Helper loaded: form_helper
INFO - 2016-11-15 22:11:00 --> Database Driver Class Initialized
INFO - 2016-11-15 22:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:11:00 --> Controller Class Initialized
INFO - 2016-11-15 22:11:00 --> Model Class Initialized
INFO - 2016-11-15 22:11:00 --> Model Class Initialized
INFO - 2016-11-15 22:11:00 --> Model Class Initialized
INFO - 2016-11-15 22:11:00 --> Model Class Initialized
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:11:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:11:00 --> Final output sent to browser
DEBUG - 2016-11-15 22:11:00 --> Total execution time: 0.4577
INFO - 2016-11-15 22:11:18 --> Config Class Initialized
INFO - 2016-11-15 22:11:18 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:11:18 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:11:18 --> Utf8 Class Initialized
INFO - 2016-11-15 22:11:18 --> URI Class Initialized
DEBUG - 2016-11-15 22:11:18 --> No URI present. Default controller set.
INFO - 2016-11-15 22:11:18 --> Router Class Initialized
INFO - 2016-11-15 22:11:18 --> Output Class Initialized
INFO - 2016-11-15 22:11:18 --> Security Class Initialized
DEBUG - 2016-11-15 22:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:11:18 --> Input Class Initialized
INFO - 2016-11-15 22:11:18 --> Language Class Initialized
INFO - 2016-11-15 22:11:18 --> Loader Class Initialized
INFO - 2016-11-15 22:11:18 --> Helper loaded: url_helper
INFO - 2016-11-15 22:11:18 --> Helper loaded: form_helper
INFO - 2016-11-15 22:11:18 --> Database Driver Class Initialized
INFO - 2016-11-15 22:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:11:18 --> Controller Class Initialized
INFO - 2016-11-15 22:11:18 --> Model Class Initialized
INFO - 2016-11-15 22:11:18 --> Model Class Initialized
INFO - 2016-11-15 22:11:18 --> Model Class Initialized
INFO - 2016-11-15 22:11:18 --> Model Class Initialized
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:11:18 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:11:18 --> Final output sent to browser
DEBUG - 2016-11-15 22:11:18 --> Total execution time: 0.5002
INFO - 2016-11-15 22:11:41 --> Config Class Initialized
INFO - 2016-11-15 22:11:42 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:11:42 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:11:42 --> Utf8 Class Initialized
INFO - 2016-11-15 22:11:42 --> URI Class Initialized
INFO - 2016-11-15 22:11:42 --> Router Class Initialized
INFO - 2016-11-15 22:11:42 --> Output Class Initialized
INFO - 2016-11-15 22:11:42 --> Security Class Initialized
DEBUG - 2016-11-15 22:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:11:42 --> Input Class Initialized
INFO - 2016-11-15 22:11:42 --> Language Class Initialized
INFO - 2016-11-15 22:11:42 --> Loader Class Initialized
INFO - 2016-11-15 22:11:42 --> Helper loaded: url_helper
INFO - 2016-11-15 22:11:42 --> Helper loaded: form_helper
INFO - 2016-11-15 22:11:42 --> Database Driver Class Initialized
INFO - 2016-11-15 22:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:11:42 --> Controller Class Initialized
INFO - 2016-11-15 22:11:42 --> Model Class Initialized
INFO - 2016-11-15 22:11:42 --> Form Validation Class Initialized
INFO - 2016-11-15 22:11:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:11:42 --> Final output sent to browser
DEBUG - 2016-11-15 22:11:42 --> Total execution time: 0.4133
INFO - 2016-11-15 22:11:55 --> Config Class Initialized
INFO - 2016-11-15 22:11:55 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:11:55 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:11:55 --> Utf8 Class Initialized
INFO - 2016-11-15 22:11:55 --> URI Class Initialized
INFO - 2016-11-15 22:11:55 --> Router Class Initialized
INFO - 2016-11-15 22:11:55 --> Output Class Initialized
INFO - 2016-11-15 22:11:55 --> Security Class Initialized
DEBUG - 2016-11-15 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:11:55 --> Input Class Initialized
INFO - 2016-11-15 22:11:55 --> Language Class Initialized
INFO - 2016-11-15 22:11:55 --> Loader Class Initialized
INFO - 2016-11-15 22:11:55 --> Helper loaded: url_helper
INFO - 2016-11-15 22:11:55 --> Helper loaded: form_helper
INFO - 2016-11-15 22:11:55 --> Database Driver Class Initialized
INFO - 2016-11-15 22:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:11:55 --> Controller Class Initialized
INFO - 2016-11-15 22:11:55 --> Model Class Initialized
INFO - 2016-11-15 22:11:55 --> Form Validation Class Initialized
INFO - 2016-11-15 22:11:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:11:55 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:11:56 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-03', '2016-11-05', '3', '2', '2016-11-15 22:11:55', '1', '')
INFO - 2016-11-15 22:11:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:12:47 --> Config Class Initialized
INFO - 2016-11-15 22:12:47 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:12:47 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:12:47 --> Utf8 Class Initialized
INFO - 2016-11-15 22:12:48 --> URI Class Initialized
DEBUG - 2016-11-15 22:12:48 --> No URI present. Default controller set.
INFO - 2016-11-15 22:12:48 --> Router Class Initialized
INFO - 2016-11-15 22:12:48 --> Output Class Initialized
INFO - 2016-11-15 22:12:48 --> Security Class Initialized
DEBUG - 2016-11-15 22:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:12:48 --> Input Class Initialized
INFO - 2016-11-15 22:12:48 --> Language Class Initialized
INFO - 2016-11-15 22:12:48 --> Loader Class Initialized
INFO - 2016-11-15 22:12:48 --> Helper loaded: url_helper
INFO - 2016-11-15 22:12:48 --> Helper loaded: form_helper
INFO - 2016-11-15 22:12:49 --> Database Driver Class Initialized
INFO - 2016-11-15 22:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:12:49 --> Controller Class Initialized
INFO - 2016-11-15 22:12:49 --> Model Class Initialized
INFO - 2016-11-15 22:12:49 --> Model Class Initialized
INFO - 2016-11-15 22:12:49 --> Model Class Initialized
INFO - 2016-11-15 22:12:49 --> Model Class Initialized
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:12:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:12:50 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:12:50 --> Final output sent to browser
DEBUG - 2016-11-15 22:12:50 --> Total execution time: 2.5877
INFO - 2016-11-15 22:13:35 --> Config Class Initialized
INFO - 2016-11-15 22:13:35 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:13:35 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:13:35 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:35 --> URI Class Initialized
DEBUG - 2016-11-15 22:13:35 --> No URI present. Default controller set.
INFO - 2016-11-15 22:13:35 --> Router Class Initialized
INFO - 2016-11-15 22:13:35 --> Output Class Initialized
INFO - 2016-11-15 22:13:35 --> Security Class Initialized
DEBUG - 2016-11-15 22:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:35 --> Input Class Initialized
INFO - 2016-11-15 22:13:35 --> Language Class Initialized
INFO - 2016-11-15 22:13:35 --> Loader Class Initialized
INFO - 2016-11-15 22:13:35 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:35 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:35 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:35 --> Controller Class Initialized
INFO - 2016-11-15 22:13:35 --> Model Class Initialized
INFO - 2016-11-15 22:13:35 --> Model Class Initialized
INFO - 2016-11-15 22:13:35 --> Model Class Initialized
INFO - 2016-11-15 22:13:35 --> Model Class Initialized
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:13:35 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:13:35 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:35 --> Total execution time: 0.4262
INFO - 2016-11-15 22:13:50 --> Config Class Initialized
INFO - 2016-11-15 22:13:50 --> Config Class Initialized
INFO - 2016-11-15 22:13:50 --> Config Class Initialized
INFO - 2016-11-15 22:13:50 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:50 --> Config Class Initialized
INFO - 2016-11-15 22:13:50 --> Config Class Initialized
INFO - 2016-11-15 22:13:50 --> Config Class Initialized
INFO - 2016-11-15 22:13:50 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:50 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:50 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:50 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:50 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:13:50 --> UTF-8 Support Enabled
DEBUG - 2016-11-15 22:13:50 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:13:50 --> Utf8 Class Initialized
DEBUG - 2016-11-15 22:13:50 --> UTF-8 Support Enabled
DEBUG - 2016-11-15 22:13:50 --> UTF-8 Support Enabled
DEBUG - 2016-11-15 22:13:50 --> UTF-8 Support Enabled
DEBUG - 2016-11-15 22:13:50 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:13:50 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:50 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:50 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:50 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:50 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:50 --> URI Class Initialized
INFO - 2016-11-15 22:13:50 --> URI Class Initialized
INFO - 2016-11-15 22:13:50 --> URI Class Initialized
INFO - 2016-11-15 22:13:50 --> URI Class Initialized
INFO - 2016-11-15 22:13:50 --> URI Class Initialized
INFO - 2016-11-15 22:13:50 --> URI Class Initialized
INFO - 2016-11-15 22:13:50 --> Router Class Initialized
INFO - 2016-11-15 22:13:50 --> Router Class Initialized
INFO - 2016-11-15 22:13:50 --> Router Class Initialized
INFO - 2016-11-15 22:13:50 --> Router Class Initialized
INFO - 2016-11-15 22:13:50 --> Router Class Initialized
INFO - 2016-11-15 22:13:50 --> Router Class Initialized
INFO - 2016-11-15 22:13:50 --> Output Class Initialized
INFO - 2016-11-15 22:13:50 --> Output Class Initialized
INFO - 2016-11-15 22:13:50 --> Output Class Initialized
INFO - 2016-11-15 22:13:50 --> Output Class Initialized
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
INFO - 2016-11-15 22:13:51 --> Output Class Initialized
INFO - 2016-11-15 22:13:51 --> Output Class Initialized
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:51 --> Controller Class Initialized
INFO - 2016-11-15 22:13:51 --> Model Class Initialized
INFO - 2016-11-15 22:13:51 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:51 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:51 --> Total execution time: 0.4420
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:51 --> Config Class Initialized
INFO - 2016-11-15 22:13:51 --> Controller Class Initialized
INFO - 2016-11-15 22:13:51 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:51 --> Model Class Initialized
DEBUG - 2016-11-15 22:13:51 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:13:51 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:51 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:51 --> URI Class Initialized
INFO - 2016-11-15 22:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:51 --> Router Class Initialized
INFO - 2016-11-15 22:13:51 --> Final output sent to browser
INFO - 2016-11-15 22:13:51 --> Output Class Initialized
DEBUG - 2016-11-15 22:13:51 --> Total execution time: 0.6016
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
INFO - 2016-11-15 22:13:51 --> Config Class Initialized
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:51 --> Hooks Class Initialized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Controller Class Initialized
DEBUG - 2016-11-15 22:13:51 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:51 --> Model Class Initialized
INFO - 2016-11-15 22:13:51 --> URI Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:51 --> Router Class Initialized
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:51 --> Output Class Initialized
INFO - 2016-11-15 22:13:51 --> Final output sent to browser
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
DEBUG - 2016-11-15 22:13:51 --> Total execution time: 0.7709
INFO - 2016-11-15 22:13:51 --> Security Class Initialized
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-11-15 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:51 --> Controller Class Initialized
INFO - 2016-11-15 22:13:51 --> Input Class Initialized
INFO - 2016-11-15 22:13:51 --> Model Class Initialized
INFO - 2016-11-15 22:13:51 --> Language Class Initialized
INFO - 2016-11-15 22:13:51 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:51 --> Loader Class Initialized
INFO - 2016-11-15 22:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:51 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:51 --> Final output sent to browser
INFO - 2016-11-15 22:13:51 --> Helper loaded: form_helper
DEBUG - 2016-11-15 22:13:51 --> Total execution time: 0.9217
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:51 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:51 --> Controller Class Initialized
INFO - 2016-11-15 22:13:51 --> Model Class Initialized
INFO - 2016-11-15 22:13:51 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:51 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:51 --> Total execution time: 0.9994
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:51 --> Controller Class Initialized
INFO - 2016-11-15 22:13:51 --> Model Class Initialized
INFO - 2016-11-15 22:13:51 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:51 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:51 --> Total execution time: 1.0869
INFO - 2016-11-15 22:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:52 --> Controller Class Initialized
INFO - 2016-11-15 22:13:52 --> Model Class Initialized
INFO - 2016-11-15 22:13:52 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:52 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:52 --> Total execution time: 0.7212
INFO - 2016-11-15 22:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:52 --> Controller Class Initialized
INFO - 2016-11-15 22:13:52 --> Model Class Initialized
INFO - 2016-11-15 22:13:52 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:52 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:52 --> Total execution time: 0.6050
INFO - 2016-11-15 22:13:58 --> Config Class Initialized
INFO - 2016-11-15 22:13:58 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:13:58 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:13:58 --> Utf8 Class Initialized
INFO - 2016-11-15 22:13:58 --> URI Class Initialized
INFO - 2016-11-15 22:13:58 --> Router Class Initialized
INFO - 2016-11-15 22:13:58 --> Output Class Initialized
INFO - 2016-11-15 22:13:58 --> Security Class Initialized
DEBUG - 2016-11-15 22:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:13:58 --> Input Class Initialized
INFO - 2016-11-15 22:13:58 --> Language Class Initialized
INFO - 2016-11-15 22:13:58 --> Loader Class Initialized
INFO - 2016-11-15 22:13:58 --> Helper loaded: url_helper
INFO - 2016-11-15 22:13:58 --> Helper loaded: form_helper
INFO - 2016-11-15 22:13:58 --> Database Driver Class Initialized
INFO - 2016-11-15 22:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:13:58 --> Controller Class Initialized
INFO - 2016-11-15 22:13:58 --> Model Class Initialized
INFO - 2016-11-15 22:13:58 --> Form Validation Class Initialized
INFO - 2016-11-15 22:13:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:13:58 --> Final output sent to browser
DEBUG - 2016-11-15 22:13:58 --> Total execution time: 0.2580
INFO - 2016-11-15 22:14:00 --> Config Class Initialized
INFO - 2016-11-15 22:14:00 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:14:00 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:14:00 --> Utf8 Class Initialized
INFO - 2016-11-15 22:14:00 --> URI Class Initialized
DEBUG - 2016-11-15 22:14:00 --> No URI present. Default controller set.
INFO - 2016-11-15 22:14:00 --> Router Class Initialized
INFO - 2016-11-15 22:14:00 --> Output Class Initialized
INFO - 2016-11-15 22:14:00 --> Security Class Initialized
DEBUG - 2016-11-15 22:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:14:00 --> Input Class Initialized
INFO - 2016-11-15 22:14:00 --> Language Class Initialized
INFO - 2016-11-15 22:14:00 --> Loader Class Initialized
INFO - 2016-11-15 22:14:00 --> Helper loaded: url_helper
INFO - 2016-11-15 22:14:00 --> Helper loaded: form_helper
INFO - 2016-11-15 22:14:00 --> Database Driver Class Initialized
INFO - 2016-11-15 22:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:14:00 --> Controller Class Initialized
INFO - 2016-11-15 22:14:00 --> Model Class Initialized
INFO - 2016-11-15 22:14:00 --> Model Class Initialized
INFO - 2016-11-15 22:14:00 --> Model Class Initialized
INFO - 2016-11-15 22:14:00 --> Model Class Initialized
INFO - 2016-11-15 22:14:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:14:00 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:14:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:14:01 --> Final output sent to browser
DEBUG - 2016-11-15 22:14:01 --> Total execution time: 0.4578
INFO - 2016-11-15 22:14:09 --> Config Class Initialized
INFO - 2016-11-15 22:14:09 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:14:09 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:14:09 --> Utf8 Class Initialized
INFO - 2016-11-15 22:14:09 --> URI Class Initialized
INFO - 2016-11-15 22:14:09 --> Router Class Initialized
INFO - 2016-11-15 22:14:09 --> Output Class Initialized
INFO - 2016-11-15 22:14:09 --> Security Class Initialized
DEBUG - 2016-11-15 22:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:14:09 --> Input Class Initialized
INFO - 2016-11-15 22:14:09 --> Language Class Initialized
INFO - 2016-11-15 22:14:09 --> Loader Class Initialized
INFO - 2016-11-15 22:14:09 --> Helper loaded: url_helper
INFO - 2016-11-15 22:14:09 --> Helper loaded: form_helper
INFO - 2016-11-15 22:14:09 --> Database Driver Class Initialized
INFO - 2016-11-15 22:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:14:09 --> Controller Class Initialized
INFO - 2016-11-15 22:14:09 --> Model Class Initialized
INFO - 2016-11-15 22:14:09 --> Form Validation Class Initialized
INFO - 2016-11-15 22:14:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:14:09 --> Final output sent to browser
DEBUG - 2016-11-15 22:14:09 --> Total execution time: 0.2573
INFO - 2016-11-15 22:14:11 --> Config Class Initialized
INFO - 2016-11-15 22:14:11 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:14:11 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:14:11 --> Utf8 Class Initialized
INFO - 2016-11-15 22:14:11 --> URI Class Initialized
DEBUG - 2016-11-15 22:14:11 --> No URI present. Default controller set.
INFO - 2016-11-15 22:14:11 --> Router Class Initialized
INFO - 2016-11-15 22:14:11 --> Output Class Initialized
INFO - 2016-11-15 22:14:11 --> Security Class Initialized
DEBUG - 2016-11-15 22:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:14:11 --> Input Class Initialized
INFO - 2016-11-15 22:14:11 --> Language Class Initialized
INFO - 2016-11-15 22:14:11 --> Loader Class Initialized
INFO - 2016-11-15 22:14:11 --> Helper loaded: url_helper
INFO - 2016-11-15 22:14:11 --> Helper loaded: form_helper
INFO - 2016-11-15 22:14:11 --> Database Driver Class Initialized
INFO - 2016-11-15 22:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:14:11 --> Controller Class Initialized
INFO - 2016-11-15 22:14:11 --> Model Class Initialized
INFO - 2016-11-15 22:14:11 --> Model Class Initialized
INFO - 2016-11-15 22:14:11 --> Model Class Initialized
INFO - 2016-11-15 22:14:11 --> Model Class Initialized
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:14:11 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:14:11 --> Final output sent to browser
DEBUG - 2016-11-15 22:14:11 --> Total execution time: 0.5483
INFO - 2016-11-15 22:14:15 --> Config Class Initialized
INFO - 2016-11-15 22:14:15 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:14:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:14:15 --> Utf8 Class Initialized
INFO - 2016-11-15 22:14:15 --> URI Class Initialized
INFO - 2016-11-15 22:14:15 --> Router Class Initialized
INFO - 2016-11-15 22:14:15 --> Output Class Initialized
INFO - 2016-11-15 22:14:15 --> Security Class Initialized
DEBUG - 2016-11-15 22:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:14:15 --> Input Class Initialized
INFO - 2016-11-15 22:14:15 --> Language Class Initialized
INFO - 2016-11-15 22:14:15 --> Loader Class Initialized
INFO - 2016-11-15 22:14:15 --> Helper loaded: url_helper
INFO - 2016-11-15 22:14:15 --> Helper loaded: form_helper
INFO - 2016-11-15 22:14:15 --> Database Driver Class Initialized
INFO - 2016-11-15 22:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:14:15 --> Controller Class Initialized
INFO - 2016-11-15 22:14:15 --> Model Class Initialized
INFO - 2016-11-15 22:14:15 --> Form Validation Class Initialized
INFO - 2016-11-15 22:14:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:14:15 --> Final output sent to browser
DEBUG - 2016-11-15 22:14:15 --> Total execution time: 0.2414
INFO - 2016-11-15 22:14:31 --> Config Class Initialized
INFO - 2016-11-15 22:14:31 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:14:31 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:14:31 --> Utf8 Class Initialized
INFO - 2016-11-15 22:14:31 --> URI Class Initialized
INFO - 2016-11-15 22:14:31 --> Router Class Initialized
INFO - 2016-11-15 22:14:31 --> Output Class Initialized
INFO - 2016-11-15 22:14:31 --> Security Class Initialized
DEBUG - 2016-11-15 22:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:14:31 --> Input Class Initialized
INFO - 2016-11-15 22:14:31 --> Language Class Initialized
INFO - 2016-11-15 22:14:31 --> Loader Class Initialized
INFO - 2016-11-15 22:14:31 --> Helper loaded: url_helper
INFO - 2016-11-15 22:14:31 --> Helper loaded: form_helper
INFO - 2016-11-15 22:14:31 --> Database Driver Class Initialized
INFO - 2016-11-15 22:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:14:31 --> Controller Class Initialized
INFO - 2016-11-15 22:14:31 --> Model Class Initialized
INFO - 2016-11-15 22:14:31 --> Form Validation Class Initialized
INFO - 2016-11-15 22:14:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:14:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-16', '2016-11-18', '3', '3', '2016-11-15 22:14:31', '1', '')
INFO - 2016-11-15 22:14:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:16:24 --> Config Class Initialized
INFO - 2016-11-15 22:16:24 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:16:24 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:16:24 --> Utf8 Class Initialized
INFO - 2016-11-15 22:16:24 --> URI Class Initialized
DEBUG - 2016-11-15 22:16:25 --> No URI present. Default controller set.
INFO - 2016-11-15 22:16:25 --> Router Class Initialized
INFO - 2016-11-15 22:16:25 --> Output Class Initialized
INFO - 2016-11-15 22:16:25 --> Security Class Initialized
DEBUG - 2016-11-15 22:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:16:25 --> Input Class Initialized
INFO - 2016-11-15 22:16:25 --> Language Class Initialized
INFO - 2016-11-15 22:16:25 --> Loader Class Initialized
INFO - 2016-11-15 22:16:25 --> Helper loaded: url_helper
INFO - 2016-11-15 22:16:25 --> Helper loaded: form_helper
INFO - 2016-11-15 22:16:25 --> Database Driver Class Initialized
INFO - 2016-11-15 22:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:16:25 --> Controller Class Initialized
INFO - 2016-11-15 22:16:25 --> Model Class Initialized
INFO - 2016-11-15 22:16:25 --> Model Class Initialized
INFO - 2016-11-15 22:16:25 --> Model Class Initialized
INFO - 2016-11-15 22:16:25 --> Model Class Initialized
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:16:25 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:16:25 --> Final output sent to browser
DEBUG - 2016-11-15 22:16:25 --> Total execution time: 0.6300
INFO - 2016-11-15 22:16:36 --> Config Class Initialized
INFO - 2016-11-15 22:16:36 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:16:36 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:16:36 --> Utf8 Class Initialized
INFO - 2016-11-15 22:16:36 --> URI Class Initialized
DEBUG - 2016-11-15 22:16:36 --> No URI present. Default controller set.
INFO - 2016-11-15 22:16:36 --> Router Class Initialized
INFO - 2016-11-15 22:16:36 --> Output Class Initialized
INFO - 2016-11-15 22:16:36 --> Security Class Initialized
DEBUG - 2016-11-15 22:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:16:36 --> Input Class Initialized
INFO - 2016-11-15 22:16:36 --> Language Class Initialized
INFO - 2016-11-15 22:16:36 --> Loader Class Initialized
INFO - 2016-11-15 22:16:36 --> Helper loaded: url_helper
INFO - 2016-11-15 22:16:36 --> Helper loaded: form_helper
INFO - 2016-11-15 22:16:36 --> Database Driver Class Initialized
INFO - 2016-11-15 22:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:16:36 --> Controller Class Initialized
INFO - 2016-11-15 22:16:36 --> Model Class Initialized
INFO - 2016-11-15 22:16:36 --> Model Class Initialized
INFO - 2016-11-15 22:16:36 --> Model Class Initialized
INFO - 2016-11-15 22:16:36 --> Model Class Initialized
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:16:36 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:16:36 --> Final output sent to browser
DEBUG - 2016-11-15 22:16:36 --> Total execution time: 0.4728
INFO - 2016-11-15 22:16:46 --> Config Class Initialized
INFO - 2016-11-15 22:16:46 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:16:46 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:16:46 --> Utf8 Class Initialized
INFO - 2016-11-15 22:16:46 --> URI Class Initialized
INFO - 2016-11-15 22:16:46 --> Router Class Initialized
INFO - 2016-11-15 22:16:46 --> Output Class Initialized
INFO - 2016-11-15 22:16:46 --> Security Class Initialized
DEBUG - 2016-11-15 22:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:16:46 --> Input Class Initialized
INFO - 2016-11-15 22:16:46 --> Language Class Initialized
INFO - 2016-11-15 22:16:46 --> Loader Class Initialized
INFO - 2016-11-15 22:16:46 --> Helper loaded: url_helper
INFO - 2016-11-15 22:16:46 --> Helper loaded: form_helper
INFO - 2016-11-15 22:16:46 --> Database Driver Class Initialized
INFO - 2016-11-15 22:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:16:46 --> Controller Class Initialized
INFO - 2016-11-15 22:16:46 --> Model Class Initialized
INFO - 2016-11-15 22:16:46 --> Form Validation Class Initialized
INFO - 2016-11-15 22:16:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:16:46 --> Final output sent to browser
DEBUG - 2016-11-15 22:16:46 --> Total execution time: 0.2494
INFO - 2016-11-15 22:16:59 --> Config Class Initialized
INFO - 2016-11-15 22:16:59 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:16:59 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:16:59 --> Utf8 Class Initialized
INFO - 2016-11-15 22:16:59 --> URI Class Initialized
INFO - 2016-11-15 22:16:59 --> Router Class Initialized
INFO - 2016-11-15 22:16:59 --> Output Class Initialized
INFO - 2016-11-15 22:16:59 --> Security Class Initialized
DEBUG - 2016-11-15 22:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:16:59 --> Input Class Initialized
INFO - 2016-11-15 22:16:59 --> Language Class Initialized
INFO - 2016-11-15 22:16:59 --> Loader Class Initialized
INFO - 2016-11-15 22:16:59 --> Helper loaded: url_helper
INFO - 2016-11-15 22:16:59 --> Helper loaded: form_helper
INFO - 2016-11-15 22:16:59 --> Database Driver Class Initialized
INFO - 2016-11-15 22:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:16:59 --> Controller Class Initialized
INFO - 2016-11-15 22:16:59 --> Model Class Initialized
INFO - 2016-11-15 22:16:59 --> Form Validation Class Initialized
INFO - 2016-11-15 22:16:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:16:59 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:16:59 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-10', '3', '2', '2016-11-15 22:16:59', '1', '')
INFO - 2016-11-15 22:16:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:17:01 --> Config Class Initialized
INFO - 2016-11-15 22:17:01 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:17:01 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:17:01 --> Utf8 Class Initialized
INFO - 2016-11-15 22:17:01 --> URI Class Initialized
INFO - 2016-11-15 22:17:01 --> Router Class Initialized
INFO - 2016-11-15 22:17:01 --> Output Class Initialized
INFO - 2016-11-15 22:17:01 --> Security Class Initialized
DEBUG - 2016-11-15 22:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:17:01 --> Input Class Initialized
INFO - 2016-11-15 22:17:01 --> Language Class Initialized
INFO - 2016-11-15 22:17:01 --> Loader Class Initialized
INFO - 2016-11-15 22:17:01 --> Helper loaded: url_helper
INFO - 2016-11-15 22:17:01 --> Helper loaded: form_helper
INFO - 2016-11-15 22:17:01 --> Database Driver Class Initialized
INFO - 2016-11-15 22:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:17:01 --> Controller Class Initialized
INFO - 2016-11-15 22:17:01 --> Model Class Initialized
INFO - 2016-11-15 22:17:01 --> Form Validation Class Initialized
INFO - 2016-11-15 22:17:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:17:01 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:17:01 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-10', '2016-11-10', '3', '2', '2016-11-15 22:17:01', '1', '')
INFO - 2016-11-15 22:17:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:19:11 --> Config Class Initialized
INFO - 2016-11-15 22:19:11 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:19:11 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:19:11 --> Utf8 Class Initialized
INFO - 2016-11-15 22:19:12 --> URI Class Initialized
DEBUG - 2016-11-15 22:19:12 --> No URI present. Default controller set.
INFO - 2016-11-15 22:19:12 --> Router Class Initialized
INFO - 2016-11-15 22:19:12 --> Output Class Initialized
INFO - 2016-11-15 22:19:12 --> Security Class Initialized
DEBUG - 2016-11-15 22:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:19:12 --> Input Class Initialized
INFO - 2016-11-15 22:19:12 --> Language Class Initialized
INFO - 2016-11-15 22:19:12 --> Loader Class Initialized
INFO - 2016-11-15 22:19:12 --> Helper loaded: url_helper
INFO - 2016-11-15 22:19:12 --> Helper loaded: form_helper
INFO - 2016-11-15 22:19:12 --> Database Driver Class Initialized
INFO - 2016-11-15 22:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:19:12 --> Controller Class Initialized
INFO - 2016-11-15 22:19:12 --> Model Class Initialized
INFO - 2016-11-15 22:19:12 --> Model Class Initialized
INFO - 2016-11-15 22:19:12 --> Model Class Initialized
INFO - 2016-11-15 22:19:12 --> Model Class Initialized
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:19:12 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:19:12 --> Final output sent to browser
DEBUG - 2016-11-15 22:19:12 --> Total execution time: 0.4491
INFO - 2016-11-15 22:19:20 --> Config Class Initialized
INFO - 2016-11-15 22:19:20 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:19:20 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:19:20 --> Utf8 Class Initialized
INFO - 2016-11-15 22:19:20 --> URI Class Initialized
INFO - 2016-11-15 22:19:20 --> Router Class Initialized
INFO - 2016-11-15 22:19:20 --> Output Class Initialized
INFO - 2016-11-15 22:19:20 --> Security Class Initialized
DEBUG - 2016-11-15 22:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:19:20 --> Input Class Initialized
INFO - 2016-11-15 22:19:20 --> Language Class Initialized
INFO - 2016-11-15 22:19:20 --> Loader Class Initialized
INFO - 2016-11-15 22:19:20 --> Helper loaded: url_helper
INFO - 2016-11-15 22:19:20 --> Helper loaded: form_helper
INFO - 2016-11-15 22:19:20 --> Database Driver Class Initialized
INFO - 2016-11-15 22:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:19:20 --> Controller Class Initialized
INFO - 2016-11-15 22:19:20 --> Model Class Initialized
INFO - 2016-11-15 22:19:20 --> Form Validation Class Initialized
INFO - 2016-11-15 22:19:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:19:20 --> Final output sent to browser
DEBUG - 2016-11-15 22:19:20 --> Total execution time: 0.2511
INFO - 2016-11-15 22:19:38 --> Config Class Initialized
INFO - 2016-11-15 22:19:38 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:19:38 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:19:38 --> Utf8 Class Initialized
INFO - 2016-11-15 22:19:38 --> URI Class Initialized
INFO - 2016-11-15 22:19:38 --> Router Class Initialized
INFO - 2016-11-15 22:19:38 --> Output Class Initialized
INFO - 2016-11-15 22:19:38 --> Security Class Initialized
DEBUG - 2016-11-15 22:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:19:38 --> Input Class Initialized
INFO - 2016-11-15 22:19:38 --> Language Class Initialized
INFO - 2016-11-15 22:19:38 --> Loader Class Initialized
INFO - 2016-11-15 22:19:38 --> Helper loaded: url_helper
INFO - 2016-11-15 22:19:38 --> Helper loaded: form_helper
INFO - 2016-11-15 22:19:39 --> Database Driver Class Initialized
INFO - 2016-11-15 22:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:19:39 --> Controller Class Initialized
INFO - 2016-11-15 22:19:39 --> Model Class Initialized
INFO - 2016-11-15 22:19:39 --> Form Validation Class Initialized
INFO - 2016-11-15 22:19:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:19:39 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:19:39 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-03', '2016-11-04', '4', '2', '2016-11-15 22:19:39', '1', '')
INFO - 2016-11-15 22:19:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:19:41 --> Config Class Initialized
INFO - 2016-11-15 22:19:41 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:19:41 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:19:41 --> Utf8 Class Initialized
INFO - 2016-11-15 22:19:41 --> URI Class Initialized
INFO - 2016-11-15 22:19:41 --> Router Class Initialized
INFO - 2016-11-15 22:19:41 --> Output Class Initialized
INFO - 2016-11-15 22:19:41 --> Security Class Initialized
DEBUG - 2016-11-15 22:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:19:41 --> Input Class Initialized
INFO - 2016-11-15 22:19:41 --> Language Class Initialized
INFO - 2016-11-15 22:19:41 --> Loader Class Initialized
INFO - 2016-11-15 22:19:41 --> Helper loaded: url_helper
INFO - 2016-11-15 22:19:41 --> Helper loaded: form_helper
INFO - 2016-11-15 22:19:41 --> Database Driver Class Initialized
INFO - 2016-11-15 22:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:19:41 --> Controller Class Initialized
INFO - 2016-11-15 22:19:41 --> Model Class Initialized
INFO - 2016-11-15 22:19:41 --> Form Validation Class Initialized
INFO - 2016-11-15 22:19:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:19:42 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
INFO - 2016-11-15 22:19:42 --> Config Class Initialized
INFO - 2016-11-15 22:19:42 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:19:42 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:19:42 --> Utf8 Class Initialized
INFO - 2016-11-15 22:19:42 --> URI Class Initialized
INFO - 2016-11-15 22:19:42 --> Router Class Initialized
INFO - 2016-11-15 22:19:42 --> Output Class Initialized
INFO - 2016-11-15 22:19:42 --> Security Class Initialized
DEBUG - 2016-11-15 22:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:19:42 --> Input Class Initialized
ERROR - 2016-11-15 22:19:42 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-03', '2016-11-04', '4', '2', '2016-11-15 22:19:42', '1', '')
INFO - 2016-11-15 22:19:42 --> Language Class Initialized
INFO - 2016-11-15 22:19:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:19:42 --> Loader Class Initialized
INFO - 2016-11-15 22:19:42 --> Helper loaded: url_helper
INFO - 2016-11-15 22:19:42 --> Helper loaded: form_helper
INFO - 2016-11-15 22:19:42 --> Database Driver Class Initialized
INFO - 2016-11-15 22:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:19:42 --> Controller Class Initialized
INFO - 2016-11-15 22:19:42 --> Model Class Initialized
INFO - 2016-11-15 22:19:42 --> Form Validation Class Initialized
INFO - 2016-11-15 22:19:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:19:42 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\LMS\app\controllers\Leave_application_c.php 81
ERROR - 2016-11-15 22:19:42 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lms`.`applicationdata`, CONSTRAINT `applicationdata_ibfk_2` FOREIGN KEY (`idEmployee`) REFERENCES `employee` (`id`)) - Invalid query: INSERT INTO `applicationData` (`startDate`, `endDate`, `numberOfDays`, `idLeaveType`, `applicationDate`, `idEmployee`, `leavePurpose`) VALUES ('2016-11-03', '2016-11-04', '4', '2', '2016-11-15 22:19:42', '1', '')
INFO - 2016-11-15 22:19:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:20:05 --> Config Class Initialized
INFO - 2016-11-15 22:20:05 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:20:05 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:20:05 --> Utf8 Class Initialized
INFO - 2016-11-15 22:20:05 --> URI Class Initialized
DEBUG - 2016-11-15 22:20:05 --> No URI present. Default controller set.
INFO - 2016-11-15 22:20:05 --> Router Class Initialized
INFO - 2016-11-15 22:20:05 --> Output Class Initialized
INFO - 2016-11-15 22:20:05 --> Security Class Initialized
DEBUG - 2016-11-15 22:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:20:05 --> Input Class Initialized
INFO - 2016-11-15 22:20:05 --> Language Class Initialized
INFO - 2016-11-15 22:20:05 --> Loader Class Initialized
INFO - 2016-11-15 22:20:05 --> Helper loaded: url_helper
INFO - 2016-11-15 22:20:05 --> Helper loaded: form_helper
INFO - 2016-11-15 22:20:05 --> Database Driver Class Initialized
INFO - 2016-11-15 22:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:20:05 --> Controller Class Initialized
INFO - 2016-11-15 22:20:05 --> Model Class Initialized
INFO - 2016-11-15 22:20:05 --> Model Class Initialized
INFO - 2016-11-15 22:20:05 --> Model Class Initialized
INFO - 2016-11-15 22:20:05 --> Model Class Initialized
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:20:05 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:20:06 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:20:06 --> Final output sent to browser
DEBUG - 2016-11-15 22:20:06 --> Total execution time: 0.4709
INFO - 2016-11-15 22:20:29 --> Config Class Initialized
INFO - 2016-11-15 22:20:29 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:20:29 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:20:29 --> Utf8 Class Initialized
INFO - 2016-11-15 22:20:29 --> URI Class Initialized
INFO - 2016-11-15 22:20:29 --> Router Class Initialized
INFO - 2016-11-15 22:20:29 --> Output Class Initialized
INFO - 2016-11-15 22:20:29 --> Security Class Initialized
DEBUG - 2016-11-15 22:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:20:29 --> Input Class Initialized
INFO - 2016-11-15 22:20:29 --> Language Class Initialized
INFO - 2016-11-15 22:20:29 --> Loader Class Initialized
INFO - 2016-11-15 22:20:29 --> Helper loaded: url_helper
INFO - 2016-11-15 22:20:29 --> Helper loaded: form_helper
INFO - 2016-11-15 22:20:29 --> Database Driver Class Initialized
INFO - 2016-11-15 22:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:20:29 --> Controller Class Initialized
INFO - 2016-11-15 22:20:29 --> Model Class Initialized
INFO - 2016-11-15 22:20:29 --> Form Validation Class Initialized
INFO - 2016-11-15 22:20:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-11-15 22:20:29 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:20:29 --> Final output sent to browser
DEBUG - 2016-11-15 22:20:29 --> Total execution time: 0.3651
INFO - 2016-11-15 22:20:37 --> Config Class Initialized
INFO - 2016-11-15 22:20:37 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:20:37 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:20:37 --> Utf8 Class Initialized
INFO - 2016-11-15 22:20:37 --> URI Class Initialized
DEBUG - 2016-11-15 22:20:37 --> No URI present. Default controller set.
INFO - 2016-11-15 22:20:37 --> Router Class Initialized
INFO - 2016-11-15 22:20:37 --> Output Class Initialized
INFO - 2016-11-15 22:20:37 --> Security Class Initialized
DEBUG - 2016-11-15 22:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:20:37 --> Input Class Initialized
INFO - 2016-11-15 22:20:37 --> Language Class Initialized
INFO - 2016-11-15 22:20:37 --> Loader Class Initialized
INFO - 2016-11-15 22:20:37 --> Helper loaded: url_helper
INFO - 2016-11-15 22:20:37 --> Helper loaded: form_helper
INFO - 2016-11-15 22:20:37 --> Database Driver Class Initialized
INFO - 2016-11-15 22:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:20:37 --> Controller Class Initialized
INFO - 2016-11-15 22:20:37 --> Model Class Initialized
INFO - 2016-11-15 22:20:37 --> Model Class Initialized
INFO - 2016-11-15 22:20:37 --> Model Class Initialized
INFO - 2016-11-15 22:20:37 --> Model Class Initialized
INFO - 2016-11-15 22:20:37 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:20:38 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:20:38 --> Final output sent to browser
DEBUG - 2016-11-15 22:20:38 --> Total execution time: 0.4777
INFO - 2016-11-15 22:21:45 --> Config Class Initialized
INFO - 2016-11-15 22:21:45 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:21:45 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:21:45 --> Utf8 Class Initialized
INFO - 2016-11-15 22:21:45 --> URI Class Initialized
DEBUG - 2016-11-15 22:21:45 --> No URI present. Default controller set.
INFO - 2016-11-15 22:21:45 --> Router Class Initialized
INFO - 2016-11-15 22:21:45 --> Output Class Initialized
INFO - 2016-11-15 22:21:45 --> Security Class Initialized
DEBUG - 2016-11-15 22:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:21:45 --> Input Class Initialized
INFO - 2016-11-15 22:21:45 --> Language Class Initialized
INFO - 2016-11-15 22:21:45 --> Loader Class Initialized
INFO - 2016-11-15 22:21:45 --> Helper loaded: url_helper
INFO - 2016-11-15 22:21:45 --> Helper loaded: form_helper
INFO - 2016-11-15 22:21:45 --> Database Driver Class Initialized
INFO - 2016-11-15 22:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:21:45 --> Controller Class Initialized
INFO - 2016-11-15 22:21:45 --> Model Class Initialized
INFO - 2016-11-15 22:21:45 --> Model Class Initialized
INFO - 2016-11-15 22:21:45 --> Model Class Initialized
INFO - 2016-11-15 22:21:45 --> Model Class Initialized
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/apply_leave_sidebar.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\employee/my_leave.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_applied.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_records.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/add_leave_record_sidebar.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\manager/leave_records_reports.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:21:45 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:21:45 --> Final output sent to browser
DEBUG - 2016-11-15 22:21:45 --> Total execution time: 0.4723
INFO - 2016-11-15 22:21:48 --> Config Class Initialized
INFO - 2016-11-15 22:21:48 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:21:48 --> Utf8 Class Initialized
INFO - 2016-11-15 22:21:48 --> URI Class Initialized
INFO - 2016-11-15 22:21:48 --> Router Class Initialized
INFO - 2016-11-15 22:21:48 --> Output Class Initialized
INFO - 2016-11-15 22:21:48 --> Security Class Initialized
DEBUG - 2016-11-15 22:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:21:48 --> Input Class Initialized
INFO - 2016-11-15 22:21:48 --> Language Class Initialized
INFO - 2016-11-15 22:21:48 --> Loader Class Initialized
INFO - 2016-11-15 22:21:48 --> Helper loaded: url_helper
INFO - 2016-11-15 22:21:48 --> Helper loaded: form_helper
INFO - 2016-11-15 22:21:48 --> Database Driver Class Initialized
INFO - 2016-11-15 22:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:21:48 --> Controller Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
DEBUG - 2016-11-15 22:21:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-15 22:21:48 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-15 22:21:48 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-15 22:21:48 --> Config Class Initialized
INFO - 2016-11-15 22:21:48 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:21:48 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:21:48 --> Utf8 Class Initialized
INFO - 2016-11-15 22:21:48 --> URI Class Initialized
DEBUG - 2016-11-15 22:21:48 --> No URI present. Default controller set.
INFO - 2016-11-15 22:21:48 --> Router Class Initialized
INFO - 2016-11-15 22:21:48 --> Output Class Initialized
INFO - 2016-11-15 22:21:48 --> Security Class Initialized
DEBUG - 2016-11-15 22:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:21:48 --> Input Class Initialized
INFO - 2016-11-15 22:21:48 --> Language Class Initialized
INFO - 2016-11-15 22:21:48 --> Loader Class Initialized
INFO - 2016-11-15 22:21:48 --> Helper loaded: url_helper
INFO - 2016-11-15 22:21:48 --> Helper loaded: form_helper
INFO - 2016-11-15 22:21:48 --> Database Driver Class Initialized
INFO - 2016-11-15 22:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:21:48 --> Controller Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:48 --> Model Class Initialized
INFO - 2016-11-15 22:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-15 22:21:49 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:21:49 --> Final output sent to browser
DEBUG - 2016-11-15 22:21:49 --> Total execution time: 0.3726
INFO - 2016-11-15 22:22:00 --> Config Class Initialized
INFO - 2016-11-15 22:22:00 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:22:00 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:22:00 --> Utf8 Class Initialized
INFO - 2016-11-15 22:22:00 --> URI Class Initialized
INFO - 2016-11-15 22:22:00 --> Router Class Initialized
INFO - 2016-11-15 22:22:00 --> Output Class Initialized
INFO - 2016-11-15 22:22:00 --> Security Class Initialized
DEBUG - 2016-11-15 22:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:22:00 --> Input Class Initialized
INFO - 2016-11-15 22:22:00 --> Language Class Initialized
INFO - 2016-11-15 22:22:00 --> Loader Class Initialized
INFO - 2016-11-15 22:22:00 --> Helper loaded: url_helper
INFO - 2016-11-15 22:22:00 --> Helper loaded: form_helper
INFO - 2016-11-15 22:22:00 --> Database Driver Class Initialized
INFO - 2016-11-15 22:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:22:00 --> Controller Class Initialized
INFO - 2016-11-15 22:22:00 --> Model Class Initialized
INFO - 2016-11-15 22:22:00 --> Model Class Initialized
INFO - 2016-11-15 22:22:00 --> Model Class Initialized
INFO - 2016-11-15 22:22:00 --> Model Class Initialized
DEBUG - 2016-11-15 22:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-11-15 22:22:00 --> Model Class Initialized
INFO - 2016-11-15 22:22:00 --> Final output sent to browser
DEBUG - 2016-11-15 22:22:00 --> Total execution time: 0.3356
INFO - 2016-11-15 22:22:00 --> Config Class Initialized
INFO - 2016-11-15 22:22:00 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:22:01 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:22:01 --> Utf8 Class Initialized
INFO - 2016-11-15 22:22:01 --> URI Class Initialized
DEBUG - 2016-11-15 22:22:01 --> No URI present. Default controller set.
INFO - 2016-11-15 22:22:01 --> Router Class Initialized
INFO - 2016-11-15 22:22:01 --> Output Class Initialized
INFO - 2016-11-15 22:22:01 --> Security Class Initialized
DEBUG - 2016-11-15 22:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:22:01 --> Input Class Initialized
INFO - 2016-11-15 22:22:01 --> Language Class Initialized
INFO - 2016-11-15 22:22:01 --> Loader Class Initialized
INFO - 2016-11-15 22:22:01 --> Helper loaded: url_helper
INFO - 2016-11-15 22:22:01 --> Helper loaded: form_helper
INFO - 2016-11-15 22:22:01 --> Database Driver Class Initialized
INFO - 2016-11-15 22:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:22:01 --> Controller Class Initialized
INFO - 2016-11-15 22:22:01 --> Model Class Initialized
INFO - 2016-11-15 22:22:01 --> Model Class Initialized
INFO - 2016-11-15 22:22:01 --> Model Class Initialized
INFO - 2016-11-15 22:22:01 --> Model Class Initialized
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:22:01 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:22:01 --> Final output sent to browser
DEBUG - 2016-11-15 22:22:01 --> Total execution time: 0.8278
INFO - 2016-11-15 22:22:40 --> Config Class Initialized
INFO - 2016-11-15 22:22:40 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:22:40 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:22:40 --> Utf8 Class Initialized
INFO - 2016-11-15 22:22:40 --> URI Class Initialized
INFO - 2016-11-15 22:22:40 --> Router Class Initialized
INFO - 2016-11-15 22:22:40 --> Output Class Initialized
INFO - 2016-11-15 22:22:40 --> Security Class Initialized
DEBUG - 2016-11-15 22:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:22:40 --> Input Class Initialized
INFO - 2016-11-15 22:22:40 --> Language Class Initialized
INFO - 2016-11-15 22:22:40 --> Loader Class Initialized
INFO - 2016-11-15 22:22:40 --> Helper loaded: url_helper
INFO - 2016-11-15 22:22:40 --> Helper loaded: form_helper
INFO - 2016-11-15 22:22:40 --> Database Driver Class Initialized
INFO - 2016-11-15 22:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:22:40 --> Controller Class Initialized
INFO - 2016-11-15 22:22:40 --> Model Class Initialized
INFO - 2016-11-15 22:22:40 --> Form Validation Class Initialized
INFO - 2016-11-15 22:22:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:22:40 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '40', 'Normal Leave')
INFO - 2016-11-15 22:22:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:22:52 --> Config Class Initialized
INFO - 2016-11-15 22:22:52 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:22:52 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:22:52 --> Utf8 Class Initialized
INFO - 2016-11-15 22:22:52 --> URI Class Initialized
DEBUG - 2016-11-15 22:22:52 --> No URI present. Default controller set.
INFO - 2016-11-15 22:22:52 --> Router Class Initialized
INFO - 2016-11-15 22:22:52 --> Output Class Initialized
INFO - 2016-11-15 22:22:52 --> Security Class Initialized
DEBUG - 2016-11-15 22:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:22:52 --> Input Class Initialized
INFO - 2016-11-15 22:22:52 --> Language Class Initialized
INFO - 2016-11-15 22:22:52 --> Loader Class Initialized
INFO - 2016-11-15 22:22:52 --> Helper loaded: url_helper
INFO - 2016-11-15 22:22:52 --> Helper loaded: form_helper
INFO - 2016-11-15 22:22:52 --> Database Driver Class Initialized
INFO - 2016-11-15 22:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:22:52 --> Controller Class Initialized
INFO - 2016-11-15 22:22:52 --> Model Class Initialized
INFO - 2016-11-15 22:22:52 --> Model Class Initialized
INFO - 2016-11-15 22:22:52 --> Model Class Initialized
INFO - 2016-11-15 22:22:52 --> Model Class Initialized
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:22:52 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:22:52 --> Final output sent to browser
DEBUG - 2016-11-15 22:22:52 --> Total execution time: 0.4607
INFO - 2016-11-15 22:23:15 --> Config Class Initialized
INFO - 2016-11-15 22:23:15 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:15 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:15 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:15 --> URI Class Initialized
INFO - 2016-11-15 22:23:15 --> Router Class Initialized
INFO - 2016-11-15 22:23:15 --> Output Class Initialized
INFO - 2016-11-15 22:23:15 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:15 --> Input Class Initialized
INFO - 2016-11-15 22:23:15 --> Language Class Initialized
INFO - 2016-11-15 22:23:16 --> Loader Class Initialized
INFO - 2016-11-15 22:23:16 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:16 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:16 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:16 --> Controller Class Initialized
INFO - 2016-11-15 22:23:16 --> Model Class Initialized
INFO - 2016-11-15 22:23:16 --> Form Validation Class Initialized
INFO - 2016-11-15 22:23:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:23:16 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '40', 'Normal Leave')
INFO - 2016-11-15 22:23:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:23:20 --> Config Class Initialized
INFO - 2016-11-15 22:23:20 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:20 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:20 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:20 --> URI Class Initialized
INFO - 2016-11-15 22:23:20 --> Router Class Initialized
INFO - 2016-11-15 22:23:20 --> Output Class Initialized
INFO - 2016-11-15 22:23:20 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:20 --> Input Class Initialized
INFO - 2016-11-15 22:23:20 --> Language Class Initialized
INFO - 2016-11-15 22:23:20 --> Loader Class Initialized
INFO - 2016-11-15 22:23:20 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:20 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:20 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:20 --> Controller Class Initialized
INFO - 2016-11-15 22:23:20 --> Model Class Initialized
INFO - 2016-11-15 22:23:20 --> Form Validation Class Initialized
INFO - 2016-11-15 22:23:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:23:20 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '40', 'Normal Leave')
INFO - 2016-11-15 22:23:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:23:20 --> Config Class Initialized
INFO - 2016-11-15 22:23:20 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:20 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:20 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:20 --> URI Class Initialized
INFO - 2016-11-15 22:23:20 --> Router Class Initialized
INFO - 2016-11-15 22:23:20 --> Output Class Initialized
INFO - 2016-11-15 22:23:20 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:20 --> Input Class Initialized
INFO - 2016-11-15 22:23:20 --> Language Class Initialized
INFO - 2016-11-15 22:23:20 --> Loader Class Initialized
INFO - 2016-11-15 22:23:20 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:20 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:20 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:20 --> Controller Class Initialized
INFO - 2016-11-15 22:23:20 --> Model Class Initialized
INFO - 2016-11-15 22:23:20 --> Form Validation Class Initialized
INFO - 2016-11-15 22:23:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:23:20 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '40', 'Normal Leave')
INFO - 2016-11-15 22:23:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:23:21 --> Config Class Initialized
INFO - 2016-11-15 22:23:21 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:21 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:21 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:21 --> URI Class Initialized
INFO - 2016-11-15 22:23:21 --> Router Class Initialized
INFO - 2016-11-15 22:23:21 --> Output Class Initialized
INFO - 2016-11-15 22:23:21 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:21 --> Input Class Initialized
INFO - 2016-11-15 22:23:21 --> Language Class Initialized
INFO - 2016-11-15 22:23:21 --> Loader Class Initialized
INFO - 2016-11-15 22:23:21 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:21 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:21 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:21 --> Controller Class Initialized
INFO - 2016-11-15 22:23:21 --> Model Class Initialized
INFO - 2016-11-15 22:23:21 --> Form Validation Class Initialized
INFO - 2016-11-15 22:23:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:23:21 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '40', 'Normal Leave')
INFO - 2016-11-15 22:23:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:23:21 --> Config Class Initialized
INFO - 2016-11-15 22:23:21 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:21 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:21 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:21 --> URI Class Initialized
INFO - 2016-11-15 22:23:21 --> Router Class Initialized
INFO - 2016-11-15 22:23:21 --> Output Class Initialized
INFO - 2016-11-15 22:23:21 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:21 --> Input Class Initialized
INFO - 2016-11-15 22:23:21 --> Language Class Initialized
INFO - 2016-11-15 22:23:21 --> Loader Class Initialized
INFO - 2016-11-15 22:23:21 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:21 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:21 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:21 --> Controller Class Initialized
INFO - 2016-11-15 22:23:21 --> Model Class Initialized
INFO - 2016-11-15 22:23:21 --> Form Validation Class Initialized
INFO - 2016-11-15 22:23:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-11-15 22:23:21 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`name`, `numberOfLeaves`, `description`) VALUES ('Normal', '40', 'Normal Leave')
INFO - 2016-11-15 22:23:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-11-15 22:23:24 --> Config Class Initialized
INFO - 2016-11-15 22:23:24 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:24 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:24 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:24 --> URI Class Initialized
DEBUG - 2016-11-15 22:23:24 --> No URI present. Default controller set.
INFO - 2016-11-15 22:23:24 --> Router Class Initialized
INFO - 2016-11-15 22:23:24 --> Output Class Initialized
INFO - 2016-11-15 22:23:24 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:24 --> Input Class Initialized
INFO - 2016-11-15 22:23:24 --> Language Class Initialized
INFO - 2016-11-15 22:23:24 --> Loader Class Initialized
INFO - 2016-11-15 22:23:24 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:24 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:24 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:24 --> Controller Class Initialized
INFO - 2016-11-15 22:23:24 --> Model Class Initialized
INFO - 2016-11-15 22:23:24 --> Model Class Initialized
INFO - 2016-11-15 22:23:24 --> Model Class Initialized
INFO - 2016-11-15 22:23:24 --> Model Class Initialized
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:23:24 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:23:24 --> Final output sent to browser
DEBUG - 2016-11-15 22:23:24 --> Total execution time: 0.4686
INFO - 2016-11-15 22:23:47 --> Config Class Initialized
INFO - 2016-11-15 22:23:47 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:47 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:47 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:47 --> URI Class Initialized
INFO - 2016-11-15 22:23:47 --> Router Class Initialized
INFO - 2016-11-15 22:23:47 --> Output Class Initialized
INFO - 2016-11-15 22:23:47 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:47 --> Input Class Initialized
INFO - 2016-11-15 22:23:47 --> Language Class Initialized
INFO - 2016-11-15 22:23:47 --> Loader Class Initialized
INFO - 2016-11-15 22:23:47 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:47 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:47 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:47 --> Controller Class Initialized
INFO - 2016-11-15 22:23:47 --> Model Class Initialized
INFO - 2016-11-15 22:23:47 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-15 22:23:47 --> Final output sent to browser
DEBUG - 2016-11-15 22:23:47 --> Total execution time: 0.3794
INFO - 2016-11-15 22:23:53 --> Config Class Initialized
INFO - 2016-11-15 22:23:53 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:23:53 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:23:53 --> Utf8 Class Initialized
INFO - 2016-11-15 22:23:53 --> URI Class Initialized
DEBUG - 2016-11-15 22:23:53 --> No URI present. Default controller set.
INFO - 2016-11-15 22:23:53 --> Router Class Initialized
INFO - 2016-11-15 22:23:53 --> Output Class Initialized
INFO - 2016-11-15 22:23:53 --> Security Class Initialized
DEBUG - 2016-11-15 22:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:23:53 --> Input Class Initialized
INFO - 2016-11-15 22:23:53 --> Language Class Initialized
INFO - 2016-11-15 22:23:53 --> Loader Class Initialized
INFO - 2016-11-15 22:23:53 --> Helper loaded: url_helper
INFO - 2016-11-15 22:23:53 --> Helper loaded: form_helper
INFO - 2016-11-15 22:23:53 --> Database Driver Class Initialized
INFO - 2016-11-15 22:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:23:53 --> Controller Class Initialized
INFO - 2016-11-15 22:23:53 --> Model Class Initialized
INFO - 2016-11-15 22:23:53 --> Model Class Initialized
INFO - 2016-11-15 22:23:53 --> Model Class Initialized
INFO - 2016-11-15 22:23:53 --> Model Class Initialized
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\navbar.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\home.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_user_sidebar.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/add_leave_type.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/all_leave_type.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/leave_reports.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\admin/user_reports.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\dashboard.php
INFO - 2016-11-15 22:23:53 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:23:53 --> Final output sent to browser
DEBUG - 2016-11-15 22:23:53 --> Total execution time: 0.4715
INFO - 2016-11-15 22:24:12 --> Config Class Initialized
INFO - 2016-11-15 22:24:12 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:24:12 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:24:12 --> Utf8 Class Initialized
INFO - 2016-11-15 22:24:12 --> URI Class Initialized
INFO - 2016-11-15 22:24:12 --> Router Class Initialized
INFO - 2016-11-15 22:24:12 --> Output Class Initialized
INFO - 2016-11-15 22:24:12 --> Security Class Initialized
DEBUG - 2016-11-15 22:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:24:12 --> Input Class Initialized
INFO - 2016-11-15 22:24:12 --> Language Class Initialized
INFO - 2016-11-15 22:24:12 --> Loader Class Initialized
INFO - 2016-11-15 22:24:12 --> Helper loaded: url_helper
INFO - 2016-11-15 22:24:12 --> Helper loaded: form_helper
INFO - 2016-11-15 22:24:12 --> Database Driver Class Initialized
INFO - 2016-11-15 22:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:24:12 --> Controller Class Initialized
INFO - 2016-11-15 22:24:12 --> Model Class Initialized
INFO - 2016-11-15 22:24:12 --> Model Class Initialized
INFO - 2016-11-15 22:24:12 --> Model Class Initialized
INFO - 2016-11-15 22:24:12 --> Model Class Initialized
DEBUG - 2016-11-15 22:24:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-11-15 22:24:12 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
ERROR - 2016-11-15 22:24:12 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\LMS\app\controllers\Auth.php 145
INFO - 2016-11-15 22:24:13 --> Config Class Initialized
INFO - 2016-11-15 22:24:13 --> Hooks Class Initialized
DEBUG - 2016-11-15 22:24:13 --> UTF-8 Support Enabled
INFO - 2016-11-15 22:24:13 --> Utf8 Class Initialized
INFO - 2016-11-15 22:24:13 --> URI Class Initialized
DEBUG - 2016-11-15 22:24:13 --> No URI present. Default controller set.
INFO - 2016-11-15 22:24:13 --> Router Class Initialized
INFO - 2016-11-15 22:24:13 --> Output Class Initialized
INFO - 2016-11-15 22:24:13 --> Security Class Initialized
DEBUG - 2016-11-15 22:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-15 22:24:13 --> Input Class Initialized
INFO - 2016-11-15 22:24:13 --> Language Class Initialized
INFO - 2016-11-15 22:24:13 --> Loader Class Initialized
INFO - 2016-11-15 22:24:13 --> Helper loaded: url_helper
INFO - 2016-11-15 22:24:13 --> Helper loaded: form_helper
INFO - 2016-11-15 22:24:13 --> Database Driver Class Initialized
INFO - 2016-11-15 22:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-15 22:24:13 --> Controller Class Initialized
INFO - 2016-11-15 22:24:13 --> Model Class Initialized
INFO - 2016-11-15 22:24:13 --> Model Class Initialized
INFO - 2016-11-15 22:24:13 --> Model Class Initialized
INFO - 2016-11-15 22:24:13 --> Model Class Initialized
INFO - 2016-11-15 22:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\header.php
INFO - 2016-11-15 22:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\auth.php
INFO - 2016-11-15 22:24:13 --> File loaded: C:\xampp\htdocs\LMS\app\views\footer.php
INFO - 2016-11-15 22:24:13 --> Final output sent to browser
DEBUG - 2016-11-15 22:24:13 --> Total execution time: 0.3122
