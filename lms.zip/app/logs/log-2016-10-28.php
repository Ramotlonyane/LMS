<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-28 09:40:21 --> Config Class Initialized
INFO - 2016-10-28 09:40:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:40:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:40:21 --> Utf8 Class Initialized
INFO - 2016-10-28 09:40:21 --> URI Class Initialized
DEBUG - 2016-10-28 09:40:21 --> No URI present. Default controller set.
INFO - 2016-10-28 09:40:21 --> Router Class Initialized
INFO - 2016-10-28 09:40:21 --> Output Class Initialized
INFO - 2016-10-28 09:40:21 --> Security Class Initialized
DEBUG - 2016-10-28 09:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:40:21 --> Input Class Initialized
INFO - 2016-10-28 09:40:21 --> Language Class Initialized
INFO - 2016-10-28 09:40:21 --> Loader Class Initialized
INFO - 2016-10-28 09:40:21 --> Helper loaded: url_helper
INFO - 2016-10-28 09:40:21 --> Helper loaded: form_helper
INFO - 2016-10-28 09:40:21 --> Database Driver Class Initialized
INFO - 2016-10-28 09:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:40:21 --> Controller Class Initialized
INFO - 2016-10-28 09:40:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:40:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 09:40:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:40:21 --> Final output sent to browser
DEBUG - 2016-10-28 09:40:21 --> Total execution time: 0.1701
INFO - 2016-10-28 09:40:48 --> Config Class Initialized
INFO - 2016-10-28 09:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:40:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:40:48 --> Utf8 Class Initialized
INFO - 2016-10-28 09:40:48 --> URI Class Initialized
INFO - 2016-10-28 09:40:48 --> Router Class Initialized
INFO - 2016-10-28 09:40:48 --> Output Class Initialized
INFO - 2016-10-28 09:40:48 --> Security Class Initialized
DEBUG - 2016-10-28 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:40:48 --> Input Class Initialized
INFO - 2016-10-28 09:40:48 --> Language Class Initialized
INFO - 2016-10-28 09:40:48 --> Loader Class Initialized
INFO - 2016-10-28 09:40:48 --> Helper loaded: url_helper
INFO - 2016-10-28 09:40:48 --> Helper loaded: form_helper
INFO - 2016-10-28 09:40:48 --> Database Driver Class Initialized
INFO - 2016-10-28 09:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:40:48 --> Controller Class Initialized
DEBUG - 2016-10-28 09:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 09:40:48 --> Model Class Initialized
INFO - 2016-10-28 09:40:48 --> Final output sent to browser
DEBUG - 2016-10-28 09:40:48 --> Total execution time: 0.0464
INFO - 2016-10-28 09:40:48 --> Config Class Initialized
INFO - 2016-10-28 09:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:40:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:40:48 --> Utf8 Class Initialized
INFO - 2016-10-28 09:40:48 --> URI Class Initialized
DEBUG - 2016-10-28 09:40:48 --> No URI present. Default controller set.
INFO - 2016-10-28 09:40:48 --> Router Class Initialized
INFO - 2016-10-28 09:40:48 --> Output Class Initialized
INFO - 2016-10-28 09:40:48 --> Security Class Initialized
DEBUG - 2016-10-28 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:40:48 --> Input Class Initialized
INFO - 2016-10-28 09:40:48 --> Language Class Initialized
INFO - 2016-10-28 09:40:48 --> Loader Class Initialized
INFO - 2016-10-28 09:40:48 --> Helper loaded: url_helper
INFO - 2016-10-28 09:40:48 --> Helper loaded: form_helper
INFO - 2016-10-28 09:40:48 --> Database Driver Class Initialized
INFO - 2016-10-28 09:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:40:48 --> Controller Class Initialized
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:40:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:40:48 --> Final output sent to browser
DEBUG - 2016-10-28 09:40:48 --> Total execution time: 0.0565
INFO - 2016-10-28 09:40:51 --> Config Class Initialized
INFO - 2016-10-28 09:40:51 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:40:51 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:40:51 --> Utf8 Class Initialized
INFO - 2016-10-28 09:40:51 --> URI Class Initialized
DEBUG - 2016-10-28 09:40:51 --> No URI present. Default controller set.
INFO - 2016-10-28 09:40:51 --> Router Class Initialized
INFO - 2016-10-28 09:40:51 --> Output Class Initialized
INFO - 2016-10-28 09:40:51 --> Security Class Initialized
DEBUG - 2016-10-28 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:40:51 --> Input Class Initialized
INFO - 2016-10-28 09:40:51 --> Language Class Initialized
INFO - 2016-10-28 09:40:51 --> Loader Class Initialized
INFO - 2016-10-28 09:40:51 --> Helper loaded: url_helper
INFO - 2016-10-28 09:40:51 --> Helper loaded: form_helper
INFO - 2016-10-28 09:40:51 --> Database Driver Class Initialized
INFO - 2016-10-28 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:40:51 --> Controller Class Initialized
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:40:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:40:51 --> Final output sent to browser
DEBUG - 2016-10-28 09:40:51 --> Total execution time: 0.0167
INFO - 2016-10-28 09:41:20 --> Config Class Initialized
INFO - 2016-10-28 09:41:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:41:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:41:20 --> Utf8 Class Initialized
INFO - 2016-10-28 09:41:20 --> URI Class Initialized
INFO - 2016-10-28 09:41:20 --> Router Class Initialized
INFO - 2016-10-28 09:41:20 --> Output Class Initialized
INFO - 2016-10-28 09:41:20 --> Security Class Initialized
DEBUG - 2016-10-28 09:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:41:20 --> Input Class Initialized
INFO - 2016-10-28 09:41:20 --> Language Class Initialized
INFO - 2016-10-28 09:41:20 --> Loader Class Initialized
INFO - 2016-10-28 09:41:20 --> Helper loaded: url_helper
INFO - 2016-10-28 09:41:20 --> Helper loaded: form_helper
INFO - 2016-10-28 09:41:20 --> Database Driver Class Initialized
INFO - 2016-10-28 09:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:41:20 --> Controller Class Initialized
INFO - 2016-10-28 09:41:20 --> Form Validation Class Initialized
INFO - 2016-10-28 09:41:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:41:20 --> Final output sent to browser
DEBUG - 2016-10-28 09:41:20 --> Total execution time: 0.0735
INFO - 2016-10-28 09:41:24 --> Config Class Initialized
INFO - 2016-10-28 09:41:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:41:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:41:24 --> Utf8 Class Initialized
INFO - 2016-10-28 09:41:24 --> URI Class Initialized
DEBUG - 2016-10-28 09:41:24 --> No URI present. Default controller set.
INFO - 2016-10-28 09:41:24 --> Router Class Initialized
INFO - 2016-10-28 09:41:24 --> Output Class Initialized
INFO - 2016-10-28 09:41:24 --> Security Class Initialized
DEBUG - 2016-10-28 09:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:41:24 --> Input Class Initialized
INFO - 2016-10-28 09:41:24 --> Language Class Initialized
INFO - 2016-10-28 09:41:24 --> Loader Class Initialized
INFO - 2016-10-28 09:41:24 --> Helper loaded: url_helper
INFO - 2016-10-28 09:41:24 --> Helper loaded: form_helper
INFO - 2016-10-28 09:41:24 --> Database Driver Class Initialized
INFO - 2016-10-28 09:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:41:24 --> Controller Class Initialized
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:41:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:41:24 --> Final output sent to browser
DEBUG - 2016-10-28 09:41:24 --> Total execution time: 0.0174
INFO - 2016-10-28 09:41:55 --> Config Class Initialized
INFO - 2016-10-28 09:41:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:41:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:41:55 --> Utf8 Class Initialized
INFO - 2016-10-28 09:41:55 --> URI Class Initialized
INFO - 2016-10-28 09:41:55 --> Router Class Initialized
INFO - 2016-10-28 09:41:55 --> Output Class Initialized
INFO - 2016-10-28 09:41:55 --> Security Class Initialized
DEBUG - 2016-10-28 09:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:41:55 --> Input Class Initialized
INFO - 2016-10-28 09:41:55 --> Language Class Initialized
INFO - 2016-10-28 09:41:55 --> Loader Class Initialized
INFO - 2016-10-28 09:41:55 --> Helper loaded: url_helper
INFO - 2016-10-28 09:41:55 --> Helper loaded: form_helper
INFO - 2016-10-28 09:41:55 --> Database Driver Class Initialized
INFO - 2016-10-28 09:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:41:55 --> Controller Class Initialized
INFO - 2016-10-28 09:41:55 --> Form Validation Class Initialized
INFO - 2016-10-28 09:41:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:41:55 --> Final output sent to browser
DEBUG - 2016-10-28 09:41:55 --> Total execution time: 0.0180
INFO - 2016-10-28 09:41:57 --> Config Class Initialized
INFO - 2016-10-28 09:41:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:41:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:41:57 --> Utf8 Class Initialized
INFO - 2016-10-28 09:41:57 --> URI Class Initialized
DEBUG - 2016-10-28 09:41:57 --> No URI present. Default controller set.
INFO - 2016-10-28 09:41:57 --> Router Class Initialized
INFO - 2016-10-28 09:41:57 --> Output Class Initialized
INFO - 2016-10-28 09:41:57 --> Security Class Initialized
DEBUG - 2016-10-28 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:41:57 --> Input Class Initialized
INFO - 2016-10-28 09:41:57 --> Language Class Initialized
INFO - 2016-10-28 09:41:57 --> Loader Class Initialized
INFO - 2016-10-28 09:41:57 --> Helper loaded: url_helper
INFO - 2016-10-28 09:41:57 --> Helper loaded: form_helper
INFO - 2016-10-28 09:41:57 --> Database Driver Class Initialized
INFO - 2016-10-28 09:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:41:57 --> Controller Class Initialized
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:41:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:41:57 --> Final output sent to browser
DEBUG - 2016-10-28 09:41:57 --> Total execution time: 0.0176
INFO - 2016-10-28 09:42:58 --> Config Class Initialized
INFO - 2016-10-28 09:42:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:42:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:42:58 --> Utf8 Class Initialized
INFO - 2016-10-28 09:42:58 --> URI Class Initialized
DEBUG - 2016-10-28 09:42:58 --> No URI present. Default controller set.
INFO - 2016-10-28 09:42:58 --> Router Class Initialized
INFO - 2016-10-28 09:42:58 --> Output Class Initialized
INFO - 2016-10-28 09:42:58 --> Security Class Initialized
DEBUG - 2016-10-28 09:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:42:58 --> Input Class Initialized
INFO - 2016-10-28 09:42:58 --> Language Class Initialized
INFO - 2016-10-28 09:42:58 --> Loader Class Initialized
INFO - 2016-10-28 09:42:58 --> Helper loaded: url_helper
INFO - 2016-10-28 09:42:58 --> Helper loaded: form_helper
INFO - 2016-10-28 09:42:58 --> Database Driver Class Initialized
INFO - 2016-10-28 09:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:42:58 --> Controller Class Initialized
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:42:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:42:58 --> Final output sent to browser
DEBUG - 2016-10-28 09:42:58 --> Total execution time: 0.0188
INFO - 2016-10-28 09:43:15 --> Config Class Initialized
INFO - 2016-10-28 09:43:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:43:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:43:15 --> Utf8 Class Initialized
INFO - 2016-10-28 09:43:15 --> URI Class Initialized
INFO - 2016-10-28 09:43:15 --> Router Class Initialized
INFO - 2016-10-28 09:43:15 --> Output Class Initialized
INFO - 2016-10-28 09:43:15 --> Security Class Initialized
DEBUG - 2016-10-28 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:43:15 --> Input Class Initialized
INFO - 2016-10-28 09:43:15 --> Language Class Initialized
INFO - 2016-10-28 09:43:15 --> Loader Class Initialized
INFO - 2016-10-28 09:43:15 --> Helper loaded: url_helper
INFO - 2016-10-28 09:43:15 --> Helper loaded: form_helper
INFO - 2016-10-28 09:43:15 --> Database Driver Class Initialized
INFO - 2016-10-28 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:43:15 --> Controller Class Initialized
INFO - 2016-10-28 09:43:15 --> Form Validation Class Initialized
INFO - 2016-10-28 09:43:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:43:15 --> Final output sent to browser
DEBUG - 2016-10-28 09:43:15 --> Total execution time: 0.0370
INFO - 2016-10-28 09:43:17 --> Config Class Initialized
INFO - 2016-10-28 09:43:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:43:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:43:17 --> Utf8 Class Initialized
INFO - 2016-10-28 09:43:17 --> URI Class Initialized
DEBUG - 2016-10-28 09:43:17 --> No URI present. Default controller set.
INFO - 2016-10-28 09:43:17 --> Router Class Initialized
INFO - 2016-10-28 09:43:17 --> Output Class Initialized
INFO - 2016-10-28 09:43:17 --> Security Class Initialized
DEBUG - 2016-10-28 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:43:17 --> Input Class Initialized
INFO - 2016-10-28 09:43:17 --> Language Class Initialized
INFO - 2016-10-28 09:43:17 --> Loader Class Initialized
INFO - 2016-10-28 09:43:17 --> Helper loaded: url_helper
INFO - 2016-10-28 09:43:17 --> Helper loaded: form_helper
INFO - 2016-10-28 09:43:17 --> Database Driver Class Initialized
INFO - 2016-10-28 09:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:43:17 --> Controller Class Initialized
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:43:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:43:17 --> Final output sent to browser
DEBUG - 2016-10-28 09:43:17 --> Total execution time: 0.0174
INFO - 2016-10-28 09:45:59 --> Config Class Initialized
INFO - 2016-10-28 09:45:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:45:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:45:59 --> Utf8 Class Initialized
INFO - 2016-10-28 09:45:59 --> URI Class Initialized
DEBUG - 2016-10-28 09:45:59 --> No URI present. Default controller set.
INFO - 2016-10-28 09:45:59 --> Router Class Initialized
INFO - 2016-10-28 09:45:59 --> Output Class Initialized
INFO - 2016-10-28 09:45:59 --> Security Class Initialized
DEBUG - 2016-10-28 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:45:59 --> Input Class Initialized
INFO - 2016-10-28 09:45:59 --> Language Class Initialized
INFO - 2016-10-28 09:45:59 --> Loader Class Initialized
INFO - 2016-10-28 09:45:59 --> Helper loaded: url_helper
INFO - 2016-10-28 09:45:59 --> Helper loaded: form_helper
INFO - 2016-10-28 09:45:59 --> Database Driver Class Initialized
INFO - 2016-10-28 09:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:45:59 --> Controller Class Initialized
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:45:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:45:59 --> Final output sent to browser
DEBUG - 2016-10-28 09:45:59 --> Total execution time: 0.0194
INFO - 2016-10-28 09:47:04 --> Config Class Initialized
INFO - 2016-10-28 09:47:04 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:47:04 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:47:04 --> Utf8 Class Initialized
INFO - 2016-10-28 09:47:04 --> URI Class Initialized
INFO - 2016-10-28 09:47:04 --> Router Class Initialized
INFO - 2016-10-28 09:47:04 --> Output Class Initialized
INFO - 2016-10-28 09:47:04 --> Security Class Initialized
DEBUG - 2016-10-28 09:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:47:04 --> Input Class Initialized
INFO - 2016-10-28 09:47:04 --> Language Class Initialized
INFO - 2016-10-28 09:47:04 --> Loader Class Initialized
INFO - 2016-10-28 09:47:04 --> Helper loaded: url_helper
INFO - 2016-10-28 09:47:04 --> Helper loaded: form_helper
INFO - 2016-10-28 09:47:04 --> Database Driver Class Initialized
INFO - 2016-10-28 09:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:47:04 --> Controller Class Initialized
INFO - 2016-10-28 09:47:04 --> Form Validation Class Initialized
INFO - 2016-10-28 09:47:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:47:04 --> Final output sent to browser
DEBUG - 2016-10-28 09:47:04 --> Total execution time: 0.0190
INFO - 2016-10-28 09:47:07 --> Config Class Initialized
INFO - 2016-10-28 09:47:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:47:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:47:07 --> Utf8 Class Initialized
INFO - 2016-10-28 09:47:07 --> URI Class Initialized
DEBUG - 2016-10-28 09:47:07 --> No URI present. Default controller set.
INFO - 2016-10-28 09:47:07 --> Router Class Initialized
INFO - 2016-10-28 09:47:07 --> Output Class Initialized
INFO - 2016-10-28 09:47:07 --> Security Class Initialized
DEBUG - 2016-10-28 09:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:47:07 --> Input Class Initialized
INFO - 2016-10-28 09:47:07 --> Language Class Initialized
INFO - 2016-10-28 09:47:07 --> Loader Class Initialized
INFO - 2016-10-28 09:47:07 --> Helper loaded: url_helper
INFO - 2016-10-28 09:47:07 --> Helper loaded: form_helper
INFO - 2016-10-28 09:47:07 --> Database Driver Class Initialized
INFO - 2016-10-28 09:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:47:07 --> Controller Class Initialized
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:47:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:47:07 --> Final output sent to browser
DEBUG - 2016-10-28 09:47:07 --> Total execution time: 0.0175
INFO - 2016-10-28 09:51:38 --> Config Class Initialized
INFO - 2016-10-28 09:51:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:51:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:51:38 --> Utf8 Class Initialized
INFO - 2016-10-28 09:51:38 --> URI Class Initialized
DEBUG - 2016-10-28 09:51:38 --> No URI present. Default controller set.
INFO - 2016-10-28 09:51:38 --> Router Class Initialized
INFO - 2016-10-28 09:51:38 --> Output Class Initialized
INFO - 2016-10-28 09:51:38 --> Security Class Initialized
DEBUG - 2016-10-28 09:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:51:38 --> Input Class Initialized
INFO - 2016-10-28 09:51:38 --> Language Class Initialized
INFO - 2016-10-28 09:51:38 --> Loader Class Initialized
INFO - 2016-10-28 09:51:38 --> Helper loaded: url_helper
INFO - 2016-10-28 09:51:38 --> Helper loaded: form_helper
INFO - 2016-10-28 09:51:38 --> Database Driver Class Initialized
INFO - 2016-10-28 09:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:51:38 --> Controller Class Initialized
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:51:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:51:38 --> Final output sent to browser
DEBUG - 2016-10-28 09:51:38 --> Total execution time: 0.0321
INFO - 2016-10-28 09:52:18 --> Config Class Initialized
INFO - 2016-10-28 09:52:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:52:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:52:18 --> Utf8 Class Initialized
INFO - 2016-10-28 09:52:18 --> URI Class Initialized
DEBUG - 2016-10-28 09:52:18 --> No URI present. Default controller set.
INFO - 2016-10-28 09:52:18 --> Router Class Initialized
INFO - 2016-10-28 09:52:18 --> Output Class Initialized
INFO - 2016-10-28 09:52:18 --> Security Class Initialized
DEBUG - 2016-10-28 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:52:18 --> Input Class Initialized
INFO - 2016-10-28 09:52:18 --> Language Class Initialized
INFO - 2016-10-28 09:52:18 --> Loader Class Initialized
INFO - 2016-10-28 09:52:18 --> Helper loaded: url_helper
INFO - 2016-10-28 09:52:18 --> Helper loaded: form_helper
INFO - 2016-10-28 09:52:18 --> Database Driver Class Initialized
INFO - 2016-10-28 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:52:18 --> Controller Class Initialized
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:52:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:52:18 --> Final output sent to browser
DEBUG - 2016-10-28 09:52:18 --> Total execution time: 0.0216
INFO - 2016-10-28 09:53:54 --> Config Class Initialized
INFO - 2016-10-28 09:53:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:53:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:53:54 --> Utf8 Class Initialized
INFO - 2016-10-28 09:53:54 --> URI Class Initialized
INFO - 2016-10-28 09:53:54 --> Router Class Initialized
INFO - 2016-10-28 09:53:54 --> Output Class Initialized
INFO - 2016-10-28 09:53:54 --> Security Class Initialized
DEBUG - 2016-10-28 09:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:53:54 --> Input Class Initialized
INFO - 2016-10-28 09:53:54 --> Language Class Initialized
INFO - 2016-10-28 09:53:54 --> Loader Class Initialized
INFO - 2016-10-28 09:53:54 --> Helper loaded: url_helper
INFO - 2016-10-28 09:53:54 --> Helper loaded: form_helper
INFO - 2016-10-28 09:53:54 --> Database Driver Class Initialized
INFO - 2016-10-28 09:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:53:54 --> Controller Class Initialized
INFO - 2016-10-28 09:53:54 --> Form Validation Class Initialized
INFO - 2016-10-28 09:53:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:53:54 --> Final output sent to browser
DEBUG - 2016-10-28 09:53:54 --> Total execution time: 0.0177
INFO - 2016-10-28 09:53:55 --> Config Class Initialized
INFO - 2016-10-28 09:53:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:53:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:53:55 --> Utf8 Class Initialized
INFO - 2016-10-28 09:53:55 --> URI Class Initialized
DEBUG - 2016-10-28 09:53:55 --> No URI present. Default controller set.
INFO - 2016-10-28 09:53:55 --> Router Class Initialized
INFO - 2016-10-28 09:53:55 --> Output Class Initialized
INFO - 2016-10-28 09:53:55 --> Security Class Initialized
DEBUG - 2016-10-28 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:53:55 --> Input Class Initialized
INFO - 2016-10-28 09:53:55 --> Language Class Initialized
INFO - 2016-10-28 09:53:55 --> Loader Class Initialized
INFO - 2016-10-28 09:53:55 --> Helper loaded: url_helper
INFO - 2016-10-28 09:53:55 --> Helper loaded: form_helper
INFO - 2016-10-28 09:53:55 --> Database Driver Class Initialized
INFO - 2016-10-28 09:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:53:55 --> Controller Class Initialized
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:53:55 --> Final output sent to browser
DEBUG - 2016-10-28 09:53:55 --> Total execution time: 0.0186
INFO - 2016-10-28 09:55:24 --> Config Class Initialized
INFO - 2016-10-28 09:55:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:55:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:55:24 --> Utf8 Class Initialized
INFO - 2016-10-28 09:55:24 --> URI Class Initialized
DEBUG - 2016-10-28 09:55:24 --> No URI present. Default controller set.
INFO - 2016-10-28 09:55:24 --> Router Class Initialized
INFO - 2016-10-28 09:55:24 --> Output Class Initialized
INFO - 2016-10-28 09:55:24 --> Security Class Initialized
DEBUG - 2016-10-28 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:55:24 --> Input Class Initialized
INFO - 2016-10-28 09:55:24 --> Language Class Initialized
INFO - 2016-10-28 09:55:24 --> Loader Class Initialized
INFO - 2016-10-28 09:55:24 --> Helper loaded: url_helper
INFO - 2016-10-28 09:55:24 --> Helper loaded: form_helper
INFO - 2016-10-28 09:55:24 --> Database Driver Class Initialized
INFO - 2016-10-28 09:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:55:24 --> Controller Class Initialized
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:55:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:55:24 --> Final output sent to browser
DEBUG - 2016-10-28 09:55:24 --> Total execution time: 0.0204
INFO - 2016-10-28 09:55:30 --> Config Class Initialized
INFO - 2016-10-28 09:55:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:55:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:55:30 --> Utf8 Class Initialized
INFO - 2016-10-28 09:55:30 --> URI Class Initialized
INFO - 2016-10-28 09:55:30 --> Router Class Initialized
INFO - 2016-10-28 09:55:30 --> Output Class Initialized
INFO - 2016-10-28 09:55:30 --> Security Class Initialized
DEBUG - 2016-10-28 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:55:30 --> Input Class Initialized
INFO - 2016-10-28 09:55:30 --> Language Class Initialized
INFO - 2016-10-28 09:55:30 --> Loader Class Initialized
INFO - 2016-10-28 09:55:30 --> Helper loaded: url_helper
INFO - 2016-10-28 09:55:30 --> Helper loaded: form_helper
INFO - 2016-10-28 09:55:30 --> Database Driver Class Initialized
INFO - 2016-10-28 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:55:30 --> Controller Class Initialized
INFO - 2016-10-28 09:55:30 --> Form Validation Class Initialized
INFO - 2016-10-28 09:55:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:55:30 --> Final output sent to browser
DEBUG - 2016-10-28 09:55:30 --> Total execution time: 0.0203
INFO - 2016-10-28 09:55:32 --> Config Class Initialized
INFO - 2016-10-28 09:55:32 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:55:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:55:32 --> Utf8 Class Initialized
INFO - 2016-10-28 09:55:32 --> URI Class Initialized
INFO - 2016-10-28 09:55:32 --> Router Class Initialized
INFO - 2016-10-28 09:55:32 --> Output Class Initialized
INFO - 2016-10-28 09:55:32 --> Security Class Initialized
DEBUG - 2016-10-28 09:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:55:32 --> Input Class Initialized
INFO - 2016-10-28 09:55:32 --> Language Class Initialized
INFO - 2016-10-28 09:55:32 --> Loader Class Initialized
INFO - 2016-10-28 09:55:32 --> Helper loaded: url_helper
INFO - 2016-10-28 09:55:32 --> Helper loaded: form_helper
INFO - 2016-10-28 09:55:32 --> Database Driver Class Initialized
INFO - 2016-10-28 09:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:55:32 --> Controller Class Initialized
INFO - 2016-10-28 09:55:32 --> Form Validation Class Initialized
INFO - 2016-10-28 09:55:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:55:32 --> Final output sent to browser
DEBUG - 2016-10-28 09:55:32 --> Total execution time: 0.0167
INFO - 2016-10-28 09:58:06 --> Config Class Initialized
INFO - 2016-10-28 09:58:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:58:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:58:06 --> Utf8 Class Initialized
INFO - 2016-10-28 09:58:06 --> URI Class Initialized
DEBUG - 2016-10-28 09:58:06 --> No URI present. Default controller set.
INFO - 2016-10-28 09:58:06 --> Router Class Initialized
INFO - 2016-10-28 09:58:06 --> Output Class Initialized
INFO - 2016-10-28 09:58:06 --> Security Class Initialized
DEBUG - 2016-10-28 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:58:06 --> Input Class Initialized
INFO - 2016-10-28 09:58:06 --> Language Class Initialized
INFO - 2016-10-28 09:58:06 --> Loader Class Initialized
INFO - 2016-10-28 09:58:06 --> Helper loaded: url_helper
INFO - 2016-10-28 09:58:06 --> Helper loaded: form_helper
INFO - 2016-10-28 09:58:06 --> Database Driver Class Initialized
INFO - 2016-10-28 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:58:06 --> Controller Class Initialized
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:58:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:58:06 --> Final output sent to browser
DEBUG - 2016-10-28 09:58:06 --> Total execution time: 0.0175
INFO - 2016-10-28 09:58:19 --> Config Class Initialized
INFO - 2016-10-28 09:58:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:58:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:58:19 --> Utf8 Class Initialized
INFO - 2016-10-28 09:58:19 --> URI Class Initialized
INFO - 2016-10-28 09:58:19 --> Router Class Initialized
INFO - 2016-10-28 09:58:19 --> Output Class Initialized
INFO - 2016-10-28 09:58:19 --> Security Class Initialized
DEBUG - 2016-10-28 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:58:19 --> Input Class Initialized
INFO - 2016-10-28 09:58:19 --> Language Class Initialized
INFO - 2016-10-28 09:58:19 --> Loader Class Initialized
INFO - 2016-10-28 09:58:19 --> Helper loaded: url_helper
INFO - 2016-10-28 09:58:19 --> Helper loaded: form_helper
INFO - 2016-10-28 09:58:19 --> Database Driver Class Initialized
INFO - 2016-10-28 09:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:58:19 --> Controller Class Initialized
INFO - 2016-10-28 09:58:19 --> Form Validation Class Initialized
INFO - 2016-10-28 09:58:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 09:58:19 --> Final output sent to browser
DEBUG - 2016-10-28 09:58:19 --> Total execution time: 0.0174
INFO - 2016-10-28 09:58:21 --> Config Class Initialized
INFO - 2016-10-28 09:58:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:58:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:58:21 --> Utf8 Class Initialized
INFO - 2016-10-28 09:58:21 --> URI Class Initialized
DEBUG - 2016-10-28 09:58:21 --> No URI present. Default controller set.
INFO - 2016-10-28 09:58:21 --> Router Class Initialized
INFO - 2016-10-28 09:58:21 --> Output Class Initialized
INFO - 2016-10-28 09:58:21 --> Security Class Initialized
DEBUG - 2016-10-28 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:58:21 --> Input Class Initialized
INFO - 2016-10-28 09:58:21 --> Language Class Initialized
INFO - 2016-10-28 09:58:21 --> Loader Class Initialized
INFO - 2016-10-28 09:58:21 --> Helper loaded: url_helper
INFO - 2016-10-28 09:58:21 --> Helper loaded: form_helper
INFO - 2016-10-28 09:58:21 --> Database Driver Class Initialized
INFO - 2016-10-28 09:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:58:21 --> Controller Class Initialized
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:58:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:58:21 --> Final output sent to browser
DEBUG - 2016-10-28 09:58:21 --> Total execution time: 0.0188
INFO - 2016-10-28 09:59:53 --> Config Class Initialized
INFO - 2016-10-28 09:59:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:59:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:59:53 --> Utf8 Class Initialized
INFO - 2016-10-28 09:59:53 --> URI Class Initialized
DEBUG - 2016-10-28 09:59:53 --> No URI present. Default controller set.
INFO - 2016-10-28 09:59:53 --> Router Class Initialized
INFO - 2016-10-28 09:59:53 --> Output Class Initialized
INFO - 2016-10-28 09:59:53 --> Security Class Initialized
DEBUG - 2016-10-28 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:59:53 --> Input Class Initialized
INFO - 2016-10-28 09:59:53 --> Language Class Initialized
INFO - 2016-10-28 09:59:53 --> Loader Class Initialized
INFO - 2016-10-28 09:59:53 --> Helper loaded: url_helper
INFO - 2016-10-28 09:59:53 --> Helper loaded: form_helper
INFO - 2016-10-28 09:59:53 --> Database Driver Class Initialized
INFO - 2016-10-28 09:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:59:53 --> Controller Class Initialized
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:59:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:59:53 --> Final output sent to browser
DEBUG - 2016-10-28 09:59:53 --> Total execution time: 0.0181
INFO - 2016-10-28 09:59:54 --> Config Class Initialized
INFO - 2016-10-28 09:59:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 09:59:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 09:59:54 --> Utf8 Class Initialized
INFO - 2016-10-28 09:59:54 --> URI Class Initialized
DEBUG - 2016-10-28 09:59:54 --> No URI present. Default controller set.
INFO - 2016-10-28 09:59:54 --> Router Class Initialized
INFO - 2016-10-28 09:59:54 --> Output Class Initialized
INFO - 2016-10-28 09:59:54 --> Security Class Initialized
DEBUG - 2016-10-28 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 09:59:54 --> Input Class Initialized
INFO - 2016-10-28 09:59:54 --> Language Class Initialized
INFO - 2016-10-28 09:59:54 --> Loader Class Initialized
INFO - 2016-10-28 09:59:54 --> Helper loaded: url_helper
INFO - 2016-10-28 09:59:54 --> Helper loaded: form_helper
INFO - 2016-10-28 09:59:54 --> Database Driver Class Initialized
INFO - 2016-10-28 09:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 09:59:54 --> Controller Class Initialized
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 09:59:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 09:59:54 --> Final output sent to browser
DEBUG - 2016-10-28 09:59:54 --> Total execution time: 0.0170
INFO - 2016-10-28 10:00:21 --> Config Class Initialized
INFO - 2016-10-28 10:00:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:00:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:00:21 --> Utf8 Class Initialized
INFO - 2016-10-28 10:00:21 --> URI Class Initialized
INFO - 2016-10-28 10:00:21 --> Router Class Initialized
INFO - 2016-10-28 10:00:21 --> Output Class Initialized
INFO - 2016-10-28 10:00:21 --> Security Class Initialized
DEBUG - 2016-10-28 10:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:00:21 --> Input Class Initialized
INFO - 2016-10-28 10:00:21 --> Language Class Initialized
INFO - 2016-10-28 10:00:21 --> Loader Class Initialized
INFO - 2016-10-28 10:00:21 --> Helper loaded: url_helper
INFO - 2016-10-28 10:00:21 --> Helper loaded: form_helper
INFO - 2016-10-28 10:00:21 --> Database Driver Class Initialized
INFO - 2016-10-28 10:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:00:21 --> Controller Class Initialized
INFO - 2016-10-28 10:00:21 --> Form Validation Class Initialized
INFO - 2016-10-28 10:00:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 10:00:21 --> Final output sent to browser
DEBUG - 2016-10-28 10:00:21 --> Total execution time: 0.0213
INFO - 2016-10-28 10:00:25 --> Config Class Initialized
INFO - 2016-10-28 10:00:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:00:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:00:25 --> Utf8 Class Initialized
INFO - 2016-10-28 10:00:25 --> URI Class Initialized
DEBUG - 2016-10-28 10:00:25 --> No URI present. Default controller set.
INFO - 2016-10-28 10:00:25 --> Router Class Initialized
INFO - 2016-10-28 10:00:25 --> Output Class Initialized
INFO - 2016-10-28 10:00:25 --> Security Class Initialized
DEBUG - 2016-10-28 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:00:25 --> Input Class Initialized
INFO - 2016-10-28 10:00:25 --> Language Class Initialized
INFO - 2016-10-28 10:00:25 --> Loader Class Initialized
INFO - 2016-10-28 10:00:25 --> Helper loaded: url_helper
INFO - 2016-10-28 10:00:25 --> Helper loaded: form_helper
INFO - 2016-10-28 10:00:25 --> Database Driver Class Initialized
INFO - 2016-10-28 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:00:25 --> Controller Class Initialized
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 10:00:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:00:25 --> Final output sent to browser
DEBUG - 2016-10-28 10:00:25 --> Total execution time: 0.0169
INFO - 2016-10-28 10:00:34 --> Config Class Initialized
INFO - 2016-10-28 10:00:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:00:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:00:34 --> Utf8 Class Initialized
INFO - 2016-10-28 10:00:34 --> URI Class Initialized
DEBUG - 2016-10-28 10:00:34 --> No URI present. Default controller set.
INFO - 2016-10-28 10:00:34 --> Router Class Initialized
INFO - 2016-10-28 10:00:34 --> Output Class Initialized
INFO - 2016-10-28 10:00:34 --> Security Class Initialized
DEBUG - 2016-10-28 10:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:00:34 --> Input Class Initialized
INFO - 2016-10-28 10:00:34 --> Language Class Initialized
INFO - 2016-10-28 10:00:34 --> Loader Class Initialized
INFO - 2016-10-28 10:00:34 --> Helper loaded: url_helper
INFO - 2016-10-28 10:00:34 --> Helper loaded: form_helper
INFO - 2016-10-28 10:00:34 --> Database Driver Class Initialized
INFO - 2016-10-28 10:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:00:34 --> Controller Class Initialized
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 10:00:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:00:34 --> Final output sent to browser
DEBUG - 2016-10-28 10:00:34 --> Total execution time: 0.0204
INFO - 2016-10-28 10:01:55 --> Config Class Initialized
INFO - 2016-10-28 10:01:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:01:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:01:55 --> Utf8 Class Initialized
INFO - 2016-10-28 10:01:55 --> URI Class Initialized
INFO - 2016-10-28 10:01:55 --> Router Class Initialized
INFO - 2016-10-28 10:01:55 --> Output Class Initialized
INFO - 2016-10-28 10:01:55 --> Security Class Initialized
DEBUG - 2016-10-28 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:01:55 --> Input Class Initialized
INFO - 2016-10-28 10:01:55 --> Language Class Initialized
INFO - 2016-10-28 10:01:55 --> Loader Class Initialized
INFO - 2016-10-28 10:01:55 --> Helper loaded: url_helper
INFO - 2016-10-28 10:01:55 --> Helper loaded: form_helper
INFO - 2016-10-28 10:01:55 --> Database Driver Class Initialized
INFO - 2016-10-28 10:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:01:55 --> Controller Class Initialized
DEBUG - 2016-10-28 10:01:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 10:01:55 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 10:01:55 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 10:01:55 --> Config Class Initialized
INFO - 2016-10-28 10:01:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:01:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:01:55 --> Utf8 Class Initialized
INFO - 2016-10-28 10:01:55 --> URI Class Initialized
DEBUG - 2016-10-28 10:01:55 --> No URI present. Default controller set.
INFO - 2016-10-28 10:01:55 --> Router Class Initialized
INFO - 2016-10-28 10:01:55 --> Output Class Initialized
INFO - 2016-10-28 10:01:55 --> Security Class Initialized
DEBUG - 2016-10-28 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:01:55 --> Input Class Initialized
INFO - 2016-10-28 10:01:55 --> Language Class Initialized
INFO - 2016-10-28 10:01:55 --> Loader Class Initialized
INFO - 2016-10-28 10:01:55 --> Helper loaded: url_helper
INFO - 2016-10-28 10:01:55 --> Helper loaded: form_helper
INFO - 2016-10-28 10:01:55 --> Database Driver Class Initialized
INFO - 2016-10-28 10:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:01:55 --> Controller Class Initialized
INFO - 2016-10-28 10:01:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:01:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 10:01:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:01:55 --> Final output sent to browser
DEBUG - 2016-10-28 10:01:55 --> Total execution time: 0.0153
INFO - 2016-10-28 10:02:05 --> Config Class Initialized
INFO - 2016-10-28 10:02:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:02:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:02:05 --> Utf8 Class Initialized
INFO - 2016-10-28 10:02:05 --> URI Class Initialized
INFO - 2016-10-28 10:02:05 --> Router Class Initialized
INFO - 2016-10-28 10:02:05 --> Output Class Initialized
INFO - 2016-10-28 10:02:05 --> Security Class Initialized
DEBUG - 2016-10-28 10:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:02:05 --> Input Class Initialized
INFO - 2016-10-28 10:02:05 --> Language Class Initialized
INFO - 2016-10-28 10:02:05 --> Loader Class Initialized
INFO - 2016-10-28 10:02:05 --> Helper loaded: url_helper
INFO - 2016-10-28 10:02:05 --> Helper loaded: form_helper
INFO - 2016-10-28 10:02:05 --> Database Driver Class Initialized
INFO - 2016-10-28 10:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:02:05 --> Controller Class Initialized
DEBUG - 2016-10-28 10:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 10:02:05 --> Model Class Initialized
INFO - 2016-10-28 10:02:05 --> Final output sent to browser
DEBUG - 2016-10-28 10:02:05 --> Total execution time: 0.0214
INFO - 2016-10-28 10:02:06 --> Config Class Initialized
INFO - 2016-10-28 10:02:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:02:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:02:06 --> Utf8 Class Initialized
INFO - 2016-10-28 10:02:06 --> URI Class Initialized
DEBUG - 2016-10-28 10:02:06 --> No URI present. Default controller set.
INFO - 2016-10-28 10:02:06 --> Router Class Initialized
INFO - 2016-10-28 10:02:06 --> Output Class Initialized
INFO - 2016-10-28 10:02:06 --> Security Class Initialized
DEBUG - 2016-10-28 10:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:02:06 --> Input Class Initialized
INFO - 2016-10-28 10:02:06 --> Language Class Initialized
INFO - 2016-10-28 10:02:06 --> Loader Class Initialized
INFO - 2016-10-28 10:02:06 --> Helper loaded: url_helper
INFO - 2016-10-28 10:02:06 --> Helper loaded: form_helper
INFO - 2016-10-28 10:02:06 --> Database Driver Class Initialized
INFO - 2016-10-28 10:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:02:06 --> Controller Class Initialized
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 10:02:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:02:06 --> Final output sent to browser
DEBUG - 2016-10-28 10:02:06 --> Total execution time: 0.0156
INFO - 2016-10-28 10:02:14 --> Config Class Initialized
INFO - 2016-10-28 10:02:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:02:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:02:14 --> Utf8 Class Initialized
INFO - 2016-10-28 10:02:14 --> URI Class Initialized
INFO - 2016-10-28 10:02:14 --> Router Class Initialized
INFO - 2016-10-28 10:02:14 --> Output Class Initialized
INFO - 2016-10-28 10:02:14 --> Security Class Initialized
DEBUG - 2016-10-28 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:02:14 --> Input Class Initialized
INFO - 2016-10-28 10:02:14 --> Language Class Initialized
INFO - 2016-10-28 10:02:14 --> Loader Class Initialized
INFO - 2016-10-28 10:02:14 --> Helper loaded: url_helper
INFO - 2016-10-28 10:02:14 --> Helper loaded: form_helper
INFO - 2016-10-28 10:02:14 --> Database Driver Class Initialized
INFO - 2016-10-28 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:02:14 --> Controller Class Initialized
INFO - 2016-10-28 10:02:14 --> Form Validation Class Initialized
INFO - 2016-10-28 10:02:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 10:02:14 --> Final output sent to browser
DEBUG - 2016-10-28 10:02:14 --> Total execution time: 0.0178
INFO - 2016-10-28 10:02:15 --> Config Class Initialized
INFO - 2016-10-28 10:02:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:02:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:02:15 --> Utf8 Class Initialized
INFO - 2016-10-28 10:02:15 --> URI Class Initialized
DEBUG - 2016-10-28 10:02:15 --> No URI present. Default controller set.
INFO - 2016-10-28 10:02:15 --> Router Class Initialized
INFO - 2016-10-28 10:02:15 --> Output Class Initialized
INFO - 2016-10-28 10:02:15 --> Security Class Initialized
DEBUG - 2016-10-28 10:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:02:15 --> Input Class Initialized
INFO - 2016-10-28 10:02:15 --> Language Class Initialized
INFO - 2016-10-28 10:02:15 --> Loader Class Initialized
INFO - 2016-10-28 10:02:15 --> Helper loaded: url_helper
INFO - 2016-10-28 10:02:15 --> Helper loaded: form_helper
INFO - 2016-10-28 10:02:15 --> Database Driver Class Initialized
INFO - 2016-10-28 10:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:02:15 --> Controller Class Initialized
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 10:02:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:02:15 --> Final output sent to browser
DEBUG - 2016-10-28 10:02:15 --> Total execution time: 0.0170
INFO - 2016-10-28 10:03:20 --> Config Class Initialized
INFO - 2016-10-28 10:03:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:03:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:03:20 --> Utf8 Class Initialized
INFO - 2016-10-28 10:03:20 --> URI Class Initialized
DEBUG - 2016-10-28 10:03:20 --> No URI present. Default controller set.
INFO - 2016-10-28 10:03:20 --> Router Class Initialized
INFO - 2016-10-28 10:03:20 --> Output Class Initialized
INFO - 2016-10-28 10:03:20 --> Security Class Initialized
DEBUG - 2016-10-28 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:03:20 --> Input Class Initialized
INFO - 2016-10-28 10:03:20 --> Language Class Initialized
INFO - 2016-10-28 10:03:20 --> Loader Class Initialized
INFO - 2016-10-28 10:03:20 --> Helper loaded: url_helper
INFO - 2016-10-28 10:03:20 --> Helper loaded: form_helper
INFO - 2016-10-28 10:03:20 --> Database Driver Class Initialized
INFO - 2016-10-28 10:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:03:20 --> Controller Class Initialized
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 10:03:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:03:20 --> Final output sent to browser
DEBUG - 2016-10-28 10:03:20 --> Total execution time: 0.0177
INFO - 2016-10-28 10:03:39 --> Config Class Initialized
INFO - 2016-10-28 10:03:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:03:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:03:39 --> Utf8 Class Initialized
INFO - 2016-10-28 10:03:39 --> URI Class Initialized
INFO - 2016-10-28 10:03:39 --> Router Class Initialized
INFO - 2016-10-28 10:03:39 --> Output Class Initialized
INFO - 2016-10-28 10:03:39 --> Security Class Initialized
DEBUG - 2016-10-28 10:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:03:39 --> Input Class Initialized
INFO - 2016-10-28 10:03:39 --> Language Class Initialized
INFO - 2016-10-28 10:03:39 --> Loader Class Initialized
INFO - 2016-10-28 10:03:39 --> Helper loaded: url_helper
INFO - 2016-10-28 10:03:39 --> Helper loaded: form_helper
INFO - 2016-10-28 10:03:39 --> Database Driver Class Initialized
INFO - 2016-10-28 10:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:03:39 --> Controller Class Initialized
DEBUG - 2016-10-28 10:03:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 10:03:39 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 10:03:39 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 10:03:39 --> Config Class Initialized
INFO - 2016-10-28 10:03:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:03:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:03:39 --> Utf8 Class Initialized
INFO - 2016-10-28 10:03:39 --> URI Class Initialized
DEBUG - 2016-10-28 10:03:39 --> No URI present. Default controller set.
INFO - 2016-10-28 10:03:39 --> Router Class Initialized
INFO - 2016-10-28 10:03:39 --> Output Class Initialized
INFO - 2016-10-28 10:03:39 --> Security Class Initialized
DEBUG - 2016-10-28 10:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:03:39 --> Input Class Initialized
INFO - 2016-10-28 10:03:39 --> Language Class Initialized
INFO - 2016-10-28 10:03:39 --> Loader Class Initialized
INFO - 2016-10-28 10:03:39 --> Helper loaded: url_helper
INFO - 2016-10-28 10:03:39 --> Helper loaded: form_helper
INFO - 2016-10-28 10:03:39 --> Database Driver Class Initialized
INFO - 2016-10-28 10:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:03:39 --> Controller Class Initialized
INFO - 2016-10-28 10:03:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:03:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 10:03:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:03:39 --> Final output sent to browser
DEBUG - 2016-10-28 10:03:39 --> Total execution time: 0.0154
INFO - 2016-10-28 10:03:46 --> Config Class Initialized
INFO - 2016-10-28 10:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:03:46 --> Utf8 Class Initialized
INFO - 2016-10-28 10:03:46 --> URI Class Initialized
INFO - 2016-10-28 10:03:46 --> Router Class Initialized
INFO - 2016-10-28 10:03:46 --> Output Class Initialized
INFO - 2016-10-28 10:03:46 --> Security Class Initialized
DEBUG - 2016-10-28 10:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:03:46 --> Input Class Initialized
INFO - 2016-10-28 10:03:46 --> Language Class Initialized
INFO - 2016-10-28 10:03:46 --> Loader Class Initialized
INFO - 2016-10-28 10:03:46 --> Helper loaded: url_helper
INFO - 2016-10-28 10:03:46 --> Helper loaded: form_helper
INFO - 2016-10-28 10:03:46 --> Database Driver Class Initialized
INFO - 2016-10-28 10:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:03:46 --> Controller Class Initialized
DEBUG - 2016-10-28 10:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 10:03:46 --> Model Class Initialized
INFO - 2016-10-28 10:03:46 --> Final output sent to browser
DEBUG - 2016-10-28 10:03:46 --> Total execution time: 0.0176
INFO - 2016-10-28 10:03:46 --> Config Class Initialized
INFO - 2016-10-28 10:03:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 10:03:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 10:03:46 --> Utf8 Class Initialized
INFO - 2016-10-28 10:03:46 --> URI Class Initialized
DEBUG - 2016-10-28 10:03:46 --> No URI present. Default controller set.
INFO - 2016-10-28 10:03:46 --> Router Class Initialized
INFO - 2016-10-28 10:03:46 --> Output Class Initialized
INFO - 2016-10-28 10:03:46 --> Security Class Initialized
DEBUG - 2016-10-28 10:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 10:03:46 --> Input Class Initialized
INFO - 2016-10-28 10:03:46 --> Language Class Initialized
INFO - 2016-10-28 10:03:46 --> Loader Class Initialized
INFO - 2016-10-28 10:03:46 --> Helper loaded: url_helper
INFO - 2016-10-28 10:03:46 --> Helper loaded: form_helper
INFO - 2016-10-28 10:03:46 --> Database Driver Class Initialized
INFO - 2016-10-28 10:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 10:03:46 --> Controller Class Initialized
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 10:03:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 10:03:46 --> Final output sent to browser
DEBUG - 2016-10-28 10:03:46 --> Total execution time: 0.0164
INFO - 2016-10-28 11:01:22 --> Config Class Initialized
INFO - 2016-10-28 11:01:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:01:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:01:22 --> Utf8 Class Initialized
INFO - 2016-10-28 11:01:22 --> URI Class Initialized
DEBUG - 2016-10-28 11:01:22 --> No URI present. Default controller set.
INFO - 2016-10-28 11:01:22 --> Router Class Initialized
INFO - 2016-10-28 11:01:22 --> Output Class Initialized
INFO - 2016-10-28 11:01:22 --> Security Class Initialized
DEBUG - 2016-10-28 11:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:01:22 --> Input Class Initialized
INFO - 2016-10-28 11:01:22 --> Language Class Initialized
INFO - 2016-10-28 11:01:22 --> Loader Class Initialized
INFO - 2016-10-28 11:01:22 --> Helper loaded: url_helper
INFO - 2016-10-28 11:01:22 --> Helper loaded: form_helper
INFO - 2016-10-28 11:01:22 --> Database Driver Class Initialized
INFO - 2016-10-28 11:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:01:22 --> Controller Class Initialized
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:01:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:01:22 --> Final output sent to browser
DEBUG - 2016-10-28 11:01:22 --> Total execution time: 0.0178
INFO - 2016-10-28 11:02:20 --> Config Class Initialized
INFO - 2016-10-28 11:02:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:20 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:20 --> URI Class Initialized
DEBUG - 2016-10-28 11:02:20 --> No URI present. Default controller set.
INFO - 2016-10-28 11:02:20 --> Router Class Initialized
INFO - 2016-10-28 11:02:20 --> Output Class Initialized
INFO - 2016-10-28 11:02:20 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:20 --> Input Class Initialized
INFO - 2016-10-28 11:02:20 --> Language Class Initialized
INFO - 2016-10-28 11:02:20 --> Loader Class Initialized
INFO - 2016-10-28 11:02:20 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:20 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:20 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:20 --> Controller Class Initialized
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:02:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:02:20 --> Final output sent to browser
DEBUG - 2016-10-28 11:02:20 --> Total execution time: 0.0172
INFO - 2016-10-28 11:02:21 --> Config Class Initialized
INFO - 2016-10-28 11:02:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:21 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:21 --> URI Class Initialized
DEBUG - 2016-10-28 11:02:21 --> No URI present. Default controller set.
INFO - 2016-10-28 11:02:21 --> Router Class Initialized
INFO - 2016-10-28 11:02:21 --> Output Class Initialized
INFO - 2016-10-28 11:02:21 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:21 --> Input Class Initialized
INFO - 2016-10-28 11:02:21 --> Language Class Initialized
INFO - 2016-10-28 11:02:21 --> Loader Class Initialized
INFO - 2016-10-28 11:02:21 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:21 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:21 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:21 --> Controller Class Initialized
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:02:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:02:21 --> Final output sent to browser
DEBUG - 2016-10-28 11:02:21 --> Total execution time: 0.0177
INFO - 2016-10-28 11:02:22 --> Config Class Initialized
INFO - 2016-10-28 11:02:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:22 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:22 --> URI Class Initialized
INFO - 2016-10-28 11:02:22 --> Router Class Initialized
INFO - 2016-10-28 11:02:22 --> Output Class Initialized
INFO - 2016-10-28 11:02:22 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:22 --> Input Class Initialized
INFO - 2016-10-28 11:02:22 --> Language Class Initialized
INFO - 2016-10-28 11:02:22 --> Loader Class Initialized
INFO - 2016-10-28 11:02:22 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:22 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:22 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:22 --> Controller Class Initialized
DEBUG - 2016-10-28 11:02:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 11:02:22 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 11:02:22 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 11:02:22 --> Config Class Initialized
INFO - 2016-10-28 11:02:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:22 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:22 --> URI Class Initialized
DEBUG - 2016-10-28 11:02:22 --> No URI present. Default controller set.
INFO - 2016-10-28 11:02:22 --> Router Class Initialized
INFO - 2016-10-28 11:02:22 --> Output Class Initialized
INFO - 2016-10-28 11:02:22 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:22 --> Input Class Initialized
INFO - 2016-10-28 11:02:22 --> Language Class Initialized
INFO - 2016-10-28 11:02:22 --> Loader Class Initialized
INFO - 2016-10-28 11:02:22 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:22 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:22 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:22 --> Controller Class Initialized
INFO - 2016-10-28 11:02:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:02:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:02:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:02:22 --> Final output sent to browser
DEBUG - 2016-10-28 11:02:22 --> Total execution time: 0.0149
INFO - 2016-10-28 11:02:31 --> Config Class Initialized
INFO - 2016-10-28 11:02:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:31 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:31 --> URI Class Initialized
INFO - 2016-10-28 11:02:31 --> Router Class Initialized
INFO - 2016-10-28 11:02:31 --> Output Class Initialized
INFO - 2016-10-28 11:02:31 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:31 --> Input Class Initialized
INFO - 2016-10-28 11:02:31 --> Language Class Initialized
INFO - 2016-10-28 11:02:31 --> Loader Class Initialized
INFO - 2016-10-28 11:02:31 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:31 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:31 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:31 --> Controller Class Initialized
DEBUG - 2016-10-28 11:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:02:31 --> Model Class Initialized
ERROR - 2016-10-28 11:02:31 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 11:02:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:02:41 --> Config Class Initialized
INFO - 2016-10-28 11:02:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:41 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:41 --> URI Class Initialized
DEBUG - 2016-10-28 11:02:41 --> No URI present. Default controller set.
INFO - 2016-10-28 11:02:41 --> Router Class Initialized
INFO - 2016-10-28 11:02:41 --> Output Class Initialized
INFO - 2016-10-28 11:02:41 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:41 --> Input Class Initialized
INFO - 2016-10-28 11:02:41 --> Language Class Initialized
INFO - 2016-10-28 11:02:41 --> Loader Class Initialized
INFO - 2016-10-28 11:02:41 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:41 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:41 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:41 --> Controller Class Initialized
INFO - 2016-10-28 11:02:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:02:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:02:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:02:41 --> Final output sent to browser
DEBUG - 2016-10-28 11:02:41 --> Total execution time: 0.0159
INFO - 2016-10-28 11:02:41 --> Config Class Initialized
INFO - 2016-10-28 11:02:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:41 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:41 --> URI Class Initialized
DEBUG - 2016-10-28 11:02:41 --> No URI present. Default controller set.
INFO - 2016-10-28 11:02:41 --> Router Class Initialized
INFO - 2016-10-28 11:02:41 --> Output Class Initialized
INFO - 2016-10-28 11:02:41 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:41 --> Input Class Initialized
INFO - 2016-10-28 11:02:41 --> Language Class Initialized
INFO - 2016-10-28 11:02:41 --> Loader Class Initialized
INFO - 2016-10-28 11:02:41 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:41 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:41 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:41 --> Controller Class Initialized
INFO - 2016-10-28 11:02:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:02:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:02:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:02:41 --> Final output sent to browser
DEBUG - 2016-10-28 11:02:41 --> Total execution time: 0.0156
INFO - 2016-10-28 11:02:49 --> Config Class Initialized
INFO - 2016-10-28 11:02:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:49 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:49 --> URI Class Initialized
INFO - 2016-10-28 11:02:49 --> Router Class Initialized
INFO - 2016-10-28 11:02:49 --> Output Class Initialized
INFO - 2016-10-28 11:02:49 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:49 --> Input Class Initialized
INFO - 2016-10-28 11:02:49 --> Language Class Initialized
INFO - 2016-10-28 11:02:49 --> Loader Class Initialized
INFO - 2016-10-28 11:02:49 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:49 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:49 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:49 --> Controller Class Initialized
DEBUG - 2016-10-28 11:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:02:49 --> Model Class Initialized
ERROR - 2016-10-28 11:02:49 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 11:02:49 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:02:54 --> Config Class Initialized
INFO - 2016-10-28 11:02:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:02:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:02:54 --> Utf8 Class Initialized
INFO - 2016-10-28 11:02:54 --> URI Class Initialized
DEBUG - 2016-10-28 11:02:54 --> No URI present. Default controller set.
INFO - 2016-10-28 11:02:54 --> Router Class Initialized
INFO - 2016-10-28 11:02:54 --> Output Class Initialized
INFO - 2016-10-28 11:02:54 --> Security Class Initialized
DEBUG - 2016-10-28 11:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:02:54 --> Input Class Initialized
INFO - 2016-10-28 11:02:54 --> Language Class Initialized
INFO - 2016-10-28 11:02:54 --> Loader Class Initialized
INFO - 2016-10-28 11:02:54 --> Helper loaded: url_helper
INFO - 2016-10-28 11:02:54 --> Helper loaded: form_helper
INFO - 2016-10-28 11:02:54 --> Database Driver Class Initialized
INFO - 2016-10-28 11:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:02:54 --> Controller Class Initialized
INFO - 2016-10-28 11:02:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:02:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:02:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:02:54 --> Final output sent to browser
DEBUG - 2016-10-28 11:02:54 --> Total execution time: 0.0158
INFO - 2016-10-28 11:04:40 --> Config Class Initialized
INFO - 2016-10-28 11:04:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:04:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:04:40 --> Utf8 Class Initialized
INFO - 2016-10-28 11:04:40 --> URI Class Initialized
DEBUG - 2016-10-28 11:04:40 --> No URI present. Default controller set.
INFO - 2016-10-28 11:04:40 --> Router Class Initialized
INFO - 2016-10-28 11:04:40 --> Output Class Initialized
INFO - 2016-10-28 11:04:40 --> Security Class Initialized
DEBUG - 2016-10-28 11:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:04:40 --> Input Class Initialized
INFO - 2016-10-28 11:04:40 --> Language Class Initialized
INFO - 2016-10-28 11:04:40 --> Loader Class Initialized
INFO - 2016-10-28 11:04:40 --> Helper loaded: url_helper
INFO - 2016-10-28 11:04:40 --> Helper loaded: form_helper
INFO - 2016-10-28 11:04:40 --> Database Driver Class Initialized
INFO - 2016-10-28 11:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:04:40 --> Controller Class Initialized
INFO - 2016-10-28 11:04:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:04:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:04:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:04:40 --> Final output sent to browser
DEBUG - 2016-10-28 11:04:40 --> Total execution time: 0.0199
INFO - 2016-10-28 11:04:45 --> Config Class Initialized
INFO - 2016-10-28 11:04:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:04:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:04:45 --> Utf8 Class Initialized
INFO - 2016-10-28 11:04:45 --> URI Class Initialized
INFO - 2016-10-28 11:04:45 --> Router Class Initialized
INFO - 2016-10-28 11:04:45 --> Output Class Initialized
INFO - 2016-10-28 11:04:45 --> Security Class Initialized
DEBUG - 2016-10-28 11:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:04:45 --> Input Class Initialized
INFO - 2016-10-28 11:04:45 --> Language Class Initialized
INFO - 2016-10-28 11:04:45 --> Loader Class Initialized
INFO - 2016-10-28 11:04:45 --> Helper loaded: url_helper
INFO - 2016-10-28 11:04:45 --> Helper loaded: form_helper
INFO - 2016-10-28 11:04:45 --> Database Driver Class Initialized
INFO - 2016-10-28 11:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:04:45 --> Controller Class Initialized
DEBUG - 2016-10-28 11:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:04:45 --> Model Class Initialized
ERROR - 2016-10-28 11:04:45 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 11:04:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:04:50 --> Config Class Initialized
INFO - 2016-10-28 11:04:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:04:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:04:50 --> Utf8 Class Initialized
INFO - 2016-10-28 11:04:50 --> URI Class Initialized
DEBUG - 2016-10-28 11:04:50 --> No URI present. Default controller set.
INFO - 2016-10-28 11:04:50 --> Router Class Initialized
INFO - 2016-10-28 11:04:50 --> Output Class Initialized
INFO - 2016-10-28 11:04:50 --> Security Class Initialized
DEBUG - 2016-10-28 11:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:04:50 --> Input Class Initialized
INFO - 2016-10-28 11:04:50 --> Language Class Initialized
INFO - 2016-10-28 11:04:50 --> Loader Class Initialized
INFO - 2016-10-28 11:04:50 --> Helper loaded: url_helper
INFO - 2016-10-28 11:04:50 --> Helper loaded: form_helper
INFO - 2016-10-28 11:04:50 --> Database Driver Class Initialized
INFO - 2016-10-28 11:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:04:50 --> Controller Class Initialized
INFO - 2016-10-28 11:04:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:04:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:04:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:04:50 --> Final output sent to browser
DEBUG - 2016-10-28 11:04:50 --> Total execution time: 0.0160
INFO - 2016-10-28 11:05:46 --> Config Class Initialized
INFO - 2016-10-28 11:05:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:05:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:05:46 --> Utf8 Class Initialized
INFO - 2016-10-28 11:05:46 --> URI Class Initialized
DEBUG - 2016-10-28 11:05:46 --> No URI present. Default controller set.
INFO - 2016-10-28 11:05:46 --> Router Class Initialized
INFO - 2016-10-28 11:05:46 --> Output Class Initialized
INFO - 2016-10-28 11:05:46 --> Security Class Initialized
DEBUG - 2016-10-28 11:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:05:46 --> Input Class Initialized
INFO - 2016-10-28 11:05:46 --> Language Class Initialized
INFO - 2016-10-28 11:05:46 --> Loader Class Initialized
INFO - 2016-10-28 11:05:46 --> Helper loaded: url_helper
INFO - 2016-10-28 11:05:46 --> Helper loaded: form_helper
INFO - 2016-10-28 11:05:46 --> Database Driver Class Initialized
INFO - 2016-10-28 11:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:05:46 --> Controller Class Initialized
INFO - 2016-10-28 11:05:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:05:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:05:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:05:46 --> Final output sent to browser
DEBUG - 2016-10-28 11:05:46 --> Total execution time: 0.0184
INFO - 2016-10-28 11:05:47 --> Config Class Initialized
INFO - 2016-10-28 11:05:47 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:05:47 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:05:47 --> Utf8 Class Initialized
INFO - 2016-10-28 11:05:47 --> URI Class Initialized
DEBUG - 2016-10-28 11:05:47 --> No URI present. Default controller set.
INFO - 2016-10-28 11:05:47 --> Router Class Initialized
INFO - 2016-10-28 11:05:47 --> Output Class Initialized
INFO - 2016-10-28 11:05:47 --> Security Class Initialized
DEBUG - 2016-10-28 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:05:47 --> Input Class Initialized
INFO - 2016-10-28 11:05:47 --> Language Class Initialized
INFO - 2016-10-28 11:05:47 --> Loader Class Initialized
INFO - 2016-10-28 11:05:47 --> Helper loaded: url_helper
INFO - 2016-10-28 11:05:47 --> Helper loaded: form_helper
INFO - 2016-10-28 11:05:47 --> Database Driver Class Initialized
INFO - 2016-10-28 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:05:47 --> Controller Class Initialized
INFO - 2016-10-28 11:05:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:05:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:05:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:05:47 --> Final output sent to browser
DEBUG - 2016-10-28 11:05:47 --> Total execution time: 0.0153
INFO - 2016-10-28 11:05:47 --> Config Class Initialized
INFO - 2016-10-28 11:05:47 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:05:47 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:05:47 --> Utf8 Class Initialized
INFO - 2016-10-28 11:05:47 --> URI Class Initialized
DEBUG - 2016-10-28 11:05:47 --> No URI present. Default controller set.
INFO - 2016-10-28 11:05:47 --> Router Class Initialized
INFO - 2016-10-28 11:05:47 --> Output Class Initialized
INFO - 2016-10-28 11:05:47 --> Security Class Initialized
DEBUG - 2016-10-28 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:05:47 --> Input Class Initialized
INFO - 2016-10-28 11:05:47 --> Language Class Initialized
INFO - 2016-10-28 11:05:47 --> Loader Class Initialized
INFO - 2016-10-28 11:05:47 --> Helper loaded: url_helper
INFO - 2016-10-28 11:05:47 --> Helper loaded: form_helper
INFO - 2016-10-28 11:05:47 --> Database Driver Class Initialized
INFO - 2016-10-28 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:05:47 --> Controller Class Initialized
INFO - 2016-10-28 11:05:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:05:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:05:47 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:05:47 --> Final output sent to browser
DEBUG - 2016-10-28 11:05:47 --> Total execution time: 0.0148
INFO - 2016-10-28 11:05:52 --> Config Class Initialized
INFO - 2016-10-28 11:05:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:05:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:05:52 --> Utf8 Class Initialized
INFO - 2016-10-28 11:05:52 --> URI Class Initialized
INFO - 2016-10-28 11:05:52 --> Router Class Initialized
INFO - 2016-10-28 11:05:52 --> Output Class Initialized
INFO - 2016-10-28 11:05:52 --> Security Class Initialized
DEBUG - 2016-10-28 11:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:05:52 --> Input Class Initialized
INFO - 2016-10-28 11:05:52 --> Language Class Initialized
INFO - 2016-10-28 11:05:52 --> Loader Class Initialized
INFO - 2016-10-28 11:05:52 --> Helper loaded: url_helper
INFO - 2016-10-28 11:05:52 --> Helper loaded: form_helper
INFO - 2016-10-28 11:05:52 --> Database Driver Class Initialized
INFO - 2016-10-28 11:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:05:52 --> Controller Class Initialized
DEBUG - 2016-10-28 11:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:05:52 --> Model Class Initialized
ERROR - 2016-10-28 11:05:52 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'admin'
AND `password` = '96030e9251c18b03cd00245bcafed2263f21249c'
INFO - 2016-10-28 11:05:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:05:57 --> Config Class Initialized
INFO - 2016-10-28 11:05:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:05:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:05:57 --> Utf8 Class Initialized
INFO - 2016-10-28 11:05:57 --> URI Class Initialized
DEBUG - 2016-10-28 11:05:57 --> No URI present. Default controller set.
INFO - 2016-10-28 11:05:57 --> Router Class Initialized
INFO - 2016-10-28 11:05:57 --> Output Class Initialized
INFO - 2016-10-28 11:05:57 --> Security Class Initialized
DEBUG - 2016-10-28 11:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:05:57 --> Input Class Initialized
INFO - 2016-10-28 11:05:57 --> Language Class Initialized
INFO - 2016-10-28 11:05:57 --> Loader Class Initialized
INFO - 2016-10-28 11:05:57 --> Helper loaded: url_helper
INFO - 2016-10-28 11:05:57 --> Helper loaded: form_helper
INFO - 2016-10-28 11:05:57 --> Database Driver Class Initialized
INFO - 2016-10-28 11:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:05:57 --> Controller Class Initialized
INFO - 2016-10-28 11:05:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:05:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:05:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:05:57 --> Final output sent to browser
DEBUG - 2016-10-28 11:05:57 --> Total execution time: 0.0163
INFO - 2016-10-28 11:07:00 --> Config Class Initialized
INFO - 2016-10-28 11:07:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:07:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:07:00 --> Utf8 Class Initialized
INFO - 2016-10-28 11:07:00 --> URI Class Initialized
DEBUG - 2016-10-28 11:07:00 --> No URI present. Default controller set.
INFO - 2016-10-28 11:07:00 --> Router Class Initialized
INFO - 2016-10-28 11:07:00 --> Output Class Initialized
INFO - 2016-10-28 11:07:00 --> Security Class Initialized
DEBUG - 2016-10-28 11:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:07:00 --> Input Class Initialized
INFO - 2016-10-28 11:07:00 --> Language Class Initialized
INFO - 2016-10-28 11:07:00 --> Loader Class Initialized
INFO - 2016-10-28 11:07:00 --> Helper loaded: url_helper
INFO - 2016-10-28 11:07:00 --> Helper loaded: form_helper
INFO - 2016-10-28 11:07:00 --> Database Driver Class Initialized
INFO - 2016-10-28 11:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:07:00 --> Controller Class Initialized
INFO - 2016-10-28 11:07:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:07:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:07:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:07:00 --> Final output sent to browser
DEBUG - 2016-10-28 11:07:00 --> Total execution time: 0.0168
INFO - 2016-10-28 11:07:09 --> Config Class Initialized
INFO - 2016-10-28 11:07:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:07:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:07:09 --> Utf8 Class Initialized
INFO - 2016-10-28 11:07:09 --> URI Class Initialized
INFO - 2016-10-28 11:07:09 --> Router Class Initialized
INFO - 2016-10-28 11:07:09 --> Output Class Initialized
INFO - 2016-10-28 11:07:09 --> Security Class Initialized
DEBUG - 2016-10-28 11:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:07:09 --> Input Class Initialized
INFO - 2016-10-28 11:07:09 --> Language Class Initialized
INFO - 2016-10-28 11:07:09 --> Loader Class Initialized
INFO - 2016-10-28 11:07:09 --> Helper loaded: url_helper
INFO - 2016-10-28 11:07:09 --> Helper loaded: form_helper
INFO - 2016-10-28 11:07:09 --> Database Driver Class Initialized
INFO - 2016-10-28 11:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:07:09 --> Controller Class Initialized
DEBUG - 2016-10-28 11:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:07:09 --> Model Class Initialized
ERROR - 2016-10-28 11:07:09 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 11:07:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:07:16 --> Config Class Initialized
INFO - 2016-10-28 11:07:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:07:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:07:16 --> Utf8 Class Initialized
INFO - 2016-10-28 11:07:16 --> URI Class Initialized
DEBUG - 2016-10-28 11:07:16 --> No URI present. Default controller set.
INFO - 2016-10-28 11:07:16 --> Router Class Initialized
INFO - 2016-10-28 11:07:16 --> Output Class Initialized
INFO - 2016-10-28 11:07:16 --> Security Class Initialized
DEBUG - 2016-10-28 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:07:16 --> Input Class Initialized
INFO - 2016-10-28 11:07:16 --> Language Class Initialized
INFO - 2016-10-28 11:07:16 --> Loader Class Initialized
INFO - 2016-10-28 11:07:16 --> Helper loaded: url_helper
INFO - 2016-10-28 11:07:16 --> Helper loaded: form_helper
INFO - 2016-10-28 11:07:16 --> Database Driver Class Initialized
INFO - 2016-10-28 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:07:16 --> Controller Class Initialized
INFO - 2016-10-28 11:07:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:07:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:07:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:07:16 --> Final output sent to browser
DEBUG - 2016-10-28 11:07:16 --> Total execution time: 0.0169
INFO - 2016-10-28 11:07:23 --> Config Class Initialized
INFO - 2016-10-28 11:07:23 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:07:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:07:23 --> Utf8 Class Initialized
INFO - 2016-10-28 11:07:23 --> URI Class Initialized
INFO - 2016-10-28 11:07:23 --> Router Class Initialized
INFO - 2016-10-28 11:07:23 --> Output Class Initialized
INFO - 2016-10-28 11:07:23 --> Security Class Initialized
DEBUG - 2016-10-28 11:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:07:23 --> Input Class Initialized
INFO - 2016-10-28 11:07:23 --> Language Class Initialized
INFO - 2016-10-28 11:07:23 --> Loader Class Initialized
INFO - 2016-10-28 11:07:23 --> Helper loaded: url_helper
INFO - 2016-10-28 11:07:23 --> Helper loaded: form_helper
INFO - 2016-10-28 11:07:23 --> Database Driver Class Initialized
INFO - 2016-10-28 11:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:07:23 --> Controller Class Initialized
DEBUG - 2016-10-28 11:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:07:23 --> Model Class Initialized
ERROR - 2016-10-28 11:07:23 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 11:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:08:27 --> Config Class Initialized
INFO - 2016-10-28 11:08:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:08:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:08:27 --> Utf8 Class Initialized
INFO - 2016-10-28 11:08:27 --> URI Class Initialized
DEBUG - 2016-10-28 11:08:27 --> No URI present. Default controller set.
INFO - 2016-10-28 11:08:27 --> Router Class Initialized
INFO - 2016-10-28 11:08:27 --> Output Class Initialized
INFO - 2016-10-28 11:08:27 --> Security Class Initialized
DEBUG - 2016-10-28 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:08:27 --> Input Class Initialized
INFO - 2016-10-28 11:08:27 --> Language Class Initialized
INFO - 2016-10-28 11:08:27 --> Loader Class Initialized
INFO - 2016-10-28 11:08:27 --> Helper loaded: url_helper
INFO - 2016-10-28 11:08:27 --> Helper loaded: form_helper
INFO - 2016-10-28 11:08:27 --> Database Driver Class Initialized
INFO - 2016-10-28 11:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:08:27 --> Controller Class Initialized
INFO - 2016-10-28 11:08:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:08:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:08:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:08:27 --> Final output sent to browser
DEBUG - 2016-10-28 11:08:27 --> Total execution time: 0.0168
INFO - 2016-10-28 11:08:33 --> Config Class Initialized
INFO - 2016-10-28 11:08:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:08:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:08:33 --> Utf8 Class Initialized
INFO - 2016-10-28 11:08:33 --> URI Class Initialized
INFO - 2016-10-28 11:08:33 --> Router Class Initialized
INFO - 2016-10-28 11:08:33 --> Output Class Initialized
INFO - 2016-10-28 11:08:33 --> Security Class Initialized
DEBUG - 2016-10-28 11:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:08:33 --> Input Class Initialized
INFO - 2016-10-28 11:08:33 --> Language Class Initialized
INFO - 2016-10-28 11:08:33 --> Loader Class Initialized
INFO - 2016-10-28 11:08:33 --> Helper loaded: url_helper
INFO - 2016-10-28 11:08:33 --> Helper loaded: form_helper
INFO - 2016-10-28 11:08:33 --> Database Driver Class Initialized
INFO - 2016-10-28 11:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:08:33 --> Controller Class Initialized
DEBUG - 2016-10-28 11:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:08:33 --> Model Class Initialized
ERROR - 2016-10-28 11:08:33 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 11:08:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:08:34 --> Config Class Initialized
INFO - 2016-10-28 11:08:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:08:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:08:34 --> Utf8 Class Initialized
INFO - 2016-10-28 11:08:34 --> URI Class Initialized
DEBUG - 2016-10-28 11:08:34 --> No URI present. Default controller set.
INFO - 2016-10-28 11:08:34 --> Router Class Initialized
INFO - 2016-10-28 11:08:34 --> Output Class Initialized
INFO - 2016-10-28 11:08:34 --> Security Class Initialized
DEBUG - 2016-10-28 11:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:08:34 --> Input Class Initialized
INFO - 2016-10-28 11:08:34 --> Language Class Initialized
INFO - 2016-10-28 11:08:34 --> Loader Class Initialized
INFO - 2016-10-28 11:08:34 --> Helper loaded: url_helper
INFO - 2016-10-28 11:08:34 --> Helper loaded: form_helper
INFO - 2016-10-28 11:08:34 --> Database Driver Class Initialized
INFO - 2016-10-28 11:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:08:34 --> Controller Class Initialized
INFO - 2016-10-28 11:08:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:08:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:08:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:08:34 --> Final output sent to browser
DEBUG - 2016-10-28 11:08:34 --> Total execution time: 0.0168
INFO - 2016-10-28 11:08:37 --> Config Class Initialized
INFO - 2016-10-28 11:08:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:08:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:08:37 --> Utf8 Class Initialized
INFO - 2016-10-28 11:08:37 --> URI Class Initialized
DEBUG - 2016-10-28 11:08:37 --> No URI present. Default controller set.
INFO - 2016-10-28 11:08:37 --> Router Class Initialized
INFO - 2016-10-28 11:08:37 --> Output Class Initialized
INFO - 2016-10-28 11:08:37 --> Security Class Initialized
DEBUG - 2016-10-28 11:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:08:37 --> Input Class Initialized
INFO - 2016-10-28 11:08:37 --> Language Class Initialized
INFO - 2016-10-28 11:08:37 --> Loader Class Initialized
INFO - 2016-10-28 11:08:37 --> Helper loaded: url_helper
INFO - 2016-10-28 11:08:37 --> Helper loaded: form_helper
INFO - 2016-10-28 11:08:37 --> Database Driver Class Initialized
INFO - 2016-10-28 11:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:08:37 --> Controller Class Initialized
INFO - 2016-10-28 11:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:08:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:08:37 --> Final output sent to browser
DEBUG - 2016-10-28 11:08:37 --> Total execution time: 0.0167
INFO - 2016-10-28 11:09:12 --> Config Class Initialized
INFO - 2016-10-28 11:09:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:09:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:09:12 --> Utf8 Class Initialized
INFO - 2016-10-28 11:09:12 --> URI Class Initialized
DEBUG - 2016-10-28 11:09:12 --> No URI present. Default controller set.
INFO - 2016-10-28 11:09:12 --> Router Class Initialized
INFO - 2016-10-28 11:09:12 --> Output Class Initialized
INFO - 2016-10-28 11:09:12 --> Security Class Initialized
DEBUG - 2016-10-28 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:09:12 --> Input Class Initialized
INFO - 2016-10-28 11:09:12 --> Language Class Initialized
INFO - 2016-10-28 11:09:12 --> Loader Class Initialized
INFO - 2016-10-28 11:09:12 --> Helper loaded: url_helper
INFO - 2016-10-28 11:09:12 --> Helper loaded: form_helper
INFO - 2016-10-28 11:09:12 --> Database Driver Class Initialized
INFO - 2016-10-28 11:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:09:12 --> Controller Class Initialized
INFO - 2016-10-28 11:09:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:09:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:09:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:09:12 --> Final output sent to browser
DEBUG - 2016-10-28 11:09:12 --> Total execution time: 0.0165
INFO - 2016-10-28 11:09:16 --> Config Class Initialized
INFO - 2016-10-28 11:09:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:09:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:09:16 --> Utf8 Class Initialized
INFO - 2016-10-28 11:09:16 --> URI Class Initialized
INFO - 2016-10-28 11:09:16 --> Router Class Initialized
INFO - 2016-10-28 11:09:16 --> Output Class Initialized
INFO - 2016-10-28 11:09:16 --> Security Class Initialized
DEBUG - 2016-10-28 11:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:09:16 --> Input Class Initialized
INFO - 2016-10-28 11:09:16 --> Language Class Initialized
INFO - 2016-10-28 11:09:16 --> Loader Class Initialized
INFO - 2016-10-28 11:09:16 --> Helper loaded: url_helper
INFO - 2016-10-28 11:09:16 --> Helper loaded: form_helper
INFO - 2016-10-28 11:09:16 --> Database Driver Class Initialized
INFO - 2016-10-28 11:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:09:16 --> Controller Class Initialized
DEBUG - 2016-10-28 11:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:09:16 --> Model Class Initialized
ERROR - 2016-10-28 11:09:16 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'gdf'
AND `password` = 'fc2d7264556871c09fc97e2751d528cd14752fdc'
INFO - 2016-10-28 11:09:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:09:18 --> Config Class Initialized
INFO - 2016-10-28 11:09:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:09:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:09:18 --> Utf8 Class Initialized
INFO - 2016-10-28 11:09:18 --> URI Class Initialized
DEBUG - 2016-10-28 11:09:18 --> No URI present. Default controller set.
INFO - 2016-10-28 11:09:18 --> Router Class Initialized
INFO - 2016-10-28 11:09:18 --> Output Class Initialized
INFO - 2016-10-28 11:09:18 --> Security Class Initialized
DEBUG - 2016-10-28 11:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:09:18 --> Input Class Initialized
INFO - 2016-10-28 11:09:18 --> Language Class Initialized
INFO - 2016-10-28 11:09:18 --> Loader Class Initialized
INFO - 2016-10-28 11:09:18 --> Helper loaded: url_helper
INFO - 2016-10-28 11:09:18 --> Helper loaded: form_helper
INFO - 2016-10-28 11:09:18 --> Database Driver Class Initialized
INFO - 2016-10-28 11:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:09:18 --> Controller Class Initialized
INFO - 2016-10-28 11:09:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:09:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:09:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:09:18 --> Final output sent to browser
DEBUG - 2016-10-28 11:09:18 --> Total execution time: 0.0167
INFO - 2016-10-28 11:09:20 --> Config Class Initialized
INFO - 2016-10-28 11:09:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:09:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:09:20 --> Utf8 Class Initialized
INFO - 2016-10-28 11:09:20 --> URI Class Initialized
INFO - 2016-10-28 11:09:20 --> Router Class Initialized
INFO - 2016-10-28 11:09:20 --> Output Class Initialized
INFO - 2016-10-28 11:09:20 --> Security Class Initialized
DEBUG - 2016-10-28 11:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:09:20 --> Input Class Initialized
INFO - 2016-10-28 11:09:20 --> Language Class Initialized
INFO - 2016-10-28 11:09:20 --> Loader Class Initialized
INFO - 2016-10-28 11:09:20 --> Helper loaded: url_helper
INFO - 2016-10-28 11:09:20 --> Helper loaded: form_helper
INFO - 2016-10-28 11:09:20 --> Database Driver Class Initialized
INFO - 2016-10-28 11:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:09:20 --> Controller Class Initialized
DEBUG - 2016-10-28 11:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:09:20 --> Model Class Initialized
ERROR - 2016-10-28 11:09:20 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'dhdg'
AND `password` = 'b4699e1334e0f913e58c26c2ab47212e61b388f8'
INFO - 2016-10-28 11:09:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:09:32 --> Config Class Initialized
INFO - 2016-10-28 11:09:32 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:09:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:09:32 --> Utf8 Class Initialized
INFO - 2016-10-28 11:09:32 --> URI Class Initialized
DEBUG - 2016-10-28 11:09:32 --> No URI present. Default controller set.
INFO - 2016-10-28 11:09:32 --> Router Class Initialized
INFO - 2016-10-28 11:09:32 --> Output Class Initialized
INFO - 2016-10-28 11:09:32 --> Security Class Initialized
DEBUG - 2016-10-28 11:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:09:32 --> Input Class Initialized
INFO - 2016-10-28 11:09:32 --> Language Class Initialized
INFO - 2016-10-28 11:09:32 --> Loader Class Initialized
INFO - 2016-10-28 11:09:32 --> Helper loaded: url_helper
INFO - 2016-10-28 11:09:32 --> Helper loaded: form_helper
INFO - 2016-10-28 11:09:32 --> Database Driver Class Initialized
INFO - 2016-10-28 11:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:09:32 --> Controller Class Initialized
INFO - 2016-10-28 11:09:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:09:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:09:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:09:32 --> Final output sent to browser
DEBUG - 2016-10-28 11:09:32 --> Total execution time: 0.0170
INFO - 2016-10-28 11:09:54 --> Config Class Initialized
INFO - 2016-10-28 11:09:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:09:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:09:54 --> Utf8 Class Initialized
INFO - 2016-10-28 11:09:54 --> URI Class Initialized
DEBUG - 2016-10-28 11:09:54 --> No URI present. Default controller set.
INFO - 2016-10-28 11:09:54 --> Router Class Initialized
INFO - 2016-10-28 11:09:54 --> Output Class Initialized
INFO - 2016-10-28 11:09:54 --> Security Class Initialized
DEBUG - 2016-10-28 11:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:09:54 --> Input Class Initialized
INFO - 2016-10-28 11:09:54 --> Language Class Initialized
INFO - 2016-10-28 11:09:54 --> Loader Class Initialized
INFO - 2016-10-28 11:09:54 --> Helper loaded: url_helper
INFO - 2016-10-28 11:09:54 --> Helper loaded: form_helper
INFO - 2016-10-28 11:09:54 --> Database Driver Class Initialized
INFO - 2016-10-28 11:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:09:54 --> Controller Class Initialized
INFO - 2016-10-28 11:09:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
ERROR - 2016-10-28 11:09:54 --> Severity: Notice --> Undefined variable: user /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php 1
INFO - 2016-10-28 11:09:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:09:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:09:54 --> Final output sent to browser
DEBUG - 2016-10-28 11:09:54 --> Total execution time: 0.0173
INFO - 2016-10-28 11:10:09 --> Config Class Initialized
INFO - 2016-10-28 11:10:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:10:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:10:09 --> Utf8 Class Initialized
INFO - 2016-10-28 11:10:09 --> URI Class Initialized
DEBUG - 2016-10-28 11:10:09 --> No URI present. Default controller set.
INFO - 2016-10-28 11:10:09 --> Router Class Initialized
INFO - 2016-10-28 11:10:09 --> Output Class Initialized
INFO - 2016-10-28 11:10:09 --> Security Class Initialized
DEBUG - 2016-10-28 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:10:09 --> Input Class Initialized
INFO - 2016-10-28 11:10:09 --> Language Class Initialized
INFO - 2016-10-28 11:10:09 --> Loader Class Initialized
INFO - 2016-10-28 11:10:09 --> Helper loaded: url_helper
INFO - 2016-10-28 11:10:09 --> Helper loaded: form_helper
INFO - 2016-10-28 11:10:09 --> Database Driver Class Initialized
INFO - 2016-10-28 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:10:09 --> Controller Class Initialized
INFO - 2016-10-28 11:10:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:10:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:10:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:10:09 --> Final output sent to browser
DEBUG - 2016-10-28 11:10:09 --> Total execution time: 0.0167
INFO - 2016-10-28 11:11:08 --> Config Class Initialized
INFO - 2016-10-28 11:11:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:11:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:11:08 --> Utf8 Class Initialized
INFO - 2016-10-28 11:11:08 --> URI Class Initialized
DEBUG - 2016-10-28 11:11:08 --> No URI present. Default controller set.
INFO - 2016-10-28 11:11:08 --> Router Class Initialized
INFO - 2016-10-28 11:11:08 --> Output Class Initialized
INFO - 2016-10-28 11:11:08 --> Security Class Initialized
DEBUG - 2016-10-28 11:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:11:08 --> Input Class Initialized
INFO - 2016-10-28 11:11:08 --> Language Class Initialized
INFO - 2016-10-28 11:11:08 --> Loader Class Initialized
INFO - 2016-10-28 11:11:08 --> Helper loaded: url_helper
INFO - 2016-10-28 11:11:08 --> Helper loaded: form_helper
INFO - 2016-10-28 11:11:08 --> Database Driver Class Initialized
INFO - 2016-10-28 11:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:11:08 --> Controller Class Initialized
INFO - 2016-10-28 11:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:11:08 --> Final output sent to browser
DEBUG - 2016-10-28 11:11:08 --> Total execution time: 0.0173
INFO - 2016-10-28 11:11:08 --> Config Class Initialized
INFO - 2016-10-28 11:11:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:11:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:11:08 --> Utf8 Class Initialized
INFO - 2016-10-28 11:11:08 --> URI Class Initialized
DEBUG - 2016-10-28 11:11:08 --> No URI present. Default controller set.
INFO - 2016-10-28 11:11:08 --> Router Class Initialized
INFO - 2016-10-28 11:11:08 --> Output Class Initialized
INFO - 2016-10-28 11:11:08 --> Security Class Initialized
DEBUG - 2016-10-28 11:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:11:08 --> Input Class Initialized
INFO - 2016-10-28 11:11:08 --> Language Class Initialized
INFO - 2016-10-28 11:11:08 --> Loader Class Initialized
INFO - 2016-10-28 11:11:08 --> Helper loaded: url_helper
INFO - 2016-10-28 11:11:08 --> Helper loaded: form_helper
INFO - 2016-10-28 11:11:08 --> Database Driver Class Initialized
INFO - 2016-10-28 11:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:11:08 --> Controller Class Initialized
INFO - 2016-10-28 11:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:11:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:11:08 --> Final output sent to browser
DEBUG - 2016-10-28 11:11:08 --> Total execution time: 0.0158
INFO - 2016-10-28 11:11:12 --> Config Class Initialized
INFO - 2016-10-28 11:11:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:11:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:11:12 --> Utf8 Class Initialized
INFO - 2016-10-28 11:11:12 --> URI Class Initialized
INFO - 2016-10-28 11:11:12 --> Router Class Initialized
INFO - 2016-10-28 11:11:12 --> Output Class Initialized
INFO - 2016-10-28 11:11:12 --> Security Class Initialized
DEBUG - 2016-10-28 11:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:11:12 --> Input Class Initialized
INFO - 2016-10-28 11:11:12 --> Language Class Initialized
INFO - 2016-10-28 11:11:12 --> Loader Class Initialized
INFO - 2016-10-28 11:11:12 --> Helper loaded: url_helper
INFO - 2016-10-28 11:11:12 --> Helper loaded: form_helper
INFO - 2016-10-28 11:11:12 --> Database Driver Class Initialized
INFO - 2016-10-28 11:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:11:12 --> Controller Class Initialized
DEBUG - 2016-10-28 11:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:11:12 --> Model Class Initialized
ERROR - 2016-10-28 11:11:12 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'fhfh'
AND `password` = 'a6b633b6c7f842d04e7f0381e3611640791645ba'
INFO - 2016-10-28 11:11:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:11:14 --> Config Class Initialized
INFO - 2016-10-28 11:11:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:11:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:11:14 --> Utf8 Class Initialized
INFO - 2016-10-28 11:11:14 --> URI Class Initialized
DEBUG - 2016-10-28 11:11:14 --> No URI present. Default controller set.
INFO - 2016-10-28 11:11:14 --> Router Class Initialized
INFO - 2016-10-28 11:11:14 --> Output Class Initialized
INFO - 2016-10-28 11:11:14 --> Security Class Initialized
DEBUG - 2016-10-28 11:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:11:14 --> Input Class Initialized
INFO - 2016-10-28 11:11:14 --> Language Class Initialized
INFO - 2016-10-28 11:11:14 --> Loader Class Initialized
INFO - 2016-10-28 11:11:14 --> Helper loaded: url_helper
INFO - 2016-10-28 11:11:14 --> Helper loaded: form_helper
INFO - 2016-10-28 11:11:14 --> Database Driver Class Initialized
INFO - 2016-10-28 11:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:11:14 --> Controller Class Initialized
INFO - 2016-10-28 11:11:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:11:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:11:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:11:14 --> Final output sent to browser
DEBUG - 2016-10-28 11:11:14 --> Total execution time: 0.0166
INFO - 2016-10-28 11:12:51 --> Config Class Initialized
INFO - 2016-10-28 11:12:51 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:12:51 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:12:51 --> Utf8 Class Initialized
INFO - 2016-10-28 11:12:51 --> URI Class Initialized
DEBUG - 2016-10-28 11:12:51 --> No URI present. Default controller set.
INFO - 2016-10-28 11:12:51 --> Router Class Initialized
INFO - 2016-10-28 11:12:51 --> Output Class Initialized
INFO - 2016-10-28 11:12:51 --> Security Class Initialized
DEBUG - 2016-10-28 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:12:51 --> Input Class Initialized
INFO - 2016-10-28 11:12:51 --> Language Class Initialized
INFO - 2016-10-28 11:12:51 --> Loader Class Initialized
INFO - 2016-10-28 11:12:51 --> Helper loaded: url_helper
INFO - 2016-10-28 11:12:51 --> Helper loaded: form_helper
INFO - 2016-10-28 11:12:51 --> Database Driver Class Initialized
INFO - 2016-10-28 11:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:12:51 --> Controller Class Initialized
INFO - 2016-10-28 11:12:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:12:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:12:51 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:12:51 --> Final output sent to browser
DEBUG - 2016-10-28 11:12:51 --> Total execution time: 0.0164
INFO - 2016-10-28 11:12:56 --> Config Class Initialized
INFO - 2016-10-28 11:12:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:12:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:12:56 --> Utf8 Class Initialized
INFO - 2016-10-28 11:12:56 --> URI Class Initialized
INFO - 2016-10-28 11:12:56 --> Router Class Initialized
INFO - 2016-10-28 11:12:56 --> Output Class Initialized
INFO - 2016-10-28 11:12:56 --> Security Class Initialized
DEBUG - 2016-10-28 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:12:56 --> Input Class Initialized
INFO - 2016-10-28 11:12:56 --> Language Class Initialized
INFO - 2016-10-28 11:12:56 --> Loader Class Initialized
INFO - 2016-10-28 11:12:56 --> Helper loaded: url_helper
INFO - 2016-10-28 11:12:56 --> Helper loaded: form_helper
INFO - 2016-10-28 11:12:56 --> Database Driver Class Initialized
INFO - 2016-10-28 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:12:56 --> Controller Class Initialized
DEBUG - 2016-10-28 11:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:12:56 --> Model Class Initialized
ERROR - 2016-10-28 11:12:56 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'nbvnvn'
AND `password` = '58f31c1e6073207ac73edadcfd4e8b454d56dfd4'
INFO - 2016-10-28 11:12:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:13:00 --> Config Class Initialized
INFO - 2016-10-28 11:13:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:13:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:13:00 --> Utf8 Class Initialized
INFO - 2016-10-28 11:13:00 --> URI Class Initialized
DEBUG - 2016-10-28 11:13:00 --> No URI present. Default controller set.
INFO - 2016-10-28 11:13:00 --> Router Class Initialized
INFO - 2016-10-28 11:13:00 --> Output Class Initialized
INFO - 2016-10-28 11:13:00 --> Security Class Initialized
DEBUG - 2016-10-28 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:13:00 --> Input Class Initialized
INFO - 2016-10-28 11:13:00 --> Language Class Initialized
INFO - 2016-10-28 11:13:00 --> Loader Class Initialized
INFO - 2016-10-28 11:13:00 --> Helper loaded: url_helper
INFO - 2016-10-28 11:13:00 --> Helper loaded: form_helper
INFO - 2016-10-28 11:13:00 --> Database Driver Class Initialized
INFO - 2016-10-28 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:13:00 --> Controller Class Initialized
INFO - 2016-10-28 11:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:13:00 --> Final output sent to browser
DEBUG - 2016-10-28 11:13:00 --> Total execution time: 0.0169
INFO - 2016-10-28 11:15:49 --> Config Class Initialized
INFO - 2016-10-28 11:15:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:15:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:15:49 --> Utf8 Class Initialized
INFO - 2016-10-28 11:15:49 --> URI Class Initialized
DEBUG - 2016-10-28 11:15:49 --> No URI present. Default controller set.
INFO - 2016-10-28 11:15:49 --> Router Class Initialized
INFO - 2016-10-28 11:15:49 --> Output Class Initialized
INFO - 2016-10-28 11:15:49 --> Security Class Initialized
DEBUG - 2016-10-28 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:15:49 --> Input Class Initialized
INFO - 2016-10-28 11:15:49 --> Language Class Initialized
INFO - 2016-10-28 11:15:49 --> Loader Class Initialized
INFO - 2016-10-28 11:15:49 --> Helper loaded: url_helper
INFO - 2016-10-28 11:15:49 --> Helper loaded: form_helper
INFO - 2016-10-28 11:15:49 --> Database Driver Class Initialized
INFO - 2016-10-28 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:15:49 --> Controller Class Initialized
INFO - 2016-10-28 11:15:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:15:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:15:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:15:49 --> Final output sent to browser
DEBUG - 2016-10-28 11:15:49 --> Total execution time: 0.0171
INFO - 2016-10-28 11:15:50 --> Config Class Initialized
INFO - 2016-10-28 11:15:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:15:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:15:50 --> Utf8 Class Initialized
INFO - 2016-10-28 11:15:50 --> URI Class Initialized
DEBUG - 2016-10-28 11:15:50 --> No URI present. Default controller set.
INFO - 2016-10-28 11:15:50 --> Router Class Initialized
INFO - 2016-10-28 11:15:50 --> Output Class Initialized
INFO - 2016-10-28 11:15:50 --> Security Class Initialized
DEBUG - 2016-10-28 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:15:50 --> Input Class Initialized
INFO - 2016-10-28 11:15:50 --> Language Class Initialized
INFO - 2016-10-28 11:15:50 --> Loader Class Initialized
INFO - 2016-10-28 11:15:50 --> Helper loaded: url_helper
INFO - 2016-10-28 11:15:50 --> Helper loaded: form_helper
INFO - 2016-10-28 11:15:50 --> Database Driver Class Initialized
INFO - 2016-10-28 11:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:15:50 --> Controller Class Initialized
INFO - 2016-10-28 11:15:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:15:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:15:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:15:50 --> Final output sent to browser
DEBUG - 2016-10-28 11:15:50 --> Total execution time: 0.0166
INFO - 2016-10-28 11:15:53 --> Config Class Initialized
INFO - 2016-10-28 11:15:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:15:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:15:53 --> Utf8 Class Initialized
INFO - 2016-10-28 11:15:53 --> URI Class Initialized
INFO - 2016-10-28 11:15:53 --> Router Class Initialized
INFO - 2016-10-28 11:15:53 --> Output Class Initialized
INFO - 2016-10-28 11:15:53 --> Security Class Initialized
DEBUG - 2016-10-28 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:15:53 --> Input Class Initialized
INFO - 2016-10-28 11:15:53 --> Language Class Initialized
INFO - 2016-10-28 11:15:53 --> Loader Class Initialized
INFO - 2016-10-28 11:15:53 --> Helper loaded: url_helper
INFO - 2016-10-28 11:15:53 --> Helper loaded: form_helper
INFO - 2016-10-28 11:15:53 --> Database Driver Class Initialized
INFO - 2016-10-28 11:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:15:53 --> Controller Class Initialized
DEBUG - 2016-10-28 11:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:15:53 --> Model Class Initialized
ERROR - 2016-10-28 11:15:53 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'cxzczc'
AND `password` = '0a98467b6e2bad592f16c15183dd2249a4fec72d'
INFO - 2016-10-28 11:15:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:15:55 --> Config Class Initialized
INFO - 2016-10-28 11:15:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:15:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:15:55 --> Utf8 Class Initialized
INFO - 2016-10-28 11:15:55 --> URI Class Initialized
DEBUG - 2016-10-28 11:15:55 --> No URI present. Default controller set.
INFO - 2016-10-28 11:15:55 --> Router Class Initialized
INFO - 2016-10-28 11:15:55 --> Output Class Initialized
INFO - 2016-10-28 11:15:55 --> Security Class Initialized
DEBUG - 2016-10-28 11:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:15:55 --> Input Class Initialized
INFO - 2016-10-28 11:15:55 --> Language Class Initialized
INFO - 2016-10-28 11:15:55 --> Loader Class Initialized
INFO - 2016-10-28 11:15:55 --> Helper loaded: url_helper
INFO - 2016-10-28 11:15:55 --> Helper loaded: form_helper
INFO - 2016-10-28 11:15:55 --> Database Driver Class Initialized
INFO - 2016-10-28 11:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:15:55 --> Controller Class Initialized
INFO - 2016-10-28 11:15:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:15:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:15:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:15:55 --> Final output sent to browser
DEBUG - 2016-10-28 11:15:55 --> Total execution time: 0.0168
INFO - 2016-10-28 11:15:58 --> Config Class Initialized
INFO - 2016-10-28 11:15:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:15:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:15:58 --> Utf8 Class Initialized
INFO - 2016-10-28 11:15:58 --> URI Class Initialized
INFO - 2016-10-28 11:15:58 --> Router Class Initialized
INFO - 2016-10-28 11:15:58 --> Output Class Initialized
INFO - 2016-10-28 11:15:58 --> Security Class Initialized
DEBUG - 2016-10-28 11:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:15:58 --> Input Class Initialized
INFO - 2016-10-28 11:15:58 --> Language Class Initialized
INFO - 2016-10-28 11:15:58 --> Loader Class Initialized
INFO - 2016-10-28 11:15:58 --> Helper loaded: url_helper
INFO - 2016-10-28 11:15:58 --> Helper loaded: form_helper
INFO - 2016-10-28 11:15:58 --> Database Driver Class Initialized
INFO - 2016-10-28 11:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:15:58 --> Controller Class Initialized
DEBUG - 2016-10-28 11:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:15:58 --> Model Class Initialized
ERROR - 2016-10-28 11:15:58 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'xzczxc'
AND `password` = '44667ad84e4544a5f775a148581e12e4f02945bf'
INFO - 2016-10-28 11:15:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:17:03 --> Config Class Initialized
INFO - 2016-10-28 11:17:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:03 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:03 --> URI Class Initialized
DEBUG - 2016-10-28 11:17:03 --> No URI present. Default controller set.
INFO - 2016-10-28 11:17:03 --> Router Class Initialized
INFO - 2016-10-28 11:17:03 --> Output Class Initialized
INFO - 2016-10-28 11:17:03 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:03 --> Input Class Initialized
INFO - 2016-10-28 11:17:03 --> Language Class Initialized
INFO - 2016-10-28 11:17:03 --> Loader Class Initialized
INFO - 2016-10-28 11:17:03 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:03 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:03 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:03 --> Controller Class Initialized
INFO - 2016-10-28 11:17:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:17:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:17:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:17:03 --> Final output sent to browser
DEBUG - 2016-10-28 11:17:03 --> Total execution time: 0.0162
INFO - 2016-10-28 11:17:05 --> Config Class Initialized
INFO - 2016-10-28 11:17:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:05 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:05 --> URI Class Initialized
INFO - 2016-10-28 11:17:05 --> Router Class Initialized
INFO - 2016-10-28 11:17:05 --> Output Class Initialized
INFO - 2016-10-28 11:17:05 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:05 --> Input Class Initialized
INFO - 2016-10-28 11:17:05 --> Language Class Initialized
INFO - 2016-10-28 11:17:05 --> Loader Class Initialized
INFO - 2016-10-28 11:17:05 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:05 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:05 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:05 --> Controller Class Initialized
DEBUG - 2016-10-28 11:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:17:05 --> Model Class Initialized
ERROR - 2016-10-28 11:17:05 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'zxczxc'
AND `password` = '8cf107a1e5eb3b632449410457a041852cafb1c2'
INFO - 2016-10-28 11:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:17:18 --> Config Class Initialized
INFO - 2016-10-28 11:17:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:18 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:18 --> URI Class Initialized
DEBUG - 2016-10-28 11:17:18 --> No URI present. Default controller set.
INFO - 2016-10-28 11:17:18 --> Router Class Initialized
INFO - 2016-10-28 11:17:18 --> Output Class Initialized
INFO - 2016-10-28 11:17:18 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:18 --> Input Class Initialized
INFO - 2016-10-28 11:17:18 --> Language Class Initialized
INFO - 2016-10-28 11:17:18 --> Loader Class Initialized
INFO - 2016-10-28 11:17:18 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:18 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:18 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:18 --> Controller Class Initialized
INFO - 2016-10-28 11:17:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:17:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:17:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:17:18 --> Final output sent to browser
DEBUG - 2016-10-28 11:17:18 --> Total execution time: 0.0166
INFO - 2016-10-28 11:17:21 --> Config Class Initialized
INFO - 2016-10-28 11:17:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:21 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:21 --> URI Class Initialized
INFO - 2016-10-28 11:17:21 --> Router Class Initialized
INFO - 2016-10-28 11:17:21 --> Output Class Initialized
INFO - 2016-10-28 11:17:21 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:21 --> Input Class Initialized
INFO - 2016-10-28 11:17:21 --> Language Class Initialized
INFO - 2016-10-28 11:17:21 --> Loader Class Initialized
INFO - 2016-10-28 11:17:21 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:21 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:21 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:21 --> Controller Class Initialized
DEBUG - 2016-10-28 11:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:17:21 --> Model Class Initialized
ERROR - 2016-10-28 11:17:21 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'ddfs'
AND `password` = '8c411a89ed6d846f064ed0decdba3a857f0d1667'
INFO - 2016-10-28 11:17:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:17:23 --> Config Class Initialized
INFO - 2016-10-28 11:17:23 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:23 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:23 --> URI Class Initialized
DEBUG - 2016-10-28 11:17:23 --> No URI present. Default controller set.
INFO - 2016-10-28 11:17:23 --> Router Class Initialized
INFO - 2016-10-28 11:17:23 --> Output Class Initialized
INFO - 2016-10-28 11:17:23 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:23 --> Input Class Initialized
INFO - 2016-10-28 11:17:23 --> Language Class Initialized
INFO - 2016-10-28 11:17:23 --> Loader Class Initialized
INFO - 2016-10-28 11:17:23 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:23 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:23 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:23 --> Controller Class Initialized
INFO - 2016-10-28 11:17:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:17:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:17:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:17:23 --> Final output sent to browser
DEBUG - 2016-10-28 11:17:23 --> Total execution time: 0.0185
INFO - 2016-10-28 11:17:52 --> Config Class Initialized
INFO - 2016-10-28 11:17:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:52 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:52 --> URI Class Initialized
DEBUG - 2016-10-28 11:17:52 --> No URI present. Default controller set.
INFO - 2016-10-28 11:17:52 --> Router Class Initialized
INFO - 2016-10-28 11:17:52 --> Output Class Initialized
INFO - 2016-10-28 11:17:52 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:52 --> Input Class Initialized
INFO - 2016-10-28 11:17:52 --> Language Class Initialized
INFO - 2016-10-28 11:17:52 --> Loader Class Initialized
INFO - 2016-10-28 11:17:52 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:52 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:52 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:52 --> Controller Class Initialized
INFO - 2016-10-28 11:17:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:17:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:17:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:17:52 --> Final output sent to browser
DEBUG - 2016-10-28 11:17:52 --> Total execution time: 0.0159
INFO - 2016-10-28 11:17:56 --> Config Class Initialized
INFO - 2016-10-28 11:17:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:56 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:56 --> URI Class Initialized
INFO - 2016-10-28 11:17:56 --> Router Class Initialized
INFO - 2016-10-28 11:17:56 --> Output Class Initialized
INFO - 2016-10-28 11:17:56 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:56 --> Input Class Initialized
INFO - 2016-10-28 11:17:56 --> Language Class Initialized
INFO - 2016-10-28 11:17:56 --> Loader Class Initialized
INFO - 2016-10-28 11:17:56 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:56 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:56 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:56 --> Controller Class Initialized
DEBUG - 2016-10-28 11:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:17:56 --> Model Class Initialized
INFO - 2016-10-28 11:17:56 --> Final output sent to browser
DEBUG - 2016-10-28 11:17:56 --> Total execution time: 0.0172
INFO - 2016-10-28 11:17:59 --> Config Class Initialized
INFO - 2016-10-28 11:17:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:17:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:17:59 --> Utf8 Class Initialized
INFO - 2016-10-28 11:17:59 --> URI Class Initialized
INFO - 2016-10-28 11:17:59 --> Router Class Initialized
INFO - 2016-10-28 11:17:59 --> Output Class Initialized
INFO - 2016-10-28 11:17:59 --> Security Class Initialized
DEBUG - 2016-10-28 11:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:17:59 --> Input Class Initialized
INFO - 2016-10-28 11:17:59 --> Language Class Initialized
INFO - 2016-10-28 11:17:59 --> Loader Class Initialized
INFO - 2016-10-28 11:17:59 --> Helper loaded: url_helper
INFO - 2016-10-28 11:17:59 --> Helper loaded: form_helper
INFO - 2016-10-28 11:17:59 --> Database Driver Class Initialized
INFO - 2016-10-28 11:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:17:59 --> Controller Class Initialized
DEBUG - 2016-10-28 11:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:17:59 --> Model Class Initialized
INFO - 2016-10-28 11:17:59 --> Final output sent to browser
DEBUG - 2016-10-28 11:17:59 --> Total execution time: 0.0166
INFO - 2016-10-28 11:19:02 --> Config Class Initialized
INFO - 2016-10-28 11:19:02 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:19:02 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:19:02 --> Utf8 Class Initialized
INFO - 2016-10-28 11:19:02 --> URI Class Initialized
DEBUG - 2016-10-28 11:19:02 --> No URI present. Default controller set.
INFO - 2016-10-28 11:19:02 --> Router Class Initialized
INFO - 2016-10-28 11:19:02 --> Output Class Initialized
INFO - 2016-10-28 11:19:02 --> Security Class Initialized
DEBUG - 2016-10-28 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:19:02 --> Input Class Initialized
INFO - 2016-10-28 11:19:02 --> Language Class Initialized
INFO - 2016-10-28 11:19:02 --> Loader Class Initialized
INFO - 2016-10-28 11:19:02 --> Helper loaded: url_helper
INFO - 2016-10-28 11:19:02 --> Helper loaded: form_helper
INFO - 2016-10-28 11:19:02 --> Database Driver Class Initialized
INFO - 2016-10-28 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:19:02 --> Controller Class Initialized
INFO - 2016-10-28 11:19:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:19:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:19:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:19:02 --> Final output sent to browser
DEBUG - 2016-10-28 11:19:02 --> Total execution time: 0.0184
INFO - 2016-10-28 11:19:20 --> Config Class Initialized
INFO - 2016-10-28 11:19:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:19:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:19:20 --> Utf8 Class Initialized
INFO - 2016-10-28 11:19:20 --> URI Class Initialized
INFO - 2016-10-28 11:19:20 --> Router Class Initialized
INFO - 2016-10-28 11:19:20 --> Output Class Initialized
INFO - 2016-10-28 11:19:20 --> Security Class Initialized
DEBUG - 2016-10-28 11:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:19:20 --> Input Class Initialized
INFO - 2016-10-28 11:19:20 --> Language Class Initialized
INFO - 2016-10-28 11:19:20 --> Loader Class Initialized
INFO - 2016-10-28 11:19:20 --> Helper loaded: url_helper
INFO - 2016-10-28 11:19:20 --> Helper loaded: form_helper
INFO - 2016-10-28 11:19:20 --> Database Driver Class Initialized
INFO - 2016-10-28 11:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:19:20 --> Controller Class Initialized
DEBUG - 2016-10-28 11:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:19:20 --> Model Class Initialized
INFO - 2016-10-28 11:19:20 --> Final output sent to browser
DEBUG - 2016-10-28 11:19:20 --> Total execution time: 0.0175
INFO - 2016-10-28 11:19:54 --> Config Class Initialized
INFO - 2016-10-28 11:19:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:19:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:19:54 --> Utf8 Class Initialized
INFO - 2016-10-28 11:19:54 --> URI Class Initialized
INFO - 2016-10-28 11:19:54 --> Router Class Initialized
INFO - 2016-10-28 11:19:54 --> Output Class Initialized
INFO - 2016-10-28 11:19:54 --> Security Class Initialized
DEBUG - 2016-10-28 11:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:19:54 --> Input Class Initialized
INFO - 2016-10-28 11:19:54 --> Language Class Initialized
INFO - 2016-10-28 11:19:54 --> Loader Class Initialized
INFO - 2016-10-28 11:19:54 --> Helper loaded: url_helper
INFO - 2016-10-28 11:19:54 --> Helper loaded: form_helper
INFO - 2016-10-28 11:19:54 --> Database Driver Class Initialized
INFO - 2016-10-28 11:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:19:54 --> Controller Class Initialized
DEBUG - 2016-10-28 11:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:19:54 --> Model Class Initialized
INFO - 2016-10-28 11:19:54 --> Final output sent to browser
DEBUG - 2016-10-28 11:19:54 --> Total execution time: 0.0173
INFO - 2016-10-28 11:19:56 --> Config Class Initialized
INFO - 2016-10-28 11:19:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:19:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:19:56 --> Utf8 Class Initialized
INFO - 2016-10-28 11:19:56 --> URI Class Initialized
DEBUG - 2016-10-28 11:19:56 --> No URI present. Default controller set.
INFO - 2016-10-28 11:19:56 --> Router Class Initialized
INFO - 2016-10-28 11:19:56 --> Output Class Initialized
INFO - 2016-10-28 11:19:56 --> Security Class Initialized
DEBUG - 2016-10-28 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:19:56 --> Input Class Initialized
INFO - 2016-10-28 11:19:56 --> Language Class Initialized
INFO - 2016-10-28 11:19:56 --> Loader Class Initialized
INFO - 2016-10-28 11:19:56 --> Helper loaded: url_helper
INFO - 2016-10-28 11:19:56 --> Helper loaded: form_helper
INFO - 2016-10-28 11:19:56 --> Database Driver Class Initialized
INFO - 2016-10-28 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:19:56 --> Controller Class Initialized
INFO - 2016-10-28 11:19:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:19:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:19:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:19:56 --> Final output sent to browser
DEBUG - 2016-10-28 11:19:56 --> Total execution time: 0.0160
INFO - 2016-10-28 11:20:44 --> Config Class Initialized
INFO - 2016-10-28 11:20:44 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:20:44 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:20:44 --> Utf8 Class Initialized
INFO - 2016-10-28 11:20:44 --> URI Class Initialized
DEBUG - 2016-10-28 11:20:44 --> No URI present. Default controller set.
INFO - 2016-10-28 11:20:44 --> Router Class Initialized
INFO - 2016-10-28 11:20:44 --> Output Class Initialized
INFO - 2016-10-28 11:20:44 --> Security Class Initialized
DEBUG - 2016-10-28 11:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:20:44 --> Input Class Initialized
INFO - 2016-10-28 11:20:44 --> Language Class Initialized
INFO - 2016-10-28 11:20:44 --> Loader Class Initialized
INFO - 2016-10-28 11:20:44 --> Helper loaded: url_helper
INFO - 2016-10-28 11:20:44 --> Helper loaded: form_helper
INFO - 2016-10-28 11:20:44 --> Database Driver Class Initialized
INFO - 2016-10-28 11:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:20:44 --> Controller Class Initialized
INFO - 2016-10-28 11:20:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:20:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:20:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:20:44 --> Final output sent to browser
DEBUG - 2016-10-28 11:20:44 --> Total execution time: 0.0842
INFO - 2016-10-28 11:20:56 --> Config Class Initialized
INFO - 2016-10-28 11:20:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:20:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:20:56 --> Utf8 Class Initialized
INFO - 2016-10-28 11:20:56 --> URI Class Initialized
INFO - 2016-10-28 11:20:56 --> Router Class Initialized
INFO - 2016-10-28 11:20:56 --> Output Class Initialized
INFO - 2016-10-28 11:20:56 --> Security Class Initialized
DEBUG - 2016-10-28 11:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:20:56 --> Input Class Initialized
INFO - 2016-10-28 11:20:56 --> Language Class Initialized
INFO - 2016-10-28 11:20:56 --> Loader Class Initialized
INFO - 2016-10-28 11:20:56 --> Helper loaded: url_helper
INFO - 2016-10-28 11:20:56 --> Helper loaded: form_helper
INFO - 2016-10-28 11:20:56 --> Database Driver Class Initialized
INFO - 2016-10-28 11:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:20:56 --> Controller Class Initialized
DEBUG - 2016-10-28 11:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:20:56 --> Model Class Initialized
INFO - 2016-10-28 11:20:56 --> Final output sent to browser
DEBUG - 2016-10-28 11:20:56 --> Total execution time: 0.0163
INFO - 2016-10-28 11:20:56 --> Config Class Initialized
INFO - 2016-10-28 11:20:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:20:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:20:56 --> Utf8 Class Initialized
INFO - 2016-10-28 11:20:56 --> URI Class Initialized
DEBUG - 2016-10-28 11:20:56 --> No URI present. Default controller set.
INFO - 2016-10-28 11:20:56 --> Router Class Initialized
INFO - 2016-10-28 11:20:56 --> Output Class Initialized
INFO - 2016-10-28 11:20:56 --> Security Class Initialized
DEBUG - 2016-10-28 11:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:20:56 --> Input Class Initialized
INFO - 2016-10-28 11:20:56 --> Language Class Initialized
INFO - 2016-10-28 11:20:56 --> Loader Class Initialized
INFO - 2016-10-28 11:20:56 --> Helper loaded: url_helper
INFO - 2016-10-28 11:20:56 --> Helper loaded: form_helper
INFO - 2016-10-28 11:20:56 --> Database Driver Class Initialized
INFO - 2016-10-28 11:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:20:56 --> Controller Class Initialized
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:20:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:20:56 --> Final output sent to browser
DEBUG - 2016-10-28 11:20:56 --> Total execution time: 0.0853
INFO - 2016-10-28 11:20:58 --> Config Class Initialized
INFO - 2016-10-28 11:20:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:20:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:20:58 --> Utf8 Class Initialized
INFO - 2016-10-28 11:20:58 --> URI Class Initialized
DEBUG - 2016-10-28 11:20:58 --> No URI present. Default controller set.
INFO - 2016-10-28 11:20:58 --> Router Class Initialized
INFO - 2016-10-28 11:20:58 --> Output Class Initialized
INFO - 2016-10-28 11:20:58 --> Security Class Initialized
DEBUG - 2016-10-28 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:20:58 --> Input Class Initialized
INFO - 2016-10-28 11:20:58 --> Language Class Initialized
INFO - 2016-10-28 11:20:58 --> Loader Class Initialized
INFO - 2016-10-28 11:20:58 --> Helper loaded: url_helper
INFO - 2016-10-28 11:20:58 --> Helper loaded: form_helper
INFO - 2016-10-28 11:20:58 --> Database Driver Class Initialized
INFO - 2016-10-28 11:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:20:58 --> Controller Class Initialized
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:20:58 --> Final output sent to browser
DEBUG - 2016-10-28 11:20:58 --> Total execution time: 0.0162
INFO - 2016-10-28 11:21:03 --> Config Class Initialized
INFO - 2016-10-28 11:21:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:21:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:21:03 --> Utf8 Class Initialized
INFO - 2016-10-28 11:21:03 --> URI Class Initialized
DEBUG - 2016-10-28 11:21:03 --> No URI present. Default controller set.
INFO - 2016-10-28 11:21:03 --> Router Class Initialized
INFO - 2016-10-28 11:21:03 --> Output Class Initialized
INFO - 2016-10-28 11:21:03 --> Security Class Initialized
DEBUG - 2016-10-28 11:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:21:03 --> Input Class Initialized
INFO - 2016-10-28 11:21:03 --> Language Class Initialized
INFO - 2016-10-28 11:21:03 --> Loader Class Initialized
INFO - 2016-10-28 11:21:03 --> Helper loaded: url_helper
INFO - 2016-10-28 11:21:03 --> Helper loaded: form_helper
INFO - 2016-10-28 11:21:03 --> Database Driver Class Initialized
INFO - 2016-10-28 11:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:21:03 --> Controller Class Initialized
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:21:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:21:03 --> Final output sent to browser
DEBUG - 2016-10-28 11:21:03 --> Total execution time: 0.0164
INFO - 2016-10-28 11:21:05 --> Config Class Initialized
INFO - 2016-10-28 11:21:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:21:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:21:05 --> Utf8 Class Initialized
INFO - 2016-10-28 11:21:05 --> URI Class Initialized
INFO - 2016-10-28 11:21:05 --> Router Class Initialized
INFO - 2016-10-28 11:21:05 --> Output Class Initialized
INFO - 2016-10-28 11:21:05 --> Security Class Initialized
DEBUG - 2016-10-28 11:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:21:05 --> Input Class Initialized
INFO - 2016-10-28 11:21:05 --> Language Class Initialized
INFO - 2016-10-28 11:21:05 --> Loader Class Initialized
INFO - 2016-10-28 11:21:05 --> Helper loaded: url_helper
INFO - 2016-10-28 11:21:05 --> Helper loaded: form_helper
INFO - 2016-10-28 11:21:05 --> Database Driver Class Initialized
INFO - 2016-10-28 11:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:21:05 --> Controller Class Initialized
DEBUG - 2016-10-28 11:21:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 11:21:05 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 11:21:05 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 11:21:05 --> Config Class Initialized
INFO - 2016-10-28 11:21:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:21:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:21:05 --> Utf8 Class Initialized
INFO - 2016-10-28 11:21:05 --> URI Class Initialized
DEBUG - 2016-10-28 11:21:05 --> No URI present. Default controller set.
INFO - 2016-10-28 11:21:05 --> Router Class Initialized
INFO - 2016-10-28 11:21:05 --> Output Class Initialized
INFO - 2016-10-28 11:21:05 --> Security Class Initialized
DEBUG - 2016-10-28 11:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:21:05 --> Input Class Initialized
INFO - 2016-10-28 11:21:05 --> Language Class Initialized
INFO - 2016-10-28 11:21:05 --> Loader Class Initialized
INFO - 2016-10-28 11:21:05 --> Helper loaded: url_helper
INFO - 2016-10-28 11:21:05 --> Helper loaded: form_helper
INFO - 2016-10-28 11:21:05 --> Database Driver Class Initialized
INFO - 2016-10-28 11:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:21:05 --> Controller Class Initialized
INFO - 2016-10-28 11:21:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:21:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:21:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:21:05 --> Final output sent to browser
DEBUG - 2016-10-28 11:21:05 --> Total execution time: 0.0148
INFO - 2016-10-28 11:27:00 --> Config Class Initialized
INFO - 2016-10-28 11:27:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:27:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:27:00 --> Utf8 Class Initialized
INFO - 2016-10-28 11:27:00 --> URI Class Initialized
DEBUG - 2016-10-28 11:27:00 --> No URI present. Default controller set.
INFO - 2016-10-28 11:27:00 --> Router Class Initialized
INFO - 2016-10-28 11:27:00 --> Output Class Initialized
INFO - 2016-10-28 11:27:00 --> Security Class Initialized
DEBUG - 2016-10-28 11:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:27:00 --> Input Class Initialized
INFO - 2016-10-28 11:27:00 --> Language Class Initialized
INFO - 2016-10-28 11:27:00 --> Loader Class Initialized
INFO - 2016-10-28 11:27:00 --> Helper loaded: url_helper
INFO - 2016-10-28 11:27:00 --> Helper loaded: form_helper
INFO - 2016-10-28 11:27:00 --> Database Driver Class Initialized
INFO - 2016-10-28 11:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:27:00 --> Controller Class Initialized
INFO - 2016-10-28 11:27:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:27:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:27:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:27:00 --> Final output sent to browser
DEBUG - 2016-10-28 11:27:00 --> Total execution time: 0.0196
INFO - 2016-10-28 11:27:03 --> Config Class Initialized
INFO - 2016-10-28 11:27:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:27:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:27:03 --> Utf8 Class Initialized
INFO - 2016-10-28 11:27:03 --> URI Class Initialized
INFO - 2016-10-28 11:27:03 --> Router Class Initialized
INFO - 2016-10-28 11:27:03 --> Output Class Initialized
INFO - 2016-10-28 11:27:03 --> Security Class Initialized
DEBUG - 2016-10-28 11:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:27:03 --> Input Class Initialized
INFO - 2016-10-28 11:27:03 --> Language Class Initialized
INFO - 2016-10-28 11:27:03 --> Loader Class Initialized
INFO - 2016-10-28 11:27:03 --> Helper loaded: url_helper
INFO - 2016-10-28 11:27:03 --> Helper loaded: form_helper
INFO - 2016-10-28 11:27:03 --> Database Driver Class Initialized
INFO - 2016-10-28 11:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:27:03 --> Controller Class Initialized
DEBUG - 2016-10-28 11:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:27:03 --> Model Class Initialized
ERROR - 2016-10-28 11:27:03 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'dghd'
AND `password` = '44805acf3d02201830d535478852b08c6dc9615d'
INFO - 2016-10-28 11:27:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:27:07 --> Config Class Initialized
INFO - 2016-10-28 11:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:27:07 --> Utf8 Class Initialized
INFO - 2016-10-28 11:27:07 --> URI Class Initialized
DEBUG - 2016-10-28 11:27:07 --> No URI present. Default controller set.
INFO - 2016-10-28 11:27:07 --> Router Class Initialized
INFO - 2016-10-28 11:27:07 --> Output Class Initialized
INFO - 2016-10-28 11:27:07 --> Security Class Initialized
DEBUG - 2016-10-28 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:27:07 --> Input Class Initialized
INFO - 2016-10-28 11:27:07 --> Language Class Initialized
INFO - 2016-10-28 11:27:07 --> Loader Class Initialized
INFO - 2016-10-28 11:27:07 --> Helper loaded: url_helper
INFO - 2016-10-28 11:27:07 --> Helper loaded: form_helper
INFO - 2016-10-28 11:27:07 --> Database Driver Class Initialized
INFO - 2016-10-28 11:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:27:07 --> Controller Class Initialized
INFO - 2016-10-28 11:27:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:27:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:27:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:27:07 --> Final output sent to browser
DEBUG - 2016-10-28 11:27:07 --> Total execution time: 0.0181
INFO - 2016-10-28 11:27:11 --> Config Class Initialized
INFO - 2016-10-28 11:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:27:11 --> Utf8 Class Initialized
INFO - 2016-10-28 11:27:11 --> URI Class Initialized
INFO - 2016-10-28 11:27:11 --> Router Class Initialized
INFO - 2016-10-28 11:27:11 --> Output Class Initialized
INFO - 2016-10-28 11:27:11 --> Security Class Initialized
DEBUG - 2016-10-28 11:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:27:11 --> Input Class Initialized
INFO - 2016-10-28 11:27:11 --> Language Class Initialized
INFO - 2016-10-28 11:27:11 --> Loader Class Initialized
INFO - 2016-10-28 11:27:11 --> Helper loaded: url_helper
INFO - 2016-10-28 11:27:11 --> Helper loaded: form_helper
INFO - 2016-10-28 11:27:11 --> Database Driver Class Initialized
INFO - 2016-10-28 11:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:27:11 --> Controller Class Initialized
DEBUG - 2016-10-28 11:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:27:11 --> Model Class Initialized
ERROR - 2016-10-28 11:27:11 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'fghfghgf'
AND `password` = 'caa6b5db9eb4eac15b607f21da818e4dd6681e47'
INFO - 2016-10-28 11:27:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:27:14 --> Config Class Initialized
INFO - 2016-10-28 11:27:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:27:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:27:14 --> Utf8 Class Initialized
INFO - 2016-10-28 11:27:14 --> URI Class Initialized
DEBUG - 2016-10-28 11:27:14 --> No URI present. Default controller set.
INFO - 2016-10-28 11:27:14 --> Router Class Initialized
INFO - 2016-10-28 11:27:14 --> Output Class Initialized
INFO - 2016-10-28 11:27:14 --> Security Class Initialized
DEBUG - 2016-10-28 11:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:27:14 --> Input Class Initialized
INFO - 2016-10-28 11:27:14 --> Language Class Initialized
INFO - 2016-10-28 11:27:14 --> Loader Class Initialized
INFO - 2016-10-28 11:27:14 --> Helper loaded: url_helper
INFO - 2016-10-28 11:27:14 --> Helper loaded: form_helper
INFO - 2016-10-28 11:27:14 --> Database Driver Class Initialized
INFO - 2016-10-28 11:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:27:14 --> Controller Class Initialized
INFO - 2016-10-28 11:27:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:27:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:27:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:27:14 --> Final output sent to browser
DEBUG - 2016-10-28 11:27:14 --> Total execution time: 0.0165
INFO - 2016-10-28 11:28:10 --> Config Class Initialized
INFO - 2016-10-28 11:28:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:10 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:10 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:10 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:10 --> Router Class Initialized
INFO - 2016-10-28 11:28:10 --> Output Class Initialized
INFO - 2016-10-28 11:28:10 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:10 --> Input Class Initialized
INFO - 2016-10-28 11:28:10 --> Language Class Initialized
INFO - 2016-10-28 11:28:10 --> Loader Class Initialized
INFO - 2016-10-28 11:28:10 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:10 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:10 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:10 --> Controller Class Initialized
INFO - 2016-10-28 11:28:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:10 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:10 --> Total execution time: 0.0174
INFO - 2016-10-28 11:28:14 --> Config Class Initialized
INFO - 2016-10-28 11:28:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:14 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:14 --> URI Class Initialized
INFO - 2016-10-28 11:28:14 --> Router Class Initialized
INFO - 2016-10-28 11:28:14 --> Output Class Initialized
INFO - 2016-10-28 11:28:14 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:14 --> Input Class Initialized
INFO - 2016-10-28 11:28:14 --> Language Class Initialized
INFO - 2016-10-28 11:28:14 --> Loader Class Initialized
INFO - 2016-10-28 11:28:14 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:14 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:14 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:14 --> Controller Class Initialized
DEBUG - 2016-10-28 11:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:28:14 --> Model Class Initialized
ERROR - 2016-10-28 11:28:14 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'sagfsdfg'
AND `password` = '7697b59d8fc35fa6041bdbefa73e3414c6a6c353'
INFO - 2016-10-28 11:28:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:28:16 --> Config Class Initialized
INFO - 2016-10-28 11:28:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:16 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:16 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:16 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:16 --> Router Class Initialized
INFO - 2016-10-28 11:28:16 --> Output Class Initialized
INFO - 2016-10-28 11:28:16 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:16 --> Input Class Initialized
INFO - 2016-10-28 11:28:16 --> Language Class Initialized
INFO - 2016-10-28 11:28:16 --> Loader Class Initialized
INFO - 2016-10-28 11:28:16 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:16 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:16 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:16 --> Controller Class Initialized
INFO - 2016-10-28 11:28:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:16 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:16 --> Total execution time: 0.0169
INFO - 2016-10-28 11:28:17 --> Config Class Initialized
INFO - 2016-10-28 11:28:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:17 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:17 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:17 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:17 --> Router Class Initialized
INFO - 2016-10-28 11:28:17 --> Output Class Initialized
INFO - 2016-10-28 11:28:17 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:17 --> Input Class Initialized
INFO - 2016-10-28 11:28:17 --> Language Class Initialized
INFO - 2016-10-28 11:28:17 --> Loader Class Initialized
INFO - 2016-10-28 11:28:17 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:17 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:17 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:17 --> Controller Class Initialized
INFO - 2016-10-28 11:28:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:17 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:17 --> Total execution time: 0.0157
INFO - 2016-10-28 11:28:21 --> Config Class Initialized
INFO - 2016-10-28 11:28:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:21 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:21 --> URI Class Initialized
INFO - 2016-10-28 11:28:21 --> Router Class Initialized
INFO - 2016-10-28 11:28:21 --> Output Class Initialized
INFO - 2016-10-28 11:28:21 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:21 --> Input Class Initialized
INFO - 2016-10-28 11:28:21 --> Language Class Initialized
INFO - 2016-10-28 11:28:21 --> Loader Class Initialized
INFO - 2016-10-28 11:28:21 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:21 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:21 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:21 --> Controller Class Initialized
DEBUG - 2016-10-28 11:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:28:21 --> Model Class Initialized
ERROR - 2016-10-28 11:28:21 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'dfgdgd'
AND `password` = '97445e1f4233653bc1a3eeee2b2137d40e25f542'
INFO - 2016-10-28 11:28:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:28:23 --> Config Class Initialized
INFO - 2016-10-28 11:28:23 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:23 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:23 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:23 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:23 --> Router Class Initialized
INFO - 2016-10-28 11:28:23 --> Output Class Initialized
INFO - 2016-10-28 11:28:23 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:23 --> Input Class Initialized
INFO - 2016-10-28 11:28:23 --> Language Class Initialized
INFO - 2016-10-28 11:28:23 --> Loader Class Initialized
INFO - 2016-10-28 11:28:23 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:23 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:23 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:23 --> Controller Class Initialized
INFO - 2016-10-28 11:28:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:23 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:23 --> Total execution time: 0.0160
INFO - 2016-10-28 11:28:49 --> Config Class Initialized
INFO - 2016-10-28 11:28:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:49 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:49 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:49 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:49 --> Router Class Initialized
INFO - 2016-10-28 11:28:49 --> Output Class Initialized
INFO - 2016-10-28 11:28:49 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:49 --> Input Class Initialized
INFO - 2016-10-28 11:28:49 --> Language Class Initialized
INFO - 2016-10-28 11:28:49 --> Loader Class Initialized
INFO - 2016-10-28 11:28:49 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:49 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:49 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:49 --> Controller Class Initialized
INFO - 2016-10-28 11:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:49 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:49 --> Total execution time: 0.0167
INFO - 2016-10-28 11:28:49 --> Config Class Initialized
INFO - 2016-10-28 11:28:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:49 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:49 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:49 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:49 --> Router Class Initialized
INFO - 2016-10-28 11:28:49 --> Output Class Initialized
INFO - 2016-10-28 11:28:49 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:49 --> Input Class Initialized
INFO - 2016-10-28 11:28:49 --> Language Class Initialized
INFO - 2016-10-28 11:28:49 --> Loader Class Initialized
INFO - 2016-10-28 11:28:49 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:49 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:49 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:49 --> Controller Class Initialized
INFO - 2016-10-28 11:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:49 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:49 --> Total execution time: 0.0160
INFO - 2016-10-28 11:28:52 --> Config Class Initialized
INFO - 2016-10-28 11:28:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:52 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:52 --> URI Class Initialized
INFO - 2016-10-28 11:28:52 --> Router Class Initialized
INFO - 2016-10-28 11:28:52 --> Output Class Initialized
INFO - 2016-10-28 11:28:52 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:52 --> Input Class Initialized
INFO - 2016-10-28 11:28:52 --> Language Class Initialized
INFO - 2016-10-28 11:28:52 --> Loader Class Initialized
INFO - 2016-10-28 11:28:52 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:52 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:52 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:52 --> Controller Class Initialized
DEBUG - 2016-10-28 11:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:28:52 --> Model Class Initialized
ERROR - 2016-10-28 11:28:52 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'gdfdg'
AND `password` = 'a9b0107084f49c6b2a04638791f2564468e4803d'
INFO - 2016-10-28 11:28:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:28:54 --> Config Class Initialized
INFO - 2016-10-28 11:28:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:28:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:28:54 --> Utf8 Class Initialized
INFO - 2016-10-28 11:28:54 --> URI Class Initialized
DEBUG - 2016-10-28 11:28:54 --> No URI present. Default controller set.
INFO - 2016-10-28 11:28:54 --> Router Class Initialized
INFO - 2016-10-28 11:28:54 --> Output Class Initialized
INFO - 2016-10-28 11:28:54 --> Security Class Initialized
DEBUG - 2016-10-28 11:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:28:54 --> Input Class Initialized
INFO - 2016-10-28 11:28:54 --> Language Class Initialized
INFO - 2016-10-28 11:28:54 --> Loader Class Initialized
INFO - 2016-10-28 11:28:54 --> Helper loaded: url_helper
INFO - 2016-10-28 11:28:54 --> Helper loaded: form_helper
INFO - 2016-10-28 11:28:54 --> Database Driver Class Initialized
INFO - 2016-10-28 11:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:28:54 --> Controller Class Initialized
INFO - 2016-10-28 11:28:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:28:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:28:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:28:54 --> Final output sent to browser
DEBUG - 2016-10-28 11:28:54 --> Total execution time: 0.0207
INFO - 2016-10-28 11:29:00 --> Config Class Initialized
INFO - 2016-10-28 11:29:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:00 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:00 --> URI Class Initialized
INFO - 2016-10-28 11:29:00 --> Router Class Initialized
INFO - 2016-10-28 11:29:00 --> Output Class Initialized
INFO - 2016-10-28 11:29:00 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:00 --> Input Class Initialized
INFO - 2016-10-28 11:29:00 --> Language Class Initialized
INFO - 2016-10-28 11:29:00 --> Loader Class Initialized
INFO - 2016-10-28 11:29:00 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:00 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:00 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:00 --> Controller Class Initialized
DEBUG - 2016-10-28 11:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:29:00 --> Model Class Initialized
ERROR - 2016-10-28 11:29:00 --> Query error: Table 'lms.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'dfgdf'
AND `password` = '3c0fc5decc5eed3df6324d4264fa9b91d66f18e5'
INFO - 2016-10-28 11:29:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:29:12 --> Config Class Initialized
INFO - 2016-10-28 11:29:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:12 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:12 --> URI Class Initialized
DEBUG - 2016-10-28 11:29:12 --> No URI present. Default controller set.
INFO - 2016-10-28 11:29:12 --> Router Class Initialized
INFO - 2016-10-28 11:29:12 --> Output Class Initialized
INFO - 2016-10-28 11:29:12 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:12 --> Input Class Initialized
INFO - 2016-10-28 11:29:12 --> Language Class Initialized
INFO - 2016-10-28 11:29:12 --> Loader Class Initialized
INFO - 2016-10-28 11:29:12 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:12 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:12 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:12 --> Controller Class Initialized
INFO - 2016-10-28 11:29:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:29:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:29:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:29:12 --> Final output sent to browser
DEBUG - 2016-10-28 11:29:12 --> Total execution time: 0.0202
INFO - 2016-10-28 11:29:16 --> Config Class Initialized
INFO - 2016-10-28 11:29:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:16 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:16 --> URI Class Initialized
INFO - 2016-10-28 11:29:16 --> Router Class Initialized
INFO - 2016-10-28 11:29:16 --> Output Class Initialized
INFO - 2016-10-28 11:29:16 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:16 --> Input Class Initialized
INFO - 2016-10-28 11:29:16 --> Language Class Initialized
INFO - 2016-10-28 11:29:16 --> Loader Class Initialized
INFO - 2016-10-28 11:29:16 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:16 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:16 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:16 --> Controller Class Initialized
DEBUG - 2016-10-28 11:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:29:16 --> Model Class Initialized
ERROR - 2016-10-28 11:29:16 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'hjkhjk'
AND `password` = '1bc6ff0c119707ed1c34d1b8d1be85067bca8348'
INFO - 2016-10-28 11:29:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:29:17 --> Config Class Initialized
INFO - 2016-10-28 11:29:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:17 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:17 --> URI Class Initialized
DEBUG - 2016-10-28 11:29:17 --> No URI present. Default controller set.
INFO - 2016-10-28 11:29:17 --> Router Class Initialized
INFO - 2016-10-28 11:29:17 --> Output Class Initialized
INFO - 2016-10-28 11:29:17 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:17 --> Input Class Initialized
INFO - 2016-10-28 11:29:17 --> Language Class Initialized
INFO - 2016-10-28 11:29:17 --> Loader Class Initialized
INFO - 2016-10-28 11:29:17 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:17 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:17 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:17 --> Controller Class Initialized
INFO - 2016-10-28 11:29:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:29:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:29:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:29:17 --> Final output sent to browser
DEBUG - 2016-10-28 11:29:17 --> Total execution time: 0.0167
INFO - 2016-10-28 11:29:22 --> Config Class Initialized
INFO - 2016-10-28 11:29:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:22 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:22 --> URI Class Initialized
INFO - 2016-10-28 11:29:22 --> Router Class Initialized
INFO - 2016-10-28 11:29:22 --> Output Class Initialized
INFO - 2016-10-28 11:29:22 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:22 --> Input Class Initialized
INFO - 2016-10-28 11:29:22 --> Language Class Initialized
INFO - 2016-10-28 11:29:22 --> Loader Class Initialized
INFO - 2016-10-28 11:29:22 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:22 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:22 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:22 --> Controller Class Initialized
DEBUG - 2016-10-28 11:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:29:22 --> Model Class Initialized
ERROR - 2016-10-28 11:29:22 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'hjkjhk'
AND `password` = '44485f3a943ef4e48748e5399bb84823aa3d1d08'
INFO - 2016-10-28 11:29:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:29:24 --> Config Class Initialized
INFO - 2016-10-28 11:29:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:24 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:24 --> URI Class Initialized
DEBUG - 2016-10-28 11:29:24 --> No URI present. Default controller set.
INFO - 2016-10-28 11:29:24 --> Router Class Initialized
INFO - 2016-10-28 11:29:24 --> Output Class Initialized
INFO - 2016-10-28 11:29:24 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:24 --> Input Class Initialized
INFO - 2016-10-28 11:29:24 --> Language Class Initialized
INFO - 2016-10-28 11:29:24 --> Loader Class Initialized
INFO - 2016-10-28 11:29:24 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:24 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:24 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:24 --> Controller Class Initialized
INFO - 2016-10-28 11:29:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:29:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:29:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:29:24 --> Final output sent to browser
DEBUG - 2016-10-28 11:29:24 --> Total execution time: 0.0161
INFO - 2016-10-28 11:29:39 --> Config Class Initialized
INFO - 2016-10-28 11:29:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:39 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:39 --> URI Class Initialized
DEBUG - 2016-10-28 11:29:39 --> No URI present. Default controller set.
INFO - 2016-10-28 11:29:39 --> Router Class Initialized
INFO - 2016-10-28 11:29:39 --> Output Class Initialized
INFO - 2016-10-28 11:29:39 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:39 --> Input Class Initialized
INFO - 2016-10-28 11:29:39 --> Language Class Initialized
INFO - 2016-10-28 11:29:39 --> Loader Class Initialized
INFO - 2016-10-28 11:29:39 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:39 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:39 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:39 --> Controller Class Initialized
INFO - 2016-10-28 11:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:29:39 --> Final output sent to browser
DEBUG - 2016-10-28 11:29:39 --> Total execution time: 0.0176
INFO - 2016-10-28 11:29:42 --> Config Class Initialized
INFO - 2016-10-28 11:29:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:42 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:42 --> URI Class Initialized
INFO - 2016-10-28 11:29:42 --> Router Class Initialized
INFO - 2016-10-28 11:29:42 --> Output Class Initialized
INFO - 2016-10-28 11:29:42 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:42 --> Input Class Initialized
INFO - 2016-10-28 11:29:42 --> Language Class Initialized
INFO - 2016-10-28 11:29:42 --> Loader Class Initialized
INFO - 2016-10-28 11:29:42 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:42 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:42 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:42 --> Controller Class Initialized
DEBUG - 2016-10-28 11:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:29:42 --> Model Class Initialized
ERROR - 2016-10-28 11:29:42 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'ghgff'
AND `password` = 'c62e1c867f1b26ba2f06b966c6339b2f6371d0da'
INFO - 2016-10-28 11:29:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:29:43 --> Config Class Initialized
INFO - 2016-10-28 11:29:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:43 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:43 --> URI Class Initialized
DEBUG - 2016-10-28 11:29:43 --> No URI present. Default controller set.
INFO - 2016-10-28 11:29:43 --> Router Class Initialized
INFO - 2016-10-28 11:29:43 --> Output Class Initialized
INFO - 2016-10-28 11:29:43 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:43 --> Input Class Initialized
INFO - 2016-10-28 11:29:43 --> Language Class Initialized
INFO - 2016-10-28 11:29:43 --> Loader Class Initialized
INFO - 2016-10-28 11:29:43 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:43 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:43 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:43 --> Controller Class Initialized
INFO - 2016-10-28 11:29:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:29:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:29:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:29:43 --> Final output sent to browser
DEBUG - 2016-10-28 11:29:43 --> Total execution time: 0.0173
INFO - 2016-10-28 11:29:46 --> Config Class Initialized
INFO - 2016-10-28 11:29:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:46 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:46 --> URI Class Initialized
INFO - 2016-10-28 11:29:46 --> Router Class Initialized
INFO - 2016-10-28 11:29:46 --> Output Class Initialized
INFO - 2016-10-28 11:29:46 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:46 --> Input Class Initialized
INFO - 2016-10-28 11:29:46 --> Language Class Initialized
INFO - 2016-10-28 11:29:46 --> Loader Class Initialized
INFO - 2016-10-28 11:29:46 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:46 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:46 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:46 --> Controller Class Initialized
DEBUG - 2016-10-28 11:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:29:46 --> Model Class Initialized
ERROR - 2016-10-28 11:29:46 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'gfhfg'
AND `password` = 'b79c264d0041f97d177b0d37e174a4368b9c636a'
INFO - 2016-10-28 11:29:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:29:57 --> Config Class Initialized
INFO - 2016-10-28 11:29:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:29:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:29:57 --> Utf8 Class Initialized
INFO - 2016-10-28 11:29:57 --> URI Class Initialized
DEBUG - 2016-10-28 11:29:57 --> No URI present. Default controller set.
INFO - 2016-10-28 11:29:57 --> Router Class Initialized
INFO - 2016-10-28 11:29:57 --> Output Class Initialized
INFO - 2016-10-28 11:29:57 --> Security Class Initialized
DEBUG - 2016-10-28 11:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:29:57 --> Input Class Initialized
INFO - 2016-10-28 11:29:57 --> Language Class Initialized
INFO - 2016-10-28 11:29:57 --> Loader Class Initialized
INFO - 2016-10-28 11:29:57 --> Helper loaded: url_helper
INFO - 2016-10-28 11:29:57 --> Helper loaded: form_helper
INFO - 2016-10-28 11:29:57 --> Database Driver Class Initialized
INFO - 2016-10-28 11:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:29:57 --> Controller Class Initialized
INFO - 2016-10-28 11:29:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:29:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:29:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:29:57 --> Final output sent to browser
DEBUG - 2016-10-28 11:29:57 --> Total execution time: 0.0179
INFO - 2016-10-28 11:30:28 --> Config Class Initialized
INFO - 2016-10-28 11:30:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:30:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:30:28 --> Utf8 Class Initialized
INFO - 2016-10-28 11:30:28 --> URI Class Initialized
DEBUG - 2016-10-28 11:30:28 --> No URI present. Default controller set.
INFO - 2016-10-28 11:30:28 --> Router Class Initialized
INFO - 2016-10-28 11:30:28 --> Output Class Initialized
INFO - 2016-10-28 11:30:28 --> Security Class Initialized
DEBUG - 2016-10-28 11:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:30:28 --> Input Class Initialized
INFO - 2016-10-28 11:30:28 --> Language Class Initialized
INFO - 2016-10-28 11:30:28 --> Loader Class Initialized
INFO - 2016-10-28 11:30:28 --> Helper loaded: url_helper
INFO - 2016-10-28 11:30:28 --> Helper loaded: form_helper
INFO - 2016-10-28 11:30:28 --> Database Driver Class Initialized
INFO - 2016-10-28 11:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:30:28 --> Controller Class Initialized
INFO - 2016-10-28 11:30:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:30:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:30:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:30:28 --> Final output sent to browser
DEBUG - 2016-10-28 11:30:28 --> Total execution time: 0.0182
INFO - 2016-10-28 11:30:29 --> Config Class Initialized
INFO - 2016-10-28 11:30:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:30:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:30:29 --> Utf8 Class Initialized
INFO - 2016-10-28 11:30:29 --> URI Class Initialized
DEBUG - 2016-10-28 11:30:29 --> No URI present. Default controller set.
INFO - 2016-10-28 11:30:29 --> Router Class Initialized
INFO - 2016-10-28 11:30:29 --> Output Class Initialized
INFO - 2016-10-28 11:30:29 --> Security Class Initialized
DEBUG - 2016-10-28 11:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:30:29 --> Input Class Initialized
INFO - 2016-10-28 11:30:29 --> Language Class Initialized
INFO - 2016-10-28 11:30:29 --> Loader Class Initialized
INFO - 2016-10-28 11:30:29 --> Helper loaded: url_helper
INFO - 2016-10-28 11:30:29 --> Helper loaded: form_helper
INFO - 2016-10-28 11:30:29 --> Database Driver Class Initialized
INFO - 2016-10-28 11:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:30:29 --> Controller Class Initialized
INFO - 2016-10-28 11:30:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:30:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:30:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:30:29 --> Final output sent to browser
DEBUG - 2016-10-28 11:30:29 --> Total execution time: 0.0174
INFO - 2016-10-28 11:30:33 --> Config Class Initialized
INFO - 2016-10-28 11:30:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:30:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:30:33 --> Utf8 Class Initialized
INFO - 2016-10-28 11:30:33 --> URI Class Initialized
INFO - 2016-10-28 11:30:33 --> Router Class Initialized
INFO - 2016-10-28 11:30:33 --> Output Class Initialized
INFO - 2016-10-28 11:30:33 --> Security Class Initialized
DEBUG - 2016-10-28 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:30:33 --> Input Class Initialized
INFO - 2016-10-28 11:30:33 --> Language Class Initialized
INFO - 2016-10-28 11:30:33 --> Loader Class Initialized
INFO - 2016-10-28 11:30:33 --> Helper loaded: url_helper
INFO - 2016-10-28 11:30:33 --> Helper loaded: form_helper
INFO - 2016-10-28 11:30:33 --> Database Driver Class Initialized
INFO - 2016-10-28 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:30:33 --> Controller Class Initialized
DEBUG - 2016-10-28 11:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:30:33 --> Model Class Initialized
ERROR - 2016-10-28 11:30:33 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'jghhgj'
AND `password` = 'b60fde1843cf51751dee3bf64662d69ead1297f7'
INFO - 2016-10-28 11:30:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:30:36 --> Config Class Initialized
INFO - 2016-10-28 11:30:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:30:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:30:36 --> Utf8 Class Initialized
INFO - 2016-10-28 11:30:36 --> URI Class Initialized
DEBUG - 2016-10-28 11:30:36 --> No URI present. Default controller set.
INFO - 2016-10-28 11:30:36 --> Router Class Initialized
INFO - 2016-10-28 11:30:36 --> Output Class Initialized
INFO - 2016-10-28 11:30:36 --> Security Class Initialized
DEBUG - 2016-10-28 11:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:30:36 --> Input Class Initialized
INFO - 2016-10-28 11:30:36 --> Language Class Initialized
INFO - 2016-10-28 11:30:36 --> Loader Class Initialized
INFO - 2016-10-28 11:30:36 --> Helper loaded: url_helper
INFO - 2016-10-28 11:30:36 --> Helper loaded: form_helper
INFO - 2016-10-28 11:30:36 --> Database Driver Class Initialized
INFO - 2016-10-28 11:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:30:36 --> Controller Class Initialized
INFO - 2016-10-28 11:30:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:30:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:30:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:30:36 --> Final output sent to browser
DEBUG - 2016-10-28 11:30:36 --> Total execution time: 0.0163
INFO - 2016-10-28 11:30:51 --> Config Class Initialized
INFO - 2016-10-28 11:30:51 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:30:51 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:30:51 --> Utf8 Class Initialized
INFO - 2016-10-28 11:30:51 --> URI Class Initialized
INFO - 2016-10-28 11:30:51 --> Router Class Initialized
INFO - 2016-10-28 11:30:51 --> Output Class Initialized
INFO - 2016-10-28 11:30:51 --> Security Class Initialized
DEBUG - 2016-10-28 11:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:30:51 --> Input Class Initialized
INFO - 2016-10-28 11:30:51 --> Language Class Initialized
INFO - 2016-10-28 11:30:51 --> Loader Class Initialized
INFO - 2016-10-28 11:30:51 --> Helper loaded: url_helper
INFO - 2016-10-28 11:30:51 --> Helper loaded: form_helper
INFO - 2016-10-28 11:30:51 --> Database Driver Class Initialized
INFO - 2016-10-28 11:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:30:51 --> Controller Class Initialized
DEBUG - 2016-10-28 11:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:30:51 --> Model Class Initialized
ERROR - 2016-10-28 11:30:51 --> Query error: Table 'lms.lms' doesn't exist - Invalid query: SELECT *
FROM `lms`
WHERE `username` = 'hjhjhj'
AND `password` = 'e3190c37ae1f52a345d2a278c12a0918138dfe59'
INFO - 2016-10-28 11:30:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 11:30:53 --> Config Class Initialized
INFO - 2016-10-28 11:30:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:30:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:30:53 --> Utf8 Class Initialized
INFO - 2016-10-28 11:30:53 --> URI Class Initialized
DEBUG - 2016-10-28 11:30:53 --> No URI present. Default controller set.
INFO - 2016-10-28 11:30:53 --> Router Class Initialized
INFO - 2016-10-28 11:30:53 --> Output Class Initialized
INFO - 2016-10-28 11:30:53 --> Security Class Initialized
DEBUG - 2016-10-28 11:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:30:53 --> Input Class Initialized
INFO - 2016-10-28 11:30:53 --> Language Class Initialized
INFO - 2016-10-28 11:30:53 --> Loader Class Initialized
INFO - 2016-10-28 11:30:53 --> Helper loaded: url_helper
INFO - 2016-10-28 11:30:53 --> Helper loaded: form_helper
INFO - 2016-10-28 11:30:53 --> Database Driver Class Initialized
INFO - 2016-10-28 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:30:53 --> Controller Class Initialized
INFO - 2016-10-28 11:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:30:53 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:30:53 --> Final output sent to browser
DEBUG - 2016-10-28 11:30:53 --> Total execution time: 0.0164
INFO - 2016-10-28 11:31:45 --> Config Class Initialized
INFO - 2016-10-28 11:31:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:31:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:31:45 --> Utf8 Class Initialized
INFO - 2016-10-28 11:31:45 --> URI Class Initialized
DEBUG - 2016-10-28 11:31:45 --> No URI present. Default controller set.
INFO - 2016-10-28 11:31:45 --> Router Class Initialized
INFO - 2016-10-28 11:31:45 --> Output Class Initialized
INFO - 2016-10-28 11:31:45 --> Security Class Initialized
DEBUG - 2016-10-28 11:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:31:45 --> Input Class Initialized
INFO - 2016-10-28 11:31:45 --> Language Class Initialized
INFO - 2016-10-28 11:31:45 --> Loader Class Initialized
INFO - 2016-10-28 11:31:45 --> Helper loaded: url_helper
INFO - 2016-10-28 11:31:45 --> Helper loaded: form_helper
INFO - 2016-10-28 11:31:45 --> Database Driver Class Initialized
INFO - 2016-10-28 11:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:31:45 --> Controller Class Initialized
INFO - 2016-10-28 11:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:31:45 --> Final output sent to browser
DEBUG - 2016-10-28 11:31:45 --> Total execution time: 0.0168
INFO - 2016-10-28 11:31:45 --> Config Class Initialized
INFO - 2016-10-28 11:31:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:31:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:31:45 --> Utf8 Class Initialized
INFO - 2016-10-28 11:31:45 --> URI Class Initialized
DEBUG - 2016-10-28 11:31:45 --> No URI present. Default controller set.
INFO - 2016-10-28 11:31:45 --> Router Class Initialized
INFO - 2016-10-28 11:31:45 --> Output Class Initialized
INFO - 2016-10-28 11:31:45 --> Security Class Initialized
DEBUG - 2016-10-28 11:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:31:45 --> Input Class Initialized
INFO - 2016-10-28 11:31:45 --> Language Class Initialized
INFO - 2016-10-28 11:31:45 --> Loader Class Initialized
INFO - 2016-10-28 11:31:45 --> Helper loaded: url_helper
INFO - 2016-10-28 11:31:45 --> Helper loaded: form_helper
INFO - 2016-10-28 11:31:45 --> Database Driver Class Initialized
INFO - 2016-10-28 11:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:31:45 --> Controller Class Initialized
INFO - 2016-10-28 11:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:31:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:31:45 --> Final output sent to browser
DEBUG - 2016-10-28 11:31:45 --> Total execution time: 0.0157
INFO - 2016-10-28 11:33:03 --> Config Class Initialized
INFO - 2016-10-28 11:33:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:33:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:33:03 --> Utf8 Class Initialized
INFO - 2016-10-28 11:33:03 --> URI Class Initialized
DEBUG - 2016-10-28 11:33:03 --> No URI present. Default controller set.
INFO - 2016-10-28 11:33:03 --> Router Class Initialized
INFO - 2016-10-28 11:33:03 --> Output Class Initialized
INFO - 2016-10-28 11:33:03 --> Security Class Initialized
DEBUG - 2016-10-28 11:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:33:03 --> Input Class Initialized
INFO - 2016-10-28 11:33:03 --> Language Class Initialized
INFO - 2016-10-28 11:33:03 --> Loader Class Initialized
INFO - 2016-10-28 11:33:03 --> Helper loaded: url_helper
INFO - 2016-10-28 11:33:03 --> Helper loaded: form_helper
INFO - 2016-10-28 11:33:03 --> Database Driver Class Initialized
INFO - 2016-10-28 11:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:33:03 --> Controller Class Initialized
INFO - 2016-10-28 11:33:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:33:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:33:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:33:03 --> Final output sent to browser
DEBUG - 2016-10-28 11:33:03 --> Total execution time: 0.0169
INFO - 2016-10-28 11:33:07 --> Config Class Initialized
INFO - 2016-10-28 11:33:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:33:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:33:07 --> Utf8 Class Initialized
INFO - 2016-10-28 11:33:07 --> URI Class Initialized
INFO - 2016-10-28 11:33:07 --> Router Class Initialized
INFO - 2016-10-28 11:33:07 --> Output Class Initialized
INFO - 2016-10-28 11:33:07 --> Security Class Initialized
DEBUG - 2016-10-28 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:33:07 --> Input Class Initialized
INFO - 2016-10-28 11:33:07 --> Language Class Initialized
INFO - 2016-10-28 11:33:07 --> Loader Class Initialized
INFO - 2016-10-28 11:33:07 --> Helper loaded: url_helper
INFO - 2016-10-28 11:33:07 --> Helper loaded: form_helper
INFO - 2016-10-28 11:33:07 --> Database Driver Class Initialized
INFO - 2016-10-28 11:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:33:07 --> Controller Class Initialized
DEBUG - 2016-10-28 11:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:33:07 --> Model Class Initialized
INFO - 2016-10-28 11:33:07 --> Final output sent to browser
DEBUG - 2016-10-28 11:33:07 --> Total execution time: 0.0173
INFO - 2016-10-28 11:33:14 --> Config Class Initialized
INFO - 2016-10-28 11:33:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:33:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:33:14 --> Utf8 Class Initialized
INFO - 2016-10-28 11:33:14 --> URI Class Initialized
INFO - 2016-10-28 11:33:14 --> Router Class Initialized
INFO - 2016-10-28 11:33:14 --> Output Class Initialized
INFO - 2016-10-28 11:33:14 --> Security Class Initialized
DEBUG - 2016-10-28 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:33:14 --> Input Class Initialized
INFO - 2016-10-28 11:33:14 --> Language Class Initialized
INFO - 2016-10-28 11:33:14 --> Loader Class Initialized
INFO - 2016-10-28 11:33:14 --> Helper loaded: url_helper
INFO - 2016-10-28 11:33:14 --> Helper loaded: form_helper
INFO - 2016-10-28 11:33:14 --> Database Driver Class Initialized
INFO - 2016-10-28 11:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:33:14 --> Controller Class Initialized
DEBUG - 2016-10-28 11:33:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:33:14 --> Model Class Initialized
INFO - 2016-10-28 11:33:14 --> Final output sent to browser
DEBUG - 2016-10-28 11:33:14 --> Total execution time: 0.0182
INFO - 2016-10-28 11:33:14 --> Config Class Initialized
INFO - 2016-10-28 11:33:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:33:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:33:14 --> Utf8 Class Initialized
INFO - 2016-10-28 11:33:14 --> URI Class Initialized
DEBUG - 2016-10-28 11:33:14 --> No URI present. Default controller set.
INFO - 2016-10-28 11:33:14 --> Router Class Initialized
INFO - 2016-10-28 11:33:14 --> Output Class Initialized
INFO - 2016-10-28 11:33:14 --> Security Class Initialized
DEBUG - 2016-10-28 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:33:14 --> Input Class Initialized
INFO - 2016-10-28 11:33:14 --> Language Class Initialized
INFO - 2016-10-28 11:33:14 --> Loader Class Initialized
INFO - 2016-10-28 11:33:14 --> Helper loaded: url_helper
INFO - 2016-10-28 11:33:14 --> Helper loaded: form_helper
INFO - 2016-10-28 11:33:14 --> Database Driver Class Initialized
INFO - 2016-10-28 11:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:33:14 --> Controller Class Initialized
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:33:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:33:14 --> Final output sent to browser
DEBUG - 2016-10-28 11:33:14 --> Total execution time: 0.0159
INFO - 2016-10-28 11:33:46 --> Config Class Initialized
INFO - 2016-10-28 11:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:33:46 --> Utf8 Class Initialized
INFO - 2016-10-28 11:33:46 --> URI Class Initialized
INFO - 2016-10-28 11:33:46 --> Router Class Initialized
INFO - 2016-10-28 11:33:46 --> Output Class Initialized
INFO - 2016-10-28 11:33:46 --> Security Class Initialized
DEBUG - 2016-10-28 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:33:46 --> Input Class Initialized
INFO - 2016-10-28 11:33:46 --> Language Class Initialized
INFO - 2016-10-28 11:33:46 --> Loader Class Initialized
INFO - 2016-10-28 11:33:46 --> Helper loaded: url_helper
INFO - 2016-10-28 11:33:46 --> Helper loaded: form_helper
INFO - 2016-10-28 11:33:46 --> Database Driver Class Initialized
INFO - 2016-10-28 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:33:46 --> Controller Class Initialized
DEBUG - 2016-10-28 11:33:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 11:33:46 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 11:33:46 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 11:33:46 --> Config Class Initialized
INFO - 2016-10-28 11:33:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:33:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:33:46 --> Utf8 Class Initialized
INFO - 2016-10-28 11:33:46 --> URI Class Initialized
DEBUG - 2016-10-28 11:33:46 --> No URI present. Default controller set.
INFO - 2016-10-28 11:33:46 --> Router Class Initialized
INFO - 2016-10-28 11:33:46 --> Output Class Initialized
INFO - 2016-10-28 11:33:46 --> Security Class Initialized
DEBUG - 2016-10-28 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:33:46 --> Input Class Initialized
INFO - 2016-10-28 11:33:46 --> Language Class Initialized
INFO - 2016-10-28 11:33:46 --> Loader Class Initialized
INFO - 2016-10-28 11:33:46 --> Helper loaded: url_helper
INFO - 2016-10-28 11:33:46 --> Helper loaded: form_helper
INFO - 2016-10-28 11:33:46 --> Database Driver Class Initialized
INFO - 2016-10-28 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:33:46 --> Controller Class Initialized
INFO - 2016-10-28 11:33:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:33:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:33:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:33:46 --> Final output sent to browser
DEBUG - 2016-10-28 11:33:46 --> Total execution time: 0.0155
INFO - 2016-10-28 11:34:03 --> Config Class Initialized
INFO - 2016-10-28 11:34:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:34:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:34:03 --> Utf8 Class Initialized
INFO - 2016-10-28 11:34:03 --> URI Class Initialized
INFO - 2016-10-28 11:34:03 --> Router Class Initialized
INFO - 2016-10-28 11:34:03 --> Output Class Initialized
INFO - 2016-10-28 11:34:03 --> Security Class Initialized
DEBUG - 2016-10-28 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:34:03 --> Input Class Initialized
INFO - 2016-10-28 11:34:03 --> Language Class Initialized
INFO - 2016-10-28 11:34:03 --> Loader Class Initialized
INFO - 2016-10-28 11:34:03 --> Helper loaded: url_helper
INFO - 2016-10-28 11:34:03 --> Helper loaded: form_helper
INFO - 2016-10-28 11:34:03 --> Database Driver Class Initialized
INFO - 2016-10-28 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:34:03 --> Controller Class Initialized
DEBUG - 2016-10-28 11:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:34:03 --> Model Class Initialized
INFO - 2016-10-28 11:34:03 --> Final output sent to browser
DEBUG - 2016-10-28 11:34:03 --> Total execution time: 0.0182
INFO - 2016-10-28 11:34:03 --> Config Class Initialized
INFO - 2016-10-28 11:34:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:34:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:34:03 --> Utf8 Class Initialized
INFO - 2016-10-28 11:34:03 --> URI Class Initialized
DEBUG - 2016-10-28 11:34:03 --> No URI present. Default controller set.
INFO - 2016-10-28 11:34:03 --> Router Class Initialized
INFO - 2016-10-28 11:34:03 --> Output Class Initialized
INFO - 2016-10-28 11:34:03 --> Security Class Initialized
DEBUG - 2016-10-28 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:34:03 --> Input Class Initialized
INFO - 2016-10-28 11:34:03 --> Language Class Initialized
INFO - 2016-10-28 11:34:03 --> Loader Class Initialized
INFO - 2016-10-28 11:34:03 --> Helper loaded: url_helper
INFO - 2016-10-28 11:34:03 --> Helper loaded: form_helper
INFO - 2016-10-28 11:34:03 --> Database Driver Class Initialized
INFO - 2016-10-28 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:34:03 --> Controller Class Initialized
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:34:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:34:03 --> Final output sent to browser
DEBUG - 2016-10-28 11:34:03 --> Total execution time: 0.0163
INFO - 2016-10-28 11:34:12 --> Config Class Initialized
INFO - 2016-10-28 11:34:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:34:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:34:12 --> Utf8 Class Initialized
INFO - 2016-10-28 11:34:12 --> URI Class Initialized
INFO - 2016-10-28 11:34:12 --> Router Class Initialized
INFO - 2016-10-28 11:34:12 --> Output Class Initialized
INFO - 2016-10-28 11:34:12 --> Security Class Initialized
DEBUG - 2016-10-28 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:34:12 --> Input Class Initialized
INFO - 2016-10-28 11:34:12 --> Language Class Initialized
INFO - 2016-10-28 11:34:12 --> Loader Class Initialized
INFO - 2016-10-28 11:34:12 --> Helper loaded: url_helper
INFO - 2016-10-28 11:34:12 --> Helper loaded: form_helper
INFO - 2016-10-28 11:34:12 --> Database Driver Class Initialized
INFO - 2016-10-28 11:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:34:12 --> Controller Class Initialized
DEBUG - 2016-10-28 11:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 11:34:12 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 11:34:12 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 11:34:12 --> Config Class Initialized
INFO - 2016-10-28 11:34:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:34:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:34:12 --> Utf8 Class Initialized
INFO - 2016-10-28 11:34:12 --> URI Class Initialized
DEBUG - 2016-10-28 11:34:12 --> No URI present. Default controller set.
INFO - 2016-10-28 11:34:12 --> Router Class Initialized
INFO - 2016-10-28 11:34:12 --> Output Class Initialized
INFO - 2016-10-28 11:34:12 --> Security Class Initialized
DEBUG - 2016-10-28 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:34:12 --> Input Class Initialized
INFO - 2016-10-28 11:34:12 --> Language Class Initialized
INFO - 2016-10-28 11:34:12 --> Loader Class Initialized
INFO - 2016-10-28 11:34:12 --> Helper loaded: url_helper
INFO - 2016-10-28 11:34:12 --> Helper loaded: form_helper
INFO - 2016-10-28 11:34:12 --> Database Driver Class Initialized
INFO - 2016-10-28 11:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:34:12 --> Controller Class Initialized
INFO - 2016-10-28 11:34:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:34:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:34:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:34:12 --> Final output sent to browser
DEBUG - 2016-10-28 11:34:12 --> Total execution time: 0.0160
INFO - 2016-10-28 11:34:19 --> Config Class Initialized
INFO - 2016-10-28 11:34:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:34:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:34:19 --> Utf8 Class Initialized
INFO - 2016-10-28 11:34:19 --> URI Class Initialized
INFO - 2016-10-28 11:34:19 --> Router Class Initialized
INFO - 2016-10-28 11:34:19 --> Output Class Initialized
INFO - 2016-10-28 11:34:19 --> Security Class Initialized
DEBUG - 2016-10-28 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:34:19 --> Input Class Initialized
INFO - 2016-10-28 11:34:19 --> Language Class Initialized
INFO - 2016-10-28 11:34:19 --> Loader Class Initialized
INFO - 2016-10-28 11:34:19 --> Helper loaded: url_helper
INFO - 2016-10-28 11:34:19 --> Helper loaded: form_helper
INFO - 2016-10-28 11:34:19 --> Database Driver Class Initialized
INFO - 2016-10-28 11:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:34:19 --> Controller Class Initialized
DEBUG - 2016-10-28 11:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:34:19 --> Model Class Initialized
INFO - 2016-10-28 11:34:19 --> Final output sent to browser
DEBUG - 2016-10-28 11:34:19 --> Total execution time: 0.0182
INFO - 2016-10-28 11:34:19 --> Config Class Initialized
INFO - 2016-10-28 11:34:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:34:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:34:19 --> Utf8 Class Initialized
INFO - 2016-10-28 11:34:19 --> URI Class Initialized
DEBUG - 2016-10-28 11:34:19 --> No URI present. Default controller set.
INFO - 2016-10-28 11:34:19 --> Router Class Initialized
INFO - 2016-10-28 11:34:19 --> Output Class Initialized
INFO - 2016-10-28 11:34:19 --> Security Class Initialized
DEBUG - 2016-10-28 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:34:19 --> Input Class Initialized
INFO - 2016-10-28 11:34:19 --> Language Class Initialized
INFO - 2016-10-28 11:34:19 --> Loader Class Initialized
INFO - 2016-10-28 11:34:19 --> Helper loaded: url_helper
INFO - 2016-10-28 11:34:19 --> Helper loaded: form_helper
INFO - 2016-10-28 11:34:19 --> Database Driver Class Initialized
INFO - 2016-10-28 11:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:34:19 --> Controller Class Initialized
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/my_leave.php
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:34:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:34:19 --> Final output sent to browser
DEBUG - 2016-10-28 11:34:19 --> Total execution time: 0.0530
INFO - 2016-10-28 11:35:09 --> Config Class Initialized
INFO - 2016-10-28 11:35:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:35:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:35:09 --> Utf8 Class Initialized
INFO - 2016-10-28 11:35:09 --> URI Class Initialized
INFO - 2016-10-28 11:35:09 --> Router Class Initialized
INFO - 2016-10-28 11:35:09 --> Output Class Initialized
INFO - 2016-10-28 11:35:09 --> Security Class Initialized
DEBUG - 2016-10-28 11:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:35:09 --> Input Class Initialized
INFO - 2016-10-28 11:35:09 --> Language Class Initialized
INFO - 2016-10-28 11:35:09 --> Loader Class Initialized
INFO - 2016-10-28 11:35:09 --> Helper loaded: url_helper
INFO - 2016-10-28 11:35:09 --> Helper loaded: form_helper
INFO - 2016-10-28 11:35:09 --> Database Driver Class Initialized
INFO - 2016-10-28 11:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:35:09 --> Controller Class Initialized
DEBUG - 2016-10-28 11:35:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 11:35:09 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 11:35:09 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 11:35:09 --> Config Class Initialized
INFO - 2016-10-28 11:35:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:35:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:35:09 --> Utf8 Class Initialized
INFO - 2016-10-28 11:35:09 --> URI Class Initialized
DEBUG - 2016-10-28 11:35:09 --> No URI present. Default controller set.
INFO - 2016-10-28 11:35:09 --> Router Class Initialized
INFO - 2016-10-28 11:35:09 --> Output Class Initialized
INFO - 2016-10-28 11:35:09 --> Security Class Initialized
DEBUG - 2016-10-28 11:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:35:09 --> Input Class Initialized
INFO - 2016-10-28 11:35:09 --> Language Class Initialized
INFO - 2016-10-28 11:35:09 --> Loader Class Initialized
INFO - 2016-10-28 11:35:09 --> Helper loaded: url_helper
INFO - 2016-10-28 11:35:09 --> Helper loaded: form_helper
INFO - 2016-10-28 11:35:09 --> Database Driver Class Initialized
INFO - 2016-10-28 11:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:35:09 --> Controller Class Initialized
INFO - 2016-10-28 11:35:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:35:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 11:35:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:35:09 --> Final output sent to browser
DEBUG - 2016-10-28 11:35:09 --> Total execution time: 0.0149
INFO - 2016-10-28 11:35:15 --> Config Class Initialized
INFO - 2016-10-28 11:35:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:35:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:35:15 --> Utf8 Class Initialized
INFO - 2016-10-28 11:35:15 --> URI Class Initialized
INFO - 2016-10-28 11:35:15 --> Router Class Initialized
INFO - 2016-10-28 11:35:15 --> Output Class Initialized
INFO - 2016-10-28 11:35:15 --> Security Class Initialized
DEBUG - 2016-10-28 11:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:35:15 --> Input Class Initialized
INFO - 2016-10-28 11:35:15 --> Language Class Initialized
INFO - 2016-10-28 11:35:15 --> Loader Class Initialized
INFO - 2016-10-28 11:35:15 --> Helper loaded: url_helper
INFO - 2016-10-28 11:35:15 --> Helper loaded: form_helper
INFO - 2016-10-28 11:35:15 --> Database Driver Class Initialized
INFO - 2016-10-28 11:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:35:15 --> Controller Class Initialized
DEBUG - 2016-10-28 11:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 11:35:15 --> Model Class Initialized
INFO - 2016-10-28 11:35:15 --> Final output sent to browser
DEBUG - 2016-10-28 11:35:15 --> Total execution time: 0.0180
INFO - 2016-10-28 11:35:15 --> Config Class Initialized
INFO - 2016-10-28 11:35:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 11:35:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 11:35:15 --> Utf8 Class Initialized
INFO - 2016-10-28 11:35:15 --> URI Class Initialized
DEBUG - 2016-10-28 11:35:15 --> No URI present. Default controller set.
INFO - 2016-10-28 11:35:15 --> Router Class Initialized
INFO - 2016-10-28 11:35:15 --> Output Class Initialized
INFO - 2016-10-28 11:35:15 --> Security Class Initialized
DEBUG - 2016-10-28 11:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 11:35:15 --> Input Class Initialized
INFO - 2016-10-28 11:35:15 --> Language Class Initialized
INFO - 2016-10-28 11:35:15 --> Loader Class Initialized
INFO - 2016-10-28 11:35:15 --> Helper loaded: url_helper
INFO - 2016-10-28 11:35:15 --> Helper loaded: form_helper
INFO - 2016-10-28 11:35:15 --> Database Driver Class Initialized
INFO - 2016-10-28 11:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 11:35:15 --> Controller Class Initialized
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 11:35:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 11:35:15 --> Final output sent to browser
DEBUG - 2016-10-28 11:35:15 --> Total execution time: 0.0162
INFO - 2016-10-28 12:30:06 --> Config Class Initialized
INFO - 2016-10-28 12:30:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:30:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:30:06 --> Utf8 Class Initialized
INFO - 2016-10-28 12:30:06 --> URI Class Initialized
DEBUG - 2016-10-28 12:30:06 --> No URI present. Default controller set.
INFO - 2016-10-28 12:30:06 --> Router Class Initialized
INFO - 2016-10-28 12:30:06 --> Output Class Initialized
INFO - 2016-10-28 12:30:06 --> Security Class Initialized
DEBUG - 2016-10-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:30:06 --> Input Class Initialized
INFO - 2016-10-28 12:30:06 --> Language Class Initialized
INFO - 2016-10-28 12:30:06 --> Loader Class Initialized
INFO - 2016-10-28 12:30:06 --> Helper loaded: url_helper
INFO - 2016-10-28 12:30:06 --> Helper loaded: form_helper
INFO - 2016-10-28 12:30:06 --> Database Driver Class Initialized
INFO - 2016-10-28 12:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:30:06 --> Controller Class Initialized
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:30:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:30:06 --> Final output sent to browser
DEBUG - 2016-10-28 12:30:06 --> Total execution time: 0.0222
INFO - 2016-10-28 12:30:07 --> Config Class Initialized
INFO - 2016-10-28 12:30:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:30:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:30:07 --> Utf8 Class Initialized
INFO - 2016-10-28 12:30:07 --> URI Class Initialized
DEBUG - 2016-10-28 12:30:07 --> No URI present. Default controller set.
INFO - 2016-10-28 12:30:07 --> Router Class Initialized
INFO - 2016-10-28 12:30:07 --> Output Class Initialized
INFO - 2016-10-28 12:30:07 --> Security Class Initialized
DEBUG - 2016-10-28 12:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:30:07 --> Input Class Initialized
INFO - 2016-10-28 12:30:07 --> Language Class Initialized
INFO - 2016-10-28 12:30:07 --> Loader Class Initialized
INFO - 2016-10-28 12:30:07 --> Helper loaded: url_helper
INFO - 2016-10-28 12:30:07 --> Helper loaded: form_helper
INFO - 2016-10-28 12:30:07 --> Database Driver Class Initialized
INFO - 2016-10-28 12:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:30:07 --> Controller Class Initialized
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:30:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:30:07 --> Final output sent to browser
DEBUG - 2016-10-28 12:30:07 --> Total execution time: 0.0171
INFO - 2016-10-28 12:30:19 --> Config Class Initialized
INFO - 2016-10-28 12:30:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:30:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:30:19 --> Utf8 Class Initialized
INFO - 2016-10-28 12:30:19 --> URI Class Initialized
INFO - 2016-10-28 12:30:19 --> Router Class Initialized
INFO - 2016-10-28 12:30:19 --> Output Class Initialized
INFO - 2016-10-28 12:30:19 --> Security Class Initialized
DEBUG - 2016-10-28 12:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:30:19 --> Input Class Initialized
INFO - 2016-10-28 12:30:19 --> Language Class Initialized
INFO - 2016-10-28 12:30:19 --> Loader Class Initialized
INFO - 2016-10-28 12:30:19 --> Helper loaded: url_helper
INFO - 2016-10-28 12:30:19 --> Helper loaded: form_helper
INFO - 2016-10-28 12:30:19 --> Database Driver Class Initialized
INFO - 2016-10-28 12:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:30:19 --> Controller Class Initialized
INFO - 2016-10-28 12:30:19 --> Form Validation Class Initialized
INFO - 2016-10-28 12:30:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 12:30:19 --> Final output sent to browser
DEBUG - 2016-10-28 12:30:19 --> Total execution time: 0.0187
INFO - 2016-10-28 12:30:22 --> Config Class Initialized
INFO - 2016-10-28 12:30:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:30:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:30:22 --> Utf8 Class Initialized
INFO - 2016-10-28 12:30:22 --> URI Class Initialized
DEBUG - 2016-10-28 12:30:22 --> No URI present. Default controller set.
INFO - 2016-10-28 12:30:22 --> Router Class Initialized
INFO - 2016-10-28 12:30:22 --> Output Class Initialized
INFO - 2016-10-28 12:30:22 --> Security Class Initialized
DEBUG - 2016-10-28 12:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:30:22 --> Input Class Initialized
INFO - 2016-10-28 12:30:22 --> Language Class Initialized
INFO - 2016-10-28 12:30:22 --> Loader Class Initialized
INFO - 2016-10-28 12:30:22 --> Helper loaded: url_helper
INFO - 2016-10-28 12:30:22 --> Helper loaded: form_helper
INFO - 2016-10-28 12:30:22 --> Database Driver Class Initialized
INFO - 2016-10-28 12:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:30:22 --> Controller Class Initialized
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:30:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:30:22 --> Final output sent to browser
DEBUG - 2016-10-28 12:30:22 --> Total execution time: 0.0170
INFO - 2016-10-28 12:30:30 --> Config Class Initialized
INFO - 2016-10-28 12:30:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:30:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:30:30 --> Utf8 Class Initialized
INFO - 2016-10-28 12:30:30 --> URI Class Initialized
INFO - 2016-10-28 12:30:30 --> Router Class Initialized
INFO - 2016-10-28 12:30:30 --> Output Class Initialized
INFO - 2016-10-28 12:30:30 --> Security Class Initialized
DEBUG - 2016-10-28 12:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:30:30 --> Input Class Initialized
INFO - 2016-10-28 12:30:30 --> Language Class Initialized
INFO - 2016-10-28 12:30:30 --> Loader Class Initialized
INFO - 2016-10-28 12:30:30 --> Helper loaded: url_helper
INFO - 2016-10-28 12:30:30 --> Helper loaded: form_helper
INFO - 2016-10-28 12:30:30 --> Database Driver Class Initialized
INFO - 2016-10-28 12:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:30:30 --> Controller Class Initialized
INFO - 2016-10-28 12:30:30 --> Form Validation Class Initialized
INFO - 2016-10-28 12:30:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 12:30:30 --> Final output sent to browser
DEBUG - 2016-10-28 12:30:30 --> Total execution time: 0.0173
INFO - 2016-10-28 12:30:31 --> Config Class Initialized
INFO - 2016-10-28 12:30:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:30:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:30:31 --> Utf8 Class Initialized
INFO - 2016-10-28 12:30:31 --> URI Class Initialized
DEBUG - 2016-10-28 12:30:31 --> No URI present. Default controller set.
INFO - 2016-10-28 12:30:31 --> Router Class Initialized
INFO - 2016-10-28 12:30:31 --> Output Class Initialized
INFO - 2016-10-28 12:30:31 --> Security Class Initialized
DEBUG - 2016-10-28 12:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:30:31 --> Input Class Initialized
INFO - 2016-10-28 12:30:31 --> Language Class Initialized
INFO - 2016-10-28 12:30:31 --> Loader Class Initialized
INFO - 2016-10-28 12:30:31 --> Helper loaded: url_helper
INFO - 2016-10-28 12:30:31 --> Helper loaded: form_helper
INFO - 2016-10-28 12:30:31 --> Database Driver Class Initialized
INFO - 2016-10-28 12:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:30:31 --> Controller Class Initialized
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:30:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:30:31 --> Final output sent to browser
DEBUG - 2016-10-28 12:30:31 --> Total execution time: 0.0176
INFO - 2016-10-28 12:39:35 --> Config Class Initialized
INFO - 2016-10-28 12:39:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:39:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:39:35 --> Utf8 Class Initialized
INFO - 2016-10-28 12:39:35 --> URI Class Initialized
DEBUG - 2016-10-28 12:39:35 --> No URI present. Default controller set.
INFO - 2016-10-28 12:39:35 --> Router Class Initialized
INFO - 2016-10-28 12:39:35 --> Output Class Initialized
INFO - 2016-10-28 12:39:35 --> Security Class Initialized
DEBUG - 2016-10-28 12:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:39:35 --> Input Class Initialized
INFO - 2016-10-28 12:39:35 --> Language Class Initialized
INFO - 2016-10-28 12:39:35 --> Loader Class Initialized
INFO - 2016-10-28 12:39:35 --> Helper loaded: url_helper
INFO - 2016-10-28 12:39:35 --> Helper loaded: form_helper
INFO - 2016-10-28 12:39:35 --> Database Driver Class Initialized
INFO - 2016-10-28 12:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:39:35 --> Controller Class Initialized
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:39:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:39:35 --> Final output sent to browser
DEBUG - 2016-10-28 12:39:35 --> Total execution time: 0.0187
INFO - 2016-10-28 12:42:38 --> Config Class Initialized
INFO - 2016-10-28 12:42:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:42:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:42:38 --> Utf8 Class Initialized
INFO - 2016-10-28 12:42:38 --> URI Class Initialized
DEBUG - 2016-10-28 12:42:38 --> No URI present. Default controller set.
INFO - 2016-10-28 12:42:38 --> Router Class Initialized
INFO - 2016-10-28 12:42:38 --> Output Class Initialized
INFO - 2016-10-28 12:42:38 --> Security Class Initialized
DEBUG - 2016-10-28 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:42:38 --> Input Class Initialized
INFO - 2016-10-28 12:42:38 --> Language Class Initialized
INFO - 2016-10-28 12:42:38 --> Loader Class Initialized
INFO - 2016-10-28 12:42:38 --> Helper loaded: url_helper
INFO - 2016-10-28 12:42:38 --> Helper loaded: form_helper
INFO - 2016-10-28 12:42:38 --> Database Driver Class Initialized
INFO - 2016-10-28 12:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:42:38 --> Controller Class Initialized
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:42:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:42:38 --> Final output sent to browser
DEBUG - 2016-10-28 12:42:38 --> Total execution time: 0.0181
INFO - 2016-10-28 12:43:18 --> Config Class Initialized
INFO - 2016-10-28 12:43:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:43:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:43:18 --> Utf8 Class Initialized
INFO - 2016-10-28 12:43:18 --> URI Class Initialized
DEBUG - 2016-10-28 12:43:18 --> No URI present. Default controller set.
INFO - 2016-10-28 12:43:18 --> Router Class Initialized
INFO - 2016-10-28 12:43:18 --> Output Class Initialized
INFO - 2016-10-28 12:43:18 --> Security Class Initialized
DEBUG - 2016-10-28 12:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:43:18 --> Input Class Initialized
INFO - 2016-10-28 12:43:18 --> Language Class Initialized
INFO - 2016-10-28 12:43:18 --> Loader Class Initialized
INFO - 2016-10-28 12:43:18 --> Helper loaded: url_helper
INFO - 2016-10-28 12:43:18 --> Helper loaded: form_helper
INFO - 2016-10-28 12:43:18 --> Database Driver Class Initialized
ERROR - 2016-10-28 12:43:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'dev_teste'@'%' to database 'lms' /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-28 12:43:18 --> Unable to connect to the database
INFO - 2016-10-28 12:43:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 12:43:19 --> Config Class Initialized
INFO - 2016-10-28 12:43:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:43:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:43:19 --> Utf8 Class Initialized
INFO - 2016-10-28 12:43:19 --> URI Class Initialized
DEBUG - 2016-10-28 12:43:19 --> No URI present. Default controller set.
INFO - 2016-10-28 12:43:19 --> Router Class Initialized
INFO - 2016-10-28 12:43:19 --> Output Class Initialized
INFO - 2016-10-28 12:43:19 --> Security Class Initialized
DEBUG - 2016-10-28 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:43:19 --> Input Class Initialized
INFO - 2016-10-28 12:43:19 --> Language Class Initialized
INFO - 2016-10-28 12:43:19 --> Loader Class Initialized
INFO - 2016-10-28 12:43:19 --> Helper loaded: url_helper
INFO - 2016-10-28 12:43:19 --> Helper loaded: form_helper
INFO - 2016-10-28 12:43:19 --> Database Driver Class Initialized
ERROR - 2016-10-28 12:43:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'dev_teste'@'%' to database 'lms' /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-28 12:43:19 --> Unable to connect to the database
INFO - 2016-10-28 12:43:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 12:43:22 --> Config Class Initialized
INFO - 2016-10-28 12:43:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:43:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:43:22 --> Utf8 Class Initialized
INFO - 2016-10-28 12:43:22 --> URI Class Initialized
DEBUG - 2016-10-28 12:43:22 --> No URI present. Default controller set.
INFO - 2016-10-28 12:43:22 --> Router Class Initialized
INFO - 2016-10-28 12:43:22 --> Output Class Initialized
INFO - 2016-10-28 12:43:22 --> Security Class Initialized
DEBUG - 2016-10-28 12:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:43:22 --> Input Class Initialized
INFO - 2016-10-28 12:43:22 --> Language Class Initialized
INFO - 2016-10-28 12:43:22 --> Loader Class Initialized
INFO - 2016-10-28 12:43:22 --> Helper loaded: url_helper
INFO - 2016-10-28 12:43:22 --> Helper loaded: form_helper
INFO - 2016-10-28 12:43:22 --> Database Driver Class Initialized
ERROR - 2016-10-28 12:43:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'dev_teste'@'%' to database 'lms' /var/www/html/ramotlonyane_modise/LMS/sys/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-10-28 12:43:22 --> Unable to connect to the database
INFO - 2016-10-28 12:43:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 12:44:29 --> Config Class Initialized
INFO - 2016-10-28 12:44:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:29 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:29 --> URI Class Initialized
DEBUG - 2016-10-28 12:44:29 --> No URI present. Default controller set.
INFO - 2016-10-28 12:44:29 --> Router Class Initialized
INFO - 2016-10-28 12:44:29 --> Output Class Initialized
INFO - 2016-10-28 12:44:29 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:29 --> Input Class Initialized
INFO - 2016-10-28 12:44:29 --> Language Class Initialized
INFO - 2016-10-28 12:44:29 --> Loader Class Initialized
INFO - 2016-10-28 12:44:29 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:29 --> Helper loaded: form_helper
INFO - 2016-10-28 12:44:29 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:29 --> Controller Class Initialized
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:44:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:44:29 --> Final output sent to browser
DEBUG - 2016-10-28 12:44:29 --> Total execution time: 0.0212
INFO - 2016-10-28 12:44:31 --> Config Class Initialized
INFO - 2016-10-28 12:44:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:31 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:31 --> URI Class Initialized
DEBUG - 2016-10-28 12:44:31 --> No URI present. Default controller set.
INFO - 2016-10-28 12:44:31 --> Router Class Initialized
INFO - 2016-10-28 12:44:31 --> Output Class Initialized
INFO - 2016-10-28 12:44:31 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:31 --> Input Class Initialized
INFO - 2016-10-28 12:44:31 --> Language Class Initialized
INFO - 2016-10-28 12:44:31 --> Loader Class Initialized
INFO - 2016-10-28 12:44:31 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:31 --> Helper loaded: form_helper
INFO - 2016-10-28 12:44:31 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:31 --> Controller Class Initialized
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:44:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:44:31 --> Final output sent to browser
DEBUG - 2016-10-28 12:44:31 --> Total execution time: 0.0171
INFO - 2016-10-28 12:44:35 --> Config Class Initialized
INFO - 2016-10-28 12:44:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:35 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:35 --> URI Class Initialized
INFO - 2016-10-28 12:44:35 --> Router Class Initialized
INFO - 2016-10-28 12:44:35 --> Output Class Initialized
INFO - 2016-10-28 12:44:35 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:35 --> Input Class Initialized
INFO - 2016-10-28 12:44:35 --> Language Class Initialized
INFO - 2016-10-28 12:44:35 --> Loader Class Initialized
INFO - 2016-10-28 12:44:35 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:35 --> Helper loaded: form_helper
INFO - 2016-10-28 12:44:35 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:35 --> Controller Class Initialized
DEBUG - 2016-10-28 12:44:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 12:44:35 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
ERROR - 2016-10-28 12:44:35 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 89
INFO - 2016-10-28 12:44:35 --> Config Class Initialized
INFO - 2016-10-28 12:44:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:35 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:35 --> URI Class Initialized
DEBUG - 2016-10-28 12:44:35 --> No URI present. Default controller set.
INFO - 2016-10-28 12:44:35 --> Router Class Initialized
INFO - 2016-10-28 12:44:35 --> Output Class Initialized
INFO - 2016-10-28 12:44:35 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:35 --> Input Class Initialized
INFO - 2016-10-28 12:44:35 --> Language Class Initialized
INFO - 2016-10-28 12:44:35 --> Loader Class Initialized
INFO - 2016-10-28 12:44:35 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:35 --> Helper loaded: form_helper
INFO - 2016-10-28 12:44:35 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:35 --> Controller Class Initialized
INFO - 2016-10-28 12:44:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:44:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 12:44:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:44:35 --> Final output sent to browser
DEBUG - 2016-10-28 12:44:35 --> Total execution time: 0.0150
INFO - 2016-10-28 12:44:41 --> Config Class Initialized
INFO - 2016-10-28 12:44:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:41 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:41 --> URI Class Initialized
INFO - 2016-10-28 12:44:41 --> Router Class Initialized
INFO - 2016-10-28 12:44:41 --> Output Class Initialized
INFO - 2016-10-28 12:44:41 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:41 --> Input Class Initialized
INFO - 2016-10-28 12:44:41 --> Language Class Initialized
INFO - 2016-10-28 12:44:41 --> Loader Class Initialized
INFO - 2016-10-28 12:44:41 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:41 --> Helper loaded: form_helper
INFO - 2016-10-28 12:44:41 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:41 --> Controller Class Initialized
DEBUG - 2016-10-28 12:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 12:44:41 --> Model Class Initialized
ERROR - 2016-10-28 12:44:41 --> Query error: Table 'dev_teste.auth' doesn't exist - Invalid query: SELECT *
FROM `auth`
WHERE `username` = 'admin'
AND `password` = 'd033e22ae348aeb5660fc2140aec35850c4da997'
INFO - 2016-10-28 12:44:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 12:44:43 --> Config Class Initialized
INFO - 2016-10-28 12:44:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:44:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:44:43 --> Utf8 Class Initialized
INFO - 2016-10-28 12:44:43 --> URI Class Initialized
DEBUG - 2016-10-28 12:44:43 --> No URI present. Default controller set.
INFO - 2016-10-28 12:44:43 --> Router Class Initialized
INFO - 2016-10-28 12:44:43 --> Output Class Initialized
INFO - 2016-10-28 12:44:43 --> Security Class Initialized
DEBUG - 2016-10-28 12:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:44:43 --> Input Class Initialized
INFO - 2016-10-28 12:44:43 --> Language Class Initialized
INFO - 2016-10-28 12:44:43 --> Loader Class Initialized
INFO - 2016-10-28 12:44:43 --> Helper loaded: url_helper
INFO - 2016-10-28 12:44:43 --> Helper loaded: form_helper
INFO - 2016-10-28 12:44:43 --> Database Driver Class Initialized
INFO - 2016-10-28 12:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:44:43 --> Controller Class Initialized
INFO - 2016-10-28 12:44:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:44:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 12:44:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:44:43 --> Final output sent to browser
DEBUG - 2016-10-28 12:44:43 --> Total execution time: 0.0167
INFO - 2016-10-28 12:48:10 --> Config Class Initialized
INFO - 2016-10-28 12:48:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:48:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:48:10 --> Utf8 Class Initialized
INFO - 2016-10-28 12:48:10 --> URI Class Initialized
DEBUG - 2016-10-28 12:48:10 --> No URI present. Default controller set.
INFO - 2016-10-28 12:48:10 --> Router Class Initialized
INFO - 2016-10-28 12:48:10 --> Output Class Initialized
INFO - 2016-10-28 12:48:10 --> Security Class Initialized
DEBUG - 2016-10-28 12:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:48:10 --> Input Class Initialized
INFO - 2016-10-28 12:48:10 --> Language Class Initialized
INFO - 2016-10-28 12:48:10 --> Loader Class Initialized
INFO - 2016-10-28 12:48:10 --> Helper loaded: url_helper
INFO - 2016-10-28 12:48:10 --> Helper loaded: form_helper
INFO - 2016-10-28 12:48:10 --> Database Driver Class Initialized
INFO - 2016-10-28 12:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:48:10 --> Controller Class Initialized
INFO - 2016-10-28 12:48:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:48:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 12:48:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:48:10 --> Final output sent to browser
DEBUG - 2016-10-28 12:48:10 --> Total execution time: 0.0575
INFO - 2016-10-28 12:48:13 --> Config Class Initialized
INFO - 2016-10-28 12:48:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:48:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:48:13 --> Utf8 Class Initialized
INFO - 2016-10-28 12:48:13 --> URI Class Initialized
INFO - 2016-10-28 12:48:13 --> Router Class Initialized
INFO - 2016-10-28 12:48:13 --> Output Class Initialized
INFO - 2016-10-28 12:48:13 --> Security Class Initialized
DEBUG - 2016-10-28 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:48:13 --> Input Class Initialized
INFO - 2016-10-28 12:48:13 --> Language Class Initialized
INFO - 2016-10-28 12:48:13 --> Loader Class Initialized
INFO - 2016-10-28 12:48:13 --> Helper loaded: url_helper
INFO - 2016-10-28 12:48:13 --> Helper loaded: form_helper
INFO - 2016-10-28 12:48:13 --> Database Driver Class Initialized
INFO - 2016-10-28 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:48:13 --> Controller Class Initialized
DEBUG - 2016-10-28 12:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 12:48:13 --> Model Class Initialized
INFO - 2016-10-28 12:48:13 --> Final output sent to browser
DEBUG - 2016-10-28 12:48:13 --> Total execution time: 0.0183
INFO - 2016-10-28 12:48:20 --> Config Class Initialized
INFO - 2016-10-28 12:48:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:48:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:48:20 --> Utf8 Class Initialized
INFO - 2016-10-28 12:48:20 --> URI Class Initialized
INFO - 2016-10-28 12:48:20 --> Router Class Initialized
INFO - 2016-10-28 12:48:20 --> Output Class Initialized
INFO - 2016-10-28 12:48:20 --> Security Class Initialized
DEBUG - 2016-10-28 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:48:20 --> Input Class Initialized
INFO - 2016-10-28 12:48:20 --> Language Class Initialized
INFO - 2016-10-28 12:48:20 --> Loader Class Initialized
INFO - 2016-10-28 12:48:20 --> Helper loaded: url_helper
INFO - 2016-10-28 12:48:20 --> Helper loaded: form_helper
INFO - 2016-10-28 12:48:20 --> Database Driver Class Initialized
INFO - 2016-10-28 12:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:48:20 --> Controller Class Initialized
DEBUG - 2016-10-28 12:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 12:48:20 --> Model Class Initialized
INFO - 2016-10-28 12:48:20 --> Final output sent to browser
DEBUG - 2016-10-28 12:48:20 --> Total execution time: 0.0184
INFO - 2016-10-28 12:48:25 --> Config Class Initialized
INFO - 2016-10-28 12:48:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:48:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:48:25 --> Utf8 Class Initialized
INFO - 2016-10-28 12:48:25 --> URI Class Initialized
INFO - 2016-10-28 12:48:25 --> Router Class Initialized
INFO - 2016-10-28 12:48:25 --> Output Class Initialized
INFO - 2016-10-28 12:48:25 --> Security Class Initialized
DEBUG - 2016-10-28 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:48:25 --> Input Class Initialized
INFO - 2016-10-28 12:48:25 --> Language Class Initialized
INFO - 2016-10-28 12:48:25 --> Loader Class Initialized
INFO - 2016-10-28 12:48:25 --> Helper loaded: url_helper
INFO - 2016-10-28 12:48:25 --> Helper loaded: form_helper
INFO - 2016-10-28 12:48:25 --> Database Driver Class Initialized
INFO - 2016-10-28 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:48:25 --> Controller Class Initialized
DEBUG - 2016-10-28 12:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 12:48:25 --> Model Class Initialized
INFO - 2016-10-28 12:48:25 --> Final output sent to browser
DEBUG - 2016-10-28 12:48:25 --> Total execution time: 0.0180
INFO - 2016-10-28 12:49:50 --> Config Class Initialized
INFO - 2016-10-28 12:49:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:49:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:49:50 --> Utf8 Class Initialized
INFO - 2016-10-28 12:49:50 --> URI Class Initialized
DEBUG - 2016-10-28 12:49:50 --> No URI present. Default controller set.
INFO - 2016-10-28 12:49:50 --> Router Class Initialized
INFO - 2016-10-28 12:49:50 --> Output Class Initialized
INFO - 2016-10-28 12:49:50 --> Security Class Initialized
DEBUG - 2016-10-28 12:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:49:50 --> Input Class Initialized
INFO - 2016-10-28 12:49:50 --> Language Class Initialized
INFO - 2016-10-28 12:49:50 --> Loader Class Initialized
INFO - 2016-10-28 12:49:50 --> Helper loaded: url_helper
INFO - 2016-10-28 12:49:50 --> Helper loaded: form_helper
INFO - 2016-10-28 12:49:50 --> Database Driver Class Initialized
INFO - 2016-10-28 12:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:49:50 --> Controller Class Initialized
INFO - 2016-10-28 12:49:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:49:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 12:49:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:49:50 --> Final output sent to browser
DEBUG - 2016-10-28 12:49:50 --> Total execution time: 0.0167
INFO - 2016-10-28 12:49:56 --> Config Class Initialized
INFO - 2016-10-28 12:49:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:49:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:49:56 --> Utf8 Class Initialized
INFO - 2016-10-28 12:49:56 --> URI Class Initialized
INFO - 2016-10-28 12:49:56 --> Router Class Initialized
INFO - 2016-10-28 12:49:56 --> Output Class Initialized
INFO - 2016-10-28 12:49:56 --> Security Class Initialized
DEBUG - 2016-10-28 12:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:49:56 --> Input Class Initialized
INFO - 2016-10-28 12:49:56 --> Language Class Initialized
INFO - 2016-10-28 12:49:56 --> Loader Class Initialized
INFO - 2016-10-28 12:49:56 --> Helper loaded: url_helper
INFO - 2016-10-28 12:49:56 --> Helper loaded: form_helper
INFO - 2016-10-28 12:49:56 --> Database Driver Class Initialized
INFO - 2016-10-28 12:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:49:56 --> Controller Class Initialized
DEBUG - 2016-10-28 12:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 12:49:56 --> Model Class Initialized
INFO - 2016-10-28 12:49:56 --> Final output sent to browser
DEBUG - 2016-10-28 12:49:56 --> Total execution time: 0.0176
INFO - 2016-10-28 12:49:56 --> Config Class Initialized
INFO - 2016-10-28 12:49:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:49:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:49:56 --> Utf8 Class Initialized
INFO - 2016-10-28 12:49:56 --> URI Class Initialized
DEBUG - 2016-10-28 12:49:56 --> No URI present. Default controller set.
INFO - 2016-10-28 12:49:56 --> Router Class Initialized
INFO - 2016-10-28 12:49:56 --> Output Class Initialized
INFO - 2016-10-28 12:49:56 --> Security Class Initialized
DEBUG - 2016-10-28 12:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:49:56 --> Input Class Initialized
INFO - 2016-10-28 12:49:56 --> Language Class Initialized
INFO - 2016-10-28 12:49:56 --> Loader Class Initialized
INFO - 2016-10-28 12:49:56 --> Helper loaded: url_helper
INFO - 2016-10-28 12:49:56 --> Helper loaded: form_helper
INFO - 2016-10-28 12:49:56 --> Database Driver Class Initialized
INFO - 2016-10-28 12:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:49:56 --> Controller Class Initialized
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:49:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:49:56 --> Final output sent to browser
DEBUG - 2016-10-28 12:49:56 --> Total execution time: 0.0161
INFO - 2016-10-28 12:49:58 --> Config Class Initialized
INFO - 2016-10-28 12:49:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:49:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:49:58 --> Utf8 Class Initialized
INFO - 2016-10-28 12:49:58 --> URI Class Initialized
DEBUG - 2016-10-28 12:49:58 --> No URI present. Default controller set.
INFO - 2016-10-28 12:49:58 --> Router Class Initialized
INFO - 2016-10-28 12:49:58 --> Output Class Initialized
INFO - 2016-10-28 12:49:58 --> Security Class Initialized
DEBUG - 2016-10-28 12:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:49:58 --> Input Class Initialized
INFO - 2016-10-28 12:49:58 --> Language Class Initialized
INFO - 2016-10-28 12:49:58 --> Loader Class Initialized
INFO - 2016-10-28 12:49:58 --> Helper loaded: url_helper
INFO - 2016-10-28 12:49:58 --> Helper loaded: form_helper
INFO - 2016-10-28 12:49:58 --> Database Driver Class Initialized
INFO - 2016-10-28 12:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:49:58 --> Controller Class Initialized
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:49:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:49:58 --> Final output sent to browser
DEBUG - 2016-10-28 12:49:58 --> Total execution time: 0.0206
INFO - 2016-10-28 12:50:09 --> Config Class Initialized
INFO - 2016-10-28 12:50:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 12:50:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 12:50:09 --> Utf8 Class Initialized
INFO - 2016-10-28 12:50:09 --> URI Class Initialized
DEBUG - 2016-10-28 12:50:09 --> No URI present. Default controller set.
INFO - 2016-10-28 12:50:09 --> Router Class Initialized
INFO - 2016-10-28 12:50:09 --> Output Class Initialized
INFO - 2016-10-28 12:50:09 --> Security Class Initialized
DEBUG - 2016-10-28 12:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 12:50:09 --> Input Class Initialized
INFO - 2016-10-28 12:50:09 --> Language Class Initialized
INFO - 2016-10-28 12:50:09 --> Loader Class Initialized
INFO - 2016-10-28 12:50:09 --> Helper loaded: url_helper
INFO - 2016-10-28 12:50:09 --> Helper loaded: form_helper
INFO - 2016-10-28 12:50:09 --> Database Driver Class Initialized
INFO - 2016-10-28 12:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 12:50:09 --> Controller Class Initialized
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 12:50:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 12:50:09 --> Final output sent to browser
DEBUG - 2016-10-28 12:50:09 --> Total execution time: 0.0166
INFO - 2016-10-28 13:10:14 --> Config Class Initialized
INFO - 2016-10-28 13:10:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:10:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:10:14 --> Utf8 Class Initialized
INFO - 2016-10-28 13:10:14 --> URI Class Initialized
DEBUG - 2016-10-28 13:10:14 --> No URI present. Default controller set.
INFO - 2016-10-28 13:10:14 --> Router Class Initialized
INFO - 2016-10-28 13:10:14 --> Output Class Initialized
INFO - 2016-10-28 13:10:14 --> Security Class Initialized
DEBUG - 2016-10-28 13:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:10:14 --> Input Class Initialized
INFO - 2016-10-28 13:10:14 --> Language Class Initialized
INFO - 2016-10-28 13:10:14 --> Loader Class Initialized
INFO - 2016-10-28 13:10:14 --> Helper loaded: url_helper
INFO - 2016-10-28 13:10:14 --> Helper loaded: form_helper
INFO - 2016-10-28 13:10:14 --> Database Driver Class Initialized
INFO - 2016-10-28 13:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:10:14 --> Controller Class Initialized
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:10:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:10:14 --> Final output sent to browser
DEBUG - 2016-10-28 13:10:14 --> Total execution time: 0.0189
INFO - 2016-10-28 13:10:52 --> Config Class Initialized
INFO - 2016-10-28 13:10:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:10:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:10:52 --> Utf8 Class Initialized
INFO - 2016-10-28 13:10:52 --> URI Class Initialized
DEBUG - 2016-10-28 13:10:52 --> No URI present. Default controller set.
INFO - 2016-10-28 13:10:52 --> Router Class Initialized
INFO - 2016-10-28 13:10:52 --> Output Class Initialized
INFO - 2016-10-28 13:10:52 --> Security Class Initialized
DEBUG - 2016-10-28 13:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:10:52 --> Input Class Initialized
INFO - 2016-10-28 13:10:52 --> Language Class Initialized
INFO - 2016-10-28 13:10:52 --> Loader Class Initialized
INFO - 2016-10-28 13:10:52 --> Helper loaded: url_helper
INFO - 2016-10-28 13:10:52 --> Helper loaded: form_helper
INFO - 2016-10-28 13:10:52 --> Database Driver Class Initialized
INFO - 2016-10-28 13:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:10:52 --> Controller Class Initialized
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:10:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:10:52 --> Final output sent to browser
DEBUG - 2016-10-28 13:10:52 --> Total execution time: 0.0173
INFO - 2016-10-28 13:10:56 --> Config Class Initialized
INFO - 2016-10-28 13:10:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:10:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:10:56 --> Utf8 Class Initialized
INFO - 2016-10-28 13:10:56 --> URI Class Initialized
INFO - 2016-10-28 13:10:56 --> Router Class Initialized
INFO - 2016-10-28 13:10:56 --> Output Class Initialized
INFO - 2016-10-28 13:10:56 --> Security Class Initialized
DEBUG - 2016-10-28 13:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:10:56 --> Input Class Initialized
INFO - 2016-10-28 13:10:56 --> Language Class Initialized
INFO - 2016-10-28 13:10:56 --> Loader Class Initialized
INFO - 2016-10-28 13:10:56 --> Helper loaded: url_helper
INFO - 2016-10-28 13:10:56 --> Helper loaded: form_helper
INFO - 2016-10-28 13:10:56 --> Database Driver Class Initialized
INFO - 2016-10-28 13:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:10:56 --> Controller Class Initialized
INFO - 2016-10-28 13:10:56 --> Form Validation Class Initialized
INFO - 2016-10-28 13:10:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:10:56 --> Final output sent to browser
DEBUG - 2016-10-28 13:10:56 --> Total execution time: 0.0170
INFO - 2016-10-28 13:10:57 --> Config Class Initialized
INFO - 2016-10-28 13:10:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:10:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:10:57 --> Utf8 Class Initialized
INFO - 2016-10-28 13:10:57 --> URI Class Initialized
DEBUG - 2016-10-28 13:10:57 --> No URI present. Default controller set.
INFO - 2016-10-28 13:10:57 --> Router Class Initialized
INFO - 2016-10-28 13:10:57 --> Output Class Initialized
INFO - 2016-10-28 13:10:57 --> Security Class Initialized
DEBUG - 2016-10-28 13:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:10:57 --> Input Class Initialized
INFO - 2016-10-28 13:10:57 --> Language Class Initialized
INFO - 2016-10-28 13:10:57 --> Loader Class Initialized
INFO - 2016-10-28 13:10:57 --> Helper loaded: url_helper
INFO - 2016-10-28 13:10:57 --> Helper loaded: form_helper
INFO - 2016-10-28 13:10:57 --> Database Driver Class Initialized
INFO - 2016-10-28 13:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:10:57 --> Controller Class Initialized
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:10:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:10:57 --> Final output sent to browser
DEBUG - 2016-10-28 13:10:57 --> Total execution time: 0.0170
INFO - 2016-10-28 13:13:42 --> Config Class Initialized
INFO - 2016-10-28 13:13:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:13:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:13:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:13:42 --> URI Class Initialized
DEBUG - 2016-10-28 13:13:42 --> No URI present. Default controller set.
INFO - 2016-10-28 13:13:42 --> Router Class Initialized
INFO - 2016-10-28 13:13:42 --> Output Class Initialized
INFO - 2016-10-28 13:13:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:13:42 --> Input Class Initialized
INFO - 2016-10-28 13:13:42 --> Language Class Initialized
INFO - 2016-10-28 13:13:42 --> Loader Class Initialized
INFO - 2016-10-28 13:13:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:13:42 --> Helper loaded: form_helper
INFO - 2016-10-28 13:13:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:13:42 --> Controller Class Initialized
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:13:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:13:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:13:42 --> Total execution time: 0.0178
INFO - 2016-10-28 13:13:58 --> Config Class Initialized
INFO - 2016-10-28 13:13:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:13:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:13:58 --> Utf8 Class Initialized
INFO - 2016-10-28 13:13:58 --> URI Class Initialized
DEBUG - 2016-10-28 13:13:58 --> No URI present. Default controller set.
INFO - 2016-10-28 13:13:58 --> Router Class Initialized
INFO - 2016-10-28 13:13:58 --> Output Class Initialized
INFO - 2016-10-28 13:13:58 --> Security Class Initialized
DEBUG - 2016-10-28 13:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:13:58 --> Input Class Initialized
INFO - 2016-10-28 13:13:58 --> Language Class Initialized
INFO - 2016-10-28 13:13:58 --> Loader Class Initialized
INFO - 2016-10-28 13:13:58 --> Helper loaded: url_helper
INFO - 2016-10-28 13:13:58 --> Helper loaded: form_helper
INFO - 2016-10-28 13:13:58 --> Database Driver Class Initialized
INFO - 2016-10-28 13:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:13:58 --> Controller Class Initialized
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:13:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:13:58 --> Final output sent to browser
DEBUG - 2016-10-28 13:13:58 --> Total execution time: 0.0192
INFO - 2016-10-28 13:14:21 --> Config Class Initialized
INFO - 2016-10-28 13:14:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:14:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:14:21 --> Utf8 Class Initialized
INFO - 2016-10-28 13:14:21 --> URI Class Initialized
DEBUG - 2016-10-28 13:14:21 --> No URI present. Default controller set.
INFO - 2016-10-28 13:14:21 --> Router Class Initialized
INFO - 2016-10-28 13:14:21 --> Output Class Initialized
INFO - 2016-10-28 13:14:21 --> Security Class Initialized
DEBUG - 2016-10-28 13:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:14:21 --> Input Class Initialized
INFO - 2016-10-28 13:14:21 --> Language Class Initialized
INFO - 2016-10-28 13:14:21 --> Loader Class Initialized
INFO - 2016-10-28 13:14:21 --> Helper loaded: url_helper
INFO - 2016-10-28 13:14:21 --> Helper loaded: form_helper
INFO - 2016-10-28 13:14:21 --> Database Driver Class Initialized
INFO - 2016-10-28 13:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:14:21 --> Controller Class Initialized
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:14:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:14:21 --> Final output sent to browser
DEBUG - 2016-10-28 13:14:21 --> Total execution time: 0.0170
INFO - 2016-10-28 13:14:50 --> Config Class Initialized
INFO - 2016-10-28 13:14:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:14:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:14:50 --> Utf8 Class Initialized
INFO - 2016-10-28 13:14:50 --> URI Class Initialized
DEBUG - 2016-10-28 13:14:50 --> No URI present. Default controller set.
INFO - 2016-10-28 13:14:50 --> Router Class Initialized
INFO - 2016-10-28 13:14:50 --> Output Class Initialized
INFO - 2016-10-28 13:14:50 --> Security Class Initialized
DEBUG - 2016-10-28 13:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:14:50 --> Input Class Initialized
INFO - 2016-10-28 13:14:50 --> Language Class Initialized
INFO - 2016-10-28 13:14:50 --> Loader Class Initialized
INFO - 2016-10-28 13:14:50 --> Helper loaded: url_helper
INFO - 2016-10-28 13:14:50 --> Helper loaded: form_helper
INFO - 2016-10-28 13:14:50 --> Database Driver Class Initialized
INFO - 2016-10-28 13:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:14:50 --> Controller Class Initialized
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:14:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:14:50 --> Final output sent to browser
DEBUG - 2016-10-28 13:14:50 --> Total execution time: 0.0168
INFO - 2016-10-28 13:14:55 --> Config Class Initialized
INFO - 2016-10-28 13:14:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:14:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:14:55 --> Utf8 Class Initialized
INFO - 2016-10-28 13:14:55 --> URI Class Initialized
INFO - 2016-10-28 13:14:55 --> Router Class Initialized
INFO - 2016-10-28 13:14:55 --> Output Class Initialized
INFO - 2016-10-28 13:14:55 --> Security Class Initialized
DEBUG - 2016-10-28 13:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:14:55 --> Input Class Initialized
INFO - 2016-10-28 13:14:55 --> Language Class Initialized
INFO - 2016-10-28 13:14:55 --> Loader Class Initialized
INFO - 2016-10-28 13:14:55 --> Helper loaded: url_helper
INFO - 2016-10-28 13:14:55 --> Helper loaded: form_helper
INFO - 2016-10-28 13:14:55 --> Database Driver Class Initialized
INFO - 2016-10-28 13:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:14:55 --> Controller Class Initialized
INFO - 2016-10-28 13:14:55 --> Form Validation Class Initialized
INFO - 2016-10-28 13:14:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:14:55 --> Final output sent to browser
DEBUG - 2016-10-28 13:14:55 --> Total execution time: 0.0178
INFO - 2016-10-28 13:14:59 --> Config Class Initialized
INFO - 2016-10-28 13:14:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:14:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:14:59 --> Utf8 Class Initialized
INFO - 2016-10-28 13:14:59 --> URI Class Initialized
DEBUG - 2016-10-28 13:14:59 --> No URI present. Default controller set.
INFO - 2016-10-28 13:14:59 --> Router Class Initialized
INFO - 2016-10-28 13:14:59 --> Output Class Initialized
INFO - 2016-10-28 13:14:59 --> Security Class Initialized
DEBUG - 2016-10-28 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:14:59 --> Input Class Initialized
INFO - 2016-10-28 13:14:59 --> Language Class Initialized
INFO - 2016-10-28 13:14:59 --> Loader Class Initialized
INFO - 2016-10-28 13:14:59 --> Helper loaded: url_helper
INFO - 2016-10-28 13:14:59 --> Helper loaded: form_helper
INFO - 2016-10-28 13:14:59 --> Database Driver Class Initialized
INFO - 2016-10-28 13:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:14:59 --> Controller Class Initialized
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:14:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:14:59 --> Final output sent to browser
DEBUG - 2016-10-28 13:14:59 --> Total execution time: 0.0166
INFO - 2016-10-28 13:15:40 --> Config Class Initialized
INFO - 2016-10-28 13:15:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:15:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:15:40 --> Utf8 Class Initialized
INFO - 2016-10-28 13:15:40 --> URI Class Initialized
DEBUG - 2016-10-28 13:15:40 --> No URI present. Default controller set.
INFO - 2016-10-28 13:15:40 --> Router Class Initialized
INFO - 2016-10-28 13:15:40 --> Output Class Initialized
INFO - 2016-10-28 13:15:40 --> Security Class Initialized
DEBUG - 2016-10-28 13:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:15:40 --> Input Class Initialized
INFO - 2016-10-28 13:15:40 --> Language Class Initialized
INFO - 2016-10-28 13:15:40 --> Loader Class Initialized
INFO - 2016-10-28 13:15:40 --> Helper loaded: url_helper
INFO - 2016-10-28 13:15:40 --> Helper loaded: form_helper
INFO - 2016-10-28 13:15:40 --> Database Driver Class Initialized
INFO - 2016-10-28 13:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:15:40 --> Controller Class Initialized
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:15:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:15:40 --> Final output sent to browser
DEBUG - 2016-10-28 13:15:40 --> Total execution time: 0.0205
INFO - 2016-10-28 13:15:42 --> Config Class Initialized
INFO - 2016-10-28 13:15:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:15:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:15:42 --> Utf8 Class Initialized
INFO - 2016-10-28 13:15:42 --> URI Class Initialized
INFO - 2016-10-28 13:15:42 --> Router Class Initialized
INFO - 2016-10-28 13:15:42 --> Output Class Initialized
INFO - 2016-10-28 13:15:42 --> Security Class Initialized
DEBUG - 2016-10-28 13:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:15:42 --> Input Class Initialized
INFO - 2016-10-28 13:15:42 --> Language Class Initialized
INFO - 2016-10-28 13:15:42 --> Loader Class Initialized
INFO - 2016-10-28 13:15:42 --> Helper loaded: url_helper
INFO - 2016-10-28 13:15:42 --> Helper loaded: form_helper
INFO - 2016-10-28 13:15:42 --> Database Driver Class Initialized
INFO - 2016-10-28 13:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:15:42 --> Controller Class Initialized
INFO - 2016-10-28 13:15:42 --> Form Validation Class Initialized
INFO - 2016-10-28 13:15:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:15:42 --> Final output sent to browser
DEBUG - 2016-10-28 13:15:42 --> Total execution time: 0.0170
INFO - 2016-10-28 13:15:47 --> Config Class Initialized
INFO - 2016-10-28 13:15:47 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:15:47 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:15:47 --> Utf8 Class Initialized
INFO - 2016-10-28 13:15:47 --> URI Class Initialized
INFO - 2016-10-28 13:15:47 --> Router Class Initialized
INFO - 2016-10-28 13:15:47 --> Output Class Initialized
INFO - 2016-10-28 13:15:47 --> Security Class Initialized
DEBUG - 2016-10-28 13:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:15:47 --> Input Class Initialized
INFO - 2016-10-28 13:15:47 --> Language Class Initialized
INFO - 2016-10-28 13:15:47 --> Loader Class Initialized
INFO - 2016-10-28 13:15:47 --> Helper loaded: url_helper
INFO - 2016-10-28 13:15:47 --> Helper loaded: form_helper
INFO - 2016-10-28 13:15:47 --> Database Driver Class Initialized
INFO - 2016-10-28 13:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:15:47 --> Controller Class Initialized
INFO - 2016-10-28 13:15:47 --> Form Validation Class Initialized
INFO - 2016-10-28 13:15:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:15:47 --> Final output sent to browser
DEBUG - 2016-10-28 13:15:47 --> Total execution time: 0.0168
INFO - 2016-10-28 13:15:49 --> Config Class Initialized
INFO - 2016-10-28 13:15:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:15:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:15:49 --> Utf8 Class Initialized
INFO - 2016-10-28 13:15:49 --> URI Class Initialized
INFO - 2016-10-28 13:15:49 --> Router Class Initialized
INFO - 2016-10-28 13:15:49 --> Output Class Initialized
INFO - 2016-10-28 13:15:49 --> Security Class Initialized
DEBUG - 2016-10-28 13:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:15:49 --> Input Class Initialized
INFO - 2016-10-28 13:15:49 --> Language Class Initialized
INFO - 2016-10-28 13:15:49 --> Loader Class Initialized
INFO - 2016-10-28 13:15:49 --> Helper loaded: url_helper
INFO - 2016-10-28 13:15:49 --> Helper loaded: form_helper
INFO - 2016-10-28 13:15:49 --> Database Driver Class Initialized
INFO - 2016-10-28 13:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:15:49 --> Controller Class Initialized
INFO - 2016-10-28 13:15:49 --> Form Validation Class Initialized
INFO - 2016-10-28 13:15:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:15:49 --> Final output sent to browser
DEBUG - 2016-10-28 13:15:49 --> Total execution time: 0.0169
INFO - 2016-10-28 13:16:09 --> Config Class Initialized
INFO - 2016-10-28 13:16:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:16:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:16:09 --> Utf8 Class Initialized
INFO - 2016-10-28 13:16:09 --> URI Class Initialized
DEBUG - 2016-10-28 13:16:09 --> No URI present. Default controller set.
INFO - 2016-10-28 13:16:09 --> Router Class Initialized
INFO - 2016-10-28 13:16:09 --> Output Class Initialized
INFO - 2016-10-28 13:16:09 --> Security Class Initialized
DEBUG - 2016-10-28 13:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:16:09 --> Input Class Initialized
INFO - 2016-10-28 13:16:09 --> Language Class Initialized
INFO - 2016-10-28 13:16:09 --> Loader Class Initialized
INFO - 2016-10-28 13:16:09 --> Helper loaded: url_helper
INFO - 2016-10-28 13:16:09 --> Helper loaded: form_helper
INFO - 2016-10-28 13:16:09 --> Database Driver Class Initialized
INFO - 2016-10-28 13:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:16:09 --> Controller Class Initialized
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:16:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:16:09 --> Final output sent to browser
DEBUG - 2016-10-28 13:16:09 --> Total execution time: 0.0175
INFO - 2016-10-28 13:16:13 --> Config Class Initialized
INFO - 2016-10-28 13:16:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:16:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:16:13 --> Utf8 Class Initialized
INFO - 2016-10-28 13:16:13 --> URI Class Initialized
INFO - 2016-10-28 13:16:13 --> Router Class Initialized
INFO - 2016-10-28 13:16:13 --> Output Class Initialized
INFO - 2016-10-28 13:16:13 --> Security Class Initialized
DEBUG - 2016-10-28 13:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:16:13 --> Input Class Initialized
INFO - 2016-10-28 13:16:13 --> Language Class Initialized
INFO - 2016-10-28 13:16:13 --> Loader Class Initialized
INFO - 2016-10-28 13:16:13 --> Helper loaded: url_helper
INFO - 2016-10-28 13:16:13 --> Helper loaded: form_helper
INFO - 2016-10-28 13:16:13 --> Database Driver Class Initialized
INFO - 2016-10-28 13:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:16:13 --> Controller Class Initialized
INFO - 2016-10-28 13:16:13 --> Form Validation Class Initialized
INFO - 2016-10-28 13:16:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:16:13 --> Final output sent to browser
DEBUG - 2016-10-28 13:16:13 --> Total execution time: 0.0167
INFO - 2016-10-28 13:16:14 --> Config Class Initialized
INFO - 2016-10-28 13:16:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:16:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:16:14 --> Utf8 Class Initialized
INFO - 2016-10-28 13:16:14 --> URI Class Initialized
DEBUG - 2016-10-28 13:16:14 --> No URI present. Default controller set.
INFO - 2016-10-28 13:16:14 --> Router Class Initialized
INFO - 2016-10-28 13:16:14 --> Output Class Initialized
INFO - 2016-10-28 13:16:14 --> Security Class Initialized
DEBUG - 2016-10-28 13:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:16:14 --> Input Class Initialized
INFO - 2016-10-28 13:16:14 --> Language Class Initialized
INFO - 2016-10-28 13:16:14 --> Loader Class Initialized
INFO - 2016-10-28 13:16:14 --> Helper loaded: url_helper
INFO - 2016-10-28 13:16:14 --> Helper loaded: form_helper
INFO - 2016-10-28 13:16:14 --> Database Driver Class Initialized
INFO - 2016-10-28 13:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:16:14 --> Controller Class Initialized
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:16:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:16:14 --> Final output sent to browser
DEBUG - 2016-10-28 13:16:14 --> Total execution time: 0.0170
INFO - 2016-10-28 13:16:45 --> Config Class Initialized
INFO - 2016-10-28 13:16:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:16:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:16:45 --> Utf8 Class Initialized
INFO - 2016-10-28 13:16:45 --> URI Class Initialized
DEBUG - 2016-10-28 13:16:45 --> No URI present. Default controller set.
INFO - 2016-10-28 13:16:45 --> Router Class Initialized
INFO - 2016-10-28 13:16:45 --> Output Class Initialized
INFO - 2016-10-28 13:16:45 --> Security Class Initialized
DEBUG - 2016-10-28 13:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:16:45 --> Input Class Initialized
INFO - 2016-10-28 13:16:45 --> Language Class Initialized
INFO - 2016-10-28 13:16:45 --> Loader Class Initialized
INFO - 2016-10-28 13:16:45 --> Helper loaded: url_helper
INFO - 2016-10-28 13:16:45 --> Helper loaded: form_helper
INFO - 2016-10-28 13:16:45 --> Database Driver Class Initialized
INFO - 2016-10-28 13:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:16:45 --> Controller Class Initialized
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:16:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:16:45 --> Final output sent to browser
DEBUG - 2016-10-28 13:16:45 --> Total execution time: 0.0179
INFO - 2016-10-28 13:21:28 --> Config Class Initialized
INFO - 2016-10-28 13:21:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:28 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:28 --> URI Class Initialized
INFO - 2016-10-28 13:21:28 --> Router Class Initialized
INFO - 2016-10-28 13:21:28 --> Output Class Initialized
INFO - 2016-10-28 13:21:28 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:28 --> Input Class Initialized
INFO - 2016-10-28 13:21:28 --> Language Class Initialized
INFO - 2016-10-28 13:21:28 --> Loader Class Initialized
INFO - 2016-10-28 13:21:28 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:28 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:28 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:28 --> Controller Class Initialized
INFO - 2016-10-28 13:21:28 --> Form Validation Class Initialized
INFO - 2016-10-28 13:21:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:21:28 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:28 --> Total execution time: 0.0197
INFO - 2016-10-28 13:21:33 --> Config Class Initialized
INFO - 2016-10-28 13:21:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:33 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:33 --> URI Class Initialized
DEBUG - 2016-10-28 13:21:33 --> No URI present. Default controller set.
INFO - 2016-10-28 13:21:33 --> Router Class Initialized
INFO - 2016-10-28 13:21:33 --> Output Class Initialized
INFO - 2016-10-28 13:21:33 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:33 --> Input Class Initialized
INFO - 2016-10-28 13:21:33 --> Language Class Initialized
INFO - 2016-10-28 13:21:33 --> Loader Class Initialized
INFO - 2016-10-28 13:21:33 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:33 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:33 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:33 --> Controller Class Initialized
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:21:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:21:33 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:33 --> Total execution time: 0.0173
INFO - 2016-10-28 13:21:55 --> Config Class Initialized
INFO - 2016-10-28 13:21:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:55 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:55 --> URI Class Initialized
INFO - 2016-10-28 13:21:55 --> Router Class Initialized
INFO - 2016-10-28 13:21:55 --> Output Class Initialized
INFO - 2016-10-28 13:21:55 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:55 --> Input Class Initialized
INFO - 2016-10-28 13:21:55 --> Language Class Initialized
INFO - 2016-10-28 13:21:55 --> Loader Class Initialized
INFO - 2016-10-28 13:21:55 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:55 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:55 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:55 --> Controller Class Initialized
INFO - 2016-10-28 13:21:55 --> Form Validation Class Initialized
INFO - 2016-10-28 13:21:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:21:55 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:55 --> Total execution time: 0.0172
INFO - 2016-10-28 13:21:57 --> Config Class Initialized
INFO - 2016-10-28 13:21:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:21:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:21:57 --> Utf8 Class Initialized
INFO - 2016-10-28 13:21:57 --> URI Class Initialized
DEBUG - 2016-10-28 13:21:57 --> No URI present. Default controller set.
INFO - 2016-10-28 13:21:57 --> Router Class Initialized
INFO - 2016-10-28 13:21:57 --> Output Class Initialized
INFO - 2016-10-28 13:21:57 --> Security Class Initialized
DEBUG - 2016-10-28 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:21:57 --> Input Class Initialized
INFO - 2016-10-28 13:21:57 --> Language Class Initialized
INFO - 2016-10-28 13:21:57 --> Loader Class Initialized
INFO - 2016-10-28 13:21:57 --> Helper loaded: url_helper
INFO - 2016-10-28 13:21:57 --> Helper loaded: form_helper
INFO - 2016-10-28 13:21:57 --> Database Driver Class Initialized
INFO - 2016-10-28 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:21:57 --> Controller Class Initialized
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:21:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:21:57 --> Final output sent to browser
DEBUG - 2016-10-28 13:21:57 --> Total execution time: 0.0167
INFO - 2016-10-28 13:23:13 --> Config Class Initialized
INFO - 2016-10-28 13:23:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:23:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:23:13 --> Utf8 Class Initialized
INFO - 2016-10-28 13:23:13 --> URI Class Initialized
DEBUG - 2016-10-28 13:23:13 --> No URI present. Default controller set.
INFO - 2016-10-28 13:23:13 --> Router Class Initialized
INFO - 2016-10-28 13:23:13 --> Output Class Initialized
INFO - 2016-10-28 13:23:13 --> Security Class Initialized
DEBUG - 2016-10-28 13:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:23:13 --> Input Class Initialized
INFO - 2016-10-28 13:23:13 --> Language Class Initialized
INFO - 2016-10-28 13:23:13 --> Loader Class Initialized
INFO - 2016-10-28 13:23:13 --> Helper loaded: url_helper
INFO - 2016-10-28 13:23:13 --> Helper loaded: form_helper
INFO - 2016-10-28 13:23:13 --> Database Driver Class Initialized
INFO - 2016-10-28 13:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:23:13 --> Controller Class Initialized
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:23:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:23:13 --> Final output sent to browser
DEBUG - 2016-10-28 13:23:13 --> Total execution time: 0.0177
INFO - 2016-10-28 13:25:37 --> Config Class Initialized
INFO - 2016-10-28 13:25:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:37 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:37 --> URI Class Initialized
DEBUG - 2016-10-28 13:25:37 --> No URI present. Default controller set.
INFO - 2016-10-28 13:25:37 --> Router Class Initialized
INFO - 2016-10-28 13:25:37 --> Output Class Initialized
INFO - 2016-10-28 13:25:37 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:37 --> Input Class Initialized
INFO - 2016-10-28 13:25:37 --> Language Class Initialized
INFO - 2016-10-28 13:25:37 --> Loader Class Initialized
INFO - 2016-10-28 13:25:37 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:37 --> Helper loaded: form_helper
INFO - 2016-10-28 13:25:37 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:37 --> Controller Class Initialized
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:25:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:25:37 --> Final output sent to browser
DEBUG - 2016-10-28 13:25:37 --> Total execution time: 0.0179
INFO - 2016-10-28 13:25:40 --> Config Class Initialized
INFO - 2016-10-28 13:25:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:40 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:40 --> URI Class Initialized
INFO - 2016-10-28 13:25:40 --> Router Class Initialized
INFO - 2016-10-28 13:25:40 --> Output Class Initialized
INFO - 2016-10-28 13:25:40 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:40 --> Input Class Initialized
INFO - 2016-10-28 13:25:40 --> Language Class Initialized
INFO - 2016-10-28 13:25:40 --> Loader Class Initialized
INFO - 2016-10-28 13:25:40 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:40 --> Helper loaded: form_helper
INFO - 2016-10-28 13:25:40 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:40 --> Controller Class Initialized
INFO - 2016-10-28 13:25:40 --> Form Validation Class Initialized
INFO - 2016-10-28 13:25:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:25:40 --> Final output sent to browser
DEBUG - 2016-10-28 13:25:40 --> Total execution time: 0.0167
INFO - 2016-10-28 13:25:41 --> Config Class Initialized
INFO - 2016-10-28 13:25:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:25:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:25:41 --> Utf8 Class Initialized
INFO - 2016-10-28 13:25:41 --> URI Class Initialized
DEBUG - 2016-10-28 13:25:41 --> No URI present. Default controller set.
INFO - 2016-10-28 13:25:41 --> Router Class Initialized
INFO - 2016-10-28 13:25:41 --> Output Class Initialized
INFO - 2016-10-28 13:25:41 --> Security Class Initialized
DEBUG - 2016-10-28 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:25:41 --> Input Class Initialized
INFO - 2016-10-28 13:25:41 --> Language Class Initialized
INFO - 2016-10-28 13:25:41 --> Loader Class Initialized
INFO - 2016-10-28 13:25:41 --> Helper loaded: url_helper
INFO - 2016-10-28 13:25:41 --> Helper loaded: form_helper
INFO - 2016-10-28 13:25:41 --> Database Driver Class Initialized
INFO - 2016-10-28 13:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:25:41 --> Controller Class Initialized
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:25:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:25:41 --> Final output sent to browser
DEBUG - 2016-10-28 13:25:41 --> Total execution time: 0.0166
INFO - 2016-10-28 13:28:19 --> Config Class Initialized
INFO - 2016-10-28 13:28:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:19 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:19 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:19 --> No URI present. Default controller set.
INFO - 2016-10-28 13:28:19 --> Router Class Initialized
INFO - 2016-10-28 13:28:19 --> Output Class Initialized
INFO - 2016-10-28 13:28:19 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:19 --> Input Class Initialized
INFO - 2016-10-28 13:28:19 --> Language Class Initialized
INFO - 2016-10-28 13:28:19 --> Loader Class Initialized
INFO - 2016-10-28 13:28:19 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:19 --> Helper loaded: form_helper
INFO - 2016-10-28 13:28:19 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:19 --> Controller Class Initialized
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:28:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:28:19 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:19 --> Total execution time: 0.0176
INFO - 2016-10-28 13:28:24 --> Config Class Initialized
INFO - 2016-10-28 13:28:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:24 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:24 --> URI Class Initialized
INFO - 2016-10-28 13:28:24 --> Router Class Initialized
INFO - 2016-10-28 13:28:24 --> Output Class Initialized
INFO - 2016-10-28 13:28:24 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:24 --> Input Class Initialized
INFO - 2016-10-28 13:28:24 --> Language Class Initialized
INFO - 2016-10-28 13:28:24 --> Loader Class Initialized
INFO - 2016-10-28 13:28:24 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:24 --> Helper loaded: form_helper
INFO - 2016-10-28 13:28:24 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:24 --> Controller Class Initialized
INFO - 2016-10-28 13:28:24 --> Form Validation Class Initialized
INFO - 2016-10-28 13:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 13:28:24 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:24 --> Total execution time: 0.0314
INFO - 2016-10-28 13:28:25 --> Config Class Initialized
INFO - 2016-10-28 13:28:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:28:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:28:25 --> Utf8 Class Initialized
INFO - 2016-10-28 13:28:25 --> URI Class Initialized
DEBUG - 2016-10-28 13:28:25 --> No URI present. Default controller set.
INFO - 2016-10-28 13:28:25 --> Router Class Initialized
INFO - 2016-10-28 13:28:25 --> Output Class Initialized
INFO - 2016-10-28 13:28:25 --> Security Class Initialized
DEBUG - 2016-10-28 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:28:25 --> Input Class Initialized
INFO - 2016-10-28 13:28:25 --> Language Class Initialized
INFO - 2016-10-28 13:28:25 --> Loader Class Initialized
INFO - 2016-10-28 13:28:25 --> Helper loaded: url_helper
INFO - 2016-10-28 13:28:25 --> Helper loaded: form_helper
INFO - 2016-10-28 13:28:25 --> Database Driver Class Initialized
INFO - 2016-10-28 13:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:28:25 --> Controller Class Initialized
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:28:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:28:25 --> Final output sent to browser
DEBUG - 2016-10-28 13:28:25 --> Total execution time: 0.0167
INFO - 2016-10-28 13:29:39 --> Config Class Initialized
INFO - 2016-10-28 13:29:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 13:29:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 13:29:39 --> Utf8 Class Initialized
INFO - 2016-10-28 13:29:39 --> URI Class Initialized
DEBUG - 2016-10-28 13:29:39 --> No URI present. Default controller set.
INFO - 2016-10-28 13:29:39 --> Router Class Initialized
INFO - 2016-10-28 13:29:39 --> Output Class Initialized
INFO - 2016-10-28 13:29:39 --> Security Class Initialized
DEBUG - 2016-10-28 13:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 13:29:39 --> Input Class Initialized
INFO - 2016-10-28 13:29:39 --> Language Class Initialized
INFO - 2016-10-28 13:29:39 --> Loader Class Initialized
INFO - 2016-10-28 13:29:39 --> Helper loaded: url_helper
INFO - 2016-10-28 13:29:39 --> Helper loaded: form_helper
INFO - 2016-10-28 13:29:39 --> Database Driver Class Initialized
INFO - 2016-10-28 13:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 13:29:39 --> Controller Class Initialized
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 13:29:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 13:29:39 --> Final output sent to browser
DEBUG - 2016-10-28 13:29:39 --> Total execution time: 0.0177
INFO - 2016-10-28 14:13:00 --> Config Class Initialized
INFO - 2016-10-28 14:13:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:13:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:13:00 --> Utf8 Class Initialized
INFO - 2016-10-28 14:13:00 --> URI Class Initialized
DEBUG - 2016-10-28 14:13:00 --> No URI present. Default controller set.
INFO - 2016-10-28 14:13:00 --> Router Class Initialized
INFO - 2016-10-28 14:13:00 --> Output Class Initialized
INFO - 2016-10-28 14:13:00 --> Security Class Initialized
DEBUG - 2016-10-28 14:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:13:00 --> Input Class Initialized
INFO - 2016-10-28 14:13:00 --> Language Class Initialized
INFO - 2016-10-28 14:13:00 --> Loader Class Initialized
INFO - 2016-10-28 14:13:00 --> Helper loaded: url_helper
INFO - 2016-10-28 14:13:00 --> Helper loaded: form_helper
INFO - 2016-10-28 14:13:00 --> Database Driver Class Initialized
INFO - 2016-10-28 14:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:13:00 --> Controller Class Initialized
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:13:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:13:00 --> Final output sent to browser
DEBUG - 2016-10-28 14:13:00 --> Total execution time: 0.0185
INFO - 2016-10-28 14:45:19 --> Config Class Initialized
INFO - 2016-10-28 14:45:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:19 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:19 --> URI Class Initialized
DEBUG - 2016-10-28 14:45:19 --> No URI present. Default controller set.
INFO - 2016-10-28 14:45:19 --> Router Class Initialized
INFO - 2016-10-28 14:45:19 --> Output Class Initialized
INFO - 2016-10-28 14:45:19 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:19 --> Input Class Initialized
INFO - 2016-10-28 14:45:19 --> Language Class Initialized
INFO - 2016-10-28 14:45:19 --> Loader Class Initialized
INFO - 2016-10-28 14:45:19 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:19 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:19 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:19 --> Controller Class Initialized
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:45:19 --> Final output sent to browser
DEBUG - 2016-10-28 14:45:19 --> Total execution time: 0.0198
INFO - 2016-10-28 14:45:22 --> Config Class Initialized
INFO - 2016-10-28 14:45:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:22 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:22 --> URI Class Initialized
INFO - 2016-10-28 14:45:22 --> Router Class Initialized
INFO - 2016-10-28 14:45:22 --> Output Class Initialized
INFO - 2016-10-28 14:45:22 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:22 --> Input Class Initialized
INFO - 2016-10-28 14:45:22 --> Language Class Initialized
INFO - 2016-10-28 14:45:22 --> Loader Class Initialized
INFO - 2016-10-28 14:45:22 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:22 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:22 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:22 --> Controller Class Initialized
INFO - 2016-10-28 14:45:22 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:45:22 --> Final output sent to browser
DEBUG - 2016-10-28 14:45:22 --> Total execution time: 0.0170
INFO - 2016-10-28 14:45:32 --> Config Class Initialized
INFO - 2016-10-28 14:45:32 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:32 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:32 --> URI Class Initialized
INFO - 2016-10-28 14:45:32 --> Router Class Initialized
INFO - 2016-10-28 14:45:32 --> Output Class Initialized
INFO - 2016-10-28 14:45:32 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:32 --> Input Class Initialized
INFO - 2016-10-28 14:45:32 --> Language Class Initialized
INFO - 2016-10-28 14:45:32 --> Loader Class Initialized
INFO - 2016-10-28 14:45:32 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:32 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:32 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:32 --> Controller Class Initialized
INFO - 2016-10-28 14:45:32 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:32 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:54 --> Config Class Initialized
INFO - 2016-10-28 14:45:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:54 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:54 --> URI Class Initialized
INFO - 2016-10-28 14:45:54 --> Router Class Initialized
INFO - 2016-10-28 14:45:54 --> Output Class Initialized
INFO - 2016-10-28 14:45:54 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:54 --> Input Class Initialized
INFO - 2016-10-28 14:45:54 --> Language Class Initialized
INFO - 2016-10-28 14:45:54 --> Loader Class Initialized
INFO - 2016-10-28 14:45:54 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:54 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:54 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:54 --> Controller Class Initialized
INFO - 2016-10-28 14:45:54 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:54 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:54 --> Config Class Initialized
INFO - 2016-10-28 14:45:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:54 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:54 --> URI Class Initialized
INFO - 2016-10-28 14:45:54 --> Router Class Initialized
INFO - 2016-10-28 14:45:54 --> Output Class Initialized
INFO - 2016-10-28 14:45:54 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:54 --> Input Class Initialized
INFO - 2016-10-28 14:45:54 --> Language Class Initialized
INFO - 2016-10-28 14:45:54 --> Loader Class Initialized
INFO - 2016-10-28 14:45:54 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:54 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:54 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:54 --> Controller Class Initialized
INFO - 2016-10-28 14:45:54 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:54 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:55 --> Config Class Initialized
INFO - 2016-10-28 14:45:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:55 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:55 --> URI Class Initialized
INFO - 2016-10-28 14:45:55 --> Router Class Initialized
INFO - 2016-10-28 14:45:55 --> Output Class Initialized
INFO - 2016-10-28 14:45:55 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:55 --> Input Class Initialized
INFO - 2016-10-28 14:45:55 --> Language Class Initialized
INFO - 2016-10-28 14:45:55 --> Loader Class Initialized
INFO - 2016-10-28 14:45:55 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:55 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:55 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:55 --> Controller Class Initialized
INFO - 2016-10-28 14:45:55 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:55 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:55 --> Config Class Initialized
INFO - 2016-10-28 14:45:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:55 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:55 --> URI Class Initialized
INFO - 2016-10-28 14:45:55 --> Router Class Initialized
INFO - 2016-10-28 14:45:55 --> Output Class Initialized
INFO - 2016-10-28 14:45:55 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:55 --> Input Class Initialized
INFO - 2016-10-28 14:45:55 --> Language Class Initialized
INFO - 2016-10-28 14:45:55 --> Loader Class Initialized
INFO - 2016-10-28 14:45:55 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:55 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:55 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:55 --> Controller Class Initialized
INFO - 2016-10-28 14:45:55 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:55 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:55 --> Config Class Initialized
INFO - 2016-10-28 14:45:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:55 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:55 --> URI Class Initialized
INFO - 2016-10-28 14:45:55 --> Router Class Initialized
INFO - 2016-10-28 14:45:55 --> Output Class Initialized
INFO - 2016-10-28 14:45:55 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:55 --> Input Class Initialized
INFO - 2016-10-28 14:45:55 --> Language Class Initialized
INFO - 2016-10-28 14:45:55 --> Loader Class Initialized
INFO - 2016-10-28 14:45:55 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:55 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:55 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:55 --> Controller Class Initialized
INFO - 2016-10-28 14:45:55 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:55 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:55 --> Config Class Initialized
INFO - 2016-10-28 14:45:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:55 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:55 --> URI Class Initialized
INFO - 2016-10-28 14:45:55 --> Router Class Initialized
INFO - 2016-10-28 14:45:55 --> Output Class Initialized
INFO - 2016-10-28 14:45:55 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:55 --> Input Class Initialized
INFO - 2016-10-28 14:45:55 --> Language Class Initialized
INFO - 2016-10-28 14:45:55 --> Loader Class Initialized
INFO - 2016-10-28 14:45:55 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:55 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:55 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:55 --> Controller Class Initialized
INFO - 2016-10-28 14:45:55 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:45:55 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:45:56 --> Config Class Initialized
INFO - 2016-10-28 14:45:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:56 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:56 --> URI Class Initialized
DEBUG - 2016-10-28 14:45:56 --> No URI present. Default controller set.
INFO - 2016-10-28 14:45:56 --> Router Class Initialized
INFO - 2016-10-28 14:45:56 --> Output Class Initialized
INFO - 2016-10-28 14:45:56 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:56 --> Input Class Initialized
INFO - 2016-10-28 14:45:56 --> Language Class Initialized
INFO - 2016-10-28 14:45:56 --> Loader Class Initialized
INFO - 2016-10-28 14:45:56 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:56 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:56 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:56 --> Controller Class Initialized
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:45:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:45:56 --> Final output sent to browser
DEBUG - 2016-10-28 14:45:56 --> Total execution time: 0.0170
INFO - 2016-10-28 14:45:59 --> Config Class Initialized
INFO - 2016-10-28 14:45:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:45:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:45:59 --> Utf8 Class Initialized
INFO - 2016-10-28 14:45:59 --> URI Class Initialized
INFO - 2016-10-28 14:45:59 --> Router Class Initialized
INFO - 2016-10-28 14:45:59 --> Output Class Initialized
INFO - 2016-10-28 14:45:59 --> Security Class Initialized
DEBUG - 2016-10-28 14:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:45:59 --> Input Class Initialized
INFO - 2016-10-28 14:45:59 --> Language Class Initialized
INFO - 2016-10-28 14:45:59 --> Loader Class Initialized
INFO - 2016-10-28 14:45:59 --> Helper loaded: url_helper
INFO - 2016-10-28 14:45:59 --> Helper loaded: form_helper
INFO - 2016-10-28 14:45:59 --> Database Driver Class Initialized
INFO - 2016-10-28 14:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:45:59 --> Controller Class Initialized
INFO - 2016-10-28 14:45:59 --> Form Validation Class Initialized
INFO - 2016-10-28 14:45:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:45:59 --> Final output sent to browser
DEBUG - 2016-10-28 14:45:59 --> Total execution time: 0.0167
INFO - 2016-10-28 14:46:04 --> Config Class Initialized
INFO - 2016-10-28 14:46:04 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:46:04 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:46:04 --> Utf8 Class Initialized
INFO - 2016-10-28 14:46:04 --> URI Class Initialized
INFO - 2016-10-28 14:46:04 --> Router Class Initialized
INFO - 2016-10-28 14:46:04 --> Output Class Initialized
INFO - 2016-10-28 14:46:04 --> Security Class Initialized
DEBUG - 2016-10-28 14:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:46:04 --> Input Class Initialized
INFO - 2016-10-28 14:46:04 --> Language Class Initialized
INFO - 2016-10-28 14:46:04 --> Loader Class Initialized
INFO - 2016-10-28 14:46:04 --> Helper loaded: url_helper
INFO - 2016-10-28 14:46:04 --> Helper loaded: form_helper
INFO - 2016-10-28 14:46:04 --> Database Driver Class Initialized
INFO - 2016-10-28 14:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:46:04 --> Controller Class Initialized
INFO - 2016-10-28 14:46:04 --> Form Validation Class Initialized
INFO - 2016-10-28 14:46:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:46:04 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:46:25 --> Config Class Initialized
INFO - 2016-10-28 14:46:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:46:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:46:25 --> Utf8 Class Initialized
INFO - 2016-10-28 14:46:25 --> URI Class Initialized
DEBUG - 2016-10-28 14:46:25 --> No URI present. Default controller set.
INFO - 2016-10-28 14:46:25 --> Router Class Initialized
INFO - 2016-10-28 14:46:25 --> Output Class Initialized
INFO - 2016-10-28 14:46:25 --> Security Class Initialized
DEBUG - 2016-10-28 14:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:46:25 --> Input Class Initialized
INFO - 2016-10-28 14:46:25 --> Language Class Initialized
INFO - 2016-10-28 14:46:25 --> Loader Class Initialized
INFO - 2016-10-28 14:46:25 --> Helper loaded: url_helper
INFO - 2016-10-28 14:46:25 --> Helper loaded: form_helper
INFO - 2016-10-28 14:46:25 --> Database Driver Class Initialized
INFO - 2016-10-28 14:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:46:25 --> Controller Class Initialized
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:46:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:46:25 --> Final output sent to browser
DEBUG - 2016-10-28 14:46:25 --> Total execution time: 0.0174
INFO - 2016-10-28 14:47:35 --> Config Class Initialized
INFO - 2016-10-28 14:47:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:47:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:47:35 --> Utf8 Class Initialized
INFO - 2016-10-28 14:47:35 --> URI Class Initialized
DEBUG - 2016-10-28 14:47:35 --> No URI present. Default controller set.
INFO - 2016-10-28 14:47:35 --> Router Class Initialized
INFO - 2016-10-28 14:47:35 --> Output Class Initialized
INFO - 2016-10-28 14:47:35 --> Security Class Initialized
DEBUG - 2016-10-28 14:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:47:35 --> Input Class Initialized
INFO - 2016-10-28 14:47:35 --> Language Class Initialized
INFO - 2016-10-28 14:47:35 --> Loader Class Initialized
INFO - 2016-10-28 14:47:35 --> Helper loaded: url_helper
INFO - 2016-10-28 14:47:35 --> Helper loaded: form_helper
INFO - 2016-10-28 14:47:35 --> Database Driver Class Initialized
INFO - 2016-10-28 14:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:47:35 --> Controller Class Initialized
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:47:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:47:35 --> Final output sent to browser
DEBUG - 2016-10-28 14:47:35 --> Total execution time: 0.0181
INFO - 2016-10-28 14:47:42 --> Config Class Initialized
INFO - 2016-10-28 14:47:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:47:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:47:42 --> Utf8 Class Initialized
INFO - 2016-10-28 14:47:42 --> URI Class Initialized
INFO - 2016-10-28 14:47:42 --> Router Class Initialized
INFO - 2016-10-28 14:47:42 --> Output Class Initialized
INFO - 2016-10-28 14:47:42 --> Security Class Initialized
DEBUG - 2016-10-28 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:47:42 --> Input Class Initialized
INFO - 2016-10-28 14:47:42 --> Language Class Initialized
INFO - 2016-10-28 14:47:42 --> Loader Class Initialized
INFO - 2016-10-28 14:47:42 --> Helper loaded: url_helper
INFO - 2016-10-28 14:47:42 --> Helper loaded: form_helper
INFO - 2016-10-28 14:47:42 --> Database Driver Class Initialized
INFO - 2016-10-28 14:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:47:42 --> Controller Class Initialized
INFO - 2016-10-28 14:47:42 --> Form Validation Class Initialized
INFO - 2016-10-28 14:47:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:47:42 --> Final output sent to browser
DEBUG - 2016-10-28 14:47:42 --> Total execution time: 0.0175
INFO - 2016-10-28 14:47:45 --> Config Class Initialized
INFO - 2016-10-28 14:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:47:45 --> Utf8 Class Initialized
INFO - 2016-10-28 14:47:45 --> URI Class Initialized
INFO - 2016-10-28 14:47:45 --> Router Class Initialized
INFO - 2016-10-28 14:47:45 --> Output Class Initialized
INFO - 2016-10-28 14:47:45 --> Security Class Initialized
DEBUG - 2016-10-28 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:47:45 --> Input Class Initialized
INFO - 2016-10-28 14:47:45 --> Language Class Initialized
INFO - 2016-10-28 14:47:45 --> Loader Class Initialized
INFO - 2016-10-28 14:47:45 --> Helper loaded: url_helper
INFO - 2016-10-28 14:47:45 --> Helper loaded: form_helper
INFO - 2016-10-28 14:47:45 --> Database Driver Class Initialized
INFO - 2016-10-28 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:47:45 --> Controller Class Initialized
INFO - 2016-10-28 14:47:45 --> Form Validation Class Initialized
INFO - 2016-10-28 14:47:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-10-28 14:47:45 --> Severity: error --> Exception: /var/www/html/ramotlonyane_modise/LMS/app/models/Leave_type_m.php exists, but doesn't declare class Leave_type_m /var/www/html/ramotlonyane_modise/LMS/sys/core/Loader.php 336
INFO - 2016-10-28 14:49:09 --> Config Class Initialized
INFO - 2016-10-28 14:49:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:09 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:09 --> URI Class Initialized
DEBUG - 2016-10-28 14:49:09 --> No URI present. Default controller set.
INFO - 2016-10-28 14:49:09 --> Router Class Initialized
INFO - 2016-10-28 14:49:09 --> Output Class Initialized
INFO - 2016-10-28 14:49:09 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:09 --> Input Class Initialized
INFO - 2016-10-28 14:49:09 --> Language Class Initialized
INFO - 2016-10-28 14:49:09 --> Loader Class Initialized
INFO - 2016-10-28 14:49:09 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:09 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:09 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:09 --> Controller Class Initialized
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:49:09 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:49:09 --> Final output sent to browser
DEBUG - 2016-10-28 14:49:09 --> Total execution time: 0.0169
INFO - 2016-10-28 14:49:37 --> Config Class Initialized
INFO - 2016-10-28 14:49:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:37 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:37 --> URI Class Initialized
INFO - 2016-10-28 14:49:37 --> Router Class Initialized
INFO - 2016-10-28 14:49:37 --> Output Class Initialized
INFO - 2016-10-28 14:49:37 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:37 --> Input Class Initialized
INFO - 2016-10-28 14:49:37 --> Language Class Initialized
INFO - 2016-10-28 14:49:37 --> Loader Class Initialized
INFO - 2016-10-28 14:49:37 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:37 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:37 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:37 --> Controller Class Initialized
INFO - 2016-10-28 14:49:37 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:37 --> Model Class Initialized
ERROR - 2016-10-28 14:49:37 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:38 --> Config Class Initialized
INFO - 2016-10-28 14:49:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:38 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:38 --> URI Class Initialized
INFO - 2016-10-28 14:49:38 --> Router Class Initialized
INFO - 2016-10-28 14:49:38 --> Output Class Initialized
INFO - 2016-10-28 14:49:38 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:38 --> Input Class Initialized
INFO - 2016-10-28 14:49:38 --> Language Class Initialized
INFO - 2016-10-28 14:49:38 --> Loader Class Initialized
INFO - 2016-10-28 14:49:38 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:38 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:38 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:38 --> Controller Class Initialized
INFO - 2016-10-28 14:49:38 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:38 --> Model Class Initialized
ERROR - 2016-10-28 14:49:38 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:38 --> Config Class Initialized
INFO - 2016-10-28 14:49:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:38 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:38 --> URI Class Initialized
INFO - 2016-10-28 14:49:38 --> Router Class Initialized
INFO - 2016-10-28 14:49:38 --> Output Class Initialized
INFO - 2016-10-28 14:49:38 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:38 --> Input Class Initialized
INFO - 2016-10-28 14:49:38 --> Language Class Initialized
INFO - 2016-10-28 14:49:38 --> Loader Class Initialized
INFO - 2016-10-28 14:49:38 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:38 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:38 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:38 --> Controller Class Initialized
INFO - 2016-10-28 14:49:38 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:38 --> Model Class Initialized
ERROR - 2016-10-28 14:49:38 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:39 --> Config Class Initialized
INFO - 2016-10-28 14:49:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:39 --> URI Class Initialized
INFO - 2016-10-28 14:49:39 --> Router Class Initialized
INFO - 2016-10-28 14:49:39 --> Output Class Initialized
INFO - 2016-10-28 14:49:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:39 --> Input Class Initialized
INFO - 2016-10-28 14:49:39 --> Language Class Initialized
INFO - 2016-10-28 14:49:39 --> Loader Class Initialized
INFO - 2016-10-28 14:49:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:39 --> Controller Class Initialized
INFO - 2016-10-28 14:49:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:39 --> Model Class Initialized
ERROR - 2016-10-28 14:49:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:39 --> Config Class Initialized
INFO - 2016-10-28 14:49:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:39 --> URI Class Initialized
INFO - 2016-10-28 14:49:39 --> Router Class Initialized
INFO - 2016-10-28 14:49:39 --> Output Class Initialized
INFO - 2016-10-28 14:49:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:39 --> Input Class Initialized
INFO - 2016-10-28 14:49:39 --> Language Class Initialized
INFO - 2016-10-28 14:49:39 --> Loader Class Initialized
INFO - 2016-10-28 14:49:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:39 --> Controller Class Initialized
INFO - 2016-10-28 14:49:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:39 --> Model Class Initialized
ERROR - 2016-10-28 14:49:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:39 --> Config Class Initialized
INFO - 2016-10-28 14:49:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:39 --> URI Class Initialized
INFO - 2016-10-28 14:49:39 --> Router Class Initialized
INFO - 2016-10-28 14:49:39 --> Output Class Initialized
INFO - 2016-10-28 14:49:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:39 --> Input Class Initialized
INFO - 2016-10-28 14:49:39 --> Language Class Initialized
INFO - 2016-10-28 14:49:39 --> Loader Class Initialized
INFO - 2016-10-28 14:49:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:39 --> Controller Class Initialized
INFO - 2016-10-28 14:49:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:39 --> Model Class Initialized
ERROR - 2016-10-28 14:49:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:40 --> Config Class Initialized
INFO - 2016-10-28 14:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:40 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:40 --> URI Class Initialized
INFO - 2016-10-28 14:49:40 --> Router Class Initialized
INFO - 2016-10-28 14:49:40 --> Output Class Initialized
INFO - 2016-10-28 14:49:40 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:40 --> Input Class Initialized
INFO - 2016-10-28 14:49:40 --> Language Class Initialized
INFO - 2016-10-28 14:49:40 --> Loader Class Initialized
INFO - 2016-10-28 14:49:40 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:40 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:40 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:40 --> Controller Class Initialized
INFO - 2016-10-28 14:49:40 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:40 --> Model Class Initialized
ERROR - 2016-10-28 14:49:40 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:40 --> Config Class Initialized
INFO - 2016-10-28 14:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:40 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:40 --> URI Class Initialized
INFO - 2016-10-28 14:49:40 --> Router Class Initialized
INFO - 2016-10-28 14:49:40 --> Output Class Initialized
INFO - 2016-10-28 14:49:40 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:40 --> Input Class Initialized
INFO - 2016-10-28 14:49:40 --> Language Class Initialized
INFO - 2016-10-28 14:49:40 --> Loader Class Initialized
INFO - 2016-10-28 14:49:40 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:40 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:40 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:40 --> Controller Class Initialized
INFO - 2016-10-28 14:49:40 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:40 --> Model Class Initialized
ERROR - 2016-10-28 14:49:40 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:40 --> Config Class Initialized
INFO - 2016-10-28 14:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:40 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:40 --> URI Class Initialized
INFO - 2016-10-28 14:49:40 --> Router Class Initialized
INFO - 2016-10-28 14:49:40 --> Output Class Initialized
INFO - 2016-10-28 14:49:40 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:40 --> Input Class Initialized
INFO - 2016-10-28 14:49:40 --> Language Class Initialized
INFO - 2016-10-28 14:49:40 --> Loader Class Initialized
INFO - 2016-10-28 14:49:40 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:40 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:40 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:40 --> Controller Class Initialized
INFO - 2016-10-28 14:49:40 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:40 --> Model Class Initialized
ERROR - 2016-10-28 14:49:40 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:40 --> Config Class Initialized
INFO - 2016-10-28 14:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:40 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:40 --> URI Class Initialized
INFO - 2016-10-28 14:49:40 --> Router Class Initialized
INFO - 2016-10-28 14:49:40 --> Output Class Initialized
INFO - 2016-10-28 14:49:40 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:40 --> Input Class Initialized
INFO - 2016-10-28 14:49:40 --> Language Class Initialized
INFO - 2016-10-28 14:49:40 --> Loader Class Initialized
INFO - 2016-10-28 14:49:40 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:40 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:40 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:40 --> Controller Class Initialized
INFO - 2016-10-28 14:49:40 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:40 --> Model Class Initialized
ERROR - 2016-10-28 14:49:40 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:49:41 --> Config Class Initialized
INFO - 2016-10-28 14:49:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:49:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:49:41 --> Utf8 Class Initialized
INFO - 2016-10-28 14:49:41 --> URI Class Initialized
INFO - 2016-10-28 14:49:41 --> Router Class Initialized
INFO - 2016-10-28 14:49:41 --> Output Class Initialized
INFO - 2016-10-28 14:49:41 --> Security Class Initialized
DEBUG - 2016-10-28 14:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:49:41 --> Input Class Initialized
INFO - 2016-10-28 14:49:41 --> Language Class Initialized
INFO - 2016-10-28 14:49:41 --> Loader Class Initialized
INFO - 2016-10-28 14:49:41 --> Helper loaded: url_helper
INFO - 2016-10-28 14:49:41 --> Helper loaded: form_helper
INFO - 2016-10-28 14:49:41 --> Database Driver Class Initialized
INFO - 2016-10-28 14:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:49:41 --> Controller Class Initialized
INFO - 2016-10-28 14:49:41 --> Form Validation Class Initialized
INFO - 2016-10-28 14:49:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:49:41 --> Model Class Initialized
ERROR - 2016-10-28 14:49:41 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:49:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:38 --> Config Class Initialized
INFO - 2016-10-28 14:50:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:38 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:38 --> URI Class Initialized
INFO - 2016-10-28 14:50:38 --> Router Class Initialized
INFO - 2016-10-28 14:50:38 --> Output Class Initialized
INFO - 2016-10-28 14:50:38 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:38 --> Input Class Initialized
INFO - 2016-10-28 14:50:38 --> Language Class Initialized
INFO - 2016-10-28 14:50:38 --> Loader Class Initialized
INFO - 2016-10-28 14:50:38 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:38 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:38 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:38 --> Controller Class Initialized
INFO - 2016-10-28 14:50:38 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:38 --> Model Class Initialized
ERROR - 2016-10-28 14:50:38 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:38 --> Config Class Initialized
INFO - 2016-10-28 14:50:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:38 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:38 --> URI Class Initialized
INFO - 2016-10-28 14:50:38 --> Router Class Initialized
INFO - 2016-10-28 14:50:38 --> Output Class Initialized
INFO - 2016-10-28 14:50:38 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:38 --> Input Class Initialized
INFO - 2016-10-28 14:50:38 --> Language Class Initialized
INFO - 2016-10-28 14:50:38 --> Loader Class Initialized
INFO - 2016-10-28 14:50:38 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:38 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:38 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:38 --> Controller Class Initialized
INFO - 2016-10-28 14:50:38 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:38 --> Model Class Initialized
ERROR - 2016-10-28 14:50:38 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:38 --> Config Class Initialized
INFO - 2016-10-28 14:50:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:38 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:38 --> URI Class Initialized
INFO - 2016-10-28 14:50:38 --> Router Class Initialized
INFO - 2016-10-28 14:50:38 --> Output Class Initialized
INFO - 2016-10-28 14:50:38 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:38 --> Input Class Initialized
INFO - 2016-10-28 14:50:38 --> Language Class Initialized
INFO - 2016-10-28 14:50:38 --> Loader Class Initialized
INFO - 2016-10-28 14:50:38 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:38 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:38 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:38 --> Controller Class Initialized
INFO - 2016-10-28 14:50:38 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:38 --> Model Class Initialized
ERROR - 2016-10-28 14:50:38 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:39 --> Config Class Initialized
INFO - 2016-10-28 14:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:39 --> URI Class Initialized
INFO - 2016-10-28 14:50:39 --> Router Class Initialized
INFO - 2016-10-28 14:50:39 --> Output Class Initialized
INFO - 2016-10-28 14:50:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:39 --> Input Class Initialized
INFO - 2016-10-28 14:50:39 --> Language Class Initialized
INFO - 2016-10-28 14:50:39 --> Loader Class Initialized
INFO - 2016-10-28 14:50:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:39 --> Controller Class Initialized
INFO - 2016-10-28 14:50:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:39 --> Model Class Initialized
ERROR - 2016-10-28 14:50:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:39 --> Config Class Initialized
INFO - 2016-10-28 14:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:39 --> URI Class Initialized
INFO - 2016-10-28 14:50:39 --> Router Class Initialized
INFO - 2016-10-28 14:50:39 --> Output Class Initialized
INFO - 2016-10-28 14:50:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:39 --> Input Class Initialized
INFO - 2016-10-28 14:50:39 --> Language Class Initialized
INFO - 2016-10-28 14:50:39 --> Loader Class Initialized
INFO - 2016-10-28 14:50:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:39 --> Controller Class Initialized
INFO - 2016-10-28 14:50:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:39 --> Model Class Initialized
ERROR - 2016-10-28 14:50:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:39 --> Config Class Initialized
INFO - 2016-10-28 14:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:39 --> URI Class Initialized
INFO - 2016-10-28 14:50:39 --> Router Class Initialized
INFO - 2016-10-28 14:50:39 --> Output Class Initialized
INFO - 2016-10-28 14:50:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:39 --> Input Class Initialized
INFO - 2016-10-28 14:50:39 --> Language Class Initialized
INFO - 2016-10-28 14:50:39 --> Loader Class Initialized
INFO - 2016-10-28 14:50:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:39 --> Controller Class Initialized
INFO - 2016-10-28 14:50:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:39 --> Model Class Initialized
ERROR - 2016-10-28 14:50:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:39 --> Config Class Initialized
INFO - 2016-10-28 14:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:39 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:39 --> URI Class Initialized
INFO - 2016-10-28 14:50:39 --> Router Class Initialized
INFO - 2016-10-28 14:50:39 --> Output Class Initialized
INFO - 2016-10-28 14:50:39 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:39 --> Input Class Initialized
INFO - 2016-10-28 14:50:39 --> Language Class Initialized
INFO - 2016-10-28 14:50:39 --> Loader Class Initialized
INFO - 2016-10-28 14:50:39 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:39 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:39 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:39 --> Controller Class Initialized
INFO - 2016-10-28 14:50:39 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:39 --> Model Class Initialized
ERROR - 2016-10-28 14:50:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:50:40 --> Config Class Initialized
INFO - 2016-10-28 14:50:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:50:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:50:40 --> Utf8 Class Initialized
INFO - 2016-10-28 14:50:40 --> URI Class Initialized
INFO - 2016-10-28 14:50:40 --> Router Class Initialized
INFO - 2016-10-28 14:50:40 --> Output Class Initialized
INFO - 2016-10-28 14:50:40 --> Security Class Initialized
DEBUG - 2016-10-28 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:50:40 --> Input Class Initialized
INFO - 2016-10-28 14:50:40 --> Language Class Initialized
INFO - 2016-10-28 14:50:40 --> Loader Class Initialized
INFO - 2016-10-28 14:50:40 --> Helper loaded: url_helper
INFO - 2016-10-28 14:50:40 --> Helper loaded: form_helper
INFO - 2016-10-28 14:50:40 --> Database Driver Class Initialized
INFO - 2016-10-28 14:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:50:40 --> Controller Class Initialized
INFO - 2016-10-28 14:50:40 --> Form Validation Class Initialized
INFO - 2016-10-28 14:50:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:50:40 --> Model Class Initialized
ERROR - 2016-10-28 14:50:40 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:50:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:54:53 --> Config Class Initialized
INFO - 2016-10-28 14:54:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:53 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:53 --> URI Class Initialized
INFO - 2016-10-28 14:54:53 --> Router Class Initialized
INFO - 2016-10-28 14:54:53 --> Output Class Initialized
INFO - 2016-10-28 14:54:53 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:53 --> Input Class Initialized
INFO - 2016-10-28 14:54:53 --> Language Class Initialized
INFO - 2016-10-28 14:54:53 --> Loader Class Initialized
INFO - 2016-10-28 14:54:53 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:53 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:53 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:53 --> Controller Class Initialized
INFO - 2016-10-28 14:54:54 --> Form Validation Class Initialized
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:54:54 --> Model Class Initialized
ERROR - 2016-10-28 14:54:54 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:54:54 --> Config Class Initialized
INFO - 2016-10-28 14:54:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:54 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:54 --> URI Class Initialized
INFO - 2016-10-28 14:54:54 --> Router Class Initialized
INFO - 2016-10-28 14:54:54 --> Output Class Initialized
INFO - 2016-10-28 14:54:54 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:54 --> Input Class Initialized
INFO - 2016-10-28 14:54:54 --> Language Class Initialized
INFO - 2016-10-28 14:54:54 --> Loader Class Initialized
INFO - 2016-10-28 14:54:54 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:54 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:54 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:54 --> Controller Class Initialized
INFO - 2016-10-28 14:54:54 --> Form Validation Class Initialized
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:54:54 --> Model Class Initialized
ERROR - 2016-10-28 14:54:54 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:54:54 --> Config Class Initialized
INFO - 2016-10-28 14:54:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:54 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:54 --> URI Class Initialized
INFO - 2016-10-28 14:54:54 --> Router Class Initialized
INFO - 2016-10-28 14:54:54 --> Output Class Initialized
INFO - 2016-10-28 14:54:54 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:54 --> Input Class Initialized
INFO - 2016-10-28 14:54:54 --> Language Class Initialized
INFO - 2016-10-28 14:54:54 --> Loader Class Initialized
INFO - 2016-10-28 14:54:54 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:54 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:54 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:54 --> Controller Class Initialized
INFO - 2016-10-28 14:54:54 --> Form Validation Class Initialized
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:54:54 --> Model Class Initialized
ERROR - 2016-10-28 14:54:54 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:54:54 --> Config Class Initialized
INFO - 2016-10-28 14:54:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:54 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:54 --> URI Class Initialized
INFO - 2016-10-28 14:54:54 --> Router Class Initialized
INFO - 2016-10-28 14:54:54 --> Output Class Initialized
INFO - 2016-10-28 14:54:54 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:54 --> Input Class Initialized
INFO - 2016-10-28 14:54:54 --> Language Class Initialized
INFO - 2016-10-28 14:54:54 --> Loader Class Initialized
INFO - 2016-10-28 14:54:54 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:54 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:54 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:54 --> Controller Class Initialized
INFO - 2016-10-28 14:54:54 --> Form Validation Class Initialized
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:54:54 --> Model Class Initialized
ERROR - 2016-10-28 14:54:54 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:54:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:54:55 --> Config Class Initialized
INFO - 2016-10-28 14:54:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:55 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:55 --> URI Class Initialized
INFO - 2016-10-28 14:54:55 --> Router Class Initialized
INFO - 2016-10-28 14:54:55 --> Output Class Initialized
INFO - 2016-10-28 14:54:55 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:55 --> Input Class Initialized
INFO - 2016-10-28 14:54:55 --> Language Class Initialized
INFO - 2016-10-28 14:54:55 --> Loader Class Initialized
INFO - 2016-10-28 14:54:55 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:55 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:55 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:55 --> Controller Class Initialized
INFO - 2016-10-28 14:54:55 --> Form Validation Class Initialized
INFO - 2016-10-28 14:54:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:54:55 --> Model Class Initialized
ERROR - 2016-10-28 14:54:55 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('Test', '3', 'Testing adding function')
INFO - 2016-10-28 14:54:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:54:56 --> Config Class Initialized
INFO - 2016-10-28 14:54:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:56 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:56 --> URI Class Initialized
DEBUG - 2016-10-28 14:54:56 --> No URI present. Default controller set.
INFO - 2016-10-28 14:54:56 --> Router Class Initialized
INFO - 2016-10-28 14:54:56 --> Output Class Initialized
INFO - 2016-10-28 14:54:56 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:56 --> Input Class Initialized
INFO - 2016-10-28 14:54:56 --> Language Class Initialized
INFO - 2016-10-28 14:54:56 --> Loader Class Initialized
INFO - 2016-10-28 14:54:56 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:56 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:56 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:56 --> Controller Class Initialized
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:54:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:54:56 --> Final output sent to browser
DEBUG - 2016-10-28 14:54:56 --> Total execution time: 0.0181
INFO - 2016-10-28 14:54:58 --> Config Class Initialized
INFO - 2016-10-28 14:54:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:54:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:54:58 --> Utf8 Class Initialized
INFO - 2016-10-28 14:54:58 --> URI Class Initialized
INFO - 2016-10-28 14:54:58 --> Router Class Initialized
INFO - 2016-10-28 14:54:58 --> Output Class Initialized
INFO - 2016-10-28 14:54:58 --> Security Class Initialized
DEBUG - 2016-10-28 14:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:54:58 --> Input Class Initialized
INFO - 2016-10-28 14:54:58 --> Language Class Initialized
INFO - 2016-10-28 14:54:58 --> Loader Class Initialized
INFO - 2016-10-28 14:54:58 --> Helper loaded: url_helper
INFO - 2016-10-28 14:54:58 --> Helper loaded: form_helper
INFO - 2016-10-28 14:54:58 --> Database Driver Class Initialized
INFO - 2016-10-28 14:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:54:58 --> Controller Class Initialized
INFO - 2016-10-28 14:54:58 --> Form Validation Class Initialized
INFO - 2016-10-28 14:54:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:54:58 --> Final output sent to browser
DEBUG - 2016-10-28 14:54:58 --> Total execution time: 0.0171
INFO - 2016-10-28 14:55:01 --> Config Class Initialized
INFO - 2016-10-28 14:55:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:55:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:55:01 --> Utf8 Class Initialized
INFO - 2016-10-28 14:55:01 --> URI Class Initialized
INFO - 2016-10-28 14:55:01 --> Router Class Initialized
INFO - 2016-10-28 14:55:01 --> Output Class Initialized
INFO - 2016-10-28 14:55:01 --> Security Class Initialized
DEBUG - 2016-10-28 14:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:55:01 --> Input Class Initialized
INFO - 2016-10-28 14:55:01 --> Language Class Initialized
INFO - 2016-10-28 14:55:01 --> Loader Class Initialized
INFO - 2016-10-28 14:55:01 --> Helper loaded: url_helper
INFO - 2016-10-28 14:55:01 --> Helper loaded: form_helper
INFO - 2016-10-28 14:55:01 --> Database Driver Class Initialized
INFO - 2016-10-28 14:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:55:01 --> Controller Class Initialized
INFO - 2016-10-28 14:55:01 --> Form Validation Class Initialized
INFO - 2016-10-28 14:55:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:55:01 --> Final output sent to browser
DEBUG - 2016-10-28 14:55:01 --> Total execution time: 0.0172
INFO - 2016-10-28 14:55:04 --> Config Class Initialized
INFO - 2016-10-28 14:55:04 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:55:04 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:55:04 --> Utf8 Class Initialized
INFO - 2016-10-28 14:55:04 --> URI Class Initialized
INFO - 2016-10-28 14:55:04 --> Router Class Initialized
INFO - 2016-10-28 14:55:04 --> Output Class Initialized
INFO - 2016-10-28 14:55:04 --> Security Class Initialized
DEBUG - 2016-10-28 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:55:04 --> Input Class Initialized
INFO - 2016-10-28 14:55:04 --> Language Class Initialized
INFO - 2016-10-28 14:55:04 --> Loader Class Initialized
INFO - 2016-10-28 14:55:04 --> Helper loaded: url_helper
INFO - 2016-10-28 14:55:04 --> Helper loaded: form_helper
INFO - 2016-10-28 14:55:04 --> Database Driver Class Initialized
INFO - 2016-10-28 14:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:55:04 --> Controller Class Initialized
INFO - 2016-10-28 14:55:04 --> Form Validation Class Initialized
INFO - 2016-10-28 14:55:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:55:04 --> Model Class Initialized
ERROR - 2016-10-28 14:55:04 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('p+p+p', '3', '')
INFO - 2016-10-28 14:55:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:55:06 --> Config Class Initialized
INFO - 2016-10-28 14:55:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:55:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:55:06 --> Utf8 Class Initialized
INFO - 2016-10-28 14:55:06 --> URI Class Initialized
INFO - 2016-10-28 14:55:06 --> Router Class Initialized
INFO - 2016-10-28 14:55:06 --> Output Class Initialized
INFO - 2016-10-28 14:55:06 --> Security Class Initialized
DEBUG - 2016-10-28 14:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:55:06 --> Input Class Initialized
INFO - 2016-10-28 14:55:06 --> Language Class Initialized
INFO - 2016-10-28 14:55:06 --> Loader Class Initialized
INFO - 2016-10-28 14:55:06 --> Helper loaded: url_helper
INFO - 2016-10-28 14:55:06 --> Helper loaded: form_helper
INFO - 2016-10-28 14:55:06 --> Database Driver Class Initialized
INFO - 2016-10-28 14:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:55:06 --> Controller Class Initialized
INFO - 2016-10-28 14:55:06 --> Form Validation Class Initialized
INFO - 2016-10-28 14:55:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:55:06 --> Model Class Initialized
ERROR - 2016-10-28 14:55:06 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('p+p+p', '3', '')
INFO - 2016-10-28 14:55:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:58:43 --> Config Class Initialized
INFO - 2016-10-28 14:58:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:58:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:58:43 --> Utf8 Class Initialized
INFO - 2016-10-28 14:58:43 --> URI Class Initialized
DEBUG - 2016-10-28 14:58:43 --> No URI present. Default controller set.
INFO - 2016-10-28 14:58:43 --> Router Class Initialized
INFO - 2016-10-28 14:58:43 --> Output Class Initialized
INFO - 2016-10-28 14:58:43 --> Security Class Initialized
DEBUG - 2016-10-28 14:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:58:43 --> Input Class Initialized
INFO - 2016-10-28 14:58:43 --> Language Class Initialized
INFO - 2016-10-28 14:58:43 --> Loader Class Initialized
INFO - 2016-10-28 14:58:43 --> Helper loaded: url_helper
INFO - 2016-10-28 14:58:43 --> Helper loaded: form_helper
INFO - 2016-10-28 14:58:43 --> Database Driver Class Initialized
INFO - 2016-10-28 14:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:58:43 --> Controller Class Initialized
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:58:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:58:43 --> Final output sent to browser
DEBUG - 2016-10-28 14:58:43 --> Total execution time: 0.0180
INFO - 2016-10-28 14:58:44 --> Config Class Initialized
INFO - 2016-10-28 14:58:44 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:58:44 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:58:44 --> Utf8 Class Initialized
INFO - 2016-10-28 14:58:44 --> URI Class Initialized
DEBUG - 2016-10-28 14:58:44 --> No URI present. Default controller set.
INFO - 2016-10-28 14:58:44 --> Router Class Initialized
INFO - 2016-10-28 14:58:44 --> Output Class Initialized
INFO - 2016-10-28 14:58:44 --> Security Class Initialized
DEBUG - 2016-10-28 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:58:44 --> Input Class Initialized
INFO - 2016-10-28 14:58:44 --> Language Class Initialized
INFO - 2016-10-28 14:58:44 --> Loader Class Initialized
INFO - 2016-10-28 14:58:44 --> Helper loaded: url_helper
INFO - 2016-10-28 14:58:44 --> Helper loaded: form_helper
INFO - 2016-10-28 14:58:44 --> Database Driver Class Initialized
INFO - 2016-10-28 14:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:58:44 --> Controller Class Initialized
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:58:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:58:44 --> Final output sent to browser
DEBUG - 2016-10-28 14:58:44 --> Total execution time: 0.0160
INFO - 2016-10-28 14:58:58 --> Config Class Initialized
INFO - 2016-10-28 14:58:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:58:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:58:58 --> Utf8 Class Initialized
INFO - 2016-10-28 14:58:58 --> URI Class Initialized
INFO - 2016-10-28 14:58:58 --> Router Class Initialized
INFO - 2016-10-28 14:58:58 --> Output Class Initialized
INFO - 2016-10-28 14:58:58 --> Security Class Initialized
DEBUG - 2016-10-28 14:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:58:58 --> Input Class Initialized
INFO - 2016-10-28 14:58:58 --> Language Class Initialized
INFO - 2016-10-28 14:58:58 --> Loader Class Initialized
INFO - 2016-10-28 14:58:58 --> Helper loaded: url_helper
INFO - 2016-10-28 14:58:58 --> Helper loaded: form_helper
INFO - 2016-10-28 14:58:58 --> Database Driver Class Initialized
INFO - 2016-10-28 14:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:58:58 --> Controller Class Initialized
INFO - 2016-10-28 14:58:58 --> Form Validation Class Initialized
INFO - 2016-10-28 14:58:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:58:58 --> Model Class Initialized
ERROR - 2016-10-28 14:58:58 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('test', '3', 'pp~++~p')
INFO - 2016-10-28 14:58:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:58:59 --> Config Class Initialized
INFO - 2016-10-28 14:58:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:58:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:58:59 --> Utf8 Class Initialized
INFO - 2016-10-28 14:58:59 --> URI Class Initialized
INFO - 2016-10-28 14:58:59 --> Router Class Initialized
INFO - 2016-10-28 14:58:59 --> Output Class Initialized
INFO - 2016-10-28 14:58:59 --> Security Class Initialized
DEBUG - 2016-10-28 14:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:58:59 --> Input Class Initialized
INFO - 2016-10-28 14:58:59 --> Language Class Initialized
INFO - 2016-10-28 14:58:59 --> Loader Class Initialized
INFO - 2016-10-28 14:58:59 --> Helper loaded: url_helper
INFO - 2016-10-28 14:58:59 --> Helper loaded: form_helper
INFO - 2016-10-28 14:58:59 --> Database Driver Class Initialized
INFO - 2016-10-28 14:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:58:59 --> Controller Class Initialized
INFO - 2016-10-28 14:58:59 --> Form Validation Class Initialized
INFO - 2016-10-28 14:58:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:58:59 --> Model Class Initialized
ERROR - 2016-10-28 14:58:59 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('test', '3', 'pp~++~p')
INFO - 2016-10-28 14:58:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:58:59 --> Config Class Initialized
INFO - 2016-10-28 14:58:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:58:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:58:59 --> Utf8 Class Initialized
INFO - 2016-10-28 14:58:59 --> URI Class Initialized
INFO - 2016-10-28 14:58:59 --> Router Class Initialized
INFO - 2016-10-28 14:58:59 --> Output Class Initialized
INFO - 2016-10-28 14:58:59 --> Security Class Initialized
DEBUG - 2016-10-28 14:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:58:59 --> Input Class Initialized
INFO - 2016-10-28 14:58:59 --> Language Class Initialized
INFO - 2016-10-28 14:58:59 --> Loader Class Initialized
INFO - 2016-10-28 14:58:59 --> Helper loaded: url_helper
INFO - 2016-10-28 14:58:59 --> Helper loaded: form_helper
INFO - 2016-10-28 14:58:59 --> Database Driver Class Initialized
INFO - 2016-10-28 14:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:58:59 --> Controller Class Initialized
INFO - 2016-10-28 14:58:59 --> Form Validation Class Initialized
INFO - 2016-10-28 14:58:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:58:59 --> Model Class Initialized
ERROR - 2016-10-28 14:58:59 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('test', '3', 'pp~++~p')
INFO - 2016-10-28 14:58:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:58:59 --> Config Class Initialized
INFO - 2016-10-28 14:58:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:58:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:58:59 --> Utf8 Class Initialized
INFO - 2016-10-28 14:58:59 --> URI Class Initialized
INFO - 2016-10-28 14:58:59 --> Router Class Initialized
INFO - 2016-10-28 14:58:59 --> Output Class Initialized
INFO - 2016-10-28 14:58:59 --> Security Class Initialized
DEBUG - 2016-10-28 14:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:58:59 --> Input Class Initialized
INFO - 2016-10-28 14:58:59 --> Language Class Initialized
INFO - 2016-10-28 14:58:59 --> Loader Class Initialized
INFO - 2016-10-28 14:58:59 --> Helper loaded: url_helper
INFO - 2016-10-28 14:58:59 --> Helper loaded: form_helper
INFO - 2016-10-28 14:58:59 --> Database Driver Class Initialized
INFO - 2016-10-28 14:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:58:59 --> Controller Class Initialized
INFO - 2016-10-28 14:58:59 --> Form Validation Class Initialized
INFO - 2016-10-28 14:58:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:58:59 --> Model Class Initialized
ERROR - 2016-10-28 14:58:59 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('test', '3', 'pp~++~p')
INFO - 2016-10-28 14:58:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 14:59:00 --> Config Class Initialized
INFO - 2016-10-28 14:59:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:00 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:00 --> URI Class Initialized
DEBUG - 2016-10-28 14:59:00 --> No URI present. Default controller set.
INFO - 2016-10-28 14:59:00 --> Router Class Initialized
INFO - 2016-10-28 14:59:00 --> Output Class Initialized
INFO - 2016-10-28 14:59:00 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:00 --> Input Class Initialized
INFO - 2016-10-28 14:59:00 --> Language Class Initialized
INFO - 2016-10-28 14:59:00 --> Loader Class Initialized
INFO - 2016-10-28 14:59:00 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:00 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:00 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:00 --> Controller Class Initialized
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:59:00 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:00 --> Total execution time: 0.0178
INFO - 2016-10-28 14:59:00 --> Config Class Initialized
INFO - 2016-10-28 14:59:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:00 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:00 --> URI Class Initialized
DEBUG - 2016-10-28 14:59:00 --> No URI present. Default controller set.
INFO - 2016-10-28 14:59:00 --> Router Class Initialized
INFO - 2016-10-28 14:59:00 --> Output Class Initialized
INFO - 2016-10-28 14:59:00 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:00 --> Input Class Initialized
INFO - 2016-10-28 14:59:00 --> Language Class Initialized
INFO - 2016-10-28 14:59:00 --> Loader Class Initialized
INFO - 2016-10-28 14:59:00 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:00 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:00 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:00 --> Controller Class Initialized
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:59:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:59:00 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:00 --> Total execution time: 0.0167
INFO - 2016-10-28 14:59:01 --> Config Class Initialized
INFO - 2016-10-28 14:59:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:01 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:01 --> URI Class Initialized
DEBUG - 2016-10-28 14:59:01 --> No URI present. Default controller set.
INFO - 2016-10-28 14:59:01 --> Router Class Initialized
INFO - 2016-10-28 14:59:01 --> Output Class Initialized
INFO - 2016-10-28 14:59:01 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:01 --> Input Class Initialized
INFO - 2016-10-28 14:59:01 --> Language Class Initialized
INFO - 2016-10-28 14:59:01 --> Loader Class Initialized
INFO - 2016-10-28 14:59:01 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:01 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:01 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:01 --> Controller Class Initialized
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:59:01 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:01 --> Total execution time: 0.0160
INFO - 2016-10-28 14:59:01 --> Config Class Initialized
INFO - 2016-10-28 14:59:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:01 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:01 --> URI Class Initialized
DEBUG - 2016-10-28 14:59:01 --> No URI present. Default controller set.
INFO - 2016-10-28 14:59:01 --> Router Class Initialized
INFO - 2016-10-28 14:59:01 --> Output Class Initialized
INFO - 2016-10-28 14:59:01 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:01 --> Input Class Initialized
INFO - 2016-10-28 14:59:01 --> Language Class Initialized
INFO - 2016-10-28 14:59:01 --> Loader Class Initialized
INFO - 2016-10-28 14:59:01 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:01 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:01 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:01 --> Controller Class Initialized
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:59:01 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:01 --> Total execution time: 0.0160
INFO - 2016-10-28 14:59:01 --> Config Class Initialized
INFO - 2016-10-28 14:59:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:01 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:01 --> URI Class Initialized
DEBUG - 2016-10-28 14:59:01 --> No URI present. Default controller set.
INFO - 2016-10-28 14:59:01 --> Router Class Initialized
INFO - 2016-10-28 14:59:01 --> Output Class Initialized
INFO - 2016-10-28 14:59:01 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:01 --> Input Class Initialized
INFO - 2016-10-28 14:59:01 --> Language Class Initialized
INFO - 2016-10-28 14:59:01 --> Loader Class Initialized
INFO - 2016-10-28 14:59:01 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:01 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:01 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:01 --> Controller Class Initialized
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:59:01 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:01 --> Total execution time: 0.0167
INFO - 2016-10-28 14:59:01 --> Config Class Initialized
INFO - 2016-10-28 14:59:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:01 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:01 --> URI Class Initialized
DEBUG - 2016-10-28 14:59:01 --> No URI present. Default controller set.
INFO - 2016-10-28 14:59:01 --> Router Class Initialized
INFO - 2016-10-28 14:59:01 --> Output Class Initialized
INFO - 2016-10-28 14:59:01 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:01 --> Input Class Initialized
INFO - 2016-10-28 14:59:01 --> Language Class Initialized
INFO - 2016-10-28 14:59:01 --> Loader Class Initialized
INFO - 2016-10-28 14:59:01 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:01 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:01 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:01 --> Controller Class Initialized
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 14:59:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 14:59:01 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:01 --> Total execution time: 0.0160
INFO - 2016-10-28 14:59:03 --> Config Class Initialized
INFO - 2016-10-28 14:59:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:03 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:03 --> URI Class Initialized
INFO - 2016-10-28 14:59:03 --> Router Class Initialized
INFO - 2016-10-28 14:59:03 --> Output Class Initialized
INFO - 2016-10-28 14:59:03 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:03 --> Input Class Initialized
INFO - 2016-10-28 14:59:03 --> Language Class Initialized
INFO - 2016-10-28 14:59:03 --> Loader Class Initialized
INFO - 2016-10-28 14:59:03 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:03 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:03 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:03 --> Controller Class Initialized
INFO - 2016-10-28 14:59:03 --> Form Validation Class Initialized
INFO - 2016-10-28 14:59:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:59:03 --> Final output sent to browser
DEBUG - 2016-10-28 14:59:03 --> Total execution time: 0.0171
INFO - 2016-10-28 14:59:07 --> Config Class Initialized
INFO - 2016-10-28 14:59:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 14:59:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 14:59:07 --> Utf8 Class Initialized
INFO - 2016-10-28 14:59:07 --> URI Class Initialized
INFO - 2016-10-28 14:59:07 --> Router Class Initialized
INFO - 2016-10-28 14:59:07 --> Output Class Initialized
INFO - 2016-10-28 14:59:07 --> Security Class Initialized
DEBUG - 2016-10-28 14:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 14:59:07 --> Input Class Initialized
INFO - 2016-10-28 14:59:07 --> Language Class Initialized
INFO - 2016-10-28 14:59:07 --> Loader Class Initialized
INFO - 2016-10-28 14:59:07 --> Helper loaded: url_helper
INFO - 2016-10-28 14:59:07 --> Helper loaded: form_helper
INFO - 2016-10-28 14:59:07 --> Database Driver Class Initialized
INFO - 2016-10-28 14:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 14:59:07 --> Controller Class Initialized
INFO - 2016-10-28 14:59:07 --> Form Validation Class Initialized
INFO - 2016-10-28 14:59:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 14:59:07 --> Model Class Initialized
ERROR - 2016-10-28 14:59:07 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('p+', '2', '~p+~p')
INFO - 2016-10-28 14:59:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:00:40 --> Config Class Initialized
INFO - 2016-10-28 15:00:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:00:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:00:40 --> Utf8 Class Initialized
INFO - 2016-10-28 15:00:40 --> URI Class Initialized
DEBUG - 2016-10-28 15:00:40 --> No URI present. Default controller set.
INFO - 2016-10-28 15:00:40 --> Router Class Initialized
INFO - 2016-10-28 15:00:40 --> Output Class Initialized
INFO - 2016-10-28 15:00:40 --> Security Class Initialized
DEBUG - 2016-10-28 15:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:00:40 --> Input Class Initialized
INFO - 2016-10-28 15:00:40 --> Language Class Initialized
INFO - 2016-10-28 15:00:40 --> Loader Class Initialized
INFO - 2016-10-28 15:00:40 --> Helper loaded: url_helper
INFO - 2016-10-28 15:00:40 --> Helper loaded: form_helper
INFO - 2016-10-28 15:00:40 --> Database Driver Class Initialized
INFO - 2016-10-28 15:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:00:40 --> Controller Class Initialized
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:00:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:00:40 --> Final output sent to browser
DEBUG - 2016-10-28 15:00:40 --> Total execution time: 0.0177
INFO - 2016-10-28 15:00:43 --> Config Class Initialized
INFO - 2016-10-28 15:00:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:00:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:00:43 --> Utf8 Class Initialized
INFO - 2016-10-28 15:00:43 --> URI Class Initialized
INFO - 2016-10-28 15:00:43 --> Router Class Initialized
INFO - 2016-10-28 15:00:43 --> Output Class Initialized
INFO - 2016-10-28 15:00:43 --> Security Class Initialized
DEBUG - 2016-10-28 15:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:00:43 --> Input Class Initialized
INFO - 2016-10-28 15:00:43 --> Language Class Initialized
INFO - 2016-10-28 15:00:43 --> Loader Class Initialized
INFO - 2016-10-28 15:00:43 --> Helper loaded: url_helper
INFO - 2016-10-28 15:00:43 --> Helper loaded: form_helper
INFO - 2016-10-28 15:00:43 --> Database Driver Class Initialized
INFO - 2016-10-28 15:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:00:43 --> Controller Class Initialized
INFO - 2016-10-28 15:00:43 --> Form Validation Class Initialized
INFO - 2016-10-28 15:00:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:00:43 --> Final output sent to browser
DEBUG - 2016-10-28 15:00:43 --> Total execution time: 0.0170
INFO - 2016-10-28 15:00:46 --> Config Class Initialized
INFO - 2016-10-28 15:00:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:00:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:00:46 --> Utf8 Class Initialized
INFO - 2016-10-28 15:00:46 --> URI Class Initialized
INFO - 2016-10-28 15:00:46 --> Router Class Initialized
INFO - 2016-10-28 15:00:46 --> Output Class Initialized
INFO - 2016-10-28 15:00:46 --> Security Class Initialized
DEBUG - 2016-10-28 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:00:46 --> Input Class Initialized
INFO - 2016-10-28 15:00:46 --> Language Class Initialized
INFO - 2016-10-28 15:00:46 --> Loader Class Initialized
INFO - 2016-10-28 15:00:46 --> Helper loaded: url_helper
INFO - 2016-10-28 15:00:46 --> Helper loaded: form_helper
INFO - 2016-10-28 15:00:46 --> Database Driver Class Initialized
INFO - 2016-10-28 15:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:00:46 --> Controller Class Initialized
INFO - 2016-10-28 15:00:46 --> Form Validation Class Initialized
INFO - 2016-10-28 15:00:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:00:46 --> Model Class Initialized
ERROR - 2016-10-28 15:00:46 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('edwed', '3', '')
INFO - 2016-10-28 15:00:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:00:47 --> Config Class Initialized
INFO - 2016-10-28 15:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:00:47 --> Utf8 Class Initialized
INFO - 2016-10-28 15:00:47 --> URI Class Initialized
INFO - 2016-10-28 15:00:47 --> Router Class Initialized
INFO - 2016-10-28 15:00:47 --> Output Class Initialized
INFO - 2016-10-28 15:00:47 --> Security Class Initialized
DEBUG - 2016-10-28 15:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:00:47 --> Input Class Initialized
INFO - 2016-10-28 15:00:47 --> Language Class Initialized
INFO - 2016-10-28 15:00:47 --> Loader Class Initialized
INFO - 2016-10-28 15:00:47 --> Helper loaded: url_helper
INFO - 2016-10-28 15:00:47 --> Helper loaded: form_helper
INFO - 2016-10-28 15:00:47 --> Database Driver Class Initialized
INFO - 2016-10-28 15:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:00:47 --> Controller Class Initialized
INFO - 2016-10-28 15:00:47 --> Form Validation Class Initialized
INFO - 2016-10-28 15:00:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:00:47 --> Model Class Initialized
ERROR - 2016-10-28 15:00:47 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('edwed', '3', '')
INFO - 2016-10-28 15:00:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:00:48 --> Config Class Initialized
INFO - 2016-10-28 15:00:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:00:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:00:48 --> Utf8 Class Initialized
INFO - 2016-10-28 15:00:48 --> URI Class Initialized
INFO - 2016-10-28 15:00:48 --> Router Class Initialized
INFO - 2016-10-28 15:00:48 --> Output Class Initialized
INFO - 2016-10-28 15:00:48 --> Security Class Initialized
DEBUG - 2016-10-28 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:00:48 --> Input Class Initialized
INFO - 2016-10-28 15:00:48 --> Language Class Initialized
INFO - 2016-10-28 15:00:48 --> Loader Class Initialized
INFO - 2016-10-28 15:00:48 --> Helper loaded: url_helper
INFO - 2016-10-28 15:00:48 --> Helper loaded: form_helper
INFO - 2016-10-28 15:00:48 --> Database Driver Class Initialized
INFO - 2016-10-28 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:00:48 --> Controller Class Initialized
INFO - 2016-10-28 15:00:48 --> Form Validation Class Initialized
INFO - 2016-10-28 15:00:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:00:48 --> Model Class Initialized
ERROR - 2016-10-28 15:00:48 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('edwed', '3', '')
INFO - 2016-10-28 15:00:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:00:48 --> Config Class Initialized
INFO - 2016-10-28 15:00:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:00:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:00:48 --> Utf8 Class Initialized
INFO - 2016-10-28 15:00:48 --> URI Class Initialized
INFO - 2016-10-28 15:00:48 --> Router Class Initialized
INFO - 2016-10-28 15:00:48 --> Output Class Initialized
INFO - 2016-10-28 15:00:48 --> Security Class Initialized
DEBUG - 2016-10-28 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:00:48 --> Input Class Initialized
INFO - 2016-10-28 15:00:48 --> Language Class Initialized
INFO - 2016-10-28 15:00:48 --> Loader Class Initialized
INFO - 2016-10-28 15:00:48 --> Helper loaded: url_helper
INFO - 2016-10-28 15:00:48 --> Helper loaded: form_helper
INFO - 2016-10-28 15:00:48 --> Database Driver Class Initialized
INFO - 2016-10-28 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:00:48 --> Controller Class Initialized
INFO - 2016-10-28 15:00:48 --> Form Validation Class Initialized
INFO - 2016-10-28 15:00:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:00:48 --> Model Class Initialized
ERROR - 2016-10-28 15:00:48 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('edwed', '3', '')
INFO - 2016-10-28 15:00:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:01:05 --> Config Class Initialized
INFO - 2016-10-28 15:01:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:05 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:05 --> URI Class Initialized
DEBUG - 2016-10-28 15:01:05 --> No URI present. Default controller set.
INFO - 2016-10-28 15:01:05 --> Router Class Initialized
INFO - 2016-10-28 15:01:05 --> Output Class Initialized
INFO - 2016-10-28 15:01:05 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:05 --> Input Class Initialized
INFO - 2016-10-28 15:01:05 --> Language Class Initialized
INFO - 2016-10-28 15:01:05 --> Loader Class Initialized
INFO - 2016-10-28 15:01:05 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:05 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:05 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:05 --> Controller Class Initialized
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:01:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:01:05 --> Final output sent to browser
DEBUG - 2016-10-28 15:01:05 --> Total execution time: 0.0174
INFO - 2016-10-28 15:01:07 --> Config Class Initialized
INFO - 2016-10-28 15:01:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:07 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:07 --> URI Class Initialized
INFO - 2016-10-28 15:01:07 --> Router Class Initialized
INFO - 2016-10-28 15:01:07 --> Output Class Initialized
INFO - 2016-10-28 15:01:07 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:07 --> Input Class Initialized
INFO - 2016-10-28 15:01:07 --> Language Class Initialized
INFO - 2016-10-28 15:01:07 --> Loader Class Initialized
INFO - 2016-10-28 15:01:07 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:07 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:07 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:07 --> Controller Class Initialized
INFO - 2016-10-28 15:01:07 --> Form Validation Class Initialized
INFO - 2016-10-28 15:01:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:01:07 --> Final output sent to browser
DEBUG - 2016-10-28 15:01:07 --> Total execution time: 0.0172
INFO - 2016-10-28 15:01:12 --> Config Class Initialized
INFO - 2016-10-28 15:01:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:12 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:12 --> URI Class Initialized
INFO - 2016-10-28 15:01:12 --> Router Class Initialized
INFO - 2016-10-28 15:01:12 --> Output Class Initialized
INFO - 2016-10-28 15:01:12 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:12 --> Input Class Initialized
INFO - 2016-10-28 15:01:12 --> Language Class Initialized
INFO - 2016-10-28 15:01:12 --> Loader Class Initialized
INFO - 2016-10-28 15:01:12 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:12 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:12 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:12 --> Controller Class Initialized
INFO - 2016-10-28 15:01:12 --> Form Validation Class Initialized
INFO - 2016-10-28 15:01:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:01:12 --> Model Class Initialized
ERROR - 2016-10-28 15:01:12 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('vffd', '1', 'fvsd')
INFO - 2016-10-28 15:01:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:01:16 --> Config Class Initialized
INFO - 2016-10-28 15:01:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:16 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:16 --> URI Class Initialized
INFO - 2016-10-28 15:01:16 --> Router Class Initialized
INFO - 2016-10-28 15:01:16 --> Output Class Initialized
INFO - 2016-10-28 15:01:16 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:16 --> Input Class Initialized
INFO - 2016-10-28 15:01:16 --> Language Class Initialized
INFO - 2016-10-28 15:01:16 --> Loader Class Initialized
INFO - 2016-10-28 15:01:16 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:16 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:16 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:16 --> Controller Class Initialized
INFO - 2016-10-28 15:01:16 --> Form Validation Class Initialized
INFO - 2016-10-28 15:01:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:01:16 --> Model Class Initialized
ERROR - 2016-10-28 15:01:16 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('vffd', '1', 'fvsd')
INFO - 2016-10-28 15:01:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:01:33 --> Config Class Initialized
INFO - 2016-10-28 15:01:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:33 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:33 --> URI Class Initialized
DEBUG - 2016-10-28 15:01:33 --> No URI present. Default controller set.
INFO - 2016-10-28 15:01:33 --> Router Class Initialized
INFO - 2016-10-28 15:01:33 --> Output Class Initialized
INFO - 2016-10-28 15:01:33 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:33 --> Input Class Initialized
INFO - 2016-10-28 15:01:33 --> Language Class Initialized
INFO - 2016-10-28 15:01:33 --> Loader Class Initialized
INFO - 2016-10-28 15:01:33 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:33 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:33 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:33 --> Controller Class Initialized
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:01:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:01:33 --> Final output sent to browser
DEBUG - 2016-10-28 15:01:33 --> Total execution time: 0.0176
INFO - 2016-10-28 15:01:35 --> Config Class Initialized
INFO - 2016-10-28 15:01:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:35 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:35 --> URI Class Initialized
INFO - 2016-10-28 15:01:35 --> Router Class Initialized
INFO - 2016-10-28 15:01:35 --> Output Class Initialized
INFO - 2016-10-28 15:01:35 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:35 --> Input Class Initialized
INFO - 2016-10-28 15:01:35 --> Language Class Initialized
INFO - 2016-10-28 15:01:35 --> Loader Class Initialized
INFO - 2016-10-28 15:01:35 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:35 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:35 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:35 --> Controller Class Initialized
INFO - 2016-10-28 15:01:35 --> Form Validation Class Initialized
INFO - 2016-10-28 15:01:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:01:35 --> Final output sent to browser
DEBUG - 2016-10-28 15:01:35 --> Total execution time: 0.0167
INFO - 2016-10-28 15:01:39 --> Config Class Initialized
INFO - 2016-10-28 15:01:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:39 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:39 --> URI Class Initialized
INFO - 2016-10-28 15:01:39 --> Router Class Initialized
INFO - 2016-10-28 15:01:39 --> Output Class Initialized
INFO - 2016-10-28 15:01:39 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:39 --> Input Class Initialized
INFO - 2016-10-28 15:01:39 --> Language Class Initialized
INFO - 2016-10-28 15:01:39 --> Loader Class Initialized
INFO - 2016-10-28 15:01:39 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:39 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:39 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:39 --> Controller Class Initialized
INFO - 2016-10-28 15:01:39 --> Form Validation Class Initialized
INFO - 2016-10-28 15:01:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:01:39 --> Model Class Initialized
ERROR - 2016-10-28 15:01:39 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('qwdq', '3', 'wqqs')
INFO - 2016-10-28 15:01:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:01:40 --> Config Class Initialized
INFO - 2016-10-28 15:01:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:01:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:01:40 --> Utf8 Class Initialized
INFO - 2016-10-28 15:01:40 --> URI Class Initialized
INFO - 2016-10-28 15:01:40 --> Router Class Initialized
INFO - 2016-10-28 15:01:40 --> Output Class Initialized
INFO - 2016-10-28 15:01:40 --> Security Class Initialized
DEBUG - 2016-10-28 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:01:40 --> Input Class Initialized
INFO - 2016-10-28 15:01:40 --> Language Class Initialized
INFO - 2016-10-28 15:01:40 --> Loader Class Initialized
INFO - 2016-10-28 15:01:40 --> Helper loaded: url_helper
INFO - 2016-10-28 15:01:40 --> Helper loaded: form_helper
INFO - 2016-10-28 15:01:40 --> Database Driver Class Initialized
INFO - 2016-10-28 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:01:40 --> Controller Class Initialized
INFO - 2016-10-28 15:01:40 --> Form Validation Class Initialized
INFO - 2016-10-28 15:01:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:01:40 --> Model Class Initialized
ERROR - 2016-10-28 15:01:40 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('qwdq', '3', 'wqqs')
INFO - 2016-10-28 15:01:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:03:30 --> Config Class Initialized
INFO - 2016-10-28 15:03:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:03:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:03:30 --> Utf8 Class Initialized
INFO - 2016-10-28 15:03:30 --> URI Class Initialized
DEBUG - 2016-10-28 15:03:30 --> No URI present. Default controller set.
INFO - 2016-10-28 15:03:30 --> Router Class Initialized
INFO - 2016-10-28 15:03:30 --> Output Class Initialized
INFO - 2016-10-28 15:03:30 --> Security Class Initialized
DEBUG - 2016-10-28 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:03:30 --> Input Class Initialized
INFO - 2016-10-28 15:03:30 --> Language Class Initialized
INFO - 2016-10-28 15:03:30 --> Loader Class Initialized
INFO - 2016-10-28 15:03:30 --> Helper loaded: url_helper
INFO - 2016-10-28 15:03:30 --> Helper loaded: form_helper
INFO - 2016-10-28 15:03:30 --> Database Driver Class Initialized
INFO - 2016-10-28 15:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:03:30 --> Controller Class Initialized
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:03:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:03:30 --> Final output sent to browser
DEBUG - 2016-10-28 15:03:30 --> Total execution time: 0.0174
INFO - 2016-10-28 15:03:31 --> Config Class Initialized
INFO - 2016-10-28 15:03:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:03:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:03:31 --> Utf8 Class Initialized
INFO - 2016-10-28 15:03:31 --> URI Class Initialized
DEBUG - 2016-10-28 15:03:31 --> No URI present. Default controller set.
INFO - 2016-10-28 15:03:31 --> Router Class Initialized
INFO - 2016-10-28 15:03:31 --> Output Class Initialized
INFO - 2016-10-28 15:03:31 --> Security Class Initialized
DEBUG - 2016-10-28 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:03:31 --> Input Class Initialized
INFO - 2016-10-28 15:03:31 --> Language Class Initialized
INFO - 2016-10-28 15:03:31 --> Loader Class Initialized
INFO - 2016-10-28 15:03:31 --> Helper loaded: url_helper
INFO - 2016-10-28 15:03:31 --> Helper loaded: form_helper
INFO - 2016-10-28 15:03:31 --> Database Driver Class Initialized
INFO - 2016-10-28 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:03:31 --> Controller Class Initialized
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:03:31 --> Final output sent to browser
DEBUG - 2016-10-28 15:03:31 --> Total execution time: 0.0167
INFO - 2016-10-28 15:03:31 --> Config Class Initialized
INFO - 2016-10-28 15:03:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:03:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:03:31 --> Utf8 Class Initialized
INFO - 2016-10-28 15:03:31 --> URI Class Initialized
DEBUG - 2016-10-28 15:03:31 --> No URI present. Default controller set.
INFO - 2016-10-28 15:03:31 --> Router Class Initialized
INFO - 2016-10-28 15:03:31 --> Output Class Initialized
INFO - 2016-10-28 15:03:31 --> Security Class Initialized
DEBUG - 2016-10-28 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:03:31 --> Input Class Initialized
INFO - 2016-10-28 15:03:31 --> Language Class Initialized
INFO - 2016-10-28 15:03:31 --> Loader Class Initialized
INFO - 2016-10-28 15:03:31 --> Helper loaded: url_helper
INFO - 2016-10-28 15:03:31 --> Helper loaded: form_helper
INFO - 2016-10-28 15:03:31 --> Database Driver Class Initialized
INFO - 2016-10-28 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:03:31 --> Controller Class Initialized
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:03:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:03:31 --> Final output sent to browser
DEBUG - 2016-10-28 15:03:31 --> Total execution time: 0.0157
INFO - 2016-10-28 15:03:33 --> Config Class Initialized
INFO - 2016-10-28 15:03:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:03:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:03:33 --> Utf8 Class Initialized
INFO - 2016-10-28 15:03:33 --> URI Class Initialized
INFO - 2016-10-28 15:03:33 --> Router Class Initialized
INFO - 2016-10-28 15:03:33 --> Output Class Initialized
INFO - 2016-10-28 15:03:33 --> Security Class Initialized
DEBUG - 2016-10-28 15:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:03:33 --> Input Class Initialized
INFO - 2016-10-28 15:03:33 --> Language Class Initialized
INFO - 2016-10-28 15:03:33 --> Loader Class Initialized
INFO - 2016-10-28 15:03:33 --> Helper loaded: url_helper
INFO - 2016-10-28 15:03:33 --> Helper loaded: form_helper
INFO - 2016-10-28 15:03:33 --> Database Driver Class Initialized
INFO - 2016-10-28 15:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:03:33 --> Controller Class Initialized
INFO - 2016-10-28 15:03:33 --> Form Validation Class Initialized
INFO - 2016-10-28 15:03:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:03:33 --> Final output sent to browser
DEBUG - 2016-10-28 15:03:33 --> Total execution time: 0.0168
INFO - 2016-10-28 15:03:37 --> Config Class Initialized
INFO - 2016-10-28 15:03:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:03:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:03:37 --> Utf8 Class Initialized
INFO - 2016-10-28 15:03:37 --> URI Class Initialized
INFO - 2016-10-28 15:03:37 --> Router Class Initialized
INFO - 2016-10-28 15:03:37 --> Output Class Initialized
INFO - 2016-10-28 15:03:37 --> Security Class Initialized
DEBUG - 2016-10-28 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:03:37 --> Input Class Initialized
INFO - 2016-10-28 15:03:37 --> Language Class Initialized
INFO - 2016-10-28 15:03:37 --> Loader Class Initialized
INFO - 2016-10-28 15:03:37 --> Helper loaded: url_helper
INFO - 2016-10-28 15:03:37 --> Helper loaded: form_helper
INFO - 2016-10-28 15:03:37 --> Database Driver Class Initialized
INFO - 2016-10-28 15:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:03:37 --> Controller Class Initialized
INFO - 2016-10-28 15:03:37 --> Form Validation Class Initialized
INFO - 2016-10-28 15:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:03:37 --> Model Class Initialized
ERROR - 2016-10-28 15:03:37 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('xbfdsd', '1', 'dfvdsvsdvf')
INFO - 2016-10-28 15:03:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:04:46 --> Config Class Initialized
INFO - 2016-10-28 15:04:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:04:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:04:46 --> Utf8 Class Initialized
INFO - 2016-10-28 15:04:46 --> URI Class Initialized
INFO - 2016-10-28 15:04:46 --> Router Class Initialized
INFO - 2016-10-28 15:04:46 --> Output Class Initialized
INFO - 2016-10-28 15:04:46 --> Security Class Initialized
DEBUG - 2016-10-28 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:04:46 --> Input Class Initialized
INFO - 2016-10-28 15:04:46 --> Language Class Initialized
ERROR - 2016-10-28 15:04:46 --> Severity: Parsing Error --> syntax error, unexpected ''<----------------------------' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
INFO - 2016-10-28 15:04:46 --> Config Class Initialized
INFO - 2016-10-28 15:04:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:04:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:04:46 --> Utf8 Class Initialized
INFO - 2016-10-28 15:04:46 --> URI Class Initialized
INFO - 2016-10-28 15:04:46 --> Router Class Initialized
INFO - 2016-10-28 15:04:46 --> Output Class Initialized
INFO - 2016-10-28 15:04:46 --> Security Class Initialized
DEBUG - 2016-10-28 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:04:46 --> Input Class Initialized
INFO - 2016-10-28 15:04:46 --> Language Class Initialized
ERROR - 2016-10-28 15:04:46 --> Severity: Parsing Error --> syntax error, unexpected ''<----------------------------' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
INFO - 2016-10-28 15:05:13 --> Config Class Initialized
INFO - 2016-10-28 15:05:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:13 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:13 --> URI Class Initialized
DEBUG - 2016-10-28 15:05:13 --> No URI present. Default controller set.
INFO - 2016-10-28 15:05:13 --> Router Class Initialized
INFO - 2016-10-28 15:05:13 --> Output Class Initialized
INFO - 2016-10-28 15:05:13 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:13 --> Input Class Initialized
INFO - 2016-10-28 15:05:13 --> Language Class Initialized
INFO - 2016-10-28 15:05:13 --> Loader Class Initialized
INFO - 2016-10-28 15:05:13 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:13 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:13 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:13 --> Controller Class Initialized
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:05:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:05:13 --> Final output sent to browser
DEBUG - 2016-10-28 15:05:13 --> Total execution time: 0.0175
INFO - 2016-10-28 15:05:17 --> Config Class Initialized
INFO - 2016-10-28 15:05:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:17 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:17 --> URI Class Initialized
INFO - 2016-10-28 15:05:17 --> Router Class Initialized
INFO - 2016-10-28 15:05:17 --> Output Class Initialized
INFO - 2016-10-28 15:05:17 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:17 --> Input Class Initialized
INFO - 2016-10-28 15:05:17 --> Language Class Initialized
INFO - 2016-10-28 15:05:17 --> Loader Class Initialized
INFO - 2016-10-28 15:05:17 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:17 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:17 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:17 --> Controller Class Initialized
INFO - 2016-10-28 15:05:17 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:17 --> Model Class Initialized
ERROR - 2016-10-28 15:05:17 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:17 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:26 --> Config Class Initialized
INFO - 2016-10-28 15:05:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:26 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:26 --> URI Class Initialized
INFO - 2016-10-28 15:05:26 --> Router Class Initialized
INFO - 2016-10-28 15:05:26 --> Output Class Initialized
INFO - 2016-10-28 15:05:26 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:26 --> Input Class Initialized
INFO - 2016-10-28 15:05:26 --> Language Class Initialized
INFO - 2016-10-28 15:05:26 --> Loader Class Initialized
INFO - 2016-10-28 15:05:26 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:26 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:26 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:26 --> Controller Class Initialized
INFO - 2016-10-28 15:05:26 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:26 --> Model Class Initialized
ERROR - 2016-10-28 15:05:26 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:26 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:26 --> Config Class Initialized
INFO - 2016-10-28 15:05:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:26 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:26 --> URI Class Initialized
INFO - 2016-10-28 15:05:26 --> Router Class Initialized
INFO - 2016-10-28 15:05:26 --> Output Class Initialized
INFO - 2016-10-28 15:05:26 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:26 --> Input Class Initialized
INFO - 2016-10-28 15:05:26 --> Language Class Initialized
INFO - 2016-10-28 15:05:26 --> Loader Class Initialized
INFO - 2016-10-28 15:05:26 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:26 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:26 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:26 --> Controller Class Initialized
INFO - 2016-10-28 15:05:26 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:26 --> Model Class Initialized
ERROR - 2016-10-28 15:05:26 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:26 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:27 --> Config Class Initialized
INFO - 2016-10-28 15:05:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:27 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:27 --> URI Class Initialized
INFO - 2016-10-28 15:05:27 --> Router Class Initialized
INFO - 2016-10-28 15:05:27 --> Output Class Initialized
INFO - 2016-10-28 15:05:27 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:27 --> Input Class Initialized
INFO - 2016-10-28 15:05:27 --> Language Class Initialized
INFO - 2016-10-28 15:05:27 --> Loader Class Initialized
INFO - 2016-10-28 15:05:27 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:27 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:27 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:27 --> Controller Class Initialized
INFO - 2016-10-28 15:05:27 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:27 --> Model Class Initialized
ERROR - 2016-10-28 15:05:27 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:27 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:42 --> Config Class Initialized
INFO - 2016-10-28 15:05:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:42 --> URI Class Initialized
INFO - 2016-10-28 15:05:42 --> Router Class Initialized
INFO - 2016-10-28 15:05:42 --> Output Class Initialized
INFO - 2016-10-28 15:05:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:42 --> Input Class Initialized
INFO - 2016-10-28 15:05:42 --> Language Class Initialized
INFO - 2016-10-28 15:05:42 --> Loader Class Initialized
INFO - 2016-10-28 15:05:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:42 --> Controller Class Initialized
INFO - 2016-10-28 15:05:42 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:42 --> Model Class Initialized
ERROR - 2016-10-28 15:05:42 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:42 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:42 --> Config Class Initialized
INFO - 2016-10-28 15:05:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:42 --> URI Class Initialized
INFO - 2016-10-28 15:05:42 --> Router Class Initialized
INFO - 2016-10-28 15:05:42 --> Output Class Initialized
INFO - 2016-10-28 15:05:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:42 --> Input Class Initialized
INFO - 2016-10-28 15:05:42 --> Language Class Initialized
INFO - 2016-10-28 15:05:42 --> Loader Class Initialized
INFO - 2016-10-28 15:05:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:42 --> Controller Class Initialized
INFO - 2016-10-28 15:05:42 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:42 --> Model Class Initialized
ERROR - 2016-10-28 15:05:42 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:42 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:42 --> Config Class Initialized
INFO - 2016-10-28 15:05:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:42 --> URI Class Initialized
INFO - 2016-10-28 15:05:42 --> Router Class Initialized
INFO - 2016-10-28 15:05:42 --> Output Class Initialized
INFO - 2016-10-28 15:05:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:42 --> Input Class Initialized
INFO - 2016-10-28 15:05:42 --> Language Class Initialized
INFO - 2016-10-28 15:05:42 --> Loader Class Initialized
INFO - 2016-10-28 15:05:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:42 --> Controller Class Initialized
INFO - 2016-10-28 15:05:42 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:42 --> Model Class Initialized
ERROR - 2016-10-28 15:05:42 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:42 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:42 --> Config Class Initialized
INFO - 2016-10-28 15:05:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:42 --> URI Class Initialized
INFO - 2016-10-28 15:05:42 --> Router Class Initialized
INFO - 2016-10-28 15:05:42 --> Output Class Initialized
INFO - 2016-10-28 15:05:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:42 --> Input Class Initialized
INFO - 2016-10-28 15:05:42 --> Language Class Initialized
INFO - 2016-10-28 15:05:42 --> Loader Class Initialized
INFO - 2016-10-28 15:05:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:42 --> Controller Class Initialized
INFO - 2016-10-28 15:05:42 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:42 --> Model Class Initialized
ERROR - 2016-10-28 15:05:42 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:42 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:42 --> Config Class Initialized
INFO - 2016-10-28 15:05:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:42 --> URI Class Initialized
INFO - 2016-10-28 15:05:42 --> Router Class Initialized
INFO - 2016-10-28 15:05:42 --> Output Class Initialized
INFO - 2016-10-28 15:05:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:42 --> Input Class Initialized
INFO - 2016-10-28 15:05:42 --> Language Class Initialized
INFO - 2016-10-28 15:05:42 --> Loader Class Initialized
INFO - 2016-10-28 15:05:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:42 --> Controller Class Initialized
INFO - 2016-10-28 15:05:42 --> Form Validation Class Initialized
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:05:42 --> Model Class Initialized
ERROR - 2016-10-28 15:05:42 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:05:42 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('asdas', '3', 'asda')
INFO - 2016-10-28 15:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:05:54 --> Config Class Initialized
INFO - 2016-10-28 15:05:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:54 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:54 --> URI Class Initialized
DEBUG - 2016-10-28 15:05:54 --> No URI present. Default controller set.
INFO - 2016-10-28 15:05:54 --> Router Class Initialized
INFO - 2016-10-28 15:05:54 --> Output Class Initialized
INFO - 2016-10-28 15:05:54 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:54 --> Input Class Initialized
INFO - 2016-10-28 15:05:54 --> Language Class Initialized
INFO - 2016-10-28 15:05:54 --> Loader Class Initialized
INFO - 2016-10-28 15:05:54 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:54 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:54 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:54 --> Controller Class Initialized
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:05:54 --> Final output sent to browser
DEBUG - 2016-10-28 15:05:54 --> Total execution time: 0.0179
INFO - 2016-10-28 15:05:54 --> Config Class Initialized
INFO - 2016-10-28 15:05:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:05:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:05:54 --> Utf8 Class Initialized
INFO - 2016-10-28 15:05:54 --> URI Class Initialized
DEBUG - 2016-10-28 15:05:54 --> No URI present. Default controller set.
INFO - 2016-10-28 15:05:54 --> Router Class Initialized
INFO - 2016-10-28 15:05:54 --> Output Class Initialized
INFO - 2016-10-28 15:05:54 --> Security Class Initialized
DEBUG - 2016-10-28 15:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:05:54 --> Input Class Initialized
INFO - 2016-10-28 15:05:54 --> Language Class Initialized
INFO - 2016-10-28 15:05:54 --> Loader Class Initialized
INFO - 2016-10-28 15:05:54 --> Helper loaded: url_helper
INFO - 2016-10-28 15:05:54 --> Helper loaded: form_helper
INFO - 2016-10-28 15:05:54 --> Database Driver Class Initialized
INFO - 2016-10-28 15:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:05:54 --> Controller Class Initialized
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:05:54 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:05:54 --> Final output sent to browser
DEBUG - 2016-10-28 15:05:54 --> Total execution time: 0.0165
INFO - 2016-10-28 15:06:00 --> Config Class Initialized
INFO - 2016-10-28 15:06:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:06:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:06:00 --> Utf8 Class Initialized
INFO - 2016-10-28 15:06:00 --> URI Class Initialized
INFO - 2016-10-28 15:06:00 --> Router Class Initialized
INFO - 2016-10-28 15:06:00 --> Output Class Initialized
INFO - 2016-10-28 15:06:00 --> Security Class Initialized
DEBUG - 2016-10-28 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:06:00 --> Input Class Initialized
INFO - 2016-10-28 15:06:00 --> Language Class Initialized
INFO - 2016-10-28 15:06:00 --> Loader Class Initialized
INFO - 2016-10-28 15:06:00 --> Helper loaded: url_helper
INFO - 2016-10-28 15:06:00 --> Helper loaded: form_helper
INFO - 2016-10-28 15:06:00 --> Database Driver Class Initialized
INFO - 2016-10-28 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:06:00 --> Controller Class Initialized
INFO - 2016-10-28 15:06:00 --> Form Validation Class Initialized
INFO - 2016-10-28 15:06:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:06:00 --> Model Class Initialized
ERROR - 2016-10-28 15:06:00 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:06:00 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('<x<xz<z', '4', '<zx<x<')
INFO - 2016-10-28 15:06:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:06:01 --> Config Class Initialized
INFO - 2016-10-28 15:06:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:06:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:06:01 --> Utf8 Class Initialized
INFO - 2016-10-28 15:06:01 --> URI Class Initialized
INFO - 2016-10-28 15:06:01 --> Router Class Initialized
INFO - 2016-10-28 15:06:01 --> Output Class Initialized
INFO - 2016-10-28 15:06:01 --> Security Class Initialized
DEBUG - 2016-10-28 15:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:06:01 --> Input Class Initialized
INFO - 2016-10-28 15:06:01 --> Language Class Initialized
INFO - 2016-10-28 15:06:01 --> Loader Class Initialized
INFO - 2016-10-28 15:06:01 --> Helper loaded: url_helper
INFO - 2016-10-28 15:06:01 --> Helper loaded: form_helper
INFO - 2016-10-28 15:06:01 --> Database Driver Class Initialized
INFO - 2016-10-28 15:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:06:01 --> Controller Class Initialized
INFO - 2016-10-28 15:06:01 --> Form Validation Class Initialized
INFO - 2016-10-28 15:06:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:06:01 --> Model Class Initialized
ERROR - 2016-10-28 15:06:01 --> Severity: Warning --> error_log() expects parameter 2 to be long, string given /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:06:01 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('<x<xz<z', '4', '<zx<x<')
INFO - 2016-10-28 15:06:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:06:41 --> Config Class Initialized
INFO - 2016-10-28 15:06:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:06:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:06:41 --> Utf8 Class Initialized
INFO - 2016-10-28 15:06:41 --> URI Class Initialized
DEBUG - 2016-10-28 15:06:41 --> No URI present. Default controller set.
INFO - 2016-10-28 15:06:41 --> Router Class Initialized
INFO - 2016-10-28 15:06:41 --> Output Class Initialized
INFO - 2016-10-28 15:06:41 --> Security Class Initialized
DEBUG - 2016-10-28 15:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:06:41 --> Input Class Initialized
INFO - 2016-10-28 15:06:41 --> Language Class Initialized
INFO - 2016-10-28 15:06:41 --> Loader Class Initialized
INFO - 2016-10-28 15:06:41 --> Helper loaded: url_helper
INFO - 2016-10-28 15:06:41 --> Helper loaded: form_helper
INFO - 2016-10-28 15:06:41 --> Database Driver Class Initialized
INFO - 2016-10-28 15:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:06:41 --> Controller Class Initialized
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:06:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:06:41 --> Final output sent to browser
DEBUG - 2016-10-28 15:06:41 --> Total execution time: 0.0171
INFO - 2016-10-28 15:06:44 --> Config Class Initialized
INFO - 2016-10-28 15:06:44 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:06:44 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:06:44 --> Utf8 Class Initialized
INFO - 2016-10-28 15:06:44 --> URI Class Initialized
INFO - 2016-10-28 15:06:44 --> Router Class Initialized
INFO - 2016-10-28 15:06:44 --> Output Class Initialized
INFO - 2016-10-28 15:06:44 --> Security Class Initialized
DEBUG - 2016-10-28 15:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:06:44 --> Input Class Initialized
INFO - 2016-10-28 15:06:44 --> Language Class Initialized
INFO - 2016-10-28 15:06:44 --> Loader Class Initialized
INFO - 2016-10-28 15:06:44 --> Helper loaded: url_helper
INFO - 2016-10-28 15:06:44 --> Helper loaded: form_helper
INFO - 2016-10-28 15:06:44 --> Database Driver Class Initialized
INFO - 2016-10-28 15:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:06:44 --> Controller Class Initialized
INFO - 2016-10-28 15:06:44 --> Form Validation Class Initialized
INFO - 2016-10-28 15:06:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:06:44 --> Final output sent to browser
DEBUG - 2016-10-28 15:06:44 --> Total execution time: 0.0169
INFO - 2016-10-28 15:06:48 --> Config Class Initialized
INFO - 2016-10-28 15:06:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:06:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:06:48 --> Utf8 Class Initialized
INFO - 2016-10-28 15:06:48 --> URI Class Initialized
INFO - 2016-10-28 15:06:48 --> Router Class Initialized
INFO - 2016-10-28 15:06:48 --> Output Class Initialized
INFO - 2016-10-28 15:06:48 --> Security Class Initialized
DEBUG - 2016-10-28 15:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:06:48 --> Input Class Initialized
INFO - 2016-10-28 15:06:48 --> Language Class Initialized
INFO - 2016-10-28 15:06:48 --> Loader Class Initialized
INFO - 2016-10-28 15:06:48 --> Helper loaded: url_helper
INFO - 2016-10-28 15:06:48 --> Helper loaded: form_helper
INFO - 2016-10-28 15:06:48 --> Database Driver Class Initialized
INFO - 2016-10-28 15:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:06:48 --> Controller Class Initialized
INFO - 2016-10-28 15:06:48 --> Form Validation Class Initialized
INFO - 2016-10-28 15:06:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:06:48 --> Model Class Initialized
ERROR - 2016-10-28 15:06:48 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jk,j,', '3', '')
INFO - 2016-10-28 15:06:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:07:41 --> Config Class Initialized
INFO - 2016-10-28 15:07:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:07:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:07:41 --> Utf8 Class Initialized
INFO - 2016-10-28 15:07:41 --> URI Class Initialized
DEBUG - 2016-10-28 15:07:41 --> No URI present. Default controller set.
INFO - 2016-10-28 15:07:41 --> Router Class Initialized
INFO - 2016-10-28 15:07:41 --> Output Class Initialized
INFO - 2016-10-28 15:07:41 --> Security Class Initialized
DEBUG - 2016-10-28 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:07:41 --> Input Class Initialized
INFO - 2016-10-28 15:07:41 --> Language Class Initialized
INFO - 2016-10-28 15:07:41 --> Loader Class Initialized
INFO - 2016-10-28 15:07:41 --> Helper loaded: url_helper
INFO - 2016-10-28 15:07:41 --> Helper loaded: form_helper
INFO - 2016-10-28 15:07:41 --> Database Driver Class Initialized
INFO - 2016-10-28 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:07:41 --> Controller Class Initialized
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:07:41 --> Final output sent to browser
DEBUG - 2016-10-28 15:07:41 --> Total execution time: 0.0169
INFO - 2016-10-28 15:07:41 --> Config Class Initialized
INFO - 2016-10-28 15:07:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:07:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:07:41 --> Utf8 Class Initialized
INFO - 2016-10-28 15:07:41 --> URI Class Initialized
DEBUG - 2016-10-28 15:07:41 --> No URI present. Default controller set.
INFO - 2016-10-28 15:07:41 --> Router Class Initialized
INFO - 2016-10-28 15:07:41 --> Output Class Initialized
INFO - 2016-10-28 15:07:41 --> Security Class Initialized
DEBUG - 2016-10-28 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:07:41 --> Input Class Initialized
INFO - 2016-10-28 15:07:41 --> Language Class Initialized
INFO - 2016-10-28 15:07:41 --> Loader Class Initialized
INFO - 2016-10-28 15:07:41 --> Helper loaded: url_helper
INFO - 2016-10-28 15:07:41 --> Helper loaded: form_helper
INFO - 2016-10-28 15:07:41 --> Database Driver Class Initialized
INFO - 2016-10-28 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:07:41 --> Controller Class Initialized
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:07:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:07:41 --> Final output sent to browser
DEBUG - 2016-10-28 15:07:41 --> Total execution time: 0.0163
INFO - 2016-10-28 15:07:46 --> Config Class Initialized
INFO - 2016-10-28 15:07:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:07:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:07:46 --> Utf8 Class Initialized
INFO - 2016-10-28 15:07:46 --> URI Class Initialized
INFO - 2016-10-28 15:07:46 --> Router Class Initialized
INFO - 2016-10-28 15:07:46 --> Output Class Initialized
INFO - 2016-10-28 15:07:46 --> Security Class Initialized
DEBUG - 2016-10-28 15:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:07:46 --> Input Class Initialized
INFO - 2016-10-28 15:07:46 --> Language Class Initialized
ERROR - 2016-10-28 15:07:46 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
INFO - 2016-10-28 15:08:14 --> Config Class Initialized
INFO - 2016-10-28 15:08:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:08:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:08:14 --> Utf8 Class Initialized
INFO - 2016-10-28 15:08:14 --> URI Class Initialized
INFO - 2016-10-28 15:08:14 --> Router Class Initialized
INFO - 2016-10-28 15:08:14 --> Output Class Initialized
INFO - 2016-10-28 15:08:14 --> Security Class Initialized
DEBUG - 2016-10-28 15:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:08:14 --> Input Class Initialized
INFO - 2016-10-28 15:08:14 --> Language Class Initialized
INFO - 2016-10-28 15:08:14 --> Loader Class Initialized
INFO - 2016-10-28 15:08:14 --> Helper loaded: url_helper
INFO - 2016-10-28 15:08:14 --> Helper loaded: form_helper
INFO - 2016-10-28 15:08:14 --> Database Driver Class Initialized
INFO - 2016-10-28 15:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:08:14 --> Controller Class Initialized
INFO - 2016-10-28 15:08:14 --> Form Validation Class Initialized
INFO - 2016-10-28 15:08:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:08:14 --> Model Class Initialized
ERROR - 2016-10-28 15:08:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:08:14 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:08:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:08:31 --> Config Class Initialized
INFO - 2016-10-28 15:08:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:08:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:08:31 --> Utf8 Class Initialized
INFO - 2016-10-28 15:08:31 --> URI Class Initialized
INFO - 2016-10-28 15:08:31 --> Router Class Initialized
INFO - 2016-10-28 15:08:31 --> Output Class Initialized
INFO - 2016-10-28 15:08:31 --> Security Class Initialized
DEBUG - 2016-10-28 15:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:08:31 --> Input Class Initialized
INFO - 2016-10-28 15:08:31 --> Language Class Initialized
INFO - 2016-10-28 15:08:31 --> Loader Class Initialized
INFO - 2016-10-28 15:08:31 --> Helper loaded: url_helper
INFO - 2016-10-28 15:08:31 --> Helper loaded: form_helper
INFO - 2016-10-28 15:08:31 --> Database Driver Class Initialized
INFO - 2016-10-28 15:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:08:31 --> Controller Class Initialized
INFO - 2016-10-28 15:08:31 --> Form Validation Class Initialized
INFO - 2016-10-28 15:08:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:08:31 --> Model Class Initialized
ERROR - 2016-10-28 15:08:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:08:31 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:08:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:08:31 --> Config Class Initialized
INFO - 2016-10-28 15:08:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:08:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:08:31 --> Utf8 Class Initialized
INFO - 2016-10-28 15:08:31 --> URI Class Initialized
INFO - 2016-10-28 15:08:31 --> Router Class Initialized
INFO - 2016-10-28 15:08:31 --> Output Class Initialized
INFO - 2016-10-28 15:08:31 --> Security Class Initialized
DEBUG - 2016-10-28 15:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:08:31 --> Input Class Initialized
INFO - 2016-10-28 15:08:31 --> Language Class Initialized
INFO - 2016-10-28 15:08:31 --> Loader Class Initialized
INFO - 2016-10-28 15:08:31 --> Helper loaded: url_helper
INFO - 2016-10-28 15:08:31 --> Helper loaded: form_helper
INFO - 2016-10-28 15:08:31 --> Database Driver Class Initialized
INFO - 2016-10-28 15:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:08:31 --> Controller Class Initialized
INFO - 2016-10-28 15:08:31 --> Form Validation Class Initialized
INFO - 2016-10-28 15:08:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:08:31 --> Model Class Initialized
ERROR - 2016-10-28 15:08:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:08:31 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:08:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:08:31 --> Config Class Initialized
INFO - 2016-10-28 15:08:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:08:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:08:31 --> Utf8 Class Initialized
INFO - 2016-10-28 15:08:31 --> URI Class Initialized
INFO - 2016-10-28 15:08:31 --> Router Class Initialized
INFO - 2016-10-28 15:08:31 --> Output Class Initialized
INFO - 2016-10-28 15:08:31 --> Security Class Initialized
DEBUG - 2016-10-28 15:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:08:31 --> Input Class Initialized
INFO - 2016-10-28 15:08:31 --> Language Class Initialized
INFO - 2016-10-28 15:08:31 --> Loader Class Initialized
INFO - 2016-10-28 15:08:31 --> Helper loaded: url_helper
INFO - 2016-10-28 15:08:31 --> Helper loaded: form_helper
INFO - 2016-10-28 15:08:31 --> Database Driver Class Initialized
INFO - 2016-10-28 15:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:08:31 --> Controller Class Initialized
INFO - 2016-10-28 15:08:31 --> Form Validation Class Initialized
INFO - 2016-10-28 15:08:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:08:31 --> Model Class Initialized
ERROR - 2016-10-28 15:08:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 50
ERROR - 2016-10-28 15:08:31 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:08:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:09:14 --> Config Class Initialized
INFO - 2016-10-28 15:09:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:09:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:09:14 --> Utf8 Class Initialized
INFO - 2016-10-28 15:09:14 --> URI Class Initialized
INFO - 2016-10-28 15:09:14 --> Router Class Initialized
INFO - 2016-10-28 15:09:14 --> Output Class Initialized
INFO - 2016-10-28 15:09:14 --> Security Class Initialized
DEBUG - 2016-10-28 15:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:09:14 --> Input Class Initialized
INFO - 2016-10-28 15:09:14 --> Language Class Initialized
INFO - 2016-10-28 15:09:14 --> Loader Class Initialized
INFO - 2016-10-28 15:09:14 --> Helper loaded: url_helper
INFO - 2016-10-28 15:09:14 --> Helper loaded: form_helper
INFO - 2016-10-28 15:09:14 --> Database Driver Class Initialized
INFO - 2016-10-28 15:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:09:14 --> Controller Class Initialized
INFO - 2016-10-28 15:09:14 --> Form Validation Class Initialized
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:09:14 --> Model Class Initialized
ERROR - 2016-10-28 15:09:14 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:09:14 --> Config Class Initialized
INFO - 2016-10-28 15:09:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:09:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:09:14 --> Utf8 Class Initialized
INFO - 2016-10-28 15:09:14 --> URI Class Initialized
INFO - 2016-10-28 15:09:14 --> Router Class Initialized
INFO - 2016-10-28 15:09:14 --> Output Class Initialized
INFO - 2016-10-28 15:09:14 --> Security Class Initialized
DEBUG - 2016-10-28 15:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:09:14 --> Input Class Initialized
INFO - 2016-10-28 15:09:14 --> Language Class Initialized
INFO - 2016-10-28 15:09:14 --> Loader Class Initialized
INFO - 2016-10-28 15:09:14 --> Helper loaded: url_helper
INFO - 2016-10-28 15:09:14 --> Helper loaded: form_helper
INFO - 2016-10-28 15:09:14 --> Database Driver Class Initialized
INFO - 2016-10-28 15:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:09:14 --> Controller Class Initialized
INFO - 2016-10-28 15:09:14 --> Form Validation Class Initialized
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:09:14 --> Model Class Initialized
ERROR - 2016-10-28 15:09:14 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:09:14 --> Config Class Initialized
INFO - 2016-10-28 15:09:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:09:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:09:14 --> Utf8 Class Initialized
INFO - 2016-10-28 15:09:14 --> URI Class Initialized
INFO - 2016-10-28 15:09:14 --> Router Class Initialized
INFO - 2016-10-28 15:09:14 --> Output Class Initialized
INFO - 2016-10-28 15:09:14 --> Security Class Initialized
DEBUG - 2016-10-28 15:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:09:14 --> Input Class Initialized
INFO - 2016-10-28 15:09:14 --> Language Class Initialized
INFO - 2016-10-28 15:09:14 --> Loader Class Initialized
INFO - 2016-10-28 15:09:14 --> Helper loaded: url_helper
INFO - 2016-10-28 15:09:14 --> Helper loaded: form_helper
INFO - 2016-10-28 15:09:14 --> Database Driver Class Initialized
INFO - 2016-10-28 15:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:09:14 --> Controller Class Initialized
INFO - 2016-10-28 15:09:14 --> Form Validation Class Initialized
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:09:14 --> Model Class Initialized
ERROR - 2016-10-28 15:09:14 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:09:14 --> Config Class Initialized
INFO - 2016-10-28 15:09:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:09:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:09:14 --> Utf8 Class Initialized
INFO - 2016-10-28 15:09:14 --> URI Class Initialized
INFO - 2016-10-28 15:09:14 --> Router Class Initialized
INFO - 2016-10-28 15:09:14 --> Output Class Initialized
INFO - 2016-10-28 15:09:14 --> Security Class Initialized
DEBUG - 2016-10-28 15:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:09:14 --> Input Class Initialized
INFO - 2016-10-28 15:09:14 --> Language Class Initialized
INFO - 2016-10-28 15:09:14 --> Loader Class Initialized
INFO - 2016-10-28 15:09:14 --> Helper loaded: url_helper
INFO - 2016-10-28 15:09:14 --> Helper loaded: form_helper
INFO - 2016-10-28 15:09:14 --> Database Driver Class Initialized
INFO - 2016-10-28 15:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:09:14 --> Controller Class Initialized
INFO - 2016-10-28 15:09:14 --> Form Validation Class Initialized
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:09:14 --> Model Class Initialized
ERROR - 2016-10-28 15:09:14 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:09:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:10:22 --> Config Class Initialized
INFO - 2016-10-28 15:10:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:10:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:10:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:10:22 --> URI Class Initialized
INFO - 2016-10-28 15:10:22 --> Router Class Initialized
INFO - 2016-10-28 15:10:22 --> Output Class Initialized
INFO - 2016-10-28 15:10:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:10:22 --> Input Class Initialized
INFO - 2016-10-28 15:10:22 --> Language Class Initialized
INFO - 2016-10-28 15:10:22 --> Loader Class Initialized
INFO - 2016-10-28 15:10:22 --> Helper loaded: url_helper
INFO - 2016-10-28 15:10:22 --> Helper loaded: form_helper
INFO - 2016-10-28 15:10:22 --> Database Driver Class Initialized
INFO - 2016-10-28 15:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:10:22 --> Controller Class Initialized
INFO - 2016-10-28 15:10:22 --> Form Validation Class Initialized
INFO - 2016-10-28 15:10:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:10:22 --> Model Class Initialized
ERROR - 2016-10-28 15:10:22 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:10:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:10:22 --> Config Class Initialized
INFO - 2016-10-28 15:10:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:10:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:10:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:10:22 --> URI Class Initialized
INFO - 2016-10-28 15:10:22 --> Router Class Initialized
INFO - 2016-10-28 15:10:22 --> Output Class Initialized
INFO - 2016-10-28 15:10:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:10:22 --> Input Class Initialized
INFO - 2016-10-28 15:10:22 --> Language Class Initialized
INFO - 2016-10-28 15:10:22 --> Loader Class Initialized
INFO - 2016-10-28 15:10:22 --> Helper loaded: url_helper
INFO - 2016-10-28 15:10:22 --> Helper loaded: form_helper
INFO - 2016-10-28 15:10:22 --> Database Driver Class Initialized
INFO - 2016-10-28 15:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:10:22 --> Controller Class Initialized
INFO - 2016-10-28 15:10:22 --> Form Validation Class Initialized
INFO - 2016-10-28 15:10:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:10:22 --> Model Class Initialized
ERROR - 2016-10-28 15:10:22 --> Query error: Unknown column '$leave_name' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leave_name`, `$numberOfLeaves`, `$description`) VALUES ('jkljl', '1', 'jklkjl')
INFO - 2016-10-28 15:10:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:12:26 --> Config Class Initialized
INFO - 2016-10-28 15:12:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:26 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:26 --> URI Class Initialized
DEBUG - 2016-10-28 15:12:26 --> No URI present. Default controller set.
INFO - 2016-10-28 15:12:26 --> Router Class Initialized
INFO - 2016-10-28 15:12:26 --> Output Class Initialized
INFO - 2016-10-28 15:12:26 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:26 --> Input Class Initialized
INFO - 2016-10-28 15:12:26 --> Language Class Initialized
INFO - 2016-10-28 15:12:26 --> Loader Class Initialized
INFO - 2016-10-28 15:12:26 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:26 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:26 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:26 --> Controller Class Initialized
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:12:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:12:26 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:26 --> Total execution time: 0.0184
INFO - 2016-10-28 15:12:29 --> Config Class Initialized
INFO - 2016-10-28 15:12:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:29 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:29 --> URI Class Initialized
INFO - 2016-10-28 15:12:29 --> Router Class Initialized
INFO - 2016-10-28 15:12:29 --> Output Class Initialized
INFO - 2016-10-28 15:12:29 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:29 --> Input Class Initialized
INFO - 2016-10-28 15:12:29 --> Language Class Initialized
INFO - 2016-10-28 15:12:29 --> Loader Class Initialized
INFO - 2016-10-28 15:12:29 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:29 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:29 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:29 --> Controller Class Initialized
INFO - 2016-10-28 15:12:29 --> Form Validation Class Initialized
INFO - 2016-10-28 15:12:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:12:29 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:29 --> Total execution time: 0.0168
INFO - 2016-10-28 15:12:40 --> Config Class Initialized
INFO - 2016-10-28 15:12:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:40 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:40 --> URI Class Initialized
DEBUG - 2016-10-28 15:12:40 --> No URI present. Default controller set.
INFO - 2016-10-28 15:12:40 --> Router Class Initialized
INFO - 2016-10-28 15:12:40 --> Output Class Initialized
INFO - 2016-10-28 15:12:40 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:40 --> Input Class Initialized
INFO - 2016-10-28 15:12:40 --> Language Class Initialized
INFO - 2016-10-28 15:12:40 --> Loader Class Initialized
INFO - 2016-10-28 15:12:40 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:40 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:40 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:40 --> Controller Class Initialized
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:12:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:12:40 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:40 --> Total execution time: 0.0171
INFO - 2016-10-28 15:12:41 --> Config Class Initialized
INFO - 2016-10-28 15:12:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:41 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:41 --> URI Class Initialized
DEBUG - 2016-10-28 15:12:41 --> No URI present. Default controller set.
INFO - 2016-10-28 15:12:41 --> Router Class Initialized
INFO - 2016-10-28 15:12:41 --> Output Class Initialized
INFO - 2016-10-28 15:12:41 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:41 --> Input Class Initialized
INFO - 2016-10-28 15:12:41 --> Language Class Initialized
INFO - 2016-10-28 15:12:41 --> Loader Class Initialized
INFO - 2016-10-28 15:12:41 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:41 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:41 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:41 --> Controller Class Initialized
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:12:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:12:41 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:41 --> Total execution time: 0.0172
INFO - 2016-10-28 15:12:43 --> Config Class Initialized
INFO - 2016-10-28 15:12:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:43 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:43 --> URI Class Initialized
INFO - 2016-10-28 15:12:43 --> Router Class Initialized
INFO - 2016-10-28 15:12:43 --> Output Class Initialized
INFO - 2016-10-28 15:12:43 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:43 --> Input Class Initialized
INFO - 2016-10-28 15:12:43 --> Language Class Initialized
INFO - 2016-10-28 15:12:43 --> Loader Class Initialized
INFO - 2016-10-28 15:12:43 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:43 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:43 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:43 --> Controller Class Initialized
INFO - 2016-10-28 15:12:43 --> Form Validation Class Initialized
INFO - 2016-10-28 15:12:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:12:43 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:43 --> Total execution time: 0.0168
INFO - 2016-10-28 15:12:57 --> Config Class Initialized
INFO - 2016-10-28 15:12:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:57 --> URI Class Initialized
DEBUG - 2016-10-28 15:12:57 --> No URI present. Default controller set.
INFO - 2016-10-28 15:12:57 --> Router Class Initialized
INFO - 2016-10-28 15:12:57 --> Output Class Initialized
INFO - 2016-10-28 15:12:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:57 --> Input Class Initialized
INFO - 2016-10-28 15:12:57 --> Language Class Initialized
INFO - 2016-10-28 15:12:57 --> Loader Class Initialized
INFO - 2016-10-28 15:12:57 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:57 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:57 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:57 --> Controller Class Initialized
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:12:57 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:57 --> Total execution time: 0.0178
INFO - 2016-10-28 15:12:57 --> Config Class Initialized
INFO - 2016-10-28 15:12:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:57 --> URI Class Initialized
DEBUG - 2016-10-28 15:12:57 --> No URI present. Default controller set.
INFO - 2016-10-28 15:12:57 --> Router Class Initialized
INFO - 2016-10-28 15:12:57 --> Output Class Initialized
INFO - 2016-10-28 15:12:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:57 --> Input Class Initialized
INFO - 2016-10-28 15:12:57 --> Language Class Initialized
INFO - 2016-10-28 15:12:57 --> Loader Class Initialized
INFO - 2016-10-28 15:12:57 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:57 --> Helper loaded: form_helper
INFO - 2016-10-28 15:12:57 --> Database Driver Class Initialized
INFO - 2016-10-28 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:12:57 --> Controller Class Initialized
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:12:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:12:57 --> Final output sent to browser
DEBUG - 2016-10-28 15:12:57 --> Total execution time: 0.0168
INFO - 2016-10-28 15:12:59 --> Config Class Initialized
INFO - 2016-10-28 15:12:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:12:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:12:59 --> Utf8 Class Initialized
INFO - 2016-10-28 15:12:59 --> URI Class Initialized
INFO - 2016-10-28 15:12:59 --> Router Class Initialized
INFO - 2016-10-28 15:12:59 --> Output Class Initialized
INFO - 2016-10-28 15:12:59 --> Security Class Initialized
DEBUG - 2016-10-28 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:12:59 --> Input Class Initialized
INFO - 2016-10-28 15:12:59 --> Language Class Initialized
INFO - 2016-10-28 15:12:59 --> Loader Class Initialized
INFO - 2016-10-28 15:12:59 --> Helper loaded: url_helper
INFO - 2016-10-28 15:12:59 --> Helper loaded: form_helper
INFO - 2016-10-28 15:13:00 --> Database Driver Class Initialized
INFO - 2016-10-28 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:13:00 --> Controller Class Initialized
INFO - 2016-10-28 15:13:00 --> Form Validation Class Initialized
INFO - 2016-10-28 15:13:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:13:00 --> Final output sent to browser
DEBUG - 2016-10-28 15:13:00 --> Total execution time: 0.0181
INFO - 2016-10-28 15:13:07 --> Config Class Initialized
INFO - 2016-10-28 15:13:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:13:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:13:07 --> Utf8 Class Initialized
INFO - 2016-10-28 15:13:07 --> URI Class Initialized
INFO - 2016-10-28 15:13:07 --> Router Class Initialized
INFO - 2016-10-28 15:13:07 --> Output Class Initialized
INFO - 2016-10-28 15:13:07 --> Security Class Initialized
DEBUG - 2016-10-28 15:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:13:07 --> Input Class Initialized
INFO - 2016-10-28 15:13:07 --> Language Class Initialized
INFO - 2016-10-28 15:13:07 --> Loader Class Initialized
INFO - 2016-10-28 15:13:07 --> Helper loaded: url_helper
INFO - 2016-10-28 15:13:07 --> Helper loaded: form_helper
INFO - 2016-10-28 15:13:07 --> Database Driver Class Initialized
INFO - 2016-10-28 15:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:13:07 --> Controller Class Initialized
INFO - 2016-10-28 15:13:07 --> Form Validation Class Initialized
INFO - 2016-10-28 15:13:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:13:07 --> Model Class Initialized
ERROR - 2016-10-28 15:13:07 --> Query error: Unknown column '$leavename' in 'field list' - Invalid query: INSERT INTO `leaveType` (`$leavename`, `$numberOfLeaves`, `$description`) VALUES ('nhhgn', '2', 'fgnfn')
INFO - 2016-10-28 15:13:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-28 15:13:50 --> Config Class Initialized
INFO - 2016-10-28 15:13:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:13:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:13:50 --> Utf8 Class Initialized
INFO - 2016-10-28 15:13:50 --> URI Class Initialized
DEBUG - 2016-10-28 15:13:50 --> No URI present. Default controller set.
INFO - 2016-10-28 15:13:50 --> Router Class Initialized
INFO - 2016-10-28 15:13:50 --> Output Class Initialized
INFO - 2016-10-28 15:13:50 --> Security Class Initialized
DEBUG - 2016-10-28 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:13:50 --> Input Class Initialized
INFO - 2016-10-28 15:13:50 --> Language Class Initialized
INFO - 2016-10-28 15:13:50 --> Loader Class Initialized
INFO - 2016-10-28 15:13:50 --> Helper loaded: url_helper
INFO - 2016-10-28 15:13:50 --> Helper loaded: form_helper
INFO - 2016-10-28 15:13:50 --> Database Driver Class Initialized
INFO - 2016-10-28 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:13:50 --> Controller Class Initialized
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:13:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:13:50 --> Final output sent to browser
DEBUG - 2016-10-28 15:13:50 --> Total execution time: 0.0173
INFO - 2016-10-28 15:13:59 --> Config Class Initialized
INFO - 2016-10-28 15:13:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:13:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:13:59 --> Utf8 Class Initialized
INFO - 2016-10-28 15:13:59 --> URI Class Initialized
INFO - 2016-10-28 15:13:59 --> Router Class Initialized
INFO - 2016-10-28 15:13:59 --> Output Class Initialized
INFO - 2016-10-28 15:13:59 --> Security Class Initialized
DEBUG - 2016-10-28 15:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:13:59 --> Input Class Initialized
INFO - 2016-10-28 15:13:59 --> Language Class Initialized
INFO - 2016-10-28 15:13:59 --> Loader Class Initialized
INFO - 2016-10-28 15:13:59 --> Helper loaded: url_helper
INFO - 2016-10-28 15:13:59 --> Helper loaded: form_helper
INFO - 2016-10-28 15:13:59 --> Database Driver Class Initialized
INFO - 2016-10-28 15:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:13:59 --> Controller Class Initialized
INFO - 2016-10-28 15:13:59 --> Form Validation Class Initialized
INFO - 2016-10-28 15:13:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:13:59 --> Final output sent to browser
DEBUG - 2016-10-28 15:13:59 --> Total execution time: 0.0173
INFO - 2016-10-28 15:20:07 --> Config Class Initialized
INFO - 2016-10-28 15:20:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:20:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:20:07 --> Utf8 Class Initialized
INFO - 2016-10-28 15:20:07 --> URI Class Initialized
DEBUG - 2016-10-28 15:20:07 --> No URI present. Default controller set.
INFO - 2016-10-28 15:20:07 --> Router Class Initialized
INFO - 2016-10-28 15:20:07 --> Output Class Initialized
INFO - 2016-10-28 15:20:07 --> Security Class Initialized
DEBUG - 2016-10-28 15:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:20:07 --> Input Class Initialized
INFO - 2016-10-28 15:20:07 --> Language Class Initialized
INFO - 2016-10-28 15:20:07 --> Loader Class Initialized
INFO - 2016-10-28 15:20:07 --> Helper loaded: url_helper
INFO - 2016-10-28 15:20:07 --> Helper loaded: form_helper
INFO - 2016-10-28 15:20:07 --> Database Driver Class Initialized
INFO - 2016-10-28 15:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:20:07 --> Controller Class Initialized
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:20:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:20:07 --> Final output sent to browser
DEBUG - 2016-10-28 15:20:07 --> Total execution time: 0.0185
INFO - 2016-10-28 15:20:18 --> Config Class Initialized
INFO - 2016-10-28 15:20:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:20:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:20:18 --> Utf8 Class Initialized
INFO - 2016-10-28 15:20:18 --> URI Class Initialized
INFO - 2016-10-28 15:20:18 --> Router Class Initialized
INFO - 2016-10-28 15:20:18 --> Output Class Initialized
INFO - 2016-10-28 15:20:18 --> Security Class Initialized
DEBUG - 2016-10-28 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:20:18 --> Input Class Initialized
INFO - 2016-10-28 15:20:18 --> Language Class Initialized
INFO - 2016-10-28 15:20:18 --> Loader Class Initialized
INFO - 2016-10-28 15:20:18 --> Helper loaded: url_helper
INFO - 2016-10-28 15:20:18 --> Helper loaded: form_helper
INFO - 2016-10-28 15:20:18 --> Database Driver Class Initialized
INFO - 2016-10-28 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:20:18 --> Controller Class Initialized
INFO - 2016-10-28 15:20:18 --> Form Validation Class Initialized
INFO - 2016-10-28 15:20:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:20:18 --> Model Class Initialized
INFO - 2016-10-28 15:20:18 --> Final output sent to browser
DEBUG - 2016-10-28 15:20:18 --> Total execution time: 0.0187
INFO - 2016-10-28 15:21:42 --> Config Class Initialized
INFO - 2016-10-28 15:21:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:21:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:21:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:21:42 --> URI Class Initialized
DEBUG - 2016-10-28 15:21:42 --> No URI present. Default controller set.
INFO - 2016-10-28 15:21:42 --> Router Class Initialized
INFO - 2016-10-28 15:21:42 --> Output Class Initialized
INFO - 2016-10-28 15:21:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:21:42 --> Input Class Initialized
INFO - 2016-10-28 15:21:42 --> Language Class Initialized
INFO - 2016-10-28 15:21:42 --> Loader Class Initialized
INFO - 2016-10-28 15:21:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:21:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:21:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:21:42 --> Controller Class Initialized
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:21:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:21:42 --> Final output sent to browser
DEBUG - 2016-10-28 15:21:42 --> Total execution time: 0.0181
INFO - 2016-10-28 15:21:52 --> Config Class Initialized
INFO - 2016-10-28 15:21:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:21:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:21:52 --> Utf8 Class Initialized
INFO - 2016-10-28 15:21:52 --> URI Class Initialized
INFO - 2016-10-28 15:21:52 --> Router Class Initialized
INFO - 2016-10-28 15:21:52 --> Output Class Initialized
INFO - 2016-10-28 15:21:52 --> Security Class Initialized
DEBUG - 2016-10-28 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:21:52 --> Input Class Initialized
INFO - 2016-10-28 15:21:52 --> Language Class Initialized
INFO - 2016-10-28 15:21:52 --> Loader Class Initialized
INFO - 2016-10-28 15:21:52 --> Helper loaded: url_helper
INFO - 2016-10-28 15:21:52 --> Helper loaded: form_helper
INFO - 2016-10-28 15:21:52 --> Database Driver Class Initialized
INFO - 2016-10-28 15:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:21:52 --> Controller Class Initialized
INFO - 2016-10-28 15:21:52 --> Form Validation Class Initialized
INFO - 2016-10-28 15:21:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:21:52 --> Final output sent to browser
DEBUG - 2016-10-28 15:21:52 --> Total execution time: 0.0169
INFO - 2016-10-28 15:22:03 --> Config Class Initialized
INFO - 2016-10-28 15:22:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:22:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:22:03 --> Utf8 Class Initialized
INFO - 2016-10-28 15:22:03 --> URI Class Initialized
INFO - 2016-10-28 15:22:03 --> Router Class Initialized
INFO - 2016-10-28 15:22:03 --> Output Class Initialized
INFO - 2016-10-28 15:22:03 --> Security Class Initialized
DEBUG - 2016-10-28 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:22:03 --> Input Class Initialized
INFO - 2016-10-28 15:22:03 --> Language Class Initialized
INFO - 2016-10-28 15:22:03 --> Loader Class Initialized
INFO - 2016-10-28 15:22:03 --> Helper loaded: url_helper
INFO - 2016-10-28 15:22:03 --> Helper loaded: form_helper
INFO - 2016-10-28 15:22:03 --> Database Driver Class Initialized
INFO - 2016-10-28 15:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:22:03 --> Controller Class Initialized
INFO - 2016-10-28 15:22:03 --> Form Validation Class Initialized
INFO - 2016-10-28 15:22:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:22:03 --> Model Class Initialized
INFO - 2016-10-28 15:22:03 --> Final output sent to browser
DEBUG - 2016-10-28 15:22:03 --> Total execution time: 0.0186
INFO - 2016-10-28 15:34:48 --> Config Class Initialized
INFO - 2016-10-28 15:34:48 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:48 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:48 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:48 --> URI Class Initialized
DEBUG - 2016-10-28 15:34:48 --> No URI present. Default controller set.
INFO - 2016-10-28 15:34:48 --> Router Class Initialized
INFO - 2016-10-28 15:34:48 --> Output Class Initialized
INFO - 2016-10-28 15:34:48 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:48 --> Input Class Initialized
INFO - 2016-10-28 15:34:48 --> Language Class Initialized
INFO - 2016-10-28 15:34:48 --> Loader Class Initialized
INFO - 2016-10-28 15:34:48 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:48 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:48 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:48 --> Controller Class Initialized
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:34:48 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:34:48 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:48 --> Total execution time: 0.0176
INFO - 2016-10-28 15:34:51 --> Config Class Initialized
INFO - 2016-10-28 15:34:51 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:51 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:51 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:51 --> URI Class Initialized
INFO - 2016-10-28 15:34:51 --> Router Class Initialized
INFO - 2016-10-28 15:34:51 --> Output Class Initialized
INFO - 2016-10-28 15:34:51 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:51 --> Input Class Initialized
INFO - 2016-10-28 15:34:51 --> Language Class Initialized
INFO - 2016-10-28 15:34:51 --> Loader Class Initialized
INFO - 2016-10-28 15:34:51 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:51 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:51 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:51 --> Controller Class Initialized
ERROR - 2016-10-28 15:34:51 --> Severity: Notice --> Undefined variable: result /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 33
INFO - 2016-10-28 15:34:51 --> Form Validation Class Initialized
INFO - 2016-10-28 15:34:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:34:51 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:51 --> Total execution time: 0.0173
INFO - 2016-10-28 15:34:53 --> Config Class Initialized
INFO - 2016-10-28 15:34:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:53 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:53 --> URI Class Initialized
INFO - 2016-10-28 15:34:53 --> Router Class Initialized
INFO - 2016-10-28 15:34:53 --> Output Class Initialized
INFO - 2016-10-28 15:34:53 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:53 --> Input Class Initialized
INFO - 2016-10-28 15:34:53 --> Language Class Initialized
INFO - 2016-10-28 15:34:53 --> Loader Class Initialized
INFO - 2016-10-28 15:34:53 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:53 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:53 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:53 --> Controller Class Initialized
ERROR - 2016-10-28 15:34:53 --> Severity: Notice --> Undefined variable: result /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 33
INFO - 2016-10-28 15:34:53 --> Form Validation Class Initialized
INFO - 2016-10-28 15:34:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:34:53 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:53 --> Total execution time: 0.0172
INFO - 2016-10-28 15:34:53 --> Config Class Initialized
INFO - 2016-10-28 15:34:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:53 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:53 --> URI Class Initialized
INFO - 2016-10-28 15:34:53 --> Router Class Initialized
INFO - 2016-10-28 15:34:53 --> Output Class Initialized
INFO - 2016-10-28 15:34:53 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:53 --> Input Class Initialized
INFO - 2016-10-28 15:34:53 --> Language Class Initialized
INFO - 2016-10-28 15:34:53 --> Loader Class Initialized
INFO - 2016-10-28 15:34:53 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:53 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:53 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:53 --> Controller Class Initialized
ERROR - 2016-10-28 15:34:53 --> Severity: Notice --> Undefined variable: result /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 33
INFO - 2016-10-28 15:34:53 --> Form Validation Class Initialized
INFO - 2016-10-28 15:34:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:34:53 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:53 --> Total execution time: 0.0168
INFO - 2016-10-28 15:34:53 --> Config Class Initialized
INFO - 2016-10-28 15:34:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:53 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:53 --> URI Class Initialized
INFO - 2016-10-28 15:34:53 --> Router Class Initialized
INFO - 2016-10-28 15:34:53 --> Output Class Initialized
INFO - 2016-10-28 15:34:53 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:53 --> Input Class Initialized
INFO - 2016-10-28 15:34:53 --> Language Class Initialized
INFO - 2016-10-28 15:34:53 --> Loader Class Initialized
INFO - 2016-10-28 15:34:53 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:53 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:53 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:53 --> Controller Class Initialized
ERROR - 2016-10-28 15:34:53 --> Severity: Notice --> Undefined variable: result /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 33
INFO - 2016-10-28 15:34:53 --> Form Validation Class Initialized
INFO - 2016-10-28 15:34:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:34:53 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:53 --> Total execution time: 0.0166
INFO - 2016-10-28 15:34:53 --> Config Class Initialized
INFO - 2016-10-28 15:34:53 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:53 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:53 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:53 --> URI Class Initialized
INFO - 2016-10-28 15:34:53 --> Router Class Initialized
INFO - 2016-10-28 15:34:53 --> Output Class Initialized
INFO - 2016-10-28 15:34:53 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:53 --> Input Class Initialized
INFO - 2016-10-28 15:34:53 --> Language Class Initialized
INFO - 2016-10-28 15:34:53 --> Loader Class Initialized
INFO - 2016-10-28 15:34:53 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:53 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:53 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:53 --> Controller Class Initialized
ERROR - 2016-10-28 15:34:53 --> Severity: Notice --> Undefined variable: result /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 33
INFO - 2016-10-28 15:34:53 --> Form Validation Class Initialized
INFO - 2016-10-28 15:34:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:34:53 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:53 --> Total execution time: 0.0172
INFO - 2016-10-28 15:34:54 --> Config Class Initialized
INFO - 2016-10-28 15:34:54 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:34:54 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:34:54 --> Utf8 Class Initialized
INFO - 2016-10-28 15:34:54 --> URI Class Initialized
INFO - 2016-10-28 15:34:54 --> Router Class Initialized
INFO - 2016-10-28 15:34:54 --> Output Class Initialized
INFO - 2016-10-28 15:34:54 --> Security Class Initialized
DEBUG - 2016-10-28 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:34:54 --> Input Class Initialized
INFO - 2016-10-28 15:34:54 --> Language Class Initialized
INFO - 2016-10-28 15:34:54 --> Loader Class Initialized
INFO - 2016-10-28 15:34:54 --> Helper loaded: url_helper
INFO - 2016-10-28 15:34:54 --> Helper loaded: form_helper
INFO - 2016-10-28 15:34:54 --> Database Driver Class Initialized
INFO - 2016-10-28 15:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:34:54 --> Controller Class Initialized
ERROR - 2016-10-28 15:34:54 --> Severity: Notice --> Undefined variable: result /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 33
INFO - 2016-10-28 15:34:54 --> Form Validation Class Initialized
INFO - 2016-10-28 15:34:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:34:54 --> Final output sent to browser
DEBUG - 2016-10-28 15:34:54 --> Total execution time: 0.0173
INFO - 2016-10-28 15:35:35 --> Config Class Initialized
INFO - 2016-10-28 15:35:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:35:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:35:35 --> Utf8 Class Initialized
INFO - 2016-10-28 15:35:35 --> URI Class Initialized
DEBUG - 2016-10-28 15:35:35 --> No URI present. Default controller set.
INFO - 2016-10-28 15:35:35 --> Router Class Initialized
INFO - 2016-10-28 15:35:35 --> Output Class Initialized
INFO - 2016-10-28 15:35:35 --> Security Class Initialized
DEBUG - 2016-10-28 15:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:35:35 --> Input Class Initialized
INFO - 2016-10-28 15:35:35 --> Language Class Initialized
INFO - 2016-10-28 15:35:35 --> Loader Class Initialized
INFO - 2016-10-28 15:35:35 --> Helper loaded: url_helper
INFO - 2016-10-28 15:35:35 --> Helper loaded: form_helper
INFO - 2016-10-28 15:35:35 --> Database Driver Class Initialized
INFO - 2016-10-28 15:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:35:35 --> Controller Class Initialized
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:35:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:35:35 --> Final output sent to browser
DEBUG - 2016-10-28 15:35:35 --> Total execution time: 0.0194
INFO - 2016-10-28 15:35:37 --> Config Class Initialized
INFO - 2016-10-28 15:35:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:35:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:35:37 --> Utf8 Class Initialized
INFO - 2016-10-28 15:35:37 --> URI Class Initialized
INFO - 2016-10-28 15:35:37 --> Router Class Initialized
INFO - 2016-10-28 15:35:37 --> Output Class Initialized
INFO - 2016-10-28 15:35:37 --> Security Class Initialized
DEBUG - 2016-10-28 15:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:35:37 --> Input Class Initialized
INFO - 2016-10-28 15:35:37 --> Language Class Initialized
INFO - 2016-10-28 15:35:37 --> Loader Class Initialized
INFO - 2016-10-28 15:35:37 --> Helper loaded: url_helper
INFO - 2016-10-28 15:35:37 --> Helper loaded: form_helper
INFO - 2016-10-28 15:35:37 --> Database Driver Class Initialized
INFO - 2016-10-28 15:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:35:37 --> Controller Class Initialized
INFO - 2016-10-28 15:35:37 --> Form Validation Class Initialized
INFO - 2016-10-28 15:35:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:35:37 --> Final output sent to browser
DEBUG - 2016-10-28 15:35:37 --> Total execution time: 0.0181
INFO - 2016-10-28 15:44:28 --> Config Class Initialized
INFO - 2016-10-28 15:44:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:28 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:28 --> URI Class Initialized
DEBUG - 2016-10-28 15:44:28 --> No URI present. Default controller set.
INFO - 2016-10-28 15:44:28 --> Router Class Initialized
INFO - 2016-10-28 15:44:28 --> Output Class Initialized
INFO - 2016-10-28 15:44:28 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:28 --> Input Class Initialized
INFO - 2016-10-28 15:44:28 --> Language Class Initialized
INFO - 2016-10-28 15:44:28 --> Loader Class Initialized
INFO - 2016-10-28 15:44:28 --> Helper loaded: url_helper
INFO - 2016-10-28 15:44:28 --> Helper loaded: form_helper
INFO - 2016-10-28 15:44:28 --> Database Driver Class Initialized
INFO - 2016-10-28 15:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:44:28 --> Controller Class Initialized
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:44:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:44:28 --> Final output sent to browser
DEBUG - 2016-10-28 15:44:28 --> Total execution time: 0.0182
INFO - 2016-10-28 15:44:33 --> Config Class Initialized
INFO - 2016-10-28 15:44:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:33 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:33 --> URI Class Initialized
INFO - 2016-10-28 15:44:33 --> Router Class Initialized
INFO - 2016-10-28 15:44:33 --> Output Class Initialized
INFO - 2016-10-28 15:44:33 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:33 --> Input Class Initialized
INFO - 2016-10-28 15:44:33 --> Language Class Initialized
ERROR - 2016-10-28 15:44:33 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:33 --> Config Class Initialized
INFO - 2016-10-28 15:44:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:33 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:33 --> URI Class Initialized
INFO - 2016-10-28 15:44:33 --> Router Class Initialized
INFO - 2016-10-28 15:44:33 --> Output Class Initialized
INFO - 2016-10-28 15:44:33 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:33 --> Input Class Initialized
INFO - 2016-10-28 15:44:33 --> Language Class Initialized
ERROR - 2016-10-28 15:44:33 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:33 --> Config Class Initialized
INFO - 2016-10-28 15:44:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:33 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:33 --> URI Class Initialized
INFO - 2016-10-28 15:44:33 --> Router Class Initialized
INFO - 2016-10-28 15:44:33 --> Output Class Initialized
INFO - 2016-10-28 15:44:33 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:33 --> Input Class Initialized
INFO - 2016-10-28 15:44:33 --> Language Class Initialized
ERROR - 2016-10-28 15:44:33 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:34 --> Config Class Initialized
INFO - 2016-10-28 15:44:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:34 --> URI Class Initialized
INFO - 2016-10-28 15:44:34 --> Router Class Initialized
INFO - 2016-10-28 15:44:34 --> Output Class Initialized
INFO - 2016-10-28 15:44:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:34 --> Input Class Initialized
INFO - 2016-10-28 15:44:34 --> Language Class Initialized
ERROR - 2016-10-28 15:44:34 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:34 --> Config Class Initialized
INFO - 2016-10-28 15:44:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:34 --> URI Class Initialized
INFO - 2016-10-28 15:44:34 --> Router Class Initialized
INFO - 2016-10-28 15:44:34 --> Output Class Initialized
INFO - 2016-10-28 15:44:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:34 --> Input Class Initialized
INFO - 2016-10-28 15:44:34 --> Language Class Initialized
ERROR - 2016-10-28 15:44:34 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:39 --> Config Class Initialized
INFO - 2016-10-28 15:44:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:39 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:39 --> URI Class Initialized
DEBUG - 2016-10-28 15:44:39 --> No URI present. Default controller set.
INFO - 2016-10-28 15:44:39 --> Router Class Initialized
INFO - 2016-10-28 15:44:39 --> Output Class Initialized
INFO - 2016-10-28 15:44:39 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:39 --> Input Class Initialized
INFO - 2016-10-28 15:44:39 --> Language Class Initialized
INFO - 2016-10-28 15:44:39 --> Loader Class Initialized
INFO - 2016-10-28 15:44:39 --> Helper loaded: url_helper
INFO - 2016-10-28 15:44:39 --> Helper loaded: form_helper
INFO - 2016-10-28 15:44:39 --> Database Driver Class Initialized
INFO - 2016-10-28 15:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:44:39 --> Controller Class Initialized
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:44:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:44:39 --> Final output sent to browser
DEBUG - 2016-10-28 15:44:39 --> Total execution time: 0.0180
INFO - 2016-10-28 15:44:40 --> Config Class Initialized
INFO - 2016-10-28 15:44:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:40 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:40 --> URI Class Initialized
DEBUG - 2016-10-28 15:44:40 --> No URI present. Default controller set.
INFO - 2016-10-28 15:44:40 --> Router Class Initialized
INFO - 2016-10-28 15:44:40 --> Output Class Initialized
INFO - 2016-10-28 15:44:40 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:40 --> Input Class Initialized
INFO - 2016-10-28 15:44:40 --> Language Class Initialized
INFO - 2016-10-28 15:44:40 --> Loader Class Initialized
INFO - 2016-10-28 15:44:40 --> Helper loaded: url_helper
INFO - 2016-10-28 15:44:40 --> Helper loaded: form_helper
INFO - 2016-10-28 15:44:40 --> Database Driver Class Initialized
INFO - 2016-10-28 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:44:40 --> Controller Class Initialized
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:44:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:44:40 --> Final output sent to browser
DEBUG - 2016-10-28 15:44:40 --> Total execution time: 0.0164
INFO - 2016-10-28 15:44:42 --> Config Class Initialized
INFO - 2016-10-28 15:44:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:42 --> URI Class Initialized
INFO - 2016-10-28 15:44:42 --> Router Class Initialized
INFO - 2016-10-28 15:44:42 --> Output Class Initialized
INFO - 2016-10-28 15:44:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:42 --> Input Class Initialized
INFO - 2016-10-28 15:44:42 --> Language Class Initialized
ERROR - 2016-10-28 15:44:42 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:42 --> Config Class Initialized
INFO - 2016-10-28 15:44:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:42 --> URI Class Initialized
INFO - 2016-10-28 15:44:42 --> Router Class Initialized
INFO - 2016-10-28 15:44:42 --> Output Class Initialized
INFO - 2016-10-28 15:44:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:42 --> Input Class Initialized
INFO - 2016-10-28 15:44:42 --> Language Class Initialized
ERROR - 2016-10-28 15:44:42 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:44:42 --> Config Class Initialized
INFO - 2016-10-28 15:44:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:44:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:44:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:44:42 --> URI Class Initialized
INFO - 2016-10-28 15:44:42 --> Router Class Initialized
INFO - 2016-10-28 15:44:42 --> Output Class Initialized
INFO - 2016-10-28 15:44:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:44:42 --> Input Class Initialized
INFO - 2016-10-28 15:44:42 --> Language Class Initialized
ERROR - 2016-10-28 15:44:42 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:08 --> Config Class Initialized
INFO - 2016-10-28 15:45:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:08 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:08 --> URI Class Initialized
INFO - 2016-10-28 15:45:08 --> Router Class Initialized
INFO - 2016-10-28 15:45:08 --> Output Class Initialized
INFO - 2016-10-28 15:45:08 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:08 --> Input Class Initialized
INFO - 2016-10-28 15:45:08 --> Language Class Initialized
ERROR - 2016-10-28 15:45:08 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:09 --> Config Class Initialized
INFO - 2016-10-28 15:45:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:09 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:09 --> URI Class Initialized
INFO - 2016-10-28 15:45:09 --> Router Class Initialized
INFO - 2016-10-28 15:45:09 --> Output Class Initialized
INFO - 2016-10-28 15:45:09 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:09 --> Input Class Initialized
INFO - 2016-10-28 15:45:09 --> Language Class Initialized
ERROR - 2016-10-28 15:45:09 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:09 --> Config Class Initialized
INFO - 2016-10-28 15:45:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:09 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:09 --> URI Class Initialized
INFO - 2016-10-28 15:45:09 --> Router Class Initialized
INFO - 2016-10-28 15:45:09 --> Output Class Initialized
INFO - 2016-10-28 15:45:09 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:09 --> Input Class Initialized
INFO - 2016-10-28 15:45:09 --> Language Class Initialized
ERROR - 2016-10-28 15:45:09 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:09 --> Config Class Initialized
INFO - 2016-10-28 15:45:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:09 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:09 --> URI Class Initialized
INFO - 2016-10-28 15:45:09 --> Router Class Initialized
INFO - 2016-10-28 15:45:09 --> Output Class Initialized
INFO - 2016-10-28 15:45:09 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:09 --> Input Class Initialized
INFO - 2016-10-28 15:45:09 --> Language Class Initialized
ERROR - 2016-10-28 15:45:09 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:09 --> Config Class Initialized
INFO - 2016-10-28 15:45:09 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:09 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:09 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:09 --> URI Class Initialized
INFO - 2016-10-28 15:45:09 --> Router Class Initialized
INFO - 2016-10-28 15:45:09 --> Output Class Initialized
INFO - 2016-10-28 15:45:09 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:09 --> Input Class Initialized
INFO - 2016-10-28 15:45:09 --> Language Class Initialized
ERROR - 2016-10-28 15:45:09 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:37 --> Config Class Initialized
INFO - 2016-10-28 15:45:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:37 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:37 --> URI Class Initialized
DEBUG - 2016-10-28 15:45:37 --> No URI present. Default controller set.
INFO - 2016-10-28 15:45:37 --> Router Class Initialized
INFO - 2016-10-28 15:45:37 --> Output Class Initialized
INFO - 2016-10-28 15:45:37 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:37 --> Input Class Initialized
INFO - 2016-10-28 15:45:37 --> Language Class Initialized
INFO - 2016-10-28 15:45:37 --> Loader Class Initialized
INFO - 2016-10-28 15:45:37 --> Helper loaded: url_helper
INFO - 2016-10-28 15:45:37 --> Helper loaded: form_helper
INFO - 2016-10-28 15:45:37 --> Database Driver Class Initialized
INFO - 2016-10-28 15:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:45:37 --> Controller Class Initialized
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:45:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:45:37 --> Final output sent to browser
DEBUG - 2016-10-28 15:45:37 --> Total execution time: 0.0182
INFO - 2016-10-28 15:45:39 --> Config Class Initialized
INFO - 2016-10-28 15:45:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:39 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:39 --> URI Class Initialized
INFO - 2016-10-28 15:45:39 --> Router Class Initialized
INFO - 2016-10-28 15:45:39 --> Output Class Initialized
INFO - 2016-10-28 15:45:39 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:39 --> Input Class Initialized
INFO - 2016-10-28 15:45:39 --> Language Class Initialized
ERROR - 2016-10-28 15:45:39 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:39 --> Config Class Initialized
INFO - 2016-10-28 15:45:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:39 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:39 --> URI Class Initialized
INFO - 2016-10-28 15:45:39 --> Router Class Initialized
INFO - 2016-10-28 15:45:39 --> Output Class Initialized
INFO - 2016-10-28 15:45:39 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:39 --> Input Class Initialized
INFO - 2016-10-28 15:45:39 --> Language Class Initialized
ERROR - 2016-10-28 15:45:39 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:39 --> Config Class Initialized
INFO - 2016-10-28 15:45:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:39 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:39 --> URI Class Initialized
INFO - 2016-10-28 15:45:39 --> Router Class Initialized
INFO - 2016-10-28 15:45:39 --> Output Class Initialized
INFO - 2016-10-28 15:45:39 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:39 --> Input Class Initialized
INFO - 2016-10-28 15:45:39 --> Language Class Initialized
ERROR - 2016-10-28 15:45:39 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:45:40 --> Config Class Initialized
INFO - 2016-10-28 15:45:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:45:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:45:40 --> Utf8 Class Initialized
INFO - 2016-10-28 15:45:40 --> URI Class Initialized
INFO - 2016-10-28 15:45:40 --> Router Class Initialized
INFO - 2016-10-28 15:45:40 --> Output Class Initialized
INFO - 2016-10-28 15:45:40 --> Security Class Initialized
DEBUG - 2016-10-28 15:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:45:40 --> Input Class Initialized
INFO - 2016-10-28 15:45:40 --> Language Class Initialized
ERROR - 2016-10-28 15:45:40 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:46:18 --> Config Class Initialized
INFO - 2016-10-28 15:46:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:18 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:18 --> URI Class Initialized
DEBUG - 2016-10-28 15:46:18 --> No URI present. Default controller set.
INFO - 2016-10-28 15:46:18 --> Router Class Initialized
INFO - 2016-10-28 15:46:18 --> Output Class Initialized
INFO - 2016-10-28 15:46:18 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:18 --> Input Class Initialized
INFO - 2016-10-28 15:46:18 --> Language Class Initialized
INFO - 2016-10-28 15:46:18 --> Loader Class Initialized
INFO - 2016-10-28 15:46:18 --> Helper loaded: url_helper
INFO - 2016-10-28 15:46:18 --> Helper loaded: form_helper
INFO - 2016-10-28 15:46:18 --> Database Driver Class Initialized
INFO - 2016-10-28 15:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:46:18 --> Controller Class Initialized
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:46:18 --> Final output sent to browser
DEBUG - 2016-10-28 15:46:18 --> Total execution time: 0.0181
INFO - 2016-10-28 15:46:18 --> Config Class Initialized
INFO - 2016-10-28 15:46:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:18 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:18 --> URI Class Initialized
DEBUG - 2016-10-28 15:46:18 --> No URI present. Default controller set.
INFO - 2016-10-28 15:46:18 --> Router Class Initialized
INFO - 2016-10-28 15:46:18 --> Output Class Initialized
INFO - 2016-10-28 15:46:18 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:18 --> Input Class Initialized
INFO - 2016-10-28 15:46:18 --> Language Class Initialized
INFO - 2016-10-28 15:46:18 --> Loader Class Initialized
INFO - 2016-10-28 15:46:18 --> Helper loaded: url_helper
INFO - 2016-10-28 15:46:18 --> Helper loaded: form_helper
INFO - 2016-10-28 15:46:18 --> Database Driver Class Initialized
INFO - 2016-10-28 15:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:46:18 --> Controller Class Initialized
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:46:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:46:18 --> Final output sent to browser
DEBUG - 2016-10-28 15:46:18 --> Total execution time: 0.0171
INFO - 2016-10-28 15:46:21 --> Config Class Initialized
INFO - 2016-10-28 15:46:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:21 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:21 --> URI Class Initialized
INFO - 2016-10-28 15:46:21 --> Router Class Initialized
INFO - 2016-10-28 15:46:21 --> Output Class Initialized
INFO - 2016-10-28 15:46:21 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:21 --> Input Class Initialized
INFO - 2016-10-28 15:46:21 --> Language Class Initialized
ERROR - 2016-10-28 15:46:21 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:46:22 --> Config Class Initialized
INFO - 2016-10-28 15:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:22 --> URI Class Initialized
INFO - 2016-10-28 15:46:22 --> Router Class Initialized
INFO - 2016-10-28 15:46:22 --> Output Class Initialized
INFO - 2016-10-28 15:46:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:22 --> Input Class Initialized
INFO - 2016-10-28 15:46:22 --> Language Class Initialized
ERROR - 2016-10-28 15:46:22 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:46:22 --> Config Class Initialized
INFO - 2016-10-28 15:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:22 --> URI Class Initialized
INFO - 2016-10-28 15:46:22 --> Router Class Initialized
INFO - 2016-10-28 15:46:22 --> Output Class Initialized
INFO - 2016-10-28 15:46:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:22 --> Input Class Initialized
INFO - 2016-10-28 15:46:22 --> Language Class Initialized
ERROR - 2016-10-28 15:46:22 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:46:22 --> Config Class Initialized
INFO - 2016-10-28 15:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:22 --> URI Class Initialized
INFO - 2016-10-28 15:46:22 --> Router Class Initialized
INFO - 2016-10-28 15:46:22 --> Output Class Initialized
INFO - 2016-10-28 15:46:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:22 --> Input Class Initialized
INFO - 2016-10-28 15:46:22 --> Language Class Initialized
ERROR - 2016-10-28 15:46:22 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:46:22 --> Config Class Initialized
INFO - 2016-10-28 15:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:22 --> URI Class Initialized
INFO - 2016-10-28 15:46:22 --> Router Class Initialized
INFO - 2016-10-28 15:46:22 --> Output Class Initialized
INFO - 2016-10-28 15:46:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:22 --> Input Class Initialized
INFO - 2016-10-28 15:46:22 --> Language Class Initialized
ERROR - 2016-10-28 15:46:22 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:46:22 --> Config Class Initialized
INFO - 2016-10-28 15:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:46:22 --> Utf8 Class Initialized
INFO - 2016-10-28 15:46:22 --> URI Class Initialized
INFO - 2016-10-28 15:46:22 --> Router Class Initialized
INFO - 2016-10-28 15:46:22 --> Output Class Initialized
INFO - 2016-10-28 15:46:22 --> Security Class Initialized
DEBUG - 2016-10-28 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:46:22 --> Input Class Initialized
INFO - 2016-10-28 15:46:22 --> Language Class Initialized
ERROR - 2016-10-28 15:46:22 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 69
INFO - 2016-10-28 15:47:31 --> Config Class Initialized
INFO - 2016-10-28 15:47:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:31 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:31 --> URI Class Initialized
DEBUG - 2016-10-28 15:47:31 --> No URI present. Default controller set.
INFO - 2016-10-28 15:47:31 --> Router Class Initialized
INFO - 2016-10-28 15:47:31 --> Output Class Initialized
INFO - 2016-10-28 15:47:31 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:31 --> Input Class Initialized
INFO - 2016-10-28 15:47:31 --> Language Class Initialized
INFO - 2016-10-28 15:47:31 --> Loader Class Initialized
INFO - 2016-10-28 15:47:31 --> Helper loaded: url_helper
INFO - 2016-10-28 15:47:31 --> Helper loaded: form_helper
INFO - 2016-10-28 15:47:31 --> Database Driver Class Initialized
INFO - 2016-10-28 15:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:47:31 --> Controller Class Initialized
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:47:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:47:31 --> Final output sent to browser
DEBUG - 2016-10-28 15:47:31 --> Total execution time: 0.0180
INFO - 2016-10-28 15:47:32 --> Config Class Initialized
INFO - 2016-10-28 15:47:32 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:32 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:32 --> URI Class Initialized
DEBUG - 2016-10-28 15:47:32 --> No URI present. Default controller set.
INFO - 2016-10-28 15:47:32 --> Router Class Initialized
INFO - 2016-10-28 15:47:32 --> Output Class Initialized
INFO - 2016-10-28 15:47:32 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:32 --> Input Class Initialized
INFO - 2016-10-28 15:47:32 --> Language Class Initialized
INFO - 2016-10-28 15:47:32 --> Loader Class Initialized
INFO - 2016-10-28 15:47:32 --> Helper loaded: url_helper
INFO - 2016-10-28 15:47:32 --> Helper loaded: form_helper
INFO - 2016-10-28 15:47:32 --> Database Driver Class Initialized
INFO - 2016-10-28 15:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:47:32 --> Controller Class Initialized
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:47:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:47:32 --> Final output sent to browser
DEBUG - 2016-10-28 15:47:32 --> Total execution time: 0.0167
INFO - 2016-10-28 15:47:34 --> Config Class Initialized
INFO - 2016-10-28 15:47:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:34 --> URI Class Initialized
INFO - 2016-10-28 15:47:34 --> Router Class Initialized
INFO - 2016-10-28 15:47:34 --> Output Class Initialized
INFO - 2016-10-28 15:47:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:34 --> Input Class Initialized
INFO - 2016-10-28 15:47:34 --> Language Class Initialized
ERROR - 2016-10-28 15:47:34 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:34 --> Config Class Initialized
INFO - 2016-10-28 15:47:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:34 --> URI Class Initialized
INFO - 2016-10-28 15:47:34 --> Router Class Initialized
INFO - 2016-10-28 15:47:34 --> Output Class Initialized
INFO - 2016-10-28 15:47:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:34 --> Input Class Initialized
INFO - 2016-10-28 15:47:34 --> Language Class Initialized
ERROR - 2016-10-28 15:47:34 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:34 --> Config Class Initialized
INFO - 2016-10-28 15:47:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:34 --> URI Class Initialized
INFO - 2016-10-28 15:47:34 --> Router Class Initialized
INFO - 2016-10-28 15:47:34 --> Output Class Initialized
INFO - 2016-10-28 15:47:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:34 --> Input Class Initialized
INFO - 2016-10-28 15:47:34 --> Language Class Initialized
ERROR - 2016-10-28 15:47:34 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:34 --> Config Class Initialized
INFO - 2016-10-28 15:47:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:34 --> URI Class Initialized
INFO - 2016-10-28 15:47:34 --> Router Class Initialized
INFO - 2016-10-28 15:47:34 --> Output Class Initialized
INFO - 2016-10-28 15:47:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:34 --> Input Class Initialized
INFO - 2016-10-28 15:47:34 --> Language Class Initialized
ERROR - 2016-10-28 15:47:34 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:35 --> Config Class Initialized
INFO - 2016-10-28 15:47:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:35 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:35 --> URI Class Initialized
INFO - 2016-10-28 15:47:35 --> Router Class Initialized
INFO - 2016-10-28 15:47:35 --> Output Class Initialized
INFO - 2016-10-28 15:47:35 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:35 --> Input Class Initialized
INFO - 2016-10-28 15:47:35 --> Language Class Initialized
ERROR - 2016-10-28 15:47:35 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:42 --> Config Class Initialized
INFO - 2016-10-28 15:47:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:42 --> URI Class Initialized
DEBUG - 2016-10-28 15:47:42 --> No URI present. Default controller set.
INFO - 2016-10-28 15:47:42 --> Router Class Initialized
INFO - 2016-10-28 15:47:42 --> Output Class Initialized
INFO - 2016-10-28 15:47:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:42 --> Input Class Initialized
INFO - 2016-10-28 15:47:42 --> Language Class Initialized
INFO - 2016-10-28 15:47:42 --> Loader Class Initialized
INFO - 2016-10-28 15:47:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:47:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:47:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:47:42 --> Controller Class Initialized
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:47:42 --> Final output sent to browser
DEBUG - 2016-10-28 15:47:42 --> Total execution time: 0.0179
INFO - 2016-10-28 15:47:42 --> Config Class Initialized
INFO - 2016-10-28 15:47:42 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:42 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:42 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:42 --> URI Class Initialized
DEBUG - 2016-10-28 15:47:42 --> No URI present. Default controller set.
INFO - 2016-10-28 15:47:42 --> Router Class Initialized
INFO - 2016-10-28 15:47:42 --> Output Class Initialized
INFO - 2016-10-28 15:47:42 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:42 --> Input Class Initialized
INFO - 2016-10-28 15:47:42 --> Language Class Initialized
INFO - 2016-10-28 15:47:42 --> Loader Class Initialized
INFO - 2016-10-28 15:47:42 --> Helper loaded: url_helper
INFO - 2016-10-28 15:47:42 --> Helper loaded: form_helper
INFO - 2016-10-28 15:47:42 --> Database Driver Class Initialized
INFO - 2016-10-28 15:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:47:42 --> Controller Class Initialized
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:47:42 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:47:42 --> Final output sent to browser
DEBUG - 2016-10-28 15:47:42 --> Total execution time: 0.0183
INFO - 2016-10-28 15:47:45 --> Config Class Initialized
INFO - 2016-10-28 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:45 --> URI Class Initialized
INFO - 2016-10-28 15:47:45 --> Router Class Initialized
INFO - 2016-10-28 15:47:45 --> Output Class Initialized
INFO - 2016-10-28 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:45 --> Input Class Initialized
INFO - 2016-10-28 15:47:45 --> Language Class Initialized
ERROR - 2016-10-28 15:47:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:45 --> Config Class Initialized
INFO - 2016-10-28 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:45 --> URI Class Initialized
INFO - 2016-10-28 15:47:45 --> Router Class Initialized
INFO - 2016-10-28 15:47:45 --> Output Class Initialized
INFO - 2016-10-28 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:45 --> Input Class Initialized
INFO - 2016-10-28 15:47:45 --> Language Class Initialized
ERROR - 2016-10-28 15:47:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:45 --> Config Class Initialized
INFO - 2016-10-28 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:45 --> URI Class Initialized
INFO - 2016-10-28 15:47:45 --> Router Class Initialized
INFO - 2016-10-28 15:47:45 --> Output Class Initialized
INFO - 2016-10-28 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:45 --> Input Class Initialized
INFO - 2016-10-28 15:47:45 --> Language Class Initialized
ERROR - 2016-10-28 15:47:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:45 --> Config Class Initialized
INFO - 2016-10-28 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:45 --> URI Class Initialized
INFO - 2016-10-28 15:47:45 --> Router Class Initialized
INFO - 2016-10-28 15:47:45 --> Output Class Initialized
INFO - 2016-10-28 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:45 --> Input Class Initialized
INFO - 2016-10-28 15:47:45 --> Language Class Initialized
ERROR - 2016-10-28 15:47:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:45 --> Config Class Initialized
INFO - 2016-10-28 15:47:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:45 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:45 --> URI Class Initialized
INFO - 2016-10-28 15:47:45 --> Router Class Initialized
INFO - 2016-10-28 15:47:45 --> Output Class Initialized
INFO - 2016-10-28 15:47:45 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:45 --> Input Class Initialized
INFO - 2016-10-28 15:47:45 --> Language Class Initialized
ERROR - 2016-10-28 15:47:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:55 --> Config Class Initialized
INFO - 2016-10-28 15:47:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:55 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:55 --> URI Class Initialized
DEBUG - 2016-10-28 15:47:55 --> No URI present. Default controller set.
INFO - 2016-10-28 15:47:55 --> Router Class Initialized
INFO - 2016-10-28 15:47:55 --> Output Class Initialized
INFO - 2016-10-28 15:47:55 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:55 --> Input Class Initialized
INFO - 2016-10-28 15:47:55 --> Language Class Initialized
INFO - 2016-10-28 15:47:55 --> Loader Class Initialized
INFO - 2016-10-28 15:47:55 --> Helper loaded: url_helper
INFO - 2016-10-28 15:47:55 --> Helper loaded: form_helper
INFO - 2016-10-28 15:47:55 --> Database Driver Class Initialized
INFO - 2016-10-28 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:47:55 --> Controller Class Initialized
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:47:55 --> Final output sent to browser
DEBUG - 2016-10-28 15:47:55 --> Total execution time: 0.0169
INFO - 2016-10-28 15:47:55 --> Config Class Initialized
INFO - 2016-10-28 15:47:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:55 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:55 --> URI Class Initialized
DEBUG - 2016-10-28 15:47:55 --> No URI present. Default controller set.
INFO - 2016-10-28 15:47:55 --> Router Class Initialized
INFO - 2016-10-28 15:47:55 --> Output Class Initialized
INFO - 2016-10-28 15:47:55 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:55 --> Input Class Initialized
INFO - 2016-10-28 15:47:55 --> Language Class Initialized
INFO - 2016-10-28 15:47:55 --> Loader Class Initialized
INFO - 2016-10-28 15:47:55 --> Helper loaded: url_helper
INFO - 2016-10-28 15:47:55 --> Helper loaded: form_helper
INFO - 2016-10-28 15:47:55 --> Database Driver Class Initialized
INFO - 2016-10-28 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:47:55 --> Controller Class Initialized
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:47:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:47:55 --> Final output sent to browser
DEBUG - 2016-10-28 15:47:55 --> Total execution time: 0.0163
INFO - 2016-10-28 15:47:57 --> Config Class Initialized
INFO - 2016-10-28 15:47:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:57 --> URI Class Initialized
INFO - 2016-10-28 15:47:57 --> Router Class Initialized
INFO - 2016-10-28 15:47:57 --> Output Class Initialized
INFO - 2016-10-28 15:47:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:57 --> Input Class Initialized
INFO - 2016-10-28 15:47:57 --> Language Class Initialized
ERROR - 2016-10-28 15:47:57 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:57 --> Config Class Initialized
INFO - 2016-10-28 15:47:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:57 --> URI Class Initialized
INFO - 2016-10-28 15:47:57 --> Router Class Initialized
INFO - 2016-10-28 15:47:57 --> Output Class Initialized
INFO - 2016-10-28 15:47:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:57 --> Input Class Initialized
INFO - 2016-10-28 15:47:57 --> Language Class Initialized
ERROR - 2016-10-28 15:47:57 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:57 --> Config Class Initialized
INFO - 2016-10-28 15:47:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:57 --> URI Class Initialized
INFO - 2016-10-28 15:47:57 --> Router Class Initialized
INFO - 2016-10-28 15:47:57 --> Output Class Initialized
INFO - 2016-10-28 15:47:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:57 --> Input Class Initialized
INFO - 2016-10-28 15:47:57 --> Language Class Initialized
ERROR - 2016-10-28 15:47:57 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:57 --> Config Class Initialized
INFO - 2016-10-28 15:47:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:57 --> URI Class Initialized
INFO - 2016-10-28 15:47:57 --> Router Class Initialized
INFO - 2016-10-28 15:47:57 --> Output Class Initialized
INFO - 2016-10-28 15:47:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:57 --> Input Class Initialized
INFO - 2016-10-28 15:47:57 --> Language Class Initialized
ERROR - 2016-10-28 15:47:57 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:47:58 --> Config Class Initialized
INFO - 2016-10-28 15:47:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:47:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:47:58 --> Utf8 Class Initialized
INFO - 2016-10-28 15:47:58 --> URI Class Initialized
INFO - 2016-10-28 15:47:58 --> Router Class Initialized
INFO - 2016-10-28 15:47:58 --> Output Class Initialized
INFO - 2016-10-28 15:47:58 --> Security Class Initialized
DEBUG - 2016-10-28 15:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:47:58 --> Input Class Initialized
INFO - 2016-10-28 15:47:58 --> Language Class Initialized
ERROR - 2016-10-28 15:47:58 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ramotlonyane_modise/LMS/app/controllers/Leave_type_c.php 64
INFO - 2016-10-28 15:48:34 --> Config Class Initialized
INFO - 2016-10-28 15:48:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:48:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:48:34 --> Utf8 Class Initialized
INFO - 2016-10-28 15:48:34 --> URI Class Initialized
DEBUG - 2016-10-28 15:48:34 --> No URI present. Default controller set.
INFO - 2016-10-28 15:48:34 --> Router Class Initialized
INFO - 2016-10-28 15:48:34 --> Output Class Initialized
INFO - 2016-10-28 15:48:34 --> Security Class Initialized
DEBUG - 2016-10-28 15:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:48:34 --> Input Class Initialized
INFO - 2016-10-28 15:48:34 --> Language Class Initialized
INFO - 2016-10-28 15:48:34 --> Loader Class Initialized
INFO - 2016-10-28 15:48:34 --> Helper loaded: url_helper
INFO - 2016-10-28 15:48:34 --> Helper loaded: form_helper
INFO - 2016-10-28 15:48:34 --> Database Driver Class Initialized
INFO - 2016-10-28 15:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:48:34 --> Controller Class Initialized
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:48:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:48:34 --> Final output sent to browser
DEBUG - 2016-10-28 15:48:34 --> Total execution time: 0.0174
INFO - 2016-10-28 15:48:35 --> Config Class Initialized
INFO - 2016-10-28 15:48:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:48:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:48:35 --> Utf8 Class Initialized
INFO - 2016-10-28 15:48:35 --> URI Class Initialized
DEBUG - 2016-10-28 15:48:35 --> No URI present. Default controller set.
INFO - 2016-10-28 15:48:35 --> Router Class Initialized
INFO - 2016-10-28 15:48:35 --> Output Class Initialized
INFO - 2016-10-28 15:48:35 --> Security Class Initialized
DEBUG - 2016-10-28 15:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:48:35 --> Input Class Initialized
INFO - 2016-10-28 15:48:35 --> Language Class Initialized
INFO - 2016-10-28 15:48:35 --> Loader Class Initialized
INFO - 2016-10-28 15:48:35 --> Helper loaded: url_helper
INFO - 2016-10-28 15:48:35 --> Helper loaded: form_helper
INFO - 2016-10-28 15:48:35 --> Database Driver Class Initialized
INFO - 2016-10-28 15:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:48:35 --> Controller Class Initialized
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:48:35 --> Final output sent to browser
DEBUG - 2016-10-28 15:48:35 --> Total execution time: 0.0169
INFO - 2016-10-28 15:48:35 --> Config Class Initialized
INFO - 2016-10-28 15:48:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:48:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:48:35 --> Utf8 Class Initialized
INFO - 2016-10-28 15:48:35 --> URI Class Initialized
DEBUG - 2016-10-28 15:48:35 --> No URI present. Default controller set.
INFO - 2016-10-28 15:48:35 --> Router Class Initialized
INFO - 2016-10-28 15:48:35 --> Output Class Initialized
INFO - 2016-10-28 15:48:35 --> Security Class Initialized
DEBUG - 2016-10-28 15:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:48:35 --> Input Class Initialized
INFO - 2016-10-28 15:48:35 --> Language Class Initialized
INFO - 2016-10-28 15:48:35 --> Loader Class Initialized
INFO - 2016-10-28 15:48:35 --> Helper loaded: url_helper
INFO - 2016-10-28 15:48:35 --> Helper loaded: form_helper
INFO - 2016-10-28 15:48:35 --> Database Driver Class Initialized
INFO - 2016-10-28 15:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:48:35 --> Controller Class Initialized
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:48:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:48:35 --> Final output sent to browser
DEBUG - 2016-10-28 15:48:35 --> Total execution time: 0.0158
INFO - 2016-10-28 15:48:37 --> Config Class Initialized
INFO - 2016-10-28 15:48:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:48:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:48:37 --> Utf8 Class Initialized
INFO - 2016-10-28 15:48:37 --> URI Class Initialized
INFO - 2016-10-28 15:48:37 --> Router Class Initialized
INFO - 2016-10-28 15:48:37 --> Output Class Initialized
INFO - 2016-10-28 15:48:37 --> Security Class Initialized
DEBUG - 2016-10-28 15:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:48:37 --> Input Class Initialized
INFO - 2016-10-28 15:48:37 --> Language Class Initialized
INFO - 2016-10-28 15:48:37 --> Loader Class Initialized
INFO - 2016-10-28 15:48:37 --> Helper loaded: url_helper
INFO - 2016-10-28 15:48:37 --> Helper loaded: form_helper
INFO - 2016-10-28 15:48:37 --> Database Driver Class Initialized
INFO - 2016-10-28 15:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:48:37 --> Controller Class Initialized
INFO - 2016-10-28 15:48:37 --> Form Validation Class Initialized
INFO - 2016-10-28 15:48:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:48:37 --> Final output sent to browser
DEBUG - 2016-10-28 15:48:37 --> Total execution time: 0.0170
INFO - 2016-10-28 15:48:38 --> Config Class Initialized
INFO - 2016-10-28 15:48:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:48:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:48:38 --> Utf8 Class Initialized
INFO - 2016-10-28 15:48:38 --> URI Class Initialized
DEBUG - 2016-10-28 15:48:38 --> No URI present. Default controller set.
INFO - 2016-10-28 15:48:38 --> Router Class Initialized
INFO - 2016-10-28 15:48:38 --> Output Class Initialized
INFO - 2016-10-28 15:48:38 --> Security Class Initialized
DEBUG - 2016-10-28 15:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:48:38 --> Input Class Initialized
INFO - 2016-10-28 15:48:38 --> Language Class Initialized
INFO - 2016-10-28 15:48:38 --> Loader Class Initialized
INFO - 2016-10-28 15:48:38 --> Helper loaded: url_helper
INFO - 2016-10-28 15:48:38 --> Helper loaded: form_helper
INFO - 2016-10-28 15:48:38 --> Database Driver Class Initialized
INFO - 2016-10-28 15:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:48:38 --> Controller Class Initialized
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:48:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:48:38 --> Final output sent to browser
DEBUG - 2016-10-28 15:48:38 --> Total execution time: 0.0174
INFO - 2016-10-28 15:49:05 --> Config Class Initialized
INFO - 2016-10-28 15:49:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:49:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:49:05 --> Utf8 Class Initialized
INFO - 2016-10-28 15:49:05 --> URI Class Initialized
DEBUG - 2016-10-28 15:49:05 --> No URI present. Default controller set.
INFO - 2016-10-28 15:49:05 --> Router Class Initialized
INFO - 2016-10-28 15:49:05 --> Output Class Initialized
INFO - 2016-10-28 15:49:05 --> Security Class Initialized
DEBUG - 2016-10-28 15:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:49:05 --> Input Class Initialized
INFO - 2016-10-28 15:49:05 --> Language Class Initialized
INFO - 2016-10-28 15:49:05 --> Loader Class Initialized
INFO - 2016-10-28 15:49:05 --> Helper loaded: url_helper
INFO - 2016-10-28 15:49:05 --> Helper loaded: form_helper
INFO - 2016-10-28 15:49:05 --> Database Driver Class Initialized
INFO - 2016-10-28 15:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:49:05 --> Controller Class Initialized
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:49:05 --> Final output sent to browser
DEBUG - 2016-10-28 15:49:05 --> Total execution time: 0.0173
INFO - 2016-10-28 15:49:05 --> Config Class Initialized
INFO - 2016-10-28 15:49:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:49:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:49:05 --> Utf8 Class Initialized
INFO - 2016-10-28 15:49:05 --> URI Class Initialized
DEBUG - 2016-10-28 15:49:05 --> No URI present. Default controller set.
INFO - 2016-10-28 15:49:05 --> Router Class Initialized
INFO - 2016-10-28 15:49:05 --> Output Class Initialized
INFO - 2016-10-28 15:49:05 --> Security Class Initialized
DEBUG - 2016-10-28 15:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:49:05 --> Input Class Initialized
INFO - 2016-10-28 15:49:05 --> Language Class Initialized
INFO - 2016-10-28 15:49:05 --> Loader Class Initialized
INFO - 2016-10-28 15:49:05 --> Helper loaded: url_helper
INFO - 2016-10-28 15:49:05 --> Helper loaded: form_helper
INFO - 2016-10-28 15:49:05 --> Database Driver Class Initialized
INFO - 2016-10-28 15:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:49:05 --> Controller Class Initialized
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:49:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:49:05 --> Final output sent to browser
DEBUG - 2016-10-28 15:49:05 --> Total execution time: 0.0166
INFO - 2016-10-28 15:49:07 --> Config Class Initialized
INFO - 2016-10-28 15:49:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:49:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:49:07 --> Utf8 Class Initialized
INFO - 2016-10-28 15:49:07 --> URI Class Initialized
INFO - 2016-10-28 15:49:07 --> Router Class Initialized
INFO - 2016-10-28 15:49:07 --> Output Class Initialized
INFO - 2016-10-28 15:49:07 --> Security Class Initialized
DEBUG - 2016-10-28 15:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:49:07 --> Input Class Initialized
INFO - 2016-10-28 15:49:07 --> Language Class Initialized
INFO - 2016-10-28 15:49:07 --> Loader Class Initialized
INFO - 2016-10-28 15:49:07 --> Helper loaded: url_helper
INFO - 2016-10-28 15:49:07 --> Helper loaded: form_helper
INFO - 2016-10-28 15:49:07 --> Database Driver Class Initialized
INFO - 2016-10-28 15:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:49:07 --> Controller Class Initialized
INFO - 2016-10-28 15:49:07 --> Form Validation Class Initialized
INFO - 2016-10-28 15:49:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:49:07 --> Final output sent to browser
DEBUG - 2016-10-28 15:49:07 --> Total execution time: 0.0168
INFO - 2016-10-28 15:49:15 --> Config Class Initialized
INFO - 2016-10-28 15:49:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:49:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:49:15 --> Utf8 Class Initialized
INFO - 2016-10-28 15:49:15 --> URI Class Initialized
INFO - 2016-10-28 15:49:15 --> Router Class Initialized
INFO - 2016-10-28 15:49:15 --> Output Class Initialized
INFO - 2016-10-28 15:49:15 --> Security Class Initialized
DEBUG - 2016-10-28 15:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:49:15 --> Input Class Initialized
INFO - 2016-10-28 15:49:15 --> Language Class Initialized
INFO - 2016-10-28 15:49:15 --> Loader Class Initialized
INFO - 2016-10-28 15:49:15 --> Helper loaded: url_helper
INFO - 2016-10-28 15:49:15 --> Helper loaded: form_helper
INFO - 2016-10-28 15:49:15 --> Database Driver Class Initialized
INFO - 2016-10-28 15:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:49:15 --> Controller Class Initialized
INFO - 2016-10-28 15:49:15 --> Form Validation Class Initialized
INFO - 2016-10-28 15:49:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:49:15 --> Model Class Initialized
INFO - 2016-10-28 15:49:15 --> Final output sent to browser
DEBUG - 2016-10-28 15:49:15 --> Total execution time: 0.0192
INFO - 2016-10-28 15:50:01 --> Config Class Initialized
INFO - 2016-10-28 15:50:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:50:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:50:01 --> Utf8 Class Initialized
INFO - 2016-10-28 15:50:01 --> URI Class Initialized
DEBUG - 2016-10-28 15:50:01 --> No URI present. Default controller set.
INFO - 2016-10-28 15:50:01 --> Router Class Initialized
INFO - 2016-10-28 15:50:01 --> Output Class Initialized
INFO - 2016-10-28 15:50:01 --> Security Class Initialized
DEBUG - 2016-10-28 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:50:01 --> Input Class Initialized
INFO - 2016-10-28 15:50:01 --> Language Class Initialized
INFO - 2016-10-28 15:50:01 --> Loader Class Initialized
INFO - 2016-10-28 15:50:01 --> Helper loaded: url_helper
INFO - 2016-10-28 15:50:01 --> Helper loaded: form_helper
INFO - 2016-10-28 15:50:01 --> Database Driver Class Initialized
INFO - 2016-10-28 15:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:50:01 --> Controller Class Initialized
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:50:01 --> Final output sent to browser
DEBUG - 2016-10-28 15:50:01 --> Total execution time: 0.0171
INFO - 2016-10-28 15:50:30 --> Config Class Initialized
INFO - 2016-10-28 15:50:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:50:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:50:30 --> Utf8 Class Initialized
INFO - 2016-10-28 15:50:30 --> URI Class Initialized
INFO - 2016-10-28 15:50:30 --> Router Class Initialized
INFO - 2016-10-28 15:50:30 --> Output Class Initialized
INFO - 2016-10-28 15:50:30 --> Security Class Initialized
DEBUG - 2016-10-28 15:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:50:30 --> Input Class Initialized
INFO - 2016-10-28 15:50:30 --> Language Class Initialized
INFO - 2016-10-28 15:50:30 --> Loader Class Initialized
INFO - 2016-10-28 15:50:30 --> Helper loaded: url_helper
INFO - 2016-10-28 15:50:30 --> Helper loaded: form_helper
INFO - 2016-10-28 15:50:30 --> Database Driver Class Initialized
INFO - 2016-10-28 15:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:50:30 --> Controller Class Initialized
INFO - 2016-10-28 15:50:30 --> Form Validation Class Initialized
INFO - 2016-10-28 15:50:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:50:30 --> Model Class Initialized
INFO - 2016-10-28 15:50:30 --> Final output sent to browser
DEBUG - 2016-10-28 15:50:30 --> Total execution time: 0.0293
INFO - 2016-10-28 15:51:57 --> Config Class Initialized
INFO - 2016-10-28 15:51:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:51:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:51:57 --> Utf8 Class Initialized
INFO - 2016-10-28 15:51:57 --> URI Class Initialized
INFO - 2016-10-28 15:51:57 --> Router Class Initialized
INFO - 2016-10-28 15:51:57 --> Output Class Initialized
INFO - 2016-10-28 15:51:57 --> Security Class Initialized
DEBUG - 2016-10-28 15:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:51:57 --> Input Class Initialized
INFO - 2016-10-28 15:51:57 --> Language Class Initialized
INFO - 2016-10-28 15:51:57 --> Loader Class Initialized
INFO - 2016-10-28 15:51:57 --> Helper loaded: url_helper
INFO - 2016-10-28 15:51:57 --> Helper loaded: form_helper
INFO - 2016-10-28 15:51:57 --> Database Driver Class Initialized
INFO - 2016-10-28 15:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:51:57 --> Controller Class Initialized
INFO - 2016-10-28 15:51:57 --> Form Validation Class Initialized
INFO - 2016-10-28 15:51:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:51:57 --> Final output sent to browser
DEBUG - 2016-10-28 15:51:57 --> Total execution time: 0.0173
INFO - 2016-10-28 15:51:59 --> Config Class Initialized
INFO - 2016-10-28 15:51:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:51:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:51:59 --> Utf8 Class Initialized
INFO - 2016-10-28 15:51:59 --> URI Class Initialized
DEBUG - 2016-10-28 15:51:59 --> No URI present. Default controller set.
INFO - 2016-10-28 15:51:59 --> Router Class Initialized
INFO - 2016-10-28 15:51:59 --> Output Class Initialized
INFO - 2016-10-28 15:51:59 --> Security Class Initialized
DEBUG - 2016-10-28 15:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:51:59 --> Input Class Initialized
INFO - 2016-10-28 15:51:59 --> Language Class Initialized
INFO - 2016-10-28 15:51:59 --> Loader Class Initialized
INFO - 2016-10-28 15:51:59 --> Helper loaded: url_helper
INFO - 2016-10-28 15:51:59 --> Helper loaded: form_helper
INFO - 2016-10-28 15:51:59 --> Database Driver Class Initialized
INFO - 2016-10-28 15:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:51:59 --> Controller Class Initialized
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:51:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:51:59 --> Final output sent to browser
DEBUG - 2016-10-28 15:51:59 --> Total execution time: 0.0166
INFO - 2016-10-28 15:52:03 --> Config Class Initialized
INFO - 2016-10-28 15:52:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:52:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:52:03 --> Utf8 Class Initialized
INFO - 2016-10-28 15:52:03 --> URI Class Initialized
INFO - 2016-10-28 15:52:03 --> Router Class Initialized
INFO - 2016-10-28 15:52:03 --> Output Class Initialized
INFO - 2016-10-28 15:52:03 --> Security Class Initialized
DEBUG - 2016-10-28 15:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:52:03 --> Input Class Initialized
INFO - 2016-10-28 15:52:03 --> Language Class Initialized
INFO - 2016-10-28 15:52:03 --> Loader Class Initialized
INFO - 2016-10-28 15:52:03 --> Helper loaded: url_helper
INFO - 2016-10-28 15:52:03 --> Helper loaded: form_helper
INFO - 2016-10-28 15:52:03 --> Database Driver Class Initialized
INFO - 2016-10-28 15:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:52:03 --> Controller Class Initialized
INFO - 2016-10-28 15:52:03 --> Form Validation Class Initialized
INFO - 2016-10-28 15:52:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 15:52:03 --> Final output sent to browser
DEBUG - 2016-10-28 15:52:03 --> Total execution time: 0.0173
INFO - 2016-10-28 15:52:05 --> Config Class Initialized
INFO - 2016-10-28 15:52:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:52:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:52:05 --> Utf8 Class Initialized
INFO - 2016-10-28 15:52:05 --> URI Class Initialized
DEBUG - 2016-10-28 15:52:05 --> No URI present. Default controller set.
INFO - 2016-10-28 15:52:05 --> Router Class Initialized
INFO - 2016-10-28 15:52:05 --> Output Class Initialized
INFO - 2016-10-28 15:52:05 --> Security Class Initialized
DEBUG - 2016-10-28 15:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:52:05 --> Input Class Initialized
INFO - 2016-10-28 15:52:05 --> Language Class Initialized
INFO - 2016-10-28 15:52:05 --> Loader Class Initialized
INFO - 2016-10-28 15:52:05 --> Helper loaded: url_helper
INFO - 2016-10-28 15:52:05 --> Helper loaded: form_helper
INFO - 2016-10-28 15:52:05 --> Database Driver Class Initialized
INFO - 2016-10-28 15:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:52:05 --> Controller Class Initialized
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:52:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:52:05 --> Final output sent to browser
DEBUG - 2016-10-28 15:52:05 --> Total execution time: 0.0165
INFO - 2016-10-28 15:53:13 --> Config Class Initialized
INFO - 2016-10-28 15:53:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:53:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 15:53:13 --> Utf8 Class Initialized
INFO - 2016-10-28 15:53:13 --> URI Class Initialized
DEBUG - 2016-10-28 15:53:13 --> No URI present. Default controller set.
INFO - 2016-10-28 15:53:13 --> Router Class Initialized
INFO - 2016-10-28 15:53:13 --> Output Class Initialized
INFO - 2016-10-28 15:53:13 --> Security Class Initialized
DEBUG - 2016-10-28 15:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 15:53:13 --> Input Class Initialized
INFO - 2016-10-28 15:53:13 --> Language Class Initialized
INFO - 2016-10-28 15:53:13 --> Loader Class Initialized
INFO - 2016-10-28 15:53:13 --> Helper loaded: url_helper
INFO - 2016-10-28 15:53:13 --> Helper loaded: form_helper
INFO - 2016-10-28 15:53:13 --> Database Driver Class Initialized
INFO - 2016-10-28 15:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 15:53:13 --> Controller Class Initialized
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 15:53:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 15:53:13 --> Final output sent to browser
DEBUG - 2016-10-28 15:53:13 --> Total execution time: 0.0192
INFO - 2016-10-28 16:02:43 --> Config Class Initialized
INFO - 2016-10-28 16:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:02:43 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:02:43 --> Utf8 Class Initialized
INFO - 2016-10-28 16:02:43 --> URI Class Initialized
DEBUG - 2016-10-28 16:02:43 --> No URI present. Default controller set.
INFO - 2016-10-28 16:02:43 --> Router Class Initialized
INFO - 2016-10-28 16:02:43 --> Output Class Initialized
INFO - 2016-10-28 16:02:43 --> Security Class Initialized
DEBUG - 2016-10-28 16:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:02:43 --> Input Class Initialized
INFO - 2016-10-28 16:02:43 --> Language Class Initialized
INFO - 2016-10-28 16:02:43 --> Loader Class Initialized
INFO - 2016-10-28 16:02:43 --> Helper loaded: url_helper
INFO - 2016-10-28 16:02:43 --> Helper loaded: form_helper
INFO - 2016-10-28 16:02:43 --> Database Driver Class Initialized
INFO - 2016-10-28 16:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:02:43 --> Controller Class Initialized
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:02:43 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:02:43 --> Final output sent to browser
DEBUG - 2016-10-28 16:02:43 --> Total execution time: 0.0177
INFO - 2016-10-28 16:04:01 --> Config Class Initialized
INFO - 2016-10-28 16:04:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:04:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:04:01 --> Utf8 Class Initialized
INFO - 2016-10-28 16:04:01 --> URI Class Initialized
DEBUG - 2016-10-28 16:04:01 --> No URI present. Default controller set.
INFO - 2016-10-28 16:04:01 --> Router Class Initialized
INFO - 2016-10-28 16:04:01 --> Output Class Initialized
INFO - 2016-10-28 16:04:01 --> Security Class Initialized
DEBUG - 2016-10-28 16:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:04:01 --> Input Class Initialized
INFO - 2016-10-28 16:04:01 --> Language Class Initialized
INFO - 2016-10-28 16:04:01 --> Loader Class Initialized
INFO - 2016-10-28 16:04:01 --> Helper loaded: url_helper
INFO - 2016-10-28 16:04:01 --> Helper loaded: form_helper
INFO - 2016-10-28 16:04:01 --> Database Driver Class Initialized
INFO - 2016-10-28 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:04:01 --> Controller Class Initialized
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:04:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:04:01 --> Final output sent to browser
DEBUG - 2016-10-28 16:04:01 --> Total execution time: 0.0170
INFO - 2016-10-28 16:09:25 --> Config Class Initialized
INFO - 2016-10-28 16:09:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:09:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:09:25 --> Utf8 Class Initialized
INFO - 2016-10-28 16:09:25 --> URI Class Initialized
DEBUG - 2016-10-28 16:09:25 --> No URI present. Default controller set.
INFO - 2016-10-28 16:09:25 --> Router Class Initialized
INFO - 2016-10-28 16:09:25 --> Output Class Initialized
INFO - 2016-10-28 16:09:25 --> Security Class Initialized
DEBUG - 2016-10-28 16:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:09:25 --> Input Class Initialized
INFO - 2016-10-28 16:09:25 --> Language Class Initialized
INFO - 2016-10-28 16:09:25 --> Loader Class Initialized
INFO - 2016-10-28 16:09:25 --> Helper loaded: url_helper
INFO - 2016-10-28 16:09:25 --> Helper loaded: form_helper
INFO - 2016-10-28 16:09:25 --> Database Driver Class Initialized
INFO - 2016-10-28 16:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:09:25 --> Controller Class Initialized
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:09:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
ERROR - 2016-10-28 16:09:25 --> Severity: Notice --> Undefined variable: all_leave_type /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 124
INFO - 2016-10-28 16:09:26 --> Config Class Initialized
INFO - 2016-10-28 16:09:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:09:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:09:26 --> Utf8 Class Initialized
INFO - 2016-10-28 16:09:26 --> URI Class Initialized
DEBUG - 2016-10-28 16:09:26 --> No URI present. Default controller set.
INFO - 2016-10-28 16:09:26 --> Router Class Initialized
INFO - 2016-10-28 16:09:26 --> Output Class Initialized
INFO - 2016-10-28 16:09:26 --> Security Class Initialized
DEBUG - 2016-10-28 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:09:26 --> Input Class Initialized
INFO - 2016-10-28 16:09:26 --> Language Class Initialized
INFO - 2016-10-28 16:09:26 --> Loader Class Initialized
INFO - 2016-10-28 16:09:26 --> Helper loaded: url_helper
INFO - 2016-10-28 16:09:26 --> Helper loaded: form_helper
INFO - 2016-10-28 16:09:26 --> Database Driver Class Initialized
INFO - 2016-10-28 16:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:09:26 --> Controller Class Initialized
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:09:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
ERROR - 2016-10-28 16:09:26 --> Severity: Notice --> Undefined variable: all_leave_type /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 124
INFO - 2016-10-28 16:09:55 --> Config Class Initialized
INFO - 2016-10-28 16:09:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:09:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:09:55 --> Utf8 Class Initialized
INFO - 2016-10-28 16:09:55 --> URI Class Initialized
DEBUG - 2016-10-28 16:09:55 --> No URI present. Default controller set.
INFO - 2016-10-28 16:09:55 --> Router Class Initialized
INFO - 2016-10-28 16:09:55 --> Output Class Initialized
INFO - 2016-10-28 16:09:55 --> Security Class Initialized
DEBUG - 2016-10-28 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:09:55 --> Input Class Initialized
INFO - 2016-10-28 16:09:55 --> Language Class Initialized
INFO - 2016-10-28 16:09:55 --> Loader Class Initialized
INFO - 2016-10-28 16:09:55 --> Helper loaded: url_helper
INFO - 2016-10-28 16:09:55 --> Helper loaded: form_helper
INFO - 2016-10-28 16:09:55 --> Database Driver Class Initialized
INFO - 2016-10-28 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:09:55 --> Controller Class Initialized
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:09:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:09:55 --> Final output sent to browser
DEBUG - 2016-10-28 16:09:55 --> Total execution time: 0.0172
INFO - 2016-10-28 16:09:57 --> Config Class Initialized
INFO - 2016-10-28 16:09:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:09:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:09:57 --> Utf8 Class Initialized
INFO - 2016-10-28 16:09:57 --> URI Class Initialized
DEBUG - 2016-10-28 16:09:57 --> No URI present. Default controller set.
INFO - 2016-10-28 16:09:57 --> Router Class Initialized
INFO - 2016-10-28 16:09:57 --> Output Class Initialized
INFO - 2016-10-28 16:09:57 --> Security Class Initialized
DEBUG - 2016-10-28 16:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:09:57 --> Input Class Initialized
INFO - 2016-10-28 16:09:57 --> Language Class Initialized
INFO - 2016-10-28 16:09:57 --> Loader Class Initialized
INFO - 2016-10-28 16:09:57 --> Helper loaded: url_helper
INFO - 2016-10-28 16:09:57 --> Helper loaded: form_helper
INFO - 2016-10-28 16:09:57 --> Database Driver Class Initialized
INFO - 2016-10-28 16:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:09:57 --> Controller Class Initialized
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:09:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:09:57 --> Final output sent to browser
DEBUG - 2016-10-28 16:09:57 --> Total execution time: 0.0175
INFO - 2016-10-28 16:14:55 --> Config Class Initialized
INFO - 2016-10-28 16:14:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:14:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:14:55 --> Utf8 Class Initialized
INFO - 2016-10-28 16:14:55 --> URI Class Initialized
DEBUG - 2016-10-28 16:14:55 --> No URI present. Default controller set.
INFO - 2016-10-28 16:14:55 --> Router Class Initialized
INFO - 2016-10-28 16:14:55 --> Output Class Initialized
INFO - 2016-10-28 16:14:55 --> Security Class Initialized
DEBUG - 2016-10-28 16:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:14:55 --> Input Class Initialized
INFO - 2016-10-28 16:14:55 --> Language Class Initialized
INFO - 2016-10-28 16:14:55 --> Loader Class Initialized
INFO - 2016-10-28 16:14:55 --> Helper loaded: url_helper
INFO - 2016-10-28 16:14:55 --> Helper loaded: form_helper
INFO - 2016-10-28 16:14:55 --> Database Driver Class Initialized
INFO - 2016-10-28 16:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:14:55 --> Controller Class Initialized
INFO - 2016-10-28 16:14:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:14:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:14:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:14:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
ERROR - 2016-10-28 16:14:55 --> Severity: Notice --> Undefined variable: all_leave_type /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 81
INFO - 2016-10-28 16:14:57 --> Config Class Initialized
INFO - 2016-10-28 16:14:57 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:14:57 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:14:57 --> Utf8 Class Initialized
INFO - 2016-10-28 16:14:57 --> URI Class Initialized
DEBUG - 2016-10-28 16:14:57 --> No URI present. Default controller set.
INFO - 2016-10-28 16:14:57 --> Router Class Initialized
INFO - 2016-10-28 16:14:57 --> Output Class Initialized
INFO - 2016-10-28 16:14:57 --> Security Class Initialized
DEBUG - 2016-10-28 16:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:14:57 --> Input Class Initialized
INFO - 2016-10-28 16:14:57 --> Language Class Initialized
INFO - 2016-10-28 16:14:57 --> Loader Class Initialized
INFO - 2016-10-28 16:14:57 --> Helper loaded: url_helper
INFO - 2016-10-28 16:14:57 --> Helper loaded: form_helper
INFO - 2016-10-28 16:14:57 --> Database Driver Class Initialized
INFO - 2016-10-28 16:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:14:57 --> Controller Class Initialized
INFO - 2016-10-28 16:14:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:14:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:14:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:14:57 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
ERROR - 2016-10-28 16:14:57 --> Severity: Notice --> Undefined variable: all_leave_type /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 81
INFO - 2016-10-28 16:15:15 --> Config Class Initialized
INFO - 2016-10-28 16:15:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:15:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:15:15 --> Utf8 Class Initialized
INFO - 2016-10-28 16:15:15 --> URI Class Initialized
DEBUG - 2016-10-28 16:15:15 --> No URI present. Default controller set.
INFO - 2016-10-28 16:15:15 --> Router Class Initialized
INFO - 2016-10-28 16:15:15 --> Output Class Initialized
INFO - 2016-10-28 16:15:15 --> Security Class Initialized
DEBUG - 2016-10-28 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:15:15 --> Input Class Initialized
INFO - 2016-10-28 16:15:15 --> Language Class Initialized
INFO - 2016-10-28 16:15:15 --> Loader Class Initialized
INFO - 2016-10-28 16:15:15 --> Helper loaded: url_helper
INFO - 2016-10-28 16:15:15 --> Helper loaded: form_helper
INFO - 2016-10-28 16:15:15 --> Database Driver Class Initialized
INFO - 2016-10-28 16:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:15:15 --> Controller Class Initialized
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:15:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:15:15 --> Final output sent to browser
DEBUG - 2016-10-28 16:15:15 --> Total execution time: 0.0185
INFO - 2016-10-28 16:15:17 --> Config Class Initialized
INFO - 2016-10-28 16:15:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:15:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:15:17 --> Utf8 Class Initialized
INFO - 2016-10-28 16:15:17 --> URI Class Initialized
DEBUG - 2016-10-28 16:15:17 --> No URI present. Default controller set.
INFO - 2016-10-28 16:15:17 --> Router Class Initialized
INFO - 2016-10-28 16:15:17 --> Output Class Initialized
INFO - 2016-10-28 16:15:17 --> Security Class Initialized
DEBUG - 2016-10-28 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:15:17 --> Input Class Initialized
INFO - 2016-10-28 16:15:17 --> Language Class Initialized
INFO - 2016-10-28 16:15:17 --> Loader Class Initialized
INFO - 2016-10-28 16:15:17 --> Helper loaded: url_helper
INFO - 2016-10-28 16:15:17 --> Helper loaded: form_helper
INFO - 2016-10-28 16:15:17 --> Database Driver Class Initialized
INFO - 2016-10-28 16:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:15:17 --> Controller Class Initialized
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:15:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:15:17 --> Final output sent to browser
DEBUG - 2016-10-28 16:15:17 --> Total execution time: 0.0166
INFO - 2016-10-28 16:16:50 --> Config Class Initialized
INFO - 2016-10-28 16:16:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:16:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:16:50 --> Utf8 Class Initialized
INFO - 2016-10-28 16:16:50 --> URI Class Initialized
DEBUG - 2016-10-28 16:16:50 --> No URI present. Default controller set.
INFO - 2016-10-28 16:16:50 --> Router Class Initialized
INFO - 2016-10-28 16:16:50 --> Output Class Initialized
INFO - 2016-10-28 16:16:50 --> Security Class Initialized
DEBUG - 2016-10-28 16:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:16:50 --> Input Class Initialized
INFO - 2016-10-28 16:16:50 --> Language Class Initialized
INFO - 2016-10-28 16:16:50 --> Loader Class Initialized
INFO - 2016-10-28 16:16:50 --> Helper loaded: url_helper
INFO - 2016-10-28 16:16:50 --> Helper loaded: form_helper
INFO - 2016-10-28 16:16:50 --> Database Driver Class Initialized
INFO - 2016-10-28 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:16:50 --> Controller Class Initialized
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:16:50 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:16:50 --> Final output sent to browser
DEBUG - 2016-10-28 16:16:50 --> Total execution time: 0.0178
INFO - 2016-10-28 16:20:06 --> Config Class Initialized
INFO - 2016-10-28 16:20:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:20:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:20:06 --> Utf8 Class Initialized
INFO - 2016-10-28 16:20:06 --> URI Class Initialized
DEBUG - 2016-10-28 16:20:06 --> No URI present. Default controller set.
INFO - 2016-10-28 16:20:06 --> Router Class Initialized
INFO - 2016-10-28 16:20:06 --> Output Class Initialized
INFO - 2016-10-28 16:20:06 --> Security Class Initialized
DEBUG - 2016-10-28 16:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:20:06 --> Input Class Initialized
INFO - 2016-10-28 16:20:06 --> Language Class Initialized
INFO - 2016-10-28 16:20:06 --> Loader Class Initialized
INFO - 2016-10-28 16:20:06 --> Helper loaded: url_helper
INFO - 2016-10-28 16:20:06 --> Helper loaded: form_helper
INFO - 2016-10-28 16:20:06 --> Database Driver Class Initialized
INFO - 2016-10-28 16:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:20:06 --> Controller Class Initialized
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:20:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:20:06 --> Final output sent to browser
DEBUG - 2016-10-28 16:20:06 --> Total execution time: 0.0181
INFO - 2016-10-28 16:20:37 --> Config Class Initialized
INFO - 2016-10-28 16:20:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:20:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:20:37 --> Utf8 Class Initialized
INFO - 2016-10-28 16:20:37 --> URI Class Initialized
DEBUG - 2016-10-28 16:20:37 --> No URI present. Default controller set.
INFO - 2016-10-28 16:20:37 --> Router Class Initialized
INFO - 2016-10-28 16:20:37 --> Output Class Initialized
INFO - 2016-10-28 16:20:37 --> Security Class Initialized
DEBUG - 2016-10-28 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:20:37 --> Input Class Initialized
INFO - 2016-10-28 16:20:37 --> Language Class Initialized
INFO - 2016-10-28 16:20:37 --> Loader Class Initialized
INFO - 2016-10-28 16:20:37 --> Helper loaded: url_helper
INFO - 2016-10-28 16:20:37 --> Helper loaded: form_helper
INFO - 2016-10-28 16:20:37 --> Database Driver Class Initialized
INFO - 2016-10-28 16:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:20:37 --> Controller Class Initialized
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:20:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:20:37 --> Final output sent to browser
DEBUG - 2016-10-28 16:20:37 --> Total execution time: 0.0179
INFO - 2016-10-28 16:20:58 --> Config Class Initialized
INFO - 2016-10-28 16:20:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:20:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:20:58 --> Utf8 Class Initialized
INFO - 2016-10-28 16:20:58 --> URI Class Initialized
DEBUG - 2016-10-28 16:20:58 --> No URI present. Default controller set.
INFO - 2016-10-28 16:20:58 --> Router Class Initialized
INFO - 2016-10-28 16:20:58 --> Output Class Initialized
INFO - 2016-10-28 16:20:58 --> Security Class Initialized
DEBUG - 2016-10-28 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:20:58 --> Input Class Initialized
INFO - 2016-10-28 16:20:58 --> Language Class Initialized
INFO - 2016-10-28 16:20:58 --> Loader Class Initialized
INFO - 2016-10-28 16:20:58 --> Helper loaded: url_helper
INFO - 2016-10-28 16:20:58 --> Helper loaded: form_helper
INFO - 2016-10-28 16:20:58 --> Database Driver Class Initialized
INFO - 2016-10-28 16:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:20:58 --> Controller Class Initialized
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:20:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:20:58 --> Final output sent to browser
DEBUG - 2016-10-28 16:20:58 --> Total execution time: 0.0174
INFO - 2016-10-28 16:22:13 --> Config Class Initialized
INFO - 2016-10-28 16:22:13 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:22:13 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:22:13 --> Utf8 Class Initialized
INFO - 2016-10-28 16:22:13 --> URI Class Initialized
DEBUG - 2016-10-28 16:22:13 --> No URI present. Default controller set.
INFO - 2016-10-28 16:22:13 --> Router Class Initialized
INFO - 2016-10-28 16:22:13 --> Output Class Initialized
INFO - 2016-10-28 16:22:13 --> Security Class Initialized
DEBUG - 2016-10-28 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:22:13 --> Input Class Initialized
INFO - 2016-10-28 16:22:13 --> Language Class Initialized
INFO - 2016-10-28 16:22:13 --> Loader Class Initialized
INFO - 2016-10-28 16:22:13 --> Helper loaded: url_helper
INFO - 2016-10-28 16:22:13 --> Helper loaded: form_helper
INFO - 2016-10-28 16:22:13 --> Database Driver Class Initialized
INFO - 2016-10-28 16:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:22:13 --> Controller Class Initialized
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:22:13 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:22:13 --> Final output sent to browser
DEBUG - 2016-10-28 16:22:13 --> Total execution time: 0.0181
INFO - 2016-10-28 16:22:25 --> Config Class Initialized
INFO - 2016-10-28 16:22:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:22:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:22:25 --> Utf8 Class Initialized
INFO - 2016-10-28 16:22:25 --> URI Class Initialized
DEBUG - 2016-10-28 16:22:25 --> No URI present. Default controller set.
INFO - 2016-10-28 16:22:25 --> Router Class Initialized
INFO - 2016-10-28 16:22:25 --> Output Class Initialized
INFO - 2016-10-28 16:22:25 --> Security Class Initialized
DEBUG - 2016-10-28 16:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:22:25 --> Input Class Initialized
INFO - 2016-10-28 16:22:25 --> Language Class Initialized
INFO - 2016-10-28 16:22:25 --> Loader Class Initialized
INFO - 2016-10-28 16:22:25 --> Helper loaded: url_helper
INFO - 2016-10-28 16:22:25 --> Helper loaded: form_helper
INFO - 2016-10-28 16:22:25 --> Database Driver Class Initialized
INFO - 2016-10-28 16:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:22:25 --> Controller Class Initialized
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:22:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:22:25 --> Final output sent to browser
DEBUG - 2016-10-28 16:22:25 --> Total execution time: 0.0172
INFO - 2016-10-28 16:22:38 --> Config Class Initialized
INFO - 2016-10-28 16:22:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:22:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:22:38 --> Utf8 Class Initialized
INFO - 2016-10-28 16:22:38 --> URI Class Initialized
INFO - 2016-10-28 16:22:38 --> Router Class Initialized
INFO - 2016-10-28 16:22:38 --> Output Class Initialized
INFO - 2016-10-28 16:22:38 --> Security Class Initialized
DEBUG - 2016-10-28 16:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:22:38 --> Input Class Initialized
INFO - 2016-10-28 16:22:38 --> Language Class Initialized
INFO - 2016-10-28 16:22:38 --> Loader Class Initialized
INFO - 2016-10-28 16:22:38 --> Helper loaded: url_helper
INFO - 2016-10-28 16:22:38 --> Helper loaded: form_helper
INFO - 2016-10-28 16:22:38 --> Database Driver Class Initialized
INFO - 2016-10-28 16:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:22:38 --> Controller Class Initialized
INFO - 2016-10-28 16:22:38 --> Form Validation Class Initialized
INFO - 2016-10-28 16:22:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 16:22:38 --> Final output sent to browser
DEBUG - 2016-10-28 16:22:38 --> Total execution time: 0.0179
INFO - 2016-10-28 16:22:39 --> Config Class Initialized
INFO - 2016-10-28 16:22:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:22:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:22:39 --> Utf8 Class Initialized
INFO - 2016-10-28 16:22:39 --> URI Class Initialized
DEBUG - 2016-10-28 16:22:39 --> No URI present. Default controller set.
INFO - 2016-10-28 16:22:39 --> Router Class Initialized
INFO - 2016-10-28 16:22:39 --> Output Class Initialized
INFO - 2016-10-28 16:22:39 --> Security Class Initialized
DEBUG - 2016-10-28 16:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:22:39 --> Input Class Initialized
INFO - 2016-10-28 16:22:39 --> Language Class Initialized
INFO - 2016-10-28 16:22:39 --> Loader Class Initialized
INFO - 2016-10-28 16:22:39 --> Helper loaded: url_helper
INFO - 2016-10-28 16:22:39 --> Helper loaded: form_helper
INFO - 2016-10-28 16:22:39 --> Database Driver Class Initialized
INFO - 2016-10-28 16:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:22:39 --> Controller Class Initialized
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:22:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:22:39 --> Final output sent to browser
DEBUG - 2016-10-28 16:22:39 --> Total execution time: 0.0169
INFO - 2016-10-28 16:25:10 --> Config Class Initialized
INFO - 2016-10-28 16:25:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:25:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:25:10 --> Utf8 Class Initialized
INFO - 2016-10-28 16:25:10 --> URI Class Initialized
DEBUG - 2016-10-28 16:25:10 --> No URI present. Default controller set.
INFO - 2016-10-28 16:25:10 --> Router Class Initialized
INFO - 2016-10-28 16:25:10 --> Output Class Initialized
INFO - 2016-10-28 16:25:10 --> Security Class Initialized
DEBUG - 2016-10-28 16:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:25:10 --> Input Class Initialized
INFO - 2016-10-28 16:25:10 --> Language Class Initialized
INFO - 2016-10-28 16:25:10 --> Loader Class Initialized
INFO - 2016-10-28 16:25:10 --> Helper loaded: url_helper
INFO - 2016-10-28 16:25:10 --> Helper loaded: form_helper
INFO - 2016-10-28 16:25:10 --> Database Driver Class Initialized
INFO - 2016-10-28 16:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:25:10 --> Controller Class Initialized
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:25:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:25:10 --> Final output sent to browser
DEBUG - 2016-10-28 16:25:10 --> Total execution time: 0.0179
INFO - 2016-10-28 16:25:40 --> Config Class Initialized
INFO - 2016-10-28 16:25:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:25:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:25:40 --> Utf8 Class Initialized
INFO - 2016-10-28 16:25:40 --> URI Class Initialized
INFO - 2016-10-28 16:25:40 --> Router Class Initialized
INFO - 2016-10-28 16:25:40 --> Output Class Initialized
INFO - 2016-10-28 16:25:40 --> Security Class Initialized
DEBUG - 2016-10-28 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:25:40 --> Input Class Initialized
INFO - 2016-10-28 16:25:40 --> Language Class Initialized
INFO - 2016-10-28 16:25:40 --> Loader Class Initialized
INFO - 2016-10-28 16:25:40 --> Helper loaded: url_helper
INFO - 2016-10-28 16:25:40 --> Helper loaded: form_helper
INFO - 2016-10-28 16:25:40 --> Database Driver Class Initialized
INFO - 2016-10-28 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:25:40 --> Controller Class Initialized
DEBUG - 2016-10-28 16:25:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 16:25:40 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
ERROR - 2016-10-28 16:25:40 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
INFO - 2016-10-28 16:25:40 --> Config Class Initialized
INFO - 2016-10-28 16:25:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:25:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:25:40 --> Utf8 Class Initialized
INFO - 2016-10-28 16:25:40 --> URI Class Initialized
DEBUG - 2016-10-28 16:25:40 --> No URI present. Default controller set.
INFO - 2016-10-28 16:25:40 --> Router Class Initialized
INFO - 2016-10-28 16:25:40 --> Output Class Initialized
INFO - 2016-10-28 16:25:40 --> Security Class Initialized
DEBUG - 2016-10-28 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:25:40 --> Input Class Initialized
INFO - 2016-10-28 16:25:40 --> Language Class Initialized
INFO - 2016-10-28 16:25:40 --> Loader Class Initialized
INFO - 2016-10-28 16:25:40 --> Helper loaded: url_helper
INFO - 2016-10-28 16:25:40 --> Helper loaded: form_helper
INFO - 2016-10-28 16:25:40 --> Database Driver Class Initialized
INFO - 2016-10-28 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:25:40 --> Controller Class Initialized
INFO - 2016-10-28 16:25:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:25:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 16:25:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:25:40 --> Final output sent to browser
DEBUG - 2016-10-28 16:25:40 --> Total execution time: 0.0153
INFO - 2016-10-28 16:25:50 --> Config Class Initialized
INFO - 2016-10-28 16:25:50 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:25:50 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:25:50 --> Utf8 Class Initialized
INFO - 2016-10-28 16:25:50 --> URI Class Initialized
INFO - 2016-10-28 16:25:50 --> Router Class Initialized
INFO - 2016-10-28 16:25:50 --> Output Class Initialized
INFO - 2016-10-28 16:25:50 --> Security Class Initialized
DEBUG - 2016-10-28 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:25:50 --> Input Class Initialized
INFO - 2016-10-28 16:25:50 --> Language Class Initialized
INFO - 2016-10-28 16:25:50 --> Loader Class Initialized
INFO - 2016-10-28 16:25:50 --> Helper loaded: url_helper
INFO - 2016-10-28 16:25:50 --> Helper loaded: form_helper
INFO - 2016-10-28 16:25:50 --> Database Driver Class Initialized
INFO - 2016-10-28 16:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:25:51 --> Controller Class Initialized
DEBUG - 2016-10-28 16:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 16:25:51 --> Model Class Initialized
INFO - 2016-10-28 16:25:51 --> Final output sent to browser
DEBUG - 2016-10-28 16:25:51 --> Total execution time: 0.0372
INFO - 2016-10-28 16:25:56 --> Config Class Initialized
INFO - 2016-10-28 16:25:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:25:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:25:56 --> Utf8 Class Initialized
INFO - 2016-10-28 16:25:56 --> URI Class Initialized
INFO - 2016-10-28 16:25:56 --> Router Class Initialized
INFO - 2016-10-28 16:25:56 --> Output Class Initialized
INFO - 2016-10-28 16:25:56 --> Security Class Initialized
DEBUG - 2016-10-28 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:25:56 --> Input Class Initialized
INFO - 2016-10-28 16:25:56 --> Language Class Initialized
INFO - 2016-10-28 16:25:56 --> Loader Class Initialized
INFO - 2016-10-28 16:25:56 --> Helper loaded: url_helper
INFO - 2016-10-28 16:25:56 --> Helper loaded: form_helper
INFO - 2016-10-28 16:25:56 --> Database Driver Class Initialized
INFO - 2016-10-28 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:25:56 --> Controller Class Initialized
DEBUG - 2016-10-28 16:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 16:25:56 --> Model Class Initialized
INFO - 2016-10-28 16:25:56 --> Final output sent to browser
DEBUG - 2016-10-28 16:25:56 --> Total execution time: 0.0169
INFO - 2016-10-28 16:25:56 --> Config Class Initialized
INFO - 2016-10-28 16:25:56 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:25:56 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:25:56 --> Utf8 Class Initialized
INFO - 2016-10-28 16:25:56 --> URI Class Initialized
DEBUG - 2016-10-28 16:25:56 --> No URI present. Default controller set.
INFO - 2016-10-28 16:25:56 --> Router Class Initialized
INFO - 2016-10-28 16:25:56 --> Output Class Initialized
INFO - 2016-10-28 16:25:56 --> Security Class Initialized
DEBUG - 2016-10-28 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:25:56 --> Input Class Initialized
INFO - 2016-10-28 16:25:56 --> Language Class Initialized
INFO - 2016-10-28 16:25:56 --> Loader Class Initialized
INFO - 2016-10-28 16:25:56 --> Helper loaded: url_helper
INFO - 2016-10-28 16:25:56 --> Helper loaded: form_helper
INFO - 2016-10-28 16:25:56 --> Database Driver Class Initialized
INFO - 2016-10-28 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:25:56 --> Controller Class Initialized
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/my_leave.php
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:25:56 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:25:56 --> Final output sent to browser
DEBUG - 2016-10-28 16:25:56 --> Total execution time: 0.0525
INFO - 2016-10-28 16:26:10 --> Config Class Initialized
INFO - 2016-10-28 16:26:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:10 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:10 --> URI Class Initialized
INFO - 2016-10-28 16:26:10 --> Router Class Initialized
INFO - 2016-10-28 16:26:10 --> Output Class Initialized
INFO - 2016-10-28 16:26:10 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:10 --> Input Class Initialized
INFO - 2016-10-28 16:26:10 --> Language Class Initialized
INFO - 2016-10-28 16:26:10 --> Loader Class Initialized
INFO - 2016-10-28 16:26:10 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:10 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:10 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:10 --> Controller Class Initialized
DEBUG - 2016-10-28 16:26:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 16:26:10 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
ERROR - 2016-10-28 16:26:10 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
INFO - 2016-10-28 16:26:10 --> Config Class Initialized
INFO - 2016-10-28 16:26:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:10 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:10 --> URI Class Initialized
DEBUG - 2016-10-28 16:26:10 --> No URI present. Default controller set.
INFO - 2016-10-28 16:26:10 --> Router Class Initialized
INFO - 2016-10-28 16:26:10 --> Output Class Initialized
INFO - 2016-10-28 16:26:10 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:10 --> Input Class Initialized
INFO - 2016-10-28 16:26:10 --> Language Class Initialized
INFO - 2016-10-28 16:26:10 --> Loader Class Initialized
INFO - 2016-10-28 16:26:10 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:10 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:10 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:10 --> Controller Class Initialized
INFO - 2016-10-28 16:26:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:26:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 16:26:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:26:10 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:10 --> Total execution time: 0.0150
INFO - 2016-10-28 16:26:20 --> Config Class Initialized
INFO - 2016-10-28 16:26:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:20 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:20 --> URI Class Initialized
INFO - 2016-10-28 16:26:20 --> Router Class Initialized
INFO - 2016-10-28 16:26:20 --> Output Class Initialized
INFO - 2016-10-28 16:26:20 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:20 --> Input Class Initialized
INFO - 2016-10-28 16:26:20 --> Language Class Initialized
INFO - 2016-10-28 16:26:20 --> Loader Class Initialized
INFO - 2016-10-28 16:26:20 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:20 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:20 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:20 --> Controller Class Initialized
DEBUG - 2016-10-28 16:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 16:26:20 --> Model Class Initialized
INFO - 2016-10-28 16:26:20 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:20 --> Total execution time: 0.0174
INFO - 2016-10-28 16:26:20 --> Config Class Initialized
INFO - 2016-10-28 16:26:20 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:20 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:20 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:20 --> URI Class Initialized
DEBUG - 2016-10-28 16:26:20 --> No URI present. Default controller set.
INFO - 2016-10-28 16:26:20 --> Router Class Initialized
INFO - 2016-10-28 16:26:20 --> Output Class Initialized
INFO - 2016-10-28 16:26:20 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:20 --> Input Class Initialized
INFO - 2016-10-28 16:26:20 --> Language Class Initialized
INFO - 2016-10-28 16:26:20 --> Loader Class Initialized
INFO - 2016-10-28 16:26:20 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:20 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:20 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:20 --> Controller Class Initialized
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:26:20 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:26:20 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:20 --> Total execution time: 0.0530
INFO - 2016-10-28 16:26:28 --> Config Class Initialized
INFO - 2016-10-28 16:26:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:28 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:28 --> URI Class Initialized
INFO - 2016-10-28 16:26:28 --> Router Class Initialized
INFO - 2016-10-28 16:26:28 --> Output Class Initialized
INFO - 2016-10-28 16:26:28 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:28 --> Input Class Initialized
INFO - 2016-10-28 16:26:28 --> Language Class Initialized
INFO - 2016-10-28 16:26:28 --> Loader Class Initialized
INFO - 2016-10-28 16:26:28 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:28 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:28 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:28 --> Controller Class Initialized
INFO - 2016-10-28 16:26:28 --> Form Validation Class Initialized
INFO - 2016-10-28 16:26:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 16:26:28 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:28 --> Total execution time: 0.0172
INFO - 2016-10-28 16:26:30 --> Config Class Initialized
INFO - 2016-10-28 16:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:30 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:30 --> URI Class Initialized
DEBUG - 2016-10-28 16:26:30 --> No URI present. Default controller set.
INFO - 2016-10-28 16:26:30 --> Router Class Initialized
INFO - 2016-10-28 16:26:30 --> Output Class Initialized
INFO - 2016-10-28 16:26:30 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:30 --> Input Class Initialized
INFO - 2016-10-28 16:26:30 --> Language Class Initialized
INFO - 2016-10-28 16:26:30 --> Loader Class Initialized
INFO - 2016-10-28 16:26:30 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:30 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:30 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:30 --> Controller Class Initialized
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:26:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:26:30 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:30 --> Total execution time: 0.0168
INFO - 2016-10-28 16:26:31 --> Config Class Initialized
INFO - 2016-10-28 16:26:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:31 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:31 --> URI Class Initialized
INFO - 2016-10-28 16:26:31 --> Router Class Initialized
INFO - 2016-10-28 16:26:31 --> Output Class Initialized
INFO - 2016-10-28 16:26:31 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:31 --> Input Class Initialized
INFO - 2016-10-28 16:26:31 --> Language Class Initialized
INFO - 2016-10-28 16:26:31 --> Loader Class Initialized
INFO - 2016-10-28 16:26:31 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:31 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:31 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:31 --> Controller Class Initialized
DEBUG - 2016-10-28 16:26:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 16:26:31 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
ERROR - 2016-10-28 16:26:31 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 91
INFO - 2016-10-28 16:26:31 --> Config Class Initialized
INFO - 2016-10-28 16:26:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:31 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:31 --> URI Class Initialized
DEBUG - 2016-10-28 16:26:31 --> No URI present. Default controller set.
INFO - 2016-10-28 16:26:31 --> Router Class Initialized
INFO - 2016-10-28 16:26:31 --> Output Class Initialized
INFO - 2016-10-28 16:26:31 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:31 --> Input Class Initialized
INFO - 2016-10-28 16:26:31 --> Language Class Initialized
INFO - 2016-10-28 16:26:31 --> Loader Class Initialized
INFO - 2016-10-28 16:26:31 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:31 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:31 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:31 --> Controller Class Initialized
INFO - 2016-10-28 16:26:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:26:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 16:26:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:26:31 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:31 --> Total execution time: 0.0150
INFO - 2016-10-28 16:26:36 --> Config Class Initialized
INFO - 2016-10-28 16:26:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:36 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:36 --> URI Class Initialized
INFO - 2016-10-28 16:26:36 --> Router Class Initialized
INFO - 2016-10-28 16:26:36 --> Output Class Initialized
INFO - 2016-10-28 16:26:36 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:36 --> Input Class Initialized
INFO - 2016-10-28 16:26:36 --> Language Class Initialized
INFO - 2016-10-28 16:26:36 --> Loader Class Initialized
INFO - 2016-10-28 16:26:36 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:36 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:36 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:36 --> Controller Class Initialized
DEBUG - 2016-10-28 16:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 16:26:36 --> Model Class Initialized
INFO - 2016-10-28 16:26:36 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:36 --> Total execution time: 0.0186
INFO - 2016-10-28 16:26:36 --> Config Class Initialized
INFO - 2016-10-28 16:26:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:26:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:26:36 --> Utf8 Class Initialized
INFO - 2016-10-28 16:26:36 --> URI Class Initialized
DEBUG - 2016-10-28 16:26:36 --> No URI present. Default controller set.
INFO - 2016-10-28 16:26:36 --> Router Class Initialized
INFO - 2016-10-28 16:26:36 --> Output Class Initialized
INFO - 2016-10-28 16:26:36 --> Security Class Initialized
DEBUG - 2016-10-28 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:26:36 --> Input Class Initialized
INFO - 2016-10-28 16:26:36 --> Language Class Initialized
INFO - 2016-10-28 16:26:36 --> Loader Class Initialized
INFO - 2016-10-28 16:26:36 --> Helper loaded: url_helper
INFO - 2016-10-28 16:26:36 --> Helper loaded: form_helper
INFO - 2016-10-28 16:26:36 --> Database Driver Class Initialized
INFO - 2016-10-28 16:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:26:36 --> Controller Class Initialized
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:26:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:26:36 --> Final output sent to browser
DEBUG - 2016-10-28 16:26:36 --> Total execution time: 0.0168
INFO - 2016-10-28 16:27:21 --> Config Class Initialized
INFO - 2016-10-28 16:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:27:21 --> Utf8 Class Initialized
INFO - 2016-10-28 16:27:21 --> URI Class Initialized
DEBUG - 2016-10-28 16:27:21 --> No URI present. Default controller set.
INFO - 2016-10-28 16:27:21 --> Router Class Initialized
INFO - 2016-10-28 16:27:21 --> Output Class Initialized
INFO - 2016-10-28 16:27:21 --> Security Class Initialized
DEBUG - 2016-10-28 16:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:27:21 --> Input Class Initialized
INFO - 2016-10-28 16:27:21 --> Language Class Initialized
INFO - 2016-10-28 16:27:21 --> Loader Class Initialized
INFO - 2016-10-28 16:27:21 --> Helper loaded: url_helper
INFO - 2016-10-28 16:27:21 --> Helper loaded: form_helper
INFO - 2016-10-28 16:27:21 --> Database Driver Class Initialized
INFO - 2016-10-28 16:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:27:21 --> Controller Class Initialized
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:27:21 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:27:21 --> Final output sent to browser
DEBUG - 2016-10-28 16:27:21 --> Total execution time: 0.0173
INFO - 2016-10-28 16:28:32 --> Config Class Initialized
INFO - 2016-10-28 16:28:32 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:28:32 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:28:32 --> Utf8 Class Initialized
INFO - 2016-10-28 16:28:32 --> URI Class Initialized
DEBUG - 2016-10-28 16:28:32 --> No URI present. Default controller set.
INFO - 2016-10-28 16:28:32 --> Router Class Initialized
INFO - 2016-10-28 16:28:32 --> Output Class Initialized
INFO - 2016-10-28 16:28:32 --> Security Class Initialized
DEBUG - 2016-10-28 16:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:28:32 --> Input Class Initialized
INFO - 2016-10-28 16:28:32 --> Language Class Initialized
INFO - 2016-10-28 16:28:32 --> Loader Class Initialized
INFO - 2016-10-28 16:28:32 --> Helper loaded: url_helper
INFO - 2016-10-28 16:28:32 --> Helper loaded: form_helper
INFO - 2016-10-28 16:28:32 --> Database Driver Class Initialized
INFO - 2016-10-28 16:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:28:32 --> Controller Class Initialized
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:28:32 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:28:32 --> Final output sent to browser
DEBUG - 2016-10-28 16:28:32 --> Total execution time: 0.0178
INFO - 2016-10-28 16:28:40 --> Config Class Initialized
INFO - 2016-10-28 16:28:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:28:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:28:40 --> Utf8 Class Initialized
INFO - 2016-10-28 16:28:40 --> URI Class Initialized
DEBUG - 2016-10-28 16:28:40 --> No URI present. Default controller set.
INFO - 2016-10-28 16:28:40 --> Router Class Initialized
INFO - 2016-10-28 16:28:40 --> Output Class Initialized
INFO - 2016-10-28 16:28:40 --> Security Class Initialized
DEBUG - 2016-10-28 16:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:28:40 --> Input Class Initialized
INFO - 2016-10-28 16:28:40 --> Language Class Initialized
INFO - 2016-10-28 16:28:40 --> Loader Class Initialized
INFO - 2016-10-28 16:28:40 --> Helper loaded: url_helper
INFO - 2016-10-28 16:28:40 --> Helper loaded: form_helper
INFO - 2016-10-28 16:28:40 --> Database Driver Class Initialized
INFO - 2016-10-28 16:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:28:40 --> Controller Class Initialized
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:28:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:28:40 --> Final output sent to browser
DEBUG - 2016-10-28 16:28:40 --> Total execution time: 0.0184
INFO - 2016-10-28 16:32:37 --> Config Class Initialized
INFO - 2016-10-28 16:32:37 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:32:37 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:32:37 --> Utf8 Class Initialized
INFO - 2016-10-28 16:32:37 --> URI Class Initialized
DEBUG - 2016-10-28 16:32:37 --> No URI present. Default controller set.
INFO - 2016-10-28 16:32:37 --> Router Class Initialized
INFO - 2016-10-28 16:32:37 --> Output Class Initialized
INFO - 2016-10-28 16:32:37 --> Security Class Initialized
DEBUG - 2016-10-28 16:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:32:37 --> Input Class Initialized
INFO - 2016-10-28 16:32:37 --> Language Class Initialized
INFO - 2016-10-28 16:32:37 --> Loader Class Initialized
INFO - 2016-10-28 16:32:37 --> Helper loaded: url_helper
INFO - 2016-10-28 16:32:37 --> Helper loaded: form_helper
INFO - 2016-10-28 16:32:37 --> Database Driver Class Initialized
INFO - 2016-10-28 16:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:32:37 --> Controller Class Initialized
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:32:37 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:32:37 --> Final output sent to browser
DEBUG - 2016-10-28 16:32:37 --> Total execution time: 0.0181
INFO - 2016-10-28 16:32:40 --> Config Class Initialized
INFO - 2016-10-28 16:32:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:32:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:32:40 --> Utf8 Class Initialized
INFO - 2016-10-28 16:32:40 --> URI Class Initialized
INFO - 2016-10-28 16:32:40 --> Router Class Initialized
INFO - 2016-10-28 16:32:40 --> Output Class Initialized
INFO - 2016-10-28 16:32:40 --> Security Class Initialized
DEBUG - 2016-10-28 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:32:40 --> Input Class Initialized
INFO - 2016-10-28 16:32:40 --> Language Class Initialized
INFO - 2016-10-28 16:32:40 --> Loader Class Initialized
INFO - 2016-10-28 16:32:40 --> Helper loaded: url_helper
INFO - 2016-10-28 16:32:40 --> Helper loaded: form_helper
INFO - 2016-10-28 16:32:40 --> Database Driver Class Initialized
INFO - 2016-10-28 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:32:40 --> Controller Class Initialized
DEBUG - 2016-10-28 16:32:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 16:32:40 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-28 16:32:40 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-28 16:32:40 --> Config Class Initialized
INFO - 2016-10-28 16:32:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:32:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:32:40 --> Utf8 Class Initialized
INFO - 2016-10-28 16:32:40 --> URI Class Initialized
DEBUG - 2016-10-28 16:32:40 --> No URI present. Default controller set.
INFO - 2016-10-28 16:32:40 --> Router Class Initialized
INFO - 2016-10-28 16:32:40 --> Output Class Initialized
INFO - 2016-10-28 16:32:40 --> Security Class Initialized
DEBUG - 2016-10-28 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:32:40 --> Input Class Initialized
INFO - 2016-10-28 16:32:40 --> Language Class Initialized
INFO - 2016-10-28 16:32:40 --> Loader Class Initialized
INFO - 2016-10-28 16:32:40 --> Helper loaded: url_helper
INFO - 2016-10-28 16:32:40 --> Helper loaded: form_helper
INFO - 2016-10-28 16:32:40 --> Database Driver Class Initialized
INFO - 2016-10-28 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:32:40 --> Controller Class Initialized
INFO - 2016-10-28 16:32:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:32:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 16:32:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:32:40 --> Final output sent to browser
DEBUG - 2016-10-28 16:32:40 --> Total execution time: 0.0150
INFO - 2016-10-28 16:32:46 --> Config Class Initialized
INFO - 2016-10-28 16:32:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:32:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:32:46 --> Utf8 Class Initialized
INFO - 2016-10-28 16:32:46 --> URI Class Initialized
INFO - 2016-10-28 16:32:46 --> Router Class Initialized
INFO - 2016-10-28 16:32:46 --> Output Class Initialized
INFO - 2016-10-28 16:32:46 --> Security Class Initialized
DEBUG - 2016-10-28 16:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:32:46 --> Input Class Initialized
INFO - 2016-10-28 16:32:46 --> Language Class Initialized
INFO - 2016-10-28 16:32:46 --> Loader Class Initialized
INFO - 2016-10-28 16:32:46 --> Helper loaded: url_helper
INFO - 2016-10-28 16:32:46 --> Helper loaded: form_helper
INFO - 2016-10-28 16:32:46 --> Database Driver Class Initialized
INFO - 2016-10-28 16:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:32:46 --> Controller Class Initialized
DEBUG - 2016-10-28 16:32:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 16:32:46 --> Model Class Initialized
INFO - 2016-10-28 16:32:46 --> Final output sent to browser
DEBUG - 2016-10-28 16:32:46 --> Total execution time: 0.0192
INFO - 2016-10-28 16:32:46 --> Config Class Initialized
INFO - 2016-10-28 16:32:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:32:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:32:46 --> Utf8 Class Initialized
INFO - 2016-10-28 16:32:46 --> URI Class Initialized
DEBUG - 2016-10-28 16:32:46 --> No URI present. Default controller set.
INFO - 2016-10-28 16:32:46 --> Router Class Initialized
INFO - 2016-10-28 16:32:46 --> Output Class Initialized
INFO - 2016-10-28 16:32:46 --> Security Class Initialized
DEBUG - 2016-10-28 16:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:32:46 --> Input Class Initialized
INFO - 2016-10-28 16:32:46 --> Language Class Initialized
INFO - 2016-10-28 16:32:46 --> Loader Class Initialized
INFO - 2016-10-28 16:32:46 --> Helper loaded: url_helper
INFO - 2016-10-28 16:32:46 --> Helper loaded: form_helper
INFO - 2016-10-28 16:32:46 --> Database Driver Class Initialized
INFO - 2016-10-28 16:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:32:46 --> Controller Class Initialized
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_record_sidebar.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:32:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:32:46 --> Final output sent to browser
DEBUG - 2016-10-28 16:32:46 --> Total execution time: 0.0160
INFO - 2016-10-28 16:33:00 --> Config Class Initialized
INFO - 2016-10-28 16:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:33:00 --> Utf8 Class Initialized
INFO - 2016-10-28 16:33:00 --> URI Class Initialized
INFO - 2016-10-28 16:33:00 --> Router Class Initialized
INFO - 2016-10-28 16:33:00 --> Output Class Initialized
INFO - 2016-10-28 16:33:00 --> Security Class Initialized
DEBUG - 2016-10-28 16:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:33:00 --> Input Class Initialized
INFO - 2016-10-28 16:33:00 --> Language Class Initialized
INFO - 2016-10-28 16:33:00 --> Loader Class Initialized
INFO - 2016-10-28 16:33:00 --> Helper loaded: url_helper
INFO - 2016-10-28 16:33:00 --> Helper loaded: form_helper
INFO - 2016-10-28 16:33:00 --> Database Driver Class Initialized
INFO - 2016-10-28 16:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:33:00 --> Controller Class Initialized
INFO - 2016-10-28 16:33:00 --> Form Validation Class Initialized
INFO - 2016-10-28 16:33:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 16:33:00 --> Final output sent to browser
DEBUG - 2016-10-28 16:33:00 --> Total execution time: 0.0180
INFO - 2016-10-28 16:33:01 --> Config Class Initialized
INFO - 2016-10-28 16:33:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:33:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:33:01 --> Utf8 Class Initialized
INFO - 2016-10-28 16:33:01 --> URI Class Initialized
DEBUG - 2016-10-28 16:33:01 --> No URI present. Default controller set.
INFO - 2016-10-28 16:33:01 --> Router Class Initialized
INFO - 2016-10-28 16:33:01 --> Output Class Initialized
INFO - 2016-10-28 16:33:01 --> Security Class Initialized
DEBUG - 2016-10-28 16:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:33:01 --> Input Class Initialized
INFO - 2016-10-28 16:33:01 --> Language Class Initialized
INFO - 2016-10-28 16:33:01 --> Loader Class Initialized
INFO - 2016-10-28 16:33:01 --> Helper loaded: url_helper
INFO - 2016-10-28 16:33:01 --> Helper loaded: form_helper
INFO - 2016-10-28 16:33:01 --> Database Driver Class Initialized
INFO - 2016-10-28 16:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:33:01 --> Controller Class Initialized
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_record_sidebar.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:33:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:33:01 --> Final output sent to browser
DEBUG - 2016-10-28 16:33:01 --> Total execution time: 0.0165
INFO - 2016-10-28 16:33:05 --> Config Class Initialized
INFO - 2016-10-28 16:33:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:33:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:33:05 --> Utf8 Class Initialized
INFO - 2016-10-28 16:33:05 --> URI Class Initialized
INFO - 2016-10-28 16:33:05 --> Router Class Initialized
INFO - 2016-10-28 16:33:05 --> Output Class Initialized
INFO - 2016-10-28 16:33:05 --> Security Class Initialized
DEBUG - 2016-10-28 16:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:33:05 --> Input Class Initialized
INFO - 2016-10-28 16:33:05 --> Language Class Initialized
INFO - 2016-10-28 16:33:05 --> Loader Class Initialized
INFO - 2016-10-28 16:33:05 --> Helper loaded: url_helper
INFO - 2016-10-28 16:33:05 --> Helper loaded: form_helper
INFO - 2016-10-28 16:33:05 --> Database Driver Class Initialized
INFO - 2016-10-28 16:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:33:05 --> Controller Class Initialized
DEBUG - 2016-10-28 16:33:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 16:33:05 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
ERROR - 2016-10-28 16:33:05 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 92
INFO - 2016-10-28 16:33:05 --> Config Class Initialized
INFO - 2016-10-28 16:33:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:33:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:33:05 --> Utf8 Class Initialized
INFO - 2016-10-28 16:33:05 --> URI Class Initialized
DEBUG - 2016-10-28 16:33:05 --> No URI present. Default controller set.
INFO - 2016-10-28 16:33:05 --> Router Class Initialized
INFO - 2016-10-28 16:33:05 --> Output Class Initialized
INFO - 2016-10-28 16:33:05 --> Security Class Initialized
DEBUG - 2016-10-28 16:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:33:05 --> Input Class Initialized
INFO - 2016-10-28 16:33:05 --> Language Class Initialized
INFO - 2016-10-28 16:33:05 --> Loader Class Initialized
INFO - 2016-10-28 16:33:05 --> Helper loaded: url_helper
INFO - 2016-10-28 16:33:05 --> Helper loaded: form_helper
INFO - 2016-10-28 16:33:05 --> Database Driver Class Initialized
INFO - 2016-10-28 16:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:33:05 --> Controller Class Initialized
INFO - 2016-10-28 16:33:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:33:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 16:33:05 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:33:05 --> Final output sent to browser
DEBUG - 2016-10-28 16:33:05 --> Total execution time: 0.0148
INFO - 2016-10-28 16:33:10 --> Config Class Initialized
INFO - 2016-10-28 16:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:33:10 --> Utf8 Class Initialized
INFO - 2016-10-28 16:33:10 --> URI Class Initialized
INFO - 2016-10-28 16:33:10 --> Router Class Initialized
INFO - 2016-10-28 16:33:10 --> Output Class Initialized
INFO - 2016-10-28 16:33:10 --> Security Class Initialized
DEBUG - 2016-10-28 16:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:33:10 --> Input Class Initialized
INFO - 2016-10-28 16:33:10 --> Language Class Initialized
INFO - 2016-10-28 16:33:10 --> Loader Class Initialized
INFO - 2016-10-28 16:33:10 --> Helper loaded: url_helper
INFO - 2016-10-28 16:33:10 --> Helper loaded: form_helper
INFO - 2016-10-28 16:33:10 --> Database Driver Class Initialized
INFO - 2016-10-28 16:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:33:10 --> Controller Class Initialized
DEBUG - 2016-10-28 16:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 16:33:10 --> Model Class Initialized
INFO - 2016-10-28 16:33:10 --> Final output sent to browser
DEBUG - 2016-10-28 16:33:10 --> Total execution time: 0.0169
INFO - 2016-10-28 16:33:10 --> Config Class Initialized
INFO - 2016-10-28 16:33:10 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:33:10 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:33:10 --> Utf8 Class Initialized
INFO - 2016-10-28 16:33:10 --> URI Class Initialized
DEBUG - 2016-10-28 16:33:10 --> No URI present. Default controller set.
INFO - 2016-10-28 16:33:10 --> Router Class Initialized
INFO - 2016-10-28 16:33:10 --> Output Class Initialized
INFO - 2016-10-28 16:33:10 --> Security Class Initialized
DEBUG - 2016-10-28 16:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:33:10 --> Input Class Initialized
INFO - 2016-10-28 16:33:10 --> Language Class Initialized
INFO - 2016-10-28 16:33:10 --> Loader Class Initialized
INFO - 2016-10-28 16:33:10 --> Helper loaded: url_helper
INFO - 2016-10-28 16:33:10 --> Helper loaded: form_helper
INFO - 2016-10-28 16:33:10 --> Database Driver Class Initialized
INFO - 2016-10-28 16:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:33:10 --> Controller Class Initialized
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:33:10 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:33:10 --> Final output sent to browser
DEBUG - 2016-10-28 16:33:10 --> Total execution time: 0.0159
INFO - 2016-10-28 16:36:18 --> Config Class Initialized
INFO - 2016-10-28 16:36:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:36:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:36:18 --> Utf8 Class Initialized
INFO - 2016-10-28 16:36:18 --> URI Class Initialized
DEBUG - 2016-10-28 16:36:18 --> No URI present. Default controller set.
INFO - 2016-10-28 16:36:18 --> Router Class Initialized
INFO - 2016-10-28 16:36:18 --> Output Class Initialized
INFO - 2016-10-28 16:36:18 --> Security Class Initialized
DEBUG - 2016-10-28 16:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:36:18 --> Input Class Initialized
INFO - 2016-10-28 16:36:18 --> Language Class Initialized
INFO - 2016-10-28 16:36:18 --> Loader Class Initialized
INFO - 2016-10-28 16:36:18 --> Helper loaded: url_helper
INFO - 2016-10-28 16:36:18 --> Helper loaded: form_helper
INFO - 2016-10-28 16:36:18 --> Database Driver Class Initialized
INFO - 2016-10-28 16:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:36:18 --> Controller Class Initialized
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:36:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:36:18 --> Final output sent to browser
DEBUG - 2016-10-28 16:36:18 --> Total execution time: 0.0176
INFO - 2016-10-28 16:40:22 --> Config Class Initialized
INFO - 2016-10-28 16:40:22 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:40:22 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:40:22 --> Utf8 Class Initialized
INFO - 2016-10-28 16:40:22 --> URI Class Initialized
DEBUG - 2016-10-28 16:40:22 --> No URI present. Default controller set.
INFO - 2016-10-28 16:40:22 --> Router Class Initialized
INFO - 2016-10-28 16:40:22 --> Output Class Initialized
INFO - 2016-10-28 16:40:22 --> Security Class Initialized
DEBUG - 2016-10-28 16:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:40:22 --> Input Class Initialized
INFO - 2016-10-28 16:40:22 --> Language Class Initialized
INFO - 2016-10-28 16:40:22 --> Loader Class Initialized
INFO - 2016-10-28 16:40:22 --> Helper loaded: url_helper
INFO - 2016-10-28 16:40:22 --> Helper loaded: form_helper
INFO - 2016-10-28 16:40:22 --> Database Driver Class Initialized
INFO - 2016-10-28 16:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:40:22 --> Controller Class Initialized
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:40:22 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:40:22 --> Final output sent to browser
DEBUG - 2016-10-28 16:40:22 --> Total execution time: 0.0177
INFO - 2016-10-28 16:40:39 --> Config Class Initialized
INFO - 2016-10-28 16:40:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:40:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:40:39 --> Utf8 Class Initialized
INFO - 2016-10-28 16:40:39 --> URI Class Initialized
DEBUG - 2016-10-28 16:40:39 --> No URI present. Default controller set.
INFO - 2016-10-28 16:40:39 --> Router Class Initialized
INFO - 2016-10-28 16:40:39 --> Output Class Initialized
INFO - 2016-10-28 16:40:39 --> Security Class Initialized
DEBUG - 2016-10-28 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:40:39 --> Input Class Initialized
INFO - 2016-10-28 16:40:39 --> Language Class Initialized
INFO - 2016-10-28 16:40:39 --> Loader Class Initialized
INFO - 2016-10-28 16:40:39 --> Helper loaded: url_helper
INFO - 2016-10-28 16:40:39 --> Helper loaded: form_helper
INFO - 2016-10-28 16:40:39 --> Database Driver Class Initialized
INFO - 2016-10-28 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:40:39 --> Controller Class Initialized
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:40:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:40:39 --> Final output sent to browser
DEBUG - 2016-10-28 16:40:39 --> Total execution time: 0.0181
INFO - 2016-10-28 16:41:02 --> Config Class Initialized
INFO - 2016-10-28 16:41:02 --> Hooks Class Initialized
DEBUG - 2016-10-28 16:41:02 --> UTF-8 Support Enabled
INFO - 2016-10-28 16:41:02 --> Utf8 Class Initialized
INFO - 2016-10-28 16:41:02 --> URI Class Initialized
DEBUG - 2016-10-28 16:41:02 --> No URI present. Default controller set.
INFO - 2016-10-28 16:41:02 --> Router Class Initialized
INFO - 2016-10-28 16:41:02 --> Output Class Initialized
INFO - 2016-10-28 16:41:02 --> Security Class Initialized
DEBUG - 2016-10-28 16:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 16:41:02 --> Input Class Initialized
INFO - 2016-10-28 16:41:02 --> Language Class Initialized
INFO - 2016-10-28 16:41:02 --> Loader Class Initialized
INFO - 2016-10-28 16:41:02 --> Helper loaded: url_helper
INFO - 2016-10-28 16:41:02 --> Helper loaded: form_helper
INFO - 2016-10-28 16:41:02 --> Database Driver Class Initialized
INFO - 2016-10-28 16:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 16:41:02 --> Controller Class Initialized
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 16:41:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 16:41:02 --> Final output sent to browser
DEBUG - 2016-10-28 16:41:02 --> Total execution time: 0.0179
INFO - 2016-10-28 17:14:27 --> Config Class Initialized
INFO - 2016-10-28 17:14:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:14:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:14:27 --> Utf8 Class Initialized
INFO - 2016-10-28 17:14:27 --> URI Class Initialized
DEBUG - 2016-10-28 17:14:27 --> No URI present. Default controller set.
INFO - 2016-10-28 17:14:27 --> Router Class Initialized
INFO - 2016-10-28 17:14:27 --> Output Class Initialized
INFO - 2016-10-28 17:14:27 --> Security Class Initialized
DEBUG - 2016-10-28 17:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:14:27 --> Input Class Initialized
INFO - 2016-10-28 17:14:27 --> Language Class Initialized
INFO - 2016-10-28 17:14:27 --> Loader Class Initialized
INFO - 2016-10-28 17:14:27 --> Helper loaded: url_helper
INFO - 2016-10-28 17:14:27 --> Helper loaded: form_helper
INFO - 2016-10-28 17:14:27 --> Database Driver Class Initialized
INFO - 2016-10-28 17:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:14:27 --> Controller Class Initialized
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:14:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:14:27 --> Final output sent to browser
DEBUG - 2016-10-28 17:14:27 --> Total execution time: 0.0180
INFO - 2016-10-28 17:17:19 --> Config Class Initialized
INFO - 2016-10-28 17:17:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:17:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:17:19 --> Utf8 Class Initialized
INFO - 2016-10-28 17:17:19 --> URI Class Initialized
DEBUG - 2016-10-28 17:17:19 --> No URI present. Default controller set.
INFO - 2016-10-28 17:17:19 --> Router Class Initialized
INFO - 2016-10-28 17:17:19 --> Output Class Initialized
INFO - 2016-10-28 17:17:19 --> Security Class Initialized
DEBUG - 2016-10-28 17:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:17:19 --> Input Class Initialized
INFO - 2016-10-28 17:17:19 --> Language Class Initialized
INFO - 2016-10-28 17:17:19 --> Loader Class Initialized
INFO - 2016-10-28 17:17:19 --> Helper loaded: url_helper
INFO - 2016-10-28 17:17:19 --> Helper loaded: form_helper
INFO - 2016-10-28 17:17:19 --> Database Driver Class Initialized
INFO - 2016-10-28 17:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:17:19 --> Controller Class Initialized
INFO - 2016-10-28 17:17:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:17:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:17:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:17:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:17:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:17:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:17:19 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:17:19 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:17:25 --> Config Class Initialized
INFO - 2016-10-28 17:17:25 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:17:25 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:17:25 --> Utf8 Class Initialized
INFO - 2016-10-28 17:17:25 --> URI Class Initialized
DEBUG - 2016-10-28 17:17:25 --> No URI present. Default controller set.
INFO - 2016-10-28 17:17:25 --> Router Class Initialized
INFO - 2016-10-28 17:17:25 --> Output Class Initialized
INFO - 2016-10-28 17:17:25 --> Security Class Initialized
DEBUG - 2016-10-28 17:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:17:25 --> Input Class Initialized
INFO - 2016-10-28 17:17:25 --> Language Class Initialized
INFO - 2016-10-28 17:17:25 --> Loader Class Initialized
INFO - 2016-10-28 17:17:25 --> Helper loaded: url_helper
INFO - 2016-10-28 17:17:25 --> Helper loaded: form_helper
INFO - 2016-10-28 17:17:25 --> Database Driver Class Initialized
INFO - 2016-10-28 17:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:17:25 --> Controller Class Initialized
INFO - 2016-10-28 17:17:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:17:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:17:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:17:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:17:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:17:25 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:17:25 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:17:25 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:17:30 --> Config Class Initialized
INFO - 2016-10-28 17:17:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:17:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:17:30 --> Utf8 Class Initialized
INFO - 2016-10-28 17:17:30 --> URI Class Initialized
DEBUG - 2016-10-28 17:17:30 --> No URI present. Default controller set.
INFO - 2016-10-28 17:17:30 --> Router Class Initialized
INFO - 2016-10-28 17:17:30 --> Output Class Initialized
INFO - 2016-10-28 17:17:30 --> Security Class Initialized
DEBUG - 2016-10-28 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:17:30 --> Input Class Initialized
INFO - 2016-10-28 17:17:30 --> Language Class Initialized
INFO - 2016-10-28 17:17:30 --> Loader Class Initialized
INFO - 2016-10-28 17:17:30 --> Helper loaded: url_helper
INFO - 2016-10-28 17:17:30 --> Helper loaded: form_helper
INFO - 2016-10-28 17:17:30 --> Database Driver Class Initialized
INFO - 2016-10-28 17:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:17:30 --> Controller Class Initialized
INFO - 2016-10-28 17:17:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:17:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:17:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:17:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:17:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:17:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:17:30 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:17:30 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:17:31 --> Config Class Initialized
INFO - 2016-10-28 17:17:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:17:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:17:31 --> Utf8 Class Initialized
INFO - 2016-10-28 17:17:31 --> URI Class Initialized
DEBUG - 2016-10-28 17:17:31 --> No URI present. Default controller set.
INFO - 2016-10-28 17:17:31 --> Router Class Initialized
INFO - 2016-10-28 17:17:31 --> Output Class Initialized
INFO - 2016-10-28 17:17:31 --> Security Class Initialized
DEBUG - 2016-10-28 17:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:17:31 --> Input Class Initialized
INFO - 2016-10-28 17:17:31 --> Language Class Initialized
INFO - 2016-10-28 17:17:31 --> Loader Class Initialized
INFO - 2016-10-28 17:17:31 --> Helper loaded: url_helper
INFO - 2016-10-28 17:17:31 --> Helper loaded: form_helper
INFO - 2016-10-28 17:17:31 --> Database Driver Class Initialized
INFO - 2016-10-28 17:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:17:31 --> Controller Class Initialized
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:17:31 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:17:31 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:17:31 --> Config Class Initialized
INFO - 2016-10-28 17:17:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:17:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:17:31 --> Utf8 Class Initialized
INFO - 2016-10-28 17:17:31 --> URI Class Initialized
DEBUG - 2016-10-28 17:17:31 --> No URI present. Default controller set.
INFO - 2016-10-28 17:17:31 --> Router Class Initialized
INFO - 2016-10-28 17:17:31 --> Output Class Initialized
INFO - 2016-10-28 17:17:31 --> Security Class Initialized
DEBUG - 2016-10-28 17:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:17:31 --> Input Class Initialized
INFO - 2016-10-28 17:17:31 --> Language Class Initialized
INFO - 2016-10-28 17:17:31 --> Loader Class Initialized
INFO - 2016-10-28 17:17:31 --> Helper loaded: url_helper
INFO - 2016-10-28 17:17:31 --> Helper loaded: form_helper
INFO - 2016-10-28 17:17:31 --> Database Driver Class Initialized
INFO - 2016-10-28 17:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:17:31 --> Controller Class Initialized
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:17:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:17:31 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:17:31 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:17:39 --> Config Class Initialized
INFO - 2016-10-28 17:17:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:17:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:17:39 --> Utf8 Class Initialized
INFO - 2016-10-28 17:17:39 --> URI Class Initialized
DEBUG - 2016-10-28 17:17:39 --> No URI present. Default controller set.
INFO - 2016-10-28 17:17:39 --> Router Class Initialized
INFO - 2016-10-28 17:17:39 --> Output Class Initialized
INFO - 2016-10-28 17:17:39 --> Security Class Initialized
DEBUG - 2016-10-28 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:17:39 --> Input Class Initialized
INFO - 2016-10-28 17:17:39 --> Language Class Initialized
INFO - 2016-10-28 17:17:39 --> Loader Class Initialized
INFO - 2016-10-28 17:17:39 --> Helper loaded: url_helper
INFO - 2016-10-28 17:17:39 --> Helper loaded: form_helper
INFO - 2016-10-28 17:17:39 --> Database Driver Class Initialized
INFO - 2016-10-28 17:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:17:39 --> Controller Class Initialized
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:17:39 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:17:39 --> Final output sent to browser
DEBUG - 2016-10-28 17:17:39 --> Total execution time: 0.0177
INFO - 2016-10-28 17:23:40 --> Config Class Initialized
INFO - 2016-10-28 17:23:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:23:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:23:40 --> Utf8 Class Initialized
INFO - 2016-10-28 17:23:40 --> URI Class Initialized
DEBUG - 2016-10-28 17:23:40 --> No URI present. Default controller set.
INFO - 2016-10-28 17:23:40 --> Router Class Initialized
INFO - 2016-10-28 17:23:40 --> Output Class Initialized
INFO - 2016-10-28 17:23:40 --> Security Class Initialized
DEBUG - 2016-10-28 17:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:23:40 --> Input Class Initialized
INFO - 2016-10-28 17:23:40 --> Language Class Initialized
INFO - 2016-10-28 17:23:40 --> Loader Class Initialized
INFO - 2016-10-28 17:23:40 --> Helper loaded: url_helper
INFO - 2016-10-28 17:23:40 --> Helper loaded: form_helper
INFO - 2016-10-28 17:23:40 --> Database Driver Class Initialized
INFO - 2016-10-28 17:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:23:40 --> Controller Class Initialized
INFO - 2016-10-28 17:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:23:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:23:40 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:23:40 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:23:41 --> Config Class Initialized
INFO - 2016-10-28 17:23:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:23:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:23:41 --> Utf8 Class Initialized
INFO - 2016-10-28 17:23:41 --> URI Class Initialized
DEBUG - 2016-10-28 17:23:41 --> No URI present. Default controller set.
INFO - 2016-10-28 17:23:41 --> Router Class Initialized
INFO - 2016-10-28 17:23:41 --> Output Class Initialized
INFO - 2016-10-28 17:23:41 --> Security Class Initialized
DEBUG - 2016-10-28 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:23:41 --> Input Class Initialized
INFO - 2016-10-28 17:23:41 --> Language Class Initialized
INFO - 2016-10-28 17:23:41 --> Loader Class Initialized
INFO - 2016-10-28 17:23:41 --> Helper loaded: url_helper
INFO - 2016-10-28 17:23:41 --> Helper loaded: form_helper
INFO - 2016-10-28 17:23:41 --> Database Driver Class Initialized
INFO - 2016-10-28 17:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:23:41 --> Controller Class Initialized
INFO - 2016-10-28 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:23:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:23:41 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:23:41 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:27:29 --> Config Class Initialized
INFO - 2016-10-28 17:27:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:27:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:27:29 --> Utf8 Class Initialized
INFO - 2016-10-28 17:27:29 --> URI Class Initialized
DEBUG - 2016-10-28 17:27:29 --> No URI present. Default controller set.
INFO - 2016-10-28 17:27:29 --> Router Class Initialized
INFO - 2016-10-28 17:27:29 --> Output Class Initialized
INFO - 2016-10-28 17:27:29 --> Security Class Initialized
DEBUG - 2016-10-28 17:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:27:29 --> Input Class Initialized
INFO - 2016-10-28 17:27:29 --> Language Class Initialized
INFO - 2016-10-28 17:27:29 --> Loader Class Initialized
INFO - 2016-10-28 17:27:29 --> Helper loaded: url_helper
INFO - 2016-10-28 17:27:29 --> Helper loaded: form_helper
INFO - 2016-10-28 17:27:29 --> Database Driver Class Initialized
INFO - 2016-10-28 17:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:27:29 --> Controller Class Initialized
INFO - 2016-10-28 17:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:27:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:27:29 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:27:29 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:28 --> Config Class Initialized
INFO - 2016-10-28 17:29:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:28 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:28 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:28 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:28 --> Router Class Initialized
INFO - 2016-10-28 17:29:28 --> Output Class Initialized
INFO - 2016-10-28 17:29:28 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:28 --> Input Class Initialized
INFO - 2016-10-28 17:29:28 --> Language Class Initialized
INFO - 2016-10-28 17:29:28 --> Loader Class Initialized
INFO - 2016-10-28 17:29:28 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:28 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:28 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:28 --> Controller Class Initialized
INFO - 2016-10-28 17:29:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:28 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:28 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:29 --> Config Class Initialized
INFO - 2016-10-28 17:29:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:29 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:29 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:29 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:29 --> Router Class Initialized
INFO - 2016-10-28 17:29:29 --> Output Class Initialized
INFO - 2016-10-28 17:29:29 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:29 --> Input Class Initialized
INFO - 2016-10-28 17:29:29 --> Language Class Initialized
INFO - 2016-10-28 17:29:29 --> Loader Class Initialized
INFO - 2016-10-28 17:29:29 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:29 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:29 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:29 --> Controller Class Initialized
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:29 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:29 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:29 --> Config Class Initialized
INFO - 2016-10-28 17:29:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:29 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:29 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:29 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:29 --> Router Class Initialized
INFO - 2016-10-28 17:29:29 --> Output Class Initialized
INFO - 2016-10-28 17:29:29 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:29 --> Input Class Initialized
INFO - 2016-10-28 17:29:29 --> Language Class Initialized
INFO - 2016-10-28 17:29:29 --> Loader Class Initialized
INFO - 2016-10-28 17:29:29 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:29 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:29 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:29 --> Controller Class Initialized
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:29 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:29 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:30 --> Config Class Initialized
INFO - 2016-10-28 17:29:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:30 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:30 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:30 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:30 --> Router Class Initialized
INFO - 2016-10-28 17:29:30 --> Output Class Initialized
INFO - 2016-10-28 17:29:30 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:30 --> Input Class Initialized
INFO - 2016-10-28 17:29:30 --> Language Class Initialized
INFO - 2016-10-28 17:29:30 --> Loader Class Initialized
INFO - 2016-10-28 17:29:30 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:30 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:30 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:30 --> Controller Class Initialized
INFO - 2016-10-28 17:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:30 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:30 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:33 --> Config Class Initialized
INFO - 2016-10-28 17:29:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:33 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:33 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:33 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:33 --> Router Class Initialized
INFO - 2016-10-28 17:29:33 --> Output Class Initialized
INFO - 2016-10-28 17:29:33 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:33 --> Input Class Initialized
INFO - 2016-10-28 17:29:33 --> Language Class Initialized
INFO - 2016-10-28 17:29:33 --> Loader Class Initialized
INFO - 2016-10-28 17:29:33 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:33 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:33 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:33 --> Controller Class Initialized
INFO - 2016-10-28 17:29:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:33 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:33 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:34 --> Config Class Initialized
INFO - 2016-10-28 17:29:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:34 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:34 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:34 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:34 --> Router Class Initialized
INFO - 2016-10-28 17:29:34 --> Output Class Initialized
INFO - 2016-10-28 17:29:34 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:34 --> Input Class Initialized
INFO - 2016-10-28 17:29:34 --> Language Class Initialized
INFO - 2016-10-28 17:29:34 --> Loader Class Initialized
INFO - 2016-10-28 17:29:34 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:34 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:34 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:34 --> Controller Class Initialized
INFO - 2016-10-28 17:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:34 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:34 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:29:59 --> Config Class Initialized
INFO - 2016-10-28 17:29:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:29:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:29:59 --> Utf8 Class Initialized
INFO - 2016-10-28 17:29:59 --> URI Class Initialized
DEBUG - 2016-10-28 17:29:59 --> No URI present. Default controller set.
INFO - 2016-10-28 17:29:59 --> Router Class Initialized
INFO - 2016-10-28 17:29:59 --> Output Class Initialized
INFO - 2016-10-28 17:29:59 --> Security Class Initialized
DEBUG - 2016-10-28 17:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:29:59 --> Input Class Initialized
INFO - 2016-10-28 17:29:59 --> Language Class Initialized
INFO - 2016-10-28 17:29:59 --> Loader Class Initialized
INFO - 2016-10-28 17:29:59 --> Helper loaded: url_helper
INFO - 2016-10-28 17:29:59 --> Helper loaded: form_helper
INFO - 2016-10-28 17:29:59 --> Database Driver Class Initialized
INFO - 2016-10-28 17:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:29:59 --> Controller Class Initialized
INFO - 2016-10-28 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:29:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:29:59 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:29:59 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:00 --> Config Class Initialized
INFO - 2016-10-28 17:30:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:00 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:00 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:00 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:00 --> Router Class Initialized
INFO - 2016-10-28 17:30:00 --> Output Class Initialized
INFO - 2016-10-28 17:30:00 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:00 --> Input Class Initialized
INFO - 2016-10-28 17:30:00 --> Language Class Initialized
INFO - 2016-10-28 17:30:00 --> Loader Class Initialized
INFO - 2016-10-28 17:30:00 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:00 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:00 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:00 --> Controller Class Initialized
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:00 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:00 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:00 --> Config Class Initialized
INFO - 2016-10-28 17:30:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:00 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:00 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:00 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:00 --> Router Class Initialized
INFO - 2016-10-28 17:30:00 --> Output Class Initialized
INFO - 2016-10-28 17:30:00 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:00 --> Input Class Initialized
INFO - 2016-10-28 17:30:00 --> Language Class Initialized
INFO - 2016-10-28 17:30:00 --> Loader Class Initialized
INFO - 2016-10-28 17:30:00 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:00 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:00 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:00 --> Controller Class Initialized
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:00 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:00 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:00 --> Config Class Initialized
INFO - 2016-10-28 17:30:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:00 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:00 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:00 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:00 --> Router Class Initialized
INFO - 2016-10-28 17:30:00 --> Output Class Initialized
INFO - 2016-10-28 17:30:00 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:00 --> Input Class Initialized
INFO - 2016-10-28 17:30:00 --> Language Class Initialized
INFO - 2016-10-28 17:30:00 --> Loader Class Initialized
INFO - 2016-10-28 17:30:00 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:00 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:00 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:00 --> Controller Class Initialized
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:00 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:00 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:16 --> Config Class Initialized
INFO - 2016-10-28 17:30:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:16 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:16 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:16 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:16 --> Router Class Initialized
INFO - 2016-10-28 17:30:16 --> Output Class Initialized
INFO - 2016-10-28 17:30:16 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:16 --> Input Class Initialized
INFO - 2016-10-28 17:30:16 --> Language Class Initialized
INFO - 2016-10-28 17:30:16 --> Loader Class Initialized
INFO - 2016-10-28 17:30:16 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:16 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:16 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:16 --> Controller Class Initialized
INFO - 2016-10-28 17:30:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:16 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:16 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:17 --> Config Class Initialized
INFO - 2016-10-28 17:30:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:17 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:17 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:17 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:17 --> Router Class Initialized
INFO - 2016-10-28 17:30:17 --> Output Class Initialized
INFO - 2016-10-28 17:30:17 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:17 --> Input Class Initialized
INFO - 2016-10-28 17:30:17 --> Language Class Initialized
INFO - 2016-10-28 17:30:17 --> Loader Class Initialized
INFO - 2016-10-28 17:30:17 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:17 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:17 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:17 --> Controller Class Initialized
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:17 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:17 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:17 --> Config Class Initialized
INFO - 2016-10-28 17:30:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:17 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:17 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:17 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:17 --> Router Class Initialized
INFO - 2016-10-28 17:30:17 --> Output Class Initialized
INFO - 2016-10-28 17:30:17 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:17 --> Input Class Initialized
INFO - 2016-10-28 17:30:17 --> Language Class Initialized
INFO - 2016-10-28 17:30:17 --> Loader Class Initialized
INFO - 2016-10-28 17:30:17 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:17 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:17 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:17 --> Controller Class Initialized
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:17 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:17 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:17 --> Config Class Initialized
INFO - 2016-10-28 17:30:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:17 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:17 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:17 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:17 --> Router Class Initialized
INFO - 2016-10-28 17:30:17 --> Output Class Initialized
INFO - 2016-10-28 17:30:17 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:17 --> Input Class Initialized
INFO - 2016-10-28 17:30:17 --> Language Class Initialized
INFO - 2016-10-28 17:30:17 --> Loader Class Initialized
INFO - 2016-10-28 17:30:17 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:17 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:17 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:17 --> Controller Class Initialized
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:17 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:17 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:17 --> Config Class Initialized
INFO - 2016-10-28 17:30:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:17 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:17 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:17 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:17 --> Router Class Initialized
INFO - 2016-10-28 17:30:17 --> Output Class Initialized
INFO - 2016-10-28 17:30:17 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:17 --> Input Class Initialized
INFO - 2016-10-28 17:30:17 --> Language Class Initialized
INFO - 2016-10-28 17:30:17 --> Loader Class Initialized
INFO - 2016-10-28 17:30:17 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:17 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:17 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:17 --> Controller Class Initialized
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:17 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:17 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:30:17 --> Config Class Initialized
INFO - 2016-10-28 17:30:17 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:30:17 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:30:17 --> Utf8 Class Initialized
INFO - 2016-10-28 17:30:17 --> URI Class Initialized
DEBUG - 2016-10-28 17:30:17 --> No URI present. Default controller set.
INFO - 2016-10-28 17:30:17 --> Router Class Initialized
INFO - 2016-10-28 17:30:17 --> Output Class Initialized
INFO - 2016-10-28 17:30:17 --> Security Class Initialized
DEBUG - 2016-10-28 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:30:17 --> Input Class Initialized
INFO - 2016-10-28 17:30:17 --> Language Class Initialized
INFO - 2016-10-28 17:30:17 --> Loader Class Initialized
INFO - 2016-10-28 17:30:17 --> Helper loaded: url_helper
INFO - 2016-10-28 17:30:17 --> Helper loaded: form_helper
INFO - 2016-10-28 17:30:17 --> Database Driver Class Initialized
INFO - 2016-10-28 17:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:30:17 --> Controller Class Initialized
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:30:17 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:30:17 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:30:17 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:31:00 --> Config Class Initialized
INFO - 2016-10-28 17:31:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:31:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:31:00 --> Utf8 Class Initialized
INFO - 2016-10-28 17:31:00 --> URI Class Initialized
DEBUG - 2016-10-28 17:31:00 --> No URI present. Default controller set.
INFO - 2016-10-28 17:31:00 --> Router Class Initialized
INFO - 2016-10-28 17:31:00 --> Output Class Initialized
INFO - 2016-10-28 17:31:00 --> Security Class Initialized
DEBUG - 2016-10-28 17:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:31:00 --> Input Class Initialized
INFO - 2016-10-28 17:31:00 --> Language Class Initialized
INFO - 2016-10-28 17:31:00 --> Loader Class Initialized
INFO - 2016-10-28 17:31:00 --> Helper loaded: url_helper
INFO - 2016-10-28 17:31:00 --> Helper loaded: form_helper
INFO - 2016-10-28 17:31:00 --> Database Driver Class Initialized
INFO - 2016-10-28 17:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:31:00 --> Controller Class Initialized
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:31:00 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:31:00 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:31:00 --> Config Class Initialized
INFO - 2016-10-28 17:31:00 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:31:00 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:31:00 --> Utf8 Class Initialized
INFO - 2016-10-28 17:31:00 --> URI Class Initialized
DEBUG - 2016-10-28 17:31:00 --> No URI present. Default controller set.
INFO - 2016-10-28 17:31:00 --> Router Class Initialized
INFO - 2016-10-28 17:31:00 --> Output Class Initialized
INFO - 2016-10-28 17:31:00 --> Security Class Initialized
DEBUG - 2016-10-28 17:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:31:00 --> Input Class Initialized
INFO - 2016-10-28 17:31:00 --> Language Class Initialized
INFO - 2016-10-28 17:31:00 --> Loader Class Initialized
INFO - 2016-10-28 17:31:00 --> Helper loaded: url_helper
INFO - 2016-10-28 17:31:00 --> Helper loaded: form_helper
INFO - 2016-10-28 17:31:00 --> Database Driver Class Initialized
INFO - 2016-10-28 17:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:31:00 --> Controller Class Initialized
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:31:00 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:31:00 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:31:00 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:31:11 --> Config Class Initialized
INFO - 2016-10-28 17:31:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:31:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:31:11 --> Utf8 Class Initialized
INFO - 2016-10-28 17:31:11 --> URI Class Initialized
DEBUG - 2016-10-28 17:31:11 --> No URI present. Default controller set.
INFO - 2016-10-28 17:31:11 --> Router Class Initialized
INFO - 2016-10-28 17:31:11 --> Output Class Initialized
INFO - 2016-10-28 17:31:11 --> Security Class Initialized
DEBUG - 2016-10-28 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:31:11 --> Input Class Initialized
INFO - 2016-10-28 17:31:11 --> Language Class Initialized
INFO - 2016-10-28 17:31:11 --> Loader Class Initialized
INFO - 2016-10-28 17:31:11 --> Helper loaded: url_helper
INFO - 2016-10-28 17:31:11 --> Helper loaded: form_helper
INFO - 2016-10-28 17:31:11 --> Database Driver Class Initialized
INFO - 2016-10-28 17:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:31:11 --> Controller Class Initialized
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:31:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:31:11 --> Final output sent to browser
DEBUG - 2016-10-28 17:31:11 --> Total execution time: 0.0175
INFO - 2016-10-28 17:31:30 --> Config Class Initialized
INFO - 2016-10-28 17:31:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:31:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:31:30 --> Utf8 Class Initialized
INFO - 2016-10-28 17:31:30 --> URI Class Initialized
DEBUG - 2016-10-28 17:31:30 --> No URI present. Default controller set.
INFO - 2016-10-28 17:31:30 --> Router Class Initialized
INFO - 2016-10-28 17:31:30 --> Output Class Initialized
INFO - 2016-10-28 17:31:30 --> Security Class Initialized
DEBUG - 2016-10-28 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:31:30 --> Input Class Initialized
INFO - 2016-10-28 17:31:30 --> Language Class Initialized
INFO - 2016-10-28 17:31:30 --> Loader Class Initialized
INFO - 2016-10-28 17:31:30 --> Helper loaded: url_helper
INFO - 2016-10-28 17:31:30 --> Helper loaded: form_helper
INFO - 2016-10-28 17:31:30 --> Database Driver Class Initialized
INFO - 2016-10-28 17:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:31:30 --> Controller Class Initialized
INFO - 2016-10-28 17:31:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:31:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:31:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:31:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:31:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:31:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:31:30 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:31:30 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:31:31 --> Config Class Initialized
INFO - 2016-10-28 17:31:31 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:31:31 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:31:31 --> Utf8 Class Initialized
INFO - 2016-10-28 17:31:31 --> URI Class Initialized
DEBUG - 2016-10-28 17:31:31 --> No URI present. Default controller set.
INFO - 2016-10-28 17:31:31 --> Router Class Initialized
INFO - 2016-10-28 17:31:31 --> Output Class Initialized
INFO - 2016-10-28 17:31:31 --> Security Class Initialized
DEBUG - 2016-10-28 17:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:31:31 --> Input Class Initialized
INFO - 2016-10-28 17:31:31 --> Language Class Initialized
INFO - 2016-10-28 17:31:31 --> Loader Class Initialized
INFO - 2016-10-28 17:31:31 --> Helper loaded: url_helper
INFO - 2016-10-28 17:31:31 --> Helper loaded: form_helper
INFO - 2016-10-28 17:31:31 --> Database Driver Class Initialized
INFO - 2016-10-28 17:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:31:31 --> Controller Class Initialized
INFO - 2016-10-28 17:31:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:31:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:31:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:31:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:31:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:31:31 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:31:31 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:31:31 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:34:36 --> Config Class Initialized
INFO - 2016-10-28 17:34:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:34:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:34:36 --> Utf8 Class Initialized
INFO - 2016-10-28 17:34:36 --> URI Class Initialized
DEBUG - 2016-10-28 17:34:36 --> No URI present. Default controller set.
INFO - 2016-10-28 17:34:36 --> Router Class Initialized
INFO - 2016-10-28 17:34:36 --> Output Class Initialized
INFO - 2016-10-28 17:34:36 --> Security Class Initialized
DEBUG - 2016-10-28 17:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:34:36 --> Input Class Initialized
INFO - 2016-10-28 17:34:36 --> Language Class Initialized
INFO - 2016-10-28 17:34:36 --> Loader Class Initialized
INFO - 2016-10-28 17:34:36 --> Helper loaded: url_helper
INFO - 2016-10-28 17:34:36 --> Helper loaded: form_helper
INFO - 2016-10-28 17:34:36 --> Database Driver Class Initialized
INFO - 2016-10-28 17:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:34:36 --> Controller Class Initialized
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:34:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:34:36 --> Final output sent to browser
DEBUG - 2016-10-28 17:34:36 --> Total execution time: 0.0179
INFO - 2016-10-28 17:34:40 --> Config Class Initialized
INFO - 2016-10-28 17:34:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:34:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:34:40 --> Utf8 Class Initialized
INFO - 2016-10-28 17:34:40 --> URI Class Initialized
INFO - 2016-10-28 17:34:40 --> Router Class Initialized
INFO - 2016-10-28 17:34:40 --> Output Class Initialized
INFO - 2016-10-28 17:34:40 --> Security Class Initialized
DEBUG - 2016-10-28 17:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:34:40 --> Input Class Initialized
INFO - 2016-10-28 17:34:40 --> Language Class Initialized
INFO - 2016-10-28 17:34:40 --> Loader Class Initialized
INFO - 2016-10-28 17:34:40 --> Helper loaded: url_helper
INFO - 2016-10-28 17:34:40 --> Helper loaded: form_helper
INFO - 2016-10-28 17:34:40 --> Database Driver Class Initialized
INFO - 2016-10-28 17:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:34:40 --> Controller Class Initialized
INFO - 2016-10-28 17:34:40 --> Form Validation Class Initialized
INFO - 2016-10-28 17:34:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 17:34:40 --> Final output sent to browser
DEBUG - 2016-10-28 17:34:40 --> Total execution time: 0.0171
INFO - 2016-10-28 17:37:40 --> Config Class Initialized
INFO - 2016-10-28 17:37:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:37:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:37:40 --> Utf8 Class Initialized
INFO - 2016-10-28 17:37:40 --> URI Class Initialized
DEBUG - 2016-10-28 17:37:40 --> No URI present. Default controller set.
INFO - 2016-10-28 17:37:40 --> Router Class Initialized
INFO - 2016-10-28 17:37:40 --> Output Class Initialized
INFO - 2016-10-28 17:37:40 --> Security Class Initialized
DEBUG - 2016-10-28 17:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:37:40 --> Input Class Initialized
INFO - 2016-10-28 17:37:40 --> Language Class Initialized
INFO - 2016-10-28 17:37:40 --> Loader Class Initialized
INFO - 2016-10-28 17:37:40 --> Helper loaded: url_helper
INFO - 2016-10-28 17:37:40 --> Helper loaded: form_helper
INFO - 2016-10-28 17:37:40 --> Database Driver Class Initialized
INFO - 2016-10-28 17:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:37:40 --> Controller Class Initialized
INFO - 2016-10-28 17:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:37:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:37:40 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:37:40 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:38:38 --> Config Class Initialized
INFO - 2016-10-28 17:38:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:38:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:38:38 --> Utf8 Class Initialized
INFO - 2016-10-28 17:38:38 --> URI Class Initialized
DEBUG - 2016-10-28 17:38:38 --> No URI present. Default controller set.
INFO - 2016-10-28 17:38:38 --> Router Class Initialized
INFO - 2016-10-28 17:38:38 --> Output Class Initialized
INFO - 2016-10-28 17:38:38 --> Security Class Initialized
DEBUG - 2016-10-28 17:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:38:38 --> Input Class Initialized
INFO - 2016-10-28 17:38:38 --> Language Class Initialized
INFO - 2016-10-28 17:38:38 --> Loader Class Initialized
INFO - 2016-10-28 17:38:38 --> Helper loaded: url_helper
INFO - 2016-10-28 17:38:38 --> Helper loaded: form_helper
INFO - 2016-10-28 17:38:38 --> Database Driver Class Initialized
INFO - 2016-10-28 17:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:38:38 --> Controller Class Initialized
INFO - 2016-10-28 17:38:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:38:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:38:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:38:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:38:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:38:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:38:38 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:38:38 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:38:40 --> Config Class Initialized
INFO - 2016-10-28 17:38:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:38:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:38:40 --> Utf8 Class Initialized
INFO - 2016-10-28 17:38:40 --> URI Class Initialized
DEBUG - 2016-10-28 17:38:40 --> No URI present. Default controller set.
INFO - 2016-10-28 17:38:40 --> Router Class Initialized
INFO - 2016-10-28 17:38:40 --> Output Class Initialized
INFO - 2016-10-28 17:38:40 --> Security Class Initialized
DEBUG - 2016-10-28 17:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:38:40 --> Input Class Initialized
INFO - 2016-10-28 17:38:40 --> Language Class Initialized
INFO - 2016-10-28 17:38:40 --> Loader Class Initialized
INFO - 2016-10-28 17:38:40 --> Helper loaded: url_helper
INFO - 2016-10-28 17:38:40 --> Helper loaded: form_helper
INFO - 2016-10-28 17:38:40 --> Database Driver Class Initialized
INFO - 2016-10-28 17:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:38:40 --> Controller Class Initialized
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:38:40 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:38:40 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:38:40 --> Config Class Initialized
INFO - 2016-10-28 17:38:40 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:38:40 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:38:40 --> Utf8 Class Initialized
INFO - 2016-10-28 17:38:40 --> URI Class Initialized
DEBUG - 2016-10-28 17:38:40 --> No URI present. Default controller set.
INFO - 2016-10-28 17:38:40 --> Router Class Initialized
INFO - 2016-10-28 17:38:40 --> Output Class Initialized
INFO - 2016-10-28 17:38:40 --> Security Class Initialized
DEBUG - 2016-10-28 17:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:38:40 --> Input Class Initialized
INFO - 2016-10-28 17:38:40 --> Language Class Initialized
INFO - 2016-10-28 17:38:40 --> Loader Class Initialized
INFO - 2016-10-28 17:38:40 --> Helper loaded: url_helper
INFO - 2016-10-28 17:38:40 --> Helper loaded: form_helper
INFO - 2016-10-28 17:38:40 --> Database Driver Class Initialized
INFO - 2016-10-28 17:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:38:40 --> Controller Class Initialized
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:38:40 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:38:40 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:38:40 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:40:03 --> Config Class Initialized
INFO - 2016-10-28 17:40:03 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:40:03 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:40:03 --> Utf8 Class Initialized
INFO - 2016-10-28 17:40:03 --> URI Class Initialized
DEBUG - 2016-10-28 17:40:03 --> No URI present. Default controller set.
INFO - 2016-10-28 17:40:03 --> Router Class Initialized
INFO - 2016-10-28 17:40:03 --> Output Class Initialized
INFO - 2016-10-28 17:40:03 --> Security Class Initialized
DEBUG - 2016-10-28 17:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:40:03 --> Input Class Initialized
INFO - 2016-10-28 17:40:03 --> Language Class Initialized
INFO - 2016-10-28 17:40:03 --> Loader Class Initialized
INFO - 2016-10-28 17:40:03 --> Helper loaded: url_helper
INFO - 2016-10-28 17:40:03 --> Helper loaded: form_helper
INFO - 2016-10-28 17:40:03 --> Database Driver Class Initialized
INFO - 2016-10-28 17:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:40:03 --> Controller Class Initialized
INFO - 2016-10-28 17:40:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:40:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:40:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:40:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:40:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:40:03 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:40:03 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:40:03 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:40:04 --> Config Class Initialized
INFO - 2016-10-28 17:40:04 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:40:04 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:40:04 --> Utf8 Class Initialized
INFO - 2016-10-28 17:40:04 --> URI Class Initialized
DEBUG - 2016-10-28 17:40:04 --> No URI present. Default controller set.
INFO - 2016-10-28 17:40:04 --> Router Class Initialized
INFO - 2016-10-28 17:40:04 --> Output Class Initialized
INFO - 2016-10-28 17:40:04 --> Security Class Initialized
DEBUG - 2016-10-28 17:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:40:04 --> Input Class Initialized
INFO - 2016-10-28 17:40:04 --> Language Class Initialized
INFO - 2016-10-28 17:40:04 --> Loader Class Initialized
INFO - 2016-10-28 17:40:04 --> Helper loaded: url_helper
INFO - 2016-10-28 17:40:04 --> Helper loaded: form_helper
INFO - 2016-10-28 17:40:04 --> Database Driver Class Initialized
INFO - 2016-10-28 17:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:40:04 --> Controller Class Initialized
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:40:04 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:40:04 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:40:04 --> Config Class Initialized
INFO - 2016-10-28 17:40:04 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:40:04 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:40:04 --> Utf8 Class Initialized
INFO - 2016-10-28 17:40:04 --> URI Class Initialized
DEBUG - 2016-10-28 17:40:04 --> No URI present. Default controller set.
INFO - 2016-10-28 17:40:04 --> Router Class Initialized
INFO - 2016-10-28 17:40:04 --> Output Class Initialized
INFO - 2016-10-28 17:40:04 --> Security Class Initialized
DEBUG - 2016-10-28 17:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:40:04 --> Input Class Initialized
INFO - 2016-10-28 17:40:04 --> Language Class Initialized
INFO - 2016-10-28 17:40:04 --> Loader Class Initialized
INFO - 2016-10-28 17:40:04 --> Helper loaded: url_helper
INFO - 2016-10-28 17:40:04 --> Helper loaded: form_helper
INFO - 2016-10-28 17:40:04 --> Database Driver Class Initialized
INFO - 2016-10-28 17:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:40:04 --> Controller Class Initialized
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:40:04 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:40:04 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:40:04 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:40:27 --> Config Class Initialized
INFO - 2016-10-28 17:40:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:40:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:40:27 --> Utf8 Class Initialized
INFO - 2016-10-28 17:40:27 --> URI Class Initialized
INFO - 2016-10-28 17:40:27 --> Router Class Initialized
INFO - 2016-10-28 17:40:27 --> Output Class Initialized
INFO - 2016-10-28 17:40:27 --> Security Class Initialized
DEBUG - 2016-10-28 17:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:40:27 --> Input Class Initialized
INFO - 2016-10-28 17:40:27 --> Language Class Initialized
INFO - 2016-10-28 17:40:27 --> Loader Class Initialized
INFO - 2016-10-28 17:40:27 --> Helper loaded: url_helper
INFO - 2016-10-28 17:40:27 --> Helper loaded: form_helper
INFO - 2016-10-28 17:40:27 --> Database Driver Class Initialized
INFO - 2016-10-28 17:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:40:27 --> Controller Class Initialized
INFO - 2016-10-28 17:40:27 --> Model Class Initialized
INFO - 2016-10-28 17:40:34 --> Config Class Initialized
INFO - 2016-10-28 17:40:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:40:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:40:34 --> Utf8 Class Initialized
INFO - 2016-10-28 17:40:34 --> URI Class Initialized
INFO - 2016-10-28 17:40:34 --> Router Class Initialized
INFO - 2016-10-28 17:40:34 --> Output Class Initialized
INFO - 2016-10-28 17:40:34 --> Security Class Initialized
DEBUG - 2016-10-28 17:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:40:34 --> Input Class Initialized
INFO - 2016-10-28 17:40:34 --> Language Class Initialized
INFO - 2016-10-28 17:40:34 --> Loader Class Initialized
INFO - 2016-10-28 17:40:34 --> Helper loaded: url_helper
INFO - 2016-10-28 17:40:34 --> Helper loaded: form_helper
INFO - 2016-10-28 17:40:34 --> Database Driver Class Initialized
INFO - 2016-10-28 17:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:40:34 --> Controller Class Initialized
INFO - 2016-10-28 17:40:34 --> Model Class Initialized
ERROR - 2016-10-28 17:40:34 --> Severity: Notice --> Undefined property: stdClass::$numberOfleaves /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 17
ERROR - 2016-10-28 17:40:34 --> Severity: Notice --> Undefined property: stdClass::$numberOfleaves /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 17
ERROR - 2016-10-28 17:40:34 --> Severity: Notice --> Undefined property: stdClass::$numberOfleaves /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 17
ERROR - 2016-10-28 17:40:34 --> Severity: Notice --> Undefined property: stdClass::$numberOfleaves /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 17
ERROR - 2016-10-28 17:40:34 --> Severity: Notice --> Undefined variable: pagination_links /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 25
INFO - 2016-10-28 17:40:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:40:34 --> Final output sent to browser
DEBUG - 2016-10-28 17:40:34 --> Total execution time: 0.0193
INFO - 2016-10-28 17:40:59 --> Config Class Initialized
INFO - 2016-10-28 17:40:59 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:40:59 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:40:59 --> Utf8 Class Initialized
INFO - 2016-10-28 17:40:59 --> URI Class Initialized
INFO - 2016-10-28 17:40:59 --> Router Class Initialized
INFO - 2016-10-28 17:40:59 --> Output Class Initialized
INFO - 2016-10-28 17:40:59 --> Security Class Initialized
DEBUG - 2016-10-28 17:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:40:59 --> Input Class Initialized
INFO - 2016-10-28 17:40:59 --> Language Class Initialized
INFO - 2016-10-28 17:40:59 --> Loader Class Initialized
INFO - 2016-10-28 17:40:59 --> Helper loaded: url_helper
INFO - 2016-10-28 17:40:59 --> Helper loaded: form_helper
INFO - 2016-10-28 17:40:59 --> Database Driver Class Initialized
INFO - 2016-10-28 17:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:40:59 --> Controller Class Initialized
INFO - 2016-10-28 17:40:59 --> Model Class Initialized
ERROR - 2016-10-28 17:40:59 --> Severity: Notice --> Undefined variable: pagination_links /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 25
INFO - 2016-10-28 17:40:59 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:40:59 --> Final output sent to browser
DEBUG - 2016-10-28 17:40:59 --> Total execution time: 0.0211
INFO - 2016-10-28 17:41:46 --> Config Class Initialized
INFO - 2016-10-28 17:41:46 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:41:46 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:41:46 --> Utf8 Class Initialized
INFO - 2016-10-28 17:41:46 --> URI Class Initialized
INFO - 2016-10-28 17:41:46 --> Router Class Initialized
INFO - 2016-10-28 17:41:46 --> Output Class Initialized
INFO - 2016-10-28 17:41:46 --> Security Class Initialized
DEBUG - 2016-10-28 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:41:46 --> Input Class Initialized
INFO - 2016-10-28 17:41:46 --> Language Class Initialized
INFO - 2016-10-28 17:41:46 --> Loader Class Initialized
INFO - 2016-10-28 17:41:46 --> Helper loaded: url_helper
INFO - 2016-10-28 17:41:46 --> Helper loaded: form_helper
INFO - 2016-10-28 17:41:46 --> Database Driver Class Initialized
INFO - 2016-10-28 17:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:41:46 --> Controller Class Initialized
INFO - 2016-10-28 17:41:46 --> Model Class Initialized
INFO - 2016-10-28 17:41:46 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:41:46 --> Final output sent to browser
DEBUG - 2016-10-28 17:41:46 --> Total execution time: 0.0172
INFO - 2016-10-28 17:41:55 --> Config Class Initialized
INFO - 2016-10-28 17:41:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:41:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:41:55 --> Utf8 Class Initialized
INFO - 2016-10-28 17:41:55 --> URI Class Initialized
DEBUG - 2016-10-28 17:41:55 --> No URI present. Default controller set.
INFO - 2016-10-28 17:41:55 --> Router Class Initialized
INFO - 2016-10-28 17:41:55 --> Output Class Initialized
INFO - 2016-10-28 17:41:55 --> Security Class Initialized
DEBUG - 2016-10-28 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:41:55 --> Input Class Initialized
INFO - 2016-10-28 17:41:55 --> Language Class Initialized
INFO - 2016-10-28 17:41:55 --> Loader Class Initialized
INFO - 2016-10-28 17:41:55 --> Helper loaded: url_helper
INFO - 2016-10-28 17:41:55 --> Helper loaded: form_helper
INFO - 2016-10-28 17:41:55 --> Database Driver Class Initialized
INFO - 2016-10-28 17:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:41:55 --> Controller Class Initialized
INFO - 2016-10-28 17:41:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:41:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:41:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:41:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:41:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:41:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:41:55 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:41:55 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:45:01 --> Config Class Initialized
INFO - 2016-10-28 17:45:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:45:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:45:01 --> Utf8 Class Initialized
INFO - 2016-10-28 17:45:01 --> URI Class Initialized
DEBUG - 2016-10-28 17:45:01 --> No URI present. Default controller set.
INFO - 2016-10-28 17:45:01 --> Router Class Initialized
INFO - 2016-10-28 17:45:01 --> Output Class Initialized
INFO - 2016-10-28 17:45:01 --> Security Class Initialized
DEBUG - 2016-10-28 17:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:45:01 --> Input Class Initialized
INFO - 2016-10-28 17:45:01 --> Language Class Initialized
INFO - 2016-10-28 17:45:01 --> Loader Class Initialized
INFO - 2016-10-28 17:45:01 --> Helper loaded: url_helper
INFO - 2016-10-28 17:45:01 --> Helper loaded: form_helper
INFO - 2016-10-28 17:45:01 --> Database Driver Class Initialized
INFO - 2016-10-28 17:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:45:01 --> Controller Class Initialized
INFO - 2016-10-28 17:45:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:45:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:45:01 --> Model Class Initialized
INFO - 2016-10-28 17:45:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:45:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:45:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:45:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:45:01 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:45:01 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:45:02 --> Config Class Initialized
INFO - 2016-10-28 17:45:02 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:45:02 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:45:02 --> Utf8 Class Initialized
INFO - 2016-10-28 17:45:02 --> URI Class Initialized
DEBUG - 2016-10-28 17:45:02 --> No URI present. Default controller set.
INFO - 2016-10-28 17:45:02 --> Router Class Initialized
INFO - 2016-10-28 17:45:02 --> Output Class Initialized
INFO - 2016-10-28 17:45:02 --> Security Class Initialized
DEBUG - 2016-10-28 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:45:02 --> Input Class Initialized
INFO - 2016-10-28 17:45:02 --> Language Class Initialized
INFO - 2016-10-28 17:45:02 --> Loader Class Initialized
INFO - 2016-10-28 17:45:02 --> Helper loaded: url_helper
INFO - 2016-10-28 17:45:02 --> Helper loaded: form_helper
INFO - 2016-10-28 17:45:02 --> Database Driver Class Initialized
INFO - 2016-10-28 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:45:02 --> Controller Class Initialized
INFO - 2016-10-28 17:45:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:45:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:45:02 --> Model Class Initialized
INFO - 2016-10-28 17:45:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:45:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:45:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:45:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 17:45:02 --> Severity: Notice --> Undefined variable: query /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
ERROR - 2016-10-28 17:45:02 --> Severity: Error --> Call to a member function result() on a non-object /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 13
INFO - 2016-10-28 17:45:19 --> Config Class Initialized
INFO - 2016-10-28 17:45:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:45:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:45:19 --> Utf8 Class Initialized
INFO - 2016-10-28 17:45:19 --> URI Class Initialized
DEBUG - 2016-10-28 17:45:19 --> No URI present. Default controller set.
INFO - 2016-10-28 17:45:19 --> Router Class Initialized
INFO - 2016-10-28 17:45:19 --> Output Class Initialized
INFO - 2016-10-28 17:45:19 --> Security Class Initialized
DEBUG - 2016-10-28 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:45:19 --> Input Class Initialized
INFO - 2016-10-28 17:45:19 --> Language Class Initialized
INFO - 2016-10-28 17:45:19 --> Loader Class Initialized
INFO - 2016-10-28 17:45:19 --> Helper loaded: url_helper
INFO - 2016-10-28 17:45:19 --> Helper loaded: form_helper
INFO - 2016-10-28 17:45:19 --> Database Driver Class Initialized
INFO - 2016-10-28 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:45:19 --> Controller Class Initialized
INFO - 2016-10-28 17:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:45:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:45:19 --> Model Class Initialized
INFO - 2016-10-28 17:45:29 --> Config Class Initialized
INFO - 2016-10-28 17:45:29 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:45:29 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:45:29 --> Utf8 Class Initialized
INFO - 2016-10-28 17:45:29 --> URI Class Initialized
DEBUG - 2016-10-28 17:45:29 --> No URI present. Default controller set.
INFO - 2016-10-28 17:45:29 --> Router Class Initialized
INFO - 2016-10-28 17:45:29 --> Output Class Initialized
INFO - 2016-10-28 17:45:29 --> Security Class Initialized
DEBUG - 2016-10-28 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:45:29 --> Input Class Initialized
INFO - 2016-10-28 17:45:29 --> Language Class Initialized
INFO - 2016-10-28 17:45:29 --> Loader Class Initialized
INFO - 2016-10-28 17:45:29 --> Helper loaded: url_helper
INFO - 2016-10-28 17:45:29 --> Helper loaded: form_helper
INFO - 2016-10-28 17:45:29 --> Database Driver Class Initialized
INFO - 2016-10-28 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:45:29 --> Controller Class Initialized
INFO - 2016-10-28 17:45:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:45:29 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:45:29 --> Model Class Initialized
INFO - 2016-10-28 17:46:01 --> Config Class Initialized
INFO - 2016-10-28 17:46:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:46:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:46:01 --> Utf8 Class Initialized
INFO - 2016-10-28 17:46:01 --> URI Class Initialized
DEBUG - 2016-10-28 17:46:01 --> No URI present. Default controller set.
INFO - 2016-10-28 17:46:01 --> Router Class Initialized
INFO - 2016-10-28 17:46:01 --> Output Class Initialized
INFO - 2016-10-28 17:46:01 --> Security Class Initialized
DEBUG - 2016-10-28 17:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:46:01 --> Input Class Initialized
INFO - 2016-10-28 17:46:01 --> Language Class Initialized
INFO - 2016-10-28 17:46:01 --> Loader Class Initialized
INFO - 2016-10-28 17:46:01 --> Helper loaded: url_helper
INFO - 2016-10-28 17:46:01 --> Helper loaded: form_helper
INFO - 2016-10-28 17:46:01 --> Database Driver Class Initialized
INFO - 2016-10-28 17:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:46:01 --> Controller Class Initialized
INFO - 2016-10-28 17:46:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:46:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:46:01 --> Model Class Initialized
INFO - 2016-10-28 17:46:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:46:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:46:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:46:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:46:30 --> Config Class Initialized
INFO - 2016-10-28 17:46:30 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:46:30 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:46:30 --> Utf8 Class Initialized
INFO - 2016-10-28 17:46:30 --> URI Class Initialized
DEBUG - 2016-10-28 17:46:30 --> No URI present. Default controller set.
INFO - 2016-10-28 17:46:30 --> Router Class Initialized
INFO - 2016-10-28 17:46:30 --> Output Class Initialized
INFO - 2016-10-28 17:46:30 --> Security Class Initialized
DEBUG - 2016-10-28 17:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:46:30 --> Input Class Initialized
INFO - 2016-10-28 17:46:30 --> Language Class Initialized
INFO - 2016-10-28 17:46:30 --> Loader Class Initialized
INFO - 2016-10-28 17:46:30 --> Helper loaded: url_helper
INFO - 2016-10-28 17:46:30 --> Helper loaded: form_helper
INFO - 2016-10-28 17:46:30 --> Database Driver Class Initialized
INFO - 2016-10-28 17:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:46:30 --> Controller Class Initialized
INFO - 2016-10-28 17:46:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:46:30 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:46:30 --> Model Class Initialized
ERROR - 2016-10-28 17:46:30 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 90
INFO - 2016-10-28 17:46:45 --> Config Class Initialized
INFO - 2016-10-28 17:46:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:46:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:46:45 --> Utf8 Class Initialized
INFO - 2016-10-28 17:46:45 --> URI Class Initialized
DEBUG - 2016-10-28 17:46:45 --> No URI present. Default controller set.
INFO - 2016-10-28 17:46:45 --> Router Class Initialized
INFO - 2016-10-28 17:46:45 --> Output Class Initialized
INFO - 2016-10-28 17:46:45 --> Security Class Initialized
DEBUG - 2016-10-28 17:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:46:45 --> Input Class Initialized
INFO - 2016-10-28 17:46:45 --> Language Class Initialized
INFO - 2016-10-28 17:46:45 --> Loader Class Initialized
INFO - 2016-10-28 17:46:45 --> Helper loaded: url_helper
INFO - 2016-10-28 17:46:45 --> Helper loaded: form_helper
INFO - 2016-10-28 17:46:45 --> Database Driver Class Initialized
INFO - 2016-10-28 17:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:46:45 --> Controller Class Initialized
INFO - 2016-10-28 17:46:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:46:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:46:45 --> Model Class Initialized
INFO - 2016-10-28 17:46:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:46:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:46:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:46:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:47:18 --> Config Class Initialized
INFO - 2016-10-28 17:47:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:47:18 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:47:18 --> Utf8 Class Initialized
INFO - 2016-10-28 17:47:18 --> URI Class Initialized
DEBUG - 2016-10-28 17:47:18 --> No URI present. Default controller set.
INFO - 2016-10-28 17:47:18 --> Router Class Initialized
INFO - 2016-10-28 17:47:18 --> Output Class Initialized
INFO - 2016-10-28 17:47:18 --> Security Class Initialized
DEBUG - 2016-10-28 17:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:47:18 --> Input Class Initialized
INFO - 2016-10-28 17:47:18 --> Language Class Initialized
INFO - 2016-10-28 17:47:18 --> Loader Class Initialized
INFO - 2016-10-28 17:47:18 --> Helper loaded: url_helper
INFO - 2016-10-28 17:47:18 --> Helper loaded: form_helper
INFO - 2016-10-28 17:47:18 --> Database Driver Class Initialized
INFO - 2016-10-28 17:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:47:18 --> Controller Class Initialized
INFO - 2016-10-28 17:47:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:47:18 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:47:18 --> Model Class Initialized
ERROR - 2016-10-28 17:47:18 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php 90
INFO - 2016-10-28 17:47:34 --> Config Class Initialized
INFO - 2016-10-28 17:47:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:47:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:47:34 --> Utf8 Class Initialized
INFO - 2016-10-28 17:47:34 --> URI Class Initialized
DEBUG - 2016-10-28 17:47:34 --> No URI present. Default controller set.
INFO - 2016-10-28 17:47:34 --> Router Class Initialized
INFO - 2016-10-28 17:47:34 --> Output Class Initialized
INFO - 2016-10-28 17:47:34 --> Security Class Initialized
DEBUG - 2016-10-28 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:47:34 --> Input Class Initialized
INFO - 2016-10-28 17:47:34 --> Language Class Initialized
INFO - 2016-10-28 17:47:34 --> Loader Class Initialized
INFO - 2016-10-28 17:47:34 --> Helper loaded: url_helper
INFO - 2016-10-28 17:47:34 --> Helper loaded: form_helper
INFO - 2016-10-28 17:47:34 --> Database Driver Class Initialized
INFO - 2016-10-28 17:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:47:34 --> Controller Class Initialized
INFO - 2016-10-28 17:47:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:47:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:47:34 --> Model Class Initialized
INFO - 2016-10-28 17:47:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:47:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:47:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:47:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:47:44 --> Config Class Initialized
INFO - 2016-10-28 17:47:44 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:47:44 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:47:44 --> Utf8 Class Initialized
INFO - 2016-10-28 17:47:44 --> URI Class Initialized
DEBUG - 2016-10-28 17:47:44 --> No URI present. Default controller set.
INFO - 2016-10-28 17:47:44 --> Router Class Initialized
INFO - 2016-10-28 17:47:44 --> Output Class Initialized
INFO - 2016-10-28 17:47:44 --> Security Class Initialized
DEBUG - 2016-10-28 17:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:47:44 --> Input Class Initialized
INFO - 2016-10-28 17:47:44 --> Language Class Initialized
INFO - 2016-10-28 17:47:44 --> Loader Class Initialized
INFO - 2016-10-28 17:47:44 --> Helper loaded: url_helper
INFO - 2016-10-28 17:47:44 --> Helper loaded: form_helper
INFO - 2016-10-28 17:47:44 --> Database Driver Class Initialized
INFO - 2016-10-28 17:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:47:44 --> Controller Class Initialized
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:47:44 --> Model Class Initialized
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:47:44 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:47:44 --> Final output sent to browser
DEBUG - 2016-10-28 17:47:44 --> Total execution time: 0.0211
INFO - 2016-10-28 17:49:15 --> Config Class Initialized
INFO - 2016-10-28 17:49:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:49:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:49:15 --> Utf8 Class Initialized
INFO - 2016-10-28 17:49:15 --> URI Class Initialized
DEBUG - 2016-10-28 17:49:15 --> No URI present. Default controller set.
INFO - 2016-10-28 17:49:15 --> Router Class Initialized
INFO - 2016-10-28 17:49:15 --> Output Class Initialized
INFO - 2016-10-28 17:49:15 --> Security Class Initialized
DEBUG - 2016-10-28 17:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:49:15 --> Input Class Initialized
INFO - 2016-10-28 17:49:15 --> Language Class Initialized
INFO - 2016-10-28 17:49:15 --> Loader Class Initialized
INFO - 2016-10-28 17:49:15 --> Helper loaded: url_helper
INFO - 2016-10-28 17:49:15 --> Helper loaded: form_helper
INFO - 2016-10-28 17:49:15 --> Database Driver Class Initialized
INFO - 2016-10-28 17:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:49:15 --> Controller Class Initialized
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:49:15 --> Model Class Initialized
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:49:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:49:15 --> Final output sent to browser
DEBUG - 2016-10-28 17:49:15 --> Total execution time: 0.0192
INFO - 2016-10-28 17:49:34 --> Config Class Initialized
INFO - 2016-10-28 17:49:34 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:49:34 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:49:34 --> Utf8 Class Initialized
INFO - 2016-10-28 17:49:34 --> URI Class Initialized
DEBUG - 2016-10-28 17:49:34 --> No URI present. Default controller set.
INFO - 2016-10-28 17:49:34 --> Router Class Initialized
INFO - 2016-10-28 17:49:34 --> Output Class Initialized
INFO - 2016-10-28 17:49:34 --> Security Class Initialized
DEBUG - 2016-10-28 17:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:49:34 --> Input Class Initialized
INFO - 2016-10-28 17:49:34 --> Language Class Initialized
INFO - 2016-10-28 17:49:34 --> Loader Class Initialized
INFO - 2016-10-28 17:49:34 --> Helper loaded: url_helper
INFO - 2016-10-28 17:49:34 --> Helper loaded: form_helper
INFO - 2016-10-28 17:49:34 --> Database Driver Class Initialized
INFO - 2016-10-28 17:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:49:34 --> Controller Class Initialized
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:49:34 --> Model Class Initialized
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:49:34 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:49:34 --> Final output sent to browser
DEBUG - 2016-10-28 17:49:34 --> Total execution time: 0.0193
INFO - 2016-10-28 17:50:21 --> Config Class Initialized
INFO - 2016-10-28 17:50:21 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:50:21 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:50:21 --> Utf8 Class Initialized
INFO - 2016-10-28 17:50:21 --> URI Class Initialized
INFO - 2016-10-28 17:50:21 --> Router Class Initialized
INFO - 2016-10-28 17:50:21 --> Output Class Initialized
INFO - 2016-10-28 17:50:21 --> Security Class Initialized
DEBUG - 2016-10-28 17:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:50:21 --> Input Class Initialized
INFO - 2016-10-28 17:50:21 --> Language Class Initialized
INFO - 2016-10-28 17:50:21 --> Loader Class Initialized
INFO - 2016-10-28 17:50:21 --> Helper loaded: url_helper
INFO - 2016-10-28 17:50:21 --> Helper loaded: form_helper
INFO - 2016-10-28 17:50:21 --> Database Driver Class Initialized
INFO - 2016-10-28 17:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:50:21 --> Controller Class Initialized
INFO - 2016-10-28 17:50:21 --> Form Validation Class Initialized
INFO - 2016-10-28 17:50:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 17:50:21 --> Model Class Initialized
INFO - 2016-10-28 17:50:21 --> Final output sent to browser
DEBUG - 2016-10-28 17:50:21 --> Total execution time: 0.0199
INFO - 2016-10-28 17:50:28 --> Config Class Initialized
INFO - 2016-10-28 17:50:28 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:50:28 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:50:28 --> Utf8 Class Initialized
INFO - 2016-10-28 17:50:28 --> URI Class Initialized
DEBUG - 2016-10-28 17:50:28 --> No URI present. Default controller set.
INFO - 2016-10-28 17:50:28 --> Router Class Initialized
INFO - 2016-10-28 17:50:28 --> Output Class Initialized
INFO - 2016-10-28 17:50:28 --> Security Class Initialized
DEBUG - 2016-10-28 17:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:50:28 --> Input Class Initialized
INFO - 2016-10-28 17:50:28 --> Language Class Initialized
INFO - 2016-10-28 17:50:28 --> Loader Class Initialized
INFO - 2016-10-28 17:50:28 --> Helper loaded: url_helper
INFO - 2016-10-28 17:50:28 --> Helper loaded: form_helper
INFO - 2016-10-28 17:50:28 --> Database Driver Class Initialized
INFO - 2016-10-28 17:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:50:28 --> Controller Class Initialized
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:50:28 --> Model Class Initialized
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:50:28 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:50:28 --> Final output sent to browser
DEBUG - 2016-10-28 17:50:28 --> Total execution time: 0.0195
INFO - 2016-10-28 17:51:49 --> Config Class Initialized
INFO - 2016-10-28 17:51:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:51:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:51:49 --> Utf8 Class Initialized
INFO - 2016-10-28 17:51:49 --> URI Class Initialized
DEBUG - 2016-10-28 17:51:49 --> No URI present. Default controller set.
INFO - 2016-10-28 17:51:49 --> Router Class Initialized
INFO - 2016-10-28 17:51:49 --> Output Class Initialized
INFO - 2016-10-28 17:51:49 --> Security Class Initialized
DEBUG - 2016-10-28 17:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:51:49 --> Input Class Initialized
INFO - 2016-10-28 17:51:49 --> Language Class Initialized
INFO - 2016-10-28 17:51:49 --> Loader Class Initialized
INFO - 2016-10-28 17:51:49 --> Helper loaded: url_helper
INFO - 2016-10-28 17:51:49 --> Helper loaded: form_helper
INFO - 2016-10-28 17:51:49 --> Database Driver Class Initialized
INFO - 2016-10-28 17:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:51:49 --> Controller Class Initialized
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:51:49 --> Model Class Initialized
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:51:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:51:49 --> Final output sent to browser
DEBUG - 2016-10-28 17:51:49 --> Total execution time: 0.0190
INFO - 2016-10-28 17:54:06 --> Config Class Initialized
INFO - 2016-10-28 17:54:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:54:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:54:06 --> Utf8 Class Initialized
INFO - 2016-10-28 17:54:06 --> URI Class Initialized
DEBUG - 2016-10-28 17:54:06 --> No URI present. Default controller set.
INFO - 2016-10-28 17:54:06 --> Router Class Initialized
INFO - 2016-10-28 17:54:06 --> Output Class Initialized
INFO - 2016-10-28 17:54:06 --> Security Class Initialized
DEBUG - 2016-10-28 17:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:54:06 --> Input Class Initialized
INFO - 2016-10-28 17:54:06 --> Language Class Initialized
INFO - 2016-10-28 17:54:06 --> Loader Class Initialized
INFO - 2016-10-28 17:54:06 --> Helper loaded: url_helper
INFO - 2016-10-28 17:54:06 --> Helper loaded: form_helper
INFO - 2016-10-28 17:54:06 --> Database Driver Class Initialized
INFO - 2016-10-28 17:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:54:06 --> Controller Class Initialized
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:54:06 --> Model Class Initialized
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:54:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:54:06 --> Final output sent to browser
DEBUG - 2016-10-28 17:54:06 --> Total execution time: 0.0197
INFO - 2016-10-28 17:54:11 --> Config Class Initialized
INFO - 2016-10-28 17:54:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:54:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:54:11 --> Utf8 Class Initialized
INFO - 2016-10-28 17:54:11 --> URI Class Initialized
INFO - 2016-10-28 17:54:11 --> Router Class Initialized
INFO - 2016-10-28 17:54:11 --> Output Class Initialized
INFO - 2016-10-28 17:54:11 --> Security Class Initialized
DEBUG - 2016-10-28 17:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:54:11 --> Input Class Initialized
INFO - 2016-10-28 17:54:11 --> Language Class Initialized
INFO - 2016-10-28 17:54:11 --> Loader Class Initialized
INFO - 2016-10-28 17:54:11 --> Helper loaded: url_helper
INFO - 2016-10-28 17:54:11 --> Helper loaded: form_helper
INFO - 2016-10-28 17:54:11 --> Database Driver Class Initialized
INFO - 2016-10-28 17:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:54:11 --> Controller Class Initialized
INFO - 2016-10-28 17:54:11 --> Form Validation Class Initialized
INFO - 2016-10-28 17:54:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 17:54:11 --> Final output sent to browser
DEBUG - 2016-10-28 17:54:11 --> Total execution time: 0.0193
INFO - 2016-10-28 17:54:12 --> Config Class Initialized
INFO - 2016-10-28 17:54:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:54:12 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:54:12 --> Utf8 Class Initialized
INFO - 2016-10-28 17:54:12 --> URI Class Initialized
DEBUG - 2016-10-28 17:54:12 --> No URI present. Default controller set.
INFO - 2016-10-28 17:54:12 --> Router Class Initialized
INFO - 2016-10-28 17:54:12 --> Output Class Initialized
INFO - 2016-10-28 17:54:12 --> Security Class Initialized
DEBUG - 2016-10-28 17:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:54:12 --> Input Class Initialized
INFO - 2016-10-28 17:54:12 --> Language Class Initialized
INFO - 2016-10-28 17:54:12 --> Loader Class Initialized
INFO - 2016-10-28 17:54:12 --> Helper loaded: url_helper
INFO - 2016-10-28 17:54:12 --> Helper loaded: form_helper
INFO - 2016-10-28 17:54:12 --> Database Driver Class Initialized
INFO - 2016-10-28 17:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:54:12 --> Controller Class Initialized
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:54:12 --> Model Class Initialized
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:54:12 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:54:12 --> Final output sent to browser
DEBUG - 2016-10-28 17:54:12 --> Total execution time: 0.0187
INFO - 2016-10-28 17:55:14 --> Config Class Initialized
INFO - 2016-10-28 17:55:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:55:14 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:55:14 --> Utf8 Class Initialized
INFO - 2016-10-28 17:55:14 --> URI Class Initialized
DEBUG - 2016-10-28 17:55:14 --> No URI present. Default controller set.
INFO - 2016-10-28 17:55:14 --> Router Class Initialized
INFO - 2016-10-28 17:55:14 --> Output Class Initialized
INFO - 2016-10-28 17:55:14 --> Security Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:55:14 --> Input Class Initialized
INFO - 2016-10-28 17:55:14 --> Language Class Initialized
INFO - 2016-10-28 17:55:14 --> Loader Class Initialized
INFO - 2016-10-28 17:55:14 --> Helper loaded: url_helper
INFO - 2016-10-28 17:55:14 --> Helper loaded: form_helper
INFO - 2016-10-28 17:55:14 --> Database Driver Class Initialized
INFO - 2016-10-28 17:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:55:14 --> Controller Class Initialized
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:55:14 --> Model Class Initialized
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:55:14 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:55:14 --> Final output sent to browser
DEBUG - 2016-10-28 17:55:14 --> Total execution time: 0.0200
INFO - 2016-10-28 17:56:07 --> Config Class Initialized
INFO - 2016-10-28 17:56:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:56:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:56:07 --> Utf8 Class Initialized
INFO - 2016-10-28 17:56:07 --> URI Class Initialized
DEBUG - 2016-10-28 17:56:07 --> No URI present. Default controller set.
INFO - 2016-10-28 17:56:07 --> Router Class Initialized
INFO - 2016-10-28 17:56:07 --> Output Class Initialized
INFO - 2016-10-28 17:56:07 --> Security Class Initialized
DEBUG - 2016-10-28 17:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:56:07 --> Input Class Initialized
INFO - 2016-10-28 17:56:07 --> Language Class Initialized
INFO - 2016-10-28 17:56:07 --> Loader Class Initialized
INFO - 2016-10-28 17:56:07 --> Helper loaded: url_helper
INFO - 2016-10-28 17:56:07 --> Helper loaded: form_helper
INFO - 2016-10-28 17:56:07 --> Database Driver Class Initialized
INFO - 2016-10-28 17:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:56:07 --> Controller Class Initialized
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:56:07 --> Model Class Initialized
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:56:07 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:56:07 --> Final output sent to browser
DEBUG - 2016-10-28 17:56:07 --> Total execution time: 0.0213
INFO - 2016-10-28 17:56:15 --> Config Class Initialized
INFO - 2016-10-28 17:56:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:56:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:56:15 --> Utf8 Class Initialized
INFO - 2016-10-28 17:56:15 --> URI Class Initialized
INFO - 2016-10-28 17:56:15 --> Router Class Initialized
INFO - 2016-10-28 17:56:15 --> Output Class Initialized
INFO - 2016-10-28 17:56:15 --> Security Class Initialized
DEBUG - 2016-10-28 17:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:56:15 --> Input Class Initialized
INFO - 2016-10-28 17:56:15 --> Language Class Initialized
INFO - 2016-10-28 17:56:15 --> Loader Class Initialized
INFO - 2016-10-28 17:56:15 --> Helper loaded: url_helper
INFO - 2016-10-28 17:56:15 --> Helper loaded: form_helper
INFO - 2016-10-28 17:56:15 --> Database Driver Class Initialized
INFO - 2016-10-28 17:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:56:15 --> Controller Class Initialized
INFO - 2016-10-28 17:56:15 --> Form Validation Class Initialized
INFO - 2016-10-28 17:56:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 17:56:15 --> Final output sent to browser
DEBUG - 2016-10-28 17:56:15 --> Total execution time: 0.0172
INFO - 2016-10-28 17:56:16 --> Config Class Initialized
INFO - 2016-10-28 17:56:16 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:56:16 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:56:16 --> Utf8 Class Initialized
INFO - 2016-10-28 17:56:16 --> URI Class Initialized
DEBUG - 2016-10-28 17:56:16 --> No URI present. Default controller set.
INFO - 2016-10-28 17:56:16 --> Router Class Initialized
INFO - 2016-10-28 17:56:16 --> Output Class Initialized
INFO - 2016-10-28 17:56:16 --> Security Class Initialized
DEBUG - 2016-10-28 17:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:56:16 --> Input Class Initialized
INFO - 2016-10-28 17:56:16 --> Language Class Initialized
INFO - 2016-10-28 17:56:16 --> Loader Class Initialized
INFO - 2016-10-28 17:56:16 --> Helper loaded: url_helper
INFO - 2016-10-28 17:56:16 --> Helper loaded: form_helper
INFO - 2016-10-28 17:56:16 --> Database Driver Class Initialized
INFO - 2016-10-28 17:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:56:16 --> Controller Class Initialized
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:56:16 --> Model Class Initialized
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:56:16 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:56:16 --> Final output sent to browser
DEBUG - 2016-10-28 17:56:16 --> Total execution time: 0.0188
INFO - 2016-10-28 17:57:19 --> Config Class Initialized
INFO - 2016-10-28 17:57:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:57:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 17:57:19 --> Utf8 Class Initialized
INFO - 2016-10-28 17:57:19 --> URI Class Initialized
DEBUG - 2016-10-28 17:57:19 --> No URI present. Default controller set.
INFO - 2016-10-28 17:57:19 --> Router Class Initialized
INFO - 2016-10-28 17:57:19 --> Output Class Initialized
INFO - 2016-10-28 17:57:19 --> Security Class Initialized
DEBUG - 2016-10-28 17:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 17:57:19 --> Input Class Initialized
INFO - 2016-10-28 17:57:19 --> Language Class Initialized
INFO - 2016-10-28 17:57:19 --> Loader Class Initialized
INFO - 2016-10-28 17:57:19 --> Helper loaded: url_helper
INFO - 2016-10-28 17:57:19 --> Helper loaded: form_helper
INFO - 2016-10-28 17:57:19 --> Database Driver Class Initialized
INFO - 2016-10-28 17:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 17:57:19 --> Controller Class Initialized
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 17:57:19 --> Model Class Initialized
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 17:57:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 17:57:19 --> Final output sent to browser
DEBUG - 2016-10-28 17:57:19 --> Total execution time: 0.0194
INFO - 2016-10-28 18:03:11 --> Config Class Initialized
INFO - 2016-10-28 18:03:11 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:03:11 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:03:11 --> Utf8 Class Initialized
INFO - 2016-10-28 18:03:11 --> URI Class Initialized
DEBUG - 2016-10-28 18:03:11 --> No URI present. Default controller set.
INFO - 2016-10-28 18:03:11 --> Router Class Initialized
INFO - 2016-10-28 18:03:11 --> Output Class Initialized
INFO - 2016-10-28 18:03:11 --> Security Class Initialized
DEBUG - 2016-10-28 18:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:03:11 --> Input Class Initialized
INFO - 2016-10-28 18:03:11 --> Language Class Initialized
INFO - 2016-10-28 18:03:11 --> Loader Class Initialized
INFO - 2016-10-28 18:03:11 --> Helper loaded: url_helper
INFO - 2016-10-28 18:03:11 --> Helper loaded: form_helper
INFO - 2016-10-28 18:03:11 --> Database Driver Class Initialized
INFO - 2016-10-28 18:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:03:11 --> Controller Class Initialized
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:03:11 --> Model Class Initialized
ERROR - 2016-10-28 18:03:11 --> Severity: Notice --> Undefined variable: config /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 54
INFO - 2016-10-28 18:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-10-28 18:03:11 --> Pagination Class Initialized
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
ERROR - 2016-10-28 18:03:11 --> Severity: Notice --> Undefined variable: pagination_links /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php 24
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:03:11 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:03:11 --> Final output sent to browser
DEBUG - 2016-10-28 18:03:11 --> Total execution time: 0.0530
INFO - 2016-10-28 18:03:23 --> Config Class Initialized
INFO - 2016-10-28 18:03:23 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:03:23 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:03:23 --> Utf8 Class Initialized
INFO - 2016-10-28 18:03:23 --> URI Class Initialized
DEBUG - 2016-10-28 18:03:23 --> No URI present. Default controller set.
INFO - 2016-10-28 18:03:23 --> Router Class Initialized
INFO - 2016-10-28 18:03:23 --> Output Class Initialized
INFO - 2016-10-28 18:03:23 --> Security Class Initialized
DEBUG - 2016-10-28 18:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:03:23 --> Input Class Initialized
INFO - 2016-10-28 18:03:23 --> Language Class Initialized
INFO - 2016-10-28 18:03:23 --> Loader Class Initialized
INFO - 2016-10-28 18:03:23 --> Helper loaded: url_helper
INFO - 2016-10-28 18:03:23 --> Helper loaded: form_helper
INFO - 2016-10-28 18:03:23 --> Database Driver Class Initialized
INFO - 2016-10-28 18:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:03:23 --> Controller Class Initialized
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:03:23 --> Model Class Initialized
ERROR - 2016-10-28 18:03:23 --> Severity: Notice --> Undefined variable: config /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 54
INFO - 2016-10-28 18:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-10-28 18:03:23 --> Pagination Class Initialized
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:03:23 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:03:23 --> Final output sent to browser
DEBUG - 2016-10-28 18:03:23 --> Total execution time: 0.0207
INFO - 2016-10-28 18:03:58 --> Config Class Initialized
INFO - 2016-10-28 18:03:58 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:03:58 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:03:58 --> Utf8 Class Initialized
INFO - 2016-10-28 18:03:58 --> URI Class Initialized
DEBUG - 2016-10-28 18:03:58 --> No URI present. Default controller set.
INFO - 2016-10-28 18:03:58 --> Router Class Initialized
INFO - 2016-10-28 18:03:58 --> Output Class Initialized
INFO - 2016-10-28 18:03:58 --> Security Class Initialized
DEBUG - 2016-10-28 18:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:03:58 --> Input Class Initialized
INFO - 2016-10-28 18:03:58 --> Language Class Initialized
INFO - 2016-10-28 18:03:58 --> Loader Class Initialized
INFO - 2016-10-28 18:03:58 --> Helper loaded: url_helper
INFO - 2016-10-28 18:03:58 --> Helper loaded: form_helper
INFO - 2016-10-28 18:03:58 --> Database Driver Class Initialized
INFO - 2016-10-28 18:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:03:58 --> Controller Class Initialized
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:03:58 --> Model Class Initialized
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:03:58 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:03:58 --> Final output sent to browser
DEBUG - 2016-10-28 18:03:58 --> Total execution time: 0.0198
INFO - 2016-10-28 18:04:02 --> Config Class Initialized
INFO - 2016-10-28 18:04:02 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:04:02 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:04:02 --> Utf8 Class Initialized
INFO - 2016-10-28 18:04:02 --> URI Class Initialized
DEBUG - 2016-10-28 18:04:02 --> No URI present. Default controller set.
INFO - 2016-10-28 18:04:02 --> Router Class Initialized
INFO - 2016-10-28 18:04:02 --> Output Class Initialized
INFO - 2016-10-28 18:04:02 --> Security Class Initialized
DEBUG - 2016-10-28 18:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:04:02 --> Input Class Initialized
INFO - 2016-10-28 18:04:02 --> Language Class Initialized
INFO - 2016-10-28 18:04:02 --> Loader Class Initialized
INFO - 2016-10-28 18:04:02 --> Helper loaded: url_helper
INFO - 2016-10-28 18:04:02 --> Helper loaded: form_helper
INFO - 2016-10-28 18:04:02 --> Database Driver Class Initialized
INFO - 2016-10-28 18:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:04:02 --> Controller Class Initialized
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:04:02 --> Model Class Initialized
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:04:02 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:04:02 --> Final output sent to browser
DEBUG - 2016-10-28 18:04:02 --> Total execution time: 0.0186
INFO - 2016-10-28 18:04:24 --> Config Class Initialized
INFO - 2016-10-28 18:04:24 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:04:24 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:04:24 --> Utf8 Class Initialized
INFO - 2016-10-28 18:04:24 --> URI Class Initialized
DEBUG - 2016-10-28 18:04:24 --> No URI present. Default controller set.
INFO - 2016-10-28 18:04:24 --> Router Class Initialized
INFO - 2016-10-28 18:04:24 --> Output Class Initialized
INFO - 2016-10-28 18:04:24 --> Security Class Initialized
DEBUG - 2016-10-28 18:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:04:24 --> Input Class Initialized
INFO - 2016-10-28 18:04:24 --> Language Class Initialized
INFO - 2016-10-28 18:04:24 --> Loader Class Initialized
INFO - 2016-10-28 18:04:24 --> Helper loaded: url_helper
INFO - 2016-10-28 18:04:24 --> Helper loaded: form_helper
INFO - 2016-10-28 18:04:24 --> Database Driver Class Initialized
INFO - 2016-10-28 18:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:04:24 --> Controller Class Initialized
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:04:24 --> Model Class Initialized
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:04:24 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:04:24 --> Final output sent to browser
DEBUG - 2016-10-28 18:04:24 --> Total execution time: 0.0200
INFO - 2016-10-28 18:05:27 --> Config Class Initialized
INFO - 2016-10-28 18:05:27 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:05:27 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:05:27 --> Utf8 Class Initialized
INFO - 2016-10-28 18:05:27 --> URI Class Initialized
DEBUG - 2016-10-28 18:05:27 --> No URI present. Default controller set.
INFO - 2016-10-28 18:05:27 --> Router Class Initialized
INFO - 2016-10-28 18:05:27 --> Output Class Initialized
INFO - 2016-10-28 18:05:27 --> Security Class Initialized
DEBUG - 2016-10-28 18:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:05:27 --> Input Class Initialized
INFO - 2016-10-28 18:05:27 --> Language Class Initialized
INFO - 2016-10-28 18:05:27 --> Loader Class Initialized
INFO - 2016-10-28 18:05:27 --> Helper loaded: url_helper
INFO - 2016-10-28 18:05:27 --> Helper loaded: form_helper
INFO - 2016-10-28 18:05:27 --> Database Driver Class Initialized
INFO - 2016-10-28 18:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:05:27 --> Controller Class Initialized
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:05:27 --> Model Class Initialized
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:05:27 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:05:27 --> Final output sent to browser
DEBUG - 2016-10-28 18:05:27 --> Total execution time: 0.0238
INFO - 2016-10-28 18:09:38 --> Config Class Initialized
INFO - 2016-10-28 18:09:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:09:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:09:38 --> Utf8 Class Initialized
INFO - 2016-10-28 18:09:38 --> URI Class Initialized
DEBUG - 2016-10-28 18:09:38 --> No URI present. Default controller set.
INFO - 2016-10-28 18:09:38 --> Router Class Initialized
INFO - 2016-10-28 18:09:38 --> Output Class Initialized
INFO - 2016-10-28 18:09:38 --> Security Class Initialized
DEBUG - 2016-10-28 18:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:09:38 --> Input Class Initialized
INFO - 2016-10-28 18:09:38 --> Language Class Initialized
INFO - 2016-10-28 18:09:38 --> Loader Class Initialized
INFO - 2016-10-28 18:09:38 --> Helper loaded: url_helper
INFO - 2016-10-28 18:09:38 --> Helper loaded: form_helper
INFO - 2016-10-28 18:09:38 --> Database Driver Class Initialized
INFO - 2016-10-28 18:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:09:38 --> Controller Class Initialized
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:09:38 --> Model Class Initialized
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:09:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:09:38 --> Final output sent to browser
DEBUG - 2016-10-28 18:09:38 --> Total execution time: 0.0200
INFO - 2016-10-28 18:10:39 --> Config Class Initialized
INFO - 2016-10-28 18:10:39 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:10:39 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:10:39 --> Utf8 Class Initialized
INFO - 2016-10-28 18:10:39 --> URI Class Initialized
INFO - 2016-10-28 18:10:39 --> Router Class Initialized
INFO - 2016-10-28 18:10:39 --> Output Class Initialized
INFO - 2016-10-28 18:10:39 --> Security Class Initialized
DEBUG - 2016-10-28 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:10:39 --> Input Class Initialized
INFO - 2016-10-28 18:10:39 --> Language Class Initialized
INFO - 2016-10-28 18:10:39 --> Loader Class Initialized
INFO - 2016-10-28 18:10:39 --> Helper loaded: url_helper
INFO - 2016-10-28 18:10:39 --> Helper loaded: form_helper
INFO - 2016-10-28 18:10:39 --> Database Driver Class Initialized
INFO - 2016-10-28 18:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:10:39 --> Controller Class Initialized
INFO - 2016-10-28 18:10:39 --> Form Validation Class Initialized
INFO - 2016-10-28 18:10:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 18:10:39 --> Final output sent to browser
DEBUG - 2016-10-28 18:10:39 --> Total execution time: 0.0177
INFO - 2016-10-28 18:10:41 --> Config Class Initialized
INFO - 2016-10-28 18:10:41 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:10:41 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:10:41 --> Utf8 Class Initialized
INFO - 2016-10-28 18:10:41 --> URI Class Initialized
DEBUG - 2016-10-28 18:10:41 --> No URI present. Default controller set.
INFO - 2016-10-28 18:10:41 --> Router Class Initialized
INFO - 2016-10-28 18:10:41 --> Output Class Initialized
INFO - 2016-10-28 18:10:41 --> Security Class Initialized
DEBUG - 2016-10-28 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:10:41 --> Input Class Initialized
INFO - 2016-10-28 18:10:41 --> Language Class Initialized
INFO - 2016-10-28 18:10:41 --> Loader Class Initialized
INFO - 2016-10-28 18:10:41 --> Helper loaded: url_helper
INFO - 2016-10-28 18:10:41 --> Helper loaded: form_helper
INFO - 2016-10-28 18:10:41 --> Database Driver Class Initialized
INFO - 2016-10-28 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:10:41 --> Controller Class Initialized
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:10:41 --> Model Class Initialized
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:10:41 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:10:41 --> Final output sent to browser
DEBUG - 2016-10-28 18:10:41 --> Total execution time: 0.0194
INFO - 2016-10-28 18:22:36 --> Config Class Initialized
INFO - 2016-10-28 18:22:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:22:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:22:36 --> Utf8 Class Initialized
INFO - 2016-10-28 18:22:36 --> URI Class Initialized
DEBUG - 2016-10-28 18:22:36 --> No URI present. Default controller set.
INFO - 2016-10-28 18:22:36 --> Router Class Initialized
INFO - 2016-10-28 18:22:36 --> Output Class Initialized
INFO - 2016-10-28 18:22:36 --> Security Class Initialized
DEBUG - 2016-10-28 18:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:22:36 --> Input Class Initialized
INFO - 2016-10-28 18:22:36 --> Language Class Initialized
INFO - 2016-10-28 18:22:36 --> Loader Class Initialized
INFO - 2016-10-28 18:22:36 --> Helper loaded: url_helper
INFO - 2016-10-28 18:22:36 --> Helper loaded: form_helper
INFO - 2016-10-28 18:22:36 --> Database Driver Class Initialized
INFO - 2016-10-28 18:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:22:36 --> Controller Class Initialized
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:22:36 --> Model Class Initialized
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:22:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:22:36 --> Final output sent to browser
DEBUG - 2016-10-28 18:22:36 --> Total execution time: 0.0204
INFO - 2016-10-28 18:23:06 --> Config Class Initialized
INFO - 2016-10-28 18:23:06 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:23:06 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:23:06 --> Utf8 Class Initialized
INFO - 2016-10-28 18:23:06 --> URI Class Initialized
DEBUG - 2016-10-28 18:23:06 --> No URI present. Default controller set.
INFO - 2016-10-28 18:23:06 --> Router Class Initialized
INFO - 2016-10-28 18:23:06 --> Output Class Initialized
INFO - 2016-10-28 18:23:06 --> Security Class Initialized
DEBUG - 2016-10-28 18:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:23:06 --> Input Class Initialized
INFO - 2016-10-28 18:23:06 --> Language Class Initialized
INFO - 2016-10-28 18:23:06 --> Loader Class Initialized
INFO - 2016-10-28 18:23:06 --> Helper loaded: url_helper
INFO - 2016-10-28 18:23:06 --> Helper loaded: form_helper
INFO - 2016-10-28 18:23:06 --> Database Driver Class Initialized
INFO - 2016-10-28 18:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:23:06 --> Controller Class Initialized
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:23:06 --> Model Class Initialized
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:23:06 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:23:06 --> Final output sent to browser
DEBUG - 2016-10-28 18:23:06 --> Total execution time: 0.0208
INFO - 2016-10-28 18:23:36 --> Config Class Initialized
INFO - 2016-10-28 18:23:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:23:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:23:36 --> Utf8 Class Initialized
INFO - 2016-10-28 18:23:36 --> URI Class Initialized
DEBUG - 2016-10-28 18:23:36 --> No URI present. Default controller set.
INFO - 2016-10-28 18:23:36 --> Router Class Initialized
INFO - 2016-10-28 18:23:36 --> Output Class Initialized
INFO - 2016-10-28 18:23:36 --> Security Class Initialized
DEBUG - 2016-10-28 18:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:23:36 --> Input Class Initialized
INFO - 2016-10-28 18:23:36 --> Language Class Initialized
INFO - 2016-10-28 18:23:36 --> Loader Class Initialized
INFO - 2016-10-28 18:23:36 --> Helper loaded: url_helper
INFO - 2016-10-28 18:23:36 --> Helper loaded: form_helper
INFO - 2016-10-28 18:23:36 --> Database Driver Class Initialized
INFO - 2016-10-28 18:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:23:36 --> Controller Class Initialized
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:23:36 --> Model Class Initialized
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:23:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:23:36 --> Final output sent to browser
DEBUG - 2016-10-28 18:23:36 --> Total execution time: 0.0196
INFO - 2016-10-28 18:24:15 --> Config Class Initialized
INFO - 2016-10-28 18:24:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:24:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:24:15 --> Utf8 Class Initialized
INFO - 2016-10-28 18:24:15 --> URI Class Initialized
DEBUG - 2016-10-28 18:24:15 --> No URI present. Default controller set.
INFO - 2016-10-28 18:24:15 --> Router Class Initialized
INFO - 2016-10-28 18:24:15 --> Output Class Initialized
INFO - 2016-10-28 18:24:15 --> Security Class Initialized
DEBUG - 2016-10-28 18:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:24:15 --> Input Class Initialized
INFO - 2016-10-28 18:24:15 --> Language Class Initialized
INFO - 2016-10-28 18:24:15 --> Loader Class Initialized
INFO - 2016-10-28 18:24:15 --> Helper loaded: url_helper
INFO - 2016-10-28 18:24:15 --> Helper loaded: form_helper
INFO - 2016-10-28 18:24:15 --> Database Driver Class Initialized
INFO - 2016-10-28 18:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:24:15 --> Controller Class Initialized
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:24:15 --> Model Class Initialized
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:24:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:24:15 --> Final output sent to browser
DEBUG - 2016-10-28 18:24:15 --> Total execution time: 0.0201
INFO - 2016-10-28 18:47:36 --> Config Class Initialized
INFO - 2016-10-28 18:47:36 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:47:36 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:47:36 --> Utf8 Class Initialized
INFO - 2016-10-28 18:47:36 --> URI Class Initialized
DEBUG - 2016-10-28 18:47:36 --> No URI present. Default controller set.
INFO - 2016-10-28 18:47:36 --> Router Class Initialized
INFO - 2016-10-28 18:47:36 --> Output Class Initialized
INFO - 2016-10-28 18:47:36 --> Security Class Initialized
DEBUG - 2016-10-28 18:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:47:36 --> Input Class Initialized
INFO - 2016-10-28 18:47:36 --> Language Class Initialized
INFO - 2016-10-28 18:47:36 --> Loader Class Initialized
INFO - 2016-10-28 18:47:36 --> Helper loaded: url_helper
INFO - 2016-10-28 18:47:36 --> Helper loaded: form_helper
INFO - 2016-10-28 18:47:36 --> Database Driver Class Initialized
INFO - 2016-10-28 18:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:47:36 --> Controller Class Initialized
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:47:36 --> Model Class Initialized
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:47:36 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:47:36 --> Final output sent to browser
DEBUG - 2016-10-28 18:47:36 --> Total execution time: 0.0230
INFO - 2016-10-28 18:47:47 --> Config Class Initialized
INFO - 2016-10-28 18:47:47 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:47:47 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:47:47 --> Utf8 Class Initialized
INFO - 2016-10-28 18:47:47 --> URI Class Initialized
INFO - 2016-10-28 18:47:47 --> Router Class Initialized
INFO - 2016-10-28 18:47:47 --> Output Class Initialized
INFO - 2016-10-28 18:47:47 --> Security Class Initialized
DEBUG - 2016-10-28 18:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:47:47 --> Input Class Initialized
INFO - 2016-10-28 18:47:47 --> Language Class Initialized
INFO - 2016-10-28 18:47:47 --> Loader Class Initialized
INFO - 2016-10-28 18:47:47 --> Helper loaded: url_helper
INFO - 2016-10-28 18:47:47 --> Helper loaded: form_helper
INFO - 2016-10-28 18:47:47 --> Database Driver Class Initialized
INFO - 2016-10-28 18:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:47:47 --> Controller Class Initialized
INFO - 2016-10-28 18:47:47 --> Form Validation Class Initialized
INFO - 2016-10-28 18:47:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 18:47:47 --> Final output sent to browser
DEBUG - 2016-10-28 18:47:47 --> Total execution time: 0.0207
INFO - 2016-10-28 18:47:49 --> Config Class Initialized
INFO - 2016-10-28 18:47:49 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:47:49 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:47:49 --> Utf8 Class Initialized
INFO - 2016-10-28 18:47:49 --> URI Class Initialized
DEBUG - 2016-10-28 18:47:49 --> No URI present. Default controller set.
INFO - 2016-10-28 18:47:49 --> Router Class Initialized
INFO - 2016-10-28 18:47:49 --> Output Class Initialized
INFO - 2016-10-28 18:47:49 --> Security Class Initialized
DEBUG - 2016-10-28 18:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:47:49 --> Input Class Initialized
INFO - 2016-10-28 18:47:49 --> Language Class Initialized
INFO - 2016-10-28 18:47:49 --> Loader Class Initialized
INFO - 2016-10-28 18:47:49 --> Helper loaded: url_helper
INFO - 2016-10-28 18:47:49 --> Helper loaded: form_helper
INFO - 2016-10-28 18:47:49 --> Database Driver Class Initialized
INFO - 2016-10-28 18:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:47:49 --> Controller Class Initialized
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:47:49 --> Model Class Initialized
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:47:49 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:47:49 --> Final output sent to browser
DEBUG - 2016-10-28 18:47:49 --> Total execution time: 0.0200
INFO - 2016-10-28 18:49:35 --> Config Class Initialized
INFO - 2016-10-28 18:49:35 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:35 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:35 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:35 --> URI Class Initialized
DEBUG - 2016-10-28 18:49:35 --> No URI present. Default controller set.
INFO - 2016-10-28 18:49:35 --> Router Class Initialized
INFO - 2016-10-28 18:49:35 --> Output Class Initialized
INFO - 2016-10-28 18:49:35 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:35 --> Input Class Initialized
INFO - 2016-10-28 18:49:35 --> Language Class Initialized
INFO - 2016-10-28 18:49:35 --> Loader Class Initialized
INFO - 2016-10-28 18:49:35 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:35 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:35 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:35 --> Controller Class Initialized
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:49:35 --> Model Class Initialized
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:49:35 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:49:35 --> Final output sent to browser
DEBUG - 2016-10-28 18:49:35 --> Total execution time: 0.0211
INFO - 2016-10-28 18:49:38 --> Config Class Initialized
INFO - 2016-10-28 18:49:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:38 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:38 --> URI Class Initialized
INFO - 2016-10-28 18:49:38 --> Router Class Initialized
INFO - 2016-10-28 18:49:38 --> Output Class Initialized
INFO - 2016-10-28 18:49:38 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:38 --> Input Class Initialized
INFO - 2016-10-28 18:49:38 --> Language Class Initialized
INFO - 2016-10-28 18:49:38 --> Loader Class Initialized
INFO - 2016-10-28 18:49:38 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:38 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:38 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:38 --> Controller Class Initialized
DEBUG - 2016-10-28 18:49:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 18:49:38 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-10-28 18:49:38 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-10-28 18:49:38 --> Config Class Initialized
INFO - 2016-10-28 18:49:38 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:38 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:38 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:38 --> URI Class Initialized
DEBUG - 2016-10-28 18:49:38 --> No URI present. Default controller set.
INFO - 2016-10-28 18:49:38 --> Router Class Initialized
INFO - 2016-10-28 18:49:38 --> Output Class Initialized
INFO - 2016-10-28 18:49:38 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:38 --> Input Class Initialized
INFO - 2016-10-28 18:49:38 --> Language Class Initialized
INFO - 2016-10-28 18:49:38 --> Loader Class Initialized
INFO - 2016-10-28 18:49:38 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:38 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:38 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:38 --> Controller Class Initialized
INFO - 2016-10-28 18:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 18:49:38 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:49:38 --> Final output sent to browser
DEBUG - 2016-10-28 18:49:38 --> Total execution time: 0.0149
INFO - 2016-10-28 18:49:45 --> Config Class Initialized
INFO - 2016-10-28 18:49:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:45 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:45 --> URI Class Initialized
INFO - 2016-10-28 18:49:45 --> Router Class Initialized
INFO - 2016-10-28 18:49:45 --> Output Class Initialized
INFO - 2016-10-28 18:49:45 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:45 --> Input Class Initialized
INFO - 2016-10-28 18:49:45 --> Language Class Initialized
INFO - 2016-10-28 18:49:45 --> Loader Class Initialized
INFO - 2016-10-28 18:49:45 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:45 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:45 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:45 --> Controller Class Initialized
DEBUG - 2016-10-28 18:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 18:49:45 --> Model Class Initialized
INFO - 2016-10-28 18:49:45 --> Final output sent to browser
DEBUG - 2016-10-28 18:49:45 --> Total execution time: 0.0175
INFO - 2016-10-28 18:49:45 --> Config Class Initialized
INFO - 2016-10-28 18:49:45 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:45 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:45 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:45 --> URI Class Initialized
DEBUG - 2016-10-28 18:49:45 --> No URI present. Default controller set.
INFO - 2016-10-28 18:49:45 --> Router Class Initialized
INFO - 2016-10-28 18:49:45 --> Output Class Initialized
INFO - 2016-10-28 18:49:45 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:45 --> Input Class Initialized
INFO - 2016-10-28 18:49:45 --> Language Class Initialized
INFO - 2016-10-28 18:49:45 --> Loader Class Initialized
INFO - 2016-10-28 18:49:45 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:45 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:45 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:45 --> Controller Class Initialized
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:49:45 --> Model Class Initialized
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:49:45 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:49:45 --> Final output sent to browser
DEBUG - 2016-10-28 18:49:45 --> Total execution time: 0.0180
INFO - 2016-10-28 18:49:52 --> Config Class Initialized
INFO - 2016-10-28 18:49:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:52 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:52 --> URI Class Initialized
INFO - 2016-10-28 18:49:52 --> Router Class Initialized
INFO - 2016-10-28 18:49:52 --> Output Class Initialized
INFO - 2016-10-28 18:49:52 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:52 --> Input Class Initialized
INFO - 2016-10-28 18:49:52 --> Language Class Initialized
INFO - 2016-10-28 18:49:52 --> Loader Class Initialized
INFO - 2016-10-28 18:49:52 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:52 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:52 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:52 --> Controller Class Initialized
DEBUG - 2016-10-28 18:49:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 18:49:52 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-10-28 18:49:52 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-10-28 18:49:52 --> Config Class Initialized
INFO - 2016-10-28 18:49:52 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:49:52 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:49:52 --> Utf8 Class Initialized
INFO - 2016-10-28 18:49:52 --> URI Class Initialized
DEBUG - 2016-10-28 18:49:52 --> No URI present. Default controller set.
INFO - 2016-10-28 18:49:52 --> Router Class Initialized
INFO - 2016-10-28 18:49:52 --> Output Class Initialized
INFO - 2016-10-28 18:49:52 --> Security Class Initialized
DEBUG - 2016-10-28 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:49:52 --> Input Class Initialized
INFO - 2016-10-28 18:49:52 --> Language Class Initialized
INFO - 2016-10-28 18:49:52 --> Loader Class Initialized
INFO - 2016-10-28 18:49:52 --> Helper loaded: url_helper
INFO - 2016-10-28 18:49:52 --> Helper loaded: form_helper
INFO - 2016-10-28 18:49:52 --> Database Driver Class Initialized
INFO - 2016-10-28 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:49:52 --> Controller Class Initialized
INFO - 2016-10-28 18:49:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:49:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 18:49:52 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:49:52 --> Final output sent to browser
DEBUG - 2016-10-28 18:49:52 --> Total execution time: 0.0155
INFO - 2016-10-28 18:50:01 --> Config Class Initialized
INFO - 2016-10-28 18:50:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:50:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:50:01 --> Utf8 Class Initialized
INFO - 2016-10-28 18:50:01 --> URI Class Initialized
INFO - 2016-10-28 18:50:01 --> Router Class Initialized
INFO - 2016-10-28 18:50:01 --> Output Class Initialized
INFO - 2016-10-28 18:50:01 --> Security Class Initialized
DEBUG - 2016-10-28 18:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:50:01 --> Input Class Initialized
INFO - 2016-10-28 18:50:01 --> Language Class Initialized
INFO - 2016-10-28 18:50:01 --> Loader Class Initialized
INFO - 2016-10-28 18:50:01 --> Helper loaded: url_helper
INFO - 2016-10-28 18:50:01 --> Helper loaded: form_helper
INFO - 2016-10-28 18:50:01 --> Database Driver Class Initialized
INFO - 2016-10-28 18:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:50:01 --> Controller Class Initialized
DEBUG - 2016-10-28 18:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 18:50:01 --> Model Class Initialized
INFO - 2016-10-28 18:50:01 --> Final output sent to browser
DEBUG - 2016-10-28 18:50:01 --> Total execution time: 0.0173
INFO - 2016-10-28 18:50:01 --> Config Class Initialized
INFO - 2016-10-28 18:50:01 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:50:01 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:50:01 --> Utf8 Class Initialized
INFO - 2016-10-28 18:50:01 --> URI Class Initialized
DEBUG - 2016-10-28 18:50:01 --> No URI present. Default controller set.
INFO - 2016-10-28 18:50:01 --> Router Class Initialized
INFO - 2016-10-28 18:50:01 --> Output Class Initialized
INFO - 2016-10-28 18:50:01 --> Security Class Initialized
DEBUG - 2016-10-28 18:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:50:01 --> Input Class Initialized
INFO - 2016-10-28 18:50:01 --> Language Class Initialized
INFO - 2016-10-28 18:50:01 --> Loader Class Initialized
INFO - 2016-10-28 18:50:01 --> Helper loaded: url_helper
INFO - 2016-10-28 18:50:01 --> Helper loaded: form_helper
INFO - 2016-10-28 18:50:01 --> Database Driver Class Initialized
INFO - 2016-10-28 18:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:50:01 --> Controller Class Initialized
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:50:01 --> Model Class Initialized
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_record_sidebar.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:50:01 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:50:01 --> Final output sent to browser
DEBUG - 2016-10-28 18:50:01 --> Total execution time: 0.0174
INFO - 2016-10-28 18:50:05 --> Config Class Initialized
INFO - 2016-10-28 18:50:05 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:50:05 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:50:05 --> Utf8 Class Initialized
INFO - 2016-10-28 18:50:05 --> URI Class Initialized
INFO - 2016-10-28 18:50:05 --> Router Class Initialized
INFO - 2016-10-28 18:50:05 --> Output Class Initialized
INFO - 2016-10-28 18:50:05 --> Security Class Initialized
DEBUG - 2016-10-28 18:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:50:05 --> Input Class Initialized
INFO - 2016-10-28 18:50:05 --> Language Class Initialized
INFO - 2016-10-28 18:50:05 --> Loader Class Initialized
INFO - 2016-10-28 18:50:05 --> Helper loaded: url_helper
INFO - 2016-10-28 18:50:05 --> Helper loaded: form_helper
INFO - 2016-10-28 18:50:05 --> Database Driver Class Initialized
INFO - 2016-10-28 18:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:50:05 --> Controller Class Initialized
INFO - 2016-10-28 18:50:05 --> Form Validation Class Initialized
INFO - 2016-10-28 18:50:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 18:50:05 --> Final output sent to browser
DEBUG - 2016-10-28 18:50:05 --> Total execution time: 0.0202
INFO - 2016-10-28 18:50:08 --> Config Class Initialized
INFO - 2016-10-28 18:50:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:50:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:50:08 --> Utf8 Class Initialized
INFO - 2016-10-28 18:50:08 --> URI Class Initialized
DEBUG - 2016-10-28 18:50:08 --> No URI present. Default controller set.
INFO - 2016-10-28 18:50:08 --> Router Class Initialized
INFO - 2016-10-28 18:50:08 --> Output Class Initialized
INFO - 2016-10-28 18:50:08 --> Security Class Initialized
DEBUG - 2016-10-28 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:50:08 --> Input Class Initialized
INFO - 2016-10-28 18:50:08 --> Language Class Initialized
INFO - 2016-10-28 18:50:08 --> Loader Class Initialized
INFO - 2016-10-28 18:50:08 --> Helper loaded: url_helper
INFO - 2016-10-28 18:50:08 --> Helper loaded: form_helper
INFO - 2016-10-28 18:50:08 --> Database Driver Class Initialized
INFO - 2016-10-28 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:50:08 --> Controller Class Initialized
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:50:08 --> Model Class Initialized
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_applied.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_records.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/add_leave_record_sidebar.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/manager/leave_records_reports.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:50:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:50:08 --> Final output sent to browser
DEBUG - 2016-10-28 18:50:08 --> Total execution time: 0.0198
INFO - 2016-10-28 18:51:07 --> Config Class Initialized
INFO - 2016-10-28 18:51:07 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:51:07 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:51:07 --> Utf8 Class Initialized
INFO - 2016-10-28 18:51:07 --> URI Class Initialized
INFO - 2016-10-28 18:51:07 --> Router Class Initialized
INFO - 2016-10-28 18:51:07 --> Output Class Initialized
INFO - 2016-10-28 18:51:07 --> Security Class Initialized
DEBUG - 2016-10-28 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:51:07 --> Input Class Initialized
INFO - 2016-10-28 18:51:07 --> Language Class Initialized
INFO - 2016-10-28 18:51:07 --> Loader Class Initialized
INFO - 2016-10-28 18:51:07 --> Helper loaded: url_helper
INFO - 2016-10-28 18:51:07 --> Helper loaded: form_helper
INFO - 2016-10-28 18:51:08 --> Database Driver Class Initialized
INFO - 2016-10-28 18:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:51:08 --> Controller Class Initialized
DEBUG - 2016-10-28 18:51:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 18:51:08 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-10-28 18:51:08 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-10-28 18:51:08 --> Config Class Initialized
INFO - 2016-10-28 18:51:08 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:51:08 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:51:08 --> Utf8 Class Initialized
INFO - 2016-10-28 18:51:08 --> URI Class Initialized
DEBUG - 2016-10-28 18:51:08 --> No URI present. Default controller set.
INFO - 2016-10-28 18:51:08 --> Router Class Initialized
INFO - 2016-10-28 18:51:08 --> Output Class Initialized
INFO - 2016-10-28 18:51:08 --> Security Class Initialized
DEBUG - 2016-10-28 18:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:51:08 --> Input Class Initialized
INFO - 2016-10-28 18:51:08 --> Language Class Initialized
INFO - 2016-10-28 18:51:08 --> Loader Class Initialized
INFO - 2016-10-28 18:51:08 --> Helper loaded: url_helper
INFO - 2016-10-28 18:51:08 --> Helper loaded: form_helper
INFO - 2016-10-28 18:51:08 --> Database Driver Class Initialized
INFO - 2016-10-28 18:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:51:08 --> Controller Class Initialized
INFO - 2016-10-28 18:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 18:51:08 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:51:08 --> Final output sent to browser
DEBUG - 2016-10-28 18:51:08 --> Total execution time: 0.0153
INFO - 2016-10-28 18:51:15 --> Config Class Initialized
INFO - 2016-10-28 18:51:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:51:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:51:15 --> Utf8 Class Initialized
INFO - 2016-10-28 18:51:15 --> URI Class Initialized
INFO - 2016-10-28 18:51:15 --> Router Class Initialized
INFO - 2016-10-28 18:51:15 --> Output Class Initialized
INFO - 2016-10-28 18:51:15 --> Security Class Initialized
DEBUG - 2016-10-28 18:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:51:15 --> Input Class Initialized
INFO - 2016-10-28 18:51:15 --> Language Class Initialized
INFO - 2016-10-28 18:51:15 --> Loader Class Initialized
INFO - 2016-10-28 18:51:15 --> Helper loaded: url_helper
INFO - 2016-10-28 18:51:15 --> Helper loaded: form_helper
INFO - 2016-10-28 18:51:15 --> Database Driver Class Initialized
INFO - 2016-10-28 18:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:51:15 --> Controller Class Initialized
DEBUG - 2016-10-28 18:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 18:51:15 --> Model Class Initialized
INFO - 2016-10-28 18:51:15 --> Final output sent to browser
DEBUG - 2016-10-28 18:51:15 --> Total execution time: 0.0179
INFO - 2016-10-28 18:51:15 --> Config Class Initialized
INFO - 2016-10-28 18:51:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:51:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:51:15 --> Utf8 Class Initialized
INFO - 2016-10-28 18:51:15 --> URI Class Initialized
DEBUG - 2016-10-28 18:51:15 --> No URI present. Default controller set.
INFO - 2016-10-28 18:51:15 --> Router Class Initialized
INFO - 2016-10-28 18:51:15 --> Output Class Initialized
INFO - 2016-10-28 18:51:15 --> Security Class Initialized
DEBUG - 2016-10-28 18:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:51:15 --> Input Class Initialized
INFO - 2016-10-28 18:51:15 --> Language Class Initialized
INFO - 2016-10-28 18:51:15 --> Loader Class Initialized
INFO - 2016-10-28 18:51:15 --> Helper loaded: url_helper
INFO - 2016-10-28 18:51:15 --> Helper loaded: form_helper
INFO - 2016-10-28 18:51:15 --> Database Driver Class Initialized
INFO - 2016-10-28 18:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:51:15 --> Controller Class Initialized
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:51:15 --> Model Class Initialized
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/apply_leave.php
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/employee/my_leave.php
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:51:15 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:51:15 --> Final output sent to browser
DEBUG - 2016-10-28 18:51:15 --> Total execution time: 0.0176
INFO - 2016-10-28 18:53:33 --> Config Class Initialized
INFO - 2016-10-28 18:53:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:53:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:53:33 --> Utf8 Class Initialized
INFO - 2016-10-28 18:53:33 --> URI Class Initialized
INFO - 2016-10-28 18:53:33 --> Router Class Initialized
INFO - 2016-10-28 18:53:33 --> Output Class Initialized
INFO - 2016-10-28 18:53:33 --> Security Class Initialized
DEBUG - 2016-10-28 18:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:53:33 --> Input Class Initialized
INFO - 2016-10-28 18:53:33 --> Language Class Initialized
INFO - 2016-10-28 18:53:33 --> Loader Class Initialized
INFO - 2016-10-28 18:53:33 --> Helper loaded: url_helper
INFO - 2016-10-28 18:53:33 --> Helper loaded: form_helper
INFO - 2016-10-28 18:53:33 --> Database Driver Class Initialized
INFO - 2016-10-28 18:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:53:33 --> Controller Class Initialized
DEBUG - 2016-10-28 18:53:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 18:53:33 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-10-28 18:53:33 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-10-28 18:53:33 --> Config Class Initialized
INFO - 2016-10-28 18:53:33 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:53:33 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:53:33 --> Utf8 Class Initialized
INFO - 2016-10-28 18:53:33 --> URI Class Initialized
DEBUG - 2016-10-28 18:53:33 --> No URI present. Default controller set.
INFO - 2016-10-28 18:53:33 --> Router Class Initialized
INFO - 2016-10-28 18:53:33 --> Output Class Initialized
INFO - 2016-10-28 18:53:33 --> Security Class Initialized
DEBUG - 2016-10-28 18:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:53:33 --> Input Class Initialized
INFO - 2016-10-28 18:53:33 --> Language Class Initialized
INFO - 2016-10-28 18:53:33 --> Loader Class Initialized
INFO - 2016-10-28 18:53:33 --> Helper loaded: url_helper
INFO - 2016-10-28 18:53:33 --> Helper loaded: form_helper
INFO - 2016-10-28 18:53:33 --> Database Driver Class Initialized
INFO - 2016-10-28 18:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:53:33 --> Controller Class Initialized
INFO - 2016-10-28 18:53:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:53:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 18:53:33 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:53:33 --> Final output sent to browser
DEBUG - 2016-10-28 18:53:33 --> Total execution time: 0.0152
INFO - 2016-10-28 18:53:55 --> Config Class Initialized
INFO - 2016-10-28 18:53:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:53:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:53:55 --> Utf8 Class Initialized
INFO - 2016-10-28 18:53:55 --> URI Class Initialized
INFO - 2016-10-28 18:53:55 --> Router Class Initialized
INFO - 2016-10-28 18:53:55 --> Output Class Initialized
INFO - 2016-10-28 18:53:55 --> Security Class Initialized
DEBUG - 2016-10-28 18:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:53:55 --> Input Class Initialized
INFO - 2016-10-28 18:53:55 --> Language Class Initialized
INFO - 2016-10-28 18:53:55 --> Loader Class Initialized
INFO - 2016-10-28 18:53:55 --> Helper loaded: url_helper
INFO - 2016-10-28 18:53:55 --> Helper loaded: form_helper
INFO - 2016-10-28 18:53:55 --> Database Driver Class Initialized
INFO - 2016-10-28 18:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:53:55 --> Controller Class Initialized
DEBUG - 2016-10-28 18:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-10-28 18:53:55 --> Model Class Initialized
INFO - 2016-10-28 18:53:55 --> Final output sent to browser
DEBUG - 2016-10-28 18:53:55 --> Total execution time: 0.0180
INFO - 2016-10-28 18:53:55 --> Config Class Initialized
INFO - 2016-10-28 18:53:55 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:53:55 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:53:55 --> Utf8 Class Initialized
INFO - 2016-10-28 18:53:55 --> URI Class Initialized
DEBUG - 2016-10-28 18:53:55 --> No URI present. Default controller set.
INFO - 2016-10-28 18:53:55 --> Router Class Initialized
INFO - 2016-10-28 18:53:55 --> Output Class Initialized
INFO - 2016-10-28 18:53:55 --> Security Class Initialized
DEBUG - 2016-10-28 18:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:53:55 --> Input Class Initialized
INFO - 2016-10-28 18:53:55 --> Language Class Initialized
INFO - 2016-10-28 18:53:55 --> Loader Class Initialized
INFO - 2016-10-28 18:53:55 --> Helper loaded: url_helper
INFO - 2016-10-28 18:53:55 --> Helper loaded: form_helper
INFO - 2016-10-28 18:53:55 --> Database Driver Class Initialized
INFO - 2016-10-28 18:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:53:55 --> Controller Class Initialized
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:53:55 --> Model Class Initialized
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:53:55 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:53:55 --> Final output sent to browser
DEBUG - 2016-10-28 18:53:55 --> Total execution time: 0.0181
INFO - 2016-10-28 18:54:15 --> Config Class Initialized
INFO - 2016-10-28 18:54:15 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:54:15 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:54:15 --> Utf8 Class Initialized
INFO - 2016-10-28 18:54:15 --> URI Class Initialized
INFO - 2016-10-28 18:54:15 --> Router Class Initialized
INFO - 2016-10-28 18:54:15 --> Output Class Initialized
INFO - 2016-10-28 18:54:15 --> Security Class Initialized
DEBUG - 2016-10-28 18:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:54:15 --> Input Class Initialized
INFO - 2016-10-28 18:54:15 --> Language Class Initialized
INFO - 2016-10-28 18:54:15 --> Loader Class Initialized
INFO - 2016-10-28 18:54:15 --> Helper loaded: url_helper
INFO - 2016-10-28 18:54:15 --> Helper loaded: form_helper
INFO - 2016-10-28 18:54:15 --> Database Driver Class Initialized
INFO - 2016-10-28 18:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:54:15 --> Controller Class Initialized
INFO - 2016-10-28 18:54:15 --> Form Validation Class Initialized
INFO - 2016-10-28 18:54:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-28 18:54:15 --> Final output sent to browser
DEBUG - 2016-10-28 18:54:15 --> Total execution time: 0.0188
INFO - 2016-10-28 18:54:19 --> Config Class Initialized
INFO - 2016-10-28 18:54:19 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:54:19 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:54:19 --> Utf8 Class Initialized
INFO - 2016-10-28 18:54:19 --> URI Class Initialized
DEBUG - 2016-10-28 18:54:19 --> No URI present. Default controller set.
INFO - 2016-10-28 18:54:19 --> Router Class Initialized
INFO - 2016-10-28 18:54:19 --> Output Class Initialized
INFO - 2016-10-28 18:54:19 --> Security Class Initialized
DEBUG - 2016-10-28 18:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:54:19 --> Input Class Initialized
INFO - 2016-10-28 18:54:19 --> Language Class Initialized
INFO - 2016-10-28 18:54:19 --> Loader Class Initialized
INFO - 2016-10-28 18:54:19 --> Helper loaded: url_helper
INFO - 2016-10-28 18:54:19 --> Helper loaded: form_helper
INFO - 2016-10-28 18:54:19 --> Database Driver Class Initialized
INFO - 2016-10-28 18:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:54:19 --> Controller Class Initialized
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/navbar.php
INFO - 2016-10-28 18:54:19 --> Model Class Initialized
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/home.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_user_sidebar.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/add_leave_type.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/all_leave_type.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/leave_reports.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/admin/user_reports.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/dashboard.php
INFO - 2016-10-28 18:54:19 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:54:19 --> Final output sent to browser
DEBUG - 2016-10-28 18:54:19 --> Total execution time: 0.0188
INFO - 2016-10-28 18:54:26 --> Config Class Initialized
INFO - 2016-10-28 18:54:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:54:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:54:26 --> Utf8 Class Initialized
INFO - 2016-10-28 18:54:26 --> URI Class Initialized
INFO - 2016-10-28 18:54:26 --> Router Class Initialized
INFO - 2016-10-28 18:54:26 --> Output Class Initialized
INFO - 2016-10-28 18:54:26 --> Security Class Initialized
DEBUG - 2016-10-28 18:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:54:26 --> Input Class Initialized
INFO - 2016-10-28 18:54:26 --> Language Class Initialized
INFO - 2016-10-28 18:54:26 --> Loader Class Initialized
INFO - 2016-10-28 18:54:26 --> Helper loaded: url_helper
INFO - 2016-10-28 18:54:26 --> Helper loaded: form_helper
INFO - 2016-10-28 18:54:26 --> Database Driver Class Initialized
INFO - 2016-10-28 18:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:54:26 --> Controller Class Initialized
DEBUG - 2016-10-28 18:54:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-10-28 18:54:26 --> Severity: Notice --> Undefined variable: username /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
ERROR - 2016-10-28 18:54:26 --> Severity: Notice --> Undefined variable: password /var/www/html/ramotlonyane_modise/LMS/app/controllers/Auth.php 98
INFO - 2016-10-28 18:54:26 --> Config Class Initialized
INFO - 2016-10-28 18:54:26 --> Hooks Class Initialized
DEBUG - 2016-10-28 18:54:26 --> UTF-8 Support Enabled
INFO - 2016-10-28 18:54:26 --> Utf8 Class Initialized
INFO - 2016-10-28 18:54:26 --> URI Class Initialized
DEBUG - 2016-10-28 18:54:26 --> No URI present. Default controller set.
INFO - 2016-10-28 18:54:26 --> Router Class Initialized
INFO - 2016-10-28 18:54:26 --> Output Class Initialized
INFO - 2016-10-28 18:54:26 --> Security Class Initialized
DEBUG - 2016-10-28 18:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-28 18:54:26 --> Input Class Initialized
INFO - 2016-10-28 18:54:26 --> Language Class Initialized
INFO - 2016-10-28 18:54:26 --> Loader Class Initialized
INFO - 2016-10-28 18:54:26 --> Helper loaded: url_helper
INFO - 2016-10-28 18:54:26 --> Helper loaded: form_helper
INFO - 2016-10-28 18:54:26 --> Database Driver Class Initialized
INFO - 2016-10-28 18:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-28 18:54:26 --> Controller Class Initialized
INFO - 2016-10-28 18:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/header.php
INFO - 2016-10-28 18:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/auth.php
INFO - 2016-10-28 18:54:26 --> File loaded: /var/www/html/ramotlonyane_modise/LMS/app/views/footer.php
INFO - 2016-10-28 18:54:26 --> Final output sent to browser
DEBUG - 2016-10-28 18:54:26 --> Total execution time: 0.0151
