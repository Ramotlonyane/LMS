<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['useragent']	= "CodeIgniter";
$config['mailpath'] 	= "/usr/bin/sendmail";
$config['protocol']		= "smtp";
$config['smtp_timeout'] = 30;
$config['smtp_user']	= "ramotlonyanemodise.gm@gmail.com";
$config['smtp_pass']	= "gabbymodise";
$config['smtp_host'] 	= "ssl://smtp.googlemail.com";
$config['smtp_port']	= "465";
$config['charset'] 		= "utf-8";
$config['crlf'] 		= "\r\n";
//$config['smtp_user']= "rgarces@acin.pt";
//$config['smtp_pass']= "MCkR5Uyv7eRd7K";
//$config['smtp_host']= "ssl://smtp.critsend.com";


//$config['smtp_host'] = "ssl://smtp.gmail.com";
//$config['smtp_host']	= "localhost";



$config['from_email']  	= "ramotlonyanemodise.gm@gmail.com";
$config['admin_email'] 	= "ramotlonyanemodise.gm@gmail.com";
//$this->email->initialize($config);
$config['mailtype'] 	= "html";
$config['newline'] 		= "\r\n";
$config['wordwrap'] 	= TRUE;
