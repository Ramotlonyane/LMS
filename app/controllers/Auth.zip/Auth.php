<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		if($this->session->userdata('logged_in') == TRUE)
		{
			$this->load->view("header");
			$this->load->view("navbar");
			$this->load->view("dashboard");
			$this->load->view("footer");
		}
		else{ 
			$this->login();
		}
	}

	function login()
	{
		$this->load->view('header');
		$this->load->view('auth');
		$this->load->view('footer');
	}

	/*function dashboard()
	{
		if($this->session->userdata('logged_in') == TRUE) {
			$this->load->view("header");
			$this->load->view("navbar");
			$this->load->view("dashboard");
			$this->load->view("footer");
		} else {
			$this->index();
		}
	}*/

	public function logged_in_check()
	{

		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$this->load->library('form_validation');
		$this->form_validation->set_rules("username", "Username", "trim|required");
		$this->form_validation->set_rules("password", "Password", "trim|required");
		/*
		  if ($this->form_validation->run() == true) 
		{
			$this->load->model('auth_model', 'auth');
			// check the username & password of user
			$status = $this->auth->validate($username, $password);
			if ($status == ERR_INVALID_USERNAME) {
				$this->session->set_flashdata("error", "Username is invalid");
			}
			elseif ($status == ERR_INVALID_PASSWORD) {
				$this->session->set_flashdata("error", "Password is invalid");
			}
			else
			{
				// success
				// store the user data to session
				$this->session->set_userdata($this->auth->get_data());
				$this->session->set_userdata("logged_in", true);
				// redirect to dashboard
				redirect(base_url("index.php"));
			}

		}*/

		/*$this->load->database('default');
		$this->load->model('auth_model');
		$state = 0;
		if ($this->auth_model->validate($username, $password)) {
			$state = 1;
		}*/
		$state = 1;
		echo json_encode(array('state' => $state));

	}

	function logout()
	{
		$array_items = array('username' => $name, 'password' => $username );
		$this->session->unset_userdata($array_items);
		$this->session->sess_destroy();

		redirect(base_url("index.php"));
	}
}